/**********************************************************************
						    SCHEDULED REPORTS GRID
**********************************************************************/

var gridMode = "my",
	loadRecordTimer;
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [{
		id: "schedname",
		name: "Schedule Name",
		field: "schedname",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "reptype",
		name: "Report Type",
		field: "reptype",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "status",
		name: "Status",
		field: "status",
		width: 160,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "schedfreq",
		name: "Frequency",
		field: "schedfreq",
		width: 160,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "lastrundate",
		name: "Last Run Date",
		field: "lastrundate",
		width: 160,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "nextrundate",
		name: "Next Run Date",
		field: "nextrundate",
		width: 160,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "schedstart",
		name: "Start Date",
		field: "schedstart",
		width: 160,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "schedend",
		name: "End Date",
		field: "schedend",
		width: 160,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}
];
if (store.get('scheduledOrder')) {
	columns = store.get('scheduledOrder');
}
if (store.get('scheduledWidths')) {
	var setWidth = store.get('scheduledWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};

var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ":  " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: false
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var repString = "", repDataPoint = "reptype";

function myFilter(item, args) {

	if (args.repString != "" && item[repDataPoint].toLowerCase().indexOf(args.repString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}



if (store.get('schedule-data')) {
	data = store.get('schedule-data');
} else {
	store.set('schedule-data', data);
}


function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='scheduled-reports.html'>Scheduled Reports</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Scheduled Report Details");
	} else if (update == "edit") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Edit Scheduled Report");
	} else if (update == "new") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("New Scheduled Report");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Scheduled Reports");
	}
}



/**********************************************************************
SETUP CONTEXT MENU
**********************************************************************/
function checkStatus(arr) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--] !== arr[L]) return false;
	}
	return arr[L];
}
var enableContextItem = function() {
	var text = $(this).children("div.disabled").text();
	$(this).children("div.disabled").replaceWith("<a href='javascript:void(0)'>" + text + "</a>");
};
var disableContextItem = function() {
	var text = $(this).children("a").text();
	$(this).children("a").replaceWith("<div class='disabled'>" + text + "</div>");
};
function setupContextMenu() {
	var sel = selectedRowIds.length,
		$contextItems = $("[data-type='context-item']");
	if (sel == 0) {
		$contextItems.each(disableContextItem);
	} else if (sel == 1) {
		$("[data-action='view'], [data-action='edit'], [data-action='delete']").each(enableContextItem);
	} else if (sel > 1) {
		sameOwner = checkStatus(selectedRowIds);
		$("[data-action='delete']").each(enableContextItem);
		$("[data-action='view'], [data-action='edit']").each(disableContextItem);
	}
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
				   INITIALIZE SCHEDULED REPORTS GRID
	**********************************************************************/

	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	try {
		grid = new Slick.Grid("#scheduledReports", dataView, columns, options);
		grid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		grid.registerPlugin(groupItemMetadataProvider);
		grid.registerPlugin(checkboxSelector);
		var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'scheduledOrder', 'scheduledWidths', ["checkboxSelector"]);
		grid.onContextMenu.subscribe(function(e, args) {
			e.preventDefault();
			var cell = grid.getCellFromEvent(e),
				row = cell.row,
				rows = grid.getSelectedRows(),
				$cmenu = $("#contextMenu");
			if ($.inArray(row, rows) == -1) {
				grid.setSelectedRows([row]);
			}
			grid.setActiveCell(row, cell.cell)
			setupContextMenu();
			var cheight = $cmenu.height(),
				winwidth = $(window).width(),
				winheight = $(window).height(),
				leftpos = e.pageX,
				toppos = e.pageY;
			if (e.pageX + 210 > winwidth) {
				leftpos = e.pageX - 205;
			}
			if (e.pageY + cheight > winheight) {
				toppos = e.pageY - cheight;
				if (toppos < 0) {
					toppos = e.pageY - (cheight - (winheight - e.pageY));
				}
			};
			$(document).off("keyup.hide-context");
			$("body").off("click.hide-context");

			function hideContextMenu() {
				$(".control-menus").children(".control-menu:visible").hide();
				$(".control-list").find(".on").removeClass("on");
				$(".control-menus").find("a.sub-open").removeClass("sub-open");
			}
			hideContextMenu();
			console.log(toppos);
			$cmenu.css("top", toppos).css("left", leftpos).show();
			$(document).on("keyup.hide-context", function(e) {
				if (e.keyCode == 27) {
					hideContextMenu()
				}
			});
			$("body").one("click.hide-context", function() {
				hideContextMenu()
			});
		});
		grid.onSelectedRowsChanged.subscribe(function(e) {
			$(document).off("keyup.hide-menu");
			$(".shell").off("resize.hide-menu");
			$("body").off("click.hide-menu");
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			selectedRowIds = [];
			var rows = grid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = dataView.getItem(rows[i])
				if (item.id) {
					selectedRowIds.push(item.id);
				}
			}
			if (selectedRowIds.length > 0) {
				$("#scheduledReports").addClass("has-bottom-controls");
				$("#reportSummary .bottom-controls").removeClass("hidden");
				$("#selectedCount").html(selectedRowIds.length);
			} else {
				$("#scheduledReports").removeClass("has-bottom-controls");
				$("#reportSummary .bottom-controls").addClass("hidden");
				$("#selectedCount").html('');
			}
			grid.resizeCanvas();
		});
		grid.onSort.subscribe(function(e, args) {
			var cols = args.sortCols;
			dataView.sort(function(dataRow1, dataRow2) {
				for (var i = 0, l = cols.length; i < l; i++) {
					sortdir = cols[i].sortAsc ? 1 : -1;
					sortcol = cols[i].sortCol.field;
					var _sorter = cols[i].sortCol.sorter,
						result;
					if (_sorter == "sorterStringCompare") {
						result = sorterStringCompare(dataRow1, dataRow2);
					} else if (_sorter == "sorterNumeric") {
						result = sorterNumeric(dataRow1, dataRow2);
					} else if (_sorter == "sorterDateIso") {
						result = sorterDateIso(dataRow1, dataRow2);
					} else if (_sorter == "sorterTime") {
						result = sorterTime(dataRow1, dataRow2);
					}
					if (result != 0) {
						return result;
					}
				}
				return 0;
			});
			args.grid.invalidateAllRows();
			args.grid.render();
		});
		grid.onClick.subscribe(function(e, args) {
			var cell = grid.getCellFromEvent(e);
			var row = cell.row;
			var item = dataView.getItem(row);
			var $row = $(e.target).closest(".slick-row");
			if (!$row.is(".slick-group, .slick-group-totals")) {
				$row.attr({
					'data-panel': '#reportViewDetail',
					'data-switch': 'switch-panels'
				}).trigger('click.switch-panels');
				$row.removeAttr("data-panel data-switch");
				updateBreadcrumb("view");
				grid.setSelectedRows(0);
				selectedRowIds = [];
				$("[data-value='schedulename']").html(item.schedname);
				$("[data-value='schedulestart']").html(item.schedstart);
				$("[data-value='scheduleend']").html(item.schedend);
				$("[data-value='frequency']").html(item.schedfreq);
				$("[data-value='frequency_detail']").html(item.schedfreqdetail);
				var repname = item.repname || item.reportname;
				var repdesc = item.description || item.reportdesc;
				var repformat = item.repformat || item.reportformat;
				var reptype = item.reptype || item.reptype;
				var repencoding = item.repencoding || item.repencoding;
				var replanguage = item.replanguage || item.replanguage;
				$("[data-value='reportname']").html(repname);
				$("[data-value='reportdesc']").html(repdesc);
				$("[data-value='reportformat']").html(repformat);
				$("[data-value='reportencoding']").html(repencoding);
				$("[data-value='reportlanguage']").html(replanguage);
				$("[data-value='reporttype']").html(reptype);
				$("[data-value='datefilter']").html();
				if (item.repprofile == "Y") {
					$("#_reportinfo1").show();
					viewmode(item);
				} else
					$("#_reportinfo1").hide();
			}
		});
		grid.onColumnsResized.subscribe(function(e, args) {
			store.set('scheduledWidths', grid.getColumns());
		});
		$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
			var columnId = $(this).data("columnId");
			var $icon = $(this).next("i");
			if (columnId != null) {
				columnFilters[columnId] = $.trim($(this).val());
				$icon.show();
				dataView.refresh();
				if (!$(this).val()) {
					$icon.hide();
				}
			}
		});
		grid.onHeaderRowCellRendered.subscribe(function(e, args) {
			if (args.column.id == "_checkbox_selector") {
				return false;
			} else {
				$(args.node).empty().addClass(args.column.headerCssClass);
				var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
				var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
					e.preventDefault();
					$(this).prev("input[type='text']").val("").trigger("change");
					$(this).hide();
				});
				if ($input.val()) {
					$icon.show();
				}
			}
		});
		dataView.onRowCountChanged.subscribe(function(e, args) {
			grid.updateRowCount();
			grid.render();
		});
		dataView.onRowsChanged.subscribe(function(e, args) {
			grid.invalidateRows(args.rows);
			grid.render();
			if (selectedRowIds.length > 0) {
				var selRows = [];
				for (var i = 0; i < selectedRowIds.length; i++) {
					var idx = dataView.getRowById(selectedRowIds[i]);
					if (idx != undefined)
						selRows.push(idx);
				}
				grid.setSelectedRows(selRows);
			}
		});
		dataView.setItems(data);
		dataView.setFilterArgs({
			repString: repString
		});
		dataView.syncGridSelection(grid, true, false);
		dataView.syncGridCellCssStyles(grid, "contextMenu");
		dataView.setFilter(myFilter);
		grid.setColumns(columns);
		if (store.get('scheduledOrder')) {
			var visibleScheduledColumns = [];
			for (var i = 0; i < store.get('scheduledOrder').length + 1; i++) {
				if (columns[i].visible) {
					visibleScheduledColumns.push(columns[i])
				}
			}
			grid.setColumns(visibleScheduledColumns);
		}
		grid.setHeaderRowVisibility(false);
	} catch (e) {}

	function viewmode(item) {
		if (item.filtertype == "Currency") {
			$("#_filters").find("label").html("Selected Currencies")
			filterColumns = [{
				id: "ccy",
				name: "Currency Code",
				field: "ccy",
				toolTip: "Click to sort by Currency Code",
				width: 150,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "ccyname",
				name: "Currency Description",
				field: "ccyname",
				toolTip: "Click to sort by Currency Description",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterCurrencyData = item.filters
		} else if (item.filtertype == "Account" || item.filtertype == undefined) {
			$("#_filters").find("label").html("Selected Accounts")
			filterColumns = [{
				id: "accountnam",
				name: "Account Name",
				field: "accountnam",
				toolTip: "Click to sort by Account Name",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "accountnum",
				name: "Account Number",
				field: "accountnum",
				toolTip: "Click to sort by Account Number",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterAccountData = item.filters
		}
		filterData = item.filters || [];
		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e, args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e, args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});
		filterDataView.setItems(filterData);
		filterGrid.setColumns(filterColumns);
	}

	/**********************************************************************
							GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});


	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
					      DELETE SCHEDULES INTERACTIONS
	**********************************************************************/

	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});

	$("#_datefilterfield").on("change", function(e) {
		var printDate = $(this).val(),
			$printDiv = $("#_printdate");
		if (printDate == "Specific Date") {
			$printDiv.html('').hide();
			$("#_datefrom, #_dateto").attr({
				"disabled": "disabled"
			}).datepicker("destroy").val('').hide();
			$("#_datefrom").show().removeAttr("disabled").attr("placeholder", "Date").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				maxDate: 0
			}).focus().blur();
		} else if (printDate == "Date Range") {
			$printDiv.html('').hide();
			$("#_datefrom").attr({
				"disabled": "disabled"
			}).datepicker("destroy").val('').hide();
			$("#_datefrom").attr("placeholder", "From");
			$("#_dateto").attr("placeholder", "To");
			$("#_datefrom, #_dateto").removeAttr("disabled").show()
			var dates = $("#_datefrom, #_dateto").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				maxDate: 0,
				onSelect: function(selectedDate) {
					var option = this.id == "_datefrom" ? "minDate" : "maxDate",
						instance = $(this).data("datepicker"),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings);
					dates.not(this).datepicker("option", option, date);
				}
			});
			$("#_datefrom").focus().blur();
		} else {
			$("#_datefrom, #_dateto").hide().attr({
				"disabled": "disabled"
			}).datepicker("destroy").val('');
		}
	});

	$("body").on("click.delete-sel", "[data-action='delete-selected']", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" || $target.prop("nodeName") == "I") {
			$("#contextMenu").hide();
			if (selectedRowIds.length > 0) {

				function deleteScheduledReports() {
					$target.attr({
						'data-switch': 'switch-panels',
						'data-panel': '#reportSummary'
					}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
					var rowsForDelete = [];
					for (var i = 0, l = selectedRowIds.length; i < l; i++) {
						var item = selectedRowIds[i];
						if (item) rowsForDelete.unshift(item)
					};
					for (var i = 0; i < rowsForDelete.length; i++) {
						dataView.deleteItem(rowsForDelete[i])
					};
					grid.setSelectedRows(0);
					selectedRowIds = [];
					dataView.refresh();
					grid.invalidate();
					grid.render();
					if (groupCollapseSetting == 1) {
						collapseAllGroups()
					};
					groupedSetting = 1;
					buildNotification("Report profiles have been deleted.", 300, 3000);
				}

				function deleteProfiles() {
					$target.attr({
						'data-switch': 'switch-panels',
						'data-panel': '#reportSummary'
					}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
					var rowsForDelete = [];
					for (var i = 0, l = selectedRowIds.length; i < l; i++) {
						var item = selectedRowIds[i];
						if (item) rowsForDelete.unshift(item)
					};
					for (var i = 0; i < rowsForDelete.length; i++) {
						dataView.deleteItem(rowsForDelete[i])
					};
					if (gridMode == "my") {
						for (var i = 0; i < rowsForDelete.length; i++) {
							for (var d = 0; d < sharedData.length; d++) {
								if (rowsForDelete[i] == sharedData[d].id) {
									sharedData.splice(d, 1)
								}
							}
						}
						store.set('schedule-data', data);
					} else {
						for (var i = 0; i < rowsForDelete.length; i++) {
							for (var d = 0; d < data.length; d++) {
								if (rowsForDelete[i] == data[d].id) {
									data.splice(d, 1)
								}
							}
						}
					}
					grid.setSelectedRows(0);
					selectedRowIds = [];
					dataView.refresh();
					grid.invalidate();
					grid.render();
					if (groupCollapseSetting == 1) {
						collapseAllGroups()
					};
					groupedSetting = 1;
					buildNotification("Scheduled profiles have been deleted.", 300, 3000);
				}

				buildConfirmDialog("Delete selected schedule profiles?", "", function() {
					deleteProfiles(e)
				});
			} else {
				return false;
			}
		}
	});

	$("body").on("click.view-sel", "[data-action='view']", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" || $target.prop("nodeName") == "I") {
			$("#contextMenu").hide();
			if (selectedRowIds.length == 1) {
				var cell = grid.getActiveCell();
				var row = cell.row;
				var item = dataView.getItem(row);
				$(this).attr({
					'data-panel': '#reportViewDetail',
					'data-switch': 'switch-panels'
				}).trigger('click.switch-panels');
				$(this).removeAttr("data-panel data-switch");
				updateBreadcrumb("view");
				grid.setSelectedRows(0);
				selectedRowIds = [];
				$("[data-value='schedulename']").html(item.schedname);
				$("[data-value='schedulestart']").html(item.schedstart);
				$("[data-value='scheduleend']").html(item.schedend);
				$("[data-value='frequency']").html(item.schedfreq);
				$("[data-value='frequency_detail']").html(item.schedfreqdetail);
				var repname = item.repname || item.reportname;
				var repdesc = item.description || item.reportdesc;
				var repformat = item.repformat || item.reportformat;
				var reptype = item.reptype || item.reptype;
				var repencoding = item.repencoding || item.repencoding;
				var replanguage = item.replanguage || item.replanguage;
				$("[data-value='reportname']").html(repname);
				$("[data-value='reportdesc']").html(repdesc);
				$("[data-value='reportformat']").html(repformat);
				$("[data-value='reportencoding']").html(repencoding);
				$("[data-value='reportlanguage']").html(replanguage);
				$("[data-value='reporttype']").html(reptype);
				$("[data-value='datefilter']").html();
				if (item.repprofile == "Y") {
					$("#_reportinfo1").show();
					viewmode(item);
				} else {
					$("#_reportinfo1").hide();
				}
			} else {
				return false;
			}
		}
	});

	$("body").on("click.edit-sel", "[data-action='edit']", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" || $target.prop("nodeName") == "I") {
			$("#contextMenu").hide();
			if (selectedRowIds.length == 1) {
				var $target = $(e.target),
					dt = new Date(),
					currentTime = dt.getHours() + ":" + dt.getMinutes(),
					auditLog = $.datepicker.formatDate('dd/mm/yy', new Date()) + " at " + currentTime;
				$target.attr({
					'data-switch': 'switch-panels',
					'data-panel': '#reportDetail'
				}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
				updateBreadcrumb("edit");
				var item = dataView.getItem(grid.getActiveCell().row);
				grid.setSelectedRows(0);
				selectedRowIds = [];
				$('#reporttypeedit').val(item.reptype);
				$('#reportformatedit').val(item.repformat);
				$('#reportnameedit').val(item.repname || item.reportname);
				$('#reportdesedit').val(item.description || item.reportdesc);
				$('#sh_name').val(item.schedname);
				$('#_editStartDate').val(item.schedstart);
				$('#_editEndDate').val(item.schedend);
				$('#fr').val(item.schedfreq);
				if (item.schedfreq == "Daily") {
					$("#fr_detail").hide();
				} else {
					$("#fr_detail").show();
				}
				$('#showreportedit').show();
				if (item.repprofile == "Y") {
					$('#reportexistingedit').prop("checked", true);
					$('#_newreportedit').prop("checked", false);
				} else {
					$('#_newreportedit').prop("checked", true);
					$('#reporttypeedit').val('');
					$('#reportformatedit').val('');
					$('#reportnameedit').val('');
					$('#reportdesedit').val('');
				}				
			} else {
				return false;
			}
		}
	});


	$("#_newReportButton").on("click", function(e) {
		updateBreadcrumb("new");
		$("#_newReportData").find(":input").val('');
		$("#_createdLog").remove();
	});

	$("#reporttypeedit ,#reportformatedit ,#reportencedit, #reportlanedit ,#reportnameedit, #reportdesedit, #emaileditdev").on("change", function() {
		$('#_newreportedit').prop("checked", true);
	});

	$("#reporttype").on("change", function(e) {
		if ($('#reporttype').val() != "") {
			$("#_repFilter").show();
			$("#_scheduleinfo").show();
		} else {
			$("#_repFilter").hide();
			$("#_scheduleinfo").hide();
		}
	});

	$("#_editButton1").on("click", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			dt = new Date(),
			currentTime = dt.getHours() + ":" + dt.getMinutes(),
			auditLog = $.datepicker.formatDate('dd/mm/yy', new Date()) + " at " + currentTime;
		$target.attr({
			'data-switch': 'switch-panels',
			'data-panel': '#reportDetail'
		}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
		updateBreadcrumb("edit");
		var item = dataView.getItem(grid.getActiveCell().row);
		grid.setSelectedRows(0);
		selectedRowIds = [];
		$('#reporttypeedit').val(item.reptype);
		$('#reportformatedit').val(item.repformat);
		$('#reportnameedit').val(item.repname || item.reportname);
		$('#reportdesedit').val(item.description || item.reportdesc);
		$('#sh_name').val(item.schedname);
		$('#_editStartDate').val(item.schedstart);
		$('#_editEndDate').val(item.schedend);
		$('#fr').val(item.schedfreq);
		if (item.schedfreq == "Daily") {
			$("#fr_detail").hide();
		} else {
			$("#fr_detail").show();
		}
		$('#showreportedit').show();
		if (item.repprofile == "Y") {
			$('#reportexistingedit').prop("checked", true);
			$('#_newreportedit').prop("checked", false);
		} else {
			$('#_newreportedit').prop("checked", true);
			$('#reporttypeedit').val('');
			$('#reportformatedit').val('');
			$('#reportnameedit').val('');
			$('#reportdesedit').val('');
		}
	});

	$("#_updateReport").on("click", function(e) {
		e.preventDefault();

		var $row = $("#reporttypeedit").closest("div.row"),
			$row1 = $("#sh_name").closest("div.row"),
			$row2 = $("#_editStartDate").closest("div.row"),
			$row3 = $("#_editEndDate").closest("div.row");
		if ($("#reporttypeedit").val() == "") {
			$row.addClass("error");
		} else {
			$row.removeClass("error");
		}
		if ($("#sh_name").val() == "") {
			$row1.addClass("error");
		} else {
			$row1.removeClass("error");
		}
		if ($("#_editStartDate").val() == "") {
			$row2.addClass("error");
		} else {
			$row2.removeClass("error");
		}
		if ($("#_editEndDate").val() == "") {
			$row3.addClass("error");
		} else {
			$row3.removeClass("error");
		}
		if ($row.hasClass("error") || $row1.hasClass("error") || $row2.hasClass("error") || $row3.hasClass("error")) {
			return false;
		}
		if ($("input[name='reportnew']:checked").val() == "new") {
			saveNewReport1();
		}
		var $target = $(e.target),
			dt = new Date(),
			currentTime = dt.getHours() + ":" + dt.getMinutes(),
			auditLog = $.datepicker.formatDate('dd/mm/yy', new Date()) + " at " + currentTime;
		$target.attr({
			'data-switch': 'switch-panels',
			'data-panel': '#reportSummary'
		}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
		if ($("#_lastMod").size() > 0) {
			$("#_lastMod").remove()
		};
		var $auditLine = $("<div class='row fluid' id='_lastMod'><div class='label-column'><label>Last Modified</label></div><div class='data-column'><div class='data-text'>" + auditLog + " by USER1</div></div></div>").appendTo($("#_audit"));
		buildNotification("Schedule profiles have been updated.", 300, 3000);
	});

	function saveNewReport1() {
		var sharedSetting, sharedBySetting;
		var newID = Math.round(Math.random() * 1000000000);
		var scheduledata = store.get('schedule-data');
		var ll = scheduledata.length;
		if ($("#_sharedfield").is(":checked")) {
			sharedSetting = "&#x2713;";
			sharedBySetting = "PrototypeUser"
		} else {
			sharedSetting = "";
			sharedBySetting = ""
		}
		var schedules = [];
		var schedule_obj = {};
		if ($("#_editStartDate").val() != "" && $("#_editEndDate").val() != "") {
			schedule_obj.id = "id_" + (ll + 1);
			schedule_obj.name = $("#sh_name").val();
			schedule_obj.status = 'active';
			schedule_obj.startdate = $("#_editStartDate").val();
			schedule_obj.enddate = $("#_editEndDate").val();
			schedule_obj.frequency = $("#fr").val();
			schedule_obj.frequencydetail = $("#fr").val();
			schedule_obj.lastrundate = "";
			schedule_obj.nextrundate = "";
			schedule_obj.ownedby = "PrototypeUser";
			schedule_obj.filtertype = $("#_filteroption").find("input[name='ftype1']:checked").val();
			try {
				schedule_obj.filters = filterDataView.getItems();
			} catch (e) {}
			schedules.push(schedule_obj);
			schedulesnumber = schedules.length;
		} else {
			schedulesnumber = '-';
			schedules = [];
		}
		var updatedItem = {
			id: newID,
			reptype: $("#reporttypeedit").val(),
			repname: $("#reportnameedit").val(),
			repformat: $("#reportformatedit").val(),
			description: $("#reportdesedit").val(),
			grouped: $("#_groupField").is(":checked"),
			shared: sharedSetting,
			sharedby: sharedBySetting,
			ownedby: "PrototypeUser",
			createdon: $.datepicker.formatDate('dd/mm/yy', new Date()),
			datefilter: $("#_datefilterfield").val(),
			fromdate: $("#_datefrom").val(),
			todate: $("#_dateto").val(),
			filtertype: $("#_filteroption").find("input[name='ftype1']:checked").val(),
			filters: schedule_obj.filters,
			schedules: schedules,
			schedulesnumber: schedulesnumber
		};
		var reportdata = store.get('report-data');
		reportdata.push(updatedItem)
			//dataViewSchedule.setItems(schedules)
		store.set('report-data', reportdata);
		if ($("#_editStartDate").val() != "" && $("#_editEndDate").val() != "") {
			var scheduledata = store.get('schedule-data');
			var ll = scheduledata.length;
			var obj1 = {};
			obj1.id = "id_" + (ll + 1)
			obj1.lastrundate = "";
			obj1.nextrundate = "";
			obj1.repprofile = "Y";
			obj1.reptype = $('#reporttypeedit').val();
			obj1.repname = $("#reportnameedit").val();
			obj1.repformat = $("#reportformatedit").val();
			obj1.description = $("#reportdesedit").val();
			obj1.schedend = $('#_editEndDate').val();
			obj1.schedfreq = $('#fr').val();
			obj1.schedname = $('#sh_name').val();
			obj1.schedstart = $('#_editStartDate').val();
			obj1.status = "Active";
			scheduledata.push(obj1);
			store.set('schedule-data', scheduledata);
			dataView.setItems(scheduledata);
			dataView.refresh();
		}
		if ($("#_sharedfield").is(":checked")) {
			sharedData.push(updatedItem)
		}
	}

	$("#_saveNewReport").on("click", function(e) {
		e.preventDefault();
		var $row = $("#schedulename").closest("div.row"),
			$row1 = $("#_newStartDate").closest("div.row"),
			$row2 = $("#_newEndDate").closest("div.row"),
			$row3 = $("#reporttype").closest("div.row"),
			$row4 = $("#reportformat").closest("div.row"),
			$row5 = $('#_f1').closest('div.row');
		if ($("#schedulename").val() == "") {
			$row.addClass("error");
		} else {
			$row.removeClass("error");
		}
		if ($("#_newStartDate").val() == "") {
			$row1.addClass("error");
		} else {
			$row1.removeClass("error");
		}
		if ($("#_newEndDate").val() == "") {
			$row2.addClass("error");
		} else {
			$row2.removeClass("error");
		}
		if ($("#reporttype").val() == "") {
			$row3.addClass("error");
		} else {
			$row3.removeClass("error");
		}
		if ($("#reportformat").val() == "") {
			$row4.addClass("error");
		} else {
			$row4.removeClass("error");
		}
		if ($("#_reportForm input[name='ftype']:checked").val() == undefined) {
			$row5.addClass("error");
		} else {
			$row5.removeClass("error");
		}
		if ($row.hasClass("error") || $row1.hasClass("error") || $row2.hasClass("error") || $row3.hasClass("error") || $row4.hasClass("error")) {
			return false;
		}
		var $target = $(e.target),
			dt = new Date(),
			currentTime = dt.getHours() + ":" + dt.getMinutes(),
			auditLog = $.datepicker.formatDate('dd/mm/yy', new Date()) + " at " + currentTime;
		$target.attr({
			'data-switch': 'switch-panels',
			'data-panel': '#reportSummary'
		}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
		if ($("#_createdLog").size() > 0) {
			if ($("#_newlastMod").size() > 0) {
				$("#_newlastMod").remove()
			};
			var $auditLine = $("<div class='row fluid' id='_newlastMod'><div class='label-column'><label>Last Modified</label></div><div class='data-column'><div class='data-text'>" + auditLog + " by USER1</div></div></div>").appendTo($("#_newaudit"));
		} else {
			var $auditLine = $("<span id='_createdLog'><span class='section-heading'>Audit History</span><div class='data-section' id='_newaudit'><div class='bg-fix'></div><div class='row fluid'><div class='label-column'><label>Created</label></div><div class='data-column'><div class='data-text'>" + auditLog + " by USER1</div></div></div></div></span>").appendTo($("#_newReportData"));
		}
		var ll = data.length;
		var obj = {};
		obj.id = "id_" + (ll + 1)
		obj.lastrundate = "";
		obj.nextrundate = "";
		obj.repprofile = "Y";
		obj.reptype = $('#reporttype').val();
		obj.repname = $("#reportname").val();
		obj.repformat = $("#reportformat").val();
		obj.description = $("#reportdesc").val();
		obj.schedend = $('#_newEndDate').val();
		obj.schedfreq = $('#_frequency').val();
		obj.schedfreqdetail = $("#_frequency_detail").val();
		obj.schedname = $('#schedulename').val();
		obj.schedstart = $('#_newStartDate').val();
		obj.status = "Active";
		obj.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
		obj.filters = filterDataView.getItems();
		data.push(obj);
		store.set('schedule-data', data);
		dataView.refresh();
		if ($('input[name="reportnew"]:checked').val() == "new") {
			var schedules = [];
			var schedule_obj = {};
			schedule_obj.id = "id_1";
			schedule_obj.name = $("#_schedulename").val();
			schedule_obj.status = 'active';
			schedule_obj.startdate = $("#_editStartDate").val();
			schedule_obj.enddate = $("#_editEndDate").val();
			schedule_obj.frequency = $("#_schedulefrequencyday").val();
			schedule_obj.lastrundate = "";
			schedule_obj.nextrundate = "";
			schedule_obj.ownedby = "PrototypeUser";
			schedule_obj.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
			schedule_obj.filters = filterDataView.getItems();
			schedules.push(schedule_obj);
			saveNewReport(schedule_obj);
		}
	});

	function saveNewReport(sch) {
		var sharedSetting, sharedBySetting;
		var newID = Math.round(Math.random() * 1000000000);
		var updatedItem = {
			id: newID,
			reptype: $("#reporttype").val(),
			repname: $("#reportname").val(),
			repformat: $("#reportformat").val(),
			description: $("#reportdesc").val(),
			grouped: $("#_groupField").is(":checked"),
			shared: sharedSetting,
			sharedby: sharedBySetting,
			ownedby: "PrototypeUser",
			createdon: $.datepicker.formatDate('dd/mm/yy', new Date()),
			datefilter: $("#_datefilterfield").val(),
			fromdate: $("#_datefrom").val(),
			todate: $("#_dateto").val(),
			filtertype: $("#_filteroption").find("input[name='ftype']:checked").val(),
			filters: filterDataView.getItems(),
			schedules: [sch],
			schedulesnumber: 1
		};
		var newdata = store.get('report-data');
		newdata.push(updatedItem)
		store.set('report-data', newdata);
		dataView.setItems(data);
		dataView.refresh();
	}

	$("#_reportForm input[name='ftype']").on("change", function(e) {
		$('#_f1').val("Currency");
		$('#_f2').val("Account");
		var type = $("input[name='ftype']:checked").val();
		//alert(type)
		if (!$("#_filters").is(":visible")) {
			$("#_filters").show()
		}
		if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
			filterGrid.destroy();
			filterData = []
		}

		if (type == "Currency" || type == "") {
			$("#_filterBtns").show().find("a[data-action='add-filters']").attr("href", "#_addCurrencies")
			$("#_filters").find("label").html("Select Currencies")
			filterColumns = [{
				id: "ccy",
				name: "Currency Code",
				field: "ccy",
				toolTip: "Click to sort by Currency Code",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "ccyname",
				name: "Currency Description",
				field: "ccyname",
				toolTip: "Click to sort by Currency Description",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterData = filterCurrencyData
		} else if (type == "Account") {
			$("#_filterBtns").show().find("a[data-action='add-filters']").attr("href", "#_addAccounts")
			$("#_filters").find("label").html("Select Accounts")
			filterColumns = [{
				id: "accountnam",
				name: "Account Name",
				field: "accountnam",
				toolTip: "Click to sort by Account Name",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "accountnum",
				name: "Account Number",
				field: "accountnum",
				toolTip: "Click to sort by Account Number",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterData = filterAccountData
		}
		var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
			cssClass: "slick-cell-checkboxsel"
		});
		filterColumns.unshift(filterCheckboxSelector.getColumnDefinition());

		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
		filterGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		filterGrid.registerPlugin(filterCheckboxSelector);
		filterGrid.onSelectedRowsChanged.subscribe(function(e) {
			filterSelectedRowIds = [];
			var rows = filterGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = filterDataView.getItem(rows[i]);
				if (item) filterSelectedRowIds.push(item.id);
			}
		});
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e, args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e, args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});
		filterDataView.setItems(filterData);
		filterGrid.setColumns(filterColumns);
	});

	$("input[name='ftype1']").on("change", function(e) {
		$('#_f11').val("Currency");
		$('#_f21').val("Account");
		var type = $("input[name='ftype1']:checked").val();
		//alert(type)
		if (!$("#_filters1").is(":visible")) {
			$("#_filters1").show()
		}
		if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
			filterGrid.destroy();
			filterData = []
		}

		if (type == "Currency" || type == "") {
			$("#_filterBtns1").show().find("a[data-action='add-filters']").attr("href", "#_addCurrencies")
			$("#_filters1").find("label").html("Select Currencies")
			filterColumns = [{
				id: "ccy",
				name: "Currency Code",
				field: "ccy",
				toolTip: "Click to sort by Currency Code",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "ccyname",
				name: "Currency Description",
				field: "ccyname",
				toolTip: "Click to sort by Currency Description",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterData = filterCurrencyData
		} else if (type == "Account") {
			$("#_filterBtns1").show().find("a[data-action='add-filters']").attr("href", "#_addAccounts")
			$("#_filters1").find("label").html("Select Accounts")
			filterColumns = [{
				id: "accountnam",
				name: "Account Name",
				field: "accountnam",
				toolTip: "Click to sort by Account Name",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "accountnum",
				name: "Account Number",
				field: "accountnum",
				toolTip: "Click to sort by Account Number",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterData = filterAccountData
		}
		var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
			cssClass: "slick-cell-checkboxsel"
		});
		filterColumns.unshift(filterCheckboxSelector.getColumnDefinition());

		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters1", filterDataView, filterColumns, filterOptions);
		filterGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		filterGrid.registerPlugin(filterCheckboxSelector);
		filterGrid.onSelectedRowsChanged.subscribe(function(e) {
			filterSelectedRowIds = [];
			var rows = filterGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = filterDataView.getItem(rows[i]);
				if (item) filterSelectedRowIds.push(item.id);
			}
		});
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e, args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e, args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});
		filterDataView.setItems(filterData);
		filterGrid.setColumns(filterColumns);
	});

	$("#_newreport").on("click", function(e) {
		$('#_reportinfo').show();
		$('#reporttype').val("");
		$('#reportname').val("");
		$('#reportdesc').val("");
		$('#reportformat').val("");
		$("#_newreport").prop("checked", true);
	});

	$("#reportexisting").on("click", function(e) {
		//e.preventDefault();
		$("#reportexisting").prop("checked", true);
		$('#_reportinfo').hide();
		showExistingReport($(this));
	});

	$("#_newreportedit").on("click", function(e) {
		$('#_reportinfoedit').show();
		$('#reporttypeedit').val("");
		$('#reportnameedit').val("");
		$('#reportdesedit').val("");

		$('#reportformatedit').val("");
		$("#_newreportedit").prop("checked", true);
	});

	$("#reportexistingedit").on("click", function(e) {
		//e.preventDefault();
		$("#reportexistingedit").prop("checked", true);
		$('#_reportinfoedit').hide();
		showExistingReport($(this));
	});

	function showExistingReport(_target) {

		function saveSelectedReports(_dialog) {
			if ($target.val()) {
				var selectedReport = mergerecords[$target.val()];
				$('#_reportinfo').show();
				$("#_repFilter").show();
				$("#_scheduleinfo").show();
				$('#reporttype').val(selectedReport.reptype);
				$('#reportname').val(selectedReport.repname);
				$('#reportdesc').val(selectedReport.description);
				$('#reportformat').val(selectedReport.repformat);
				$('#reporttypeedit').val(selectedReport.reptype);
				$('#reportnameedit').val(selectedReport.repname);
				$('#reportdescedit').val(selectedReport.description);
				$('#reportformatedit').val(selectedReport.repformat);
				dialogHider(_dialog);
			} else {
				dialogHider(_dialog);
			}
		}

		var $wrapper = $("<div class='widget-accounts wrapper' />"),

			/* build the account filter input */
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a Report...' />").on("keyup", function() {
				if (this.value != '') {
					$("#clearAccountsFilter").show()
				} else {
					$("#clearAccountsFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#AddAccountsFilterInput").val("").trigger("change");
				$(this).hide();
			}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
			$nameHeader = $("<div class='fav-header-col' style='width: 220px;'>Report Name</div>").appendTo($header),
			$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Report Type</div>").appendTo($header),
			$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Report Description</div>").appendTo($header),
			$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Shared</div>").appendTo($header),
			$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Shared By</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
			$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
			$li, $row, $checkDiv, $checkInput, $name, $number, $currency;

		var mergerecords = $.merge(store.get('report-data'), store.get('report-sharedData'));

		var $target;
		$.each(mergerecords, function(index) {

			/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
			var _alreadyAdded = false;

			if (!_alreadyAdded) {
				$li = $("<li>").appendTo($ul),
					$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
						$target = $(e.target);
						if ($target.prop("nodeName") == "DIV") {
							if ($target.hasClass("fav-data-col")) {
								$target = $target.closest("div.fav-row");
							}
							$target.parent().parent().find("div.fav-row").removeClass("selected");
							$target = $target.find("input[name='_addAccount']");
							$target.closest("div.fav-row").addClass("selected")
						}

					});
				var $name = $("<div class='fav-data-col' style='width: 220px;'><input name='_addAccount' type=hidden id='' value='" + index + "' >" + this.repname + "</div>").appendTo($row),
					$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.reptype + "</div>").appendTo($row),
					$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.description + "</div>").appendTo($row),
					$currency = $("<div class='fav-data-col' style='width: 160px;text-align:center'>" + this.shared + "</div>").appendTo($row),
					$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.sharedby + "</div>").appendTo($row);
			}
		});

		/* build and show the add accounts dialog */
		var _origin = _target;
		var _dialog = {
			id: "AddAccounts",
			title: "Select a Report",
			size: "xxl",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						$("#_newreport").prop("checked", true);
						$('#_reportinfo').show();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						saveSelectedReports(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
			var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no reports to add</div>").appendTo($dataContainer);
		}
	}

	$("#_saveAndAddNew").on("click", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		$target.attr({
			'data-switch': 'switch-panels',
			'data-panel': '#reportNew'
		}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
		$("#_newReportData").find(":input").val('');
		$("#_createdLog").remove();
		$("#_weekly, #_monthly").hide();
	});

	var newRepDates = $("#_newStartDate, #_newEndDate").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			var option = this.id == "_newStartDate" ? "minDate" : "maxDate",
				instance = $(this).data("datepicker"),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings);
			newRepDates.not(this).datepicker("option", option, date);
		}
	});

	var editRepDates = $("#_editStartDate, #_editEndDate").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			var option = this.id == "_editStartDate" ? "minDate" : "maxDate",
				instance = $(this).data("datepicker"),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings);
			newRepDates.not(this).datepicker("option", option, date);
		}
	});

	$("#_frequency").on("change", function(e) {
		var frq = $(this).val();
		if (frq == "Daily") {
			$("#_weekly, #_monthly").hide()
		} else if (frq == "Weekly") {
			$("#_monthly").hide();
			$("#_weekly").show()
		} else if (frq == "Monthly") {
			$("#_weekly").hide();
			$("#_monthly").show()
		}
	});

	$("body").on("click", "[data-action='add-accounts']", function(e) {
		findGrid.setSelectedRows(0);
		$("#_findAccountsClear").trigger("click");
	});

	$("#_addSelectedAccounts").on("click", function(e) {
		if (findSelectedRowIds.length > 0) {
			var $loading = $(".loading-panel"),
				$primarytab = $(".primary-tabs ul").children("li.active").children("a"),
				addSelected;
			if ($("#reportDetail").hasClass("hidden")) {
				addSelected = function() {
					for (var i = findSelectedRowIds.length - 1; i >= 0; i--) {
						var itemID = "id_" + Math.round(Math.random() * 1000000000),
							itemACCNAM = "CURRENT" + Math.round(Math.random() * 1000),
							itemACCNUM = Math.round(Math.random() * 1000000000).toString();
						newData.push({
							id: itemID,
							accountnam: itemACCNAM,
							accountnum: itemACCNUM
						})
					}
					newGrid.updateRowCount();
					newGrid.render();
					newDataView.setItems(newData);
					$primarytab.removeClass("load");
					$loading.addClass("hidden");
					findGrid.setSelectedRows(0);
					$("#_addAccounts").closeDialog();
				}
			} else if ($("#reportNew").hasClass("hidden")) {
				addSelected = function() {
					for (var i = findSelectedRowIds.length - 1; i >= 0; i--) {
						var itemID = "id_" + Math.round(Math.random() * 1000000000),
							itemACCNAM = "CURRENT" + Math.round(Math.random() * 1000),
							itemACCNUM = Math.round(Math.random() * 1000000000).toString();
						addedData.push({
							id: itemID,
							accountnam: itemACCNAM,
							accountnum: itemACCNUM
						})
					}
					addedGrid.updateRowCount();
					addedGrid.render();
					addedDataView.setItems(addedData);
					$primarytab.removeClass("load");
					$loading.addClass("hidden");
					findGrid.setSelectedRows(0);
					$("#_addAccounts").closeDialog();
				}
			}
			$primarytab.addClass("load");
			$loading.removeClass("hidden");
			setTimeout(addSelected, 500);
		} else {
			alert("Select some accounts in the grid to add them to this report");
		}
	});

	$("body").on("click", "[data-action='remove-accounts']", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($("#reportDetail").hasClass("hidden")) {
			if (newSelectedRowIds.length > 0) {
				var r = confirm("Remove Selected Accounts From This Report?")
				if (r == true) {
					var rowsForDelete = [];
					for (var i = 0, l = newSelectedRowIds.length; i < l; i++) {
						var item = newSelectedRowIds[i];
						if (item) rowsForDelete.unshift(item)
					};
					for (var i = 0; i < rowsForDelete.length; i++) {
						newDataView.deleteItem(rowsForDelete[i])
					};
					newSelectedRowIds = [];
					newDataView.refresh();
					newGrid.invalidate();
					newGrid.render();
					newGrid.setSelectedRows(0);
				} else {
					return false;
				}
			}
		} else if ($("#reportNew").hasClass("hidden")) {
			if (addedSelectedRowIds.length > 0) {
				var r = confirm("Remove Selected Accounts From This Report?")
				if (r == true) {
					var rowsForDelete = [];
					for (var i = 0, l = addedSelectedRowIds.length; i < l; i++) {
						var item = addedSelectedRowIds[i];
						if (item) rowsForDelete.unshift(item)
					};
					for (var i = 0; i < rowsForDelete.length; i++) {
						addedDataView.deleteItem(rowsForDelete[i])
					};
					addedSelectedRowIds = [];
					addedDataView.refresh();
					addedGrid.invalidate();
					addedGrid.render();
					addedGrid.setSelectedRows(0);
				} else {
					return false;
				}
			}
		}
	});


	/**********************************************************************
							GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});

	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});



	$("[data-action='backToGrid']").on("click", function(e){
		e.preventDefault();
		$(this).attr({
			'data-panel': '#reportSummary',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		updateBreadcrumb("close");
	});

	/**********************************************************************
					  FIND SCHEDULED REPORTS INTERACTION
	**********************************************************************/
	function repFilter() {
		var rows = grid.getSelectedRows();
		if (rows.length > 0) {
			grid.setSelectedRows(0)
		};
		if (repString == "") {
			dataView.setFilterArgs({
				repString: repString
			})
		} else {
			dataView.setFilterArgs({
				repString: repString
			})
		};
		dataView.refresh();
	}

	$("#repSearchClear").on("click", function() {
		$("#_findReports").val('');
		$("#_findReports").blur();
		$("#repSearchClear").hide();
		repString = "";
		repFilter();
	});

	$("#_findReports").keyup(function(e) {
		if (e.which == 27) {
			$("#repSearchClear").hide();
			this.value = '';
			this.blur()
		};
		repString = this.value;
		repFilter();
		if (this.value != "") {
			$("#repSearchClear").show()
		} else {
			$("#repSearchClear").hide()
		}
	});

	$("#findReportOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var repPlaceholder = $(this).text(),
			repString = $(this).attr("data-value");
		if (repDataPoint != repString) {
			$("#_findReports").attr("placeholder", repPlaceholder);
			repDataPoint = repString;
			$("#_findReports").val('').focus();
			$("#repSearchClear").hide();
			repString = '';
			repFilter();
		}
	});


	/**********************************************************************
							FIND ACCOUNTS INTERACTION
	**********************************************************************/
	function findFilter() {
		var rows = findGrid.getSelectedRows();
		if (rows.length > 0) {
			findGrid.setSelectedRows(0)
		};
		if (findString == "") {
			findDataView.setFilterArgs({
				findString: findString
			})
		} else {
			findDataView.setFilterArgs({
				findString: findString
			})
		};
		findDataView.refresh();
	}

	$("#_findAccountsClear").on("click", function() {
		$("#_findAccountsInput").val('');
		$("#_findAccountsInput").blur();
		$("#_findAccountsClear").hide();
		findString = "";
		findFilter();
	});

	$("#_findAccountsInput").keyup(function(e) {
		if (e.which == 27) {
			$("#_findAccountsClear").hide();
			this.value = '';
			this.blur()
		};
		findString = this.value;
		findFilter();
		if (this.value != "") {
			$("#_findAccountsClear").show()
		} else {
			$("#_findAccountsClear").hide()
		}
	});

	$("#findAccountOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var findPlaceholder = $(this).text(),
			findString = $(this).attr("data-value");
		if (findPlaceholder != findString) {
			$("#_findAccountsInput").attr("placeholder", findPlaceholder);
			findDataPoint = findString;
			$("#_findAccountsInput").val('').focus();
			$("#_findAccountsClear").hide();
			findString = '';
			findFilter();
		}
	});

	$("#toggleFilter").on("click", toggleFilterRow);

	/**********************************************************************
							TOGGLE UI FUNCTION
	**********************************************************************/

	$(".toggle-ui").on("click", function() {
		var $div = $(this),
			$toggle = $div.find("i"),
			$label = $div.find("span"),
			$input = $div.find("input[type='hidden']"),
			_state = ($input.val() == "on") ? true : false;
		if ($div.hasClass("disabled")) {
			return false;
		} else {
			if (_state) {
				$toggle.removeClass("fa-toggle-on").addClass("fa-toggle-off");
				$label.html("Toggle Off");
				$input.val("off");
			} else {
				$toggle.removeClass("fa-toggle-off").addClass("fa-toggle-on");
				$label.html("Toggle On");
				$input.val("on");
			}
		}
	});

	/**********************************************************************
							PROCESSING DIALOG
	**********************************************************************/

	function showProcessingDialog(e) {

		e.preventDefault();

		/* define the steps */
		var steps = ["User Creation", "Application Assignment", "Password Generation"];

		/* build the content */
		var $content = $("<div class='processing-steps' />"),
			$connector = $("<div class='step-connector' />").appendTo($content),
			$ul = $("<ul />").appendTo($content),
			$li, $div, $text;
		for (var i = 0; i < steps.length; i++) {
			$li = $("<li />").appendTo($ul),
				$div = $("<div class='processing-step' />").appendTo($li),
				$text = $("<span>" + steps[i] + " Pending</span>").appendTo($div);
		}

		/* build and open the dialog */
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: "ProcessingDialog",
			title: "Your Request is Being Processed",
			size: "small",
			icon: "<i class='fa fa-male'></i>",
			content: $content,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* set the height of the connector line */
		$connector.css({
			"height": $ul.height()
		});

		/* run the sequence */
		var n = 0;

		function runSequence(n) {
			if (n < steps.length) {
				var $div = $ul.children("li").eq(n).children("div"),
					$span = $div.children("span");
				setTimeout(function() {
					$div.addClass("progress");
					$span.html(steps[n] + " In Progress");
					setTimeout(function() {
						$div.addClass("complete");
						$span.html(steps[n] + " Complete");
						n = n + 1;
						runSequence(n);
					}, 2000);
				}, 300);
			} else {
				return false;
			}
		}
		runSequence(n);
	}



	/**********************************************************************
	FIND CURRENCIES GRID
	**********************************************************************/
	var findCCYDataView;
	var findCCYGrid;
	var findCCYData = [{
		id: "id_0",
		ccy: "AUD",
		ccyname: "Australian Dollars"
	}, {
		id: "id_1",
		ccy: "CNY",
		ccyname: "Chinese Yuan"
	}, {
		id: "id_2",
		ccy: "EUR",
		ccyname: "Euro"
	}, {
		id: "id_3",
		ccy: "HKD",
		ccyname: "Hong Kong Dollars"
	}, {
		id: "id_4",
		ccy: "IDR",
		ccyname: "Indonesian Rupiah"
	}, {
		id: "id_5",
		ccy: "INR",
		ccyname: "Indian Rupee"
	}, {
		id: "id_6",
		ccy: "KRW",
		ccyname: "Korean Won"
	}, {
		id: "id_7",
		ccy: "KHR",
		ccyname: "Cambodian Riel"
	}, {
		id: "id_8",
		ccy: "MYR",
		ccyname: "Malaysian Ringgit"
	}, {
		id: "id_9",
		ccy: "NZD",
		ccyname: "New Zealand Dollar"
	}, {
		id: "id_10",
		ccy: "SGD",
		ccyname: "Singapore Dollar"
	}, {
		id: "id_11",
		ccy: "THB",
		ccyname: "Thailand Baht"
	}, {
		id: "id_12",
		ccy: "USD",
		ccyname: "United States Dollar"
	}, {
		id: "id_13",
		ccy: "VND",
		ccyname: "Vietnamese Dong"
	}];
	var findCCYSelectedRowIds = [];
	var findCCYColumns = [{
			id: "ccy",
			name: "Currency Code",
			field: "ccy",
			toolTip: "Click to sort by Currency Code",
			width: 150,
			sortable: true,
			visible: true,
			cssClass: "no-pointer"
		}, {
			id: "ccyname",
			name: "Currency Description",
			field: "ccyname",
			toolTip: "Click to sort by Currency Description",
			width: 350,
			sortable: true,
			visible: true,
			cssClass: "no-pointer"
		}],
		findCCYOptions = {
			editable: false,
			enableAddRow: false,
			enableCellNavigation: false,
			enableColumnReorder: false,
			autoHeight: false,
			forceFitColumns: true,
			multiSelect: true
		};
	var findCCYCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	findCCYColumns.unshift(findCCYCheckboxSelector.getColumnDefinition());
	var findCCYString = "",
		findCCYDataPoint = "ccy";

	function ccyFilter(item, args) {
		if (args.findCCYString != "" && item[findCCYDataPoint].toLowerCase().indexOf(args.findCCYString.toLowerCase()) == -1)
			return false;
		return true;
	}


	/**********************************************************************
	FIND ACCOUNTS GRID
	**********************************************************************/
	var findDataView;
	var findGrid;
	var findData = [];
	var findSelectedRowIds = [];
	var findColumns = [{
			id: "accountnam",
			name: "Account Name",
			field: "accountnam",
			toolTip: "Click to sort by Account Name",
			width: 250,
			sortable: true,
			visible: true,
			cssClass: "no-pointer"
		}, {
			id: "accountnum",
			name: "Account Number",
			field: "accountnum",
			toolTip: "Click to sort by Account Number",
			width: 250,
			sortable: true,
			visible: true,
			cssClass: "no-pointer"
		}],
		findOptions = {
			editable: false,
			enableAddRow: false,
			enableCellNavigation: false,
			enableColumnReorder: false,
			autoHeight: false,
			forceFitColumns: true,
			multiSelect: true
		};
	var findCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	findColumns.unshift(findCheckboxSelector.getColumnDefinition());
	var findString = "",
		findDataPoint = "accountnam";

	function accFilter(item, args) {

		if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1)
			return false;

		return true;
	}
	for (var i = 0; i < 30; i++) {
		var d = (findData[i] = {});
		d["id"] = "id_" + i;
		d["accountnam"] = "CURRENT" + Math.round(Math.random() * 1000);
		d["accountnum"] = Math.round(Math.random() * 1000000000).toString();
	}

	/**********************************************************************
	FILTER ITEMS GRID
	**********************************************************************/
	var filterDataView,
		filterGrid,
		filterData = [],
		filterAccountData = []
	filterCurrencyData = []
	filterColumns = [],
		filterSelectedRowIds = [],
		filterOptions = {
			editable: false,
			enableAddRow: false,
			enableCellNavigation: false,
			enableColumnReorder: false,
			autoHeight: false,
			forceFitColumns: true,
			multiSelect: true
		};


	$("#processingDialogButton").on("click", showProcessingDialog);


});