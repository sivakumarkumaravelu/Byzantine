/**********************************************************************
SETUP THE REPORT DETAIL SCREEN
**********************************************************************/
var gridMode = "my",
	loadRecordTimer;

function updateBreadcrumb(update) {
	var $breadcrumb = $(".application-breadcrumb");
	$breadcrumb.empty();
	$(update).appendTo($breadcrumb);
}

function setupReportDetails(item, mode) {
	if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
		filterGrid.destroy()
		filterData = []
		filterAccountData = []
		filterCurrencyData = []
	}
	function showScheduleDetails(_target) {
		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='wrapper' style='overflow:hidden;height:320px' />");

		var obj = dataViewSchedule.getItem(row);
		$('<div class="data-entry" style="" id="_scheduleinfo"> <div class="form-section"> <div class="row"> <div class="label-column"><label>Schedule Name</label></div> <div class="data-column" style="padding-top:7px"> ' + obj.name + '</div> </div> <div class="row"> <div class="label-column"><label>Time Zone</label></div> <div class="data-column" style="padding-top:7px"> System Time Zone</div> </div> <div class="row"> <div class="label-column"><label>Schedule Period</label></div> <div class="data-column" style="padding-top:7px">' + obj.startdate + '<div class="data-text">-</div>' + obj.enddate + '</div> </div> <div class="row"> <div class="label-column"><label>Frequency</label></div> <div class="data-column" style="padding-top:7px">' + obj.frequency + '</div> </div> <div class="row"> <div class="label-column"><label>Run Time</label></div> <div class="data-column" style="padding-top:7px">12<label class="desc">Hours</label> 00<label class="desc">Minutes</label></div> </div> <div class="row"> <div class="label-column"><label>Delivery By Email</label></div> <div class="data-column"><span data-mode="view" style="display: inline;padding-top:7px" ><div class="data-text" data-value="shared"><i class="fa fa-check-square-o fa-fw" style="margin-right: 4px;"></i> Delivery by Email Enabled </div></span> </div> </div> </div> </div>').appendTo($wrapper);

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "AddDebitAccount1",
			title: "View Schedule",
			size: "small",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper,
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog);
						$('#AddDebitAccount1').remove()
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		setTimeout(function() {
			$('#AddDebitAccount1.moveback').remove();
		}, 1000);
	}
	if (jQuery.type(item) === "object") {
		$("[data-value='repname']").html(item.repname)
		if (item.shared != "") {
			$("[data-value='shared']").html("<i class='fa fa-check-square-o fa-fw' style='margin-right: 4px;'></i> Report Sharing Enabled");
			$("#_sharedfield").prop("checked", true)
		} else {
			$("[data-value='shared']").html('&nbsp;');
			$("#_sharedfield").prop("checked", false)
		}
		$("[data-value='description']").html(item.description)
		$("[data-value='reptype']").html(item.reptype);
		$("[data-value='repformat']").html(item.repformat);
		$("[data-value='replanguage']").html(item.replanguage);
		$("[data-value='repencoding']").html(item.repencoding);
		if (item.grouped) {
			$("[data-value='grouped']").html("<i class='fa fa-check-square-o fa-fw' style='margin-right: 4px;'></i> Group Transactions");
			$("#_groupField").prop("checked", true)
		} else {
			$("[data-value='grouped']").html("<i class='fa fa-square-o fa-fw' style='margin-right: 4px;'></i> Group Transactions");
			$("#_groupField").prop("checked", false)
		}
		if (item.shared) {
			$("[data-value='shared']").html("<i class='fa fa-check-square-o fa-fw' style='margin-right: 4px;'></i> Enabled");
			$("#_sharedfield").prop("checked", true)
		} else {
			$("[data-value='shared']").html("<i class='fa fa-square-o fa-fw' style='margin-right: 4px;'></i> ");
			$("#_sharedfield").prop("checked", false)
		}
		$("[data-value='datefilter']").html(item.datefilter)
		$("[data-value='fromdate']").html(item.fromdate)
		$("[data-value='todate']").html(item.todate)
		$("[data-value='filtertype']").html(item.filtertype)
		$("[data-value='createdon']").html(item.createdon)
		$("[data-value='ownedby']").html(item.ownedby)
		$("#_repnamefield").val(item.repname)
		$("#_descriptionfield").val(item.description)
		$("#_reptypefield").val(item.reptype)
		$("#_repformatfield").val(item.repformat)
		$("#_replanguage").val(item.replanguage)
		$("#_repencoding").val(item.repencoding)
		$("#_filteroption").find("input[value='" + item.filtertype + "']").prop("checked", true)
		$("#_datefilterfield").val(item.datefilter)
	}
	if (mode == "view") {
		updateBreadcrumb("view");
		$("#_editButtons, #_newButtons, #_filterBtns").hide();
		$("#_scheduleinfo").hide();
		$('#_filterBtnsSchedule').hide();
		$("#_associatedscheduleinfo").show();
		$("#_viewButtons, #_navButtons, #_repFilter, #_filters, #_auditHistory").show()
		$("#_reportForm").find("span[data-mode='edit']").hide()
		$("#_reportForm").find("span[data-mode='view']").show()
		if (item.ownedby != "PrototypeUser") {
			$("#_ownerCheck").hide();
		} else {
			$("#_ownerCheck").show();
		}
		if (item.repformat == "PDF" || item.repformat == "Excel") {
			$("div.row[data-value='grouping']").show();
		} else {
			$("div.row[data-value='grouping']").hide();
		}
		if (item.filtertype == "Currency") {
			$("#_filters").find("label").html("Selected Currencies")
			filterColumns = [{
				id: "ccy",
				name: "Currency Code",
				field: "ccy",
				toolTip: "Click to sort by Currency Code",
				width: 150,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "ccyname",
				name: "Currency Description",
				field: "ccyname",
				toolTip: "Click to sort by Currency Description",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterCurrencyData = item.filters
		} else if (item.filtertype == "Account") {
			$("#_filters").find("label").html("Selected Accounts")
			filterColumns = [{
				id: "accountnam",
				name: "Account Name",
				field: "accountnam",
				toolTip: "Click to sort by Account Name",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "accountnum",
				name: "Account Number",
				field: "accountnum",
				toolTip: "Click to sort by Account Number",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterAccountData = item.filters
		}

		filterData = item.filters;
		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e, args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e, args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});

		try {
			filterDataView.setItems(filterData);
			filterGrid.setColumns(filterColumns);
		} catch (e) {}
		// columnsschedule.shift();
		var clonedArray = JSON.parse(JSON.stringify(columnsschedule));
		clonedArray.shift();


		schedulegrid.onSelectedRowsChanged.subscribe(function(e) {
			$(document).off("keyup.hide-menu");
			$(".shell").off("resize.hide-menu");
			$("body").off("click.hide-menu");
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").children(".on").removeClass("on");
			selectedRowIdsSchedule = [];
			selectedReportOwners = [];
			var rows = grid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = dataView.getItem(rows[i])
				if (item.id) {
					selectedRowIdsSchedule.push(item.id);
					selectedReportOwners.push(item.ownedby)
				}

			}
			if (selectedRowIdsSchedule.length > 0) {
				$("#adhocReports").addClass("has-bottom-controls");
				$("#reportSummary .bottom-controls").removeClass("hidden");
				$("#selectedCount").html(selectedRowIdsSchedule.length);
				schedulegrid.resizeCanvas();
			} else {
				$("#adhocReports").removeClass("has-bottom-controls");
				$("#reportSummary .bottom-controls").addClass("hidden");
				$("#selectedCount").html('');
				schedulegrid.resizeCanvas();
			}
		});

		schedulegrid.onClick.subscribe(function(e, args) {
			row = args.row, $row = $(e.target).closest(".slick-row");
			if (!$row.is(".slick-group, .slick-group-totals")) {

				showScheduleDetails($('#_associatedschedule'));

			}
		});

		schedulegrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			dataViewSchedule.fastSort(sortcol, args.sortAsc);
		});
		schedulegrid.onColumnsResized.subscribe(function(e, args) {
			store.set('scheduleWidths', grid.getColumns());
		});
		dataViewSchedule.onRowCountChanged.subscribe(function(e, args) {
			schedulegrid.updateRowCount();
			schedulegrid.render();

		});
		dataViewSchedule.onRowsChanged.subscribe(function(e, args) {
			schedulegrid.invalidateRows(args.rows);
			schedulegrid.render();
			if (selectedRowIdsSchedule.length > 0) {
				var selRows = [];
				for (var i = 0; i < selectedRowIdsSchedule.length; i++) {
					var idx = dataView.getRowById(selectedRowIdsSchedule[i]);
					if (idx != undefined)
						selRows.push(idx);
				}
				schedulegrid.setSelectedRows(selRows);
			}
		});

		dataViewSchedule.setItems(item.schedules);
		schedulegrid.setColumns(clonedArray);
		dataViewSchedule.refresh();
	} else if (mode == "edit") {
		updateBreadcrumb("edit");
		$("#_newButtons, #_viewButtons, #_navButtons").hide();
		$("#_associatedscheduleinfo").show();
		$("#_editButtons, #_repFilter, #_filters, #_auditHistory, #_filterBtns").show();
		$("#_reportForm").find("span[data-mode='view']").hide();
		$("#_reportForm").find("span[data-mode='edit']").show();
		$('#_filterBtnsSchedule').show();
		if (item.filtertype == "Currency") {
			$("#_filterBtns a[data-action='add-filters']").attr("href", "javascript:void(0)")
			$("#_filters").find("label").html("Select Currencies")
			filterColumns = [{
				id: "ccy",
				name: "Currency Code",
				field: "ccy",
				toolTip: "Click to sort by Currency Code",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "ccyname",
				name: "Currency Description",
				field: "ccyname",
				toolTip: "Click to sort by Currency Description",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterCurrencyData = item.filters
		} else if (item.filtertype == "Account") {
			$("#_filterBtns a[data-action='add-filters']").attr("href", "javascript:void(0)")
			$("#_filters").find("label").html("Select Accounts")
			filterColumns = [{
				id: "accountnam",
				name: "Account Name",
				field: "accountnam",
				toolTip: "Click to sort by Account Name",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}, {
				id: "accountnum",
				name: "Account Number",
				field: "accountnum",
				toolTip: "Click to sort by Account Number",
				width: 200,
				sortable: true,
				visible: true,
				cssClass: "cursor-default"
			}]
			filterAccountData = item.filters
		}
		$("#_datefilterfield").trigger("change");
		$("#_datefrom").datepicker("setDate", item.fromdate)
		$("#_dateto").datepicker("setDate", item.todate)
		filterData = item.filters;
		var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
			cssClass: "slick-cell-checkboxsel"
		});
		filterColumns.unshift(filterCheckboxSelector.getColumnDefinition());
		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
		filterGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		filterGrid.registerPlugin(filterCheckboxSelector);
		filterGrid.onSelectedRowsChanged.subscribe(function(e) {
			filterSelectedRowIds = [];
			var rows = filterGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = filterDataView.getItem(rows[i]);
				if (item) filterSelectedRowIds.push(item.id);
			}
		});
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e, args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e, args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});
		filterDataView.setItems(filterData);
		filterGrid.setColumns(filterColumns);
		schedulegrid.onClick.subscribe(function(e, args) {
			row = args.row, $row = $(e.target).closest(".slick-row");
			if (!$row.is(".slick-group, .slick-group-totals")) {
				showEditSchedule($('#_associatedschedule'));
			}
		});
		schedulegrid.onSelectedRowsChanged.subscribe(function(e) {
			selectedRowIdsSchedule = [];
			var rows = schedulegrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = dataViewSchedule.getItem(rows[i]);
				if (item) selectedRowIdsSchedule.push(item.id);
			}
		});
		schedulegrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			dataViewSchedule.fastSort(sortcol, args.sortAsc);
		});
		schedulegrid.onColumnsResized.subscribe(function(e, args) {
			store.set('scheduleWidths', schedulegrid.getColumns());
		});
		dataViewSchedule.onRowCountChanged.subscribe(function(e, args) {
			schedulegrid.updateRowCount();
			schedulegrid.render();
		});
		dataViewSchedule.onRowsChanged.subscribe(function(e, args) {
			schedulegrid.invalidateRows(args.rows);
			schedulegrid.render();
			if (selectedRowIdsSchedule.length > 0) {
				var selRows = [];
				for (var i = 0; i < selectedRowIdsSchedule.length + 1; i++) {
					var idx = dataView.getRowById(selectedRowIdsSchedule[i]);
					if (idx != undefined)
						selRows.push(idx);
				}
				schedulegrid.setSelectedRows(selRows);
			}
		});
		dataViewSchedule.setItems(item.schedules);
		schedulegrid.setColumns(columnsschedule);
		dataViewSchedule.refresh();
		$("#_datefrom").datepicker("hide");
		$("#_dateto").datepicker("hide");
		$("#_reptypefield").focus();
	} else if (mode == "new") {
		updateBreadcrumb("new");
		$("#_editButtons, #_viewButtons, #_navButtons, #_repFilter, #_auditHistory, #_scheduleinfo").hide();
		$('#_filterBtnsSchedule').hide();
		$("#_associatedscheduleinfo").hide();
		$("#_datefrom, #_dateto").attr({
			"disabled": "disabled"
		}).datepicker("destroy").val('').hide();
		$("#_newButtons").show()
		$("#_reportForm").find("span[data-mode='view']").hide()
		$("#_reportForm").find("span[data-mode='edit']").show()
		$("#_reportForm").find("input[type='text'],input[type='hidden'],select,textarea").val('');
		$("#_reportForm").find("input[type='checkbox'], input[type='radio']").prop("checked", false);
		$("#_reptypefield").focus()
	}
	if (mode == "edit" || mode == "new") {
		$("#_addSchedule").on("click", function(e) {
			e.preventDefault();
			showAddSchedule($(this));
		});
		$("#_reptypefield").on("change", function(e) {
			var $target = $(e.target),
				type = $("#_reptypefield").val();
			if (type == "") {
				$("#_repFilter").hide();
				$("#_scheduleinfo").hide();
			} else {
				$("#_filters").hide()
				$("#_repFilter").show().find("input[type='checkbox'], input[type='radio']").prop("checked", false);
				$("#_scheduleinfo").show();
				if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
					filterGrid.destroy();
					filterData = [], filterCurrencyData = [], filterAccountData = []
				}
			}
		});
		$("#_repformatfield").on("change", function(e) {
			var _format = $(this).val();
			if (_format == "PDF" || _format == "Excel") {
				$("div.row[data-value='grouping']").slideDown("fast");
			} else {
				$("div.row[data-value='grouping']").slideUp("fast");
			}
		});
		$("#_reportForm input[name='ftype']").on("change", function(e) {
			var type = $("#_reportForm input[name='ftype']:checked").val()
			if (!$("#_filters").is(":visible")) {
				$("#_filters").show()
			}
			if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
				filterGrid.destroy();
				filterData = []
			}
			if (type == "Currency") {
				$("#_filterBtns").show().find("a[data-action='add-filters']").attr("href", "#_addCurrencies")
				$("#_filters").find("label").html("Select Currencies")
				filterColumns = [{
					id: "ccy",
					name: "Currency Code",
					field: "ccy",
					toolTip: "Click to sort by Currency Code",
					width: 200,
					sortable: true,
					visible: true,
					cssClass: "cursor-default"
				}, {
					id: "ccyname",
					name: "Currency Description",
					field: "ccyname",
					toolTip: "Click to sort by Currency Description",
					width: 200,
					sortable: true,
					visible: true,
					cssClass: "cursor-default"
				}]
				filterData = filterCurrencyData
			} else if (type == "Account") {
				$("#_filterBtns").show().find("a[data-action='add-filters']").attr("href", "#_addAccounts")
				$("#_filters").find("label").html("Select Accounts")
				filterColumns = [{
					id: "accountnam",
					name: "Account Name",
					field: "accountnam",
					toolTip: "Click to sort by Account Name",
					width: 200,
					sortable: true,
					visible: true,
					cssClass: "cursor-default"
				}, {
					id: "accountnum",
					name: "Account Number",
					field: "accountnum",
					toolTip: "Click to sort by Account Number",
					width: 200,
					sortable: true,
					visible: true,
					cssClass: "cursor-default"
				}]
				filterData = filterAccountData
			}
			var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
				cssClass: "slick-cell-checkboxsel"
			});
			filterColumns.unshift(filterCheckboxSelector.getColumnDefinition());
			filterDataView = new Slick.Data.DataView({});
			filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
			filterGrid.setSelectionModel(new Slick.RowSelectionModel({
				selectActiveRow: false
			}));
			filterGrid.registerPlugin(filterCheckboxSelector);
			filterGrid.onSelectedRowsChanged.subscribe(function(e) {
				filterSelectedRowIds = [];
				var rows = filterGrid.getSelectedRows();
				for (var i = 0, l = rows.length; i < l; i++) {
					var item = filterDataView.getItem(rows[i]);
					if (item) filterSelectedRowIds.push(item.id);
				}
			});
			filterGrid.onSort.subscribe(function(e, args) {
				sortcol = args.sortCol.field;
				sortdir = args.sortAsc ? 1 : -1;
				filterDataView.fastSort(sortcol, args.sortAsc);
			});
			filterDataView.onRowCountChanged.subscribe(function(e, args) {
				filterGrid.updateRowCount();
				filterGrid.render();
			});
			filterDataView.onRowsChanged.subscribe(function(e, args) {
				filterGrid.invalidateRows(args.rows);
				filterGrid.render();
			});
			filterDataView.setItems(filterData);
			filterGrid.setColumns(filterColumns);
		});
		$("[data-action='remove-filters']").on("click", function(e) {
			e.preventDefault();
			var $target = $(e.target);
			if (filterSelectedRowIds.length > 0) {
				function removeFilters() {
					var rowsForDelete = [];
					for (var i = 0, l = filterSelectedRowIds.length; i < l; i++) {
						var item = filterSelectedRowIds[i];
						if (item) rowsForDelete.unshift(item)
					};
					for (var i = 0; i < rowsForDelete.length; i++) {
						filterDataView.deleteItem(rowsForDelete[i])
					};
					filterSelectedRowIds = [];
					filterDataView.refresh();
					filterGrid.invalidate();
					filterGrid.render();
					filterGrid.setSelectedRows(0);
					if ($("#_reportForm input[name='ftype']:checked").val() == "Account") {
						filterAccountData = filterDataView.getItems()
					} else {
						filterCurrencyData = filterDataView.getItems()
					}
				}
				$('.confirmation-dialog').remove();
				buildConfirmDialog("Remove selected items?", "", function() {
					removeFilters(e)
				});
			}
		});
		$("[data-action='remove-schedule']").on("click", function(e) {
			e.preventDefault();
			var $target = $(e.target);

			if (selectedRowIdsSchedule.length > 0) {
				function removeFilters() {
					var rowsForDelete = [];
					for (var i = 0, l = selectedRowIdsSchedule.length; i < l; i++) {
						var item = selectedRowIdsSchedule[i];
						if (item) rowsForDelete.unshift(item)
					};

					for (var i = 0; i < rowsForDelete.length; i++) {
						dataViewSchedule.deleteItem(rowsForDelete[i])
					};
					selectedRowIdsSchedule = [];
					dataViewSchedule.refresh();
					schedulegrid.invalidate();
					schedulegrid.render();
					schedulegrid.setSelectedRows(0);

				}
				$('.confirmation-dialog').remove();
				buildConfirmDialog("Remove selected items?", "", function() {
					removeFilters(e)
				});
			}
		});
		$("#_addSelectedAccounts").on("click", function(e) {
			if (findSelectedRowIds.length > 0) {
				var $loading = $(".loading-panel"),
					$primarytab = $(".primary-tabs ul").children("li.active").children("a");
				var addSelected = function() {
					for (var i = findSelectedRowIds.length - 1; i >= 0; i--) {
						var itemID = "id_" + Math.round(Math.random() * 12345),
							itemACCNAM = "CURRENT" + Math.round(Math.random() * 1000),
							itemACCNUM = Math.round(Math.random() * 1000000000).toString();
						filterData.push({
							id: itemID,
							accountnam: itemACCNAM,
							accountnum: itemACCNUM
						})
					}
					filterDataView.setItems(filterData);
					filterDataView.refresh();
					filterAccountData = filterDataView.getItems();
					filterGrid.updateRowCount();
					filterGrid.render();
					$primarytab.removeClass("load");
					$loading.addClass("hidden");
					findGrid.setSelectedRows(0);
					$("#_addAccounts").closeDialog();
				}
				$primarytab.addClass("load");
				$loading.removeClass("hidden");
				setTimeout(addSelected, 500);
			} else {
				alert("Select accounts to add them to the report filter");
			}
		});
		$("#_addSelectedCurrencies").on("click", function(e) {
			if (findCCYSelectedRowIds.length > 0) {
				var $loading = $(".loading-panel"),
					$primarytab = $(".primary-tabs ul").children("li.active").children("a");
				addSelected = function() {
					var rowsToAdd = [];
					for (var i = 0, l = findCCYSelectedRowIds.length; i < l; i++) {
						var item = findCCYSelectedRowIds[i];
						if (item) {
							var itemID = "id_" + Math.round(Math.random() * 12345);
							var itemCCY = findCCYDataView.getItemById(item).ccy;
							var itemName = findCCYDataView.getItemById(item).ccyname;
							rowsToAdd.unshift({
								id: itemID,
								ccy: itemCCY,
								ccyname: itemName
							})
						}
					};
					for (var i = 0; i < rowsToAdd.length; i++) {
						filterData.push(rowsToAdd[i])
					};
					filterDataView.setItems(filterData);
					filterDataView.refresh();
					filterCurrencyData = filterDataView.getItems();
					filterGrid.updateRowCount();
					filterGrid.render();
					$primarytab.removeClass("load");
					$loading.addClass("hidden");
					findCCYGrid.setSelectedRows(0);
					$("#_addCurrencies").closeDialog();
				}
				$primarytab.addClass("load");
				$loading.removeClass("hidden");
				setTimeout(addSelected, 500);
			} else {
				alert("Select currencies to add them to the report filter");
			}
		});
	}
}

function saveNewReport() {
	var sharedSetting, sharedBySetting;
	var newID = Math.round(Math.random() * 1000000000);
	var scheduledata = store.get('schedule-data');
	var ll = scheduledata.length;
	if ($("#_sharedfield").is(":checked")) {
		sharedSetting = "&#x2713;";
		sharedBySetting = "PrototypeUser"
	} else {
		sharedSetting = "";
		sharedBySetting = ""
	}
	var schedules = [];
	var schedule_obj = {};
	if ($("#_editStartDate").val() != "" && $("#_editEndDate").val() != "") {
		schedule_obj.id = "id_" + (ll + 1);
		schedule_obj.name = $("#_schedulename").val();
		schedule_obj.status = 'active';
		//schedule_obj.timezone = $("#_scheduletimezone").val();
		schedule_obj.startdate = $("#_editStartDate").val();
		schedule_obj.enddate = $("#_editEndDate").val();
		// schedule_obj.frequencytype = $("#_schedulefrequency").val();
		schedule_obj.frequency = $("#_schedulefrequencyday").val();
		schedule_obj.lastrundate = "";
		schedule_obj.nextrundate = "";
		schedule_obj.ownedby = "PrototypeUser";
		//schedule_obj.runtimemins = $("#_schedulemins").val();
		schedule_obj.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
		schedule_obj.filters = filterDataView.getItems();
		schedules.push(schedule_obj);
		schedulesnumber = schedules.length;
	} else {
		schedulesnumber = '-';
		schedules = [];
	}
	var updatedItem = {
		id: newID,
		reptype: $("#_reptypefield").val(),
		repname: $("#_repnamefield").val(),
		replanguage: $("#_replanguage").val(),
		repencoding: $("#_repencoding").val(),
		repformat: $("#_repformatfield").val(),
		description: $("#_descriptionfield").val(),
		grouped: $("#_groupField").is(":checked"),
		shared: sharedSetting,
		sharedby: sharedBySetting,
		ownedby: "PrototypeUser",
		createdon: $.datepicker.formatDate('dd/mm/yy', new Date()),
		datefilter: $("#_datefilterfield").val(),
		fromdate: $("#_datefrom").val(),
		todate: $("#_dateto").val(),
		filtertype: $("#_filteroption").find("input[name='ftype']:checked").val(),
		filters: filterDataView.getItems(),
		schedules: schedules,
		schedulesnumber: schedulesnumber
	};
	data.push(updatedItem)
	store.set('report-data', data);
	dataView.setItems(data);
	dataView.refresh();

	if ($("#_editStartDate").val() != "" && $("#_editEndDate").val() != "") {
		var scheduledata = store.get('schedule-data');
		var ll = scheduledata.length;
		var obj1 = {};
		obj1.id = "id_" + (ll + 1)
		obj1.lastrundate = "";
		obj1.nextrundate = "";
		obj1.repprofile = "Y";
		obj1.reptype = $('#_reptypefield').val();
		obj1.repname = $("#_repnamefield").val();
		obj1.repformat = $("#_repformatfield").val();
		obj1.replanguage = $("#_replanguage").val();
		obj1.repencoding = $("#_repencoding").val();
		obj1.description = $("#_descriptionfield").val();
		obj1.schedend = $('#_editEndDate').val();
		obj1.schedfreq = $('#_schedulefrequencyday').val();
		obj1.schedname = $('#_schedulename').val();
		obj1.schedstart = $('#_editStartDate').val();
		obj1.status = "Active";
		scheduledata.push(obj1);
		store.set('schedule-data', scheduledata);
	}
	if ($("#_sharedfield").is(":checked")) {
		sharedData.push(updatedItem)
	}
}

function updateReport(item) {
	var report = dataView.getItemById(item.id);
	report.reptype = $("#_reptypefield").val();
	report.repname = $("#_repnamefield").val();
	report.repformat = $("#_repformatfield").val();
	report.replanguage = $("#_replanguage").val();
	report.repencoding = $("#_repencoding").val();
	report.description = $("#_descriptionfield").val();
	report.grouped = $("#_groupField").is(":checked");
	report.shared = ($("#_sharedfield").is(":checked")) ? "y" : "";
	report.sharedby = ($("#_sharedfield").is(":checked")) ? "PrototypeUser" : "";
	report.datefilter = $("#_datefilterfield").val();
	report.fromdate = $("#_datefrom").val();
	report.todate = $("#_dateto").val();
	report.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
	report.filters = filterDataView.getItems();
	report.schedules = item.schedules;
	report.schedulesnumber = item.schedulesnumber;
	if (gridMode == "my") {
		if ($("#_sharedfield").is(":checked")) {
			var index = $.inArray(item, sharedData);
			if (index != -1) {
				var report = sharedData[index];
				report.reptype = $("#_reptypefield").val();
				report.repname = $("#_repnamefield").val();
				report.repformat = $("#_repformatfield").val();
				report.replanguage = $("#_replanguage").val();
				report.repencoding = $("#_repencoding").val();
				report.grouped = $("#_groupField").is(":checked");
				report.description = $("#_descriptionfield").val();
				report.shared = "y";
				report.sharedby = "PrototypeUser";
				report.datefilter = $("#_datefilterfield").val();
				report.fromdate = $("#_datefrom").val();
				report.todate = $("#_dateto").val();
				report.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
				report.filters = filterDataView.getItems();
			} else {
				sharedData.push(item)
			}
		} else {
			var index = $.inArray(item, sharedData);
			if (index != -1) {
				sharedData.splice(index, 1)
			}
		}
		dataView.setItems(data)
	} else {
		var index = $.inArray(item, data);
		var report = data[index];
		report.reptype = $("#_reptypefield").val();
		report.repname = $("#_repnamefield").val();
		report.repformat = $("#_repformatfield").val();
		report.replanguage = $("#_replanguage").val();
		report.repencoding = $("#_repencoding").val();
		report.grouped = $("#_groupField").is(":checked");
		report.description = $("#_descriptionfield").val();
		report.shared = ($("#_sharedfield").is(":checked")) ? "y" : "";
		report.sharedby = ($("#_sharedfield").is(":checked")) ? "PrototypeUser" : "";
		report.datefilter = $("#_datefilterfield").val();
		report.fromdate = $("#_datefrom").val();
		report.todate = $("#_dateto").val();
		report.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
		report.filters = filterDataView.getItems();
		report.schedules = item.schedules;
		report.schedulesnumber = item.schedulesnumber;
		if (report.shared == "") {
			var index = $.inArray(item, sharedData);
			if (index != -1) {
				sharedData.splice(index, 1)
			}
		}
		dataView.setItems(sharedData)
	}
	dataView.refresh();
	grid.invalidate();
	grid.render();
	setupReportDetails(item, "view")
}

function showAddSchedule(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' style='overflow:hidden;height:320px' />");

	function saveSchedule(_dialog) {
		var item = dataView.getItem(grid.getActiveCell().row);
		var index = $.inArray(item, data);

		var scheduledata = store.get('schedule-data');
		var ll = scheduledata.length;
		var obj = {};
		obj.id = "id_" + (ll + 1)
		obj.lastrundate = "";
		obj.nextrundate = "";
		obj.repprofile = "Y";
		obj.reptype = $('#_reptypefield').val();
		obj.schedend = $('#_editEndDate1').val();
		obj.enddate = $('#_editEndDate1').val();
		obj.schedfreq = $('#_schedulefrequency1').val();
		obj.frequency = $('#_schedulefrequency1').val();
		obj.schedname = $('#_schedulename1').val();
		obj.name = $('#_schedulename1').val();
		obj.schedstart = $('#_editStartDate1').val();
		obj.startdate = $('#_editStartDate1').val();
		obj.status = "Active";
		obj.reportformat = $('#_repformatfield').val();
		obj.reportname = $('#_repnamefield').val();
		obj.reportdesc = $('#_descriptionfield').val();
		obj.reportlanguage = $('#_replanguage').val();
		obj.reportencoding = $('#_repencoding').val();
		obj.reportfilterdate = $('#_datefilterfield').val();
		obj.reportfilterdatefrom = $('#_datefrom').val();
		obj.reportfilterdateto = $('#_dateto').val();

		scheduledata.push(obj);
		if (index >= 0) {
			data[index].schedules.push(obj);
			data[index].schedulesnumber = data[index].schedules.length;
		}
		store.set('report-data', data);
		store.set('schedule-data', scheduledata);

		dataViewSchedule.refresh();
		dataViewSchedule.setItems(item.schedules);
		schedulegrid.setColumns(columnsschedule);
	}
	/* build the account filter input */
	/* build the header row */
	//var $header = $("<div class='dialog-search-header' />").appendTo($wrapper);
	//$nameHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Name</div>").appendTo($header),
	//$numberHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Number</div>").appendTo($header),
	//$currencyHeader = $("<div class='dialog-search-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	$('<div class="data-entry" style="" id="_scheduleinfo">  <div class="form-section"> <div class="row"> <div class="label-column"><label>Schedule Name</label></div> <div class="data-column"><input type="text" id="_schedulename1" size="40" value="Previous Week Statements" /></div> </div> <div class="row"> <div class="label-column"><label>Time Zone</label></div> <div class="data-column"><select id="_scheduletimezone"><option value="sys" selected="selected">System Time Zone</option><option value="-12.0">(GMT -12:00) Eniwetok, Kwajalein</option> <option value="-11.0">(GMT -11:00) Midway Island, Samoa</option><option value="-10.0">(GMT -10:00) Hawaii</option> <option value="-9.0">(GMT -9:00) Alaska</option><option value="-8.0">(GMT -8:00) Pacific Time (US &amp; Canada)</option><option value="-7.0">(GMT -7:00) Mountain Time (US &amp; Canada)</option><option value="-6.0">(GMT -6:00) Central Time (US &amp; Canada), Mexico City</option><option value="-5.0">(GMT -5:00) Eastern Time (US &amp; Canada), Bogota, Lima</option><option value="-4.0">(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz</option><option value="-3.5">(GMT -3:30) Newfoundland</option><option value="-3.0">(GMT -3:00) Brazil, Buenos Aires, Georgetown</option><option value="-2.0">(GMT -2:00) Mid-Atlantic</option><option value="-1.0">(GMT -1:00 hour) Azores, Cape Verde Islands</option><option value="0.0">(GMT) Western Europe Time, London, Lisbon, Casablanca</option><option value="1.0">(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris</option><option value="2.0">(GMT +2:00) Kaliningrad, South Africa</option><option value="3.0">(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg</option><option value="3.5">(GMT +3:30) Tehran</option><option value="4.0">(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi</option><option value="4.5">(GMT +4:30) Kabul</option><option value="5.0">(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent</option><option value="5.5">(GMT +5:30) Bombay, Calcutta, Madras, New Delhi</option><option value="5.75">(GMT +5:45) Kathmandu</option><option value="6.0">(GMT +6:00) Almaty, Dhaka, Colombo</option><option value="7.0">(GMT +7:00) Bangkok, Hanoi, Jakarta</option><option value="8.0">(GMT +8:00) Beijing, Perth, Singapore, Hong Kong</option><option value="9.0">(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option><option value="9.5">(GMT +9:30) Adelaide, Darwin</option><option value="10.0">(GMT +10:00) Eastern Australia, Guam, Vladivostok</option><option value="11.0">(GMT +11:00) Magadan, Solomon Islands, New Caledonia</option><option value="12.0">(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka</option></select></div> </div> <div class="row"> <div class="label-column"><label>Schedule Period</label></div> <div class="data-column"><input type="text" style="width: 120px;" size="12" value="01/03/2013" id="_editStartDate1" class="hasDatepicker" placeholder="From" /><div class="data-text">-</div><input type="text" size="12" style="width: 120px;" value="01/03/2015" class="hasDatepicker" id="_editEndDate1" placeholder="To" /></div> </div> <div class="row"> <div class="label-column"><label>Frequency</label></div> <div class="data-column"><select id="_schedulefrequency1" style="width: auto; min-width: 120px; margin-right: 10px;"><option value="Daily">Daily</option><option value="Weekly" selected="selected">Weekly</option><option value="Monthly">Monthly</option></select> <select id="_schedulefrequencyday" style="width: auto; min-width: 120px;"><option selected="selected">Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option></select></div> </div> <div class="row"> <div class="label-column"><label>Run Time</label></div> <div class="data-column"><select id="_schedulehours1" style="width: 60px;"><option>01</option><option>02</option><option>03</option><option>04</option><option>05</option><option>06</option><option>07</option><option>08</option><option selected="selected">09</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option></select><label class="desc">Hours</label> <select id="_schedulemins" style="width: 60px;"><option selected="selected">00</option><option>01</option><option>02</option><option>03</option><option>04</option><option>05</option><option>06</option><option>07</option><option>08</option><option>09</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option></select><label class="desc">Minutes</label></div> </div> <div class="row"> <div class="label-column"><label>Delivery By Email</label></div> <div class="data-column"><input type="checkbox" name="_scheduleemail" id="_scheduleemail"> </div> </div>  </div> </div>').appendTo($wrapper);

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddDebitAccount",
		title: "Add a Schedule",
		size: "small",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
					//$('#AddDebitAccount').fadeOut();
					$('#AddDebitAccount').remove()
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveSchedule(_dialog)
					dialogHider(_dialog);
					//$('#AddDebitAccount').fadeOut();
					$('#AddDebitAccount').remove()
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	setTimeout(function() {
		$('#AddDebitAccount.moveback').remove();
	}, 300);
}

function showEditSchedule(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' style='overflow:hidden;height:320px' />");

	function saveSchedule(_dialog) {
		var item = dataView.getItem(grid.getActiveCell().row);
		var index = $.inArray(item, data);

		var scheduledata = store.get('schedule-data');
		var items = dataViewSchedule.getItem(schedulegrid.getActiveCell().row);


		//var indexs = $.inArray(items, scheduledata);
		var result = $.grep(scheduledata, function(e, ind) {
			return e.id == items.id;
		});

		var indexs = $.inArray(result[0], scheduledata);

		var ll = scheduledata.length;

		var sindex = $.inArray(items, item.schedules);
		//scheduledata[indexs].id = "id_"+ (ll+1)
		result[0].lastrundate = "";
		result[0].nextrundate = "";
		result[0].repprofile = "Y";
		result[0].reptype = $('#_reptypefield1').val();
		result[0].schedend = $('#_editEndDate1').val();
		result[0].enddate = $('#_editEndDate1').val();
		result[0].schedfreq = $('#_schedulefrequency1').val();
		result[0].frequency = $('#_schedulefrequency1').val();
		result[0].schedname = $('#_schedulename1').val();
		result[0].name = $('#_schedulename1').val();
		result[0].schedstart = $('#_editStartDate1').val();
		result[0].startdate = $('#_editStartDate1').val();
		result[0].status = "Active";

		//scheduledata.push(obj);
		scheduledata[indexs] = result[0];

		data[index].schedules[sindex] = result[0];

		store.set('report-data', data);
		store.set('schedule-data', scheduledata);

		dataViewSchedule.refresh();
		dataViewSchedule.setItems(item.schedules);
		schedulegrid.setColumns(columnsschedule);
	}
	/* build the account filter input */
	/* build the header row */
	//var $header = $("<div class='dialog-search-header' />").appendTo($wrapper);
	//$nameHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Name</div>").appendTo($header),
	//$numberHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Number</div>").appendTo($header),
	//$currencyHeader = $("<div class='dialog-search-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	$('<div class="data-entry" style="" id="_scheduleinfo">  <div class="form-section"> <div class="row"> <div class="label-column"><label>Schedule Name</label></div> <div class="data-column"><input type="text" id="_schedulename1" size="40" value="Previous Week Statements" /></div> </div> <div class="row"> <div class="label-column"><label>Time Zone</label></div> <div class="data-column"><select id="_scheduletimezone"><option value="sys" selected="selected">System Time Zone</option><option value="-12.0">(GMT -12:00) Eniwetok, Kwajalein</option> <option value="-11.0">(GMT -11:00) Midway Island, Samoa</option><option value="-10.0">(GMT -10:00) Hawaii</option> <option value="-9.0">(GMT -9:00) Alaska</option><option value="-8.0">(GMT -8:00) Pacific Time (US &amp; Canada)</option><option value="-7.0">(GMT -7:00) Mountain Time (US &amp; Canada)</option><option value="-6.0">(GMT -6:00) Central Time (US &amp; Canada), Mexico City</option><option value="-5.0">(GMT -5:00) Eastern Time (US &amp; Canada), Bogota, Lima</option><option value="-4.0">(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz</option><option value="-3.5">(GMT -3:30) Newfoundland</option><option value="-3.0">(GMT -3:00) Brazil, Buenos Aires, Georgetown</option><option value="-2.0">(GMT -2:00) Mid-Atlantic</option><option value="-1.0">(GMT -1:00 hour) Azores, Cape Verde Islands</option><option value="0.0">(GMT) Western Europe Time, London, Lisbon, Casablanca</option><option value="1.0">(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris</option><option value="2.0">(GMT +2:00) Kaliningrad, South Africa</option><option value="3.0">(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg</option><option value="3.5">(GMT +3:30) Tehran</option><option value="4.0">(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi</option><option value="4.5">(GMT +4:30) Kabul</option><option value="5.0">(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent</option><option value="5.5">(GMT +5:30) Bombay, Calcutta, Madras, New Delhi</option><option value="5.75">(GMT +5:45) Kathmandu</option><option value="6.0">(GMT +6:00) Almaty, Dhaka, Colombo</option><option value="7.0">(GMT +7:00) Bangkok, Hanoi, Jakarta</option><option value="8.0">(GMT +8:00) Beijing, Perth, Singapore, Hong Kong</option><option value="9.0">(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option><option value="9.5">(GMT +9:30) Adelaide, Darwin</option><option value="10.0">(GMT +10:00) Eastern Australia, Guam, Vladivostok</option><option value="11.0">(GMT +11:00) Magadan, Solomon Islands, New Caledonia</option><option value="12.0">(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka</option></select></div> </div> <div class="row"> <div class="label-column"><label>Schedule Period</label></div> <div class="data-column"><input type="text" style="width: 120px;" size="12" value="01/03/2013" id="_editStartDate1" class="hasDatepicker" placeholder="From" /><div class="data-text">-</div><input type="text" size="12" style="width: 120px;" value="01/03/2015" class="hasDatepicker" id="_editEndDate1" placeholder="To" /></div> </div> <div class="row"> <div class="label-column"><label>Frequency</label></div> <div class="data-column"><select id="_schedulefrequency1" style="width: auto; min-width: 120px; margin-right: 10px;"><option value="Daily">Daily</option><option value="Weekly" selected="selected">Weekly</option><option value="Monthly">Monthly</option></select> <select id="_schedulefrequencyday" style="width: auto; min-width: 120px;"><option selected="selected">Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option></select></div> </div> <div class="row"> <div class="label-column"><label>Run Time</label></div> <div class="data-column"><select id="_schedulehours1" style="width: 60px;"><option>01</option><option>02</option><option>03</option><option>04</option><option>05</option><option>06</option><option>07</option><option>08</option><option selected="selected">09</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option></select><label class="desc">Hours</label> <select id="_schedulemins" style="width: 60px;"><option selected="selected">00</option><option>01</option><option>02</option><option>03</option><option>04</option><option>05</option><option>06</option><option>07</option><option>08</option><option>09</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option></select><label class="desc">Minutes</label></div> </div> <div class="row"> <div class="label-column"><label>Delivery By Email</label></div> <div class="data-column"><input type="checkbox" name="_scheduleemail" id="_scheduleemail"> </div> </div>  </div> </div>').appendTo($wrapper);

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddDebitAccount",
		title: "Edit a Schedule",

		size: "small",

		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
					//$('#AddDebitAccount').fadeOut();
					$('#AddDebitAccount').remove()
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveSchedule(_dialog)
					dialogHider(_dialog);
					//$('#AddDebitAccount').fadeOut();
					$('#AddDebitAccount').remove()
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	setTimeout(function() {
		$('#AddDebitAccount.moveback').remove();
		$('#_editStartDate1').datepicker();
		$('#_editEndDate1').datepicker();
	}, 1000);
}


/**********************************************************************
REPORTS GRID SETUP
**********************************************************************/
var dataView;
var grid;
var data = [];
var sharedData = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [{
	id: "repname",
	name: "Report Name",
	field: "repname",
	width: 300,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "reptype",
	name: "Report Type",
	field: "reptype",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "description",
	name: "Description",
	field: "description",
	width: 400,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "shared",
	name: "Shared",
	field: "shared",
	width: 100,
	sortable: true,
	sorter: "sorterStringCompare",
	headerCssClass: "centered",
	cssClass: "centered",
	visible: true
}, {
	id: "sharedby",
	name: "Shared By",
	field: "sharedby",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "schedulesnumber",
	name: "Schedules",
	field: "schedulesnumber",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true,
	headerCssClass: "centered",
	cssClass: "centered"
}];
if (store.get('adhocOrder')) {
	columns = store.get('adhocOrder');
}
if (store.get('adhocWidths')) {
	var setWidth = store.get('adhocWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
},
groupedSetting = 0,
groupCollapseSetting = 0;


/**********************************************************************
REPORT SCHEDULES GRID SETUP
**********************************************************************/
var dataViewSchedule;
var schedulegrid;
var dataschedule = [];
var sharedData = [];
var selectedRowIdsSchedule = [];
var columnsschedule = [{
	id: "name",
	name: "Schedule Name",
	field: "name",
	width: 300,
	sortable: true,
	visible: true
}, {
	id: "status",
	name: "Status",
	field: "status",
	width: 100,
	sortable: true,
	visible: true
}, {
	id: "frequency",
	name: "Frequency",
	field: "frequency",
	width: 100,
	sortable: true,
	visible: true
}, {
	id: "lastrundate",
	name: "Last Run Date",
	field: "lastrundate",
	width: 180,
	sortable: true,
	headerCssClass: "centered",
	cssClass: "centered",
	visible: true
}, {
	id: "nextrundate",
	name: "Next Run Date",
	field: "nextrundate",
	width: 180,
	sortable: true,
	visible: true
}, {
	id: "startdate",
	name: "Start Date",
	field: "startdate",
	width: 180,
	sortable: true,
	headerCssClass: "centered",
	cssClass: "centered",
	visible: true
}, {
	id: "enddate",
	name: "End Date",
	field: "enddate",
	width: 180,
	sortable: true,
	visible: true
}, ];
if (store.get('scheduleOrder')) {
	columnsschedule = store.get('scheduleOrder');
}
if (store.get('scheduleWidths')) {
	var setWidth = store.get('scheduleWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columnsschedule.length; c++) {
			if (s.id == columnsschedule[c].id) {
				columnsschedule[c].width = s.width
			}
		}
	}
}
var optionsschedule = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiSelect: true
},
groupedSetting = 0,
groupCollapseSetting = 0;


/**********************************************************************
REPORT PROFILE GROUPING
**********************************************************************/
function expandAllGroups() {
	dataView.expandAllGroups();
}

function collapseAllGroups() {
	dataView.collapseAllGroups();
}

function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}

function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				if (item == "sharedby" && g.value == "0") {
					return text + ": Not Shared <span>(" + g.count + " items)</span>";
				} else {
					return text + ":  " + g.value + "  <span>(" + g.count + " items)</span>";
				}
			},
			displayTotalsRow: false
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}



/**********************************************************************
REPORT PROFILE FILTERING
**********************************************************************/
var repString = "",
	repDataPoint = "repname";

function myFilter(item, args) {

	if (args.repString != "" && item[repDataPoint].toLowerCase().indexOf(args.repString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}

function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}



/**********************************************************************
REPORT PROFILE DATA
**********************************************************************/
if (store.get('report-data')) {
	data = store.get('report-data');
} else {
	store.set('report-data', data);
}
if (store.get('report-sharedData')) {
	sharedData = store.get('report-sharedData');
} else {
	store.set('report-sharedData', sharedData);
}


/**********************************************************************
FIND CURRENCIES GRID
**********************************************************************/
var findCCYDataView;
var findCCYGrid;
var findCCYData = [{
	id: "id_0",
	ccy: "AUD",
	ccyname: "Australian Dollars"
}, {
	id: "id_1",
	ccy: "CNY",
	ccyname: "Chinese Yuan"
}, {
	id: "id_2",
	ccy: "EUR",
	ccyname: "Euro"
}, {
	id: "id_3",
	ccy: "HKD",
	ccyname: "Hong Kong Dollars"
}, {
	id: "id_4",
	ccy: "IDR",
	ccyname: "Indonesian Rupiah"
}, {
	id: "id_5",
	ccy: "INR",
	ccyname: "Indian Rupee"
}, {
	id: "id_6",
	ccy: "KRW",
	ccyname: "Korean Won"
}, {
	id: "id_7",
	ccy: "KHR",
	ccyname: "Cambodian Riel"
}, {
	id: "id_8",
	ccy: "MYR",
	ccyname: "Malaysian Ringgit"
}, {
	id: "id_9",
	ccy: "NZD",
	ccyname: "New Zealand Dollar"
}, {
	id: "id_10",
	ccy: "SGD",
	ccyname: "Singapore Dollar"
}, {
	id: "id_11",
	ccy: "THB",
	ccyname: "Thailand Baht"
}, {
	id: "id_12",
	ccy: "USD",
	ccyname: "United States Dollar"
}, {
	id: "id_13",
	ccy: "VND",
	ccyname: "Vietnamese Dong"
}];
var findCCYSelectedRowIds = [];
var findCCYColumns = [{
		id: "ccy",
		name: "Currency Code",
		field: "ccy",
		toolTip: "Click to sort by Currency Code",
		width: 150,
		sortable: true,
		cssClass: "no-pointer"
	}, {
		id: "ccyname",
		name: "Currency Description",
		field: "ccyname",
		toolTip: "Click to sort by Currency Description",
		width: 350,
		sortable: true,
		cssClass: "no-pointer"
	}],
	findCCYOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};
var findCCYCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
findCCYColumns.unshift(findCCYCheckboxSelector.getColumnDefinition());
var findCCYString = "",
	findCCYDataPoint = "ccy";

function ccyFilter(item, args) {
	if (args.findCCYString != "" && item[findCCYDataPoint].toLowerCase().indexOf(args.findCCYString.toLowerCase()) == -1)
		return false;
	return true;
}


/**********************************************************************
FIND ACCOUNTS GRID
**********************************************************************/
var findDataView;
var findGrid;
var findData = [];
var findSelectedRowIds = [];
var findColumns = [{
		id: "accountnam",
		name: "Account Name",
		field: "accountnam",
		toolTip: "Click to sort by Account Name",
		width: 250,
		sortable: true,
		cssClass: "no-pointer"
	}, {
		id: "accountnum",
		name: "Account Number",
		field: "accountnum",
		toolTip: "Click to sort by Account Number",
		width: 250,
		sortable: true,
		cssClass: "no-pointer"
	}],
	findOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};
var findCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
findColumns.unshift(findCheckboxSelector.getColumnDefinition());
var findString = "",
	findDataPoint = "accountnam";

function accFilter(item, args) {

	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1)
		return false;

	return true;
}
for (var i = 0; i < 30; i++) {
	var d = (findData[i] = {});
	d["id"] = "id_" + i;
	d["accountnam"] = "CURRENT" + Math.round(Math.random() * 1000);
	d["accountnum"] = Math.round(Math.random() * 1000000000).toString();
}

/**********************************************************************
FILTER ITEMS GRID
**********************************************************************/
var filterDataView,
	filterGrid,
	filterData = [],
	filterAccountData = []
filterCurrencyData = []
filterColumns = [],
	filterSelectedRowIds = [],
	filterOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};


/**********************************************************************
SETUP CONTEXT MENU
**********************************************************************/
function checkStatus(arr) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--] !== arr[L]) return false;
	}
	return arr[L];
}
var enableContextItem = function() {
	var text = $(this).children("div.disabled").text();
	$(this).children("div.disabled").replaceWith("<a href='javascript:void(0)'>" + text + "</a>");
};
var disableContextItem = function() {
	var text = $(this).children("a").text();
	$(this).children("a").replaceWith("<div class='disabled'>" + text + "</div>");
};
var selectedReportOwners = [];

function setupContextMenu() {
	var sel = selectedReportOwners.length,
		$contextItems = $("[data-type='context-item']");
	var sameOwner;
	if (sel == 0) {
		$contextItems.each(disableContextItem);
	} else if (sel == 1) {
		sameOwner = checkStatus(selectedReportOwners);
		if (sameOwner == "PrototypeUser") {
			$contextItems.each(enableContextItem);
		} else {
			$("[data-action='run'], [data-action='view']").each(enableContextItem);
			$("[data-action='edit'], [data-action='delete']").each(disableContextItem);
		}
	} else if (sel > 1) {
		sameOwner = checkStatus(selectedReportOwners);
		$("[data-action='delete']").each(enableContextItem);
		$("[data-action='run'], [data-action='edit'], [data-action='view']").each(disableContextItem);
		if (!sameOwner || sameOwner != "PrototypeUser") {
			$("[data-action='delete']").each(disableContextItem);
		}
	}
}


/**********************************************************************
UPDATE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='report-profiles.html'>Report Profiles</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Report Profile Details");
	} else if (update == "edit") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Edit Report Profile");
	} else if (update == "new") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("New Report Profile");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Report Profiles");
	}
}



/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {

	try {
		var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		dataView = new Slick.Data.DataView({
			groupItemMetadataProvider: groupItemMetadataProvider
		});
		grid = new Slick.Grid("#adhocReports", dataView, columns, options);
		grid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		grid.registerPlugin(groupItemMetadataProvider);
		grid.registerPlugin(checkboxSelector);
		var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'adhocOrder', 'adhocWidths', ["checkboxSelector"]);
		grid.onContextMenu.subscribe(function(e, args) {
			e.preventDefault();
			var cell = grid.getCellFromEvent(e),
				row = cell.row,
				rows = grid.getSelectedRows(),
				$cmenu = $("#contextMenu");
			if ($.inArray(row, rows) == -1) {
				grid.setSelectedRows([row]);
			}
			grid.setActiveCell(row, cell.cell)
			setupContextMenu();
			var cheight = $cmenu.height(),
				winwidth = $(window).width(),
				winheight = $(window).height(),
				leftpos = e.pageX,
				toppos = e.pageY;
			if (e.pageX + 210 > winwidth) {
				leftpos = e.pageX - 205;
			}
			if (e.pageY + cheight > winheight) {
				toppos = e.pageY - cheight;
				if (toppos < 0) {
					toppos = e.pageY - (cheight - (winheight - e.pageY));
				}
			};
			$(document).off("keyup.hide-context");
			$("body").off("click.hide-context");
			function hideContextMenu() {
				$(".control-menus").children(".control-menu:visible").hide();
				$(".control-list").find(".on").removeClass("on");
				$(".control-menus").find("a.sub-open").removeClass("sub-open");
			}
			hideContextMenu();
			$cmenu.css("top", toppos).css("left", leftpos).show();
			$(document).on("keyup.hide-context", function(e) {
				if (e.keyCode == 27) {
					hideContextMenu()
				}
			});
			$("body").one("click.hide-context", function() {
				hideContextMenu()
			});
		});
		grid.onSelectedRowsChanged.subscribe(function(e) {
			$(document).off("keyup.hide-menu");
			$(".shell").off("resize.hide-menu");
			$("body").off("click.hide-menu");
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			selectedRowIds = [];
			selectedReportOwners = [];
			var rows = grid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = dataView.getItem(rows[i])
				if (item.id) {
					selectedRowIds.push(item.id);
					selectedReportOwners.push(item.ownedby)
				}
			}
			if (selectedRowIds.length > 0) {
				$("#adhocReports").addClass("has-bottom-controls");
				$("#reportSummary .bottom-controls").removeClass("hidden");
				$("#selectedCount").html(selectedRowIds.length);
			} else {
				$("#adhocReports").removeClass("has-bottom-controls");
				$("#reportSummary .bottom-controls").addClass("hidden");
				$("#selectedCount").html('');
			}
			grid.resizeCanvas();
		});
		grid.onClick.subscribe(function(e, args) {
			row = args.row, $row = $(e.target).closest(".slick-row");
			if (!$row.is(".slick-group, .slick-group-totals")) {
				$row.attr({
					'data-panel': '#reportDetail',
					'data-switch': 'switch-panels'
				}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
				setupReportDetails(dataView.getItem(row), "view")
				grid.setSelectedRows(0);
				selectedRowIds = [];
			}
		});
		grid.onSort.subscribe(function(e, args) {
			var cols = args.sortCols;
			dataView.sort(function(dataRow1, dataRow2) {
				for (var i = 0, l = cols.length; i < l; i++) {
					sortdir = cols[i].sortAsc ? 1 : -1;
					sortcol = cols[i].sortCol.field;
					var _sorter = cols[i].sortCol.sorter,
						result;
					if (_sorter == "sorterStringCompare") {
						result = sorterStringCompare(dataRow1, dataRow2);
					} else if (_sorter == "sorterNumeric") {
						result = sorterNumeric(dataRow1, dataRow2);
					} else if (_sorter == "sorterDateIso") {
						result = sorterDateIso(dataRow1, dataRow2);
					} else if (_sorter == "sorterTime") {
						result = sorterTime(dataRow1, dataRow2);
					}
					if (result != 0) {
						return result;
					}
				}
				return 0;
			});
			args.grid.invalidateAllRows();
			args.grid.render();
		});
		grid.onColumnsResized.subscribe(function(e, args) {
			store.set('adhocWidths', grid.getColumns());
		});
		$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
			var columnId = $(this).data("columnId");
			var $icon = $(this).next("i");
			if (columnId != null) {
				columnFilters[columnId] = $.trim($(this).val());
				$icon.show();
				dataView.refresh();
				if (!$(this).val()) {
					$icon.hide();
				}
			}
		});
		grid.onHeaderRowCellRendered.subscribe(function(e, args) {
			if (args.column.id == "_checkbox_selector") {
				return false;
			} else {
				$(args.node).empty().addClass(args.column.headerCssClass);
				var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
				var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
					e.preventDefault();
					$(this).prev("input[type='text']").val("").trigger("change");
					$(this).hide();
				});
				if ($input.val()) {
					$icon.show();
				}
			}
		});
		dataView.onRowCountChanged.subscribe(function(e, args) {
			grid.updateRowCount();
			grid.render();
		});
		dataView.onRowsChanged.subscribe(function(e, args) {
			grid.invalidateRows(args.rows);
			grid.render();
			if (selectedRowIds.length > 0) {
				var selRows = [];
				for (var i = 0; i < selectedRowIds.length; i++) {
					var idx = dataView.getRowById(selectedRowIds[i]);
					if (idx != undefined)
						selRows.push(idx);
				}
				grid.setSelectedRows(selRows);
			}
		});
		dataView.setItems(data);
		dataView.setFilterArgs({
			repString: repString
		});
		dataView.syncGridSelection(grid, true, false);
		dataView.syncGridCellCssStyles(grid, "contextMenu");
		dataView.setFilter(myFilter);
		grid.setColumns(columns);
		if (store.get('adhocOrder')) {
			var visibleAdHocColumns = [];
			for (var i = 0; i < store.get('adhocOrder').length + 1; i++) {
				if (columns[i].visible) {
					visibleAdHocColumns.push(columns[i])
				}
			}
			grid.setColumns(visibleAdHocColumns);
		}
		grid.setHeaderRowVisibility(false);
	} catch (e) {}

	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
		if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
			filterGrid.resizeCanvas();
		}
	});



	/**********************************************************************
	schedule INITIALISE REPORTS GRID
	**********************************************************************/
	try {
		var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		dataViewSchedule = new Slick.Data.DataView({
			groupItemMetadataProvider: groupItemMetadataProvider
		});
		var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
			cssClass: "slick-cell-checkboxsel"
		});
		columnsschedule.unshift(filterCheckboxSelector.getColumnDefinition());

		schedulegrid = new Slick.Grid("#_associatedschedule", dataViewSchedule, columnsschedule, optionsschedule);
		schedulegrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		schedulegrid.registerPlugin(groupItemMetadataProvider);
		schedulegrid.registerPlugin(filterCheckboxSelector);
		var columnpicker = new Slick.Controls.ColumnPicker(columnsschedule, schedulegrid, optionsschedule, 'scheduleOrder', 'scheduleWidths', ["filterCheckboxSelector"]);
		dataViewSchedule.setItems(dataschedule);
		dataViewSchedule.setFilterArgs({
			repString: repString
		});
		dataViewSchedule.setFilter(myFilter);
		schedulegrid.setColumns(columnsschedule);
		if (store.get('adhocOrder')) {
			var visibleAdHocColumns = [];
			for (var i = 0; i < store.get('adhocOrder').length + 1; i++) {
				if (columnsschedule[i].visible) {
					visibleAdHocColumns.push(columnsschedule[i])
				}
			}
			schedulegrid.setColumns(visibleAdHocColumns);
		}

	} catch (e) {

	}

	/**********************************************************************
	schedule GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		try {
			schedulegrid.resizeCanvas();
		} catch (e) {}
		if (typeof(filterGrid) != 'undefined' && filterGrid != null) {
			filterGrid.resizeCanvas();
		}
	});



	/**********************************************************************
	REMEMBER GRID SETTINGS
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	REPORT INTERACTIONS
	**********************************************************************/
	$("[data-action='view']").on("click", "a", function(e) {
		var $target = $(e.target);
		var item = dataView.getItem(grid.getSelectedRows());
		$target.attr({
			'data-panel': '#reportDetail',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		setupReportDetails(item, "view")
		grid.setSelectedRows(0);
		selectedRowIds = [];
	});
	$("[data-action='edit']").on("click", "a", function(e) {
		var $target = $(e.target);
		var item = dataView.getItem(grid.getSelectedRows());
		$target.attr({
			'data-panel': '#reportDetail',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		setupReportDetails(item, "edit")
		grid.setSelectedRows(0);
		selectedRowIds = [];
	});
	$("[data-action='delete']").on("click.delete-sel", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" || $target.prop("nodeName") == "I") {
			$("#contextMenu").hide();

			function deleteProfiles() {
				$target.attr({
					'data-switch': 'switch-panels',
					'data-panel': '#reportSummary'
				}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
				var rowsForDelete = [];
				for (var i = 0, l = selectedRowIds.length; i < l; i++) {
					var item = selectedRowIds[i];
					if (item) rowsForDelete.unshift(item)
				};
				for (var i = 0; i < rowsForDelete.length; i++) {
					dataView.deleteItem(rowsForDelete[i])
				};
				if (gridMode == "my") {
					for (var i = 0; i < rowsForDelete.length; i++) {
						for (var d = 0; d < sharedData.length; d++) {
							if (rowsForDelete[i] == sharedData[d].id) {
								sharedData.splice(d, 1)
							}
						}
					}
				} else {
					for (var i = 0; i < rowsForDelete.length; i++) {
						for (var d = 0; d < data.length; d++) {
							if (rowsForDelete[i] == data[d].id) {
								data.splice(d, 1)
							}
						}
					}
				}
				store.set('report-data', data);
				grid.setSelectedRows(0);
				selectedRowIds = [];
				dataView.refresh();
				grid.invalidate();
				grid.render();
				if (groupCollapseSetting == 1) {
					collapseAllGroups()
				};
				groupedSetting = 1;
				buildNotification("Report profiles have been deleted.", 300, 3000);
			}
			buildConfirmDialog("Delete selected report profiles?", "", function() {
				deleteProfiles(e)
			});
		}
	});
	$("#_newReportButton").on("click", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		$target.attr({
			'data-panel': '#reportDetail',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		setupReportDetails('', "new")
	});
	$("#_updateReport").on("click", "a", function(e) {
		var $target = $(e.target);
		var item = dataView.getItem(grid.getActiveCell().row);
		$target.attr({
			'data-switch': 'switch-panels',
			'data-panel': '#reportDetail'
		}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
		updateReport(item);
		buildNotification(item.repname + " report profile has been updated", 300, 3000);
	});
	$("#_saveNewReport").on("click", "a", function(e) {

		var $row = $("#_reptypefield").closest("div.row"),
			$f1 = $("#_f1").closest("div.row"),
			$f2 = $("#_f2").closest("div.row"),
			$row2 = $("#_schedulename").closest("div.row"),
			$row3 = $("#_editStartDate").closest("div.row"),
			$row4 = $("#_editEndDate").closest("div.row");
		if ($("#_reptypefield").val() == "") {
			$row.addClass("error");

		} else {
			$row.removeClass("error");
		}

		if ($("#_f1").prop("checked") === false && $("#_f2").prop("checked") === false) {
			$f1.addClass("error");


		} else {
			$f1.removeClass("error");
		}

		if ($("#_schedulename").val() != "" || $("#_editStartDate").val() != "" || $("#_editEndDate").val() != "") {


			if ($("#_schedulename").val() == "") {
				$row2.addClass("error");

			} else {
				$row2.removeClass("error");
			}

			if ($("#_editStartDate").val() == "") {
				$row3.addClass("error");

			} else {
				$row3.removeClass("error");
			}


			if ($("#_editEndDate").val() == "") {
				$row4.addClass("error");

			} else {
				$row4.removeClass("error");
			}



		} else {

			$row2.removeClass("error");
			$row3.removeClass("error");
			$row4.removeClass("error");
		}

		if ($row.hasClass("error") || $f1.hasClass("error") || $row2.hasClass("error") || $row3.hasClass("error") || $row4.hasClass("error")) {
			return false;
		}

		saveNewReport();
		var $target = $(e.target);
		$target.attr({
			'data-switch': 'switch-panels',
			'data-panel': '#reportSummary'
		}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
		var repName = $("#_repnamefield").val(),
			repType = $("#_reptypefield").val();
		buildNotification(repName + " report profile has been created.", 300, 3000);
	});
	$("#_deleteButton").on("click", "a", function(e) {
		e.preventDefault();
		var $target = $(e.target);

		function deleteProfile() {
			$target.attr({
				'data-switch': 'switch-panels',
				'data-panel': '#reportSummary'
			}).trigger("click.switch-panels").removeAttr("data-switch data-panel");
			var item = dataView.getItem(grid.getActiveCell().row);
			dataView.deleteItem(item.id)
			if (gridMode == "my") {
				for (var d = 0; d < sharedData.length; d++) {
					if (item.id == sharedData[d].id) {
						sharedData.splice(d, 1)
					}
				}
			} else {
				for (var d = 0; d < data.length; d++) {
					if (item.id == data[d].id) {
						data.splice(d, 1)
					}
				}
			}
			store.set('report-data', data);
			grid.setSelectedRows(0);
			selectedRowIds = [];
			dataView.refresh();
			grid.invalidate();
			grid.render();
			if (groupCollapseSetting == 1) {
				collapseAllGroups()
			};
			groupedSetting = 1;
			buildNotification("Report profile has been deleted.", 300, 3000);
		}
		buildConfirmDialog("Delete this report profile?", "", function() {
			deleteProfile(e)
		});
	});
	$("[data-action='backToGrid']").on("click", function(e){
		e.preventDefault();
		$(this).attr({
			'data-panel': '#reportSummary',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		updateBreadcrumb("close");
	});

	/**********************************************************************
	DATE RANGE FUNCTIONS
	**********************************************************************/
	function getFilterDate(selection) {
		if (selection == "Today") {
			printdate = $.datepicker.formatDate('dd/mm/yy', new Date())
		} else if (selection == "Yesterday") {
			var yesterday = new Date();
			yesterday.setDate(yesterday.getDate() - 1)
			printdate = $.datepicker.formatDate('dd/mm/yy', yesterday)
		} else if (selection == "Week To Date") {
			var fromDate = new Date(),
				toDate = new Date();
			var startDate = fromDate.getDate() - fromDate.getDay() + (fromDate.getDay() == 0 ? -6 : 1)
			fromDate.setDate(startDate)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate) + " - " + $.datepicker.formatDate('dd/mm/yy', toDate)
		} else if (selection == "Previous Week") {
			var fromDate = new Date(),
				toDate = new Date();
			var startDate = (fromDate.getDate() - 7) - fromDate.getDay() + (fromDate.getDay() == 0 ? -6 : 1)
			fromDate.setDate(startDate)
			var endDate = fromDate.getDate() + 4;
			toDate.setDate(endDate)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate) + " - " + $.datepicker.formatDate('dd/mm/yy', toDate)
		} else if (selection == "Month To Date") {
			var fromDate = new Date(),
				toDate = new Date();
			fromDate.setDate(1)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate) + " - " + $.datepicker.formatDate('dd/mm/yy', toDate)
		} else if (selection == "Previous Month") {
			var fromDate = new Date(),
				toDate = new Date();
			fromDate.setMonth(fromDate.getMonth() - 1)
			fromDate.setDate(1)
			toDate.setMonth(fromDate.getMonth() + 1)
			toDate.setDate(0)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate) + " - " + $.datepicker.formatDate('dd/mm/yy', toDate)
		}
		return printdate
	}
	var newRepDates = $("#_newStartDate, #_newEndDate").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			var option = this.id == "_newStartDate" ? "minDate" : "maxDate",
				instance = $(this).data("datepicker"),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings);
			newRepDates.not(this).datepicker("option", option, date);
		}
	});
	var editRepDates = $("#_editStartDate, #_editEndDate, #_editStartDate1 , #_editEndDate1").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			var option = this.id == "_editStartDate" ? "minDate" : "maxDate",
				instance = $(this).data("datepicker"),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings);
			newRepDates.not(this).datepicker("option", option, date);
		}
	});
	$("#_datefilterfield").on("change", function(e) {
		var printDate = $(this).val(),
			$printDiv = $("#_printdate");
		if (printDate == "Specific Date") {
			$printDiv.html('').hide();
			$("#_datefrom, #_dateto").attr({
				"disabled": "disabled"
			}).datepicker("destroy").val('').hide();
			$("#_datefrom").show().removeAttr("disabled").attr("placeholder", "Date").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				maxDate: 0
			}).focus().blur();
		} else if (printDate == "Date Range") {
			$printDiv.html('').hide();
			$("#_datefrom").attr({
				"disabled": "disabled"
			}).datepicker("destroy").val('').hide();
			$("#_datefrom").attr("placeholder", "From");
			$("#_dateto").attr("placeholder", "To");
			$("#_datefrom, #_dateto").removeAttr("disabled").show()
			var dates = $("#_datefrom, #_dateto").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				maxDate: 0,
				onSelect: function(selectedDate) {
					var option = this.id == "_datefrom" ? "minDate" : "maxDate",
						instance = $(this).data("datepicker"),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings);
					dates.not(this).datepicker("option", option, date);
				}
			});
			$("#_datefrom").focus().blur();
		} else {
			$("#_datefrom, #_dateto").hide().attr({
				"disabled": "disabled"
			}).datepicker("destroy").val('');
		}
	});
	$("#_editButton").on("click", "a", function(e) {
		var $target = $(e.target);
		var item = dataView.getItem(grid.getActiveCell().row);
		$target.attr({
			'data-panel': '#reportDetails',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		setupReportDetails(item, "edit");
	});
	$("[data-action='previousReport']").on("click", function(e) {
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow - 1;
		if ($("#adhocReports").find("div[row='" + activeRow + "']").is(".slick-group, .slick-group-totals")) {
			activeRow = activeRow - 1;
		}
		grid.setActiveCell(activeRow, 0)
		$("#adhocReports").find("div[row='" + activeRow + "'] div.slick-cell").eq(2).trigger("click")
	});
	$("[data-action='nextReport']").on("click", function(e) {
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow + 1;
		if ($("#adhocReports").find("div[row='" + activeRow + "']").is(".slick-group, .slick-group-totals")) {
			activeRow = activeRow + 1;
		}
		if (activeRow >= grid.getDataLength()) {
			return false;
		} else {
			grid.setActiveCell(activeRow, 0)
			$("#adhocReports").find("div[row='" + activeRow + "'] div.slick-cell").eq(2).trigger("click")
		}
	});


	/**********************************************************************
	CONTROL MENU FUNCTIONS
	**********************************************************************/
	$("[data-action='my-reports']").on("click", function(e) {
		e.preventDefault();
		gridMode = "my";
		$("#repSearchClear").trigger('click')
		dataView.setItems(data);
		dataView.refresh();
		grid.invalidate();
		grid.render();
	});
	$("[data-action='shared-reports']").on("click", function(e) {
		e.preventDefault();
		gridMode = "shared";
		$("#repSearchClear").trigger('click')
		dataView.setItems(sharedData);
		dataView.refresh();
		grid.invalidate();
		grid.render();
	});
	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
	FIND REPORTS INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);

	function repFilter() {
		var rows = grid.getSelectedRows();
		if (rows.length > 0) {
			grid.setSelectedRows(0)
		};
		if (repString == "") {
			dataView.setFilterArgs({
				repString: repString
			})
		} else {
			dataView.setFilterArgs({
				repString: repString
			})
		};
		dataView.refresh();
	}
	$("#repSearchClear").on("click", function() {
		$("#_findReports").val('');
		$("#_findReports").blur();
		$("#repSearchClear").hide();
		repString = "";
		repFilter();
	});
	$("#_findReports").keyup(function(e) {
		if (e.which == 27) {
			$("#repSearchClear").hide();
			this.value = '';
			this.blur()
		};
		repString = this.value;
		repFilter();
		if (this.value != "") {
			$("#repSearchClear").show()
		} else {
			$("#repSearchClear").hide()
		}
	});
	$("#findReportOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var repPlaceholder = $(this).text(),
			repString = $(this).attr("data-find");
		if (repDataPoint != repString) {
			$("#_findReports").attr("placeholder", repPlaceholder);
			repDataPoint = repString;
			$("#_findReports").val('').focus();
			$("#repSearchClear").hide();
			repString = '';
			repFilter();
		}
	});


	/**********************************************************************
	FIND ACCOUNTS INTERACTION
	**********************************************************************/
	function findFilter() {
		var rows = findGrid.getSelectedRows();
		if (rows.length > 0) {
			findGrid.setSelectedRows(0)
		};
		if (findString == "") {
			findDataView.setFilterArgs({
				findString: findString
			})
		} else {
			findDataView.setFilterArgs({
				findString: findString
			})
		};
		findDataView.refresh();
	}
	$("#_findAccountsClear").on("click", function() {
		$("#_findAccountsInput").val('');
		$("#_findAccountsInput").blur();
		$("#_findAccountsClear").hide();
		findString = "";
		findFilter();
	});
	$("#_findAccountsInput").keyup(function(e) {
		if (e.which == 27) {
			$("#_findAccountsClear").hide();
			this.value = '';
			this.blur()
		};
		findString = this.value;
		findFilter();
		if (this.value != "") {
			$("#_findAccountsClear").show()
		} else {
			$("#_findAccountsClear").hide()
		}
	});
	$("#findAccountOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var findPlaceholder = $(this).text(),
			findString = $(this).attr("data-find");
		if (findPlaceholder != findString) {
			$("#_findAccountsInput").attr("placeholder", findPlaceholder);
			findDataPoint = findString;
			$("#_findAccountsInput").val('').focus();
			$("#_findAccountsClear").hide();
			findString = '';
			findFilter();
		}
	});


	/**********************************************************************
	FIND CURRENCIES INTERACTION
	**********************************************************************/
	function findCCYFilter() {
		var rows = findCCYGrid.getSelectedRows();
		if (rows.length > 0) {
			findCCYGrid.setSelectedRows(0)
		};
		if (findCCYString == "") {
			findCCYDataView.setFilterArgs({
				findCCYString: findCCYString
			})
		} else {
			findCCYDataView.setFilterArgs({
				findCCYString: findCCYString
			})
		};
		findCCYDataView.refresh();
	}
	$("#_findCurrencyClear").on("click", function() {
		$("#_findCurrencyInput").val('');
		$("#_findCurrencyInput").blur();
		$("#_findCurrencyClear").hide();
		findCCYString = "";
		findCCYFilter();
	});
	$("#_findCurrencyInput").keyup(function(e) {
		if (e.which == 27) {
			$("#_findCurrencyClear").hide();
			this.value = '';
			this.blur()
		};
		findCCYString = this.value;
		findCCYFilter();
		if (this.value != "") {
			$("#_findCurrencyClear").show()
		} else {
			$("#_findCurrencyClear").hide()
		}
	});
	$("#findCurrencyOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var findCCYPlaceholder = $(this).text(),
			findCCYString = $(this).attr("data-find");
		if (findCCYPlaceholder != findCCYString) {
			$("#_findCurrencyInput").attr("placeholder", findCCYPlaceholder);
			findCCYDataPoint = findCCYString;
			$("#_findCurrencyInput").val('').focus();
			$("#_findCurrencyClear").hide();
			findCCYString = '';
			findCCYFilter();
		}
	});


	/**********************************************************************
	JUMP TO REPORT PROFILE DETAILS
	**********************************************************************/
	var b = document.location.href.split(".html")[1];

	if (b == "#detail") {
		$("#adhocReports").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		document.location.hash = '';
	}


});