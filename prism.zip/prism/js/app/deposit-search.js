/**********************************************************************
DATA
**********************************************************************/
var DEPOSITS = [{
	name: "",
	number: "113-6677-322",
	currency: "AUD",
	funds: "12,000.00",
	available: "12,000.00",
	balance: "12,000.00"
}, {
	name: "",
	number: "456-8888-125",
	currency: "SGD",
	funds: "32,101.53",
	available: "32,101.53",
	balance: "32,101.53"
}, {
	name: "",
	number: "684-2345-111",
	currency: "SGD",
	funds: "6,130.00",
	available: "6,130.00",
	balance: "6,130.00"
}, {
	name: "",
	number: "334-3566-122",
	currency: "AUD",
	funds: "8,456.31",
	available: "8,456.31",
	balance: "8,456.31"
}, {
	name: "",
	number: "888-3354-355",
	currency: "HKD",
	funds: "17,257.91",
	available: "17,257.91",
	balance: "17,257.91"
}];

/**********************************************************************
SEARCH GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [{
	id: "depositnum",
	name: "Deposit Number",
	field: "depositnum",
	toolTip: "Click to sort by Deposit Number",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "depositdate",
	name: "Deposit Date",
	field: "depositdate",
	toolTip: "Click to sort by Deposit Date",
	width: 160,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "principlebalance",
	name: "Principle Amount",
	field: "principlebalance",
	toolTip: "Click to sort by Principle Amount",
	width: 140,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	cssClass: "num pos",
	headerCssClass: "righted",
	visible: true
}, {
	id: "ccy",
	name: "Currency",
	field: "ccy",
	toolTip: "Click to sort by Currency",
	width: 100,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "maturitydate",
	name: "Maturity Date",
	field: "maturitydate",
	toolTip: "Click to sort by Maturity Date",
	width: 160,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "maturitybalance",
	name: "Maturity Amount",
	field: "maturitybalance",
	toolTip: "Click to sort by Maturity Amount",
	width: 160,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	cssClass: "num pos",
	headerCssClass: "righted",
	visible: true
}, {
	id: "company",
	name: "Company",
	field: "company",
	toolTip: "Click to sort by Company",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "status",
	name: "Status",
	field: "status",
	sortable: true,
	sorter: "sorterStringCompare",
	toolTip: "Click to sort by Status",
	width: 160,
	visible: true
}, {
	id: "intrate",
	name: "Interest Rate",
	field: "intrate",
	sortable: true,
	sorter: "sorterNumeric",
	toolTip: "Click to sort by Interest Rate",
	width: 160,
	cssClass: "num pos",
	headerCssClass: "righted",
	visible: true
}, {
	id: "bankname",
	name: "Bank",
	field: "bankname",
	toolTip: "Click to sort by Bank",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('depositSearchOrder')) {
	columns = store.get('depositSearchOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "principlebalance" || columns[i].id == "maturitybalance") {
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if (store.get('depositSearchWidths')) {
	var setWidth = store.get('depositSearchWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
function myFilter(item, args) {
	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
for (var i = 0; i < 100; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	d["depositdate"] = smartDates('randompast');
	d["maturitydate"] = smartDates('randomfuture');
	if (i % 3 == 0) {
		d["company"] = "Consulting Pte. Ltd.";
		d["ccy"] = "SGD";
		d["bankname"] = "ANZ Singapore";
		d["status"] = "Outstanding";
		if (i < 65) {
			d["depositnum"] = "501635560";
			d["principlebalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["maturitybalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["intrate"] = 3.0293;
		} else {
			d["depositnum"] = "827515111";
			d["principlebalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["maturitybalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["intrate"] = 2.5293;
		};
	} else {
		d["company"] = "Manufacturing Inc.";
		d["ccy"] = "AUD";
		d["bankname"] = "ANZ Australia";
		d["status"] = "Outstanding";
		if (i < 65) {
			d["depositnum"] = "501635560";
			d["principlebalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["maturitybalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["intrate"] = 3.0293;
		} else {
			d["depositnum"] = "827515111";
			d["principlebalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["maturitybalance"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
			d["intrate"] = 2.5293;
		};
	};
}


/**********************************************************************
SEARCH INDICATOR SETUP
**********************************************************************/
function indicatorSelection() {
	var alphaIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "~", "Contains"],
		numIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "&gt;", "Greater Than", "&lt;", "Less Than", "&hArr;", "Between"],
		dateIndicatores = ["=", "Specific Date", "&hArr;", "Date Range", "Rd", "Rolling Dates"];
	var $indicatorMenu, whichArray, indicator, mainInput, fromInput, toInput, rollingInput, hiddenInput;
	var sibs;

	function init() {
		$indicatorMenu = $("<div class='indicator-menu' style='display:none;position:absolute;' />").appendTo(document.body);
		$indicatorMenu.bind("click", setIndicator);
		setupIndicators();
	}

	function setupIndicators() {
		var $indicatorItem;
		$("#transactionSearch .indicator").bind("click", function(e) {
			e.stopPropagation();
			if ($indicatorMenu.is(":visible") && $indicatorMenu.attr("id") == $(this).attr("id") + "m") {
				$indicatorMenu.empty().hide();
				return;
			}
			$indicatorMenu.empty();
			indicator = $(this);
			sibs = $(this).siblings("input").not("input[type='hidden']");
			mainInput = $(this).next("input");
			fromInput = mainInput.next("input");
			toInput = fromInput.next("input");
			rollingInput = toInput.next("input");
			hiddenInput = $(this).siblings("input[type='hidden']");
			$indicatorMenu.attr("id", indicator.attr("id") + "m");
			whichArray = alphaIndicators;
			if ($(this).hasClass("num")) whichArray = numIndicators;
			if ($(this).hasClass("date")) whichArray = dateIndicatores;
			for (var i = 0; i < whichArray.length; i++) {
				$indicatorItem = $("<div />").attr("id", i).html("<strong id=" + i + ">" + whichArray[i] + "</strong> " + whichArray[i + 1]).appendTo($indicatorMenu);
				i = i + 1;
			}
			var pleft = $(this).offset().left;
			var ptop = $(this).offset().top + 21;
			$indicatorMenu.css("top", ptop).css("left", pleft).show();
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").children(".on").removeClass("on");
			$("body").one("click", function() {
				$indicatorMenu.empty().hide();
			});
			$(document).on("keyup.hideIndicator", function(e) {
				if (e.keyCode == 27) {
					$indicatorMenu.empty().hide();
					$(document).off("keyup.hideIndicator");
				}
			});
		});
	}

	function setIndicator(e) {
		var indset = whichArray[parseInt(e.target.id)];
		var hidset = whichArray[parseInt(e.target.id) + 1];
		indicator.html(indset).attr("title", hidset);
		hiddenInput.val(hidset);
		if (hidset == "Date Range" || hidset == "Between") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.removeClass("display-none").prop("disabled", "").focus();
			toInput.removeClass("display-none").prop("disabled", "");
		}
		if (hidset == "Rolling Dates") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.removeClass("display-none").prop("disabled", "").focus().click();
		}
		if (hidset != "Date Range" && hidset != "Rolling Dates" && hidset != "Between") {
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			mainInput.removeClass("display-none").prop("disabled", "").focus();
		}
	}
	init();
}

/**********************************************************************
SAVED SEARCHES
**********************************************************************/
var saved_searches = [{
		name: "Debits Above USD $10000",
		id: "asdf3"
	}, {
		name: "Deposit Search XYZ",
		id: "sdf23"
	}, {
		name: "Deposits ABC",
		id: "hgj56"
	}],
	searches_updated = false,
	searches_deleted = false,
	$search_message = $("<p>Use the saved search feature to save frequent searches and quickly recall them.</p>");
if (store.get('saved_deposit_searches')) {
	saved_searches = store.get('saved_deposit_searches')
};
function searchChecker(val) {
	var _search = val,
		error = false,
		$searchList = $(".search-list").children("li"),
		existingSearches = [];
	for (var i = 0; i < $searchList.length; i++) {
		existingSearches.push($searchList.eq(i).attr("data-search"));
	}
	if ($.inArray(_search, existingSearches != -1)) {
		error = "existing"
	}
	return error;
}
function renameSearch(el) {
	var newSearchName = $.trim(el.val());
	if (newSearchName == '' || newSearchName == "undefined") {
		el.val(el.attr("data-search-name"));
	} else {
		el.val(newSearchName);
		el.closest("li").attr("data-search", newSearchName);
		searches_updated = true;
	}
}
function deleteSearch(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function() {
		if (!$target.hasClass('new')) {
			searches_deleted = true;
		}
		$target.remove();
		$(".folder-list").sortable("refresh");
		searches_updated = true;
		if (!$(".folder-list").children("li").size()) {
			$(".search-instructions").remove();
			$search_message.appendTo(".folder-settings");
		}
	});
}
function populateSearches() {
	var $savedSearches = $(".saved-searches"),
		searchCount = saved_searches.length,
		activeSearch = $savedSearches.children("li.active") ? $savedSearches.children("li.active").attr("data-search-id") : false;
	$savedSearches.children().remove();
	if (searchCount > 0) {
		var $li, $a
		$savedSearches.each(function() {
			var _this = $(this);
			if (_this.parents().attr("id") == "viewMenu") {
				$.each(saved_searches, function() {
					$li = $("<li data-search='" + this.name + "' data-search-id='" + this.id + "' />").appendTo(_this);
					if (this.id == activeSearch) {
						$li.addClass("active");
						$("#searchMenuControl").children("a").children("span").html(this.name);
					}
					$a = $("<a href='javascript:void(0)' title='" + this.name + "' data-search='" + this.name + "' data-search-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
						e.preventDefault();
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.saved-searches"),
			$li = $("<li class='no-set' />").appendTo($viewMenu),
			$a = $("<div >You have no saved searches</div>").appendTo($li);
	}
}
function populateSearchManager() {
	searches_updated = false;
	searches_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
		$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({
			handle: '.reorder-folder',
			axis: 'y',
			tolerance: "pointer",
			update: function(event, ui) {
				searches_updated = true
			}
		}),
		folderCount = saved_searches.length,
		$li, $div, $span, $input, $remove, $view, $error;
	if (folderCount > 0) {
		$folderAddLine = $("<p class='search-instructions'>Reorder, rename, run or remove your saved searches.</p>").insertBefore($folderList),
			$.each(saved_searches, function() {
				$li = $("<li data-search='" + this.name + "' data-search-id='" + this.id + "' class='row' />").appendTo($folderList);
				$div = $("<div class='folder-row data-column' />").appendTo($li);
				$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
				$input = $("<input type='text' maxlength='25' value='" + this.name + "' data-search-name='" + this.name + "' />").on("change", function() {
					renameSearch($(this));
				}).appendTo($div);
				$view = $("<a href='javascript:void(0)' class='view-folder'><i class='fa fa-search fa-fw'></i></a>").appendTo($div);
				$remove = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteSearch).appendTo($div);
				$error = $("<div class='data-error'>A saved search with this name already exists</div>").appendTo($div);
			});
	} else {
		$search_message.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showSearchManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Saved Searches",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function() {
			return populateSearchManager()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateSearches(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveSearches(dialog) {
	var $dialog = $("#" + dialog.id),
		$active = $("#viewMenu").children(".saved-searches").find("li.active").attr("data-search-id");
	$dialog.addClass("working");
	saved_searches = searches_updated;

	var active_deleted = true;

	for (f = 0; f < saved_searches.length; f++) {
		if ($active == saved_searches[f].id) {
			active_deleted = false;
			break;
		}
	}

	searches_updated = false;
	searches_deleted = false;
	store.set('saved_deposit_searches', saved_searches);
	setTimeout(function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateSearches();
		if (!saved_searches.length || active_deleted) {
			$("#_noSearch").trigger("click");
		}
		dialogHider(dialog);
	}, 300);
}
function updateSearches(dialog) {
	if (searches_updated) {
		searches_updated = [];
		var duplicate_names = false,
			$searchList = $(".folder-list");
		$searchList.find("li.error").removeClass("error");
		$searchList.children("li").each(function() {
			searches_updated.push({
				"name": $(this).attr("data-search"),
				"id": $(this).attr("data-search-id")
			});
			var _name = $(this).attr("data-search");
			$(this).siblings().each(function() {
				if ($(this).attr("data-search") == _name) {
					$(this).addClass("error");
				}
			});
		});
		if ($searchList.find("li.error").size()) {
			duplicate_names = true;
		}
		if (duplicate_names) {
			return false;
		} else {
			var save_searches = false;
			if (saved_searches.length != searches_updated.length) {
				save_searches = true;
			} else {
				for (var i = 0; i < saved_searches.length; i++) {
					if (saved_searches[i].name != searches_updated[i].name || saved_searches[i].id != searches_updated[i].id) {
						save_searches = true;
						break;
					}
				}
			}
			if (save_searches || searches_deleted) {
				if (searches_deleted) {
					buildConfirmDialog("You've deleted some saved searches.", "Are you sure you want to continue?", function() {
						saveSearches(dialog)
					});
				} else {
					saveSearches(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}

/**********************************************************************
SEARCH FIELD TOGGLE
**********************************************************************/
var search_height = 0;
var inMotion = false;
function showSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	$this.attr("show", "true").addClass("btn-on");
	$i.removeClass("fa-search-plus").addClass("fa-search-minus");
	$(".search-fields").removeClass("slide-up");
	$(".scroll-area").removeClass("full-height");
	$(".basic-search").css("overflow", "hidden");
	inMotion = setTimeout(function() {
		$(".basic-search").css("overflow", "visible");
		grid.resizeCanvas();
		inMotion = false;
	}, 300);
}
function hideSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	if (inMotion) clearTimeout(inMotion);
	$i.removeClass("fa-search-minus").addClass("fa-search-plus");
	$this.attr("show", "false").removeClass("btn-on");
	$(".search-fields").css("overflow", "hidden").addClass("slide-up");
	$(".scroll-area").addClass("full-height");
	setTimeout(function() {
		grid.resizeCanvas();
	}, 300);
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {

	/**********************************************************************
	INITIALIZE SEARCH GRID
	**********************************************************************/
	var GroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		GroupItemMetadataProvider: GroupItemMetadataProvider
	});
	grid = new Slick.Grid("#searchGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(GroupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'depositSearchOrder', 'depositSearchWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			$cmenu = $("#contextMenu")
		};
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if(selectedRowIds.length > 0) {
			$("#transactionSearchPanel .bottom-controls").removeClass("hidden");
			$("#transactionSearchPanel .gutter-30").addClass("has-bottom-controls");
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#transactionSearchPanel .bottom-controls").addClass("hidden");
			$("#transactionSearchPanel .gutter-30").removeClass("has-bottom-controls");
			$("#selectedCount").html('');
		}
		grid.resizeCanvas();
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-toggle': 'show-modal',
				'href': '#transactionDetail'
			}).trigger('click.show-modal');
			$row.removeAttr("data-toggle href");
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('depositSearchWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('depositSearchOrder')) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('depositSearchOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleColumns);
	}
	grid.setHeaderRowVisibility(false);

	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});

	/**********************************************************************
	SAVED SEARCH EVENTS
	**********************************************************************/
	$(".manage-searches").on("click", showSearchManagerDialog);
	populateSearches();

	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		}
	});

	/**********************************************************************
	SEARCH FIELDS
	**********************************************************************/
	$("#show-hide-search").on("click", function(e) {
		e.preventDefault();
		var $this = $(this);
		if ($this.attr("show") == "false") {
			showSearchFields();
		} else {
			hideSearchFields();
		}
	});

	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);

	/**********************************************************************
	SETTINGS MENU
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault()
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text()
		groupBy(item, text)
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});

	/**********************************************************************
	INITIALIZE SEARCH INDICATORS
	**********************************************************************/
	indicatorSelection();

	/**********************************************************************
	SETUP THE DATE FUNCTIONS
	**********************************************************************/
	var rollingDates = ["Today", "Yesterday", "Week to Date", "Previous Week", "Month to Date", "Previous Month"];
	$("#postingdaterolling,  #valuedaterolling").bind("keydown", function(e) {
		if (e.keyCode == "9") {
			e.stopImmediatePropagation();
		}
	});
	$("#postingdaterolling, #valuedaterolling").autocomplete({
		source: rollingDates,
		autoFocus: false,
		delay: 0,
		minLength: 0,
		focus: function(e, ui) {
			return false;
		},
		change: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(rollingDates, function() {
				if (this.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this;
					return false;
				}
			});
			$(this).val(matchie);
			if (!valid) {
				$(this).val("");
				return false;
			}
		}
	});
	$("#postingdaterolling, #valuedaterolling").bind("click focus", function() {
		$(this).autocomplete("search", "");
	});
	var postingdate = $("#postingdate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});
	var valuedate = $("#valuedate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});
	var postingdates = $("#postingdatefrom, #postingdateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			var option = this.id == "postingdatefrom" ? "minDate" : "maxDate",
				instance = $(this).data("datepicker"),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings);
			postingdates.not(this).datepicker("option", option, date);
		}
	});
	var valuedates = $("#valuedatefrom, #valuedateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			var option = this.id == "valuedatefrom" ? "minDate" : "maxDate",
				instance = $(this).data("datepicker"),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings);
			valuedates.not(this).datepicker("option", option, date);
		}
	});

	/**********************************************************************
	SELECTIZE FIELDS
	**********************************************************************/
	var selectize_options = {
		plugins: ['remove_button'],
		maxItems: null,
		valueField: 'number',
		labelField: 'name',
		searchField: ['number', 'name'],
		options: DEPOSITS,
		render: {
			item: function(item, escape) {
				return '<div>' +
					(item.number ? '<span style="font-weight:bold;">' + escape(item.number) + '</span>' : '') +
					'</div>';
			},
			option: function(item, escape) {
				var label = item.number;
				return '<div>' +
					'<div class="label" >' + escape(label) + '</div>' +
					'</div>';
			}
		},
		onItemAdd: function(value, $item) {
			this.$control_input.blur().focus();
			this.$control_input.focus();
		},
		onItemRemove: function(value) {},
		onDropdownOpen: function($dropdown, value) {
			if (!this.$control_input.val().length) this.close();
		},
		load: function(query, callback) {},
		persist: false,
		addPrecedence: true,
		openOnFocus: false,
		closeAfterSelect: true,
		create: "false"
	};
	$('.account-search').selectize(selectize_options);


	/**********************************************************************
	SEARCH / RESET BUTTONS
	**********************************************************************/
	$(".start-search").click(function(e) {
		e.preventDefault();
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			hideSearchFields();
			$("#noSearch").hide();
			$("#searchGrid").removeClass("hidden");
		}, 1000);
	});
	$(".resetSearch").click(function(e) {
		e.preventDefault();
		grid.setSelectedRows([]);
		$("#searchGrid").addClass("hidden");
		$("#noSearch").show();
	});



	/**********************************************************************
	ADD / REMOVE ITEM MODAL
	**********************************************************************/
	function showAddAccounts(_target) {

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
			if ($("input[name=_addAccount]:checked").length > 0) {
				for (var i = 0; i < accounts.length; i++) {
					for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
						if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
							//_data.push( accounts[i] );
							$(".account-search")[0].selectize.addItem(accounts[i].number)
						}
					}
				}
				dialogHider(_dialog);
				//buildFavouriteAccounts(_id,true);
				//store.set('saved_widget_data', widgetDataArray);
				//
			} else {
				dialogHider(_dialog);
			}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

			/* build the account filter input */
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a deposit...' />").on("keyup", function() {
				if (this.value != '') {
					$("#clearAccountsFilter").show()
				} else {
					$("#clearAccountsFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#AddAccountsFilterInput").val("").trigger("change");
				$(this).hide();
			}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
			$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='_selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=_addAccount]:visible");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
			$numberHeader = $("<div class='fav-header-col' style='width: 330px;'>Deposit Number</div>").appendTo($header),
			$currencyHeader = $("<div class='fav-header-col' style='width: 270px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
			$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
			$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

			/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
			var _alreadyAdded = false;

			if (!_alreadyAdded) {
				$li = $("<li>").appendTo($ul),
					$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
						var $target = $(e.target);
						if ($target.prop("nodeName") == "DIV") {
							if ($target.hasClass("fav-data-col")) {
								$target = $target.closest("div.fav-row");
							}
							$target = $target.find("input[name='_addAccount']");
							var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
						}
						if (!$(this).prop("checked")) {
							$("input[name='_selectAll']").prop("checked", false)
						}
						if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
							$("input[name='_selectAll']").prop("checked", true)
						}
					}),
					$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
				var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount'/>").appendTo($checkDiv).on("change", function() {
						var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
					}),
					$number = $("<div class='fav-data-col' style='width: 330px;'>" + this.number + "</div>").appendTo($row),
					$currency = $("<div class='fav-data-col' style='width: 270px;'>" + this.currency + "</div>").appendTo($row)

				if ($.inArray(this.number, $(".account-search")[0].selectize.items) > -1) {
					//$checkInput.attr("checked", true); 
					//$row.addClass("selected"); 
					$li.remove();
				}
			}
		});

		/* build and show the add deposits dialog */
		var _origin = _target;
		var _dialog = {
			id: "AddAccounts",
			title: "Add Deposits",
			size: "medium",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Add",
				icon: "<i class='fa fa-plus fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						saveSelectedAccounts(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
			var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no deposits to show</div>").appendTo($dataContainer);
		}
	}
	$(".account-search-column label>i").click(function() {
		showAddAccounts($(this))
	});

});