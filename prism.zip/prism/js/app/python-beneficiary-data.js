/* BENEFICIARIES */
/* used by the beneficiary account generator */
var _beneficiaries = [{
	id: randString(20),
	beneid: "OPBEN01",
	name: "Simple Delights",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary1@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN02",
	name: "European Car Association of Melbourne",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary2@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN03",
	name: "King Corporate Training",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary3@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN04",
	name: "Near And Far Transport Inc.",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary4@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN05",
	name: "Bear Logistics Services",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary5@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN06",
	name: "Specialist Data Analysis Centre Of New Zealand",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary6@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN07",
	name: "20/20 Financial Services",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary7@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN08",
	name: "The Hawthorne Group",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary8@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN09",
	name: "K-Media Creative Services",
	localname: "",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary9@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN10",
	name: "Flow Water Incorporated",
	localname: "",
	address1: "#10-01 Mapletree Business City",
	address2: "20 Pasir Panjang Road",
	address3: "",
	postal: "117439",
	country: "China",
	city: "Beijijng",
	email: "beneficiary10@opee.prototype.com",
	phone: "+65 5555 5555",
	fax: "+65 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN11",
	name: "Shin Low Trading Inc.",
	localname: "",
	address1: "#10-01 Mapletree Business City",
	address2: "20 Pasir Panjang Road",
	address3: "",
	postal: "117439",
	country: "China",
	city: "Beijijng",
	email: "beneficiary11@opee.prototype.com",
	phone: "+65 5555 5555",
	fax: "+65 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN12",
	name: "White Lotus Holdings",
	localname: "",
	address1: "#10-01 Mapletree Business City",
	address2: "20 Pasir Panjang Road",
	address3: "",
	postal: "117439",
	country: "China",
	city: "Beijijng",
	email: "beneficiary12@opee.prototype.com",
	phone: "+65 5555 5555",
	fax: "+65 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN13",
	name: "Shield Incorporated",
	localname: "",
	address1: "600 Bourke Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary13@opee.prototype.com",
	phone: "+61 3 5555 5555",
	fax: "+61 3 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN14",
	name: "Wallaby Services Pte. Ltd.",
	localname: "",
	address1: "600 Bourke Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary14@opee.prototype.com",
	phone: "+61 3 5555 5555",
	fax: "+61 3 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN15",
	name: "Omolon Technologies LLC.",
	localname: "",
	address1: "600 Bourke Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary15@opee.prototype.com",
	phone: "+61 3 5555 5555",
	fax: "+61 3 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN16",
	name: "Emilio Carloti Imports & Exports",
	localname: "",
	address1: "600 Bourke Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary15@opee.prototype.com",
	phone: "+61 3 5555 5555",
	fax: "+61 3 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN17",
	name: "Farm To Table Inc.",
	localname: "",
	address1: "600 Bourke Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary15@opee.prototype.com",
	phone: "+61 3 5555 5555",
	fax: "+61 3 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN18",
	name: "CBGB Global Enterprises",
	localname: "",
	address1: "#10-01 Mapletree Business City",
	address2: "20 Pasir Panjang Road",
	address3: "",
	postal: "117439",
	country: "China",
	city: "Beijijng",
	email: "beneficiary15@opee.prototype.com",
	phone: "+65 5555 5555",
	fax: "+65 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN19",
	name: "Guardian Suppliers",
	localname: "卫供应商",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary19@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}, {
	id: randString(20),
	beneid: "OPBEN20",
	name: "Manufacturing Enterprises China",
	localname: "制造企业中国",
	address1: "Level 10/15",
	address2: "One Queen Street",
	address3: "",
	postal: "3000",
	country: "Australia",
	city: "Melbourne",
	email: "beneficiary20@opee.prototype.com",
	phone: "+86 20 5555 5555",
	fax: "+86 20 5555 5555",
	aliases: [],
	nickname: "Nickname Here"
}];

/* LOCAL CLEARING BANKS */
/* used by the beneficiary account generator */
var _beneficiary_local_banks = [{
	id: "OPBBANK01",
	name: "WESTPAC",
	localname: "",
	branch: "Queen Street Branch",
	address1: "Westpac Tower",
	address2: "488 Queen Street",
	address3: "Auckland",
	postal: "",
	city: "Auckland",
	country: "New Zealand",
	clearing: [{
		type: "BSB",
		code: "030-253"
	}]
}, {
	id: "OPBBANK02",
	name: "BANK OF NEW ZEALAND",
	localname: "",
	branch: "The Cooperative Bank 2",
	address1: "C/-BNZ Business Centre",
	address2: "L5 Harbour Quay",
	address3: "60 Waterloo Quay",
	postal: "",
	city: "Wellington",
	country: "New Zealand",
	clearing: [{
		type: "BSB",
		code: "021-246"
	}]
}, {
	id: "OPBBANK03",
	name: "BANK OF MELBOURNE",
	localname: "",
	branch: "Payments Branch",
	address1: "Level 8",
	address2: "530 Collins Street",
	address3: "",
	postal: "3000",
	city: "Melbourne",
	country: "Australia",
	clearing: [{
		type: "BSB",
		code: "193-911"
	}]
}, {
	id: "OPBBANK04",
	name: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	localname: "英国渣打银行有限责任公司上海分行",
	branch: "Shanghai Branch",
	address1: "Unit 1077/1079/108",
	address2: "No. 1018, Chang Ning Road",
	address3: "Shanghai",
	postal: "200042",
	city: "Shanghai",
	country: "China",
	clearing: [{
		type: "CNAPS",
		code: "671290000017"
	}]
}, {
	id: "OPBBANK05",
	name: "CITIBANK (CHINA) CO., LTD.",
	localname: "美国花旗银行有限公司北京分行",
	branch: "Beijing Branch",
	address1: "Floor 18, Citic International Building",
	address2: "19 Jianguomenwai Da Jie",
	address3: "Beijing",
	postal: "100004",
	country: "China",
	city: "Beijing",
	clearing: [{
		type: "CNAPS",
		code: "531100000018"
	}]
}, {
	id: "OPBBANK06",
	name: "COMMONWEALTH BANK",
	localname: "",
	branch: "Commonwealth Bank",
	address1: "367 Collins Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	city: "Melbourne",
	country: "Australia",
	clearing: [{
		type: "BSB",
		code: "063-032"
	}]
}, {
	id: "OPBBANK07",
	name: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	localname: "",
	branch: "ANZ Banking Group Limited",
	address1: "Level 12, 530 Collins Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	city: "Melbourne",
	country: "Australia",
	clearing: [{
		type: "BSB",
		code: "013-988"
	}]
}, {
	id: "OPBBANK08",
	name: "DBS BANK LTD SINGAPORE",
	localname: "",
	branch: "DBS Shenton Way",
	address1: "MBFC Tower 3",
	address2: "12 Marina Boulevard",
	address3: "",
	postal: "018982",
	city: "Singapore",
	country: "Singapore",
	clearing: [{
		type: "SWIFT",
		code: "DBSSSGSG"
	}]
}, {
	id: "OPBBANK09",
	name: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	localname: "",
	branch: "Ocean Financial Centre",
	address1: "Ocean Financial Centre",
	address2: "10 Collyer Quay",
	address3: "30-00",
	postal: "049315",
	city: "Singapore",
	country: "Singapore",
	clearing: [{
		type: "SWIFT",
		code: "ANZBSGSX"
	}]
}, {
	id: "OPBBANK10",
	name: "Deutsche Bank AG",
	localname: "",
	branch: "Kownloon Branch",
	address1: "1 Austin Road West",
	address2: "Level 52, International Commerce Centre",
	address3: "Kowloon",
	postal: "",
	city: "Hong Kong",
	country: "Hong Kong",
	clearing: [{
		type: "China National Clearing Code",
		code: "CN989584005403"
	}]
}];

/* SWIFT BANKS */
/* used by the beneficiary account generator */
var _beneficiary_swift_banks = [{
	id: "OPBBANK01",
	name: "WESTPAC",
	localname: "",
	branch: "Queen Street Branch",
	address1: "Westpac Tower",
	address2: "488 Queen Street",
	address3: "Auckland",
	postal: "",
	country: "New Zealand",
	swift: "COOKNZ2A",
	city: "Auckland"
}, {
	id: "OPBBANK02",
	name: "BANK OF NEW ZEALAND",
	localname: "",
	branch: "The Cooperative Bank 2",
	address1: "C/-BNZ Business Centre",
	address2: "L5 Harbour Quay",
	address3: "60 Waterloo Quay",
	postal: "",
	country: "New Zealand",
	swift: "BKNZN222500",
	city: "Wellington"
}, {
	id: "OPBBANK03",
	name: "BANK OF MELBOURNE",
	localname: "",
	branch: "Payments Branch",
	address1: "Level 8",
	address2: "530 Collins Street",
	address3: "",
	postal: "3000",
	swift: "BNKMDL2123",
	city: "Melbourne"
}, {
	id: "OPBBANK04",
	name: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	localname: "英国渣打银行有限责任公司上海分行",
	branch: "Shanghai Branch",
	address1: "Unit 1077/1079/108",
	address2: "No. 1018, Chang Ning Road",
	address3: "Shanghai",
	postal: "200042",
	country: "China",
	swift: "SCBLCNSXSHA",
	city: "Shanghai"
}, {
	id: "OPBBANK05",
	name: "CITIBANK (CHINA) CO., LTD.",
	localname: "美国花旗银行有限公司北京分行",
	branch: "Beijing Branch",
	address1: "Floor 18, Citic International Building",
	address2: "19 Jianguomenwai Da Jie",
	address3: "Beijing",
	postal: "100004",
	country: "China",
	swift: "CITICNSXBJG",
	city: "Beijing"
}, {
	id: "OPBBANK06",
	name: "COMMONWEALTH BANK",
	localname: "",
	branch: "Commonwealth Bank",
	address1: "367 Collins Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	swift: "CTBAAU2S",
	city: "Melbourne"
}, {
	id: "OPBBANK07",
	name: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	localname: "",
	branch: "ANZ Banking Group Limited",
	address1: "Level 12, 530 Collins Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	country: "Australia",
	swift: "ANZBAU3M",
	city: "Melbourne"
}, {
	id: "OPBBANK08",
	name: "DBS BANK LTD SINGAPORE",
	localname: "",
	branch: "DBS Shenton Way",
	address1: "MBFC Tower 3",
	address2: "12 Marina Boulevard",
	address3: "",
	postal: "018982",
	country: "Singapore",
	swift: "DBSSSGSG",
	city: "Singapore"
}, {
	id: "OPBBANK09",
	name: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	localname: "",
	branch: "Ocean Financial Centre",
	address1: "Ocean Financial Centre",
	address2: "10 Collyer Quay",
	address3: "30-00",
	postal: "049315",
	country: "Singapore",
	swift: "ANZBSGSX",
	city: "Singapore"
}, {
	id: "OPBBANK10",
	name: "Deutsche Bank AG",
	localname: "",
	branch: "Kownloon Branch",
	address1: "1 Austin Road West",
	address2: "Kowloon",
	address3: "",
	postal: "",
	city: "Hong Kong",
	country: "Hong Kong",
	swift: "DEUTHKHHXXX"
}];

/* BENEFICIARY ACCOUNT CURRENCIES */
/* used by the beneficiary account generator */
var _beneficiary_account_currencies = [{
	country: "Australia",
	code: "AUD",
	currency: "Australian Dollar"
}, {
	country: "China",
	code: "CNY",
	currency: "Chinese Yuan"
}, {
	country: "Singapore",
	code: "SGD",
	currency: "Singapore Dollar"
}, {
	country: "Hong Kong",
	code: "HKD",
	currency: "Hong Kong Dollar"
}, {
	country: "New Zealand",
	code: "NZD",
	currency: "New Zealand Dollar"
}];

/* BENEFICIARY STATUS WORKFLOW */
/* used by the beneficiary account generator */
var _beneficiary_workflow = [{
	status: "New",
	workflow: "Pending Approval - New",
}, {
	status: "New",
	workflow: "Creation Rejected"
}, {
	status: "Active",
	workflow: "Approved"
}, {
	status: "Active",
	workflow: "Pending Approval - Modified"
}, {
	status: "Active",
	workflow: "Pending Approval - Deleted"
}, {
	status: "Active",
	workflow: "Changes Rejected"
}, {
	status: "Active",
	workflow: "Deletion Rejected"
}, {
	status: "Deleted",
	workflow: "Approved"
}];

/* BENEFICIARY TYPES */
/* used by the beneficiary account generator */
var _beneficiary_types = ["Resident Corporate", "Non-Resident Corporate", "Resident Individual", "Non-Resident Individual"];

/* BENEFICIARY ACCOUNTS */
/* the array that holds beneficiary accounts */
/* the beneficiary account generator function */
/* generate beneficiary accounts or use stored values */

var _tbos_beneficiary_accounts = [];

function generateBeneficiaryAccounts() {
	var b = {};
	var bene = _beneficiaries[rand(0, _beneficiaries.length - 1)];
	var localbank = _beneficiary_local_banks[rand(0, _beneficiary_local_banks.length - 1)];
	var swiftbank;
	for (var i = 0; i < _beneficiary_swift_banks.length; i++) {
		if (_beneficiary_swift_banks[i].id == localbank.id) {
			swiftbank = _beneficiary_swift_banks[i];
			break;
		}
	}
	var currency;
	for (var i = 0; i < _beneficiary_account_currencies.length; i++) {
		if (_beneficiary_account_currencies[i].country == localbank.country) {
			currency = _beneficiary_account_currencies[i];
			break;
		}
	}
	var benetype = (bene.country == localbank.country) ? "Resident Individual" : "Non-Resident Individual";
	var status = _beneficiary_workflow[rand(0, _beneficiary_workflow.length - 1)];
	b["id"] = randString(10);
	b["beneid"] = randString(6);
	b["benename"] = bene.name;
	b["benelocalname"] = bene.localname;
	b["benenickname"] = bene.nickname;
	b["benetype"] = benetype;
	b["beneaccount"] = randNumber(10);
	b["beneaccountccy"] = currency.code;
	b["beneaddress1"] = bene.address1;
	b["beneaddress2"] = bene.address2;
	b["beneaddress3"] = bene.address3;
	b["benecity"] = bene.city;
	b["benepostal"] = bene.postal;
	b["benecountry"] = bene.country;
	b["benephone"] = bene.phone;
	b["benefax"] = bene.fax;
	b["beneemail"] = bene.email;
	b["benebank"] = localbank.name;
	b["benebanklocalname"] = localbank.localname;
	b["benebankbranch"] = localbank.branch;
	b["benebankaddress1"] = localbank.address1;
	b["benebankaddress2"] = localbank.address2;
	b["benebankaddress3"] = localbank.address3;
	b["benebankpostal"] = localbank.postal;
	b["benebankcity"] = localbank.city;
	b["benebankcountry"] = localbank.country;
	b["benebankclearingtype"] = localbank.clearing[0].type;
	b["benebankclearingcode"] = localbank.clearing[0].code;
	b["swiftbank"] = swiftbank.name;
	b["swiftbanklocalname"] = swiftbank.localname;
	b["swiftbranch"] = swiftbank.branch;
	b["swiftbankaddress1"] = swiftbank.address1;
	b["swiftbankaddress2"] = swiftbank.address2;
	b["swiftbankaddress3"] = swiftbank.address3;
	b["swiftbankpostal"] = swiftbank.postal;
	b["swiftbankcity"] = swiftbank.city;
	b["swiftbankcountry"] = swiftbank.country;
	b["swiftcode"] = swiftbank.swift;
	b["benestatus"] = status.status;
	b["beneworkflow"] = status.workflow;
	b["benedivision"] = "Customer Division";
	b["entrymethod"] = "Online"
	b["folder"] = "None";
	b["folderid"] = "None";
	b["audit"] = [];
	b["enteredby"] = "Test User 1";
	b["enteredon"] = smartDates("randompast") + " at " + timeFormatter();
	b["lastupdateby"] = "Test User 1";
	b["lastupdate"] = smartDates("yesterday") + " at " + timeFormatter();
	b["approvedby"] = "Test User 2";
	b["approvedon"] = smartDates("today") + " at " + timeFormatter();
	b["rejectedby"] = "Test User 2";
	b["rejectedon"] = smartDates("today") + " at " + timeFormatter();
	b["deletedby"] = "Test User 1";
	b["deletedon"] = smartDates("today") + " at " + timeFormatter();
	return b;
}

if (store.get("_stored_tbos_beneficiary_accounts")) {
	_tbos_beneficiary_accounts = store.get("_stored_tbos_beneficiary_accounts");
} else {
	for (var i = 0; i < 50; i++) {
		_tbos_beneficiary_accounts[i] = generateBeneficiaryAccounts();
	}
	store.set("_stored_tbos_beneficiary_accounts", _tbos_beneficiary_accounts);
}