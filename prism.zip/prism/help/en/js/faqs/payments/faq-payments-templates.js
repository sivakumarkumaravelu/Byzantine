/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Payments Onscreen Guide",
	action: "slider"
}, {
	title: "Can I create a template from a payment?",
	faq: "<p>You can create a new template from an existing payment only if it is in one of the following statuses:<br /> &gt; Pending Approval<br /> &gt; Approver Rejected<br /> &gt; Approved<br /> &gt; Processing<br /> &gt; Future Dated<br /> &gt; Insufficient Funds<br /> &gt; Bank Rejected<br /> &gt; Completed</p>"
}, {
	title: "Do beneficiaries need to be in the address book when creating a template?",
	faq: "<p>No, if you have access to create ad-hoc beneficiaries, you can add a new beneficiary to the template when you are creating the template. However the new beneficiary will need to be approved in your Address Book before the template can be approved and made available for use.</p>"
}, {
	title: "Do all templates need to be approved?",
	faq: "<p>If your organisation has requested an approval workflow for templates, all templates must be approved before they can be used.</p>"
}, {
	title: "How many approvers are required for templates?",
	faq: "<p>If your organisation has requested an approval workflow for templates, only one approver will be required to approve the request.</p>"
}, {
	title: "Who can create Salary payment templates?",
	faq: "<p>Only users who are entitled to create salary payment templates can manage these templates. To change this permission, your authorised signatory must complete a maintenance form to change your user profile with ANZ.</p>"
}, {
	title: "Can I limit salary entitlements to only payments?",
	faq: "<p>No, if you are entitled to the salary payment type you will be able to create both salary templates and payments. There is no distinction.</p>"
}, {
	title: "Why aren’t there any FX details or Supporting Documents when I create a template?",
	faq: "<p>These are related to the payment and must be filled out when completing the payment details for submission.</p>"
}, {
	title: "Can you upload a Payment File in a template?",
	faq: "<p>No, you can only do this from Create Payments > Use Payment File or Payment File Summary > Upload Payment File.</p>"
}, {
	title: "Why can't I edit a template that is in a Pending Approval status?",
	faq: "<p>Before you can edit a template in a Pending Approval status you must recall the template to take it out of the approval queue.</p>"
}, {
	title: "Why can I still see a template after it has been deleted?",
	faq: "<p>A deleted template will be purged from the system after seven days.</p>"
}];