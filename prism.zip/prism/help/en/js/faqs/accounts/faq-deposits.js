/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Accounts Onscreen Guide",
	action: "slider"
}, {
	title: "How do I download a Deposit Summary Report?",
	faq: "<p>Select one or more deposits &gt; Right-click &gt; Request a Deposit Summary Report.</p><p>The report will be available in the Download screen to view or save.</p>"
}, {
	title: "How do I set a Reference Currency?",
	faq: "<p>To set a Reference Currency for displaying totals on screen;<br />Click on the Action Menu &gt; Set Reference Currency &gt; Select your preferred Currency</p><p>Reports will download in the Reference Currency you have specified in Settings & Preferences.</p>"
}, {
	title: "How do I customise my view of the Deposits screen?",
	faq: "<p>&gt; Sort columns by clicking on a column heading.<br />&gt; Drag and drop columns to order them in your preferred sequence.<br />&gt; Right-click on any column heading to set which columns you would like to appear in this screen.</p>"
}, {
	title: "How do I make this screen my Homepage?",
	faq: "<p>Drop down the Settings &  Preferences menu (displayed as your User Name on the top right of the screen) &gt; select &#39;Set this page as my home page&#39;.</p>"
}];