/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Payments Onscreen Guide",
	action: "slider"
}, {
	title: "Do I have to use the address book for my beneficiary list?",
	faq: "<p>No, you do not have to use the address book. However, you will not be able to create templates and all users will need to be permissioned to use ad-hoc beneficiaries.</p>"
}, {
	title: "Do all beneficiaries need to be approved?",
	faq: "<p>If your organisation has requested an approval workflow for beneficiaries in the Address Book, all beneficiaries added or modified in the Address Book will need to be approved by a single approver before they can be used in a payment or template.</p>"
}, {
	title: "How many approvers are required for beneficiaries?",
	faq: "<p>If your organisation has requested an approval workflow for beneficiaries in the Address Book, only one approver will be required to approve the request.</p>"
}, {
	title: "What is the email address used for when you create a new beneficiary?",
	faq: "<p>The application will use this email address if you request a beneficiary advice be sent to the beneficiary as part of your payment.</p>"
}, {
	title: "Do I need to enter both local clearing information and SWIFT bank information for all beneficiaries in the address book?",
	faq: "<p>In most cases you will only need to enter one set of information. If you plan to make both domestic and international (cross border) payments to the same beneficiary, you should enter both the local clearing information and SWIFT clearing details.</p>"
}, {
	title: "How long do deleted beneficiaries stay in system?",
	faq: "<p>A deleted beneficiary will be purged from the system after seven days.</p>"
}];