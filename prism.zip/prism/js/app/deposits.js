/**********************************************************************
TERM DEPOSITS GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columns = [
	{id:"company", name:"Company", field:"company", toolTip:"Click to sort by Company", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"termdepositnumb", name:"Deposit Number", field:"termdepositnumb", toolTip:"Click to sort by Deposit Number", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"status", name:"Status", field:"status", toolTip:"Click to sort by Status", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"baldate", name:"Balance Date", field:"baldate", toolTip:"Click to sort by Balance Date", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"fxrate", name:"Exchange Rate", field:"fxrate", toolTip:"Click to sort by FX Rate", width: 160, sortable: true, sorter: "sorterNumeric", cssClass: "num", headerCssClass: "righted", visible: true},
	{id:"currency", name:"Currency", field:"currency", toolTip:"Click to sort by Currency", width: 100, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"currbal", name:"Current Balance", field:"currbal", toolTip:"Click to sort by Current Balance", width: 160, sortable:true, sorter: "sorterNumeric", groupTotalsFormatter:sumTotalsFormatter, formatter: Slick.Formatters.AmountFormatter, cssClass: "num pos", headerCssClass: "righted", visible: true},
	{id:"depdate", name:"Deposit Date", field:"depdate", toolTip:"Click to sort by Deposit Date", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"principleamount", name:"Principle Amount", field:"principleamount", toolTip:"Click to sort by Principle Amount", width: 160, sortable: true, sorter: "sorterNumeric", groupTotalsFormatter:sumTotalsFormatter, formatter: Slick.Formatters.AmountFormatter, cssClass: "num pos", headerCssClass: "righted", visible: true},
	{id:"rate", name:"Interest Rate", field:"rate", toolTip:"Click to sort by Interest Rate", width: 160, sortable:true, sorter: "sorterNumeric", cssClass: "num", headerCssClass: "righted", visible: true},
	{id:"matdate", name:"Maturity Date", field:"matdate", toolTip:"Click to sort by Maturity Date", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"matamount", name:"Maturity Amount", field:"matamount", toolTip:"Click to sort by Maturity Amount", width: 160, sortable:true, sorter: "sorterNumeric", groupTotalsFormatter:sumTotalsFormatter, formatter: Slick.Formatters.AmountFormatter, cssClass: "num pos", headerCssClass: "righted", visible: true},
	{id:"country", name:"Country", field:"country", toolTip:"Click to sort by Country", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"bankname", name:"Bank Name", field:"bankname", toolTip:"Click to sort by Bank Name", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true}
];
var columnFilters = {};
if ( store.get('termDepositOrder') ) {
	columns = store.get('termDepositOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "currbal" || columns[i].id == "principleamount" || columns[i].id == "matamount") {
			columns[i].groupTotalsFormatter = sumTotalsFormatter;
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
};
if ( store.get('termDepositWidths') ) {
	var setTermDepositWidth = store.get('termDepositWidths');
	for (var i in setTermDepositWidth) {
		var s = setTermDepositWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
};
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
var groupedSetting = 0, groupCollapseSetting = 0, groupCCYSetting = "USD";
function sumTotalsFormatter(totals, columnDef) {
	return groupCCYSetting + " " + addCommas(Math.round((totals.sum[columnDef.field] * 100)/100).toFixed(2));
}
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);

	dataView.setAggregators([
		new Slick.Data.Aggregators.Sum("matamount"),
		new Slick.Data.Aggregators.Sum("principleamount"),
		new Slick.Data.Aggregators.Sum("currbal")
	], true);

	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var labelString = "", findString = "", statusString= "", findDataPoint = "termdepositnumb";
function myFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}
		
	if (args.statusString != "" && item["status"] != args.statusString) {
		return false;
	}
		
	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function calculateTotals() {
	var totalPrinciple = 0, totalCurrent = 0, totalMaturity = 0;
	for (var i = 0; i < dataView.getLength(); i++) {
		totalPrinciple = parseFloat(totalPrinciple) + parseFloat(dataView.getItem(i).principleamount.replace(',', ''));
		totalCurrent = parseFloat(totalCurrent) + parseFloat(dataView.getItem(i).currbal.replace(',', ''));
		totalMaturity = parseFloat(totalMaturity) + parseFloat(dataView.getItem(i).matamount.replace(',', ''));
	}
	totalPrinciple = addCommas(totalPrinciple.toFixed(2))
	$("[data-value='totalPrinciple']").html(totalPrinciple)
	totalCurrent = addCommas(totalCurrent.toFixed(2))
	$("[data-value='totalCurrent']").html(totalCurrent)
	totalMaturity = addCommas(totalMaturity.toFixed(2))
	$("[data-value='totalMaturity']").html(totalMaturity)
}
function filterAccounts() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	calculateTotals()
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
for (var i=0; i<20; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	d["label"] = "None";
	d["labelid"] = "None";
	d["accountname"] = "Term Deposit Account " + Math.round(Math.random() * 100).toString();
	d["termdepositnumb"] = Math.round(Math.random() * 1000000000).toString();
	d["depdate"] = "20/01/2012";
	d["baldate"] = "20/01/2012";
	d["matdate"] = "20/01/2017";
	if(i < 4) {d["status"] = "Outstanding";}else if(i >= 4 && i < 7){d["status"] = "Rolled Over";}else if(i >= 7){d["status"] = "Matured";};
	if(i % 3 == 0){d["currency"] = "SGD"}else if(i % 2 == 0){d["currency"] = "AUD"}else{d["currency"] = "SGD"};
	if(i % 3 == 0){d["fxrate"] = "1.2341"}else if(i % 2 == 0){d["fxrate"] = "0.9312"}else{d["fxrate"] = "1.2341"};
	d["principleamount"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["currbal"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["matamount"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["rate"] = (Math.round(Math.random() * 1000)/100).toFixed(2);
	if(i % 3 == 0){d["country"] = "Singapore"}else if(i % 2 == 0){d["country"] = "Australia"}else{d["country"] = "Singapore"};
	if(i % 3 == 0){d["bankname"] = "ANZ Singapore"}else if(i % 2 == 0){d["bankname"] = "ANZ Australia"}else{d["bankname"] = "ANZ Singapore"};
	if(i % 3 == 0){d["company"] = "Consulting Pte. Ltd.";}else{d["company"] = "Manufacturing Inc.";};
}


/**********************************************************************
DEPOSIT HISTORY GRID
**********************************************************************/
var depositDataView;
var depositgrid;
var	depositdata = [];
var	depositcolumns = [
	{ id:"date", name:"Date", field:"date", width: 160, sortable: true, sorter: "sorterDateIso",},
	{ id:"balance", name:"Balance", field:"balance", width: 200, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter },
	{ id:"accrued", name:"Interest Accrued To Date", field:"accrued", width: 200, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter },
	{ id:"ipaid", name:"Interest Paid To Date", field:"ipaid", width: 200, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter },
	{ id:"wht", name:"Withholding Tax", field:"wht", width: 200, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter }	
],
depositoptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: false,
	showHeaderRow: false,
	headerRowHeight: 40
};
if ( store.get('depositSummayOrder') ) {
	depositcolumns = store.get('depositSummayOrder');
	for (i = 0; i < depositcolumns.length; i++) {
		if (depositcolumns[i].id == "balance" || depositcolumns[i].id == "accrued" || depositcolumns[i].id == "ipaid" || depositcolumns[i].id == "wht") {
			depositcolumns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
};
if ( store.get('depositSummayWidths') ) {
	var setDepositSummaryWidth = store.get('depositSummayWidths');
	for (var i in setDepositSummaryWidth) {
		var s = setDepositSummaryWidth[i]
		for (c = 0; c < depositcolumns.length; c++) {
			if (s.id == depositcolumns[c].id) {
				depositcolumns[c].width = s.width
			}
		}
	}
};
for (var i=0; i<30; i++) {
	var d = (depositdata[i] = {});
	d["id"] = "id_" + i;
	d["date"] =  "April "+parseInt(i+1)+", 2013";
	d["balance"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["accrued"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["ipaid"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["wht"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
}


/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var user_deposit_folders = [], folders_updated = false, folders_deleted = false;
$folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Accounts</p><p style='font-size: 14px;'>Folders help you keep your accounts organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move accounts into a folder by selecting them in the accounts grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-th-list fa-fw'></i> View Menu.</p></div>"),
$folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if ( store.get('deposit_folders') ) { user_deposit_folders = store.get('deposit_folders') };
function folderFilter() {
	var rows = grid.getSelectedRows();
	statusString = "";
	if(rows.length > 0) {
		grid.setSelectedRows(0)
	}
	dataView.setFilterArgs({
		labelString: labelString,
		statusString: statusString,
		findString: findString
	})
	filterAccounts()
}
function folderChecker(val) {
	var _folder = val, error = false, $folderList = $(".folder-list").children("li"), existingFolders = [];
	for ( var i = 0; i < $folderList.length; i++ ) {
		existingFolders.push( $folderList.eq(i).attr("data-folder") );
	}
	if ($.inArray(_folder, existingFolders) != -1) { error = "existing" }
	return error;
}
function renameFolder(el) {
	var newFolderName = $.trim(el.val());
	if ( newFolderName == '' || newFolderName == "undefined" ) {
		el.val( el.attr("data-folder-name") );
	} else {
		el.val(newFolderName);
		el.closest("li").attr("data-folder", newFolderName );
		folders_updated = true;
	}
}
function addFolder() {
	var folderName = $.trim($("#newFolderInput").val()), $folderList = $("ul.folder-list"), $newFolderDiv = $("div.new-folder"), $li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
	if ( folderName == '' || folderName== "undefined" ) {
		$("#newFolderInput").val('');
		return false;
	} else {	
		if ( folderCheck == "existing" ) {
			 $newFolderDiv.addClass("error");
			 $("#newFolderInput").focus().select().one("keyup.remove-error", function() { $newFolderDiv.removeClass("error"); });
		} else {
			if ( $newFolderDiv.hasClass("error") ) { $newFolderDiv.removeClass("error"); }
			if ( $(".folder-message").size() ) {
				$(".folder-message").remove();
				$folderListInstruction.insertBefore($folderList);
			}
			$li = $("<li data-folder='"+folderName+"' data-folder-id='"+randString()+"' class='row new' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' value='"+folderName+"' maxlength='25' data-folder-name='"+folderName+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
			$("#newFolderInput").val('');
			$folderList.sortable("refresh");
			folders_updated = true;		
		}
	}
}
function addFolderInline() {
	var folderName = $.trim($("#_inlineFolderInput").val()), folderExists = false;
	if ( folderName == '' || folderName == "undefined" ) {
		$("#_inlineFolderInput").val('');
		return false;
	} else {
		for ( var i = 0; i < user_deposit_folders.length; i++ ) {
			if ( folderName == user_deposit_folders[i].name ) {
				folderExists = true;
				break;
			}
		}
		if ( folderExists ) {
			alert("A folder with that name already exists.");
		} else {
			var _id = randString();
			var _new = { name: folderName, id: _id };
			user_deposit_folders.push(_new);
			populateFolders();
			store.set('deposit_folders', user_deposit_folders);
			$("#_inlineFolderInput").val('');
			moveAccounts(_id);
		}
	}
}
function deleteFolder(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function(){
		if ( !$target.hasClass('new') ) { folders_deleted = true; }
		$target.remove();
		$(".folder-list").sortable("refresh");
		folders_updated = true;
		if ( !$(".folder-list").children("li").size() ) {
			$(".folder-list-instructions").remove();
			$folderMessage.appendTo(".folder-settings");
		}
		if ( $("div.new-folder").hasClass("error") ) {
			 $("div.new-folder").removeClass("error");
		}
	 });
}
function populateFolders() {
	var $assignFolders = $(".assign-folders"), folderCount = user_deposit_folders.length, activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
	$assignFolders.children().remove();
	if ( $("#removeFromFolder").size() > 0 ) { $("#removeFromFolder").remove(); }
	if ( folderCount > 0 ) {
		var $li, $a
		$assignFolders.each( function() {
			var _this = $(this);
			if (  _this.parents().attr("id") == "folderMenu" ) {
				$.each(user_deposit_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
					}).appendTo($li);
				});
				var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
				$spacer = $("<li class='menu-section' />").appendTo($ul),
				$li = $("<li />").appendTo($ul),
				$a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected accounts from folders' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
					e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
				}).appendTo($li),
				$spacer = $("<li class='menu-section' />").appendTo($ul);
			} else if ( _this.parents().attr("id") == "viewMenu" ) {
				$.each(user_deposit_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					if ( this.id == activeFolder ) { $li.addClass("active"); $("#viewMenuControl").children("a").children("span").html(this.name); }
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault();
						var _folderID = $(this).attr("data-folder-id"), _folderName = $(this).attr("data-folder");
						if ( labelString != _folderID ) {
							labelString = _folderID;
						}
						folderFilter();
						$("#selectedFolder").html(_folderName);
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
		$li = $("<li class='no-set' />").appendTo($viewMenu),
		$a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Folders</div>Folders help keep your data organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
	}
}
function populateFolderManager() {	
	folders_updated = false; folders_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
	$folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
	$folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
	$folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e){if(e.keyCode == 13){addFolder()}}).appendTo($folderAddDiv),
	$folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
	$folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
	$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({ handle: '.reorder-folder', axis: 'y', tolerance: "pointer", update: function( event, ui ) { folders_updated = true } }),
	folderCount = user_deposit_folders.length, $li, $div, $span, $input, $a, $error;
	if ( folderCount > 0 ) {
		$folderListInstruction.insertBefore($folderList);
		$.each(user_deposit_folders, function() {
			$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='"+this.name+"' data-folder-name='"+this.name+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
		});
	} else {
		$folderMessage.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showFolderManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Deposit Folders",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function(){return populateFolderManager()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();updateFolders(_dialog)}}], cssClass: "primary" }
		] 
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );	
}
function saveFolders(dialog) {
	var $dialog = $("#"+dialog.id), $active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
	$dialog.addClass("working");	
	user_deposit_folders = folders_updated;
	
	var active_deleted = true;
	
	for ( f = 0; f < user_deposit_folders.length; f++ ) {
		if ( $active == user_deposit_folders[f].id ) {
			active_deleted = false;
			break;
		}
	}
	
	for ( var i = 0; i < data.length; i++ ) {
		var _resetFolder = true;
		for ( var n = 0; n < user_deposit_folders.length; n++ ) {
			if ( data[i].labelid == user_deposit_folders[n].id ) {
				data[i].label = user_deposit_folders[n].name;
				_resetFolder = false;
				break;
			} 
		}	
		if ( _resetFolder ) {
			data[i].label = "None";
			data[i].labelid = "None";
		}

	}	
	folders_updated = false;
	folders_deleted = false;
	store.set('deposit_folders', user_deposit_folders);
	setTimeout( function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateFolders();
		if ( !user_deposit_folders.length || active_deleted ) { $("#_allAccounts").trigger("click"); }
		dialogHider(dialog);
	}, 300);
}
function updateFolders(dialog) {
	if ( folders_updated ) {
		folders_updated = [];
		var duplicate_names = false, $folderList = $(".folder-list");
		$folderList.find("li.error").removeClass("error");
		$folderList.children("li").each(function() {
			folders_updated.push( { "name":$(this).attr("data-folder"), "id":$(this).attr("data-folder-id") });
			var _name = $(this).attr("data-folder");
			$(this).siblings().each(function() {
				if ( $(this).attr("data-folder") == _name ) {
					$(this).addClass("error");
				}
			});
		});
		if ( $folderList.find("li.error").size() ) {
			duplicate_names = true;
		}
		if ( duplicate_names ) {	
			return false;
		} else {		
			var save_folders = false;
			if ( user_deposit_folders.length != folders_updated.length ) {
				save_folders = true;
			} else {
				for (var i = 0; i < user_deposit_folders.length; i++) {
					if ( user_deposit_folders[i].name != folders_updated[i].name || user_deposit_folders[i].id != folders_updated[i].id ) {
						save_folders = true;
						break;
					}
				}
			}
			if ( save_folders || folders_deleted ) {
				if ( folders_deleted ) {
					buildConfirmDialog( "You've removed some existing folders.", "Are you sure you want to continue?", function(){saveFolders(dialog)});
				} else {
					saveFolders(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}
function moveAccounts(_id) {
	var _folder, _message, _rowsForUpdate = [], _sel = selectedRowIds.length;
	for ( var i = 0; i < user_deposit_folders.length; i++ ) {
		if ( user_deposit_folders[i].id == _id ) {
			_folder = user_deposit_folders[i];
			_message = "Selected accounts were moved to &quot;"+_folder.name+"&quot;";
			break;
		}
	}
	if ( _id == "None" ) {
		_folder = [{ name:"None", id:"None"}];
		_message = "Selected accounts were removed from their folders";
	}
	for ( var i = 0, l = _sel; i < l; i++ ) {
		var _item = selectedRowIds[i];
		if ( _item ) {
			_rowsForUpdate.unshift(_item);
		}
	}
	for ( var i = 0; i < _rowsForUpdate.length; i++ ) {
		data[dataView.getIdxById(_rowsForUpdate[i])].label = _folder.name;
		data[dataView.getIdxById(_rowsForUpdate[i])].labelid = _folder.id;
	}
	grid.setSelectedRows(0);
	selectedRowIds = [];
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) { collapseAllGroups(); }
	groupedSetting = 1;
	buildNotification(_message, 300, 3000);
	store.set('depositNumbers', dataView.getItems());
	$("#viewMenu .assign-folders").find("a[data-folder-id='"+_folder.id+"']").trigger("click");
}


/**********************************************************************
MODAL WINDOWS 
**********************************************************************/
function showDepositSummaryModal(e) {
	e.preventDefault();
	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report took more than 3 seconds to generate.","It will be available for download in the &quot;Downloads&quot; section shortly.","");
		}, 3000);
	};
	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).parent("div.data-column").find("div.data-text"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='statementSpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();			
		} else if ( _date == "dr" ) {
			$("#statementSpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='statementFromDate' style='width: 120px !important; margin-right: 10px;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='statementToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var statementeDatRange = $("#statementFromDate, #statementToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "statementFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					statementeDatRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#statementSpecificDate, #statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
		$row.add("focused");
	};
	var formElements = [
		{ name: "Report Format", id: "stmt-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "stmt-name", type: "input", max: 30 },
		{ name: "Description", id: "stmt-desc", type: "input", max: 75 },
		{ name: "Data From", id: "stmt-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function(){ $(this).addClass("focused") }).on("focusout", function(){ $(this).removeClass("focused") }).appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $note;
		if ( formElements[i].type == "select" ) {
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
		} else if ( formElements[i].type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}
		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}
		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}	
		$el.appendTo($data);
		if ( formElements[i].note ) {
			$note = $("<div class='data-text'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestSummary",
		title: "Deposit Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}] }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}


/**********************************************************************
UPDATE THE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='deposits.html'>Deposits</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Deposit Details");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Deposits");
	}
}



/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE TERM DEPOSITS GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#summaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);	
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'termDepositOrder', 'termDepositWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();	
		var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			if (rows.length > 1) {
				$cmenu = $("#multipleContextMenu")
			} else {
				$cmenu = $("#contextMenu")
			}
		};
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {		
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	}); 
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if(selectedRowIds.length > 0) {
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#selectedCount").html('');		
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		if( !$row.is(".slick-group, .slick-group-totals") ) {
			$row.attr({'data-panel': '#accountDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels');
			$("#accountDetailsTab").trigger("click");
			updateBreadcrumb("view");
			$row.removeAttr("data-panel data-switch");
			grid.setSelectedRows(0);
			selectedRowIds = [];
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('termDepositWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		labelString: labelString,
		statusString: statusString,
		findString: findString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if ( store.get('termDepositOrder') ) {
		var visibleTermDepositColumns = [];
		for (var i = 0; i < store.get('termDepositOrder').length+1; i++) {
			if (columns[i].visible) {
				visibleTermDepositColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleTermDepositColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	CALCULATE TOTALS
	**********************************************************************/	
	calculateTotals()


	/**********************************************************************
	INITIALIZE DEPOSIT HISTORY GRID
	**********************************************************************/		
	var depositItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	depositDataView = new Slick.Data.DataView({
		depositItemMetaProvider: depositItemMetaProvider
	});
	depositgrid = new Slick.Grid("#depositHistory", depositDataView, depositcolumns, depositoptions);
	depositgrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	depositgrid.registerPlugin(depositItemMetaProvider);
	var depositcolumnpicker = new Slick.Controls.ColumnPicker(depositcolumns, depositgrid, depositoptions, 'depositSummayOrder', 'depositSummayWidths', []);
	depositgrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		depositDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	depositgrid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
	});
	depositgrid.onColumnsResized.subscribe(function(e, args) {
		store.set('depositSummayWidths', depositgrid.getColumns());
	});
	depositDataView.onRowCountChanged.subscribe(function(e,args) {
		depositgrid.updateRowCount();
		depositgrid.render();
	});
	depositDataView.onRowsChanged.subscribe(function(e,args) {
		depositgrid.invalidateRows(args.rows);
		depositgrid.render();
	});	
	depositDataView.setItems(depositdata);
	depositDataView.syncGridSelection(depositgrid, true, false);
	depositDataView.syncGridCellCssStyles(depositgrid, "contextMenu");
	depositgrid.setColumns(depositcolumns);
	if ( store.get('depositSummayOrder') ) {
		var visibleDepositSummaryColumns = [];
		for (var i = 0; i < store.get('depositSummayOrder').length; i++) {
			if (depositcolumns[i].visible) {
				visibleDepositSummaryColumns.push(bcolumns[i])
			}
		}
		depositgrid.setColumns(visibleDepositSummaryColumns);
	}


	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/	
	$(window).bind("resize", function() {
		grid.resizeCanvas();
		depositgrid.resizeCanvas();
	});


	/**********************************************************************
	 VIEW MENU INTERACTIONS
	**********************************************************************/	
	function statusFilter() {
		var rows = grid.getSelectedRows();
		labelString = "";
		if(rows.length > 0) {
			grid.setSelectedRows(0);
		}
		dataView.setFilterArgs({
			labelString: labelString,
			statusString: statusString,
			findString: findString
		});
		filterAccounts();
	}
	$("#viewStatus").on("click.label-view", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ( $target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set") ) {
			var value = $target.attr("data-value");
			if (statusString != value) {
				statusString = value;
			};
			statusFilter();
			$("#selectedFolder").html($target.html())
		}
	});
	$("#_allAccounts").on("click", function(e) {
		e.preventDefault();
		var _folder = "";
		if ( labelString != _folder ) {
			labelString = _folder;
		}
		folderFilter();
		$("#selectedFolder").html("All Deposits")
	});
	$(".manage-folders").on("click", showFolderManagerDialog);
	$("#_inlineFolderButton").on("click", addFolderInline);
	$("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
		if (e.keyCode == 13) {
			addFolderInline();
		}
	});
	populateFolders();

	/**********************************************************************
	SETTINGS MENU
	**********************************************************************/
	function returnRate(a, b) {
		var rate;
		if (a == "AUD") {
			if (b == "AUD") {
				rate = 1.0000
			} else if (b == "SGD") {
				rate = 0.8222
			}
		} else if (a == "CNY") {
			if (b == "AUD") {
				rate = 5.9200
			} else if (b == "SGD") {
				rate = 4.8400
			}
		} else if (a == "EUR") {
			if (b == "AUD") {
				rate = 0.7502
			} else if (b == "SGD") {
				rate = 0.6100
			}
		} else if (a == "HKD") {
			if (b == "AUD") {
				rate = 7.4910
			} else if (b == "SGD") {
				rate = 6.1230
			}
		} else if (a == "IDR") {
			if (b == "AUD") {
				rate = 9426.0710
			} else if (b == "SGD") {
				rate = 7708.4500
			}
		} else if (a == "INR") {
			if (b == "AUD") {
				rate = 53.8600
			} else if (b == "SGD") {
				rate = 43.8700
			}
		} else if (a == "KRW") {
			if (b == "AUD") {
				rate = 1081.8300
			} else if (b == "SGD") {
				rate = 886.1722
			}
		} else if (a == "KHR") {
			if (b == "AUD") {
				rate = 3852.6700
			} else if (b == "SGD") {
				rate = 3164.1900
			}
		} else if (a == "MYR") {
			if (b == "AUD") {
				rate = 2.9201
			} else if (b == "SGD") {
				rate = 2.3902
			}
		} else if (a == "NZD") {
			if (b == "AUD") {
				rate = 1.2000
			} else if (b == "SGD") {
				rate = 0.9800
			}
		} else if (a == "SGD") {
			if (b == "AUD") {
				rate = 1.2222
			} else if (b == "SGD") {
				rate = 1.0000
			}
		} else if (a == "THB") {
			if (b == "AUD") {
				rate = 28.9100
			} else if (b == "SGD") {
				rate = 23.7100
			}
		} else if (a == "USD") {
			if (b == "AUD") {
				rate = 0.9600
			} else if (b == "SGD") {
				rate = 0.7900
			}
		} else if (a == "VND") {
			if (b == "AUD") {
				rate = 20208.5600
			} else if (b == "SGD") {
				rate = 16565.4300
			}
		};
		return (rate)
	}
	$("#ccyMenu").on("click.set-ccy", "a", function(e) {
		e.preventDefault();
		groupCCYSetting = $(this).attr("data-value");
		for (var i = 0; i < data.length; i++) {
			data[i].fxrate = returnRate(groupCCYSetting, data[i].currency).toFixed(4);
		}
		dataView.setItems(data)
		filterAccounts();
		$("span[data-object='reference-ccy']").empty().html(groupCCYSetting);
		$("#_totalsRow [data-value='totalccy']").html(groupCCYSetting);
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}		
	});

	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		}
	});

	/**********************************************************************
	ACTION MENU INTERACTION
	**********************************************************************/
	$("#actionMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength =  grid.getSelectedRows().length;
		var menuLink = $("#actionMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({"href":"#actionMenuNoSelected"});
		} else if (rowsLength == 1) {
			menuLink.attr({"href":"#actionMenu"});
		} else if (rowsLength > 1) {
			menuLink.attr({"href":"#actionMenuMultiSelected"});
		}
	});

	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);

	/**********************************************************************
	REQUEST REPORT MODALS
	**********************************************************************/
	$(".request-summary").on("click", showDepositSummaryModal);

	/**********************************************************************
	BALANCE HISTORY DATE FILTERS
	**********************************************************************/
	$("#_balspecificDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#balDate").find("li.active").removeClass("active");
			$("#balSpecDateItem").closest("li").addClass("active");
			$("div.control-list").find("a[href='#balDate']").children("span.item-text").text(dateText);
			$("#balanceHistoryDate").html(dateText);
			$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
			$('#depositHistoryTab').trigger('click');
			updateBreadcrumb("view");
		}
	}).click(function(e) {e.stopPropagation();});
	var balDateRangeSelection = $("#_balrangeDateFrom, #_balrangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_balrangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				balDateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {e.stopPropagation();});
	$("#_balDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_balrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_balrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#balDate").find("li.active").removeClass("active");
		$("#balRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#depositHistoryTab').trigger('click');
		updateBreadcrumb("view");
		$("div.control-list").find("a[href='#balDate']").children("span.item-text").text(fromDate+" - "+toDate);
		$("#balanceHistoryDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});

	/**********************************************************************
	CLOSE DETAIL VIEW
	**********************************************************************/
	$("#closeDetailView").on("click", function(e){
		updateBreadcrumb("close");
	});


});