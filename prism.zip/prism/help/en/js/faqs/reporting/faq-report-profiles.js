/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Report Centre Onscreen Guide",
	action: "slider"
}, {
	title: "How do I create a Report Profile?",
	faq: "<p>Click the New Report Profile &gt; Enter details for the report you require &gt; Select Save if this is a regular report or Run for an ad-hoc report.<br />If you run the report,it will be available in the Download screen to view or save.</p><p>Selecting &#39;Share this report&#39; will allow all users registered in your organisation and entitled to Reporting functionality to view this report.</p>"
}, {
	title: "How do I edit a Report Profile?",
	faq: "<p>Edit an existing report profile by right--clicking on the Report Profile &gt; selecting Edit &gt; Update details as required &gt; Click Save.</p>"
}, {
	title: "Can the system remember my preferred settings?",
	faq: "<p>Selecting &#39;Remember Settings&#39; from the Action Menu, the application will remember your grouping selections for this screen.</p>"
}];