(function ($) {
	function SlickPreviewSortPicker(columns, grid, options) {

		var $mouseDiv, sortId, sortAsc;
        
		function init() {
			grid.onPreviewSort.subscribe(handlePreviewSort);
			grid.onBeforeDestroy.subscribe(destroy);
		}
		
		function handlePreviewSort(e){
			var id = 'slickPreviewSortpicker_'+options.id;
			$mouseDiv = $('#' + id);
            if ($mouseDiv.length != 0) {
            	$mouseDiv.fadeIn(0);
            } else {
            	$mouseDiv = $("<div id='"+id+"' style='display: none; position: absolute;z-index: 200; padding-left: 20px; padding-right: 20px; padding-bottom: 20px;' />").appendTo(document.body);
            	var $menu = $("<ul class='slick-columnpicker' style='width:225px; overflow-y: hidden; height: auto;' />"),
            	$heading = $("<li class='menu-heading'>Sort By</li>").appendTo($menu);
                for (var i = 0; i < columns.length; i++) {
	             	var col = columns[i], cname = col.name;
	             	$menu.append($("<li />").data('sort-col', col.id).prepend($("<label />").text(cname)).click(sortColumn));
                }
                if ( e.pageY + $menu.height() > $(window).height() ) {
                	$menu.css({ "overflow-y":"scroll", "height": $(window).height() - e.pageY - 10 });
                }
            	$mouseDiv.bind("mouseleave", function (e) {
                    $(this).fadeOut(150);
                    $menu.css({"overflow-y":"hidden", "height":"auto"});
            	});
				$menu.appendTo($mouseDiv);
            }
            var leftOffset = ((e.pageX + $mouseDiv.outerWidth() + 20) > $(window).width()) ? (e.pageX + $mouseDiv.outerWidth() + 20 - $(window).width()) : 25;
            $mouseDiv.css("top", e.pageY - 10).css("left", e.pageX - leftOffset).fadeIn(0);
		}
		
		function sortColumn(e){
			var $el = $(e.currentTarget), sortCol = $el.data("sort-col");
			if (sortCol === sortId) {
				sortAsc = !sortAsc;
			} else {
				sortId = sortCol;
				sortAsc = true;
			}
			grid.onSort.notify({'sortCol':{'field': sortCol},'sortAsc':sortAsc}, null, grid);
			$el.removeAttr("class").addClass( sortAsc ? "preview-sort-asc" : "preview-sort-desc" ).siblings("li").not("li.menu-heading").removeAttr("class");
		}
		
		function destroy() {
			$mouseDiv.remove();
        }
		
		init();

        return {
            
        };
	}
	
	// Slick.Controls.PreviewSortPicker
    $.extend(true, window, {
        Slick: {
            Controls: {
            	SlickPreviewSortPicker: SlickPreviewSortPicker
            }
        }
    });
})(jQuery);