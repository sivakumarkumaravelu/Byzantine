/**********************************************************************
NET POSITION GRID
**********************************************************************/
var dataView;
var grid;
var data = [
	{id: "id_0",company: "ABC Company",accounttype: "Operating Accounts",currency: "SGD",country: "Singapore",fxrate: parseFloat(1.2311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_1",company: "ABC Company",accounttype: "Operating Accounts",currency: "AUD",country: "Singapore",fxrate: parseFloat(0.9311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_2",company: "ABC Company",accounttype: "Operating Accounts",currency: "USD",country: "Singapore",fxrate: parseFloat(1.0000).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_3",company: "ABC Company",accounttype: "Deposits",currency: "SGD",country: "Singapore",fxrate: parseFloat(1.2311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_4",company: "ABC Company",accounttype: "Deposits",currency: "AUD",country: "Singapore",fxrate: parseFloat(0.9311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_5",company: "ABC Company",accounttype: "Deposits",currency: "USD",country: "United States",fxrate: parseFloat(1.0000).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_6",company: "XYZ Company",accounttype: "Operating Accounts",currency: "AUD",country: "Australia",fxrate: parseFloat(0.9311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_7",company: "XYZ Company",accounttype: "Operating Accounts",currency: "EUR",country: "France",fxrate: parseFloat(1.6311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)},
	{id: "id_8",company: "XYZ Company",accounttype: "Operating Accounts",currency: "SGD",country: "Singapore",fxrate: parseFloat(1.2311).toFixed(4), numb: (Math.round(Math.random() * 10).toFixed(0)), amount: (Math.round(Math.random() * 10000000)/100).toFixed(2), equivalent: (Math.round(Math.random() * 10000000)/100).toFixed(2)}
];
var selectedRowIds = [];
var columns = [
	{id:"company", name:"Company", field:"company", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"country", name:"Country", field:"country", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"accounttype", name:"Type", field:"accounttype", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"numb", name:"Number", field:"numb", width: 100, sortable: true, sorter: "sorterNumeric", visible: true },
	{id:"fxrate", name:"Exchange Rate", field:"fxrate", width: 160, sortable: true, sorter: "sorterNumeric", cssClass: "num", headerCssClass: "righted", visible: true},
	{id:"currency", name:"Currency", field:"currency", width: 100, sortable: true, sorter: "sorterStringCompare", visible: true},	
	{id:"amount", name:"Total Amount", field:"amount", width: 200, sortable: true, sorter: "sorterNumeric", visible: true, cssClass: "num pos", headerCssClass: "righted", formatter: Slick.Formatters.AmountFormatter, groupTotalsFormatter:sumTotalsFormatter},
	{id:"equivalent", name:"Equivalent Balance", field:"equivalent", width: 200, sortable: true, sorter: "sorterNumeric", visible: true, cssClass: "num pos", headerCssClass: "righted", formatter: Slick.Formatters.AmountFormatter, groupTotalsFormatter:sumTotalsFormatter}
];
var columnFilters = {};

if ( store.get('netPositionOrder') ) {
	columns = store.get('netPositionOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "amount" || columns[i].id == "equivalent") {
			columns[i].groupTotalsFormatter = sumTotalsFormatter;
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}

if ( store.get('netPositionWidths') ) {
	var setWidth = store.get('netPositionWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}

options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: false,
	showHeaderRow: true,
	headerRowHeight: 40
};

var groupedSetting = 0, groupCollapseSetting = 0, groupCCYSetting = "USD";


function sumTotalsFormatter(totals, columnDef) {
	return groupCCYSetting+" "+ addCommas(Math.round((totals.sum[columnDef.field] * 100)/100).toFixed(2));
}

function sumNumberFormatter(totals, columnDef) {
	return Math.round(totals.sum[columnDef.field])
}

function expandAllGroups() {
	dataView.expandAllGroups();
}

function collapseAllGroups() {
	dataView.collapseAllGroups();
}

function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}

function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);

	dataView.setAggregators([
		new Slick.Data.Aggregators.Sum("amount"),
		new Slick.Data.Aggregators.Sum("equivalent")
	], true);

	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var findString = "", findDataPoint = "currency";

function myFilter(item, args) {	
	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}
	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}
	return true;
}

function calculateTotals() {
	var totalNet = 0;
	for (var i = 0; i < dataView.getLength(); i++) {
		if (dataView.getItem(i).id) {
			totalNet = parseFloat(totalNet) + parseFloat(dataView.getItem(i).amount.replace(',', ''));
		}
	}
	totalNet = addCommas(totalNet.toFixed(2))
	$("[data-value='totalnet']").html(totalNet)
}

function filterAccounts() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}

function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}


/**********************************************************************
GET CURRENT TIME
**********************************************************************/
function getCurrentTime() {
	var d = new Date();
	var hh = d.getHours();
	var dd = " AM";
	var h = hh;
	if (h >= 12) {
		h = hh-12
		dd = " PM"
	}
	if (h == 0) {
		h = 12
	}	
	var mm = d.getMinutes();
	var m = (mm < 10) ? "0"+mm : mm;
	var currentTime = h+":"+m+dd;
	return currentTime;
}
function updateTimeStamp(_date) {
	$("#_timestamp").html(_date);
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE NET POSITION GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#netPositionGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	grid.registerPlugin(groupItemMetadataProvider);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'netPositionOrder', 'netPositionWidths');
	grid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();	
		var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
		$cmenu = $("#contextMenu")
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {		
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	}); 
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
		var type = dataView.getItem(row).accounttype;
		var $row = $(e.target).closest(".slick-row");
		if( !$row.is(".slick-group, .slick-group-totals") ) {
			if (type == "Deposits") {
				document.location.href = 'deposits.html';
			} else if (type == "Operating Accounts") {
				document.location.href = 'operating-accounts.html';
			}
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('netPositionWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		$(args.node).empty().addClass(args.column.headerCssClass);
		var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
		var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
			e.preventDefault();
			$(this).prev("input[type='text']").val("").trigger("change");
			$(this).hide();
		});
		if ($input.val()) {
			$icon.show();
		}
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		findString: findString
	});
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if ( store.get('netPositionOrder') ) {
		var visibleDownloadColumns = [];
		for (var i = 0; i < store.get('netPositionOrder').length; i++) {
			if (columns[i].visible) {
				visibleDownloadColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleDownloadColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});


	/**********************************************************************
	CALCULATE TOTALS AND GET DATE | TIMESTAMP
	**********************************************************************/	
	calculateTotals()
	updateTimeStamp($.datepicker.formatDate('dd/mm/yy', new Date()))
		

	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}		
	});

	/**********************************************************************
	REMEMBER GRID SETTINGS
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	CURRENCY INTERACTION
	**********************************************************************/
	function returnRate(a,b) {
		var rate;	
		if (a == "AUD") {
			if (b == "AUD") {rate = 1.0000} else if (b == "SGD") {rate = 0.8222} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "CNY") {
			if (b == "AUD") {rate = 5.9200} else if (b == "SGD") {rate = 4.8400} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "EUR") {
			if (b == "AUD") {rate = 0.7502} else if (b == "SGD") {rate = 0.6100} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 1.0000}
		} else if (a == "HKD") {
			if (b == "AUD") {rate = 7.4910} else if (b == "SGD") {rate = 6.1230} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "IDR") {
			if (b == "AUD") {rate = 9426.0710} else if (b == "SGD") {rate = 7708.4500} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "INR") {
			if (b == "AUD") {rate = 53.8600} else if (b == "SGD") {rate = 43.8700} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "KRW") {
			if (b == "AUD") {rate = 1081.8300} else if (b == "SGD") {rate = 886.1722} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "KHR") {
			if (b == "AUD") {rate = 3852.6700} else if (b == "SGD") {rate = 3164.1900} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "MYR") {
			if (b == "AUD") {rate = 2.9201} else if (b == "SGD") {rate = 2.3902} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "NZD") {
			if (b == "AUD") {rate = 1.2000} else if (b == "SGD") {rate = 0.9800} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "SGD") {
			if (b == "AUD") {rate = 1.2222} else if (b == "SGD") {rate = 1.0000} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "THB") {
			if (b == "AUD") {rate = 28.9100} else if (b == "SGD") {rate = 23.7100} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "USD") {
			if (b == "AUD") {rate = 0.9600} else if (b == "SGD") {rate = 0.7900} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		} else if (a == "VND") {
			if (b == "AUD") {rate = 20208.5600} else if (b == "SGD") {rate = 16565.4300} else if (b == "USD") {rate = 0.9600} else if (b == "EUR") {rate = 0.7200}
		};
		return(rate)
	}
	$("#ccyMenu").on("click.set-ccy", "a", function(e) {
		e.preventDefault()
		groupCCYSetting = $(this).attr("data-value")
		for (var i = 0; i < data.length; i++) {
			data[i].fxrate = returnRate(groupCCYSetting,data[i].currency).toFixed(4);
		}
		dataView.setItems(data)
		filterAccounts();
		$("#_totalsRow [data-value='totalccy']").html(groupCCYSetting)
		$("span[data-object='reference-ccy']").empty().html(groupCCYSetting);
	});


	/**********************************************************************
	BALANCE DATE
	**********************************************************************/

	$("#balDateToday").on("click", function(e){
		e.preventDefault();
		updateTimeStamp($.datepicker.formatDate('dd/mm/yy', new Date()));
	})

	$("#balDateYesterday").on("click", function(e){
		e.preventDefault();
		updateTimeStamp($.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - 1))));
	})
	

	$("#_specificBalDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			updateTimeStamp(dateText)
			$("#settingsMenuControl").removeClass("on");
			$("#balanceDate").find("li.active").removeClass("active");
			$("#speBalanceDate").closest("li").addClass("active");
			$("div.control-list").find("a[href='#balanceDate']").children("span.item-text").text(dateText);
			$("div.control-list").find("a[href='#balanceDate']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({
				"data-panel": "#netPosition",
				"data-switch": "switch-panels"
			}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		}
	}).click(function(e) {
		e.stopPropagation();
	});
		
	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


});



