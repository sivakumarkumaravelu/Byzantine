/**********************************************************************
            MICRO-TEMPLATE
**********************************************************************/
(function() {
  var cache = {};
  this.tmpl = function tmpl(str, data) {
    var fn = !/\W/.test(str) ?
      cache[str] = cache[str] ||
      tmpl(document.getElementById(str).innerHTML) :
      new Function("obj",
        "var p=[],print=function(){p.push.apply(p,arguments);};" +
        "with(obj){p.push('" +
        str
        .replace(/[\r\t\n]/g, " ")
        .split("<%").join("\t")
        .replace(/((^|%>)[^\t]*)'/g, "$1\r")
        .replace(/\t=(.*?)%>/g, "',$1,'")
        .split("\t").join("');")
        .split("%>").join("p.push('")
        .split("\r").join("\\'") + "');}return p.join('');");
    return data ? fn(data) : fn;
  };
})();


/**********************************************************************
BENEFICIARY DATA
**********************************************************************/
var data = _tbos_beneficiary_accounts;


/**********************************************************************
BENEFICIARY CREATE / VIEW / EDIT
**********************************************************************/
var trackviewmode = false;
function setupViewBeneficiary(record) {


  /* get additional record data */
  trackviewmode = true;

  /* load record data into view fields */
  $("#beneInformation").scrollTop(0);


  $("#viewBeneRecordId").html(record.id);
  $("#viewBeneStatus").html(record.beneworkflow);
  $("#viewBeneDivision").html(record.benedivision);
  $("#viewBeneName").html(record.benename);
  $("#viewBeneLocalName").html(record.benelocalname);
  $("#viewBeneNickName").html(record.benenickname);
  $("#viewBeneAccountNumber").html(record.beneaccount);
  $("#viewBeneAccountType").html(record.benetype);
  $("#viewBeneAddress1").html(record.beneaddress1);
  $("#viewBeneAddress2").html(record.beneaddress2);
  $("#viewBeneAddress3").html(record.beneaddress3);
  $("#viewBeneCity").html(record.benecity);
  $("#viewBeneCountry").html(record.benecountry);
  $("#viewBeneEmail").html(record.beneemail);
  $("#viewBeneBankCountry").html(record.benebankcountry);
  if (record.benebankcountry == "Australia") {
    $("#viewBeneBankLocalClearingSection").hide();
    $("#viewBeneBankSwiftClearingSection, #viewSwiftNCCSection").show();
    $("#viewBeneSwiftNCCCode").html(record.swiftncc);
    $("#viewBeneSwiftCode").html(record.swiftcode);
    $("#viewBeneSwiftBankName").html(record.swiftbank);
    $("#viewBeneSwiftBranchName").html(record.swiftbranch);
    $("#viewBeneSwiftBankAddress1").html(record.swiftbankaddress1);
    $("#viewBeneSwiftBankAddress2").html(record.swiftbankaddress2);
    $("#viewBeneSwiftBankAddress3").html(record.swiftbankaddress3);
    $("#viewBeneSwiftCity").html(record.swiftbankcity);
  } else if (record.benebankcountry == "China") {
    $("#viewBeneBankLocalClearingSection, #viewBeneBankSwiftClearingSection").show();
    $("#viewBeneLocalBankNCCCode").html('').hide();
    $("#viewBeneLocalBankClearingCode").html(record.benebankclearingcode);
    $("#viewBeneLocalBankName").html(record.benebank);
    $("#viewBeneLocalBankBranchName").html(record.benebankbranch);
    $("#viewBeneLocalBankAddress1").html(record.benebankaddress1);
    $("#viewBeneLocalBankAddress2").html(record.benebankaddress2);
    $("#viewBeneLocalBankAddress3").html(record.benebankaddress3);
    $("#viewSwiftNCCSection").show();
    $("#viewBeneSwiftNCCCode").html(record.swiftncc);
    $("#viewBeneSwiftCode").html(record.swiftcode);
    $("#viewBeneSwiftBankName").html(record.swiftbank);
    $("#viewBeneSwiftBranchName").html(record.swiftbranch);
    $("#viewBeneSwiftBankAddress1").html(record.swiftbankaddress1);
    $("#viewBeneSwiftBankAddress2").html(record.swiftbankaddress2);
    $("#viewBeneSwiftBankAddress3").html(record.swiftbankaddress3);
    $("#viewBeneSwiftCity").html(record.swiftbankcity);
  } else if (record.benebankcountry == "Hong Kong") {
    $("#viewBeneBankLocalClearingSection, #viewBeneBankSwiftClearingSection").show();
    $("#viewBeneLocalBankNCCCode").html(record.benebankclearingtype).show();
    $("#viewBeneLocalBankClearingCode").html(record.benebankclearingcode);
    $("#viewBeneLocalBankName").html(record.benebank);
    $("#viewBeneLocalBankBranchName").html(record.benebankbranch);
    $("#viewBeneLocalBankAddress1").html(record.benebankaddress1);
    $("#viewBeneLocalBankAddress2").html(record.benebankaddress2);
    $("#viewBeneLocalBankAddress3").html(record.benebankaddress3);
    $("#viewSwiftNCCSection").hide();
    $("#viewBeneSwiftNCCCode").html('');
    $("#viewBeneSwiftCode").html(record.swiftcode);
    $("#viewBeneSwiftBankName").html(record.swiftbank);
    $("#viewBeneSwiftBranchName").html(record.swiftbranch);
    $("#viewBeneSwiftBankAddress1").html(record.swiftbankaddress1);
    $("#viewBeneSwiftBankAddress2").html(record.swiftbankaddress2);
    $("#viewBeneSwiftBankAddress3").html(record.swiftbankaddress3);
    $("#viewBeneSwiftCity").html(record.swiftbankcity);
  } else if (record.benebankcountry == "New Zealand") {
    $("#viewBeneBankLocalClearingSection").hide();
    $("#viewBeneBankSwiftClearingSection, #viewSwiftNCCSection").show();
    $("#viewBeneSwiftNCCCode").html(record.swiftncc);
    $("#viewBeneSwiftCode").html(record.swiftcode);
    $("#viewBeneSwiftBankName").html(record.swiftbank);
    $("#viewBeneSwiftBranchName").html(record.swiftbranch);
    $("#viewBeneSwiftBankAddress1").html(record.swiftbankaddress1);
    $("#viewBeneSwiftBankAddress2").html(record.swiftbankaddress2);
    $("#viewBeneSwiftBankAddress3").html(record.swiftbankaddress3);
    $("#viewBeneSwiftCity").html(record.swiftbankcity);
  } else if (record.benebankcountry == "Singapore") {
    $("#viewBeneBankLocalClearingSection, #viewSwiftNCCSection").hide();
    $("#viewBeneBankSwiftClearingSection").show();
    $("#viewBeneSwiftCode").html(record.swiftcode);
    $("#viewBeneSwiftBankName").html(record.swiftbank);
    $("#viewBeneSwiftBranchName").html(record.swiftbranch);
    $("#viewBeneSwiftBankAddress1").html(record.swiftbankaddress1);
    $("#viewBeneSwiftBankAddress2").html(record.swiftbankaddress2);
    $("#viewBeneSwiftBankAddress3").html(record.swiftbankaddress3);
    $("#viewBeneSwiftCity").html(record.swiftbankcity);
  }


  /* show correct action buttons */
  if (record.benestatus == "Active") {
    if (record.beneworkflow == "Approved" || record.beneworkflow == "Changes Rejected" || record.beneworkflow == "Deletion Rejected") {
      $("#approveBeneBtn, #rejectBeneBtn, #viewBeneChangesBtn").hide();
      $("#editBeneBtn, #deleteBeneBtn, #payBeneBtn").show();
    } else if (record.beneworkflow == "Pending Approval - Modified") {
      $("#editBeneBtn, #deleteBeneBtn, #payBeneBtn").hide();
      $("#approveBeneBtn, #rejectBeneBtn, #viewBeneChangesBtn").show();
    } else if (record.beneworkflow == "Pending Approval - Deleted") {
      $("#editBeneBtn, #deleteBeneBtn, #payBeneBtn, #viewBeneChangesBtn").hide();
      $("#approveBeneBtn, #rejectBeneBtn").show();
    }
  } else if (record.benestatus == "New") {
    if (record.beneworkflow == "Pending Approval - New" || record.beneworkflow == "Pending Approval - Deleted") {
      $("#editBeneBtn, #deleteBeneBtn, #payBeneBtn, #viewBeneChangesBtn").hide();
      $("#approveBeneBtn, #rejectBeneBtn").show();
    } else if (record.beneworkflow == "Creation Rejected" || record.beneworkflow == "Deletion Rejected") {
      $("#approveBeneBtn, #rejectBeneBtn, #viewBeneChangesBtn, #payBeneBtn").hide();
      $("#editBeneBtn, #deleteBeneBtn").show();
    }
  } else if (record.benestatus == "Deleted") {
    $("#approveBeneBtn, #rejectBeneBtn, #viewBeneChangesBtn, #editBeneBtn, #deleteBeneBtn, #payBeneBtn").hide();
  }
}
function setupEditBeneficiary(record) {


  /* load record data into view fields */
  $("#editBeneInformation").scrollTop(0);
  $("#editBeneRecordId").html(record.id);
  $("#editBeneStatus").html(record.beneworkflow);
  $("#editDivisionSelectInput").val(record.division);
  $("#editBeneName").val(record.benename);
  $("#editBeneLocalLanguageName").val(record.benelocalname);
  $("#editBeneNickName").val(record.benenickname);
  $("#editBeneAccountNumber").val(record.beneaccount);
  $("#editBeneAccountType").val(record.benetype);
  $("#editBeneAddress1").val(record.beneaddress1);
  $("#editBeneAddress2").val(record.beneaddress2);
  $("#editBeneAddress3").val(record.beneaddress3);
  $("#editBeneCity").val(record.benecity);
  $("#editBeneCountry").val(record.benecountry);
  $("#editBeneEmail").val(record.beneemail);
  $("#editBeneBankCountry").val(record.benebankcountry);
  if (record.benebankcountry == "Australia") {
    $("#editBeneBankLocalClearingSection").hide();
    $("#editBeneBankSwiftClearingSection, #editSwiftNCCSection").show();
    $("#editBeneSwiftBankClearingCode").val(record.swiftcode);
    $("#editBeneSwiftBankNCCCode").empty();
    var $option = $("<option value='Australia Bank Branch Code'>Australia Bank Branch Code</option>").appendTo($("#editBeneSwiftBankNCCCode"));
    $("#editBeneSwiftBankNCCCode").parent().show();
    $("#editBeneSwiftBankNCCClearingCode").val(record.swiftncc);
    $("#editBeneSwiftBankName").val(record.swiftbank);
    $("#editBeneSwiftBankBranchName").val(record.swiftbranch);
    $("#editBeneSwiftBankBranchAddress1").val(record.swiftbankaddress1);
    $("#editBeneSwiftBankBranchAddress2").val(record.swiftbankaddress2);
    $("#editBeneSwiftBankBranchAddress3").val(record.swiftbankaddress3);
    $("#editBeneSwiftBankBranchCity").val(record.swiftbankcity);
  } else if (record.benebankcountry == "China") {
    $("#editBeneBankLocalClearingSection, #editBeneBankSwiftClearingSection, #editSwiftNCCSection").show();
    $("#editBeneLocalBankNCCCode").empty('').parent().hide();
    $("#editBeneLocalBankClearingCode").val(record.benebankclearingcode);
    $("#editBeneLocalBankName").val(record.benebank);
    $("#editBeneLocalBankBranchName").val(record.benebankbranch);
    $("#editBeneLocalBankBranchAddress1").val(record.benebankaddress1);
    $("#editBeneLocalBankBranchAddress2").val(record.benebankaddress2);
    $("#editBeneLocalBankBranchAddress3").val(record.benebankaddress3);
    $("#editBeneSwiftBankClearingCode").val(record.swiftcode);
    $("#editBeneSwiftBankNCCCode").empty();
    var $option = $("<option value='China National Clearing Code'>China National Clearing Code</option>").appendTo($("#editBeneSwiftBankNCCCode"));
    $("#editBeneSwiftBankNCCCode").parent().show();
    $("#editBeneSwiftBankNCCClearingCode").val(record.swiftncc);
    $("#editBeneSwiftBankName").val(record.swiftbank);
    $("#editBeneSwiftBankBranchName").val(record.swiftbranch);
    $("#editBeneSwiftBankBranchAddress1").val(record.swiftbankaddress1);
    $("#editBeneSwiftBankBranchAddress2").val(record.swiftbankaddress2);
    $("#editBeneSwiftBankBranchAddress3").val(record.swiftbankaddress3);
    $("#editBeneSwiftBankBranchCity").val(record.swiftbankcity);
  } else if (record.benebankcountry == "Hong Kong") {
    $("#editBeneBankLocalClearingSection, #editBeneBankSwiftClearingSection").show();
    $("#editBeneLocalBankNCCCode").empty();
    var $option = $("<option value='China National Clearing Code'>China National Clearing Code</option>").appendTo($("#editBeneLocalBankNCCCode"));
    $("#editBeneLocalBankNCCCode").parent().show();
    $("#editBeneLocalBankClearingCode").val(record.benebankclearingcode);
    $("#editBeneLocalBankName").val(record.benebank);
    $("#editBeneLocalBankBranchName").val(record.benebankbranch);
    $("#editBeneLocalBankBranchAddress1").val(record.benebankaddress1);
    $("#editBeneLocalBankBranchAddress2").val(record.benebankaddress2);
    $("#editBeneLocalBankBranchAddress3").val(record.benebankaddress3);
    $("#editBeneSwiftBankClearingCode").val(record.swiftcode);
    $("#editSwiftNCCSection").hide();
    $("#editBeneSwiftBankNCCCode").empty().parent().hide();
    $("#editBeneSwiftBankNCCClearingCode").val('');
    $("#editBeneSwiftBankName").val(record.swiftbank);
    $("#editBeneSwiftBankBranchName").val(record.swiftbranch);
    $("#editBeneSwiftBankBranchAddress1").val(record.swiftbankaddress1);
    $("#editBeneSwiftBankBranchAddress2").val(record.swiftbankaddress2);
    $("#editBeneSwiftBankBranchAddress3").val(record.swiftbankaddress3);
    $("#editBeneSwiftBankBranchCity").val(record.swiftbankcity);
  } else if (record.benebankcountry == "New Zealand") {
    $("#editBeneBankLocalClearingSection").hide();
    $("#editBeneBankSwiftClearingSection, #editSwiftNCCSection").show();
    $("#editBeneSwiftBankClearingCode").val(record.swiftcode);
    $("#editBeneSwiftBankNCCCode").empty();
    var $option = $("<option value='New Zealand Bank Branch Code'>New Zealand Bank Branch Code</option>").appendTo($("#editBeneSwiftBankNCCCode"));
    $("#editBeneSwiftBankNCCCode").parent().show();
    $("#editBeneSwiftBankNCCClearingCode").val(record.swiftncc);
    $("#editBeneSwiftBankName").val(record.swiftbank);
    $("#editBeneSwiftBankBranchName").val(record.swiftbranch);
    $("#editBeneSwiftBankBranchAddress1").val(record.swiftbankaddress1);
    $("#editBeneSwiftBankBranchAddress2").val(record.swiftbankaddress2);
    $("#editBeneSwiftBankBranchAddress3").val(record.swiftbankaddress3);
    $("#editBeneSwiftBankBranchCity").val(record.swiftbankcity);
  } else if (record.benebankcountry == "Singapore") {
    $("#editBeneBankLocalClearingSection, #editSwiftNCCSection").hide();
    $("#editBeneBankSwiftClearingSection").show();
    $("#editBeneSwiftBankClearingCode").val(record.swiftcode);
    $("#editBeneSwiftBankName").val(record.swiftbank);
    $("#editBeneSwiftBankBranchName").val(record.swiftbranch);
    $("#editBeneSwiftBankBranchAddress1").val(record.swiftbankaddress1);
    $("#editBeneSwiftBankBranchAddress2").val(record.swiftbankaddress2);
    $("#editBeneSwiftBankBranchAddress3").val(record.swiftbankaddress3);
    $("#editBeneSwiftBankBranchCity").val(record.swiftbankcity);
  }
}

/**********************************************************************
BENEFICIARY GRID
**********************************************************************/
var loadRecordTimer;
var dataView,
  grid,
  record = null,
  selectedRowIds = [],
  selectedRowStates = [],
  selectedRowWorkflows = [],
  columns = [{
    id: "id",
    name: "Beneficiaries",
    formatter: renderCell,
    field: "id",
    cssClass: "contact-card-cell",
    type: "preview"
  }];
var checkboxSelector = new Slick.CheckboxSelectColumn({
  cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var options = {
  rowHeight: 70,
  editable: false,
  autoEdit: false,
  enableCellNavigation: true,
  enableColumnReorder: false,
  enableColumnReorderCheckbox: false,
  syncColumnCellResize: false,
  forceFitColumns: true,
  multiSelect: true,
  showHeaderRow: false
};
var groupedSetting = 0,
  groupCollapseSetting = 0;
var compiled_template = tmpl("cell_template");
function renderCell(row, cell, value, columnDef, dataContext) {
  return compiled_template(dataContext);
};
function collapseAllGroups() {
  dataView.beginUpdate();
  for (var i = 0; i < dataView.getGroups().length; i++) {
    if (!dataView.getGroups()[i].collapsed)
      dataView.collapseGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
  }
  dataView.endUpdate();
}
function expandAllGroups() {
  for (var i = 0; i < dataView.getGroups().length; i++) {
    dataView.expandGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
  }
}
function clearGrouping() {
  dataView.groupBy(null);
  groupedSetting = 0;
}
function groupBy(item, text) {
  dataView.groupBy(
    item,
    function(g) {
      return text + ":  " + g.value + "  <span>(" + g.count + " items)</span>";
    },
    function(a, b) {
      var x = a.value
      var y = b.value;
      return (x == y ? 0 : (x > y ? 1 : -1));
    }
  );
  if (groupCollapseSetting == 1) {
    collapseAllGroups();
  }
  groupedSetting = 1;
}
var folderString = "",
  searchString = "",
  statusString = "Active New",
  workflowString = "",
  searchPoint = "beneaccount";
function myFilter(item, args) {

  if (args.folderString != "" && item["folderid"] != args.folderString)
    return false;

  if (args.statusString != "" && args.statusString.toLowerCase().indexOf(item["benestatus"].toLowerCase()) == -1)
    return false;

  if (args.workflowString != "" && item["beneworkflow"].toLowerCase().indexOf(args.workflowString.toLowerCase()) == -1)
    return false;

  if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1)
    return false;

  return true;
}
function filterBeneficiaries() {
  dataView.refresh();
  grid.invalidate();
  grid.render();
  if (groupCollapseSetting == 1) {
    collapseAllGroups();
  }
}
function viewFilter() {
  var rows = grid.getSelectedRows();
  folderString = "";
  if (rows.length > 0) {
    grid.setSelectedRows(0);
  }
  dataView.setFilterArgs({
    folderString: folderString,
    statusString: statusString,
    workflowString: workflowString,
    searchString: searchString
  });
  filterBeneficiaries();
}
function folderFilter() {
  var rows = grid.getSelectedRows();
  statusString = "";
  workflowString = "";
  if (rows.length > 0) {
    grid.setSelectedRows(0)
  }
  dataView.setFilterArgs({
    folderString: folderString,
    statusString: statusString,
    workflowString: workflowString,
    searchString: searchString
  })
  filterBeneficiaries();
}
function findBeneficiaries() {
  var rows = grid.getSelectedRows();
  if (rows.length > 0) {
    grid.setSelectedRows(0)
  };
  dataView.setFilterArgs({
    folderString: folderString,
    statusString: statusString,
    workflowString: workflowString,
    searchString: searchString
  });
  dataView.refresh();
}



/**********************************************************************
CONTEXT MENU SETUP
**********************************************************************/
function checkStatus(arr) {
  var L = arr.length - 1;
  while (L) {
    if (arr[L--] !== arr[L]) return false;
  }
  return arr[L];
}
function checkWorkflow(arr, text) {
  var L = arr.length - 1;
  while (L) {
    if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
      return false
    }
  }
  return arr[L]
}
var enableContextItem = function() {
  $(this).children("div.disabled").remove();
  $(this).children("a").show();
};
var disableContextItem = function() {
  if ($(this).children("div.disabled").size()) {
    $(this).children("div.disabled").remove();
  }
  var $a = $(this).children("a"),
    $div = $("<div class='disabled' />"),
    content = $a.html();
  $a.hide();
  $div.html(content).appendTo($(this));
};
function setupContextMenu(record) {
  var sel = selectedRowIds.length,
    $contextItems = $("[data-type='context-item']"),
    statusValue = "",
    workflowValue = "";
  if (record != null) {
    selectedRowStates.push(record.benestatus);
    selectedRowWorkflows.push(record.beneworkflow);
    sel = 1;
  }
  if (!sel) {
    $contextItems.each(disableContextItem);
  } else {
    statusValue = checkStatus(selectedRowStates);
    workflowValue = checkWorkflow(selectedRowWorkflows, "Pending");
    if (sel == 1) {
      if (statusValue == "Active") {
        if (workflowValue == "Pending Approval - Modified") {
          $("[data-action='view'], [data-action='copy'], [data-action='delete'], [data-action='approve'], [data-action='reject'], [data-action='pay'], [data-action='move']").each(enableContextItem);
          $("[data-action='edit']").each(disableContextItem);
        } else if (workflowValue == "Pending Approval - Deleted") {
          $("[data-action='view'], [data-action='copy'], [data-action='approve'], [data-action='reject'], [data-action='pay'], [data-action='move']").each(enableContextItem);
          $("[data-action='edit'], [data-action='delete']").each(disableContextItem);
        } else {
          $("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='pay'], [data-action='move']").each(enableContextItem);
          $("[data-action='approve'], [data-action='reject']").each(disableContextItem);
        }
      } else if (statusValue == "New") {
        if (workflowValue == "Pending Approval - New" || workflowValue == "Pending Approval - Deleted") {
          $("[data-action='view'], [data-action='approve'], [data-action='reject'], [data-action='copy']").each(enableContextItem);
          $("[data-action='edit'], [data-action='delete'], [data-action='pay'], [data-action='move']").each(disableContextItem);
        } else {
          $("[data-action='view'], [data-action='edit'], [data-action='delete'], [data-action='copy']").each(enableContextItem);
          $("[data-action='approve'], [data-action='reject'], [data-action='pay'], [data-action='move']").each(disableContextItem);
        }
      } else if (statusValue == "Deleted") {
        $("[data-action='view'], [data-action='copy']").each(enableContextItem);
        $("[data-action='edit'], [data-action='approve'], [data-action='delete'], [data-action='reject'], [data-action='pay'], [data-action='move']").each(disableContextItem);
      }
    } else {
      if (!statusValue) {
        if (selectedRowStates.indexOf("New") > -1 && selectedRowStates.indexOf("Active") > -1 && selectedRowStates.indexOf("Deleted") == -1) {
          if (selectedRowWorkflows.indexOf("Pending Approval - Deleted") > -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") > -1 && selectedRowWorkflows.indexOf("Pending Approval - New") > 1 && selectedRowWorkflows.indexOf("Approved") == -1 && selectedRowWorkflows.indexOf("Changes Rejected") == -1 && selectedRowWorkflows.indexOf("Deletion Rejected") == -1 && selectedRowWorkflows.indexOf("Creation Rejected") == -1) {
            $("[data-action='approve'], [data-action='reject']").each(enableContextItem);
            $("[data-action='view'], [data-action='copy'], [data-action='delete'], [data-action='edit'], [data-action='pay'], [data-action='move']").each(disableContextItem);
          } else if (selectedRowWorkflows.indexOf("Creation Rejected") > -1 && selectedRowWorkflows.indexOf("Changes Rejected") > -1 && selectedRowWorkflows.indexOf("Deletion Rejected") > -1 && selectedRowWorkflows.indexOf("Pending Approval - Deleted") == -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") == -1 && selectedRowWorkflows.indexOf("Pending Approval - New") == -1 && selectedRowWorkflows.indexOf("Approved") == -1) {
            $("[data-action='delete']").each(enableContextItem);
            $("[data-action='view'], [data-action='copy'], [data-action='approve'], [data-action='reject'], [data-action='edit'], [data-action='pay'], [data-action='move']").each(disableContextItem);
          } else if (selectedRowWorkflows.indexOf("Creation Rejected") > -1 && selectedRowWorkflows.indexOf("Changes Rejected") > -1 && selectedRowWorkflows.indexOf("Deletion Rejected") > -1 && selectedRowWorkflows.indexOf("Pending Approval - Deleted") > -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") > -1 && selectedRowWorkflows.indexOf("Pending Approval - New") > -1 && selectedRowWorkflows.indexOf("Approved") > -1) {
            $contextItems.each(disableContextItem);
          }
          $("[data-action='move']").each(disableContextItem);
        }
      } else if (statusValue == "Active") {
        if (workflowValue == "Pending Approval - Modified") {
          $("[data-action='approve'], [data-action='reject'], [data-action='delete'], [data-action='move']").each(enableContextItem);
          $("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='pay']").each(disableContextItem);
        } else if (workflowValue == "Pending Approval - Deleted") {
          $("[data-action='approve'], [data-action='reject'], [data-action='move']").each(enableContextItem);
          $("[data-action='view'], [data-action='copy'], [data-action='delete'], [data-action='edit'], [data-action='pay']").each(disableContextItem);
        } else {
          if (selectedRowWorkflows.indexOf("Pending Approval - Deleted") > -1) {
            $("[data-action='move']").each(enableContextItem);
            $("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='approve'], [data-action='reject'], [data-action='pay']").each(disableContextItem);
          } else {
            $("[data-action='delete'], [data-action='move']").each(enableContextItem);
            $("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='approve'], [data-action='reject'], [data-action='pay']").each(disableContextItem);
          }
          if (selectedRowWorkflows.indexOf("Pending Approval - Deleted") > -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") > -1 && selectedRowWorkflows.indexOf("Approved") == -1 && selectedRowWorkflows.indexOf("Changes Rejected") == -1 && selectedRowWorkflows.indexOf("Deletion Rejected") == -1) {
            $("[data-action='approve'], [data-action='reject'], [data-action='move']").each(enableContextItem);
            $("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='pay']").each(disableContextItem);
          }
        }
      } else if (statusValue == "New") {
        if (workflowValue == "Pending Approval - New" || workflowValue == "Pending Approval - Deleted") {
          $("[data-action='approve'], [data-action='reject']").each(enableContextItem);
          $("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='pay'], [data-action='move']").each(disableContextItem);
        } else if (workflowValue == "Creation Rejected") {
          $("[data-action='delete']").each(enableContextItem);
          $("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='approve'], [data-action='reject'], [data-action='pay'], [data-action='move']").each(disableContextItem);
        } else if (!workflowValue) {
          $contextItems.each(disableContextItem);
        }
      } else if (statusValue == "Deleted") {
        $contextItems.each(disableContextItem);
      }
    }
  }
}



/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var user_bene_folders = [], folders_updated = false, folders_deleted = false;
var $folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Beneficiaries</p><p style='font-size: 14px;'>Folders help you keep your beneficiaries organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move beneficiaries by selecting them in the grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-th-list fa-fw'></i> View Menu.</p></div>");
var $folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if (store.get('bene_folder_store')) {
  user_bene_folders = store.get('bene_folder_store')
};
function folderChecker(val) {
  var _folder = val,
    error = false,
    $folderList = $(".folder-list").children("li"),
    existingFolders = [];
  for (var i = 0; i < $folderList.length; i++) {
    existingFolders.push($folderList.eq(i).attr("data-folder"));
  }
  if ($.inArray(_folder, existingFolders) != -1) {
    error = "existing"
  }
  return error;
}
function renameFolder(el) {
  var newFolderName = $.trim(el.val());
  if (newFolderName == '' || newFolderName == "undefined") {
    el.val(el.attr("data-folder-name"));
  } else {
    el.val(newFolderName);
    el.closest("li").attr("data-folder", newFolderName);
    folders_updated = true;
  }
}
function addFolder() {
  var folderName = $.trim($("#newFolderInput").val()),
    $folderList = $("ul.folder-list"),
    $newFolderDiv = $("div.new-folder"),
    $li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
  if (folderName == '' || folderName == "undefined") {
    $("#newFolderInput").val('');
    return false;
  } else {
    if (folderCheck == "existing") {
      $newFolderDiv.addClass("error");
      $("#newFolderInput").focus().select().one("keyup.remove-error", function() {
        $newFolderDiv.removeClass("error");
      });
    } else {
      if ($newFolderDiv.hasClass("error")) {
        $newFolderDiv.removeClass("error");
      }
      if ($(".folder-message").size()) {
        $(".folder-message").remove();
        $folderListInstruction.insertBefore($folderList);
      }
      $li = $("<li data-folder='" + folderName + "' data-folder-id='" + randString() + "' class='row new' />").appendTo($folderList);
      $div = $("<div class='folder-row data-column' />").appendTo($li);
      $span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
      $input = $("<input type='text' value='" + folderName + "' maxlength='25' data-folder-name='" + folderName + "' />").on("change", function() {
        renameFolder($(this));
      }).appendTo($div);
      $a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
      $error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
      $("#newFolderInput").val('');
      $folderList.sortable("refresh");
      folders_updated = true;
    }
  }
}
function addFolderInline() {
  var folderName = $.trim($("#_inlineFolderInput").val()),
    folderExists = false;
  if (folderName == '' || folderName == "undefined") {
    $("#_inlineFolderInput").val('');
    return false;
  } else {
    for (var i = 0; i < user_bene_folders.length; i++) {
      if (folderName == user_bene_folders[i].name) {
        folderExists = true;
        break;
      }
    }
    if (folderExists) {
      alert("A folder with that name already exists.");
    } else {
      var _id = randString();
      var _new = {
        name: folderName,
        id: _id
      };
      user_bene_folders.push(_new);
      populateFolders();
      store.set('bene_folder_store', user_bene_folders);
      $("#_inlineFolderInput").val('');
      moveBeneficiary(_id);
    }
  }
}
function deleteFolder(e) {
  e.preventDefault();
  var $target = $(this).closest("li");
  $target.hide('fast', function() {
    if (!$target.hasClass('new')) {
      folders_deleted = true;
    }
    $target.remove();
    $(".folder-list").sortable("refresh");
    folders_updated = true;
    if (!$(".folder-list").children("li").size()) {
      $(".folder-list-instructions").remove();
      $folderMessage.appendTo(".folder-settings");
    }
    if ($("div.new-folder").hasClass("error")) {
      $("div.new-folder").removeClass("error");
    }
  });
}
function populateFolders() {
  var $assignFolders = $(".assign-folders"),
    folderCount = user_bene_folders.length,
    activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
  $assignFolders.children().remove();
  if ($("#removeFromFolder").size() > 0) {
    $("#removeFromFolder").remove();
  }
  if (folderCount > 0) {
    var $li, $a
    $assignFolders.each(function() {
      var _this = $(this);
      if (_this.parents().attr("id") == "folderMenu") {
        $.each(user_bene_folders, function() {
          $li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' />").appendTo(_this);
          $a = $("<a href='javascript:void(0)' title='" + this.name + "' data-folder='" + this.name + "' data-folder-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
            e.preventDefault();
            moveBeneficiary($(this).attr("data-folder-id"));
          }).appendTo($li);
        });
        var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
          $spacer = $("<li class='menu-section' />").appendTo($ul),
          $li = $("<li />").appendTo($ul),
          $a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected beneficiaries from a folder' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
            e.preventDefault();
            moveBeneficiary($(this).attr("data-folder-id"));
          }).appendTo($li),
          $spacer = $("<li class='menu-section' />").appendTo($ul);
      } else if (_this.parents().attr("id") == "viewMenu") {
        $.each(user_bene_folders, function() {
          $li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' />").appendTo(_this);
          if (this.id == activeFolder) {
            $li.addClass("active");
            $("#viewMenuControl").children("a").children("span").html(this.name);
          }
          $a = $("<a href='javascript:void(0)' title='" + this.name + "' data-folder='" + this.name + "' data-folder-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
            e.preventDefault();
            var _folderID = $(this).attr("data-folder-id"),
              _folderName = $(this).attr("data-folder");
            if (folderString != _folderID) {
              folderString = _folderID;
            }
            folderFilter();
            $("#selectedFolder").html(_folderName);
          }).appendTo($li);
        });
      }
    });
  } else {
    var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
      $li = $("<li class='no-set' />").appendTo($viewMenu),
      $a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Folders</div>Folders help keep your data organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
  }
}
function populateFolderManager() {
  folders_updated = false;
  folders_deleted = false;
  var $folderSettings = $("<div class='folder-settings' />"),
    $folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
    $folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
    $folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e) {
      if (e.keyCode == 13) {
        addFolder()
      }
    }).appendTo($folderAddDiv),
    $folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
    $folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
    $folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({
      handle: '.reorder-folder',
      axis: 'y',
      tolerance: "pointer",
      update: function(event, ui) {
        folders_updated = true
      }
    }),
    folderCount = user_bene_folders.length,
    $li, $div, $span, $input, $a, $error;
  if (folderCount > 0) {
    $folderListInstruction.insertBefore($folderList);
    $.each(user_bene_folders, function() {
      $li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' class='row' />").appendTo($folderList);
      $div = $("<div class='folder-row data-column' />").appendTo($li);
      $span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
      $input = $("<input type='text' maxlength='25' value='" + this.name + "' data-folder-name='" + this.name + "' />").on("change", function() {
        renameFolder($(this));
      }).appendTo($div);
      $a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
      $error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
    });
  } else {
    $folderMessage.appendTo($folderSettings);
  }
  return $folderSettings;
}
function showFolderManagerDialog(e) {
  e.preventDefault();
  var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
  var _dialog = {
    id: "folderManager",
    title: "Manage Beneficiary Folders",
    size: "medium",
    icon: "<i class='fa fa-folder-open'></i>",
    content: function() {
      return populateFolderManager()
    },
    buttons: [{
      name: "Cancel",
      icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          dialogHider(_dialog)
        }
      }]
    }, {
      name: "Ok",
      icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          updateFolders(_dialog)
        }
      }],
      cssClass: "primary"
    }]
  }
  dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveFolders(dialog) {
  var $dialog = $("#" + dialog.id),
    $active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
  $dialog.addClass("working");
  user_bene_folders = folders_updated;

  var active_deleted = true;

  for (f = 0; f < user_bene_folders.length; f++) {
    if ($active == user_bene_folders[f].id) {
      active_deleted = false;
      break;
    }
  }

  for (var i = 0; i < data.length; i++) {
    var _resetFolder = true;
    for (var n = 0; n < user_bene_folders.length; n++) {
      if (data[i].folderid == user_bene_folders[n].id) {
        data[i].folder = user_bene_folders[n].name;
        _resetFolder = false;
        break;
      }
    }
    if (_resetFolder) {
      data[i].folder = "None";
      data[i].folderid = "None";
    }

  }
  folders_updated = false;
  folders_deleted = false;
  store.set('bene_folder_store', user_bene_folders);
  setTimeout(function() {
    dataView.refresh();
    grid.invalidate();
    grid.render();
    populateFolders();
    if (!user_bene_folders.length || active_deleted) {
      $("#allActiveBeneficiaries").trigger("click");
    }
    dialogHider(dialog);
  }, 300);
}
function updateFolders(dialog) {
  if (folders_updated) {
    folders_updated = [];
    var duplicate_names = false,
      $folderList = $(".folder-list");
    $folderList.find("li.error").removeClass("error");
    $folderList.children("li").each(function() {
      folders_updated.push({
        "name": $(this).attr("data-folder"),
        "id": $(this).attr("data-folder-id")
      });
      var _name = $(this).attr("data-folder");
      $(this).siblings().each(function() {
        if ($(this).attr("data-folder") == _name) {
          $(this).addClass("error");
        }
      });
    });
    if ($folderList.find("li.error").size()) {
      duplicate_names = true;
    }
    if (duplicate_names) {
      return false;
    } else {
      var save_folders = false;
      if (user_bene_folders.length != folders_updated.length) {
        save_folders = true;
      } else {
        for (var i = 0; i < user_bene_folders.length; i++) {
          if (user_bene_folders[i].name != folders_updated[i].name || user_bene_folders[i].id != folders_updated[i].id) {
            save_folders = true;
            break;
          }
        }
      }
      if (save_folders || folders_deleted) {
        if (folders_deleted) {
          buildConfirmDialog("You've removed some existing folders.", "Are you sure you want to continue?", function() {
            saveFolders(dialog)
          });
        } else {
          saveFolders(dialog)
        }
      } else {
        dialogHider(dialog);
      }
    }
  } else {
    dialogHider(dialog)
  }
}
function moveBeneficiary(_id) {
  var _folder, _message, _rowsForUpdate = [],
    _sel = selectedRowIds.length;
  for (var i = 0; i < user_bene_folders.length; i++) {
    if (user_bene_folders[i].id == _id) {
      _folder = user_bene_folders[i];
      _message = "Selected beneficiaries were moved to &quot;" + _folder.name + "&quot;";
      break;
    }
  }
  if (_id == "None") {
    _folder = [{
      name: "None",
      id: "None"
    }];
    _message = "Selected beneficiaries were removed from their folders";
  }
  for (var i = 0, l = _sel; i < l; i++) {
    var _item = selectedRowIds[i];
    if (_item) {
      _rowsForUpdate.unshift(_item);
    }
  }
  for (var i = 0; i < _rowsForUpdate.length; i++) {
    data[dataView.getIdxById(_rowsForUpdate[i])].folder = _folder.name;
    data[dataView.getIdxById(_rowsForUpdate[i])].folderid = _folder.id;
  }
  grid.setSelectedRows(0);
  selectedRowIds = [];
  dataView.refresh();
  grid.invalidate();
  grid.render();
  if (groupCollapseSetting == 1) {
    collapseAllGroups();
  }
  groupedSetting = 1;
  buildNotification(_message, 300, 3000);
  store.set('beneficiaryBook', dataView.getItems());
  $("#viewMenu .assign-folders").find("a[data-folder-id='" + _folder.id + "']").trigger("click");
}



/**********************************************************************
RECORD ACTIONS
**********************************************************************/
function createNewBeneficiary(e) {
  e.preventDefault();

  clearFormElements("newBeneSection");
  clearFormElements("newBeneBankSection");
  $("#beneNew").find("div.error").removeClass("error");
  $("#beneNew").find("div.data-error").remove();
  $("#newBeneBankLocalClearingSection, #newBeneBankSwiftClearingSection, #swiftNCCSection").hide();


  var $target = $(e.target);
  $target.attr({
    'data-panel': '#beneNew',
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  grid.setSelectedRows(0);
  selectedRowIds = [];
  trackviewmode = false;
  record = null;
  setupNewBeneficiary();
}
function closeNewBeneficiary(e) {
  e.preventDefault();
  var $target = $(e.target);
  $target.attr({
    'data-panel': '#beneList',
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  trackviewmode = false;
  record = null;
}
function saveNewBeneficiary(e) {
  e.preventDefault();
  var _passed = true;
  if (!$("#newBeneName").val()) {
    var $row = $("#newBeneName").closest("div.row");
    var $col = $("#newBeneName").closest("div.data-column");
    $row.addClass("error");
    if ($col.find("div.data-error").size() == 0) {
      var $message = $("<div class='data-error'>Beneficiary Name is mandatory</div>").appendTo($col);
    }
    _passed = false;
  } else {
    var $row = $("#newBeneName").closest("div.row");
    $row.removeClass("error").find("div.data-error").remove();
  }
  if (!$("#newBeneNickName").val()) {
    var $row = $("#newBeneNickName").closest("div.row");
    var $col = $("#newBeneNickName").closest("div.data-column");
    $row.addClass("error");
    if ($col.find("div.data-error").size() == 0) {
      var $message = $("<div class='data-error'>Beneficiary Nick Name is mandatory</div>").appendTo($col);
    }
    _passed = false;
  } else {
    var $row = $("#newBeneNickName").closest("div.row");
    $row.removeClass("error").find("div.data-error").remove();
  }
  if (!$("#newBeneAccountNumber").val()) {
    var $row = $("#newBeneAccountNumber").closest("div.row");
    var $col = $("#newBeneAccountNumber").closest("div.data-column");
    $row.addClass("error");
    if ($col.find("div.data-error").size() == 0) {
      var $message = $("<div class='data-error'>Account Number is mandatory</div>").appendTo($col);
    }
    _passed = false;
  } else {
    var $row = $("#newBeneAccountNumber").closest("div.row");
    $row.removeClass("error").find("div.data-error").remove();
  }
  if (!$("#newBeneBankCountry").val()) {
    var $row = $("#newBeneBankCountry").closest("div.row");
    var $col = $("#newBeneBankCountry").closest("div.data-column");
    $row.addClass("error");
    if ($col.find("div.data-error").size() == 0) {
      var $message = $("<div class='data-error'>Country is mandatory</div>").appendTo($col);
    }
    _passed = false;
  } else {
    var $row = $("#newBeneBankCountry").closest("div.row");
    $row.removeClass("error").find("div.data-error").remove();
  }
  if (_passed) {
    var $target = $(e.target);
    var bene = {
      id: randString(10),
      beneid: randString(6),
      benename: $("#newBeneName").val(),
      benelocalname: $("#newBeneLocalLanguageName").val(),
      benenickname: $("#newBeneNickName").val(),
      benetype: $("#newBeneAccountType").val(),
      beneaccount: $("#newBeneAccountNumber").val(),
      beneaccountccy: "AUD",
      beneaddress1: $("#newBeneAddress1").val(),
      beneaddress2: $("#newBeneAddress2").val(),
      beneaddress3: $("#newBeneAddress3").val(),
      benecity: $("#newBeneCity").val(),
      benepostal: "3000",
      benecountry: $("#newBeneCountry").val(),
      benephone: "+61 3 5555 5555",
      benefax: "+61 3 5555 5555",
      beneemail: $("#newBeneEmail").val(),
      benebank: $("#newBeneLocalBankName").val(),
      benebanklocalname: "",
      benebankbranch: $("#newBeneLocalBankBranchName").val(),
      benebankaddress1: $("#newBeneLocalBankBranchAddress1").val(),
      benebankaddress2: $("#newBeneLocalBankBranchAddress2").val(),
      benebankaddress3: $("#newBeneLocalBankBranchAddress3").val(),
      benebankpostal: "",
      benebankcity: "",
      benebankcountry: $("#newBeneBankCountry").val(),
      benebankclearingtype: $("#newBeneLocalBankNCCCode").val(),
      benebankclearingcode: $("#newBeneLocalBankClearingCode").val(),
      swiftbank: $("#newBeneSwiftBankName").val(),
      swiftbanklocalname: "",
      swiftbranch: $("#newBeneSwiftBankBranchName").val(),
      swiftbankaddress1: $("#newBeneSwiftBankBranchAddress1").val(),
      swiftbankaddress2: $("#newBeneSwiftBankBranchAddress2").val(),
      swiftbankaddress3: $("#newBeneSwiftBankBranchAddress3").val(),
      swiftbankpostal: "",
      swiftbankcity: $("#newBeneSwiftBankBranchCity").val(),
      swiftbankcountry: $("#newBeneBankCountry").val(),
      swiftcode: $("#newBeneSwiftBankClearingCode").val(),
      benestatus: "New",
      beneworkflow: "Pending Approval - New",
      benedivision: "Customer Division 1",
      entrymethod: "Online",
      folder: "None",
      folderid: "None",
      audit: [],
      enteredby: "Test User",
      enteredon: smartDates("randompast") + " at " + timeFormatter(),
      lastupdateby: "Test User",
      lastupdate: smartDates("yesterday") + " at " + timeFormatter(),
      approvedby: "",
      approvedon: "",
      rejectedby: "",
      rejectedon: "",
      deletedby: "",
      deletedon: ""
    }
    _tbos_beneficiary_accounts.push(bene);
    dataView.refresh();
    grid.invalidate();
    grid.render();
    store.set('beneficiaryBook', data);
    $target.attr({
      'data-panel': '#beneList',
      'data-switch': 'switch-panels'
    }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
    trackviewmode = false;
    buildNotification("Beneficiary record has been submitted successfully.", 700, 5000);
  } else {
    return false;
  }
}
function viewRecord(e) {
  e.preventDefault();
  var $target = $(e.target);
  $target.attr({
    'data-panel': '#beneDetail',
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  record = dataView.getItem(grid.getActiveCell().row);
  setupViewBeneficiary(record);
  grid.setSelectedRows(0);
  selectedRowIds = [];
}
function closeViewRecord(e) {
  e.preventDefault();
  var $target = $(e.target);
  $target.attr({
    'data-panel': '#beneList',
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  trackviewmode = false;
  record = null;
}
function editRecord(e) {
  e.preventDefault();
  var $target = $(e.target);
  $target.attr({
    'data-panel': '#beneEdit',
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  if (!record || record == null) {
    record = dataView.getItem(grid.getActiveCell().row);
  }
  setupEditBeneficiary(record);
  grid.setSelectedRows(0);
  selectedRowIds = [];
}
function resetEditRecord(e) {
  e.preventDefault();
  setupEditBeneficiary(record);
}
function cancelEditRecord(e) {
  e.preventDefault();
  var $target = $(e.target);
  var backto = (trackviewmode == true) ? "#beneDetail" : "#beneList";
  $target.attr({
    'data-panel': backto,
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  if (trackviewmode) {
    setupViewBeneficiary(record);
  } else {
    trackviewmode = false;
    record = null;
  }
}
function saveRecord(e) {
  e.preventDefault();
  var bene = dataView.getItemById(record.id);
  if (record.beneworkflow == "Creation Rejected" || record.beneworkflow == "Deletion Rejected") {
    bene.benestatus = "New";
    bene.beneworkflow = "Pending Approval - New";
  } else if (record.beneworkflow == "Approved") {
    bene.benestatus = "Active";
    bene.beneworkflow = "Pending Approval - Modified";
  }
  bene.lastupdateby = "Prototype User 99";
  bene.lastupdate = smartDates("today") + " at " + timeFormatter();
  bene.benename = $("#editBeneName").val();
  bene.beneaccount = $("#editBeneAccountNumber").val();
  bene.beneaccountccy = $("#editBeneAccountCCY").val();
  bene.address1 = $("#editBeneAddress1").val();
  bene.address2 = $("#editBeneAddress2").val();
  bene.address3 = $("#editBeneAddress3").val();
  bene.state = $("#editBeneState").val();
  bene.postal = $("#editBenePostal").val();
  bene.country = $("#editBeneCountry").val();
  bene.fax = $("#editBeneFax").val();
  bene.phone = $("#editBenePhone").val();
  bene.email = $("#editBeneEmail").val();
  bene.benebank = $("#editBeneBankName").val();
  bene.benebankaddress1 = $("#editBeneBankAddress1").val();
  bene.benebankaddress2 = $("#editBeneBankAddress2").val();
  bene.benebankaddress3 = $("#editBeneBankAddress3").val();
  bene.benebankpostal = $("#editBeneBankState").val();
  bene.benebankstate = $("#editBeneBankPostal").val();
  bene.benebankcountry = $("#editBeneBankCountry").val();
  bene.benebankbranch = $("#editBeneBankBranch").val();
  bene.benebankswift = $("#editBeneBankSwift").val();
  bene.benebankclearing = $("#editBeneBankClearing").val();
  dataView.refresh();
  grid.invalidate();
  grid.render();
  store.set('beneficiaryBook', data);
  var $target = $(e.target);
  $target.attr({
    'data-panel': '#beneDetail',
    'data-switch': 'switch-panels'
  }).trigger('click.switch-panels').removeAttr("data-panel data-switch");
  setupViewBeneficiary(bene);
  buildNotification("The beneficiary record for <strong>" + bene.benename + " (" + bene.beneid + ")</strong> has been modified and is now pending approval.", 500, 5000);
}
function deleteRecords() {
  $("body").addClass("loading");
  $(".header, .shell").find(":focusable").attr("tabindex", -1);
  var sel = selectedRowIds.length,
    bene,
    msg;
  if (!sel || sel == 1) {
    bene = record != null ? dataView.getItemById(record.id) : data[dataView.getIdxById(selectedRowIds[0])];
    msg = "The beneficiary record for <strong>" + bene.benename + " (" + bene.beneid + ")</strong> has been submitted for deletion."
    setTimeout(function() {
      $("body").removeClass("loading");
      $(".header, .shell").find(":focusable").removeAttr("tabindex");
      bene.beneworkflow = "Pending Approval - Deleted";
      bene.deletedby = "Prototype User 101";
      bene.deletedon = smartDates("today") + " at " + timeFormatter();
      dataView.refresh();
      grid.invalidate();
      grid.render();
      grid.setSelectedRows([]);
      store.set('beneficiaryBook', data);
      if (record != null) {
        setupViewBeneficiary(bene);
      }
      buildNotification(msg, 500, 5000);
    }, 1500);
  } else if (sel > 1) {
    var reloadBeneficiaryList = function() {
      store.set('beneficiaryBook', data);
      setTimeout(function() {
        $("body").removeClass("loading");
        $(".header, .shell").find(":focusable").removeAttr("tabindex");
        dataView.refresh();
        grid.invalidate();
        grid.render();
        grid.setSelectedRows([]);
        buildNotification(msg, 500, 5000);
      }, 1500);
    }
    for (var i = 0; i < selectedRowIds.length; i++) {
      data[dataView.getIdxById(selectedRowIds[i])].beneworkflow = "Pending Approval - Deleted";
      data[dataView.getIdxById(selectedRowIds[i])].deletedby = "Prototype User 101";
      data[dataView.getIdxById(selectedRowIds[i])].deletedon = smartDates("today") + " at " + timeFormatter();
    }
    msg = "Selected beneficiary records have been submitted for deletion.";
    reloadBeneficiaryList();
  }
}
function deleteRecordConfirmation(e) {
  e.preventDefault();
  var sel = selectedRowIds.length;
  var msg = sel > 1 ? "Selected beneficiary records will be submitted for deletion." : "Selected beneficiary record will be submitted for deletion.";
  buildConfirmDialog(msg, "Do you want to continue?", function() {
    deleteRecords();
  });
}
function viewImpactedPayments(e) {
  e.preventDefault();

  var $target = $(e.target),
    beneName = $target.attr("data-beneficiary"),
    beneStatus = $target.attr("data-status"),
    dialogMessage = (beneStatus.indexOf("Deleted") != -1) ? "Upon approval, this beneficiary (" + beneName + ") will be deleted from your address book and the following payments containing this beneficiary <strong>will be moved</strong> into a &quot;Needs Repair&quot; status. The beneficiary will continue to remain in these payments." : "Upon approval, this beneficiary (" + beneName + ") <strong>will be automatically updated</strong> in the following payments:";

  var impactedPaymentData = function() {
    var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
      $p = $("<p>" + dialogMessage + "</p>").appendTo($dialogContent),
      $tableDiv = $("<div style='margin-top: 20px;'>").appendTo($dialogContent),
      $dataTable = $("<div class='data-table' />").appendTo($tableDiv),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment ID</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Beneficiary / Payment Name</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment Type</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>Value Date</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Status</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Draft</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Draft</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Draft</div>").appendTo($dataTableRow),

      $noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
      $note = $("<p><strong>NOTE:</strong><br />The records above have been identified based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".<br />Access to view the above records will be based on your entitlements.</p>").appendTo($noteDiv);
    return $dialogContent;
  }

  var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

  var _dialog = {
    id: "impactedPayments",
    title: "Impact Summary for " + beneName,
    size: "xxl",
    icon: "<i class='fa fa-info-circle'></i>",
    content: function() {
      return impactedPaymentData()
    },
    buttons: [{
      name: "Close",
      icon: "<i class='fa fa-times-circle fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          dialogHider(_dialog)
        }
      }]
    }]
  }

  dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function viewNonImpactedPayments(e) {
  e.preventDefault();

  var $target = $(e.target),
    beneName = $target.attr("data-beneficiary"),
    beneStatus = $target.attr("data-status"),
    dialogMessage = (beneStatus.indexOf("Deleted") != -1) ? "This beneficiary (" + beneName + ") <strong>will not be removed</strong> from the following payments. Please consider removing the beneficiary from these payments manually." : "This beneficiary (" + beneName + ") <strong>will not be updated</strong> in the following payments because the payments have been partially approved or have been sent to the bank. Please consider updating these payments manually.";

  var nonImpactedPaymentData = function() {
    var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
      $p = $("<p>" + dialogMessage + "</p>").appendTo($dialogContent),
      $tableDiv = $("<div style='margin-top: 20px;'>").appendTo($dialogContent),
      $dataTable = $("<div class='data-table' />").appendTo($tableDiv),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment ID</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Beneficiary / Payment Name</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment Type</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>Value Date</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
      $noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
      $note = $("<p><strong>NOTE:</strong><br />The records above have been identified based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".<br />Access to view the above records will be based on your entitlements.</p>").appendTo($noteDiv);
    return $dialogContent;
  }

  var $target = $(e.target),
    beneName = $target.attr("data-beneficiary");

  var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

  var _dialog = {
    id: "nonImpactedPayments",
    title: "Impact Summary for " + beneName,
    size: "xxl",
    icon: "<i class='fa fa-info-circle'></i>",
    content: function() {
      return nonImpactedPaymentData()
    },
    buttons: [{
      name: "Close",
      icon: "<i class='fa fa-times-circle fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          dialogHider(_dialog)
        }
      }]
    }]
  }

  dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function viewImpactedTemplates(e) {
  e.preventDefault();

  var $target = $(e.target),
    beneName = $target.attr("data-beneficiary"),
    beneStatus = $target.attr("data-status"),
    dialogMessage = (beneStatus.indexOf("Deleted") != -1) ? "Upon approval, this beneficiary (" + beneName + ") <strong>will be automatically removed</strong> from the following templates:" : "Upon approval, this beneficiary (" + beneName + ") <strong>will be automatically updated</strong> in the following templates:";

  var impactedTemplateData = function() {
    var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
      $p = $("<p>" + dialogMessage + "</p>").appendTo($dialogContent),
      $tableDiv = $("<div style='margin-top: 20px;'>").appendTo($dialogContent),
      $dataTable = $("<div class='data-table' />").appendTo($tableDiv),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template ID</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template Name</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Payment Type</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Status</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>lGMDjZMDKOTMP</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template - GTF</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Domestic Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Draft</div>").appendTo($dataTableRow),
      $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>KpldUSpockTMP</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template - EiT</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>International Payment</div>").appendTo($dataTableRow),
      $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Draft</div>").appendTo($dataTableRow),
      $noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
      $note = $("<p><strong>NOTE:</strong><br />The records above have been identified based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".<br />Access to view the above records will be based on your entitlements.</p>").appendTo($noteDiv);
    return $dialogContent;
  }

  var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

  var _dialog = {
    id: "impactedTemplates",
    title: "Impact Summary for " + beneName,
    size: "xxl",
    icon: "<i class='fa fa-info-circle'></i>",
    content: function() {
      return impactedTemplateData()
    },
    buttons: [{
      name: "Close",
      icon: "<i class='fa fa-times-circle fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          dialogHider(_dialog)
        }
      }]
    }]
  }

  dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
var reloadBeneficiaryDetails = function() {
  $("body").addClass("loading");
  $(".header, .shell").find(":focusable").attr("tabindex", -1);
  setTimeout(function() {
    dataView.refresh();
    grid.invalidate();
    grid.render();
    store.set('beneficiaryBook', data);
    grid.setSelectedRows([]);
    $("body").removeClass("loading");
    $(".header, .shell").find(":focusable").removeAttr("tabindex");
    if ($("#beneList").hasClass("hidden")) {
      setupViewBeneficiary(record);
    }
    buildNotification(msg, 300, 5000);
  }, 1500);
}
var approveNewBeneficiary = function(records) {
  for (var i = 0, l = records.length; i < l; i++) {
    var _record = records[i];
    _record.benestatus = "Active";
    _record.beneworkflow = "Approved";
    _record.approvedby = "Test User 1";
    _record.approvedon = smartDates("today") + " at " + timeFormatter();
  }
  if (records.length == 1) {
    msg = "The beneficiary record for <strong>" + records[0].benename + " (" + records[0].beneid + ")</strong> has been approved and is now active.";
  } else {
    msg = "Selected beneficiary records have been approved and are now active.";
  }
  reloadBeneficiaryDetails();
}
var approveSelectedBeneficiaries = function(records) {

  var confirmBeneficiaryApproval = function(_dialog) {
    for (var i = 0, l = records.length; i < l; i++) {
      var _record = records[i];
      if (_record.beneworkflow == "Pending Approval - Deleted") {
        _record.benestatus = "Deleted";
        _record.folder = "None";
        _record.folderid = "None";
      } else {
        _record.benestatus = "Active";
      }
      _record.beneworkflow = "Approved";
      _record.approvedby = "Test User 1";
      _record.approvedon = smartDates("today") + " at " + timeFormatter();
    }
    msg = "Selected beneficiary records have been approved.";
    dialogHider(_dialog);
    reloadBeneficiaryDetails();
  }

  var impactSummaryDialog = function() {
    var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
      $msgDiv = $("<p>The following beneficiaries exist in current payments and templates which may be impacted by confirming your approval. Refer to the table below to view records that will have beneficiary updates applied.</p>").appendTo($dialogContent),
      $tableDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
      $table = $("<table style='width: 100%; font-size: 14px; border-collapse: collapse; border-spacing: 0;' />").appendTo($tableDiv),
      $tr = $("<tr />").appendTo($table),
      $td = $("<td style='width: 15%; padding: 11px 10px;' />").appendTo($tr),
      $td = $("<td style='width: 28%; padding: 11px 10px;' />").appendTo($tr),
      $td = $("<td style='width: 12%; padding: 11px 10px;' />").appendTo($tr),
      $td = $("<td colspan='2' style='width: 30%; padding: 11px 10px; text-align: center;font-weight: bold;  background: #f8f8f8; border: 1px solid #cdcdcd;'>Payments</td>").appendTo($tr),
      $td = $("<td style='width: 15%; padding: 11px 10px; text-align: center; font-weight: bold; background: #f8f8f8; border: 1px solid #cdcdcd; border-left: 0;'>Templates</td>").appendTo($tr),
      $tr = $("<tr />").appendTo($table),
      $td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px;'>Beneficiary ID</td>").appendTo($tr),
      $td = $("<td style='width: 28%; border: 1px solid #cdcdcd; padding: 11px 10px;'>Beneficiary Name</td>").appendTo($tr),
      $td = $("<td style='width: 12%; border: 1px solid #cdcdcd; padding: 11px 10px;'>Action</td>").appendTo($tr),
      $td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px; background: #f8f8f8; text-align: center;'>No. to be updated</td>").appendTo($tr),
      $td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px; background: #f8f8f8; text-align: center;'>No. that will <strong>not be</strong> updated</td>").appendTo($tr),
      $td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px; background: #f8f8f8; text-align: center;'>No. to be updated</td>").appendTo($tr);

    for (var i = 0, l = records.length; i < l; i++) {
      var _record = records[i];
      var _action;
      if (_record.beneworkflow.indexOf("Deleted") != -1) {
        _action = "Deleted";
        var $tr = $("<tr />").appendTo($table),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.beneid + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.benename + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _action + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>0</span>").appendTo($td),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>10</a>").appendTo($td).on("click", viewNonImpactedPayments),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>2</a>").appendTo($td).on("click", viewImpactedTemplates);
      } else if (_record.beneworkflow.indexOf("Modified") != -1) {
        _action = "Modified";
        var $tr = $("<tr />").appendTo($table),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.beneid + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.benename + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _action + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>3</a>").appendTo($td).on("click", viewImpactedPayments),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>10</a>").appendTo($td).on("click", viewNonImpactedPayments),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>2</a>").appendTo($td).on("click", viewImpactedTemplates);
      } else if (_record.beneworkflow.indexOf("New") != -1) {
        _action = "Created";
        var $tr = $("<tr />").appendTo($table),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.beneid + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.benename + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _action + "</td>").appendTo($tr),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>0</span>").appendTo($td),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>0</span>").appendTo($td),
          $td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
          $a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.benename + "' data-status='" + _record.beneworkflow + "'>0</span>").appendTo($td);
      }
    }

    var $noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
      $note = $("<p><strong>NOTE:</strong></p>").appendTo($noteDiv),
      $note1 = $("<p style='margin-top: 10px;'>The records above are impacted based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".</p>").appendTo($noteDiv),
      $note2 = $("<p style='margin-top: 10px;'>Select Approve to continue.</p>").appendTo($noteDiv);
    return $dialogContent;
  }

  var _dialog = {
    id: "impactSummaryDialog",
    title: "Impact Summary",
    size: "xxl",
    icon: "<i class='fa fa-info-circle'></i>",
    content: function() {
      return impactSummaryDialog()
    },
    buttons: [{
      name: "Cancel",
      icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          dialogHider(_dialog)
        }
      }]
    }, {
      name: "Approve",
      icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          confirmBeneficiaryApproval(_dialog)
        }
      }],
      cssClass: "primary"
    }]
  }

  dialogViewer('', _dialog, dialogBuilder(_dialog));
}
function approveRecordDetail(e) {
  e.preventDefault();
  var bene = record;
  if (bene.benestatus == "New") {
    if (bene.beneworkflow == "Pending Approval - New") {
      buildConfirmDialog("On approval this beneficiary record will become active and available for use in payment instructions.", "Do you want to continue?", function() {
        approveNewBeneficiary([bene]);
      });
    } else if (bene.beneworkflow == "Pending Approval - Deleted") {
      buildConfirmDialog("This beneficiary record will be deleted. It will be available in the &quot;Deleted&quot; queue for a period of time.", "Do you want to continue?", function() {
        $("body").addClass("loading");
        setTimeout(function() {
          $("body").removeClass("loading");
          approveSelectedBeneficiaries([bene]);
        }, 500);
      });
    }
  } else
  if (bene.benestatus == "Active") {
    if (bene.beneworkflow == "Pending Approval - Modified") {
      buildConfirmDialog("Changes to this beneficiary record will be approved and saved.", "Do you want to continue?", function(e) {
        $("body").addClass("loading");
        setTimeout(function() {
          $("body").removeClass("loading");
          approveSelectedBeneficiaries([bene]);
        }, 500);
      });
    } else if (bene.beneworkflow == "Pending Approval - Deleted") {
      buildConfirmDialog("This beneficiary record will be deleted. It will be available in the &quot;Deleted&quot; queue for a period of time.", "Do you want to continue?", function() {
        $("body").addClass("loading");
        setTimeout(function() {
          $("body").removeClass("loading");
          approveSelectedBeneficiaries([bene]);
        }, 500);
      });
    }
  }
}
function approveFromList(e) {
  e.preventDefault();
  var bene,
    msg,
    sel = selectedRowIds.length,
    statusValue,
    workflowValue;

  if (sel == 1) {
    record = data[dataView.getIdxById(selectedRowIds[0])];
    if (record.benestatus == "Active") {
      if (record.beneworkflow == "Pending Approval - Modified") {
        buildConfirmDialog("Changes to this beneficiary record will be approved and saved.", "Do you want to continue?", function() {
          $("body").addClass("loading");
          setTimeout(function() {
            $("body").removeClass("loading");
            approveSelectedBeneficiaries([record]);
          }, 500);
        });
      } else if (record.beneworkflow == "Pending Approval - Deleted") {
        buildConfirmDialog("This beneficiary record will be deleted. It will be available in the &quot;Deleted&quot; queue for a period of time.", "Do you want to continue?", function() {
          $("body").addClass("loading");
          setTimeout(function() {
            $("body").removeClass("loading");
            approveSelectedBeneficiaries([record]);
          }, 500);
        });
      }
    } else if (record.benestatus == "New") {
      buildConfirmDialog("On approval this beneficiary record will become active and available for use in payment instructions.", "Do you want to continue?", function() {
        approveNewBeneficiary([record]);
      });
    }
  } else if (sel > 1) {
    var selectedItems = [];
    for (var i = 0; i < selectedRowIds.length; i++) {
      selectedItems.push(data[dataView.getIdxById(selectedRowIds[i])]);
    }
    if (selectedRowWorkflows.indexOf("Pending Approval - Deleted") > -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") == -1 && selectedRowWorkflows.indexOf("Pending Approval - New") == -1) {
      buildConfirmDialog("Selected beneficiary records will be deleted. They will be available in the &quot;Deleted&quot; queue for a period of time.", "Do you want to continue?", function() {
        $("body").addClass("loading");
        setTimeout(function() {
          $("body").removeClass("loading");
          approveSelectedBeneficiaries(selectedItems);
        }, 500);
      });
    } else if (selectedRowWorkflows.indexOf("Pending Approval - Deleted") == -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") > -1 && selectedRowWorkflows.indexOf("Pending Approval - New") == -1) {
      buildConfirmDialog("Changes to selected beneficiary records will be approved and saved.", "Do you want to continue?", function() {
        $("body").addClass("loading");
        setTimeout(function() {
          $("body").removeClass("loading");
          approveSelectedBeneficiaries(selectedItems);
        }, 500);
      });
    } else if (selectedRowWorkflows.indexOf("Pending Approval - Deleted") == -1 && selectedRowWorkflows.indexOf("Pending Approval - Modified") == -1 && selectedRowWorkflows.indexOf("Pending Approval - New") > -1) {
      buildConfirmDialog("On approval, selected beneficiary records will become active and available for use in payment instructions.", "Do you want to continue?", function() {
        approveNewBeneficiary(selectedItems);
      });
    } else {
      buildConfirmDialog("On approval, selected beneficiary records will be updated.<div style='font-size: 85%; margin-top: 15px;'>New beneficiary records will become approved and active.<br /><br />Beneficiary records pending changes will be saved and updated.<br /><br />Beneficiary records pending deletion will be deleted.</div>", "Do you want to continue?", function() {
        $("body").addClass("loading");
        setTimeout(function() {
          $("body").removeClass("loading");
          approveSelectedBeneficiaries(selectedItems);
        }, 500);
      });
    }
  }
}
function rejectRecords(dialog) {
  $("#rejectReason").addClass("working");
  var sel = selectedRowIds.length;
  if (!sel || sel == 1) {
    var bene, msg;
    if (record != null) {
      bene = dataView.getItemById(record.id);
    } else {
      bene = data[dataView.getIdxById(selectedRowIds[0])];
    }
    var reloadBeneficiaryDetails = function() {
      bene.rejectedby = "Prototype User 100";
      bene.rejectedon = smartDates("today") + " at " + timeFormatter();
      setTimeout(function() {
        $("#rejectReason").removeClass("working");
        dialogHider(dialog);
        dataView.refresh();
        grid.invalidate();
        grid.render();
        grid.setSelectedRows([]);
        store.set('beneficiaryBook', data);
        if (record != null) {
          setupViewBeneficiary(bene);
        }
        buildNotification(msg, 500, 5000);
      }, 1500);
    }
    if (bene.beneworkflow == "Pending Approval - Modified") {
      bene.beneworkflow = "Changes Rejected";
      msg = "Changes to beneficiary record <strong>" + bene.benename + " (" + bene.beneid + ")</strong> have been rejected.";
      reloadBeneficiaryDetails();
    } else if (bene.beneworkflow == "Pending Approval - Deleted") {
      bene.beneworkflow = "Deletion Rejected";
      msg = "The deletion of beneficiary record <strong>" + bene.benename + " (" + bene.beneid + ")</strong> has been rejected.";
      reloadBeneficiaryDetails();
    } else if (bene.beneworkflow == "Pending Approval - New") {
      bene.beneworkflow = "Creation Rejected";
      msg = "The creation of beneficiary record <strong>" + bene.benename + " (" + bene.beneid + ")</strong> has been rejected.";
      reloadBeneficiaryDetails();
    }
  } else if (sel > 1) {
    var reloadBeneficiaryList = function() {
      store.set('beneficiaryBook', data);
      setTimeout(function() {
        $("#rejectReason").removeClass("working");
        dialogHider(dialog);
        dataView.refresh();
        grid.invalidate();
        grid.render();
        grid.setSelectedRows([]);
        buildNotification(msg, 500, 5000);
      }, 1500);
    }
    for (var i = 0; i < selectedRowIds.length; i++) {
      if (data[dataView.getIdxById(selectedRowIds[i])].beneworkflow == "Pending Approval - Deleted") {
        data[dataView.getIdxById(selectedRowIds[i])].beneworkflow = "Deletion Rejected";
      } else if (data[dataView.getIdxById(selectedRowIds[i])].beneworkflow == "Pending Approval - Modified") {
        data[dataView.getIdxById(selectedRowIds[i])].beneworkflow = "Changes Rejected";
      } else if (data[dataView.getIdxById(selectedRowIds[i])].beneworkflow == "Pending Approval - New") {
        data[dataView.getIdxById(selectedRowIds[i])].beneworkflow = "Creation Rejected";
      }
      data[dataView.getIdxById(selectedRowIds[i])].rejectedby = "Prototype User 100";
      data[dataView.getIdxById(selectedRowIds[i])].rejectedon = smartDates("today") + " at " + timeFormatter();
    }
    msg = "Selected beneficiary records have been rejected.";
    reloadBeneficiaryList();
  }
}
function rejectRecordReason(e) {
  e.preventDefault();
  var $target = $(e.target);
  var populateRejectReason = function() {
    var $form = $("<div class='form-section' />");
    var $row = $("<div class='row' />").appendTo($form);
    var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
    var $textarea = $("<textarea style='width: 425px; height: 230px;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
    return $form;
  }
  var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
  var _dialog = {
    id: "rejectReason",
    title: "Enter A Reason For Rejection",
    size: "small",
    icon: "<i class='fa fa-ban'></i>",
    content: function() {
      return populateRejectReason()
    },
    buttons: [{
      name: "Cancel",
      icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          dialogHider(_dialog)
        }
      }]
    }, {
      name: "Ok",
      icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
      events: [{
        event: "click",
        action: function(e) {
          e.preventDefault();
          rejectRecords(_dialog)
        }
      }],
      cssClass: "primary"
    }]
  }
  dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
  $("#rejectionReasonTextarea").focus();
}
function rejectRecordFromList(e) {
  e.preventDefault();
  var sel = selectedRowIds.length;
  if (sel > 1) {
    buildConfirmDialog("This action will reject multiple records in one go.", "Do you want to continue?", function() {
      rejectRecordReason(e);
    });
  } else {
    rejectRecordReason(e);
  }
}



/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


  /* SPLIT VIEW */
  var $shell = $(".shell"),
    $leftPanel = $(".left-panel"),
    $rightPanel = $(".right-panel"),
    $resizer = $(".resizer");

  $(".resizer").drag("start", function(ev, dd) {
    $("body").trigger("click.hide-menu");
    $resizer.addClass("on");
    dd.limit = $shell.offset();
    dd.limit.left = 400;
    dd.limit.right = $shell.width() - (500);
  }).drag(function(ev, dd) {
    $rightPanel.css({
      left: Math.min(dd.limit.right, Math.max(dd.limit.left, dd.offsetX - $shell.position().left))
    });
    $leftPanel.css({
      width: $rightPanel.position().left
    });
    grid.resizeCanvas();
  }, {
    handle: ".resizer"
  }).drag("end", function(ev, dd) {
    $resizer.removeClass("on");
    grid.resizeCanvas();
  });


  populateFolders();

  var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
  dataView = new Slick.Data.DataView({
    groupItemMetadataProvider: groupItemMetadataProvider
  });
  grid = new Slick.Grid("#beneficiaryList", dataView, columns, options);
  grid.setSelectionModel(new Slick.RowSelectionModel({
    selectActiveRow: false
  }));
  grid.registerPlugin(groupItemMetadataProvider);
  grid.registerPlugin(checkboxSelector);


  var sortcolumns = [{
    id: "benename",
    name: "Beneficiary Name",
    field: "benename",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "beneaccountccy",
    name: "Account Currency",
    field: "beneaccountccy",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "benecountry",
    name: "Beneficiary Country",
    field: "benecountry",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "benebank",
    name: "Beneficiary Bank",
    field: "benebank",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "benebankbranch",
    name: "Bank Branch",
    field: "benebankbranch",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "benebankcountry",
    name: "Bank Country",
    field: "benebankcountry",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "benestatus",
    name: "Status",
    field: "benestatus",
    width: 200,
    sortable: true,
    visible: true
  }, {
    id: "beneworkflow",
    name: "Workflow",
    field: "beneworkflow",
    width: 200,
    sortable: true,
    visible: true
  }];
  new Slick.Controls.SlickPreviewSortPicker(sortcolumns, grid, options);

  var $beneGrid = $(grid.getCanvasNode());

  grid.onContextMenu.subscribe(function(e, args) {
    e.preventDefault();
    var cell = grid.getCellFromEvent(e),
      row = cell.row,
      rows = grid.getSelectedRows(),
      $cmenu = $("#contextMenu");
    if ($.inArray(row, rows) == -1) {
      grid.setActiveCell(row, 1);
    }
    setupContextMenu();
    var cheight = $cmenu.height(),
      winwidth = $(window).width(),
      winheight = $(window).height(),
      leftpos = e.pageX,
      toppos = e.pageY;
    if (e.pageX + 210 > winwidth) {
      leftpos = e.pageX - 205;
    }
    if (e.pageY + cheight > winheight) {
      toppos = e.pageY - cheight;
      if (toppos < 0) {
        toppos = e.pageY - (cheight - (winheight - e.pageY));
      }
    };
    $(document).off("keyup.hide-context");
    $("body").off("click.hide-context");

    function hideContextMenu() {
      $(".control-menus").children(".control-menu:visible").hide();
      $(".control-list").find(".on").removeClass("on");
      $(".control-menus").find("a.sub-open").removeClass("sub-open");
    }
    hideContextMenu();
    $cmenu.css("top", toppos).css("left", leftpos).show();
    $(document).on("keyup.hide-context", function(e) {
      if (e.keyCode == 27) {
        hideContextMenu()
      }
    });
    $("body").one("click.hide-context", function() {
      hideContextMenu()
    });
  });

  grid.onSelectedRowsChanged.subscribe(function(e) {
    clearTimeout(loadRecordTimer);
    $(document).off("keyup.hide-menu");
    $(".shell").off("resize.hide-menu");
    $("body").off("click.hide-menu");
    $(".control-menus").children(".control-menu:visible").hide();
    $(".control-list").children(".on").removeClass("on");
    selectedRowIds = [];
    selectedRowStates = [];
    selectedRowWorkflows = [];
    var rows = grid.getSelectedRows();
    for (var i = 0, l = rows.length; i < l; i++) {
      var item = dataView.getItem(rows[i])
      if (item.id) {
        selectedRowIds.push(item.id);
        selectedRowStates.push(item.benestatus);
        selectedRowWorkflows.push(item.beneworkflow);
      }
    }
    if (!rows.length) {
      grid.resetActiveCell();
      $(".right-panel").removeClass("loading");
      $(".selection-panel").show().find("div[data-value='multiple-selection']").hide();
      $(".selection-panel").find("div[data-value='no-selection']").show();
      grid.resizeCanvas();
    } else if (rows.length === 1) {
      if (!grid.getActiveCell() || grid.getActiveCell().row != rows[0]) {
        grid.setActiveCell(rows[0], 1);
      }
      $(".right-panel").addClass("loading").find(".scroll-area").scrollTop("0");
      loadRecordTimer = setTimeout(function() {
        $(".right-panel").removeClass("loading");
        setupViewBeneficiary(dataView.getItem(rows[0]));
        $(".selection-panel").hide();
      }, 500);
    } else if (rows.length > 1) {
      $(".right-panel").removeClass("loading");
      $(".selection-panel").show().find("div[data-value='no-selection']").hide()
      $(".selection-panel").find("div[data-value='multiple-selection']").show();
    }
  });

  grid.onClick.subscribe(function(e, args) {
    var row = args.row;
    if (grid.getActiveCell() && grid.getActiveCell().row == args.row) {
      grid.resetActiveCell();
    }
    grid.setSelectedRows([row]);
    grid.setActiveCell(row, 1);
  });

  grid.onActiveCellChanged.subscribe(function(e, args) {
    var item = grid.getActiveCell(),
      $row = $(grid.getActiveCellNode()).closest(".slick-row");
    if ($row.is(".slick-group, .slick-group-totals")) {
      return false;
    } else {
      if (item) {
        if (grid.getActiveCell().row != grid.getSelectedRows([0]) || !grid.getSelectedRows().length) {
          grid.setSelectedRows([item.row]);
        }
      }
    }
  });

  grid.onSort.subscribe(function(e, args) {
    sortcol = args.sortCol.field;
    sortdir = args.sortAsc ? 1 : -1;
    dataView.fastSort(sortcol, args.sortAsc);
  });

  dataView.onRowCountChanged.subscribe(function(e, args) {
    grid.updateRowCount();
    grid.render();
  });

  dataView.onRowsChanged.subscribe(function(e, args) {
    grid.invalidateRows(args.rows);
    grid.render();
    if (selectedRowIds.length > 0) {
      var selRows = [];
      for (var i = 0; i < selectedRowIds.length; i++) {
        var idx = dataView.getRowById(selectedRowIds[i]);
        if (idx != undefined)
          selRows.push(idx);
      }
      grid.setSelectedRows(selRows);
    }
  });

  dataView.setItems(data);

  dataView.setFilterArgs({
    folderString: folderString,
    statusString: statusString,
    workflowString: workflowString,
    searchString: searchString
  });

  dataView.setFilter(myFilter);

  grid.setColumns(columns);


  $(window).bind("resize", function() {
    grid.resizeCanvas();
  });


  $("#viewWorkflowFilter").on("click.filter-view", function(e) {
    e.preventDefault();
    var $target = $(e.target);
    if ($target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set")) {
      var status = $target.attr("data-status"),
        workflow = $target.attr("data-workflow");
      if (!status) {
        statusString = ""
      }
      if (statusString != status) {
        statusString = status
      }
      if (!workflow) {
        workflowString = ""
      }
      if (workflowString != workflow) {
        workflowString = workflow
      }
      viewFilter();
    }
  });

  $(".manage-folders").on("click", showFolderManagerDialog);

  $("#_inlineFolderButton").on("click", addFolderInline);

  $("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
    if (e.keyCode == 13) {
      addFolderInline();
    }
  });

  $("#groupMenu [data-action='group']").on("click.group-by", function(e) {
    e.preventDefault();
    var $target = $(e.target),
      item = $target.attr("data-item"),
      text = $target.text();
    groupBy(item, text);
  });

  $(".collapse-mark").bind("click.collapse-mark", function(e) {
    e.stopPropagation();
    var $item = $(".collapse-mark").parent("li");
    if (groupCollapseSetting == 0) {
      $item.addClass("on");
      groupCollapseSetting = 1;
    } else {
      $item.removeClass("on");
      groupCollapseSetting = 0;
    }
  });

  $("#actionMenuControl").on("click", function(e) {
    e.preventDefault();
    setupContextMenu();
  });

  $(" #moreActionsViewButton").on("click", function(e) {
    e.preventDefault();
    setupContextMenu(record);
  });

  $(".remember-settings").on("click", function() {
    $("body").addClass("loading");
    setTimeout(function() {
      $("body").removeClass("loading");
      buildNotification("Default settings for this screen have been updated", 500, 3000);
    }, 1000);
  });

  $("[data-action='refresh']").on("click", function(e) {
    e.preventDefault();
    $('#beneList').addClass("loading");
    setTimeout(function() {
      $('#beneList').removeClass("loading");
    }, 600);
  });

  $("[data-action='download']").on("click", function(e) {
    e.preventDefault();
  });

  $(".search-btn").on("click", function(e) {
    e.preventDefault();
    if ($(".search-menu").is(":visible")) {
      $(this).removeClass("open");
      $(".search-menu").hide();
      $("#beneficiaryList").css({
        "top": 0
      });
      grid.resizeCanvas();
    } else {
      $(this).addClass("open");
      $(".search-menu").show().find("input.search-input").focus();
      $("#beneficiaryList").css({
        "top": 50
      });
      grid.resizeCanvas();
    }
  });

  $(".search-options").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();

    function hideMenu() {
      $("#findMenu").hide();
      $(document).off("keyup.hide-search");
      $(window).off("resize.hide-search");
      $("body").off("click.hide-search");
    }
    if ($("#findMenu").is(":visible")) {
      hideMenu();
    } else {
      $(".control-menus .control-menu").hide();
      $("#findMenu").show().css({
        "top": "218px"
      });
      $(window).on("resize.hide-search", function() {
        hideMenu()
      });
      $(document).on("keyup.hide-search", function(e) {
        e.preventDefault();
        if (e.keyCode == 27) {
          hideMenu()
        }
      });
      $("body").on("click.hide-search", function() {
        hideMenu()
      });
    }
  });

  $("#clearSearchCriteria").on("click", function() {
    $("#findBeneficiaries").val('');
    $("#findBeneficiaries").blur();
    $("#clearSearchCriteria").hide();
    searchString = "";
    findBeneficiaries();
  });

  $("#findBeneficiaries").keyup(function(e) {
    if (e.which == 27) {
      $("#clearSearchCriteria").hide();
      this.value = '';
      this.blur()
    }
    searchString = this.value;
    findBeneficiaries();
    if (this.value != "") {
      $("#clearSearchCriteria").show()
    } else {
      $("#clearSearchCriteria").hide()
    }
  });

  $("#findMenu").on("click.set-find", "a", function(e) {
    e.preventDefault();
    var repPlaceholder = $(this).text(),
      searchString = $(this).attr("data-find");
    if (searchPoint != searchString) {
      $("#findBeneficiaries").attr("placeholder", repPlaceholder);
      searchPoint = searchString;
      $("#findBeneficiaries").val('').focus();
      $("#clearSearchCriteria").hide();
      searchString = '';
      findBeneficiaries();
    }
  });


  $("#closeViewBeneBtn").on("click", function(e) {
    e.preventDefault();
    grid.setSelectedRows({});
    grid.resetActiveCell();
  });


  $("[data-action='previousRequest']").on("click", function(e) {
    e.preventDefault();
    var activeRow = grid.getActiveCell().row;
    activeRow = activeRow - 1;
    if ($beneGrid.find("div[row='" + activeRow + "']").is(".slick-group, .slick-group-totals")) {
      activeRow = activeRow - 1;
    }
    $beneGrid.find("div[row='" + activeRow + "'] div.slick-cell").eq(1).trigger("click")
  });

  $("[data-action='nextRequest']").on("click", function(e) {
    e.preventDefault();
    var activeRow = grid.getActiveCell().row;
    activeRow = activeRow + 1;
    if ($beneGrid.find("div[row='" + activeRow + "']").is(".slick-group, .slick-group-totals")) {
      activeRow = activeRow + 1;
    }
    $beneGrid.find("div[row='" + activeRow + "'] div.slick-cell").eq(1).trigger("click")
  });

});