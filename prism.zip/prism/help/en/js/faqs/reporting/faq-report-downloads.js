/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Report Centre Onscreen Guide",
	action: "slider"
}, {
	title: "How do I view my report history?",
	faq: "<p>Drop down the Date filter &gt; Select the required date period&#47;range you wish to view.</p>"
}, {
	title: "How do I download more than one report at a time?",
	faq: "<p>Place a tick next to the required reports &gt; Right click and select Download Selected Files.</p><p>This will produce a .zip file which will contain the selected reports.</p>"
}, {
	title: "How do I make this screen my Homepage?",
	faq: "<p>Drop down the Settings &  Preferences menu (displayed as your User Name on the top right of the screen) &gt; select &#39;Set this page as my home page&#39;.</p>"
}];