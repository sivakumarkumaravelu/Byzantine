/**********************************************************************
DATA
**********************************************************************/
var ACCOUNTS = [{name: "Primary Savings Account", number: "113-6677-322", currency: "AUD", funds: "12,000.00", available: "12,000.00", balance: "12,000.00"}, {name: "Funding Account Singapore", number: "456-8888-125", currency: "SGD", funds: "32,101.53", available: "32,101.53", balance: "32,101.53"}, {name: "Loan Repayment Account", number: "684-2345-111", currency: "SGD", funds: "6,130.00", available: "6,130.00", balance: "6,130.00"}, {name: "Operations Account", number: "334-3566-122", currency: "AUD", funds: "8,456.31", available: "8,456.31", balance: "8,456.31"}, {name: "Current Account", number: "888-3354-355", currency: "HKD", funds: "17,257.91", available: "17,257.91", balance: "17,257.91"}, {name: "Funding Account China", number: "356-5788-009", currency: "HKD", funds: "57,774.31", available: "57,774.31", balance: "57,774.31"}, {name: "India Operations", number: "433-3566-123", currency: "INR", funds: "76,730.00", available: "76,730.00", balance: "76,730.00"}, {name: "Legal Operations Account", number: "112-6578-244", currency: "AUD", funds: "108,456.31", available: "108,456.31", balance: "108,456.31"}, {name: "Trade Account", number: "333-3555-122", currency: "SGD", funds: "27,257.31", available: "27,257.31", balance: "27,257.31"}, {name: "Secondary Savings Account", number: "111-1222-245", currency: "AUD", funds: "207,774.31", available: "207,774.31", balance: "207,774.31"}, {name: "India Legal", number: "344-1678-999", currency: "INR", funds: "500,000.00", available: "500,000.00", balance: "500,000.00"}, {name: "India Financing", number: "311-3556-133", currency: "INR", funds: "700,000.00", available: "700,000.00", balance: "700,000.00"}, {name: "Thai Operations", number: "777-3123-663", currency: "THB", funds: "1,000,000.00", available: "1,000,000.00", balance: "1,000,000.00"}, {name: "THB Legal", number: "334-1456-123", currency: "THB", funds: "2,632,012.64", available: "2,632,012.64", balance: "2,632,012.64"}];
var enquiryTypes = ["Correspondent Bank Charges","Incorrect Information","Incorrect Charges","Amend Beneficiary","Incorrect Debit Account","Beneficiary Claims Non-Receipt","Incorrect Cover","Incorrect Amount","Outward Duplicate Payment","Unable to Effect Payment","Incorrect Credit Account","Incorrect Bank Paid","Miscellaneous","Compliance","Sanctions Inquiry","Incorrect Payments","Fraud Inquiry","Return of Funds","Unable to Apply Credit","Unable to Apply Debit","Inward Duplicate Payment"];
function rand(min, max) {
  var offset = min;
  var range = (max - min) + 1;
  var randomNumber = Math.floor( Math.random() * range) + offset;
  return randomNumber;
}


/**********************************************************************
ENQUIRIES GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [
	{id:"accountnumb", name:"Account Number", field:"accountnumb", toolTip:"Click to sort by Account Number. Right-Click to hide or show", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"enquiryid", name:"Enquiry ID", field:"enquiryid", toolTip:"Click to sort by Enquiry ID. Right-Click to hide or show", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"creationdate", name:"Creation Date", field:"creationdate", toolTip:"Click to sort by Creation Date. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"lastupdate", name:"Last Update", field:"lastupdate", toolTip:"Click to sort by Last update. Right-Click to hide or show", width: 200, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"currency", name:"Currency", field:"currency", toolTip:"Click to sort by Account Currency. Right-Click to hide or show", width: 100, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"enquiryamount", name:"Enquiry Amount", field:"enquiryamount", toolTip:"Click to sort by Enquiry Amount. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterNumeric", cssClass: "num pos", headerCssClass: "righted", visible: true, formatter: Slick.Formatters.AmountFormatter},
	{id:"enquirystatus", name:"Enquiry Status", field:"enquirystatus", toolTip:"Click to sort by Enquiry Status. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"transactionref", name:"Transaction Reference", field:"transactionref", toolTip:"Click to sort by Transaction Reference. Right-Click to hide or show", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"createdby", name:"Created By", field:"createdby", toolTip:"Click to sort by Created By. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"accountowner", name:"Account Owner", field:"accountowner", toolTip:"Click to sorty by Account Owner. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true },
	{id:"enquirytype", name:"Enquiry Type", field:"enquirytype", toolTip:"Click to sort by Enquiry Type. Right-Click to hide or show", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"closedate", name:"Closed Date", field:"closedate", toolTip:"Click to sort by Closed Date. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"channel", name:"Channel", field:"channel", toolTip:"Click to sort by Reference Channel. Right-Click to hide or show", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true}
];
options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if ( store.get('enquiryColumnOrder') ) {
	columns = store.get('enquiryColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if ( columns[i].id == "enquiryamount") {
			columns[i].formatter = Slick.Formatters.AmountFormatter
		}
	}
}
if ( store.get('enquiryColumnWidth') ) {
	var setWidth = store.get('enquiryColumnWidth');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var labelString = "", findString = "", findDataPoint = "accountnumb";
function myFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}
		
	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterAccounts() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
for (var i=0; i<20; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	d["label"] = "None";
	d["labelid"] = "None";
	d["creationdate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date()) + " " + timeFormatter();
	d["accountnumb"] = Math.round(Math.random() * 1000000000).toString();
	d["enquiryid"] = "ANZAU"+Math.round(Math.random() * 1000000000).toString();
	d["currency"] = "AUD";
	d["enquiryamount"] = (Math.round(Math.random() * 10000000)/100).toFixed(2);
	d["transactionref"] = Math.round(Math.random() * 1000000000).toString();
	d["createdby"] = "ANZUser";
	d["accountowner"] = "ANZAccountOwner";
	d["enquirytype"] = enquiryTypes[rand(0, enquiryTypes.length - 1)];  
	if(i % 2 == 0) {
		d["enquirystatus"] = "Closed";
		d["closedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	} else {
		d["enquirystatus"] = "Open";
		d["closedate"] = "";
	}
	d["channel"] = "Self Service";
	d["enquirydescription"] = "This is where the enquiry description will appear. Lorem ipsum dolor sit ament aidispicing conseqtateur. Lorem ipsum dolor sit ament aidispicing conseqtateur...";
	d["transactiontype"] = "";
	d["transactiondate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["swiftbic"] = "";

	if(i % 3 == 0) {
		d["debitamount"] = Math.round(Math.random() * 1000000000).toString();
		d["debitcurrency"] = "AUD";
		d["debitdate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
		d["creditamount"] = "";
		d["creditcurrency"] = "";
		d["creditdate"] = "";
	} else {
		d["debitamount"] = "";
		d["debitcurrency"] = "";
		d["debitdate"] = "";
		d["creditamount"] = Math.round(Math.random() * 1000000000).toString();
		d["creditcurrency"] = "AUD";
		d["creditdate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	}
	d["incomingtrn"] = "This is where incoming TRN information will appear.";
	d["attachmentDate"] = $.datepicker.formatDate('dd/mm/yy', new Date()) + " " + timeFormatter();
	d["attachmentType"] = "Note";
};


/**********************************************************************
SAVED ENQUIRY SEARCHES
**********************************************************************/	
var saved_searches = [{name:"Open Enquiries", id:"asdf3"},{name:"Closed Enquiries", id:"sdf23"},{name:"This Week", id:"hgj56"},{name:"This Month", id:"ncve4"},{name:"Last Month", id:"47hj6"}], searches_updated = false, searches_deleted = false, $search_message = $("<p>Use the saved search feature to save frequent searches and quickly recall them.</p>");
if ( store.get('saved_enquiry_searches') ) { saved_searches = store.get('saved_enquiry_searches') };
function searchChecker(val) {
	var _search = val, error = false, $searchList = $(".search-list").children("li"), existingSearches = [];
	for ( var i = 0; i < $searchList.length; i++ ) {
		existingSearches.push( $searchList.eq(i).attr("data-search") );
	}
	if ($.inArray(_search, existingSearches != -1)) {
		error = "existing"
	}
	return error;
}
function renameSearch(el) {
	var newSearchName = $.trim(el.val());
	if ( newSearchName == '' || newSearchName == "undefined" ) {
		el.val( el.attr("data-search-name") );
	} else {
		el.val(newSearchName);
		el.closest("li").attr("data-search", newSearchName );
		searches_updated = true;
	}
}
function deleteSearch(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function(){
		if ( !$target.hasClass('new') ) { searches_deleted = true; }
		$target.remove();
		$(".folder-list").sortable("refresh");
		searches_updated = true;
		if ( !$(".folder-list").children("li").size() ) {
			$(".search-instructions").remove();
			$search_message.appendTo(".folder-settings");
		}
	 });
}
function populateSearches() {
	var $savedSearches = $(".saved-searches"), searchCount = saved_searches.length, activeSearch = $savedSearches.children("li.active") ? $savedSearches.children("li.active").attr("data-search-id") : false;
	$savedSearches.children().remove();
	if ( searchCount > 0 ) {
		var $li, $a
		$savedSearches.each( function() {
			var _this = $(this);
			if ( _this.parents().attr("id") == "viewMenu" ) {
				$.each(saved_searches, function() {
					$li = $("<li data-search='"+this.name+"' data-search-id='"+this.id+"' />").appendTo(_this);
					if ( this.id == activeSearch ) { $li.addClass("active"); $("#searchMenuControl").children("a").children("span").html(this.name); }
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-search='"+this.name+"' data-search-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault();
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.saved-searches"),
		$li = $("<li class='no-set' />").appendTo($viewMenu),
		$a = $("<div >You have no saved searches</div>").appendTo($li);
	}
}
function populateSearchManager() {	
	searches_updated = false; searches_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
	$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({ handle: '.reorder-folder', axis: 'y', tolerance: "pointer", update: function( event, ui ) { searches_updated = true } }),
	folderCount = saved_searches.length, $li, $div, $span, $input, $remove, $view, $error;
	if ( folderCount > 0 ) {
		$folderAddLine = $("<p class='search-instructions'>Reorder, rename, run or remove your saved searches.</p>").insertBefore($folderList),
		$.each(saved_searches, function() {
			$li = $("<li data-search='"+this.name+"' data-search-id='"+this.id+"' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='"+this.name+"' data-search-name='"+this.name+"' />").on("change", function() { renameSearch( $(this) );}).appendTo($div);
			$view = $("<a href='javascript:void(0)' class='view-folder'><i class='fa fa-search fa-fw'></i></a>").appendTo($div);
			$remove = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteSearch).appendTo($div);
			$error = $("<div class='data-error'>A saved search with this name already exists</div>").appendTo($div);
		});
	} else {
		$search_message.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showSearchManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Saved Searches",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function(){return populateSearchManager()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw fa-lg'></i>", cssClass: "primary", events: [{event: "click", action: function(e){e.preventDefault();updateSearches(_dialog)}}] }
		] 
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );	
}
function saveSearches(dialog) {
	var $dialog = $("#"+dialog.id), $active = $("#viewMenu").children(".saved-searches").find("li.active").attr("data-search-id");
	$dialog.addClass("working");	
	saved_searches = searches_updated;
	
	var active_deleted = true;
	
	for ( f = 0; f < saved_searches.length; f++ ) {
		if ( $active == saved_searches[f].id ) {
			active_deleted = false;
			break;
		}
	}

	searches_updated = false;
	searches_deleted = false;
	store.set('saved_enquiry_searches', saved_searches);
	setTimeout( function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateSearches();
		if ( !saved_searches.length || active_deleted ) { $("#_noSearch").trigger("click"); }
		dialogHider(dialog);
	}, 300);
}
function updateSearches(dialog) {
	if ( searches_updated ) {
		searches_updated = [];
		var duplicate_names = false, $searchList = $(".folder-list");
		$searchList.find("li.error").removeClass("error");
		$searchList.children("li").each(function() {
			searches_updated.push( { "name":$(this).attr("data-search"), "id":$(this).attr("data-search-id") });
			var _name = $(this).attr("data-search");
			$(this).siblings().each(function() {
				if ( $(this).attr("data-search") == _name ) {
					$(this).addClass("error");
				}
			});
		});
		if ( $searchList.find("li.error").size() ) {
			duplicate_names = true;
		}
		if ( duplicate_names ) {	
			return false;
		} else {		
			var save_searches = false;
			if ( saved_searches.length != searches_updated.length ) {
				save_searches = true;
			} else {
				for (var i = 0; i < saved_searches.length; i++) {
					if ( saved_searches[i].name != searches_updated[i].name || saved_searches[i].id != searches_updated[i].id ) {
						save_searches = true;
						break;
					}
				}
			}
			if ( save_searches || searches_deleted ) {
				if ( searches_deleted ) {
					buildConfirmDialog( "You've deleted some saved searches.", "Are you sure you want to continue?", function(){saveSearches(dialog)});
				} else {
					saveSearches(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}


/**********************************************************************
SEARCH INDICATOR SETUP
**********************************************************************/
function indicatorSelection() {
	var alphaIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "~", "Contains"],
		numIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "&gt;", "Greater Than", "&lt;", "Less Than", "&hArr;", "Between"],
		dateIndicatores = ["=", "Specific Date", "&hArr;", "Date Range", "Rd", "Rolling Dates"];
	var $indicatorMenu, whichArray, indicator, mainInput, fromInput, toInput, rollingInput, hiddenInput;
	var sibs;

	function init() {
		$indicatorMenu = $("<div class='indicator-menu' style='display:none;position:absolute;' />").appendTo(document.body);
		$indicatorMenu.bind("click", setIndicator);
		setupIndicators();
	}

	function setupIndicators() {

		var $indicatorItem;
		$(".transactionSearch .indicator").bind("click", function(e) {
			e.stopPropagation();
			if ($indicatorMenu.is(":visible") && $indicatorMenu.attr("id") == $(this).attr("id") + "m") {
				$indicatorMenu.empty().hide();
				return;
			}
			$indicatorMenu.empty();
			indicator = $(this);
			sibs = $(this).siblings("input").not("input[type='hidden']");
			mainInput = $(this).next("input");
			fromInput = mainInput.next("input");
			toInput = fromInput.next("input");
			rollingInput = toInput.next("input");
			hiddenInput = $(this).siblings("input[type='hidden']");
			$indicatorMenu.attr("id", indicator.attr("id") + "m");
			whichArray = alphaIndicators;
			if ($(this).hasClass("num")) whichArray = numIndicators;
			if ($(this).hasClass("date")) whichArray = dateIndicatores;
			for (var i = 0; i < whichArray.length; i++) {
				$indicatorItem = $("<div />").attr("id", i).html("<strong id=" + i + ">" + whichArray[i] + "</strong> " + whichArray[i + 1]).appendTo($indicatorMenu);
				i = i + 1;
			}
			var pleft = $(this).offset().left;
			var ptop = $(this).offset().top + $(this).height() + 2;
			$indicatorMenu.css("top", ptop).css("left", pleft).show();
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").children(".on").removeClass("on");
			$("body").one("click", function() {
				$indicatorMenu.empty().hide();
			});
			$(document).on("keyup.hideIndicator", function(e) {
				if (e.keyCode == 27) {
					$indicatorMenu.empty().hide();
					$(document).off("keyup.hideIndicator");
				}
			});
		});
	}

	function setIndicator(e) {
		var indset = whichArray[parseInt(e.target.id)];
		var hidset = whichArray[parseInt(e.target.id) + 1];
		indicator.html(indset).attr("title", hidset);
		hiddenInput.val(hidset);
		if (hidset == "Date Range" || hidset == "Between") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.removeClass("display-none").prop("disabled", "").focus();
			toInput.removeClass("display-none").prop("disabled", "");
		}
		if (hidset == "Rolling Dates") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.removeClass("display-none").prop("disabled", "").focus();
		}
		if (hidset != "Date Range" && hidset != "Rolling Dates" && hidset != "Between") {
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			mainInput.removeClass("display-none").prop("disabled", "").focus();
		}
	}
	init();
}


/**********************************************************************
SEARCH FIELD TOGGLE
**********************************************************************/
var search_height = 0;
var inMotion = false;
function showSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	$this.attr("show", "true").addClass("btn-on");
	$i.removeClass("fa-search-plus").addClass("fa-search-minus");
	$(".search-fields").removeClass("slide-up");
	$(".scroll-area").removeClass("full-height");
	$(".basic-search").css("overflow", "hidden");
	inMotion = setTimeout(function() {
		$(".basic-search").css("overflow", "visible");
		grid.resizeCanvas();
		inMotion = false;
	}, 300);
}
function hideSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	if (inMotion) clearTimeout(inMotion);
	$i.removeClass("fa-search-minus").addClass("fa-search-plus");
	$this.attr("show", "false").removeClass("btn-on");
	$(".search-fields").css("overflow", "hidden").addClass("slide-up");
	$(".scroll-area").addClass("full-height");
	setTimeout(function() {
		grid.resizeCanvas();
	}, 300);
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {

	/**********************************************************************
	INITIALIZE ENQUIRIES GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#searchGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	grid.registerPlugin(groupItemMetadataProvider);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, "enquiryColumnOrder", "enquiryColumnWidth", []);
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		if( !$row.is(".slick-group, .slick-group-totals") ) {
			function showEnquiryDetails(row) {
				var _row = row;
				var _enquiry = dataView.getItem(_row);
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
				$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
				$controls = $("<div class='control-list' />").appendTo($navigationBar),
				$historyBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-list fa-fw text-right'></i>Enquiry History</a></span>").appendTo($controls),
				$reportBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-download fa-fw'></i></a></span>").appendTo($controls),
				$rightControls = $("<div class='control-list right' />").appendTo($navigationBar),
				$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($rightControls),
				$nextBtn = $("<span class='btn'><a href='javascript:void(0);'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($rightControls),
				details1 = [
					{name: "Enquiry Type", id: "td1", type: "text", data: _enquiry.enquirytype},
					{name: "Enquiry Amount", id: "td2", type: "text", data: _enquiry.enquiryamount},
					{name: "Creation Date", id: "td3", type: "text", data: _enquiry.creationdate},
					{name: "Account Number", id: "td8", type: "text", data: _enquiry.accountnumb},
					{name: "Account Currency", id: "td9", type: "text", data: _enquiry.currency },
					{name: "Transaction Reference", id: "td10", type: "text", data: _enquiry.transactionref},
					{name: "Transaction Type", id: "td11", type: "text", data: _enquiry.transactiontype },
					{name: "Transaction Date", id: "td12", type: "text", data: _enquiry.transactiondate },
					{name: "SWIFT BIC", id: "td13", type: "text", data: _enquiry.swiftbic }
				],
				details2 = [
					{name: "Enquiry Status", id: "td5", type: "text", data: _enquiry.enquirystatus },
					{name: "Last Update", id: "td4", type: "text", data: _enquiry.lastupdate},
					{name: "Closed Date", id: "td6", type: "text", data: _enquiry.closedate },
					{name: "Debit Amount", id: "td14", type: "text", data: _enquiry.debitamount},
					{name: "Debit Amount Currency", id: "td15", type: "text", data: _enquiry.debitcurrency},
					{name: "Debit Value Date", id: "td16", type: "text", data: _enquiry.debitdate},	
					{name: "Credit Amount", id: "td17", type: "text", data: _enquiry.creditamount },
					{name: "Credit Amount Currency", id: "td18", type: "text", data: _enquiry.creditcurrency },
					{name: "Credit Value Date", id: "td19", type: "text", data: _enquiry.creditdate}
				],
				details3 = [
					{name: "Incoming TRN", id: "td20", type: "text", data: _enquiry.incomingtrn},
					{name: "Equiry Description", id: "td7", type: "text", data: _enquiry.enquirydescription }
				],
				$detailsForm = $("<div class='data-entry' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
				$enquiryHeading = $("<div class='section-heading'>Enquiry Information</div>").appendTo($detailsForm),
				$enquirySection = $("<div class='form-section' id='enquiryDetailsWindow' />").appendTo($detailsForm),
				$column1 = $("<div style='display: inline-block; vertical-align: top; width: 50%;' />").appendTo($enquirySection);
				for (var i = 0; i < details1.length; i++) {
					var $row = $("<div class='row' />").appendTo($column1),
					$label = $("<div class='label-column' style='width: 50%;'><label>"+details1[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details1[i].id+"'>"+details1[i].data+"</div>").appendTo($data);
				};
				var $column2 = $("<div style='display: inline-block; vertical-align: top; width: 50%;' />").appendTo($enquirySection);
				for (var i = 0; i < details2.length; i++) {
					var $row = $("<div class='row' />").appendTo($column2),
					$label = $("<div class='label-column' style='width: 50%;'><label>"+details2[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details2[i].id+"'>"+details2[i].data+"</div>").appendTo($data);
				};
				var $column3 = $("<div style='display: block;' />").appendTo($enquirySection);
				for (var i = 0; i < details3.length; i++) {
					var $row = $("<div class='row' />").appendTo($column3),
					$label = $("<div class='label-column' style='width: 25%;'><label>"+details3[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details3[i].id+"'>"+details3[i].data+"</div>").appendTo($data);
				};
				var $attachmentHeading = $("<div class='section-heading'>Attachments</div>").appendTo($detailsForm),
				$attachmentSection = $("<div class='form-section' />").appendTo($detailsForm),
				$attachmentTable = $("<table style='table-layout: fixed; width: 100%;' />").appendTo($attachmentSection),
				$attachmentBody = $("<tbody />").appendTo($attachmentTable),
				$attachmentHeaderRow = $("<tr />").appendTo($attachmentBody),
				$attachmentHeaderDate = $("<td style='width: 40%; line-height: 40px; padding: 0 25px; color: #004165; border-right: 1px solid #ebebeb; background: #f8f8f8;'>Date &amp; Time</td>").appendTo($attachmentHeaderRow),
				$attachmentHeaderType = $("<td style='width: 60%; line-height: 40px; padding: 0 25px; color: #004165; background: #f8f8f8;'>Attachment Type</td>").appendTo($attachmentHeaderRow);
				if ( _enquiry.attachmentDate != "" ) {
					var $attachmentContentRow = $("<tr />").appendTo($attachmentBody),
					$attachmentDate = $("<td style='line-height: 40px; padding: 0 25px; color: #394A58;'>"+_enquiry.attachmentDate+"</td>").appendTo($attachmentContentRow),
					$attachmentType = $("<td style='line-height: 40px; padding: 0 25px; color: #394A58;'><a href='' style='text-decoration: none; color: #00c6d7;'>"+_enquiry.attachmentType+"</a></td>").appendTo($attachmentContentRow);
				}
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "enquiryDetails",
				title: "Enquiry Details",
				size: "large",
				icon: "<i class='fa fa-file-text'></i>",
				content: function(){return showEnquiryDetails(row)},
				buttons: [
					{ name: "Close", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
					{ name: "Update Enquiry", icon: "<i class='fa fa-edit fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] }
				]
			}
			dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('enquiryColumnWidth', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if ( store.get('enquiryColumnOrder') ) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('enquiryColumnOrder').length; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleColumns);
	}
	grid.setHeaderRowVisibility(false);

	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));

		
	/**********************************************************************
	SAVED SEARCH INTERACTIONS
	**********************************************************************/	
	$(".manage-searches").on("click", showSearchManagerDialog);
	populateSearches();


	/**********************************************************************
	INITIALIZE SEARCH INDICATORS
	**********************************************************************/
	indicatorSelection();


	/**********************************************************************
	SETTINGS MENU
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	SEARCH FIELDS
	**********************************************************************/
	$("#show-hide-search").on("click", function(e) {
		e.preventDefault();
		var $this = $(this);
		if ($this.attr("show") == "false") {
			showSearchFields();
		} else {
			hideSearchFields();
		}
	});


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}		
	});


	/**********************************************************************
	SETUP THE DATE FUNCTIONS
	**********************************************************************/
	var rollingDates = ["Today", "Yesterday", "Week to Date", "Previous Week", "Month to Date", "Previous Month"];
	$(".postingdaterolling, .valuedaterolling").autocomplete({
		source: rollingDates,
		autoFocus: true,
		delay: 0,
		minLength: 0,
		select: function(e, ui) {
			$(this).autocomplete("close");
		},
		change: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(rollingDates, function() {
				if (this.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this;
					return false;
				}
			});
			$(this).val(matchie);
			if (!valid) {
				$(this).val("");
				return false;
			}
		}
	});
	$(".postingdaterolling, .valuedaterolling").on("focus", function(e) {
		$(this).autocomplete("search", "");
	}).on("click", function(e) {
		$(this).autocomplete("search", "");
	}).on("keydown", function(e) {
		if (e.keyCode == "9") {
			e.stopImmediatePropagation();
		}
	});
	var postingdate = $(".postingdate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});
	var valuedate = $(".valuedate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});
	var postingdates = $(".postingdatefrom, .postingdateto")
	$(".postingdatefrom").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".postingdateto").datepicker("option", "minDate", selectedDate)
			setTimeout(function() {
				$(".postingdateto").focus()
			}, 50)
		}
	});
	$(".postingdateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".postingdatefrom").datepicker("option", "maxDate", selectedDate)
		}
	});
	var valuedates = $(".valuedatefrom, .valuedateto")
	$(".valuedatefrom").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".valuedateto").datepicker("option", "minDate", selectedDate)
			setTimeout(function() {
				$(".valuedateto").focus()
			}, 50)
		}
	});
	$(".valuedateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".valuedatefrom").datepicker("option", "maxDate", selectedDate)
		}
	});

	/**********************************************************************
	SELECTIZE FIELDS
	**********************************************************************/
	var selectize_options = {
		plugins: ['remove_button'],
		maxItems: null,
		maxOptions: 50,
		valueField: 'number',
		labelField: 'name',
		searchField: ['number', 'name'],
		highlight: false,
		hideSelected: true,
		options: ACCOUNTS,
		render: {
			item: function(item, escape) {
				if (item.name == item.number) return '<div>' + '<span class="name" style="margin-right:0px;">' + escape(item.name) + '</span></div>'
				return '<div>' +
					(item.name ? '<span style="font-weight:bold; margin-right:5px;">' + escape(item.name) + '</span>' : '') +
					(item.number ? '<span>' + escape(item.number) + '</span>' : '') +
					'</div>';
			},
			option: function(item, escape) {
				var label = item.name || item.number;
				var caption = item.name ? item.number : null;
				return '<div>' +
					'<div class="label" >' + escape(label) + '</div>' +
					(caption ? '<div class="caption">' + escape(caption) + '</div>' : '') +
					'</div>';
			}
		},
		onItemAdd: function(value, $item) {
			this.$control_input.blur().focus();
			this.$control_input.focus();
		},
		onItemRemove: function(value) {},
		onDropdownOpen: function($dropdown, value) {
			if (!this.$control_input.val().length) this.close();
		},
		load: function(query, callback) {},
		persist: false,
		addPrecedence: true,
		openOnFocus: false,
		closeAfterSelect: true,
		create: "false"
	};
	$('.account-search').selectize(selectize_options);
	selectize_options.render.item = function(item, escape) {
		return '<div>' +
			'<span style="font-weight:bold; margin-right:5px;">' + escape(item.number) + '</span>' +
			'</div>';
	}


	/**********************************************************************
	ADD / REMOVE ITEM MODAL
	**********************************************************************/
	function showAddItems(_target, title, headers, items, SEL_INPUT) {

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
			if ($("input[name=_addAccount]:checked").length > 0) {
				var ADD_ITEMS = [];
				var checked_items = $("input[name=_addAccount]:checked");

				for (var s = 0; s < checked_items.length; s++) {
					for (var i = s; i < items.length + s; i++) {
						if (i > items.length) i = i - items.length;
						if (items[i].number == checked_items.eq(s).val()) {
							ADD_ITEMS.push(items[i].number);
							break;
						}
					}
				}
				SEL_INPUT[0].selectize.addItems(ADD_ITEMS);
				dialogHider(_dialog);
			} else {
				dialogHider(_dialog);
			}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

			/* build the account filter input */
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
				if (this.value != '') {
					$("#clearAccountsFilter").show()
				} else {
					$("#clearAccountsFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#AddAccountsFilterInput").val("").trigger("change");
				$(this).hide();
			}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
			$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='_selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=_addAccount]:visible");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv);
		for (var i = 0; i < headers.length; i++) {
			var width = 600 / headers.length;
			if (headers.length > 2) i <= 2 ? width += 20 : width -= 40;
			else i == 0 ? width += 40 : width -= 40;
			$("<div class='fav-header-col' style='width: " + width + "px;'>" + headers[i] + "</div>").appendTo($header);
		}

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
			$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
			$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(items, function() {

			$li = $("<li>").appendTo($ul),
				$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						if ($target.hasClass("fav-data-col")) {
							$target = $target.closest("div.fav-row");
						}
						$target = $target.find("input[name='_addAccount']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='_selectAll']").prop("checked", false)
					}
					if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
						$("input[name='_selectAll']").prop("checked", true)
					}
				}),
				$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
			var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount'/>").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
			});
			for (var i = 0; i < headers.length; i++) {
				var width = 600 / headers.length;
				if (headers.length > 2) i <= 2 ? width += 20 : width -= 40;
				else i == 0 ? width += 40 : width -= 40;
				$("<div class='fav-data-col' style='width: " + width + "px;'>" + (i == 0 ? this.name : (i == 1 ? this.number : this.currency)) + "</div>").appendTo($row);
			}

			if ($.inArray(this.number, SEL_INPUT[0].selectize.items) > -1) {
				$li.remove();
			}
		});

		/* build and show the add accounts dialog */
		var _origin = _target;
		var _dialog = {
			id: "AddAccounts",
			title: title,
			size: "medium",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Add",
				icon: "<i class='fa fa-plus fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						saveSelectedAccounts(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		if (!$("#AddAccountsFilterList").children("li").length) {
			var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}
	}
	$(".account-search-column label>i").click(function() {
		showAddItems($(this), "Add Accounts", ["Account Name", "Account Number", "Currency"], accounts, $('.account-search'))
	});


	/**********************************************************************
	SEARCH / RESET BUTTONS
	**********************************************************************/
	$(".start-search").click(function(e) {
		e.preventDefault();
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			hideSearchFields();
			$("#noSearch").hide();
			$("#searchGrid").removeClass("hidden");
		}, 1000);
	});
	$(".resetSearch").click(function(e) {
		e.preventDefault();
		grid.setSelectedRows([]);
		$("#searchGrid").addClass("hidden");
		$("#noSearch").show();
	});

	
});