/**********************************************************************
						MICRO-TEMPLATE
**********************************************************************/
(function(){
  var cache = {};
  this.tmpl = function tmpl(str, data){
	var fn = !/\W/.test(str) ?
	  cache[str] = cache[str] ||
		tmpl(document.getElementById(str).innerHTML) :
	  new Function("obj",
		"var p=[],print=function(){p.push.apply(p,arguments);};" +
		"with(obj){p.push('" +
		str
		  .replace(/[\r\t\n]/g, " ")
		  .split("<%").join("\t")
		  .replace(/((^|%>)[^\t]*)'/g, "$1\r")
		  .replace(/\t=(.*?)%>/g, "',$1,'")
		  .split("\t").join("');")
		  .split("%>").join("p.push('")
		  .split("\r").join("\\'")
	  + "');}return p.join('');");
	return data ? fn( data ) : fn;
  };
})();


/**********************************************************************
ACCOUNT SUMMARY GRID
**********************************************************************/
var dataView, grid, data = [], selectedRowIds = [], loadRecordTimer;
var columns = [
	{id:"account", name:"Deal Name", formatter:renderCell, field:"dealname", cssClass:"contact-card-cell", type: "preview"}
];
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
options = {
	rowHeight: 70,	
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: true,
	multiSelect: true,
	showHeaderRow: false
};
var compiled_template = tmpl("cell_template");
function renderCell(row, cell, value, columnDef, dataContext) {
	return compiled_template(dataContext);
};
var groupedSetting = 0, groupCollapseSetting = 0, groupCCYSetting = "USD";
function sumTotalsFormatter(totals, columnDef) {
	return groupCCYSetting+" "+ addCommas(Math.round((totals.sum[columnDef.field] * 100)/100).toFixed(2));
}
function collapseAllGroups() {
	dataView.beginUpdate();
	for (var i = 0; i < dataView.getGroups().length; i++) {
		if(!dataView.getGroups()[i].collapsed)
			dataView.collapseGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
	dataView.endUpdate();
}
function expandAllGroups() {
	for (var i = 0; i < dataView.getGroups().length; i++) {
		dataView.expandGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
}
function clearGrouping() {
	dataView.groupBy(null);
	groupedSetting = 0;
}
function groupBy(item,text) {
	dataView.groupBy(
		item,
		function (g) {
			return text+":  " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		function (a, b) {
			return a.value - b.value;
		}
	);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var labelString = "", findString = "", findDataPoint = "accountnumb";
function myFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString)
		return false;
		
	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1)
		return false;

	return true;
}
function calculateTotals() {
	var totalAvailable = 0, totalLedger = 0;
	for (var i = 0; i < dataView.getLength(); i++) {
		if (dataView.getItem(i).id) {
			//totalAvailable = parseFloat(totalAvailable) + parseFloat(dataView.getItem(i).availablebal.replace(',', ''));
			//totalLedger = parseFloat(totalLedger) + parseFloat(dataView.getItem(i).ledgerbal.replace(',', ''));
		}
	}
	totalAvailable = addCommas(totalAvailable.toFixed(2))
	$("[data-value='totalavailable']").html(totalAvailable)
	totalLedger = addCommas(totalLedger.toFixed(2))
	$("[data-value='totalledger']").html(totalLedger)
}
function filterAccounts() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	calculateTotals()
}
if (store.get('oppLoaniq')) {
	data = store.get('oppLoaniq');
	for (var i = 0; i < data.length; i++) {
		data[i].baldate = $.datepicker.formatDate('dd/mm/yy', new Date());
	}
	store.set('oppLoaniq', data);
} else {
	for (var i = 0; i < 20; i++) {
		var d = (data[i] = {});
		d["id"] = "id_" + i;
		d["label"] = "None";
		d["labelid"] = "None";
		d["dealid"] = Math.floor(100000 + Math.random() * 9000000);
		d["currency"] = "AUD";
	    d["fxrate"] = 0.91;
		if(i%2 == 0){
			d["dealname"]  = "Abc Bridge 250M AUD";
			d["facilityname"]  = "Tranche A";
			d["noofdrawings"]  = 4;

			d["limit"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));
			d["undrwarn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));
			d["drawn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
		}
		else if(i%3 == 0){
			d["dealname"]  = "Abc Deal 50M AUD";
			d["facilityname"]  = "Tranche B";
			d["noofdrawings"]  = 2;
			d["limit"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
			d["undrwarn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));
			d["drawn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
		}
		else if(i%5 == 0){
			d["dealname"]  = "Abc Bridge 250M AUD";
			d["facilityname"]  = "Facility1";
			d["noofdrawings"]  = 3;
			d["limit"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
			d["undrwarn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));
			d["drawn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
		}
		else {
			d["dealname"]  = "XYZ Deal 5M AUD";
			d["facilityname"]  = "Facility2";
			d["noofdrawings"]  = 2;
			d["limit"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
			d["undrwarn"]  = addCommas((Math.round(Math.random() * 100000000) / 100).toFixed(2));
			d["drawn"]  = addCommas((Math.round(Math.random() * 1000000000) / 100).toFixed(2));;
		}

		/*d["accountnumb"] = Math.round(Math.random() * 1000000000).toString();
		d["baldate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
		d["openingavailablebal"] = addCommas((Math.round(Math.random() * 10000000) / 100).toFixed(2));
		d["openingledgerbal"] = addCommas((Math.round(Math.random() * 10000000) / 100).toFixed(2));
		d["availablebal"] = addCommas((Math.round(Math.random() * 10000000) / 100).toFixed(2));
		d["ledgerbal"] = addCommas((Math.round(Math.random() * 10000000) / 100).toFixed(2));
		d["overdraft"] = addCommas((Math.round(Math.random() * 1000000) / 100).toFixed(2));*/
	};
	store.set('oppLoaniq', data);
}


/**********************************************************************
BALANCE HISTORY GRID
**********************************************************************/
var balanceDataView;
var balancehistorygrid;
var	bdata = [];
var	bcolumns = [{
		id: "outstandingalias",
		name: "Outstanding Alias",
		field: "outstandingalias",
		width: 100,
		sortable: true,
		visible: true
	}, {
		id: "pricingoption",
		name: "Pricing Option",
		field: "pricingoption",
		width: 175,
		
		sortable: true,
		visible: true
	}, {
		id: "amount",
		name: "Amount",
		field: "amount",
		width: 175,

		sortable: true,
		visible: true
	}, {
		id: "startdate",
		name: "Start Date",
		field: "startdate",
		width: 175,
		
		sortable: true,
		visible: true
	}, {
		id: "duedate",
		name: "Due Date",
		field: "duedate",
		width: 175,
		
		sortable: true,
		visible: true
	}, {
		id: "baserate",
		name: "Base Rate",
		field: "baserate",
		width: 175,
		
		sortable: true,
		visible: true
	}, {
		id: "alluprate",
		name: "All Up Rate",
		field: "alluprate",
		width: 175,
		
		sortable: true,
		visible: true
	}, {
		id: "interestcycle",
		name: "Interest Cycle",
		field: "interestcycle",
		width: 175,
		
		sortable: true,
		visible: true
	},{
		id: "projectedinterestdue",
		name: "Projected Interest Due",
		field: "projectedinterestdue",
		width: 175,
		
		sortable: true,
		visible: true
	}],
boptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: true,
	autoHeight: false,
	forceFitColumns: false
};
if ( store.get('balanceOrder') ) {
	bcolumns = store.get('balanceOrder');
}
if ( store.get('balanceWidths') ) {
	var setBalanceWidth = store.get('balanceWidths');
	for (var i in setBalanceWidth) {
		var s = setBalanceWidth[i]
		for (c = 0; c < bcolumns.length; c++) {
			if (s.id == bcolumns[c].id) {
				bcolumns[c].width = s.width
			}
		}
	}
}
for (var i = 0; i < 30; i++) {
	var d = (bdata[i] = {});
	d["id"] = "id_" + i;
	if(i%2 ==0){
		d["duedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
		d["startdate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/08/2016"));
		d["outstandingalias"] = "ABC 0001";
		d["pricingoption"] = "BKBM";
		d["amount"] = "100m";
		d["baserate"] = "2.12%";
		d["alluprate"] = "4.12%";
		d["interestcycle"] = "End Of Term";
		d["projectedinterestdue"] = Math.round(Math.random() * 1000000) / 1000;
	}
	else if(i%3 ==0){
		d["duedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
		d["startdate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/08/2016"));
		d["outstandingalias"] = "ABC 0002";
		d["pricingoption"] = "ANZ Variable";
		d["amount"] = "40m";
		d["baserate"] = "2.32%";
		d["alluprate"] = "4.32%";
		d["interestcycle"] = "Monthly";
		d["projectedinterestdue"] = Math.round(Math.random() * 1000000) / 1000;
	}
	else {
		d["duedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
		d["startdate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/08/2016"));
		d["outstandingalias"] = "ABC 0003";
		d["pricingoption"] = "BKBM";
		d["amount"] = "50m";
		d["baserate"] = "3.14%";
		d["alluprate"] = "4.64%";
		d["interestcycle"] = "End Of Term";
		d["projectedinterestdue"] = Math.round(Math.random() * 1000000) / 1000;
	}
	//d["closingavailbal"] = Math.round(Math.random() * 1000000) / 1000;
	//d["openingledgbal"] = Math.round(Math.random() * 1000000) / 1000;
	//d["closingledgbal"] = Math.round(Math.random() * 1000000) / 1000;
}


/**********************************************************************
Ammortisation  GRID
**********************************************************************/
var activity1DataView;
var activity1Grid;
var activity1Data = [];
var activity1SelectedRowIds = [];
var activity1Columns = [{
		id: "item",
		name: "Item",
		field: "item",
		sortable: true,
		width: 100
	}, {
		id: "amount",
		name: "Amount",
		field: "amount",
		width: 110,
		sortable: true
	}, {
		id: "duedate",
		name: "Due Date",
		field: "duedate",
		sortable: true,
		width: 200
	},{
		id: "remainingamount",
		name: "Remaining Amount",
		field: "remainingamount",
		sortable: true,
		width: 200
	}],
	activity1Options = {
		editable: false,
		autoEdit: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnReorderCheckbox: false,
		syncColumnCellResize: false,
		forceFitColumns: false,
		multiSelect: false,
		showHeaderRow: false
	};
if (store.get('activity1Order')) {
	activity1Columns = store.get('activity1Order');
	for (i = 0; i < activity1Columns.length; i++) {
		if (activity1Columns[i].id == "damount" || activity1Columns[i].id == "camount") {
			activity1Columns[i].groupTotalsFormatter = sumTotalsFormatter
		}
	}
}
if (store.get('activity1Widths')) {
	var setActivityWidth = store.get('activity1Widths');
	for (var i in setActivity1Width) {
		var s = setActivity1Width[i]
		for (c = 0; c < activity1Columns.length; c++) {
			if (s.id == activity1Columns[c].id) {
				activity1Columns[c].width = s.width
			}
		}
	}
}
/*var activity1CheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
activity1Columns.unshift(activity1CheckboxSelector.getColumnDefinition());
*/
function trxncollapseAllGroupsammor() {
	activity1DataView.beginUpdate();
	for (var i = 0; i < activity1DataView.getGroups().length; i++) {
		if (!activity1DataView.getGroups()[i].collapsed)
			activity1DataView.collapseGroup(activity1DataView.getGroups()[i].value, activity1DataView.getGroups()[i].rows);
	}
	activityDataView.endUpdate();
}

function trxnexpandAllGroupsammor() {
	for (var i = 0; i < activity1DataView.getGroups().length; i++) {
		activity1DataView.expandGroup(activity1DataView.getGroups()[i].value, activity1DataView.getGroups()[i].rows);
	}
}

function trxnclearGroupingammor() {
	activity1DataView.groupBy(null);
}

function trxngroupByammor(item, text) {
	activity1DataView.groupBy(
		item,
		function(g) {
			return text + ":  " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		function(a, b) {
			return a.value - b.value;
		}
	);
	activity1DataView.setAggregators([
		new Slick.Data.Aggregators.Sum("damount"),
		new Slick.Data.Aggregators.Sum("camount")
	], true);
	if (groupCollapseSetting == 1) {
		trxncollapseAllGroupsammor();
	}
}
var findActivity1String = "",
	findActivity1DataPoint = "feetype";

function myActivity1Filter(item, args) {

	if (args.findActivityString != "" && item[findActivityDataPoint].toLowerCase().indexOf(args.findActivityString.toLowerCase()) == -1)
		return false;

	return true;
}

function filterActivity1() {
	var $loading = $(".loading-panel"),
		$primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showActivity = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		activityDataView.refresh();
		if (groupCollapseSetting == 1) {
			trxncollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showActivity, 500);
}
for (var i = 0; i < 45; i++) {
	var d = (activity1Data[i] = {});
	d["id"] = "id_" + i;
	
	d["item"] = i+1;

	if (i % 2 == 0) {
		d["amount"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
		d["duedate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/01/2017") );
		d["remainingamount"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
	}
	else if (i % 3 == 0) {
		d["amount"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
		d["duedate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/09/2016") );
		d["remainingamount"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
		
	} else {
		d["amount"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
		d["duedate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/10/2016") );
		d["remainingamount"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
	};
	
}



/**********************************************************************
ACCOUNT ACTIVITY GRID
**********************************************************************/
var activityDataView;
var activityGrid;
var activityData = [];
var activityColumns = [{
		id: "feename",
		name: "Fee Name",
		field: "feename",
		sortable: true,
		width: 170
	}, {
		id: "feetype",
		name: "Fee Type",
		field: "feetype",
		width: 110,
		sortable: true
	}, {
		id: "marginoramount",
		name: "Margin / Amount",
		field: "marginoramount",
		sortable: true,
		width: 200
	},{
		id: "cyclestartdate",
		name: "Cycle Start Date",
		field: "cyclestartdate",
		sortable: true,
		width: 200
	},
	{
		id: "cycleenddate",
		name: "Cycle End Date",
		field: "cycleenddate",
		sortable: true,
		width: 200
	},  {
		id: "projectedfeedue",
		name: "Projected Fee Due",
		field: "projectedfeedue",
		width: 200,
		cssClass: "centered",
		sortable: true
	}],
activityOptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	autoHeight: false,
	forceFitColumns: false,
	multiSelect: true
};
if ( store.get('activityOrder') ) {
	activityColumns = store.get('activityOrder');
	for (i = 0; i < activityColumns.length; i++) {
		if (activityColumns[i].id == "damount" || activityColumns[i].id == "camount") {
			activityColumns[i].groupTotalsFormatter = sumTotalsFormatter
		}
	}
}
if ( store.get('activityWidths') ) {
	var setActivityWidth = store.get('activityWidths');
	for (var i in setActivityWidth) {
		var s = setActivityWidth[i]
		for (c = 0; c < activityColumns.length; c++) {
			if (s.id == activityColumns[c].id) {
				activityColumns[c].width = s.width
			}
		}
	}
}
var activityCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
activityColumns.unshift(activityCheckboxSelector.getColumnDefinition());
function trxncollapseAllGroups() {
	activityDataView.beginUpdate();
	for (var i = 0; i < activityDataView.getGroups().length; i++) {
		if(!activityDataView.getGroups()[i].collapsed)
			activityDataView.collapseGroup(activityDataView.getGroups()[i].value, activityDataView.getGroups()[i].rows);
	}
	activityDataView.endUpdate();
}
function trxnexpandAllGroups() {
	for (var i = 0; i < activityDataView.getGroups().length; i++) {
		activityDataView.expandGroup(activityDataView.getGroups()[i].value, activityDataView.getGroups()[i].rows);
	}
}
function trxnclearGrouping() {
	activityDataView.groupBy(null);
}
function trxngroupBy(item,text) {
	activityDataView.groupBy(
		item,
		function (g) {
			return text+":  " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		function (a, b) {
			return a.value - b.value;
		}
	);
	activityDataView.setAggregators([
		new Slick.Data.Aggregators.Sum("damount"),
		new Slick.Data.Aggregators.Sum("camount")
	], true);
	if(groupCollapseSetting == 1) {
		trxncollapseAllGroups();
	}
	activityGrid.invalidate();
	activityGrid.render();
}
var findActivityString = "", findActivityDataPoint = "transcode";
function myActivityFilter(item, args) {
		
	if (args.findActivityString != "" && item[findActivityDataPoint].toLowerCase().indexOf(args.findActivityString.toLowerCase()) == -1)
		return false;

	return true;
}
function filterActivity() {
	var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showActivity = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		activityDataView.refresh();
		if(groupCollapseSetting == 1) {
			trxncollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showActivity, 500);
}
for (var i = 0; i < 45; i++) {
	var d = (activityData[i] = {});
	d["id"] = "id_" + i;
	d["cyclestartdate"] = $.datepicker.formatDate('dd/mm/yy', new Date("01/09/2016") );
	d["cycleenddate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["valuedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());

	if (i % 3 == 0) {
		d["projectedfeedue"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
		
		d["marginoramount"] = "0.5%";
		d["feetype"] = "In Advance";
		d["feename"] = "Line Fee";
	} else {
		d["projectedfeedue"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
		
		d["marginoramount"] = "0.25%";
		d["feetype"] = "In Arrears";
		d["feename"] = "Committment Fee";
	};
	
}


/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var user_account_folders = [], folders_updated = false, folders_deleted = false;
$folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Accounts</p><p style='font-size: 14px;'>Folders help you keep your accounts organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move accounts into a folder by selecting them in the accounts grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-folder fa-fw'></i> Folder Menu.</p></div>"),
$folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if ( store.get('account_folders') ) { user_account_folders = store.get('account_folders') };
function folderFilter() {
	var rows = grid.getSelectedRows()
	if(rows.length > 0) {
		grid.setSelectedRows(0)
	}
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	})
	filterAccounts()
}
function folderChecker(val) {
	var _folder = val, error = false, $folderList = $(".folder-list").children("li"), existingFolders = [];
	for ( var i = 0; i < $folderList.length; i++ ) {
		existingFolders.push( $folderList.eq(i).attr("data-folder") );
	}
	if ($.inArray(_folder, existingFolders) != -1) { error = "existing" }
	return error;
}
function renameFolder(el) {
	var newFolderName = $.trim(el.val());
	if ( newFolderName == '' || newFolderName == "undefined" ) {
		el.val( el.attr("data-folder-name") );
	} else {
		el.val(newFolderName);
		el.closest("li").attr("data-folder", newFolderName );
		folders_updated = true;
	}
}
function addFolder() {
	var folderName = $.trim($("#newFolderInput").val()), $folderList = $("ul.folder-list"), $newFolderDiv = $("div.new-folder"), $li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
	if ( folderName == '' || folderName== "undefined" ) {
		$("#newFolderInput").val('');
		return false;
	} else {	
		if ( folderCheck == "existing" ) {
			 $newFolderDiv.addClass("error");
			 $("#newFolderInput").focus().select().one("keyup.remove-error", function() { $newFolderDiv.removeClass("error"); });
		} else {
			if ( $newFolderDiv.hasClass("error") ) { $newFolderDiv.removeClass("error"); }
			if ( $(".folder-message").size() ) {
				$(".folder-message").remove();
				$folderListInstruction.insertBefore($folderList);
			}
			$li = $("<li data-folder='"+folderName+"' data-folder-id='"+randString()+"' class='row new' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' value='"+folderName+"' maxlength='25' data-folder-name='"+folderName+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
			$("#newFolderInput").val('');
			$folderList.sortable("refresh");
			folders_updated = true;		
		}
	}
}
function addFolderInline() {
	var folderName = $.trim($("#_inlineFolderInput").val()), folderExists = false;
	if ( folderName == '' || folderName == "undefined" ) {
		$("#_inlineFolderInput").val('');
		return false;
	} else {
		for ( var i = 0; i < user_account_folders.length; i++ ) {
			if ( folderName == user_account_folders[i].name ) {
				folderExists = true;
				break;
			}
		}
		if ( folderExists ) {
			alert("A folder with that name already exists.");
		} else {
			var _id = randString();
			var _new = { name: folderName, id: _id };
			user_account_folders.push(_new);
			populateFolders();
			store.set('account_folders', user_account_folders);
			$("#_inlineFolderInput").val('');
			moveAccounts(_id);
		}
	}

}
function deleteFolder(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function(){
		if ( !$target.hasClass('new') ) { folders_deleted = true; }
		$target.remove();
		$(".folder-list").sortable("refresh");
		folders_updated = true;
		if ( !$(".folder-list").children("li").size() ) {
			$(".folder-list-instructions").remove();
			$folderMessage.appendTo(".folder-settings");
		}
		if ( $("div.new-folder").hasClass("error") ) {
			 $("div.new-folder").removeClass("error");
		}
	 });
}
function populateFolders() {
	var $assignFolders = $(".assign-folders"), folderCount = user_account_folders.length, activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
	$assignFolders.children().remove();
	if ( $("#removeFromFolder").size() > 0 ) { $("#removeFromFolder").remove(); }
	if ( folderCount > 0 ) {
		var $li, $a
		$assignFolders.each( function() {
			var _this = $(this);
			if (  _this.parents().attr("id") == "folderMenu" ) {
				$.each(user_account_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
					}).appendTo($li);
				});
				var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
				$spacer = $("<li class='menu-section' />").appendTo($ul),
				$li = $("<li />").appendTo($ul),
				$a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected accounts from folders' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
					e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
				}).appendTo($li),
				$spacer = $("<li class='menu-section' />").appendTo($ul);
			} else if ( _this.parents().attr("id") == "viewMenu" ) {
				$.each(user_account_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					if ( this.id == activeFolder ) { $li.addClass("active"); $("#viewMenuControl").children("a").children("span").html(this.name); }
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault();
						var _folderID = $(this).attr("data-folder-id"), _folderName = $(this).attr("data-folder");
						if ( labelString != _folderID ) {
							labelString = _folderID;
						}
						folderFilter();
						$("#selectedFolder").html(_folderName);
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
		$li = $("<li class='no-set' />").appendTo($viewMenu),
		$a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Account Folders</div>Folders help keep your accounts organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
	}
}
function populateFolderManager() {	
	folders_updated = false; folders_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
	$folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
	$folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
	$folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e){if(e.keyCode == 13){addFolder()}}).appendTo($folderAddDiv),
	$folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
	$folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
	$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({ handle: '.reorder-folder', axis: 'y', tolerance: "pointer", update: function( event, ui ) { folders_updated = true } }),
	folderCount = user_account_folders.length, $li, $div, $span, $input, $a, $error;
	if ( folderCount > 0 ) {
		$folderListInstruction.insertBefore($folderList);
		$.each(user_account_folders, function() {
			$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='"+this.name+"' data-folder-name='"+this.name+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
		});
	} else {
		$folderMessage.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showFolderManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Operating Account Folders",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function(){return populateFolderManager()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();updateFolders(_dialog)}}] }
		] 
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );	
}
function saveFolders(dialog) {
	var $dialog = $("#"+dialog.id), $active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
	$dialog.addClass("working");	
	user_account_folders = folders_updated;
	
	var active_deleted = true;
	
	for ( f = 0; f < user_account_folders.length; f++ ) {
		if ( $active == user_account_folders[f].id ) {
			active_deleted = false;
			break;
		}
	}
	
	for ( var i = 0; i < data.length; i++ ) {
		var _resetFolder = true;
		for ( var n = 0; n < user_account_folders.length; n++ ) {
			if ( data[i].labelid == user_account_folders[n].id ) {
				data[i].label = user_account_folders[n].name;
				_resetFolder = false;
				break;
			} 
		}	
		if ( _resetFolder ) {
			data[i].label = "None";
			data[i].labelid = "None";
		}

	}	
	folders_updated = false;
	folders_deleted = false;
	store.set('account_folders', user_account_folders);
	setTimeout( function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateFolders();
		if ( !user_account_folders.length || active_deleted ) { $("#_allAccounts").trigger("click"); }
		dialogHider(dialog);
	}, 300);
}
function updateFolders(dialog) {
	if ( folders_updated ) {
		folders_updated = [];
		var duplicate_names = false, $folderList = $(".folder-list");
		$folderList.find("li.error").removeClass("error");
		$folderList.children("li").each(function() {
			folders_updated.push( { "name":$(this).attr("data-folder"), "id":$(this).attr("data-folder-id") });
			var _name = $(this).attr("data-folder");
			$(this).siblings().each(function() {
				if ( $(this).attr("data-folder") == _name ) {
					$(this).addClass("error");
				}
			});
		});
		if ( $folderList.find("li.error").size() ) {
			duplicate_names = true;
		}
		if ( duplicate_names ) {	
			return false;
		} else {		
			var save_folders = false;
			if ( user_account_folders.length != folders_updated.length ) {
				save_folders = true;
			} else {
				for (var i = 0; i < user_account_folders.length; i++) {
					if ( user_account_folders[i].name != folders_updated[i].name || user_account_folders[i].id != folders_updated[i].id ) {
						save_folders = true;
						break;
					}
				}
			}
			if ( save_folders || folders_deleted ) {
				if ( folders_deleted ) {
					buildConfirmDialog( "You've removed some existing folders.", "Are you sure you want to continue?", function(){saveFolders(dialog)});
				} else {
					saveFolders(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}
function moveAccounts(_id) {
	var _folder, _message, _rowsForUpdate = [], _sel = selectedRowIds.length;
	for ( var i = 0; i < user_account_folders.length; i++ ) {
		if ( user_account_folders[i].id == _id ) {
			_folder = user_account_folders[i];
			_message = "Selected accounts were moved to &quot;"+_folder.name+"&quot;";
			break;
		}
	}
	if ( _id == "None" ) {
		_folder = [{ name:"None", id:"None"}];
		_message = "Selected accounts were removed from their folders";
	}
	for ( var i = 0, l = _sel; i < l; i++ ) {
		var _item = selectedRowIds[i];
		if ( _item ) {
			_rowsForUpdate.unshift(_item);
		}
	}
	for ( var i = 0; i < _rowsForUpdate.length; i++ ) {
		data[dataView.getIdxById(_rowsForUpdate[i])].label = _folder.name;
		data[dataView.getIdxById(_rowsForUpdate[i])].labelid = _folder.id;
	}
	grid.setSelectedRows(0);
	selectedRowIds = [];
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) { collapseAllGroups(); }
	groupedSetting = 1;
	buildNotification(_message, 300, 3000);
	store.set('oppAccounts', dataView.getItems());
	$("#viewMenu .assign-folders").find("a[data-folder-id='"+_folder.id+"']").trigger("click");
}



/**********************************************************************
MODAL WINDOWS 
**********************************************************************/
function showAccountStatementModal(e) {
	e.preventDefault();
	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.","It will be available for download in the &quot;Download Reports&quot; section shortly.","");
		}, 3000);
	};
	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).parent("div.data-column").find("div.data-text"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='statementSpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();			
		} else if ( _date == "dr" ) {
			$("#statementSpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='statementFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='statementToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var statementeDatRange = $("#statementFromDate, #statementToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "statementFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					statementeDatRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#statementSpecificDate, #statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
		$row.add("focused");
	};
	var formElements = [
		{ name: "Report Format", id: "stmt-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "MT940", value: "MT940"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "stmt-name", type: "input", max: 30 },
		{ name: "Description", id: "stmt-desc", type: "input", max: 75 },
		{ name: "Data From", id: "stmt-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function(){ $(this).addClass("focused") }).on("focusout", function(){ $(this).removeClass("focused") }).appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $note;
		if ( formElements[i].type == "select" ) {
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
		} else if ( formElements[i].type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}
		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}
		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}	
		$el.appendTo($data);
		if ( formElements[i].note ) {
			$note = $("<div class='data-text'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestStatement",
		title: "Account Statement Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}] }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
function showBalanceHistoryModal(e) {
	e.preventDefault();
	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report took more than 3 seconds to generate.","It will be available for download in the &quot;Downloads&quot; section shortly.","");
		}, 3000);
	};
	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).parent("div.data-column").find("div.data-text"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='summarySpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();			
		} else if ( _date == "dr" ) {
			$("#summarySpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='summaryFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='summaryToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var summaryDateRange = $("#summaryFromDate, #summaryToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "summaryFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					summaryDateRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#summarySpecificDate, #summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
		$row.add("focused");
	};
	var formElements = [
		{ name: "Report Format", id: "bal-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "MT940", value: "MT940"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "bal-name", type: "input", max: 30 },
		{ name: "Description", id: "bal-desc", type: "input", max: 75 },
		{ name: "Data From", id: "bal-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function(){ $(this).addClass("focused") }).on("focusout", function(){ $(this).removeClass("focused") }).appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $note;
		if ( formElements[i].type == "select" ) {
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
		} else if ( formElements[i].type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}
		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}
		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}	
		$el.appendTo($data);
		if ( formElements[i].note ) {
			$note = $("<div class='data-text'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestBalances",
		title: "Balance Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}] }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}

/**********************************************************************
SERVICE REQUEST WARNING
**********************************************************************/
function navigateToServiceRequests(e) {
	document.location.href="service-requests-from-account.html#new";
}

function createServiceRequestWarning(e) {
	e.preventDefault();
	buildConfirmDialog( "This will take you to the Service Requests Application to create a new account related service request.", "Do you want to proceed?", function(){navigateToServiceRequests(e)});
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


/**********************************************************************
INITIALIZE ACCOUNT SUMMARY GRID
**********************************************************************/
var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
dataView = new Slick.Data.DataView({
	groupItemMetadataProvider: groupItemMetadataProvider
});
grid = new Slick.Grid("#summaryGrid", dataView, columns, options);
grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:true}));
grid.registerPlugin(groupItemMetadataProvider);
grid.registerPlugin(checkboxSelector);

var sortcolumns = [
	{id:"dealname", name:"Deal Name", field:"dealname", toolTip:"Click to sort by Deal Name", width: 160, sortable:true, visible: true},
	{id:"dealid", name:"Deal ID", field:"dealid", toolTip:"Click to sort by Deal ID", width: 160, sortable: true, visible: true},
	{id:"facility", name:"Facility", field:"facility", toolTip:"Click to sort by Facility", width: 75, sortable:true, visible: true},
	{id:"limit", name:"Limit", field:"limit", toolTip:"Click to sort by Limit", width: 130, sortable:true, cssClass: "num pos", headerCssClass: "righted", visible: true}
];
new Slick.Controls.SlickPreviewSortPicker(sortcolumns, grid, options);


var $accountsGrid = $(grid.getCanvasNode()),
$scrollArea = $("#summaryGrid").parent("div.scroll-area"),
$bottomControls = $("#accountGrid .bottom-controls"),
$selected = $("#selectedCount");
grid.onContextMenu.subscribe(function (e,args) {
	e.preventDefault();	
	var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
	if ($.inArray(row, rows) == -1) {
		grid.setSelectedRows([row])
		$cmenu = $("#contextMenu")
	} else {
		if (rows.length > 1) {
			$cmenu = $("#multipleContextMenu")
		} else {
			$cmenu = $("#contextMenu")
		}
	};
	var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
	if(e.pageX + 210 > winwidth) {
		leftpos = e.pageX-205;
	}
	if(e.pageY + cheight > winheight) {
		toppos = e.pageY-cheight;
		if(toppos < 0) {
			toppos = e.pageY - (cheight-(winheight-e.pageY));
		}
	};
	$(document).off("keyup.hide-context");
	$("body").off("click.hide-context");
	function hideContextMenu() {		
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		$(".control-menus").find("a.sub-open").removeClass("sub-open");
	}
	hideContextMenu();
	$cmenu.css("top", toppos).css("left", leftpos).show();
	$(document).on("keyup.hide-context", function(e) {
		if(e.keyCode == 27) {
			hideContextMenu()
		}
	});
	$("body").one("click.hide-context", function() {
		hideContextMenu()
	});
});	 
grid.onSelectedRowsChanged.subscribe(function(e) {
	clearTimeout(loadRecordTimer);
	$(document).off("keyup.hide-menu");
	$(".shell").off("resize.hide-menu");
	$("body").off("click.hide-menu");
	$(".control-menus").children(".control-menu:visible").hide();
	$(".control-list").children(".on").removeClass("on");
	selectedRowIds = [];
	selectedReportOwners = [];
	var rows = grid.getSelectedRows();
	for (var i = 0, l = rows.length; i < l; i++) {
		var item = dataView.getItem(rows[i])
		if (item.id) {
			selectedRowIds.push(item.id);
			selectedReportOwners.push(item.ownedby)
		}
	}
	if ( !rows.length ) {
		grid.resetActiveCell();
		$(".selection-panel").show().find("div[data-value='multiple-selection']").hide();
		$(".selection-panel").find("div[data-value='no-selection']").show();
		$selected.html('');
	} else if ( rows.length === 1 ) {
		if ( !grid.getActiveCell() || grid.getActiveCell().row != rows[0] ) {
			 grid.setActiveCell( rows[0], 1);
		}
		$selected.html(selectedRowIds.length);
		$(".right-panel").addClass("loading").find(".scroll-area").scrollTop("0");
		loadRecordTimer = setTimeout( function() {
			$(".right-panel").removeClass("loading");
			$(".selection-panel").hide();
		}, 500);
	} else if ( rows.length > 1 ) {
		$(".right-panel").removeClass("loading");
		$(".selection-panel").show().find("div[data-value='no-selection']").hide()
		$(".selection-panel").find("div[data-value='multiple-selection']").show();
		$selected.html(selectedRowIds.length);
	}
});
grid.onClick.subscribe(function(e, args) {
	var row = args.row;
	if ( grid.getActiveCell() && grid.getActiveCell().row == args.row ) {
		grid.resetActiveCell();
	}
	grid.setSelectedRows([row]);
	grid.setActiveCell(row, 1);
});
grid.onActiveCellChanged.subscribe(function(e, args) {
	var item = grid.getActiveCell(), $row = $(grid.getActiveCellNode()).closest(".slick-row");
	if ( $row.is(".slick-group, .slick-group-totals") ) {
		return false;
	} else {
		if ( item ) {
			if ( grid.getActiveCell().row != grid.getSelectedRows([0]) || !grid.getSelectedRows().length ) {
				 grid.setSelectedRows([item.row]);
			}
		}
	}
});
grid.onSort.subscribe(function(e, args) {
	sortcol = args.sortCol.field;
	sortdir = args.sortAsc ? 1 : -1;
	dataView.fastSort(sortcol, args.sortAsc);
});
dataView.onRowCountChanged.subscribe(function(e,args) {
	grid.updateRowCount();
	grid.render();
});
dataView.onRowsChanged.subscribe(function(e,args) {
	grid.invalidateRows(args.rows);
	grid.render();
	if (selectedRowIds.length > 0)
	{
		var selRows = [];
		for (var i = 0; i < selectedRowIds.length; i++)
		{
			var idx = dataView.getRowById(selectedRowIds[i]);
			if (idx != undefined)
				selRows.push(idx);
		}
		grid.setSelectedRows(selRows);
	}
});
if (store.get('oppAccounts')) {
	data = store.get('oppAccounts')
}
dataView.setItems(data);
dataView.setFilterArgs({
	labelString: labelString,
	findString: findString
});
dataView.setFilter(myFilter);
grid.setColumns(columns);


/**********************************************************************
CALCULATE GRAND TOTALS
**********************************************************************/	
calculateTotals()



/**********************************************************************
INITIALIZE BALANCE HISTORY GRID
**********************************************************************/	
var balanceHistoryItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
balanceDataView = new Slick.Data.DataView({
	balanceHistoryItemMetaProvider: balanceHistoryItemMetaProvider
});
balancehistorygrid = new Slick.Grid("#balanceGrid", balanceDataView, bcolumns, boptions);
balancehistorygrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
balancehistorygrid.registerPlugin(balanceHistoryItemMetaProvider);
var bcolumnpicker = new Slick.Controls.ColumnPicker(bcolumns, balancehistorygrid, boptions, 'balanceOrder', 'balanceWidths');
balancehistorygrid.onSort.subscribe(function(e, args) {
	sortcol = args.sortCol.field;
	sortdir = args.sortAsc ? 1 : -1;
	balanceDataView.fastSort(sortcol, args.sortAsc);
});

balancehistorygrid.onClick.subscribe(function(e, args) { 

		var acell = balancehistorygrid.getCellFromEvent(e),
			arow = acell.row,
			$arow = $(e.target).closest(".slick-row");
		if (!$arow.is(".slick-group, .slick-group-totals")) {
			e.preventDefault();
			balancehistorygrid.setSelectedRows(0);
			activitySelectedRowIds = [];

			function showTransactionDetails() {
				function navigateTransactions() {}

				function voucherImages() {}

				function transactionHelp() {}
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
					$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
					$controls = $("<div class='control-list right' />").appendTo($navigationBar),
					$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
					$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
					$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
					details = [{
						name: "Outstanding Alias",
						id: "td1",
						type: "text",
						data: "ABC 0001"
					}, {
						name: "Facility",
						id: "td2",
						type: "text",
						data: "Tranche A"
					}, {
						name: "Name",
						id: "td3",
						type: "text",
						data: "BKBM"
					}, {
						name: "Pricing",
						id: "td4",
						type: "text",
						data: "ABC Pty Ltd"
					}, {
						name: "Option",
						id: "td5",
						type: "text",
						data: "100m"
					}, {
						name: "Base Rate",
						id: "td6",
						type: "text",
						data: "2.12%"
					}, {
						name: "Margin",
						id: "td7",
						type: "text",
						data: "2.00%"
					}, {
						name: "All Up Rate",
						id: "td8",
						type: "text",
						
						data: "4.12%"
					},
					 {
						name: "Start Date",
						id: "td9",
						type: "text",
						data: smartDates("randompast")
					}, {
						name: "End Date",
						id: "td10",
						type: "text",
						data: smartDates("yesterday")
					},  {
						name: "Interest Due Date",
						id: "td11",
						type: "text",
						data: smartDates("yesterday")
					}, {
						name: "Interest Cycle",
						id: "td12",
						type: "text",
						data: "End Of Term"
					},  {
						name: "Repricing",
						id: "td13",
						type: "text",
						data: "Quarterly"
					}, {
						name: "Frequency",
						id: "td14",
						type: "text",
						data: "In Arrears"
					},  {
						name: "Payment Method",
						id: "td15",
						type: "text",
						data: "Actual/365"
					}, {
						name: "Accrued Interest Till Date",
						id: "td16",
						type: "text",
						data: "402,23.23"
					}, {
						name: "Projected Interest Due",
						id: "td17",
						type: "text",
						data: "$1,045,344.23"
					}],
					$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
					$formSection = $("<div class='form-section' />").appendTo($detailsForm);
				for (var i = 0; i < details.length; i++) {
					var $row = $("<div class='row' />").appendTo($formSection),
						$label = $("<div class='label-column' style='width:45%'><label>" + details[i].name + "</label></div>)").appendTo($row),
						$data = $("<div class='data-column' style='width:30%' />").appendTo($row),
						$el = $("<div class='data-text' id='" + details[i].id + "'>" + details[i].data + "</div>").appendTo($data);
					if (details[i].attributes) {
						for (var a = 0; a < details[i].attributes.length; a++) {
							$el.attr(details[i].attributes[a].name, details[i].attributes[a].value);
						}
					}
				};
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "transactionDetails",
				title: "Outstanding Summary",
				size: "medium",
				icon: "<i class='fa fa-file-text'></i>",
				content: function() {
					return showTransactionDetails()
				},
				buttons: [{
					name: "Close",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Outstanding Summary",
					icon: "<i class='fa fa-file-text fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}
		//var bcell = balancehistorygrid.getCellFromEvent(e);
		//var brow = balancehistorygrid.row;
		//$('#accountActivityTab').trigger('click');
	});



balancehistorygrid.onColumnsReordered.subscribe(function(e, args) {
	store.set('balanceOrder', bcolumns);
});
balancehistorygrid.onColumnsResized.subscribe(function(e, args) {
	store.set('balanceWidths', balancehistorygrid.getColumns());
});
balanceDataView.onRowCountChanged.subscribe(function(e,args) {
	balancehistorygrid.updateRowCount();
	balancehistorygrid.render();
});
balanceDataView.onRowsChanged.subscribe(function(e,args) {
	balancehistorygrid.invalidateRows(args.rows);
	balancehistorygrid.render();
});	
balanceDataView.setItems(bdata);
balancehistorygrid.setColumns(bcolumns);
if ( store.get('balanceOrder') ) {
	var visibleBalanceColumns = [];
	for (var i = 0; i < store.get('balanceOrder').length; i++) {
		if (bcolumns[i].visible) {
			visibleBalanceColumns.push(bcolumns[i])
		}
	}
	balancehistorygrid.setColumns(visibleBalanceColumns);
}

/**********************************************************************
INITIALIZE Ammortisation HISTORY GRID
**********************************************************************/	
var balanceHistoryItemMetaProvider1 = new Slick.Data.GroupItemMetadataProvider();
balanceDataView1 = new Slick.Data.DataView({
	balanceHistoryItemMetaProvider1: balanceHistoryItemMetaProvider1
});
balancehistorygrid1 = new Slick.Grid("#ammortisationGrid", balanceDataView1, activity1Columns, activity1Options);
balancehistorygrid1.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
balancehistorygrid1.registerPlugin(balanceHistoryItemMetaProvider);
var bcolumnpicker1 = new Slick.Controls.ColumnPicker(activity1Columns, balancehistorygrid1, activity1Options, 'balanceOrder1', 'balanceWidths1');
balancehistorygrid1.onSort.subscribe(function(e, args) {
	sortcol = args.sortCol.field;
	sortdir = args.sortAsc ? 1 : -1;
	balanceDataView1.fastSort(sortcol, args.sortAsc);
});
/*balancehistorygrid1.onClick.subscribe(function(e, args) {
	var bcell = balancehistorygrid1.getCellFromEvent(e);
	var brow = balancehistorygrid1.row;
	$('#accountActivityTab').trigger('click');
});*/
balancehistorygrid1.onColumnsReordered.subscribe(function(e, args) {
	store.set('balanceOrder1', bcolumns);
});
balancehistorygrid.onColumnsResized.subscribe(function(e, args) {
	store.set('balanceWidths1', balancehistorygrid1.getColumns());
});
balanceDataView.onRowCountChanged.subscribe(function(e,args) {
	balancehistorygrid1.updateRowCount();
	balancehistorygrid1.render();
});
balanceDataView.onRowsChanged.subscribe(function(e,args) {
	balancehistorygrid1.invalidateRows(args.rows);
	balancehistorygrid1.render();
});	

balanceDataView1.setItems(activity1Data);
balancehistorygrid1.setColumns(activity1Columns);
if ( store.get('balanceOrder1') ) {
	var visibleBalanceColumns = [];
	for (var i = 0; i < store.get('balanceOrder1').length; i++) {
		if (activity1Columns[i].visible) {
			visibleBalanceColumns.push(activity1Columns[i])
		}
	}
	balancehistorygrid1.setColumns(visibleBalanceColumns);
}





/**********************************************************************
INITIALIZE ACCOUNT ACTIVITY GRID
**********************************************************************/	
/*var activityGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
activityDataView = new Slick.Data.DataView({
	activityGroupItemMetadataProvider: activityGroupItemMetadataProvider
});
activityGrid = new Slick.Grid("#activityGrid", activityDataView, activityColumns, activityOptions);
activityGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
activityGrid.registerPlugin(activityGroupItemMetadataProvider);
activityGrid.registerPlugin(activityCheckboxSelector);
var activityColumnpicker = new Slick.Controls.ColumnPicker(activityColumns, activityGrid, activityOptions, 'activityOrder', 'activityWidths')
activityGrid.onSort.subscribe(function(e, args) {
	sortcol = args.sortCol.field;
	sortdir = args.sortAsc ? 1 : -1;
	activityDataView.fastSort(sortcol, args.sortAsc);
});
activityGrid.onClick.subscribe(function(e, args) {
	var acell = activityGrid.getCellFromEvent(e), arow = acell.row, $arow = $(e.target).closest(".slick-row");
	if( !$arow.is(".slick-group, .slick-group-totals") ) {
		e.preventDefault();
		function showTransactionDetails() {
			function navigateTransactions() {}
			function voucherImages() {}
			function transactionHelp() {}
			var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
			$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
			$controls = $("<div class='control-list right' />").appendTo($navigationBar),
			$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
			$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
			$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
			details = [
				{name: "Company", id: "td1", type: "text", data: "LLC Manufacturing Inc."},
				{name: "Account Name", id: "td2", type: "text", data: "AUD Operations"},
				{name: "Account Number", id: "td3", type: "text", data: "334-1233-212"},
				{name: "Transaction Code", id: "td4", type: "text", data: "TC3457"},
				{name: "BAI Code", id: "td5", type: "text", data: "BAI39433"},
				{name: "Posting Date", id: "td6", type: "text", data: smartDates("yesterday")},
				{name: "Value Date", id: "td7", type: "text", data: smartDates("yesterday")},
				{name: "Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "AUD 1,300.00"},
				{name: "Transaction Narrative", id: "td9", type: "text", data: "Praesent magna purus, posuere et porta ac, volutpat ut dui. Ut non mauris orci. In a porttitor felis. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt."},
				{name: "Transaction Description", id: "td10", type: "text", data: "Praesent magna purus, posuere et porta ac, volutpat ut dui. Ut non mauris orci. In a porttitor felis. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt."},
				{name: "Voucher Images", id: "td11", type: "text", data: "<a href='javascript:void(0)'><i class='fa fa-image fa-fw' style='margin-right: 8px;'></i>View Images</a>"}
			],
			$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
			$formSection = $("<div class='form-section' />").appendTo($detailsForm);
			for (var i = 0; i < details.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
				$label = $("<div class='label-column'><label>"+details[i].name+"</label></div>)").appendTo($row),
				$data = $("<div class='data-column' />").appendTo($row),
				$el = $("<div class='data-text' id='"+details[i].id+"'>"+details[i].data+"</div>").appendTo($data);
				if ( details[i].attributes ) {
					for ( var a = 0; a < details[i].attributes.length; a++ ) {
						$el.attr( details[i].attributes[a].name ,details[i].attributes[a].value );
					}
				}
			};
			return $transactionDetails;
		}
		var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
		var _dialog = {
			id: "transactionDetails",
			title: "Transaction Details",
			size: "medium",
			icon: "<i class='fa fa-file-text'></i>",
			content: function(){return showTransactionDetails()},
			buttons: [
				{ name: "Close", icon: "<i class='fa fa-times fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
				{ name: "Transaction Detail Report", icon: "<i class='fa fa-file-text fa-fw fa-lg'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] }
			]
		}
		dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
	}
});
activityGrid.onColumnsReordered.subscribe(function(e, args) {
	store.set('activityOrder', activityColumns.slice(1));
});
activityGrid.onColumnsResized.subscribe(function(e, args) {
	store.set('activityWidths', activityGrid.getColumns());
});
activityDataView.onRowCountChanged.subscribe(function(e,args) {
	activityGrid.updateRowCount();
	activityGrid.render();
});
activityDataView.onRowsChanged.subscribe(function(e,args) {
	activityGrid.invalidateRows(args.rows);
	activityGrid.render();
});	
activityDataView.setItems(activityData);
activityDataView.setFilterArgs({
	findActivityString: findActivityString
});
activityDataView.setFilter(myActivityFilter);
activityGrid.setColumns(activityColumns);
if ( store.get('activityOrder') ) {
	var visibleActivityColumns = [];
	for (var i = 0; i < store.get('activityOrder').length+1; i++) {
		if (activityColumns[i].visible) {
			visibleActivityColumns.push(activityColumns[i])
		}
	}
	visibleActivityColumns.unshift(activityColumns[0]);
	activityGrid.setColumns(visibleActivityColumns);
}



*/

	
/**********************************************************************
GRID RESIZE EVENT
**********************************************************************/
$(window).bind("resize", function() {	
	grid.resizeAndRender();
	balancehistorygrid.resizeAndRender();
	balancehistorygrid1.resizeAndRender();
});


/**********************************************************************
FOLDER VIEW INTERACTIONS
**********************************************************************/	
$("#_allAccounts").on("click", function(e) {
	e.preventDefault();
	var _folder = "";
	if ( labelString != _folder ) {
		labelString = _folder;
	}
	folderFilter();
	$("#selectedFolder").html("All")
});
$(".manage-folders").on("click", showFolderManagerDialog);
$("#_inlineFolderButton").on("click", addFolderInline);
$("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
	if (e.keyCode == 13) {
		addFolderInline();
	}
});
populateFolders();


/**********************************************************************
GROUPING INTERACTIONS
**********************************************************************/
$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
$("body").on("click.trxngroup-by", "#trxnGroupBy [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		trxngroupBy(item,text);
	});
$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}		
	});


/**********************************************************************
CURRENCY INTERACTION
**********************************************************************/
function returnRate(a,b) {
	var rate;
		if (a == "AUD") {if (b == "AUD") {rate = 1.0000} else if (b == "SGD") {rate = 0.8222}
		} else if (a == "CNY") {if (b == "AUD") {rate = 5.9200} else if (b == "SGD") {rate = 4.8400}
		} else if (a == "EUR") {if (b == "AUD") {rate = 0.7502} else if (b == "SGD") {rate = 0.6100}
		} else if (a == "HKD") {if (b == "AUD") {rate = 7.4910} else if (b == "SGD") {rate = 6.1230}
		} else if (a == "IDR") {if (b == "AUD") {rate = 9426.0710} else if (b == "SGD") {rate = 7708.4500}
		} else if (a == "INR") {if (b == "AUD") {rate = 53.8600} else if (b == "SGD") {rate = 43.8700}
		} else if (a == "KRW") {if (b == "AUD") {rate = 1081.8300} else if (b == "SGD") {rate = 886.1722}
		} else if (a == "KHR") {if (b == "AUD") {rate = 3852.6700} else if (b == "SGD") {rate = 3164.1900}
		} else if (a == "MYR") {if (b == "AUD") {rate = 2.9201} else if (b == "SGD") {rate = 2.3902}
		} else if (a == "NZD") {if (b == "AUD") {rate = 1.2000} else if (b == "SGD") {rate = 0.9800}
		} else if (a == "SGD") {if (b == "AUD") {rate = 1.2222} else if (b == "SGD") {rate = 1.0000}
		} else if (a == "THB") {if (b == "AUD") {rate = 28.9100} else if (b == "SGD") {rate = 23.7100}
		} else if (a == "USD") {if (b == "AUD") {rate = 0.9600} else if (b == "SGD") {rate = 0.7900}
		} else if (a == "VND") {if (b == "AUD") {rate = 20208.5600} else if (b == "SGD") {rate = 16565.4300}
		};
	return(rate)
}
$("#ccyMenu").on("click.set-ccy", "a", function(e) {
		e.preventDefault();
		groupCCYSetting = $(this).attr("data-value");
		for (var i = 0; i < data.length; i++) {
			data[i].fxrate = returnRate(groupCCYSetting,data[i].currency).toFixed(2);
		}
		dataView.setItems(data)
		filterAccounts();
		$("#_totalsRow [data-value='totalccy']").html(groupCCYSetting);
	});


/**********************************************************************
ACTION MENU INTERACTION
**********************************************************************/
$("#actionMenuControl").on("click.show-actionMenu", function(e) {
	var rowsLength =  grid.getSelectedRows().length;
	var menuLink = $("#actionMenuControl").children("a")
	if (rowsLength == 0) {
		menuLink.attr({"href":"#actionMenuNoSelected"});
	} else if (rowsLength == 1) {
		menuLink.attr({"href":"#actionMenu"});
	} else if (rowsLength > 1) {
		menuLink.attr({"href":"#actionMenuMultiSelected"});
	}
});
$(".remember-settings").on("click", function() {
	$("body").addClass("loading");
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("Default settings for this screen have been updated", 500, 3000);
	}, 1000);
});



/**********************************************************************
SEARCH BOX INTERACTIONS
**********************************************************************/
function findFilter() {
		var rows = grid.getSelectedRows();
		if(rows.length > 0) {
			grid.setSelectedRows(0);
		}
		if(findString == "") {
			dataView.setFilterArgs({
				labelString: labelString,
				findString: findString
			});	
		} else {
			dataView.setFilterArgs({
				labelString: labelString,
				findString: findString
			});
		}
		dataView.refresh();
	}
$("#acctSearchClear").on("click", function(e) {
		e.preventDefault(); e.stopPropagation();
		$("#_findAccounts").val('');
		$("#_findAccounts").focus();
		 $("#acctSearchClear").hide();
		findString = "";
		findFilter();
	});
$("#_findAccounts").keyup(function (e) {
	if (e.which == 27) {
	  $("#acctSearchClear").hide();
	  this.value = '';
	}
	findString = this.value;
	findFilter();
	if ( this.value != "" ) {
		$("#acctSearchClear").show();
	} else {
		$("#acctSearchClear").hide();
	}
  });
$("#findAccountOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var findPlaceholder = $(this).text(), filterString = $(this).attr("data-value");
		if (findDataPoint != filterString) {
			if ( document.createElement("input").placeholder != undefined ) {
				$("#_findAccounts").attr("placeholder", findPlaceholder);
			}
			findDataPoint = filterString;
			$("#_findAccounts").val('').focus();
			$("#acctSearchClear").hide();
			findString = '';
			findFilter();
		}
		$("#findAccountOptions").hide();
	});
$(".search-btn").on("click", function(e) {
	e.preventDefault();
	if ( $(".search-menu").is(":visible") ) {
		$(this).removeClass("open");
		$(".search-menu").hide();
		$("#summaryGrid").css({"top": 0});
		grid.resizeAndRender();
	} else {
		$(this).addClass("open");
		$(".search-menu").show().find("input.search-input").focus();
		$("#summaryGrid").css({"top": 50});
		grid.resizeAndRender();
	}
});
$(".search-options").on("click", function(e) {
	e.preventDefault(); e.stopPropagation();
	function hideMenu() {
		$("#findAccountOptions").hide();
		$(document).off("keyup.hide-search");
		$(window).off("resize.hide-search");
		$("body").off("click.hide-search");
	}
	if ( $("#findAccountOptions").is(":visible") ) {
		hideMenu();
	} else {
		$(".control-menus .control-menu").hide();
		$("#findAccountOptions").show().css({"top":"218px"});
		$(window).on("resize.hide-search", function() {
			hideMenu()
		});
		$(document).on("keyup.hide-search", function(e) {
			e.preventDefault();
			if(e.keyCode == 27) {
				hideMenu()
			}
		});
		$("body").on("click.hide-search", function() {
			hideMenu()
		});
	}
});
function findActivityFilter() {
		var rows = activityGrid.getSelectedRows();
		if(rows.length > 0) {
			activityGrid.setSelectedRows(0);
		}
		if(findActivityString == "") {
			activityDataView.setFilterArgs({
				findActivityString: findActivityString
			});	
		} else {
			activityDataView.setFilterArgs({
				findActivityString: findActivityString
			});
		}
		activityDataView.refresh();
	}	
$("#activitySearchClear").on("click", function() {
		$("#_findActivity").val('');
		$("#_findActivity").blur();
		 $("#activitySearchClear").hide();
		findActivityString = "";
		findActivityFilter();
	});
$("#_findActivity").keyup(function (e) {
		if (e.which == 27) {
		  $("#activitySearchClear").hide();
		  this.value = '';
		  this.blur();
		}
    	findActivityString = this.value;
    	findActivityFilter();
    	if ( this.value != "" ) {
    		$("#activitySearchClear").show();
    	} else {
    		 $("#activitySearchClear").hide();
    	}
  });
$("#findAccountActivity").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var findPlaceholder = $(this).text(), filterString = $(this).attr("data-value");
		if (findActivityDataPoint != filterString) {
			if ( document.createElement("input").placeholder != undefined ) {
				$("#_findActivity").attr("placeholder", findPlaceholder);
			}
			findActivityDataPoint = filterString;
			$("#_findActivity").val('').focus();
			$("#activitySearchClear").hide();
			findActivityString = '';
			findActivityFilter();
		}
	});


/**********************************************************************
ACCOUNT ACTIVITY / BALANCE HISTORY DATE FILTERS
**********************************************************************/
$("#_trxnspecificDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#trxnDate").find("li.active").removeClass("active");
			$("#trxnSpecDateItem").closest("li").addClass("active");
			$("div.control-list").find("a[href='#trxnDate']").children("span").text(dateText);
			$("#activityDate").html(dateText);
			$("div.control-list").find("a[href='#trxnDate']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
			$('#accountActivityTab').trigger('click');
	}
}).click(function(e) {e.stopPropagation();});
var trxnDateRangeSelection = $("#_trxnrangeDateFrom, #_trxnrangeDateTo").datepicker({
	dateFormat: 'dd/mm/yy',
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function( selectedDate ) {
		var option = this.id == "_trxnrangeDateFrom" ? "minDate" : "maxDate",
			instance = $( this ).data( "datepicker" ),
			date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
			trxnDateRangeSelection.not(this).datepicker("option", option, date);
	}
}).click(function(e) {e.stopPropagation();});
$("#_trxnDateRangeBtn").on("click", function(e) {
	var fromDate = $('#_trxnrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
	var toDate = $('#_trxnrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
	$("#trxnDate").find("li.active").removeClass("active");
	$("#trxnRangeDateItem").closest("li").addClass("active");
	$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
	$('#accountActivityTab').trigger('click');
	$("div.control-list").find("a[href='#trxnDate']").children("span").text(fromDate+" - "+toDate);
	$("#activityDate").html(fromDate+" - "+toDate);
	$("div.control-list").find("a[href='#trxnDate']").parent(".btn").removeClass("on");
	$("div.control-menus div.control-menu").hide();
});
$("#_balspecificDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#balDate").find("li.active").removeClass("active");
			$("#balSpecDateItem").closest("li").addClass("active");
			$("div.control-list").find("a[href='#balDate']").children("span").text(dateText);
			$("#balanceHistoryDate").html(dateText);
			$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
			$('#balanceHistoryTab').trigger('click');
		}
	}).click(function(e) {e.stopPropagation();});	
var balDateRangeSelection = $("#_balrangeDateFrom, #_balrangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_balrangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				balDateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {e.stopPropagation();});	
$("#_balDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_balrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_balrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#balDate").find("li.active").removeClass("active");
		$("#balRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#balanceHistoryTab').trigger('click');
		$("div.control-list").find("a[href='#balDate']").children("span").text(fromDate+" - "+toDate);
		$("#balanceHistoryDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});
	
	
/**********************************************************************
REQUEST REPORT MODALS
**********************************************************************/
$(".request-statement").on("click", showAccountStatementModal);
$(".request-balances").on("click", showBalanceHistoryModal);

/**********************************************************************
CREATE NEW SERVICE REQUEST
**********************************************************************/
$(".new-service-request").on("click", createServiceRequestWarning);


/**********************************************************************
SPLIT VIEW
**********************************************************************/
$("[data-action='previousAccount']").on("click", function(e) {
	e.preventDefault();
	var activeRow = grid.getActiveCell().row;
	activeRow = activeRow-1;
	if ( $accountsGrid.find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
		activeRow = activeRow-1;
	}	
	$accountsGrid.find("div[row='"+activeRow+"'] div.slick-cell").eq(1).trigger("click")
});
$("[data-action='nextAccount']").on("click", function(e) {
	e.preventDefault();
	var activeRow = grid.getActiveCell().row;
	activeRow = activeRow+1;
	if ( $accountsGrid.find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
		activeRow = activeRow+1;
	}
	$accountsGrid.find("div[row='"+activeRow+"'] div.slick-cell").eq(1).trigger("click")
});
$("#_closeButton").on("click", "a", function(e) {
	e.preventDefault();
	grid.setSelectedRows({});
	grid.resetActiveCell();
});
var $shell = $(".shell"), $leftPanel = $(".left-panel"), $rightPanel = $(".right-panel"), $resizer = $(".resizer");
$(".resizer").drag("start", function(ev,dd) {
	$("body").trigger("click.hide-menu");
	$resizer.addClass("on");
	dd.limit = $shell.offset();
	dd.limit.left = 400;
	dd.limit.right = $shell.width() - ( 500 );
}).drag( function(ev,dd) {
	$rightPanel.css({ left: Math.min(dd.limit.right, Math.max(dd.limit.left, dd.offsetX - $shell.position().left )) });
	$leftPanel.css({ width: $rightPanel.position().left });
	grid.resizeAndRender();
	balancehistorygrid.resizeAndRender();
	activityGrid.resizeAndRender();
}, {handle: ".resizer"}).drag("end", function(ev,dd) {
	$resizer.removeClass("on");
	grid.resizeAndRender();
	balancehistorygrid.resizeAndRender();
	activityGrid.resizeAndRender();
});


});


