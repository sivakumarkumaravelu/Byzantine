/***
 * Contains basic SlickGrid formatters.
 * 
 * NOTE:  These are merely examples.  You will most likely need to implement something more
 *        robust/extensible/localizable/etc. for your use!
 * 
 * @module Formatters
 * @namespace Slick
 */

(function($) {
  // register namespace
  $.extend(true, window, {
    "Slick": {
      "Formatters": {
        "ValidatedIconFormatter": ValidatedIconFormatter,
        "NoticesIconFormatter": NoticesIconFormatter,
        "AmountFormatter": AmountFormatter,
        "PercentComplete": PercentCompleteFormatter,
        "PercentCompleteBar": PercentCompleteBarFormatter,
        "YesNo": YesNoFormatter,
        "Checkmark": CheckmarkFormatter,
        "ValidIcon": ValidIconFormatter
      }
    }
  });


  function ValidatedIconFormatter(row, cell, value, columnDef, dataContext) {
      if ( value == null || value === "") {
          return "";
      }
      var icon, color, title;
      if ( value == "rejected" ) {
          icon = "fa-ban";
          color = "#c91b01";
          title = "Payment is Rejected";
      } else if (value == "new") {
            icon = "fa-check-circle";
            color = "#DEE3E5";
            title = "Payment is new";
      } else {
          if (value) {
              icon = "fa-check-circle";
              color = "#009900";
              title = "Payment is valid";
          } else {
              icon = "fa-exclamation-triangle";
              color = "#c91b01";
              title = "Payment is incomplete or needs repair";
          }
      }
      return "<i class='fa " + icon + " fa-fw' style='color:" + color + "' title='" + title + "'></i>"
  }

  function NoticesIconFormatter(row, cell, value, columnDef, dataContext) {
      return value ? "<i class='fa fa-flag fa-fw' style='color: #e98c3a;'></i>" : "";
  }

  function AmountFormatter(row, cell, value, columnDef, dataContext) {
    return addCommas(value);
  }

  function PercentFormatter(row, cell, value, columnDef, dataContext) {
    return "<span>"+ value + "%</span>";
  }

  function PercentCompleteFormatter(row, cell, value, columnDef, dataContext) {
    if (value == null || value === "") {
      return "-";
    } else if (value < 50) {
      return "<span style='color:red;font-weight:bold;'>" + value + "%</span>";
    } else {
      return "<span style='color:green'>" + value + "%</span>";
    }
  }

  function PercentCompleteBarFormatter(row, cell, value, columnDef, dataContext) {
    if (value == null || value === "") {
      return "";
    }

    var color;

    if (value < 30) {
      color = "red";
    } else if (value < 70) {
      color = "silver";
    } else {
      color = "green";
    }

    return "<span class='percent-complete-bar' style='background:" + color + ";width:" + value + "%'></span>";
  }

  function YesNoFormatter(row, cell, value, columnDef, dataContext) {
    return value ? "Yes" : "No";
  }

  function ValidIconFormatter(row, cell, value, columnDef, dataContext) {
    return value ? "<i class='fa fa-check fa-fw' style='color: #009900;'></i>" : "<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01;'></i>";
  }

  function CheckmarkFormatter(row, cell, value, columnDef, dataContext) {
    return value ? "<input type=checkbox value='"+value+"' class='editor-checkbox' checked='checked' />" : "<input type=checkbox value='"+value+"' class='editor-checkbox' />";
  }
})(jQuery);