(function($) {
  function SlickColumnPicker(columns, grid, options, sessionorder, sessionwidth, specialColumns) {

	var $menu;
	var $mouseDiv;
	var columnCheckboxes;
	var checkboxRowSelection = false;
	var flagColumn = false;
	var defaults = {
		fadeSpeed: 150
	};

    function init() {
      grid.onHeaderContextMenu.subscribe(handleHeaderContextMenu);
      grid.onColumnsReordered.subscribe(updateColumnOrder);
      options = $.extend({}, defaults, options);

      // Update by Peter - added outer div to adjust to browser height
      $mouseDiv = $("<div style='display: none; position: absolute; z-index: 500; padding-left: 20px; padding-right: 20px; padding-bottom: 20px;' />").appendTo(document.body);
      $menu = $("<ul class='slick-columnpicker' style='width:225px; overflow-y: hidden; height: auto;' />").appendTo($mouseDiv);
      $mouseDiv.bind("mouseleave", function(e) { $(this).fadeOut(options.fadeSpeed, function(){ $menu.css({"overflow-y":"hidden", "height":"auto"}) }) });
      $menu.bind("mousedown", function(e) {
        e.stopPropagation();
      });
      $menu.bind("click", updateColumn);
    }

    function destroy() {
      grid.onHeaderContextMenu.unsubscribe(handleHeaderContextMenu);
      grid.onColumnsReordered.unsubscribe(updateColumnOrder);
      $menu.remove();
    }

    function hideColumnPicker() {
      $mouseDiv.hide();
      $menu.css({
        "overflow-y": "hidden",
        "height": "auto"
      });
      $("document").off("keyup.hide-columnpicker");
      $(".slick-resizable-handle").off("keyup.hide-columnpicker");
      $(window).off("resize.hide-columnpicker");
    }

    function handleHeaderContextMenu(e, args) {
      e.preventDefault();
      e.stopPropagation();

	  $(".control-menus").children(".control-menu:visible").hide().css({
		"z-index": "100",
		height: "auto",
		overflowY: "hidden"
	  });
	  $(".control-list").children(".on").removeClass("on");

      $menu.empty();

      var $open = ($(".control-list li.open").size()) ? $(".control-list li.open") : null;
      if ($open) {
        $open.removeClass("open");
        $("document").off("keyup.hide-menu");
      }

      if ($("ul#contextMenu").is(":visible")) {
        hideContextMenu();
      }

      $("body").one("mousedown.hide-columnpicker", hideColumnPicker);
      $(".slick-resizable-handle").on("mousedown.hide-columnpicker", hideColumnPicker);
      $(window).on("resize.hide-columnpicker", hideColumnPicker)
      $("body").one("contextmenu", hideColumnPicker);
      $(document).on("keyup.hide-columnpicker", function(e) {
        e.preventDefault();
        if (e.keyCode == 27) {
          hideColumnPicker()
        }
      });

      columnCheckboxes = [];
      updateColumnOrder();
  

      var $li, $input, $span;


      for (var i = 0; i < columns.length; i++) {


        $li = $("<li />").appendTo($menu);
        $input = $("<input type='checkbox' />").data("column-id", columns[i].id);
        columnCheckboxes.push($input);

        if (grid.getColumnIndex(columns[i].id) != null) {
          $input.attr("checked", "checked");
        }

        $("<label />")
          .text(columns[i].name)
          .prepend($input)
          .appendTo($li);

        if (!columns[i].name || columns[i].name.indexOf("<input type='checkbox'") === 0) {
          $li.css({
            display: "none"
          });
          checkboxRowSelection = true;
        }

		if (!columns[i].name || columns[i].name.indexOf("<i class='fa fa-exclamation-triangle fa-fw'") === 0) {
			$li.css({
				display: "none"
			});
			flagColumn = true;
		}
      }

      // Update by Peter - menu spacer
      $("<li class='menu-section'></li>").appendTo($menu);

      // Update by Peter - fit columns once
      $li = $("<li />").appendTo($menu);
      $span = $("<span />").data("option", "autoresizeonce").text("Fit Columns To Panel").appendTo($li);

      // Update by Peter - reset columns
      $li = $("<li />").appendTo($menu);
      $span = $("<span />").data("option", "reset").text("Reset Columns").appendTo($li);

      var leftOffset = ((e.pageX + $mouseDiv.outerWidth() + 20) > $(window).width()) ? (e.pageX + $mouseDiv.outerWidth() + 20 - $(window).width()) : 25;
      $mouseDiv.css("top", e.pageY - 10).css("left", e.pageX - leftOffset).fadeIn(options.fadeSpeed);
      if (e.pageY + $menu.height() > $(window).height()) {
        $menu.css({
          "overflow-y": "scroll",
          "height": $(window).height() - e.pageY - 20
        })
      }
    }

    function updateColumnOrder() {
      var current = grid.getColumns().slice(0);
      var ordered = new Array(columns.length);
      for (var i = 0; i < ordered.length; i++) {
        if (grid.getColumnIndex(columns[i].id) === undefined) {
          ordered[i] = columns[i];
        } else {
          ordered[i] = current.shift();
        }
      }
      columns = ordered;
      if ( specialColumns != null && specialColumns.length > 0 ) {
      	 store.set(sessionorder, columns.slice(specialColumns.length));
      } else {
      	 store.set(sessionorder, columns);
      }
     
    }

    function updateColumn(e) {
      /* added by peter: prevent bubble up */
      e.stopPropagation();
      // Update by Peter - fit columns once
      if ($(e.target).data("option") == "autoresizeonce") {
        grid.autosizeColumns();
        store.set(sessionwidth, grid.getColumns());
        hideColumnPicker();
        return;
      }
      // Update by Peter - reset columns to default
      if ($(e.target).data("option") == "reset") {
        function resetColumns() {
          store.remove(sessionorder);
          store.remove(sessionwidth);
          location.reload();
        }
        hideColumnPicker();
        buildConfirmDialog("This will reset the columns in this grid to their default state.", "Do you want to proceed?", function() {
          resetColumns(e)
        });
      }
      if ($(e.target).is(":checkbox")) {
        var visibleColumns = [];
        $.each(columnCheckboxes, function(i, e) {
          if ($(this).is(":checked")) {
            columns[i].visible = true;
            visibleColumns.push(columns[i]);
          } else {
            columns[i].visible = false;
          }
        });

        if (!visibleColumns.length) {
          $(e.target).attr("checked", "checked");
          return;
        }

      if ( specialColumns!= null && specialColumns.length > 0 ) {
      	 store.set(sessionorder, columns.slice(specialColumns.length));
      } else {
      	 store.set(sessionorder, columns);
      }

        grid.setColumns(visibleColumns);
      }
    }

    function getAllColumns() {
      return columns;
    }

    init();

    return {
      "getAllColumns": getAllColumns,
      "destroy": destroy
    };
  }

  // Slick.Controls.ColumnPicker
  $.extend(true, window, {
    Slick: {
      Controls: {
        ColumnPicker: SlickColumnPicker
      }
    }
  });
})(jQuery);