/* USERS */
var _users = [{
	id: randString(20),
	userid: "SMITJAM",
	firstname: "John",
	surname: "Smith",
	preferredname: "Johnny",
	usercredential: "Password",
	status: "Active",
	workflow: "Approved",
	country: "Australia",
	lastlogin: smartDates("randompast")  + " 10:10:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "smithjohn@prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "Company"
}, {
	id: randString(20),
	userid: "BAUSR3",
	firstname: "William",
	surname: "Jones",
	preferredname: "Will",
	usercredential: "Security Device",
	status: "Active",
	workflow: "Pending Approval – Delete",
	country: "Australia",
	lastlogin: smartDates("randompast")  + " 11:20:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "williamjones@prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "B-Manager",
	permissions:[],
	applications: [],
	managedby: "Company"
}, {
	id: randString(20),
	userid: "JOHNBR",
	firstname: "John",
	surname: "Brown",
	preferredname: "JB",
	usercredential: "Security Device",
	status: "Active",
	workflow: "Pending Approval – Modify",
	country: "Australia",
	lastlogin: smartDates("randompast")   + " 12:30:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "johnbrown@prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "Company"
}, {
	id: randString(20),
	userid: "CHARLIEBR",
	firstname: "Charles",
	surname: "Brown",
	preferredname: "Charlie",
	usercredential: "Password",
	status: "Active",
	workflow: "Pending Approval - Disable",
	country: "Australia",
	lastlogin: smartDates("randompast")  + " 15:40:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "charliebrown@prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "Company"
}, {
	id: randString(20),
	userid: "02OCTP",
	firstname: "Herry",
	surname: "Wibowo",
	preferredname: "Hank",
	usercredential: "Security Device",
	status: "Active",
	workflow: "Pending Approval – Register",
	country: "Australia",
	lastlogin: smartDates("randompast") + " 14:30:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "beneficiary1@opee.prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "Company"
}, {
	id: randString(20),
	userid: "01OCTP",
	firstname: "Peter",
	surname: "Lam",
	preferredname: "Pete",
	usercredential: "Security Device",
	status: "Disabled",
	workflow: "Approved",
	country: "Australia",
	lastlogin: smartDates("randompast") + " 13:10:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "beneficiary1@opee.prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "ANZ"
}, {
	id: randString(20),
	userid: "USRTK2",
	firstname: "Alexandra",
	surname: "Tee",
	preferredname: "Lexie",
	usercredential: "Password",
	status: "Disabled",
	workflow: "Pending Approval – Enable",
	country: "Australia",
	lastlogin: smartDates("randompast") + " 15:10:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "beneficiary1@opee.prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "ANZ"
}, {
	id: randString(20),
	userid: "USRTK3",
	firstname: "Deborah",
	surname: "Wright",
	preferredname: "Debbie",
	usercredential: "Password",
	status: "Disabled",
	workflow: "Pending Approval - Delete",
	country: "Australia",
	lastlogin: smartDates("randompast") + " 16:20:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "beneficiary1@opee.prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "ANZ"
}, {
	id: randString(20),
	userid: "USRTK3",
	firstname: "Victoria",
	surname: "Liao",
	preferredname: "Vicky",
	usercredential: "Password",
	status: "Disabled",
	workflow: "Pending Approval – Modify",
	country: "Australia",
	lastlogin: smartDates("randompast") + " 17:30:00",
	city: "Melbourne",
	state: "Victoria",
	postal: "3000",
	email: "beneficiary1@opee.prototype.com",
	phone: { country: "+61", number: "5555555"},
	usertype: "Admin",
	address1: "Level 25/100 Queens Street",
	address2: "Institutional Building",
	panelauthgroup: "A-Manager",
	permissions:[],
	applications: [],
	managedby: "ANZ"
}];


/*  USER ROLES/APPLICATIONS */


var _roles = [{
	id: randString(20),
	rolename: "Authorised Signatory",
	rolefamily: "Commercial Cards",
	roledes: "Card Request Creation & User Management",
	division: "Selected",
	roletype: "System",
	
  },
  {
	id: randString(20),
	rolename: "Create & Approve",
	rolefamily: "Cash Management",
	roledes: "Payment Creation & Approval",
	division: "All",
	roletype: "System",
	
  },
  {
	id: randString(20),
	rolename: "Approver",
	rolefamily: "Cash Management",
	roledes: "Payment Approval",
	division: "Selected",
	roletype: "System",
	
  }
];

var _tbos_users_roles = [];

function generateRoles() {
	var b = {};
	var bene = _beneficiaries[rand(0, _beneficiaries.length - 1)];
	var localbank = _beneficiary_local_banks[rand(0, _beneficiary_local_banks.length - 1)];
	var swiftbank;
	for (var i = 0; i < _beneficiary_swift_banks.length; i++) {
		if (_beneficiary_swift_banks[i].id == localbank.id) {
			swiftbank = _beneficiary_swift_banks[i];
			break;
		}
	}
	var currency;
	for (var i = 0; i < _beneficiary_account_currencies.length; i++) {
		if (_beneficiary_account_currencies[i].country == localbank.country) {
			currency = _beneficiary_account_currencies[i];
			break;
		}
	}
	var benetype = (bene.country == localbank.country) ? "Resident Individual" : "Non-Resident Individual";
	var status = _beneficiary_workflow[rand(0, _beneficiary_workflow.length - 1)];
	b["id"] = randString(10);
	b["beneid"] = randString(6);
	b["benename"] = bene.name;
	b["benelocalname"] = bene.localname;
	b["benenickname"] = bene.nickname;
	b["benetype"] = benetype;
	b["beneaccount"] = randNumber(10);
	b["beneaccountccy"] = currency.code;
	b["beneaddress1"] = bene.address1;
	b["beneaddress2"] = bene.address2;
	b["beneaddress3"] = bene.address3;
	b["benecity"] = bene.city;
	b["benepostal"] = bene.postal;
	b["benecountry"] = bene.country;
	b["benephone"] = bene.phone;
	b["benefax"] = bene.fax;
	b["beneemail"] = bene.email;
	b["benebank"] = localbank.name;
	b["benebanklocalname"] = localbank.localname;
	b["benebankbranch"] = localbank.branch;
	b["benebankaddress1"] = localbank.address1;
	b["benebankaddress2"] = localbank.address2;
	b["benebankaddress3"] = localbank.address3;
	b["benebankpostal"] = localbank.postal;
	b["benebankcity"] = localbank.city;
	b["benebankcountry"] = localbank.country;
	b["benebankclearingtype"] = localbank.clearing[0].type;
	b["benebankclearingcode"] = localbank.clearing[0].code;
	b["swiftbank"] = swiftbank.name;
	b["swiftbanklocalname"] = swiftbank.localname;
	b["swiftbranch"] = swiftbank.branch;
	b["swiftbankaddress1"] = swiftbank.address1;
	b["swiftbankaddress2"] = swiftbank.address2;
	b["swiftbankaddress3"] = swiftbank.address3;
	b["swiftbankpostal"] = swiftbank.postal;
	b["swiftbankcity"] = swiftbank.city;
	b["swiftbankcountry"] = swiftbank.country;
	b["swiftcode"] = swiftbank.swift;
	b["benestatus"] = status.status;
	b["beneworkflow"] = status.workflow;
	b["benedivision"] = "Customer Division";
	b["entrymethod"] = "Online"
	b["folder"] = "None";
	b["folderid"] = "None";
	b["audit"] = [];
	b["enteredby"] = "Test User 1";
	b["enteredon"] = smartDates("randompast") + " at " + timeFormatter();
	b["lastupdateby"] = "Test User 1";
	b["lastupdate"] = smartDates("yesterday") + " at " + timeFormatter();
	b["approvedby"] = "Test User 2";
	b["approvedon"] = smartDates("today") + " at " + timeFormatter();
	b["rejectedby"] = "Test User 2";
	b["rejectedon"] = smartDates("today") + " at " + timeFormatter();
	b["deletedby"] = "Test User 1";
	b["deletedon"] = smartDates("today") + " at " + timeFormatter();
	return b;
}

if (store.get("_stored_tbos_users_roles")) {
	_tbos_users_roles = store.get("_stored_tbos_users");
} else {
	for (var i = 0; i < 50; i++) {
		//_tbos_users_roles[i] = generateRoles();
	}
	store.set("_stored_tbos_users_roles", _tbos_users_roles);
}



/* AUDIT LOG GENERATOR */
/* generate audit log for payments */
function generateAuditLog(record) {
	var audit = [],
		entry;
	if (record.workflow == "Pending Approval – Enable" || record.workflow == "Pending Approval – Disable" || record.workflow == "Approved" || record.workflow == "Pending Approval – Register" || record.workflow == "Pending Approval – Modify" || record.workflow == "Pending Approval – Delete") {
		entry = {};
		entry.id = randString(10);
		entry.record = 'SMITJAM';
		entry.action = "Created";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "User Created";
		entry.fields = [{
			field: "firstname",
			label: "First name",
			from: '',
			to: 'Smith'
		}, {
			field: "lastname",
			label: "Last Name",
			from: '',
			to: "John"
		}, {
			field: "address",
			label: "Address",
			from: '',
			to: "Level 25/100 Queens Street Institutional Building"
		},{
			field: "city",
			label: "City",
			from: '',
			to: "Melbourne"
		},{
			field: "state",
			label: "State",
			from: '',
			to: "Victoria"
		},{
			field: "country",
			label: "Country",
			from: '',
			to: "Australia"
		}];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = 'SMITJAM';
		entry.action = "Modified";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "User Modified";
		entry.fields = [{
			field: "firstname",
			label: "First name",
			from: 'Smith',
			to: 'Smith.'
		}, {
			field: "lastname",
			label: "Last Name",
			from: 'John',
			to: "John K"
		}, {
			field: "address",
			label: "Address",
			from: 'Level 25/100 Queens Street Institutional Building',
			to: "Level 25/100 Queens Street Institutional Building ."
		},{
			field: "city",
			label: "City",
			from: 'Melbourn',
			to: "Melbourne"
		},{
			field: "state",
			label: "State",
			from: 'Victori',
			to: "Victoria"
		},{
			field: "country",
			label: "Country",
			from: 'AU',
			to: "Australia"
		}];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = 'SMITJAM';
		entry.action = "Modified";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "User Modified";
		entry.fields = [{
			field: "firstname",
			label: "First name",
			from: 'Smith.',
			to: 'Smith'
		}, {
			field: "lastname",
			label: "Last Name",
			from: 'John K',
			to: "John"
		},];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = record.id;
		entry.action = "PAdded";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "Permission " + "P" + randString(10) + " Added";
		entry.fields = [];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = record.id;
		entry.action = "PAdded";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "Permission " + "P" + randString(10) + " Added";
		entry.fields = [];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = record.id;
		entry.action = "PRemoved";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "Permission " + "P" + randString(10) + " Removed";
		entry.fields = [];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = record.id;
		entry.action = "PModified";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "Permission " + "P" + randString(10) + " Modified";
		entry.fields = [];
		entry.comment = "";
		audit.push(entry);

		entry = {};
		entry.id = randString(10);
		entry.record = record.id;
		entry.action = "PModified";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.datetime = entry.date + " at " + entry.time;
		entry.by = "Test User";
		entry.description = "Permission " + "P" + randString(10) + " Modified";
		entry.fields = [];
		entry.comment = "";
		audit.push(entry);


		if (record.status == "Disabled" ) {
			entry = {};
			entry.id = randString(10);
			entry.record = record.id;
			entry.action = "Approval";
			entry.date = smartDates("today");
			entry.time = timeFormatter();
			entry.datetime = entry.date + " at " + entry.time;
			entry.by = "Test User";
			entry.description = "User is disabled";
			entry.fields = [{
				field: "paymentdate",
				label: "Value Date",
				from: record.paymentdate,
				to: smartDates("randomfuture")
			}];
			entry.comment = "";
			audit.push(entry);
			if (record.status == "Approver Rejected") {
				entry = {};
				entry.id = randString(10);
				entry.record = record.id;
				entry.action = "Rejected";
				entry.date = smartDates("today");
				entry.time = timeFormatter();
				entry.datetime = entry.date + " at " + entry.time;
				entry.by = "TBOS Approver 1";
				entry.description = "User Rejected";
				entry.fields = [];
				entry.comment = "This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message.";
				audit.push(entry);
			}
		}
		if (record.status == "Active" ) { 

			entry = {};
			entry.id = randString(10);
			entry.record = record.id;
			entry.action = "Rejected";
			entry.date = smartDates("today");
			entry.time = timeFormatter();
			entry.datetime = entry.date + " at " + entry.time;
			entry.by = "TBOS Approver 1";
			entry.description = "User is Rejected";
			entry.fields = [];
			entry.comment = "This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message. This is a sample rejection message.";
			audit.push(entry);

			

			entry = {};
			entry.id = randString(10);
			entry.record = record.id;
			entry.action = "Approved";
			entry.date = smartDates("today");
			entry.time = timeFormatter();
			entry.datetime = entry.date + " at " + entry.time;
			entry.by = "TBOS Approver 1";
			entry.description = "User Approved";
			entry.fields = [];
			entry.comment = "";
			audit.push(entry);

		
		}
	}
	
	return audit;
}

for(var j=0; j< _users.length; j++){
	_users[j].audit = generateAuditLog(_users[j])
}

