/* PAYMENT CHARGES */
/* used by the payment generator to tag payments with a charge type */
var _payment_charges = [{
	code: "OUR",
	description: "Ours"
}, {
	code: "BEN",
	description: "Beneficiary"
}, {
	code: "SHA",
	description: "Shared"
}];

/* PURPOSE CODES */
/* used by the payment generator to tag payments with purspose codes */

var _beps_purpose_codes = [
	'02102 - 普通汇兑 Common exchange'
];

var _dhvps_purpose_codes = [
	'02102 - 普通汇兑 Common exchange'
];

var _cbhvps_purspoe_codes = [
	'02112 - 货物贸易结算 Goods trade settlement',
	'02113 - 货物贸易结算退款 Goods trade settlement refund',
	'02114 - 服务贸易结算 Service trade settlement',
	'02115 - 服务贸易结算退款 Service trade settlement refund',
	'02116 - 资本项下跨境支付 X-border pmt under capital acc',
	'02117 - 资本项下跨境支付退款 X-border pmt refund capital',
	'02125 - 其他经常项目支出 Other current acc transactions'
];

/* SENDER TO RECEIVER CODES */
/* used by the payment generator to tag payments with sender to reciever codes */
var _sender_to_receiver_codes = [
	"/ACC/",
	"/CCDNDR/",
	"/CCTFDR/",
	"/CGODDR/",
	"/COCADR/",
	"/CSTRDR/",
	"/INS/",
	"/INT/",
	"/REC/",
	"/TRADE/"
];

/* LOCAL PAYMENT METHODS */
/* used by the payment generator to tag payments with payment method when both customer and beneficiary banks are in china */

var _china_payment_methods = [
	"Book Transfer",
	"BEPS",
	"DHVPS",
	"CBHVPS"
];


/* PAYMENT TYPES */
/* used by the payment generator */
var _payment_types = [
	"Domestic",
	"Domestic Salary",
	"International",
	"International Salary"
];

/* FX RATE TYPES */
/* used by the payment generator to assign an fx rate type to cross currency payments */
var _payment_rate_types = [
	"Carded"
];

var _payment_currencies = [
	"AUD",
	"CNY",
	"HKD",
	"SGD",
	"NZD"
];

/* SYSTEM FX RATES */
/* used by the payment generator to get a system rate for a currency pair */
var _payment_system_rates = [{
	from: "AUD",
	to: "CNY",
	rate: 4.8076
}, {
	from: "AUD",
	to: "SGD",
	rate: 1.0190
}, {
	from: "AUD",
	to: "HKD",
	rate: 5.8900
}, {
	from: "AUD",
	to: "NZD",
	rate: 1.0700
}, {
	from: "CNY",
	to: "AUD",
	rate: 0.2080
}, {
	from: "CNY",
	to: "SGD",
	rate: 0.2120
}, {
	from: "CNY",
	to: "HKD",
	rate: 1.1700
}, {
	from: "CNY",
	to: "NZD",
	rate: 0.2100
}, {
	from: "SGD",
	to: "AUD",
	rate: 0.9813
}, {
	from: "SGD",
	to: "CNY",
	rate: 4.7169
}, {
	from: "SGD",
	to: "HKD",
	rate: 5.7800
}, {
	from: "SGD",
	to: "NZD",
	rate: 1.0100
}, {
	from: "HKD",
	to: "AUD",
	rate: 0.1700
}, {
	from: "HKD",
	to: "CNY",
	rate: 0.8500
}, {
	from: "HKD",
	to: "SGD",
	rate: 0.1700
}, {
	from: "HKD",
	to: "NZD",
	rate: 0.1800
}, {
	from: "NZD",
	to: "AUD",
	rate: 0.9400
}, {
	from: "NZD",
	to: "CNY",
	rate: 4.8400
}, {
	from: "NZD",
	to: "SGD",
	rate: 0.9900
}, {
	from: "NZD",
	to: "HKD",
	rate: 5.5300
}];


/* FX CONTRACT RATE RANGES */
/* used by the fx contract generator to get contract rate ranges */
var _payment_contract_rates = [{
	from: "AUD",
	to: "CNY",
	high: 4.8110,
	low: 4.7710
}, {
	from: "AUD",
	to: "SGD",
	high: 1.0410,
	low: 1.0010
}, {
	from: "AUD",
	to: "HKD",
	high: 5.9100,
	low: 5.8800
}, {
	from: "AUD",
	to: "NZD",
	high: 1.0710,
	low: 1.0690
}, {
	from: "CNY",
	to: "AUD",
	high: 0.2310,
	low: 0.1910
}, {
	from: "CNY",
	to: "SGD",
	high: 0.2310,
	low: 0.1910
}, {
	from: "CNY",
	to: "HKD",
	high: 1.1850,
	low: 1.1670
}, {
	from: "CNY",
	to: "NZD",
	high: 0.2300,
	low: 0.2000
}, {
	from: "SGD",
	to: "AUD",
	high: 1.0010,
	low: 0.9610
}, {
	from: "SGD",
	to: "CNY",
	high: 4.7210,
	low: 4.6810
}, {
	from: "SGD",
	to: "HKD",
	high: 5.7900,
	low: 5.7100
}, {
	from: "SGD",
	to: "NZD",
	high: 1.0250,
	low: 1.0090
}, {
	from: "HKD",
	to: "AUD",
	high: 0.1710,
	low: 0.1690
}, {
	from: "HKD",
	to: "CNY",
	high: 0.8550,
	low: 0.8480
}, {
	from: "HKD",
	to: "SGD",
	high: 0.1710,
	low: 0.1690
}, {
	from: "HKD",
	to: "NZD",
	high: 0.1990,
	low: 0.1700
}, {
	from: "NZD",
	to: "AUD",
	high: 0.9600,
	low: 0.9200
}, {
	from: "NZD",
	to: "CNY",
	high: 4.8500,
	low: 4.8200
}, {
	from: "NZD",
	to: "SGD",
	high: 1.0000,
	low: 0.9700
}, {
	from: "NZD",
	to: "HKD",
	high: 5.5600,
	low: 5.5100
}];



/* CURRENT PAYMENT STATUS AND WORKFLOW STATES */
/* used by the payment generator to tag outward payments with status and workflow */
var _template_workflow = [{
	status: "Draft",
	workflow: "New"
}, {
	status: "Pending Approval",
	workflow: "New"
}, {
	status: "Approved",
	workflow: "Approved"
}, {
	status: "Rejected",
	workflow: "New"
}, {
	status: "Needs Repair",
	workflow: "New"
}];


/* AUDIT LOG GENERATOR */
/* generate audit log for payments */
function generateAuditLog(record) {
	var audit = [],
		entry;
	if (record.workflow == "New" || record.workflow == "Approved" || record.workflow == "Needs Repair") {
		entry = {};
		entry.record = record.id;
		entry.action = "Created";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.by = "Test User";
		entry.description = "Record Created";
		entry.fields = [];
		entry.comment = "";
		audit.push(entry);
		entry = {};
		entry.record = record.id;
		entry.action = "Modified";
		entry.date = smartDates("today");
		entry.time = timeFormatter();
		entry.by = "Test User";
		entry.description = "Record Modified";
		entry.fields = [{
			field: "valuedate",
			label: "Value Date",
			from: record.valuedate,
			to: smartDates("randomfuture")
		}];
		entry.comment = "";
		audit.push(entry);
		if (record.status == "Pending Approval" || record.status == "Approver Rejected") {
			entry = {};
			entry.record = record.id;
			entry.action = "Submitted For Approval";
			entry.date = smartDates("today");
			entry.time = timeFormatter();
			entry.by = "Test User";
			entry.description = "Record Submitted For Approval";
			entry.fields = [{
				field: "valuedate",
				label: "Value Date",
				from: record.valuedate,
				to: smartDates("randomfuture")
			}];
			entry.comment = "";
			audit.push(entry);
			if (record.status == "Approver Rejected") {
				entry = {};
				entry.record = record.id;
				entry.action = "Rejected";
				entry.date = smartDates("today");
				entry.time = timeFormatter();
				entry.by = "TBOS Approver";
				entry.description = "Record Rejected";
				entry.fields = [];
				entry.comment = "The value date was modified incorrectly. Please correct it.";
				audit.push(entry);
			}
		}
		if (record.status == "Needs Repair") {
			entry = {};
			entry.record = record.id;
			entry.action = "Approved";
			entry.date = smartDates("today");
			entry.time = timeFormatter();
			entry.by = "TBOS Approver";
			entry.description = "Record Approved";
			entry.fields = [];
			entry.comment = "";
			audit.push(entry);
		}
	}
	return audit;
}



/* FX CONTRACT GENERATOR */
/* generate fx contracts for payments and stores them in the _tbos_fx_contracts array */
var _tbox_fx_contracts = [];

function generateFXContracts(fromccy, toccy, num, amount) {
	var contracts = [];
	var splitamount = (parseFloat(amount / num)).toFixed(2);
	var usedtotal = (parseFloat(splitamount * num)).toFixed(2);
	var high, low;
	var clientid = "CLIENTFXID-" + randString(4);
	for (var r = 0; r < _payment_contract_rates.length; r++) {
		var pcr = _payment_contract_rates[r];
		if (fromccy == pcr.from && toccy == pcr.to) {
			high = pcr.high;
			low = pcr.low;
			break;
		}
	}
	for (var i = 0; i < num; i++) {
		var total = rand(50000, 100000);
		var rate = parseFloat(generateRandomDecimal(high, low));
		var remaining = addCommas((parseFloat(total - splitamount)).toFixed(2));
		contracts[i] = {};
		contracts[i].id = randString(20);
		contracts[i].clientid = clientid;
		contracts[i].reference = randString(10);
		contracts[i].fromccy = fromccy;
		contracts[i].toccy = toccy;
		contracts[i].rate = rate;
		contracts[i].total = total;
		contracts[i].used = splitamount;
		contracts[i].remaining = remaining;
		contracts[i].booked = smartDates("randompast");
		contracts[i].expires = smartDates("randomfuture");
		_tbox_fx_contracts.push(contracts[i]);
	}
	if (amount > usedtotal) {
		var lessby = parseFloat(amount - usedtotal).toFixed(2);
		contracts[contracts.length - 1].used = (Number(contracts[contracts.length - 1].used) + Number(lessby)).toFixed(2);
	} else if (amount < usedtotal) {
		var overby = parseFloat(usedtotal - amount).toFixed(2);
		contracts[contracts.length - 1].used = (Number(contracts[contracts.length - 1].used) - Number(overby)).toFixed(2);
	}
	return contracts;
}


/* DIVISIONS */
var divisions = ["Customer Division 1", "Customer Division 2"];



/* CURRENT PAYMENTS */
/* the array that holds current payment batches */
var _tbos_payment_templates = [];

function generatePaymentTemplates() {
	var b = {};
	var batchreference = randString(5) + "-BatchPay";
	var debitaccount = _tbos_customer_accounts[rand(0, _tbos_customer_accounts.length - 1)];
	var paymenttype = _payment_types[rand(0, _payment_types.length - 1)];
	var workflow = _template_workflow[rand(0, _template_workflow.length - 1)];
	var paymentdate = smartDates("today");
	var paymentcurrency = _payment_currencies[rand(0, _payment_currencies.length - 1)];
	var numberOfPayments = rand(1, 20);


	/* build batch header details */
	b["id"] = randString(20);
	b["category"] = "batch";
	b["templateid"] = randString(10) + "TMP";
	b["templatename"] = "Template - " + randString(3);
	b["templatedescription"] = "This is a sample template description.";


	b["type"] = paymenttype;
	b["debitcredit"] = "DR";
	b["batchid"] = "B" + randString(5) + paymentdate;
	b["batchreference"] = batchreference;
	b["name"] = "Batch - " + randString(5) + " - " + paymentdate;
	b["batchdescription"] = "This is a sample payment description.";
	b["division"] = divisions[rand(0, divisions.length - 1)];
	b["paymentdate"] = paymentdate;
	b["paymentcurrency"] = paymentcurrency;
	b["debitaccount"] = debitaccount;
	b["debitaccountnumber"] = debitaccount.number;
	b["debitaccountname"] = debitaccount.name;
	b["debitcurrency"] = debitaccount.currency.code;
	b["debitaccountavailablebalance"] = debitaccount.availablebalance;
	b["debitaccountavailablefunds"] = debitaccount.availablefunds;

	/* batch settings flags */
	b["individualdebitsflag"] = rand(0, 1);
	b["urgentflag"] = (paymenttype.indexOf("International") != -1) ? rand(0, 1) : 0;
	b["debitequivalentflag"] = (debitaccount.currency.code == paymentcurrency) ? 0 : rand(0, 1);

	/* batch fx rate settings */
	b["ratetype"] = "";
	b["rate"] = "";
	b["fromccy"] = "";
	b["toccy"] = "";
	b["contracts"] = [];
	if (debitaccount.currency.code != paymentcurrency) {
		if (b["individualdebitsflag"] == 0) {
			b["ratetype"] = (debitaccount.currency.code == paymentcurrency) ? 0 : _payment_rate_types[rand(0, _payment_rate_types.length - 1)];
			if (b["ratetype"] == "Carded") {
				if (b["debitequivalentflag"] == 1) {
					for (var i = 0; i < _payment_system_rates.length; i++) {
						var psr = _payment_system_rates[i];
						if (debitaccount.currency.code == psr.from && paymentcurrency == psr.to) {
							b["rate"] = psr.rate;
							b["fromccy"] = debitaccount.currency.code;
							b["toccy"] = paymentcurrency;
							break;
						}
					}
				} else {
					for (var i = 0; i < _payment_system_rates.length; i++) {
						var psr = _payment_system_rates[i];
						if (debitaccount.currency.code == psr.to && paymentcurrency == psr.from) {
							b["rate"] = psr.rate;
							b["fromccy"] = paymentcurrency;
							b["toccy"] = debitaccount.currency.code;
							break;
						}
					}
				}
			}
		}
	}

	/* batch amounts */
	b["totalpaymentamount"] = 0;
	b["totaldebitamount"] = 0;

	/* generate batch payment instructions */
	b["payments"] = [];
	b["numberofpayments"] = numberOfPayments;
	for (var a = 0; a < numberOfPayments; a++) {
		var p = (b["payments"][a] = {});
		var beneficiary = _tbos_beneficiary_accounts[rand(0, _tbos_beneficiary_accounts.length - 1)];

		/* payment details */
		p["id"] = randString(20);
		p["number"] = a + 1;
		p["validated"] = true;
		p["batchreference"] = batchreference;
		p["beneficiary"] = beneficiary;
		p["beneficiaryname"] = beneficiary.benename;
		p["beneficiaryaccountnumber"] = beneficiary.beneaccount;
		p["beneficiaryid"] = beneficiary.beneid;
		p["paymentreference"] = "P" + randString(10);
		p["paymentdate"] = paymentdate;
		p["remittanceinformation"] = "This is sample remittance information";
		p["supportingdocs"] = [];
		p["paymentcurrency"] = paymentcurrency;
		p["debitaccountcurrency"] = debitaccount.currency.code;
		p["workflow"] = workflow.workflow;
		p["status"] = workflow.status;
		p["errors"] = [];
		if (b["type"].indexOf("International") != -1) {
			p["paymentmethod"] = "Telegraphic Transfer";
		} else {
			p["paymentmethod"] = _china_payment_methods[rand(0, _china_payment_methods.length - 1)];
		}
		if (p["paymentmethod"] == "BEPS") {
			p["purposecode"] = _beps_purpose_codes[rand(0, _beps_purpose_codes.length - 1)];
		} else if (p["paymentmethod"] == "DHVPS") {
			p["purposecode"] = _dhvps_purpose_codes[rand(0, _dhvps_purpose_codes.length - 1)];
		} else if (p["paymentmethod"] == "CBHVPS") {
			p["purposecode"] = _cbhvps_purspoe_codes[rand(0, _cbhvps_purspoe_codes.length - 1)];
		} else {
			p["purposecode"] = "";
		}
		p["ratetype"] = "";
		p["rate"] = "";
		p["contracts"] = [];
		if (debitaccount.currency.code != paymentcurrency) {
			if (b["individualdebitsflag"] == 1) {
				p["ratetype"] = _payment_rate_types[rand(0, _payment_rate_types.length - 1)];
				if (p["ratetype"] == "Carded") {
					if (b["debitequivalentflag"] == 1) {
						for (var i = 0; i < _payment_system_rates.length; i++) {
							var psr = _payment_system_rates[i];
							if (debitaccount.currency.code == psr.from && paymentcurrency == psr.to) {
								p["rate"] = psr.rate;
								p["fromccy"] = debitaccount.currency.code;
								p["toccy"] = paymentcurrency;
								break;
							}
						}
						p["debitequivalentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
						p["paymentamount"] = parseFloat(Number(p["debitequivalentamount"]) * Number(p["rate"])).toFixed(2);
					} else {
						for (var i = 0; i < _payment_system_rates.length; i++) {
							var psr = _payment_system_rates[i];
							if (debitaccount.currency.code == psr.to && paymentcurrency == psr.from) {
								p["rate"] = psr.rate;
								p["fromccy"] = paymentcurrency;
								p["toccy"] = debitaccount.currency.code;
								break;
							}
						}
						p["paymentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
						p["debitequivalentamount"] = parseFloat(Number(p["paymentamount"]) * Number(p["rate"])).toFixed(2);
					}
				} else if (p["ratetype"] == "Contract") {
					var _randomNumber = rand(1, 5);
					if (b["debitequivalentflag"] == 1) {
						p["debitequivalentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
						p["paymentamount"] = 0;
						p["contracts"] = generateFXContracts(debitaccount.currency.code, paymentcurrency, _randomNumber, p["debitequivalentamount"]);
						p["rate"] = (_randomNumber == 1) ? p["contracts"][0].rate : "";
						for (var i = 0; i < p["contracts"].length; i++) {
							p["paymentamount"] = Number(p["paymentamount"]) + (Number(p["contracts"][i].used) * Number(p["contracts"][i].rate));
						}
						p["paymentamount"] = p["paymentamount"].toFixed(2);
					} else {
						p["paymentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
						p["debitequivalentamount"] = 0;
						p["contracts"] = generateFXContracts(paymentcurrency, debitaccount.currency.code, _randomNumber, p["paymentamount"]);
						p["rate"] = (_randomNumber == 1) ? p["contracts"][0].rate : "";
						for (var i = 0; i < p["contracts"].length; i++) {
							p["debitequivalentamount"] = Number(p["debitequivalentamount"]) + (Number(p["contracts"][i].used) * Number(p["contracts"][i].rate));
						}
						p["debitequivalentamount"] = p["debitequivalentamount"].toFixed(2);
					}
				}
				b["totalpaymentamount"] = parseFloat(Number(b["totalpaymentamount"]) + Number(p["paymentamount"])).toFixed(2);
				b["totaldebitamount"] = parseFloat(Number(b["totaldebitamount"]) + Number(p["debitequivalentamount"])).toFixed(2);
			} else {
				if (b["debitequivalentflag"] == 1) {
					p["debitequivalentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
					b["totaldebitamount"] = parseFloat(Number(b["totaldebitamount"]) + Number(p["debitequivalentamount"])).toFixed(2);
				} else {
					p["paymentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
					b["totalpaymentamount"] = parseFloat(Number(b["totalpaymentamount"]) + Number(p["paymentamount"])).toFixed(2);
				}
			}
		} else {
			p["paymentamount"] = (parseFloat((Math.random() * 1000000) / 100)).toFixed(2);
			p["debitequivalentamount"] = p["paymentamount"];
			b["totalpaymentamount"] = parseFloat(Number(b["totalpaymentamount"]) + Number(p["paymentamount"])).toFixed(2);
			b["totaldebitamount"] = parseFloat(Number(b["totaldebitamount"]) + Number(p["debitequivalentamount"])).toFixed(2);
		}
	}


	/* set the final batch total payment and total debit amounts */
	if (b["ratetype"] == "Carded") {
		if (b["debitequivalentflag"] == 1) {
			b["totalpaymentamount"] = addCommas(parseFloat(Number(b["totaldebitamount"]) * Number(b["rate"])).toFixed(2));
			b["totaldebitamount"] = addCommas(b["totaldebitamount"]);
		} else {
			b["totaldebitamount"] = addCommas(parseFloat(Number(b["totalpaymentamount"]) * Number(b["rate"])).toFixed(2));
			b["totalpaymentamount"] = addCommas(b["totalpaymentamount"]);
		}
	} else if (b["ratetype"] == "Contract") {
		var _randomNumber = rand(1, 5);
		if (b["debitequivalentflag"] == 1) {
			b["contracts"] = generateFXContracts(debitaccount.currency.code, paymentcurrency, _randomNumber, b["totaldebitamount"]);
			b["rate"] = (_randomNumber == 1) ? b["contracts"][0].rate : "";
			b["fromccy"] = debitaccount.currency.code;
			b["toccy"] = paymentcurrency;
			for (var i = 0; i < b["contracts"].length; i++) {
				b["totalpaymentamount"] = Number(b["totalpaymentamount"]) + (Number(b["contracts"][i].used) * Number(b["contracts"][i].rate));
			}
			b["totalpaymentamount"] = addCommas(b["totalpaymentamount"].toFixed(2));
			b["totaldebitamount"] = addCommas(b["totaldebitamount"]);
		} else {
			b["contracts"] = generateFXContracts(paymentcurrency, debitaccount.currency.code, _randomNumber, b["totalpaymentamount"]);
			b["rate"] = (_randomNumber == 1) ? b["contracts"][0].rate : "";
			b["fromccy"] = paymentcurrency;
			b["toccy"] = debitaccount.currency.code;
			for (var i = 0; i < b["contracts"].length; i++) {
				b["totaldebitamount"] = Number(b["totaldebitamount"]) + (Number(b["contracts"][i].used) * Number(b["contracts"][i].rate));
			}
			b["totaldebitamount"] = addCommas(b["totaldebitamount"].toFixed(2));
			b["totalpaymentamount"] = addCommas(b["totalpaymentamount"]);
		}
	} else if (b["ratetype"] == "") {
		b["totalpaymentamount"] = addCommas(b["totalpaymentamount"]);
		b["totaldebitamount"] = addCommas(b["totaldebitamount"]);
	}


	/* status */
	b["workflow"] = workflow.workflow;
	b["status"] = workflow.status;
	b["errors"] = [];

	/* audit */
	b["audit"] = generateAuditLog(b);
	for (var i = 0; i < b["audit"].length; i++) {
		if (b["audit"][i].action == "Created") {
			b["createdby"] = b["audit"][i].by;
			b["createdon"] = b["audit"][i].date;
			break;
		}
	}
	for (var i = b["audit"].length - 1, l = 0; i > l; i--) {
		if (b["audit"][i].action == "Modified") {
			b["lastmodifiedby"] = b["audit"][i].by;
			b["lastmodifiedon"] = b["audit"][i].date;
			break;
		}
	}
	for (var i = b["audit"].length - 1, l = 0; i > l; i--) {
		if (b["audit"][i].action == "Approved") {
			b["lastapprovedby"] = b["audit"][i].by;
			b["lastapprovedon"] = b["audit"][i].date;
			break;
		}
	}

	return b;
}


for (var i = 0; i < 10; i++) {
	_tbos_payment_templates[i] = generatePaymentTemplates();
}