/**********************************************************************
FILES DATA
**********************************************************************/
var _files = [{
	id: randString(20),
	fileid: randString(10),
	filetype: "Payment",
	filename: "DIVPAYFILE1-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	controlamount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
	division: "Customer Division 1",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Payment",
	filename: "DIVPAYFILE2-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	controlamount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
	division: "Customer Division 1",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Payment",
	filename: "DIVPAYFILE3-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	controlamount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
	division: "Customer Division 1",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Payment",
	filename: "DIVPAYFILE4-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	controlamount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
	division: "Customer Division 1",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Payment",
	filename: "DIVPAYFILE5-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	controlamount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
	division: "Customer Division 2",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Payment",
	filename: "DIVPAYFILE6-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	controlamount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
	division: "Customer Division 2",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Beneficiary",
	filename: "DIVPAYFILE7-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	validbeneficiary: randNumber(1),
	beneficiariesneedrepair: randNumber(1),
	rejectedbeneficiaries: randNumber(1),
	totaltransactions: randNumber(2),
	controlamount: "--",
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	division: "Customer Division 2",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Beneficiary",
	filename: "DIVPAYFILE8-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	validbeneficiary: randNumber(1),
	beneficiariesneedrepair: randNumber(1),
	rejectedbeneficiaries: randNumber(1),
	controlamount: "--",
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	division: "Customer Division 2",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Beneficiary",
	filename: "DIVPAYFILE9-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	validbeneficiary: randNumber(1),
	beneficiariesneedrepair: randNumber(1),
	rejectedbeneficiaries: randNumber(1),
	controlamount: "--",
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	division: "Customer Division 2",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}, {
	id: randString(20),
	fileid: randString(10),
	filetype: "Beneficiary",
	filename: "DIVPAYFILE10-" + smartDates("today"),
	uploadedon: smartDates("today") + timeFormatter(),
	totalbatches: randNumber(2),
	validbeneficiary: randNumber(1),
	beneficiariesneedrepair: randNumber(1),
	rejectedbeneficiaries: randNumber(1),
	controlamount: "--",
	totaltransactions: randNumber(2),
	totalvalidtransactions: randNumber(1),
	totaltransactionsinrepair: randNumber(1),
	totalrejectedtransactions: randNumber(1),
	division: "Customer Division 2",
	format: "OTL Fixed Length",
	encoding: "UTF-8",
	entrytype: "File Upload",
	uploadedby: "Test User",
	status: "Processed"
}];


/**********************************************************************
GRID SETUP
**********************************************************************/
var data = _files;
var dataView;
var grid;
var record = null;
var fileRecord = null;
var selectedRowIds = [];
var columnFilters = {};
var	columns = [{
	id: "fileid",
	name: "File ID",
	field: "fileid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "filetype",
	name: "File Type",
	field: "filetype",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "filename",
	name: "File Name",
	field: "filename",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "totaltransactions",
	name: "Total No. of Transactions",
	field: "totaltransactions",
	width: 200,
	headerCssClass: "righted",
	cssClass: "num",
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "totalvalidtransactions",
	name: "Valid",
	field: "totalvalidtransactions",
	width: 100,
	headerCssClass: "righted",
	cssClass: "num",
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "totaltransactionsinrepair",
	name: "Needing Repair",
	field: "totaltransactionsinrepair",
	width: 160,
	headerCssClass: "righted",
	cssClass: "num",
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "totalrejectedtransactions",
	name: "Rejected",
	field: "totalrejectedtransactions",
	width: 120,
	headerCssClass: "righted",
	cssClass: "num",
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "controlamount",
	name: "Control Amount",
	field: "controlamount",
	width: 200,
	headerCssClass: "righted",
	cssClass: "num",
	formatter: Slick.Formatters.AmountFormatter,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "division",
	name: "Division",
	field: "division",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "uploadedon",
	name: "Uploaded On",
	field: "uploadedon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "uploadedby",
	name: "Uploaded By",
	field: "uploadedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "status",
	name: "Status",
	field: "status",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: false,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('filesColumnOrder')) {
	columns = store.get('filesColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if ( columns[i].id == "controlamount") {
			columns[i].formatter = Slick.Formatters.AmountFormatter
		}
	}
} else {
	store.set('filesColumnOrder', columns)
}
if (store.get('filesColumnWidths')) {
	var setWidth = store.get('filesColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var searchString = "", searchPoint = "";
function myFilter(item, args) {

	if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field],
					_greaterThen, _lessThen, _comparer, _between = false;
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, '');
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterFileGrid() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function quickFindFiles() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	dataView.setFilterArgs({
		searchString: searchString
	});
	dataView.refresh();
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
function filesViewFilter() {
	var rows = grid.getSelectedRows();
	folderString = "";
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		searchString: searchString
	});
	filterFileGrid();
}



/**********************************************************************
PAYMENT FILE UPLOAD FUNCTIONS
**********************************************************************/
function checkFormat() {
	var _gcp = ($(this).val() == "GCP Delimited") ? true : false;
	if (_gcp) {
		$("#debitIndicatorRow, #purposeRow").show();
	} else {
		$("#debitIndicatorRow, #purposeRow").hide();
	}
}
function clearErrors() {
	if ($(this).val() != '' && $(this).closest("div.row").hasClass("error")) {
		$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
	}
}
function clearAllErrors() {
	$("#fileUploadForm").find('div.error').removeClass("error").find("div.data-error").remove();
}
function cancelUpload() {
	$("#fileSection").hide();
	$("#uploadFileInput").val('');
	$("#uploadButton, #startUpload").removeClass("disabled");
	$(".progress-meter").stop(true, true).css({
		width: 0
	});
	clearAllErrors();
}
function showFileUploadSection() {
	$("#uploadMessage").hide();
	$("#fileSection, #fileUploadActions").show();
	$(".progress-meter").stop(true, true).css({
		width: 0
	});

	var str = $(this).val();
	var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);
	$("#filenamevalue").html(filename);
	console.log(this.files[0])
	if (window.ActiveXObject) {
		var myFSO = new ActiveXObject("Scripting.FileSystemObject");
		var filepath = document.getElementById('uploadFileInput').value;
		var thefile = myFSO.getFile(filepath);
		var size = thefile.size;
	} else {
		var size = this.files[0].size;
	}

	var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
	fSize = size;
	i = 0;
	while (fSize > 900) {
		fSize /= 1024;
		i++;
	}
	$("#filesize").html("(" + (Math.round(fSize * 100) / 100) + ' ' + fSExt[i] + ")");
}
function checkUploadSettings() {
	var _passed = true,
		_division = $("#divisionField").val(),
		_format = $("#formatField").val(),
		_encoding = $("#encodingField").val(),
		_indicator = $("#debitIndicatorField").val(),
		_purpose = $("#purposeField").val();

	if (!_division) {
		_passed = false;
		$("#divisionField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>Division is required</div>");
			}
		});
	}
	if (!_format) {
		_passed = false;
		$("#formatField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>File Format is required</div>");
			}
		});
	}
	if (!_encoding) {
		_passed = false;
		$("#encodingField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>File Encoding is required</div>");
			}
		});
	}

	if (_format == "GCP Delimited") {
		if (!_indicator) {
			_passed = false;
			$("#debitIndicatorField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>Debit Indicator is required</div>");
				}
			});
		}
		if (!_purpose) {
			_passed = false;
			$("#purposeField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>Payment Purpose is required</div>");
				}
			});
		}
	}

	if (_passed) {
		$("#fileUploadSection").closest("div.row").removeClass("error").find("div.data-error").remove();
		$("#uploadButton, #startUpload").addClass("disabled");
		$(".progress-meter").animate({
			width: "100%"
		}, 3000, function() {
			$("#uploadButton, #startUpload").removeClass("disabled");
			$("#fileUploadActions").hide();
			$("#uploadMessage").show();
			$("#uploadFileInput").val('');
		});
	} else {
		$("#fileUploadSection").closest("div.row").addClass("error").find("div.data-column").append($("<div class='data-error'>File does not match selection criteria</div>"));
	}
}
function populateFileUploadDialog() {
	var $dialogContent = $("<div class='py-ui' style='padding: 10px;' id='fileUploadForm' />");
	var $div = $("<div class=' top-label' />").appendTo($dialogContent);

	var $gridrow = $("<div class='grid-row' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridrow);

	var $row = $("<div class='row mandatory' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Division</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='divisionField'><option value=''></option><option value='Division ABC'>Division ABC</option><option value='Division 123'>Division 123</option><option value='Division XYZ'>Division XYZ</option></select>").appendTo($customSelect).on("change", clearErrors);

	var $row = $("<div class='row mandatory' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>File Format</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='formatField'><option value=''></option><option value='PAC File Format'>PAC File Format</option><option value='OTL Fixed Length'>OTL Fixed Length</option><option value='OTL Delimited'>OTL Delimited</option><option value='GCP Delimited'>GCP Delimited</option></select>").appendTo($customSelect).on("change", checkFormat).on("change", clearErrors);

	var $row = $("<div class='row mandatory' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>File Encoding</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='encodingField'><option value=''></option><option value='UTF-8'>UTF-8</option><option value='ASCII'>ASCII</option><option value='Unicode'>Unicode</option><option value='GB2312'>GB2312</option><option value='GB2312-80'>GB2312-80</option><option value='BIG5'>BIG5</option><option value='BIG5-HKSCS'>BIG5-HKSCS</option><option value='Shift-JIS'>Shift-JIS</option></select>").appendTo($customSelect).on("change", clearErrors);

	var $gridcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridrow);

	var $row = $("<div class='row mandatory' id='debitIndicatorRow' style='display: none;' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Debit Indicator</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='debitIndicatorField'><option value=''></option><option value='Bulk Debit'>Bulk Debit</option><option value='Itemised Debit'>Itemised Debit</option></select>").appendTo($customSelect).on("change", clearErrors);

	var $row = $("<div class='row mandatory' id='purposeRow' style='display: none;' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Payment Purpose</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='purposeField'><option value=''></option><option value='Non-Salary Payment'>Non-Salary Payment</option><option value='Salary Payment'>Salary Payment</option></select>").appendTo($customSelect).on("change", clearErrors);


	var $gridrow = $("<div class='grid-row' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);

	var $row = $("<div class='row' />").appendTo($gridcell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);
	var $buttonSpan = $("<span class='form-button primary' id='uploadButton' />").appendTo($dataCol);
	var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Browse Files</a>").appendTo($buttonSpan);
	var $fileInput = $("<input type='file' name='file' id='uploadFileInput' style='position: absolute; left: 30px; padding: 0; width: 155px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($buttonSpan).on('change', showFileUploadSection);


	var $gridrow = $("<div class='grid-row' style='display: none;' id='fileSection' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);
	var $row = $("<div class='row' />").appendTo($gridcell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);

	var $uploadDiv = $("<div class='file-upload-section' id='fileUploadSection' />").appendTo($dataCol);
	var $fileDiv = $("<div id='fileNameDiv' />").appendTo($uploadDiv);
	var $data = $("<div class='file-name'><i class='fa fa-paperclip fa-fw'></i> <strong id='filenamevalue'></strong></div>").appendTo($fileDiv);
	var $data = $("<div class='file-size'><span id='filesize'></span></div>").appendTo($fileDiv);
	var $uploadActions = $("<div id='fileUploadActions' />").appendTo($uploadDiv);
	var $btndiv = $("<div class='file-upload-buttons' />").appendTo($uploadActions);
	var $buttonSpan = $("<span class='form-button primary' id='startUpload' />").appendTo($btndiv);
	var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-upload fa-fw'></i>Start</a>").appendTo($buttonSpan).on("click", checkUploadSettings);
	var $buttonSpan = $("<span class='form-button' id='cancelUpload' />").appendTo($btndiv);
	var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i>Cancel</a>").appendTo($buttonSpan).on("click", cancelUpload);
	var $data = $("<div class='progress-bar'></div>").appendTo($uploadActions);
	var $meter = $("<div class='progress-meter' />").appendTo($data);
	var $messageDiv = $("<div class='file-upload-message' id='uploadMessage' style='display: none;' />").appendTo($uploadDiv);
	var $fileMessage = $("<div>This file has been <span style='color: #009900; font-weight: bold;'>successfully uploaded</span>. It will now be scanned and processed. You can find this file in the Payments File page with <strong>File ID: 34234234</strong>.</div>").appendTo($messageDiv);



	return $dialogContent;
}
function triggerUploadDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "uploadFile",
		title: "Upload Payment File",
		size: "xwide",
		icon: "<i class='fa fa-upload'></i>",
		content: function() {
			return populateFileUploadDialog()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/**********************************************************************
VIEW FILE DETAILS
**********************************************************************/
function viewFileDetails() {
	updateBreadcrumb("view");
	$("#fileid").html(fileRecord.fileid);
	$("#filestatus").html(fileRecord.status);
	$("#filename, #pagetitle").html(fileRecord.filename);
	$("#batchesno").html(fileRecord.totalbatches);
	$("#transactionsno").html(fileRecord.totaltransactions);
	$("#validno").html(fileRecord.totalvalidtransactions);
	$("#repairno").html(fileRecord.totaltransactionsinrepair);
	$("#rejectedno").html(fileRecord.totalrejectedtransactions);
	$("#validbene").html(fileRecord.validbeneficiary);
	$("#repairbene").html(fileRecord.beneficiariesneedrepair);
	$("#rejectedbene").html(fileRecord.rejectedbeneficiaries);
	$("#controlamount").html(fileRecord.controlamount);
	$("#division").html(fileRecord.division);
	$("#uploadedby").html(fileRecord.uploadedby);
	$("#uploadedon").html(fileRecord.uploadedon);
	$("#fileformat").html(fileRecord.format);
	$("#encoding").html(fileRecord.encoding);
	$("#entrytype").html(fileRecord.entrytype);
	$("#rejectedPaymentGrid").empty();
	if (fileRecord.totalrejectedtransactions > 0) {
		var $headRow = $("<div class='data-table-row' />"),
			$headLineCell = $("<div class='data-table-cell' style='width: 15%;'>File Line No.</div>").appendTo($headRow),
			$headReasonCell = $("<div class='data-table-cell' style='width: 85%;'>Reason For Rejection</div>").appendTo($headRow);
		$headRow.appendTo($("#rejectedPaymentGrid"));
		for (var i = 0, l = fileRecord.totalrejectedtransactions; i < l; i++) {
			var $row = $("<div class='data-table-row' />"),
				$lineCell = $("<div class='data-table-cell' style='width: 15%;'>" + randNumber(2) + "</div>").appendTo($row), $reasonCell;
				if(fileRecord.rejectedbeneficiaries >= 0) {
					$reasonCell = $("<div class='data-table-cell' style='width: 85%;'>Beneficiary item could not be parsed and read.</div>").appendTo($row);
				} else {
					$reasonCell = $("<div class='data-table-cell' style='width: 85%;'>Payment item could not be parsed and read.</div>").appendTo($row);
				}
			$row.appendTo($("#rejectedPaymentGrid"));
		}
		$("#rejectedTransactionSection").show();
	} else {
		$("#rejectedTransactionSection").hide();
	}
	if(fileRecord.filetype == "Payment"){
		$('#filetype3').text("Payment");
		$('#viewpay').css("display","inline-block")
		$('#viewbene').css("display","none");
		$('#p1,#p2,#p3,#p4,#p5,#p6, #p7').css("display","block");
		$('#b1,#b2,#b3').css("display","none");
		$('#headingrejected').text('Rejected Transactions');
		$('#textrejected').text('The following transactions could not be imported from the payment file.');
		$('#moretext').text('* This number represents the number of transactions needing repair at the time the file was uploaded.');
	} else {
		$('#filetype3').text("Beneficiary");
		$('#viewbene').css("display","inline-block");
		$('#viewpay').css("display","none");
		$('#p1,#p2,#p3,#p4,#p5,#p6, #p7').css("display","none");
		$('#b1').css("display","block");
		$('#b2').css("display","block");
		$('#b3').css("display","block");
		$('#headingrejected').text('Rejected Beneficiaries');
		$('#textrejected').text('The following beneficiaries could not be imported from the beneficiary file.');
		$('#moretext').text('* This number represents the number of beneficiaries needing repair at the time the file was uploaded.');
	}
}


/**********************************************************************
UPDATE THE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='payments-files.html'>Payment File Summary</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("File Details");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Payment File Summary");
	}
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#grid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'filesColumnOrder', 'filesColumnWidths', []);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		fileRecord = dataView.getItem(row);
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell);
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
			}
		}
		if (selectedRowIds.length > 0) {
			$("#paymentSummaryGrid").addClass("has-bottom-controls");
			$("#paymentsGrid .bottom-controls").removeClass("hidden");
			$("#selectedCount").html(selectedRowIds.length);
			grid.resizeCanvas();
		} else {
			$("#paymentSummaryGrid").removeClass("has-bottom-controls");
			$("#paymentsGrid .bottom-controls").addClass("hidden");
			$("#selectedCount").html('');
			grid.resizeCanvas();
		}
	});
	grid.onClick.subscribe(function(e, args) {
		row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			fileRecord = dataView.getItem(row);
			$row.attr({
				'data-panel': '#fileDetail',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			grid.setSelectedRows(0);
			selectedRowIds = [];
			viewFileDetails();
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('filesColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		searchString: searchString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('filesColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i < store.get('filesColumnOrder').length; i++) {
			if (columns[i].visible) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleAdHocColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	GRID RESIZER
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


	/**********************************************************************
	UPLOAD FILE INTERACTION
	**********************************************************************/
	$("#newFileUpload").on("click", triggerUploadDialog);


	/**********************************************************************
	CONTEXT MENU
	**********************************************************************/
	$("#viewFileDetails").on("click", function(e){
		e.preventDefault();
		$(this).attr({
			'data-panel': '#fileDetail',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		grid.setSelectedRows(0);
		selectedRowIds = [];
		viewFileDetails();
	});


	/**********************************************************************
	CLOSE DETAIL VIEW
	**********************************************************************/
	$("#closeDetailView").on("click", function(e){
		updateBreadcrumb("close");
	});


	/**********************************************************************
	GROUPING
	**********************************************************************/
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});


	/**********************************************************************
	SETTINGS
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


});