function renderSliderDialog(e) {
    e.preventDefault();
	function renderImage() {
		var $dialogContent = $("<div style='display: none;' class='center slider' />");
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>Access payments easily from your <span class='c007dba'>workspace</span> or the <span class='c007dba'>navigation menu</span>.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>You can <span class='c007dba'>create</span>, <span class='c007dba'>view</span> and <span class='c007dba'>approve</span> a range of payment types for your organisation.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>After the <span class='c007dba'>final approval</span> step, <span class='c007dba'>successful payments</span> will be <span class='c007dba'>automatically sent to the bank for processing</span> as a release step is not required.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide01.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>You can manage a range of payment types for your organisation:</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph' style='padding: 0;'><ul><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Account Transfers</li><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Domestic &amp; International Payments</li><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Salary Payments</li></ul></div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Choose to create a payment using a <span class='c007dba'>template</span>, <span class='c007dba'>file</span> or <span class='c007dba'>past payment</span>. You can also setup and manage <span class='c007dba'>recurring payments</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide02.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><span class='c007dba'>Current Payments</span> gives you a consolidated view of <span class='c007dba'>unprocessed payments</span> and payments processed in the last seven calendar days.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Here you can also <span class='c007dba'>review</span> and <span class='c007dba'>approve payments</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide03.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><span class='c007dba'>Past Payments</span> gives you a consolidated view of payments processed <span class='c007dba'>in the last 24 months</span>. The default 30 day view can be easily customised.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>It shows you payments in a <span class='c007dba'>Completed</span>, <span class='c007dba'>Completed with Errors</span> or <span class='c007dba'>Bank Rejected status</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide04.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>Use the <span class='c007dba'>Payee List</span> to setup and manage <span class='c007dba'>beneficiaries you frequently pay</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide05.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>Use <span class='c007dba'>Templates</span> to view, create and approve your <span class='c007dba'>regular payments</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide06.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>Use the <span class='c007dba'>File Import Summary</span> for a consolidated view of the <span class='c007dba'>payment files uploaded</span> for your organisation.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide07.png' style='border: 0;' />").appendTo($guideImage);
		
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/payments/slide08.png' style='border: 0;' />").appendTo($guideImage);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><strong>Need more information?</strong></div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>View <span class='c007dba'>Online Help</span> within ANZ Transactive – Global or visit our <span class='c007dba'>Online Resources</span> site to access a range of detailed guidance.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>We also encourage you to be familiar with our <a href='about:blank' target='_blank' style='color: #007dba; text-decoration: underline;'>Privacy Statement</a></div>").appendTo($guideContent);

		setTimeout(function() { 
			$('.dialog-container').removeClass('working').on("click", function(e){
				e.stopPropagation();
			});
			$('.slider').show(); 
			$(".center").slick({
				dots: true,
				infinite: true,
				prevArrow: '<div><i class="fa fa-chevron-circle-left faprev" aria-hidden="true"></i></div>',
				nextArrow: '<div><i class="fa fa-chevron-circle-right fanext" aria-hidden="true"></i></div>',
				slidesToShow: 1,
			});
		},800);
		return $dialogContent;
	}
	var $target = $(e.target);
	var origin = $target.closest(".dialog-parent").length > 0 ? $target.closest(".dialog-parent") : $target;
	var dialog = {
		id: "guideDialog",
		title: "Accounts Onscreen Guide",
		size: "guide working",
		icon: "<i class='fa fa-info-circle'></i>",
		content: function() {
			return renderImage();
		}
		
	}
	dialogViewer(origin, dialog, dialogBuilder(dialog));
}