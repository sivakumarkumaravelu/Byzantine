/**********************************************************************
SEARCH GRID
**********************************************************************/
var data = _tbos_past_payment_batches;
var dataView;
var grid;
var record = null;
var selectedRowIds = [];
var selectedRowStates = [];
var selectedRowWorkflows = [];
var columnFilters = {};
var columns = [{
	id: "name",
	name: "Beneficiary / Payment Name",
	field: "name",
	width: 250,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "status",
	name: "Status",
	field: "status",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "batchid",
	name: "Payment ID",
	field: "batchid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "totaldebitamount",
	name: "Debit Amount",
	field: "totaldebitamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "debitcurrency",
	name: "Debit Currency",
	field: "debitcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitcredit",
	name: "Debit / Credit",
	field: "debitcredit",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "debitaccountnumber",
	name: "Debit Account Number",
	field: "debitaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "paymentdate",
	name: "Value Date",
	field: "paymentdate",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "type",
	name: "Payment Type",
	field: "type",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitaccountname",
	name: "Debit Account Name",
	field: "debitaccountname",
	width: 220,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "totalpaymentamount",
	name: "Payment Amount",
	field: "totalpaymentamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "paymentcurrency",
	name: "Payment Currency",
	field: "paymentcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "rate",
	name: "Exchange Rate",
	field: "rate",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: false
}, {
	id: "beneficiaryaccountnumber",
	name: "Beneficiary Account",
	field: "beneficiaryaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiaryid",
	name: "Beneficiary ID",
	field: "beneficiaryid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiarybankid",
	name: "Beneficiary Bank ID",
	field: "beneficiarybankid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiarybankname",
	name: "Beneficiary Bank Name",
	field: "beneficiarybankname",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "createdby",
	name: "Created By",
	field: "createdby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false,
}, {
	id: "createdon",
	name: "Creation Date",
	field: "createdon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: false
}, {
	id: "lastmodifiedby",
	name: "Last Modified By",
	field: "lastmodifiedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "lastmodifiedon",
	name: "Last Modified Date",
	field: "lastmodifiedon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: false
}, {
	id: "lastapprovedby",
	name: "Last Approver",
	field: "lastapprovedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "numberofpayments",
	name: "No. of Instructions",
	field: "numberofpayments",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "contractid",
	name: "Contract ID",
	field: "contractid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "division",
	name: "Division",
	field: "division",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('paymentSearchColumnOrder')) {
	columns = store.get('paymentSearchColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "totaldebitamount" || columns[i].id == "totalpaymentamount") {
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
} else {
	store.set('paymentSearchColumnOrder', columns)
}
if (store.get('paymentSearchColumnWidths')) {
	var setWidth = store.get('paymentSearchColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());

var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var searchString = "", statusString = "", workflowString = "", userString = "", searchPoint = "debitaccountnumber";
function myFilter(item, args) {

	if (args.statusString != "" && args.statusString.toLowerCase().indexOf(item["status"].toLowerCase()) == -1) {
		return false;
	}

	if (args.workflowString != "" && item["workflow"].toLowerCase().indexOf(args.workflowString.toLowerCase()) == -1) {
		return false;
	}

	if (args.userString != "" && item["createdby"].toLowerCase().indexOf(args.userString.toLowerCase()) == -1) {
		return false;
	}

	if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterPaymentSummaryGrid() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function quickFindPayments() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.refresh();
}
function paymentsViewFilter() {
	var rows = grid.getSelectedRows();
	folderString = "";
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	filterPaymentSummaryGrid();
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}


/**********************************************************************
SEARCH FIELD TOGGLE
**********************************************************************/
var search_height = 0;
var inMotion = false;
function showSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	$this.attr("show", "true").addClass("btn-on");
	$i.removeClass("fa-search-plus").addClass("fa-search-minus");
	$(".search-fields").removeClass("slide-up");
	$(".scroll-area").removeClass("full-height");
	$(".basic-search").css("overflow", "hidden");
	inMotion = setTimeout(function() {
		$(".basic-search").css("overflow", "visible");
		grid.resizeCanvas();
		inMotion = false;
	}, 300);
}
function hideSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	if (inMotion) clearTimeout(inMotion);
	$i.removeClass("fa-search-minus").addClass("fa-search-plus");
	$this.attr("show", "false").removeClass("btn-on");
	$(".search-fields").css("overflow", "hidden").addClass("slide-up");
	$(".scroll-area").addClass("full-height");
	setTimeout(function() {
		grid.resizeCanvas();
	}, 300);
}

/**********************************************************************
CONTEXT MENU SETUP
**********************************************************************/
function checkStatus(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
function checkWorkflow(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
var enableContextItem = function() {
	$(this).children("div.disabled").remove();
	$(this).children("a").show();
}
var disableContextItem = function() {
	if ($(this).children("div.disabled").size()) {
		$(this).children("div.disabled").remove();
	}
	var $a = $(this).children("a"),
		$div = $("<div class='disabled' />"),
		content = $a.html();
	$a.hide();
	$div.html(content).appendTo($(this));
}
function setupContextMenu(record) {
	var sel = selectedRowIds.length,
		$contextItems = $("[data-type='context-item']");
	if (record != null) {
		sel = 1;
	}
	if (!sel) {
		$contextItems.each(disableContextItem);
	} else {
		if (sel == 1) {
			$("[data-action='copy'], [data-action='pymtemplate'], [data-action='reports']").each(enableContextItem);
		} else {
			$("[data-action='copy'], [data-action='pymtemplate'], [data-action='reports']").each(disableContextItem);
		}
	}
}


/**********************************************************************
					SEARCH INDICATOR SETUP
**********************************************************************/
function indicatorSelection() {
	var alphaIndicators = ["*", "Like", "=", "Equal To", "&ne;", "Not Equal To"],
		numIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "&gt;", "Greater Than", "&lt;", "Less Than", "&hArr;", "Between"],
		dateIndicatores = ["=", "Specific Date", "&hArr;", "Date Range", "Rd", "Rolling Dates"],
		autoCompleteIndicators = ["=", "Equal To", "&ne;", "Not Equal To"];
	var $indicatorMenu, whichArray, indicator, mainInput, fromInput, toInput, rollingInput, hiddenInput;
	var sibs;

	function init() {
		$indicatorMenu = $("<div class='indicator-menu' style='display:none;position:absolute;' />").appendTo(document.body);
		$indicatorMenu.bind("click", setIndicator);
		setupIndicators();
	}

	function setupIndicators() {

		var $indicatorItem;
		$(".transactionSearch .indicator").bind("click", function(e) {
			e.stopPropagation();
			if ($indicatorMenu.is(":visible") && $indicatorMenu.attr("id") == $(this).attr("id") + "m") {
				$indicatorMenu.empty().hide();
				return;
			}
			$indicatorMenu.empty();
			indicator = $(this);
			sibs = $(this).siblings("input").not("input[type='hidden']");
			mainInput = $(this).next("input");
			fromInput = mainInput.next("input");
			toInput = fromInput.next("input");
			rollingInput = toInput.next("input");
			hiddenInput = $(this).siblings("input[type='hidden']");
			$indicatorMenu.attr("id", indicator.attr("id") + "m");
			whichArray = alphaIndicators;
			if ($(this).hasClass("num")) whichArray = numIndicators;
			if ($(this).hasClass("date")) whichArray = dateIndicatores;
			if ($(this).hasClass("auto")) whichArray = autoCompleteIndicators;
			for (var i = 0; i < whichArray.length; i++) {
				$indicatorItem = $("<div />").attr("id", i).html("<strong id=" + i + ">" + whichArray[i] + "</strong> " + whichArray[i + 1]).appendTo($indicatorMenu);
				i = i + 1;
			}
			var pleft = $(this).offset().left;
			var ptop = $(this).offset().top + $(this).height() + 2;
			$indicatorMenu.css("top", ptop).css("left", pleft).show();
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").children(".on").removeClass("on");
			$("body").one("click", function() {
				$indicatorMenu.empty().hide();
			});
			$(document).on("keyup.hideIndicator", function(e) {
				if (e.keyCode == 27) {
					$indicatorMenu.empty().hide();
					$(document).off("keyup.hideIndicator");
				}
			});
		});
	}

	function setIndicator(e) {
		var indset = whichArray[parseInt(e.target.id)];
		var hidset = whichArray[parseInt(e.target.id) + 1];
		indicator.html(indset).attr("title", hidset);
		hiddenInput.val(hidset);
		if (hidset == "Date Range" || hidset == "Between") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.removeClass("display-none").prop("disabled", "").focus();
			toInput.removeClass("display-none").prop("disabled", "");
		}
		if (hidset == "Rolling Dates") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.removeClass("display-none").prop("disabled", "").focus();
		}
		if (hidset != "Date Range" && hidset != "Rolling Dates" && hidset != "Between") {
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			mainInput.removeClass("display-none").prop("disabled", "").focus();
		}
	}
	init();
}


/**********************************************************************
							SAVED SEARCHES
**********************************************************************/
var saved_searches = [{
		name: "Payments up to $10k",
		id: "asdf3"
	}, {
		name: "All Singapore Payments",
		id: "sdf23"
	}, {
		name: "Last Week Payments",
		id: "hgj56"
	}, {
		name: "SGD Payments",
		id: "ncve4"
	}],
	searches_updated = false,
	searches_deleted = false,
	$search_message = $("<p>Use the saved search feature to save frequent searches and quickly recall them.</p>");
if (store.get('saved_payment_searches')) {
	saved_searches = store.get('saved_payment_searches')
};
function searchChecker(val) {
	var _search = val,
		error = false,
		$searchList = $(".search-list").children("li"),
		existingSearches = [];
	for (var i = 0; i < $searchList.length; i++) {
		existingSearches.push($searchList.eq(i).attr("data-search"));
	}
	if ($.inArray(_search, existingSearches != -1)) {
		error = "existing"
	}
	return error;
}
function renameSearch(el) {
	var newSearchName = $.trim(el.val());
	if (newSearchName == '' || newSearchName == "undefined") {
		el.val(el.attr("data-search-name"));
	} else {
		el.val(newSearchName);
		el.closest("li").attr("data-search", newSearchName);
		searches_updated = true;
	}
}
function deleteSearch(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function() {
		if (!$target.hasClass('new')) {
			searches_deleted = true;
		}
		$target.remove();
		$(".folder-list").sortable("refresh");
		searches_updated = true;
		if (!$(".folder-list").children("li").size()) {
			$(".search-instructions").remove();
			$search_message.appendTo(".folder-settings");
		}
	});
}
function runSavedSearch() {
	$(".shell").addClass("loading");
	$("#paymentSummaryGrid").addClass("hidden");
	$("#noSearch").show();
	setTimeout(function() {
		$(".shell").removeClass("loading");
		$("#noSearch").hide();
		$("#paymentSummaryGrid").removeClass("hidden");
		hideSearchFields();
	}, 500);
}
function runSavedSearchFromSearchManagerDialog(dialog, searchid) {
	dialogHider(dialog);
	$("#" + searchid).trigger("click");
	hideSearchFields();
}
function populateSearches() {
	var $savedSearches = $(".saved-searches"),
		searchCount = saved_searches.length,
		activeSearch = $savedSearches.children("li.active") ? $savedSearches.children("li.active").attr("data-search-id") : false;
	$savedSearches.children().remove();
	if (searchCount > 0) {
		var $li, $a
		$savedSearches.each(function() {
			var _this = $(this);
			if (_this.parents().attr("id") == "viewMenu") {
				$.each(saved_searches, function() {
					$li = $("<li data-search='" + this.name + "' data-search-id='" + this.id + "' />").appendTo(_this);
					if (this.id == activeSearch) {
						$li.addClass("active");
						$("#searchMenuControl").children("a").children("span").html(this.name);
					}
					$a = $("<a href='javascript:void(0)' id='" + this.id + "' title='" + this.name + "' data-search='" + this.name + "' data-search-id='" + this.id + "'>" + this.name + "</a>").on("click", runSavedSearch).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.saved-searches"),
			$li = $("<li class='no-set' />").appendTo($viewMenu),
			$a = $("<div >You have no saved searches</div>").appendTo($li);
	}
}
function populateSearchManager(dialog) {
	searches_updated = false;
	searches_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
		$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({
			handle: '.reorder-folder',
			axis: 'y',
			tolerance: "pointer",
			update: function(event, ui) {
				searches_updated = true
			}
		}),
		folderCount = saved_searches.length,
		$li, $div, $span, $input, $remove, $view, $error;
	if (folderCount > 0) {
		$folderAddLine = $("<p class='search-instructions'>Reorder, rename, run or remove your saved searches.</p>").insertBefore($folderList),
			$.each(saved_searches, function() {
				$li = $("<li data-search='" + this.name + "' data-search-id='" + this.id + "' class='row' />").appendTo($folderList);
				$div = $("<div class='folder-row data-column' />").appendTo($li);
				$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
				$input = $("<input type='text' maxlength='25' value='" + this.name + "' data-search-name='" + this.name + "' />").on("change", function() {
					renameSearch($(this));
				}).appendTo($div);
				$view = $("<a href='javascript:void(0)' class='view-folder' data-search-id='" + this.id + "'><i class='fa fa-search fa-fw'></i></a>").appendTo($div).on("click", function(e) {
					e.preventDefault();
					runSavedSearchFromSearchManagerDialog(dialog, $(this).attr("data-search-id"));
				});
				$remove = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteSearch).appendTo($div);
				$error = $("<div class='data-error'>A saved search with this name already exists</div>").appendTo($div);
			});
	} else {
		$search_message.appendTo($folderSettings);
	}
	return $folderSettings;
}
function populateNewSearchDialog() {
	var $dataForm = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($dataForm),
		$row = $("<div class='row' />").appendTo($formSection),
		$labelCol = $("<div class='label-column' />").appendTo($row),
		$label = $("<label>Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($row),
		$data = $("<input type='text' style='width: 190px;' name='searchName' id='searchNameField' value='' />").appendTo($dataCol);
	return $dataForm;
}
function showSaveNewSearchDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "newSavedSearch",
		title: "Save Search Criteria",
		size: "small",
		icon: "<i class='fa fa-save'></i>",
		content: function() {
			return populateNewSearchDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Save",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveNewSearch(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveNewSearch(dialog) {
	var _newSearchName = $("#searchNameField").val(),
		exists = false,
		newSearch = {};
	var saveTheSearch = function(dialog) {
		dialogHider(dialog);
		populateSearches();
		buildNotification("You search has been saved", 300, 4000);
	}
	for (var i = 0, l = saved_searches.length; i < l; i++) {
		if (saved_searches[i].name == _newSearchName) {
			exists = true;
			break;
		}
	}
	if (exists) {
		buildConfirmDialog("This Saved Search already exists. Do you want to replace the existing Saved Search?", function() {
			saveTheSearch(dialog);
		});
	} else {
		newSearch = {
			name: _newSearchName,
			id: randString(20)
		}
		saved_searches.push(newSearch);
		store.set('saved_payment_searches', saved_searches);
		saveTheSearch(dialog);
	}
}
function showSearchManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "savedSearchManager",
		title: "Manage Saved Searches",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function() {
			return populateSearchManager(_dialog)
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateSearches(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveSearches(dialog) {
	var $dialog = $("#" + dialog.id),
		$active = $("#viewMenu").children(".saved-searches").find("li.active").attr("data-search-id");
	$dialog.addClass("working");
	saved_searches = searches_updated;

	var active_deleted = true;

	for (f = 0; f < saved_searches.length; f++) {
		if ($active == saved_searches[f].id) {
			active_deleted = false;
			break;
		}
	}

	searches_updated = false;
	searches_deleted = false;
	store.set('saved_payment_searches', saved_searches);
	setTimeout(function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateSearches();
		if (!saved_searches.length || active_deleted) {
			$("#_noSearch").trigger("click");
		}
		dialogHider(dialog);
	}, 300);
}
function updateSearches(dialog) {
	if (searches_updated) {
		searches_updated = [];
		var duplicate_names = false,
			$searchList = $(".folder-list");
		$searchList.find("li.error").removeClass("error");
		$searchList.children("li").each(function() {
			searches_updated.push({
				"name": $(this).attr("data-search"),
				"id": $(this).attr("data-search-id")
			});
			var _name = $(this).attr("data-search");
			$(this).siblings().each(function() {
				if ($(this).attr("data-search") == _name) {
					$(this).addClass("error");
				}
			});
		});
		if ($searchList.find("li.error").size()) {
			duplicate_names = true;
		}
		if (duplicate_names) {
			return false;
		} else {
			var save_searches = false;
			if (saved_searches.length != searches_updated.length) {
				save_searches = true;
			} else {
				for (var i = 0; i < saved_searches.length; i++) {
					if (saved_searches[i].name != searches_updated[i].name || saved_searches[i].id != searches_updated[i].id) {
						save_searches = true;
						break;
					}
				}
			}
			if (save_searches || searches_deleted) {
				if (searches_deleted) {
					buildConfirmDialog("You've deleted some saved searches.", "Are you sure you want to continue?", function() {
						saveSearches(dialog)
					});
				} else {
					saveSearches(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}


/**********************************************************************
DIALOG WINDOWS
**********************************************************************/
function showPaymentDetailReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#detailReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}


		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "detailReportDialog",
		title: "Payment Detail Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentSummaryReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#summaryReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}


		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "summaryReportDialog",
		title: "Payment Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentTemplateDialog(e) {
	e.preventDefault();



	function confirmTemplateCreation(_dialog) {
		$("#createTemplateDialog").addClass("working");
		setTimeout(function() {
			buildCustomDialog([{
				text: "Template Name: " + $("#templateName").val(),
				style: "color: #007dba; font-weight: bold;"
			}, {
				text: "Payment template has been successfully created.",
				style: ""
			}], [{
				title: "Ok",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
				}
			}, {
				title: "View This Template",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
					setTimeout(function() {
						document.location.href = "payments-templates.html#detail";
					}, 500);
				}
			}]);
			dialogHider(_dialog);
		}, 1000);
	}


	var populateTemplateCreationDialog = function() {
		var $dialogContent = $("<div class='data-form top-label' id='templateDialogContent' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row mandatory' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateName' style='width: 90%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateDesc' style='width: 90%;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "createTemplateDialog",
		title: "Create A Template From This Payment",
		size: "xsmall",
		icon: "<i class='fa fa-clipboard'></i>",
		content: function() {
			return populateTemplateCreationDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					confirmTemplateCreation(_dialog)
				}
			}],
			attributes: [{
				name: "id",
				value: "createTemplateButton"
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#templateName").focus();
}


/**********************************************************************
VIEW PAYMENT DETAILS
**********************************************************************/
function viewPaymentDetails(record) {

	updateBreadcrumb("view");

	var showDebitDescriptionDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderBatchDescriptionDialog() {
			var $dialogContent = $("<div class='py-ui' />"),
				$row = $("<div class='row' />").appendTo($dialogContent),
				$dataCol = $("<div class='data-column full' />").appendTo($row),
				$data = $("<textarea style='width: 95%; height: 150px;' disabled='disabled' class='disabled' id='viewBatchDescriptionField'>" + record.batchdescription + "</textarea>").appendTo($dataCol);
			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Advice Description",
			size: "xsmall",
			icon: "<i class='fa fa-edit'></i>",
			content: function() {
				return renderBatchDescriptionDialog();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var showDebitAccountDetailsDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderDebitAccountInformation() {
			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />"),
				$box = $("<div class='box' />").appendTo($dialogContent),
				$boxHeader = $("<div class='box-header'>Account Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Account Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.name + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Debit Account</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.number + " (" + record.debitaccount.currency.code + ")</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Branch Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.name + " " + record.debitaccount.bank.branch + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Address</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$inputGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address1 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address2 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address3 + "</div>").appendTo($inputGroup),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Country</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.country + "</div>").appendTo($dataCol);

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Account Information",
			size: "large",
			icon: "<i class='fa fa-external-link'></i>",
			content: function() {
				return renderDebitAccountInformation();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* setup the review grid */
	var reviewDataView;
	var reviewGrid;
	var reviewData = [];
	var reviewColumns = [{
		id: "number",
		name: "#",
		field: "number",
		toolTip: "Item Number",
		width: 50,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: false
	}, {
		id: "validated",
		name: "<i class='fa fa-check-circle fa-fw'></i>",
		field: "validated",
		toolTip: "Payment Validation",
		width: 60,
		headerCssClass: "centered",
		cssClass: "centered",
		sortable: false,
		visible: true,
		resizable: false,
		formatter: Slick.Formatters.ValidatedIconFormatter
	}, {
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryaccountnumber",
		name: "Account",
		field: "beneficiaryaccountnumber",
		toolTip: "Beneficiary Account",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "status",
		name: "Status",
		field: "status",
		toolTip: "Status",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}];

	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			visible: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			visible: true,
			formatter: Slick.Formatters.AmountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			visible: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			visible: true,
			formatter: Slick.Formatters.AmountFormatter
		}
	}
	reviewColumns.push(currencyColumn);
	reviewColumns.push(amountColumn);

	var reviewOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};

	var $paymentDetailSection = $("#viewPaymentDetail");



	/* CONTROL BAR */
	var $topControls = $("<div class='top-controls' />");
	var $controlList = $("<ul class='control-list' />").appendTo($topControls);


	/* ACTION BUTTON GROUP */
	var $recordActionButtonGroup = $("<div class='btn-group' />");
	var $reportsButton = $("<span class='btn has-menu' />").appendTo($recordActionButtonGroup).on("click", controlMenuManager),
		$reportsAnchor = $("<a href='#requestReportsMenu' title='Reports' />").appendTo($reportsButton),
		$reportsIcon = $("<i class='fa fa-file-text fa-fw text-right'></i>").appendTo($reportsAnchor),
		$reportsText = $("<span>Reports</span>").appendTo($reportsAnchor);
		$reportsMenuIcon = $("<i class='fa fa-caret-down fa-fw menu-arrow'></i>").appendTo($reportsAnchor);
	var $actionButton = $("<span class='btn has-menu' />").appendTo($recordActionButtonGroup).on("click", controlMenuManager),
		$actionAnchor = $("<a href='#actionMenu' title='Actions' />").appendTo($actionButton),
		$actionIcon = $("<i class='fa fa-ellipsis-v fa-fw text-right'></i>").appendTo($actionAnchor),
		$actionText = $("<span>Actions</span>").appendTo($actionAnchor);
		$actionMenuIcon = $("<i class='fa fa-caret-down fa-fw menu-arrow'></i>").appendTo($actionAnchor);


	/* CLOSE PREVIOUS NEXT BUTTON GROUP */
	var $recordNavigationButtonGroup = $("<div class='btn-group' />");
	var $closeButton = $("<span class='btn' />").appendTo($recordNavigationButtonGroup),
		$closeAnchor = $("<a href='#paymentsGrid' title='Close Record' data-action='close' data-panel='#pastPaymentSearch' data-switch='switch-panels' />").appendTo($closeButton).appendTo($closeButton).on("click", function(e) {
			record = null;
			reviewGrid.destroy()
			reviewGrid = null;
			reviewDataView = null;
			reviewData = [];
			reviewColumsn = [];
			$(window).off("resize.reviewgrid");
			$("#viewPaymentContent").remove();
			updateBreadcrumb("close");
		}),
		$closeIcon = $("<i class='fa fa-times fa-fw text-right'></i>").appendTo($closeAnchor),
		$closeText = $("<span>Close</span>").appendTo($closeAnchor);


	/* ATTACH BUTTONS AND CONTROL BAR */
	$recordActionButtonGroup.appendTo($controlList);
	$recordNavigationButtonGroup.appendTo($controlList);
	$topControls.appendTo($paymentDetailSection);




	/* view payment section */
	var $paymentDetailContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; background: #f5f5f5;' id='viewPaymentContent' />");

	/* detail section */
	var $paymentDataSection = $("<div class='grid-layout' />").appendTo($paymentDetailContainer);



	/* HEADING SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
		$data = $("<div class='data-text'><span class='large-blue-text'>" + record.type + " Payment ID: " + record.batchid + "</span></div>").appendTo($dataGroup);
		$data = $("<div class='data-text'><strong>Value Date:</strong> " + record.paymentdate + "</div>").appendTo($dataGroup);
	if (record.filereference) {
		var $data = $("<div class='data-text'><strong>File Reference:</strong> " + record.filereference + "</div>").appendTo($dataGroup);
	}
	var	$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$dataCol = $("<div class='data-column text-right' />").appendTo($dataRow),
		$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
		$data = $("<div class='data-text'><strong style='font-size: 16px;'>"+record.paymentcurrency+"</strong> <span class='large-blue-text'>$" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($dataGroup);
	var	$data = $("<div class='data-text'><strong>Status:</strong> " + record.status + "</div>").appendTo($dataGroup);


	/* ALERTS AND ERRORS SECTION */
	if (record.notices == 1) {
		function dynamicSort(property) {
			var sortOrder = 1;
			if (property[0] === "-") {
				sortOrder = -1;
				property = property.substr(1);
			}
			return function(a, b) {
				var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
				return result * sortOrder;
			}
		}
		record.noticeitems.sort(dynamicSort("type")).reverse();
		var _haserrors = false;
		for (var e = 0, f = record.noticeitems.length; e < f; e++) {
			if (record.noticeitems[e].type == "error") {
				_haserrors = true;
				break;
			}
		}
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell);
		if (_haserrors) {
			var $boxHeader = $("<div class='box-header'>Payment Errors and Alerts</div>").appendTo($box);
		} else {
			var $boxHeader = $("<div class='box-header'>Payment Alerts</div>").appendTo($box);
		}
		var	$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$errorGrid = $("<div class='error-grid' id='errorsGrid' />").appendTo($dataCol),
			$errorList = $("<ul class='error-list' />").appendTo($errorGrid);

		for (var e = 0, f = record.noticeitems.length; e < f; e++) {
			var _class = (record.noticeitems[e].type == "error") ? "error-icon" : "alert-icon";
			var $errorLi = $("<li><span class='" + _class + "'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + record.noticeitems[e].description + "</span></li>").appendTo($errorList);
		}
	}

	/* DIVISION & FROM ACCOUNT SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow),
		$box = $("<div class='box'/>").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>From</div>").appendTo($box),
		$boxContent = $("<div class='box-content' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'><strong>"+record.division+"</strong></div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$dataCol = $("<div class='data-column full' />").appendTo($dataRow),
		$selectionComponentDiv = $("<div class='selection-display' />").appendTo($dataCol);
		$selectionDetail = $("<div class='selection-display-detail' />").appendTo($selectionComponentDiv),
		$selectionContent = $("<div class='selection-content' />").appendTo($selectionDetail),
		$selectionContentLeft = $("<div class='selection-content-left' />").appendTo($selectionContent),
		$selectionAccountCurrency = $("<div class='selected-account-currency'>"+record.debitcurrency+"</div>").appendTo($selectionContentLeft),
		$selectionAccountName = $("<div class='selected-account-name'>"+record.debitaccountname+"</div>").appendTo($selectionContentLeft),
		$selectionAccountNumber = $("<div class='selected-account-number'>"+record.debitaccountnumber+"</div>").appendTo($selectionContentLeft),
		$selectionContentRight = $("<div class='selection-content-right' />").appendTo($selectionContent),
		$selectionAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectionContentRight),
		$selectionAccountBalanceLabel = $("<div>Available Balance</div>").appendTo($selectionAccountBalance),
		$selectionAccountBalanceValue = $("<div>"+addCommas(record.debitaccount.availablebalance)+"</div>").appendTo($selectionAccountBalance),
		$selectionAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectionContentRight),
		$selectionAccountFundsLabel = $("<div>Available Balance</div>").appendTo($selectionAccountFunds),
		$selectionAccountFundsValue = $("<div>"+addCommas(record.debitaccount.availablefunds)+"</div>").appendTo($selectionAccountFunds),
		$selectionAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectionContentRight),
		$selectionAccountDetailAnchor = $("<a href='#accountdetail' title='View Account Details' id='viewDebitAccountDetailsDialog'><i class='fa fa-info-circle fa-fw'></i></a>").appendTo($selectionAccountDetail).on("click", showDebitAccountDetailsDialog);





	/* PAYMENT METHOD SECTION */
	if (record.type == "Domestic" || record.type == "Domestic Salary" ) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow),
			$box = $("<div class='box'/>").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Payment Method</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow);
			if ( record.debitaccount.bank.country == "China" ) {
				var $data = $("<div class='data-text'>For domestic payments originating in China the Payment Method is selected along with the beneficiary account.</div>").appendTo($dataCol);
			} else if ( record.debitaccount.bank.country == "Australia" ) {
				var $data = $("<input type='radio' name='pymthd' id='pymthd-rtgs' disabled='disabled' class='disabled' checked='checked' />").appendTo($dataCol),
					$labelDesc = $("<label class='desc'>RTGS</label>").appendTo($dataCol),
					data = $("<input type='radio' name='pymthd' id='pymthd-npp' disabled='disabled' class='disabled' />").appendTo($dataCol),
					$labelDesc = $("<label class='desc'>NPP</label>").appendTo($dataCol);
			}
	}


	/* BATCH DETAILS SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Value Date</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.paymentdate + "</div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.name + "</div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Reference</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.batchreference + "</div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Debit Advice Description</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<textarea style='width: 95%; height: 100px;' disabled='disabled' class='disabled' id='viewBatchDescriptionField'>" + record.batchdescription + "</textarea>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Currency</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.paymentcurrency + "</div>").appendTo($dataCol);

	if (record.paymentcurrency != record.debitcurrency) {
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Enter Amounts in Debit Currency</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
			$data = $("<input type='checkbox' id='viewDebitFlag' disabled='disabled' class='disabled' />").appendTo($dataGroup),
			$desc = $("<label class='desc' style='cursor: default;'>Yes</label>").appendTo($dataGroup);
		if (record.debitequivalentflag) {
			$data.prop("checked", true);
		}
	}

	var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Individual Debits</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
		$data = $("<input type='checkbox' id='viewIndividualDebitsFlag' disabled='disabled' class='disabled' />").appendTo($dataGroup),
		$desc = $("<label class='desc' style='cursor: default;'>Yes</label>").appendTo($dataGroup);
	if (record.individualdebitsflag) {
		$data.prop("checked", true);
	}


	/* BENEFICIARIES SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Beneficiaries</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
		$boxDiv = $("<div />").appendTo($boxContent),
		$dataRow = $("<div class='row' />").appendTo($boxDiv),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$div = $("<div style='padding: 0 0 10px 0;' />").appendTo($dataCol);
		$inlineSearch = $("<div class='search-inline-payments' />").appendTo($div),
		$searchDiv = $("<div class='icon-input payment-grid-filter' />").appendTo($inlineSearch),
		$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
		$searchInput = $("<input type='text' placeholder='Search Payment Instructions' />").appendTo($searchDiv),
		$paymentInstructionGrid = $("<div class='payment-grid' id='viewPaymentsGrid' />").appendTo($dataCol),
		$batchTotalsSection = $("<div class='bottom-controls' />").appendTo($dataCol),
		$batchTotalsTable = $("<div class='bottom-control-table' />").appendTo($batchTotalsSection),
		$selectedItemsCount = $("<div class='control-list' style='width: 100%;' />").appendTo($batchTotalsTable),
		$batchTotalControlList = $("<div class='control-list' />").appendTo($batchTotalsTable),
		$batchTotalsDiv = $("<div style='display: inline-block;' />").appendTo($batchTotalControlList),
		$batchTotalsRow = $("<div class='totals-row' />").appendTo($batchTotalsDiv),
		$batchTotalItems = $("<div class='payment-amount-total' id='totalBatchItems' />").appendTo($batchTotalsRow),
		$batchTotalItemCount = $("<div><span>Total Number of Items:</span><span id='NumberOfPayments'>" + record.numberofpayments + "</span></div>").appendTo($batchTotalItems);
	if (record.paymentcurrency != record.debitcurrency) {
		if (record.debitequivalentflag) {
			var $totalPYAmount = $("<div class='payment-amount-total' id='totalBatchPaymentAmount' />").appendTo($batchTotalsRow),
				$totalAmountItem = $("<div><span>Total Payment Amount:</span><span id='TotalPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($totalPYAmount),
				$totalDBAmount = $("<div class='payment-amount-total' id='totalBatchDebitAmount' />").appendTo($batchTotalsRow),
				$totalAmountItem = $("<div><span>Total Debit Amount:</span><span id='TotalDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</span></div>").appendTo($totalDBAmount);
		} else {
			var $totalDBAmount = $("<div class='payment-amount-total' id='totalBatchDebitAmount' />").appendTo($batchTotalsRow),
				$totalAmountItem = $("<div><span>Total Debit Amount:</span><span id='TotalDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</span></div>").appendTo($totalDBAmount),
				$totalPYAmount = $("<div class='payment-amount-total' id='totalBatchPaymentAmount' />").appendTo($batchTotalsRow),
				$totalAmountItem = $("<div><span>Total Payment Amount:</span><span id='TotalPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($totalPYAmount);
		}
	} else {
		var $totalPYAmount = $("<div class='payment-amount-total' id='totalBatchPaymentAmount' />").appendTo($batchTotalsRow),
			$totalAmountItem = $("<div><span>Total Payment Amount:</span><span id='TotalPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($totalPYAmount);
	}
	if ( record.numberofrejectedpayments != 0 ) {
		var $batchTotalRejectedCount = $("<div><span>Rejected Items:</span><span id='numberOfRejectedItems'>" + record.numberofrejectedpayments + "</span></div>").appendTo($batchTotalItems);
		var $batchTotaValidCount = $("<div><span>Valid Items:</span><span id='numberOfValidItems'>" + record.numberofvalidpayments + "</span></div>").appendTo($batchTotalItems);
		var $rejectedPaymentAmount = $("<div><span>Rejected Payment Amount:</span><span id='totalRejectedPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalrejectedpaymentamount) + "</span></div>").appendTo($totalPYAmount);
		var $netPaymentAmount = $("<div><span>Net Payment Amount:</span><span id='netPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.netpaymentamount) + "</span></div>").appendTo($totalPYAmount);		
		if (record.paymentcurrency != record.debitcurrency) {
			var $rejectedDebitAmount = $("<div><span>Rejected Debit Amount:</span><span id='totalRejectedDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totalrejecteddebitamount) + "</span></div>").appendTo($totalDBAmount);
			var $netDebitAmount = $("<div><span>Net Debit Amount:</span><span id='netDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.netdebitamount) + "</span></div>").appendTo($totalDBAmount);	
		}
	}


	/* FX SECTION */
	if ((record.paymentcurrency != record.debitcurrency) && !record.individualdebitsflag) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Rate Type</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + record.ratetype + "</div>").appendTo($dataCol);
		if (record.ratetype == "Carded") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Rate</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.rate + " &nbsp;&nbsp; 1 " + record.fromccy + " &nbsp; = &nbsp; " + (1 * record.rate) + " " + record.toccy + "</div>").appendTo($dataCol);
		} else if (record.ratetype == "Contract") {
			var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
			var _remaining = 0;
			for (var x = 0, y = record.contracts.length; x < y; x++) {
				_remaining = (Number(_remaining) + Number(record.contracts[x].used));
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].reference + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].clientid + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + record.contracts[x].rate + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].used) + "</div>").appendTo($dataTableRow);
			}
			var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
			var _remaining = Number(_remaining).toFixed(2);
			if (record.debitequivalentflag) {
				if (_remaining == removeCommas(record.totaldebitamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totaldebitamount)) {
					var _amt = (Number(removeCommas(record.totaldebitamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totaldebitamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totaldebitamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			} else {
				if (_remaining == removeCommas(record.totalpaymentamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(removeCommas(record.totalpaymentamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totalpaymentamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			}
		}
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' style='padding-top: 0;' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
	}


	/* attach the content */
	$paymentDetailContainer.appendTo($paymentDetailSection);



	/* instruction dialog */
	function triggerInstructionDialog(_target, item) {


		function triggerBeneficiaryAdviceDialog(_target) {
			function downloadReport(_dialog) {
				$("#BeneAdviceReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "")
				}, 3000);
			};

			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}



				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};


			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "BeneAdviceReportDialog",
				title: "Beneficiary Advice",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function triggerDebitAdviceDialog(_target) {
			function downloadReport(_dialog) {
				$("#DebitAdviceReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
				}, 3000);
			};

			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}



				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};

			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "DebitAdviceReportDialog",
				title: "Debit Advice",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function renderPaymentInstructionDetails() {

			var instruction = item;


			function triggerBeneficiaryDialog(_target) {

				function renderBeneficiaryData() {
					var bene = instruction.beneficiary;
					var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewBeneDialog' />");

					/* beneficiary section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Beneficiary Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benename + "</div>").appendTo($dataCol);
					if (bene.benelocalname != "") {
						var $row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Beneficiary Local Language Name</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + bene.benelocalname + "</div>").appendTo($dataCol);
					}
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Number</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneaccount + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Type</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benetype + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress3 + ", " + bene.benepostal + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.benecity + "</div>").appendTo($break),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benecountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>E-mail</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneemail + "</div>").appendTo($dataCol);


					/* bank section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary Bank</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Clearing Code</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Bank Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Branch Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress3 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchcity + "</div>").appendTo($break);

					/* update section
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header-inline'>Update</div>").appendTo($box),
						$boxContent = $("<div class='box-content-inline' />").appendTo($box),
						$dataRow = $("<div class='row' />").appendTo($boxContent),
						$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow),
						$data = $("<input type='checkbox' id='updateAddressBook' />").appendTo($dataCol),
						$desc = $("<label class='desc' for='updateAddressBook'>Update beneficiary details in the Address Book</label>").appendTo($dataCol);
					 */

					return $dialogContent;
				}

				var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
				var _dialog = {
					id: "viewBeneDetails",
					title: "Beneficiary Details",
					size: "xl",
					icon: "<i class='fa fa-book'></i>",
					content: function() {
						return renderBeneficiaryData();
					},
					buttons: [{
						name: "Close",
						icon: "<i class='fa fa-times fa-fw'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								dialogHider(_dialog);
							}
						}]
					}]
				}

				dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			}

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.id + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.status + "</div>").appendTo($dataCol);


			if (instruction.status == "Needs Repair") {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
					$boxDiv = $("<div />").appendTo($boxContent),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>This payment instruction has the following errors:</div>").appendTo($dataCol),
					$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 200px; margin-top: 10px; overflow-y: scroll;' id='errorsGrid' />").appendTo($dataCol),
					$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
				for (var e = 0, f = instruction.errors.length; e < f; e++) {
					var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + instruction.errors[e].description + "</span></li>").appendTo($errorList);
				}
			}


			/* beneficiary section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>To</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Beneficiary</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' />").appendTo($dataCol),
				$link = $("<a href='javacript:void(0)' id='viewBeneDetailTrigger' style='color: #017dba;'>" + instruction.beneficiaryname + " <i class='fa fa-external-link fa-fw' style='vertical-align: middle;'></i></a>").appendTo($data).on("click", function(e) {
					e.preventDefault();
					triggerBeneficiaryDialog($(this))
				}),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.beneficiaryaccountnumber + "</div>").appendTo($dataCol);
			if (instruction.beneficiary.benelocalname != "") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Local Language Name</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.beneficiary.benelocalname + "</div>").appendTo($dataCol);
			}
			if (record.type.indexOf("International") != -1) {
				var bank = instruction.beneficiary.swiftbank,
					bankbranch = instruction.beneficiary.swiftbranch,
					bankcountry = instruction.beneficiary.swiftbankcountry,
					branchaddress1 = instruction.beneficiary.swiftbankaddress1,
					branchaddress2 = instruction.beneficiary.swiftbankaddress2,
					branchaddress3 = instruction.beneficiary.swiftbankaddress3,
					branchpostal = instruction.beneficiary.swiftbankpostal,
					branchcity = instruction.beneficiary.swiftbankcity,
					bankcode = instruction.beneficiary.swiftcode + " (SWIFT)";
			} else {
				var bank = instruction.beneficiary.benebank,
					bankbranch = instruction.beneficiary.benebankbranch,
					bankcountry = instruction.beneficiary.benebankcountry,
					branchaddress1 = instruction.beneficiary.benebankaddress1,
					branchaddress2 = instruction.beneficiary.benebankaddress2,
					branchaddress3 = instruction.beneficiary.benebankaddress3,
					branchpostal = instruction.beneficiary.benebankpostal,
					branchcity = instruction.beneficiary.benebankcity,
					bankcode = instruction.beneficiary.benebankclearingcode + " (" + instruction.beneficiary.benebankclearingtype + ")";
			}
			var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Bank Details</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataGroup),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Clearing</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol);


			/* payment details section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Method</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.paymentmethod + "</div>").appendTo($dataCol),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Date</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentdate + "</div>").appendTo($dataCol);

			if (record.individualdebitsflag) {
				if (record.paymentcurrency != record.debitcurrency) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			} else {
				if (record.debitequivalentflag) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			}


			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Reference</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.paymentreference + "</div>").appendTo($dataCol);

			if (instruction.paymentmethod == "BEPS" || instruction.paymentmethod == "DHVPS" || instruction.paymentmethod == "CBHVPS") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Purpose Code</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.purposecode + "</div>").appendTo($dataCol);
			}

			var $row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Remittance Information</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='max-width: 70%;'>" + instruction.remittanceinformation + "</div>").appendTo($dataCol);

			if ((record.paymentcurrency != record.debitcurrency) && record.individualdebitsflag) {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($dataRow),
					$label = $("<label>Rate Type</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>" + instruction.ratetype + "</div>").appendTo($dataCol);
				if (instruction.ratetype == "Carded") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>Rate</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-text'>" + instruction.rate + " &nbsp;&nbsp; 1 " + instruction.fromccy + " &nbsp; = &nbsp; " + (1 * instruction.rate) + " " + instruction.toccy + "</div>").appendTo($dataCol);
				} else if (instruction.ratetype == "Contract") {
					var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
					var _remaining = 0;
					for (var x = 0, y = instruction.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(instruction.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].reference + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + instruction.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].used) + "</div>").appendTo($dataTableRow);
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					if (record.debitequivalentflag) {
						if (_remaining == instruction.debitequivalentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.debitequivalentamount) {
							var _amt = (Number(instruction.debitequivalentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.debitequivalentamount) {
							var _amt = (Number(_remaining) - Number(instruction.debitequivalentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						if (_remaining == instruction.paymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.paymentamount) {
							var _amt = (Number(instruction.paymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.paymentamount) {
							var _amt = (Number(_remaining) - Number(instruction.paymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}
				}
				var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
			}

			/* supporting documents section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);

			for (var x = 0, y = instruction.supportingdocs.length; x < y; x++) {
				_doc = instruction.supportingdocs[x];
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
			}

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "viewPaymentInstruction",
			title: "Payment Instruction",
			size: "xxl",
			icon: "<i class='fa fa-money'></i>",
			content: function() {
				return renderPaymentInstructionDetails();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Beneficiary Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						triggerBeneficiaryAdviceDialog($(this))
					}
				}],
				cssClass: "primary"
			}, {
				name: "Debit Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						triggerDebitAdviceDialog($(this))
					}
				}],
				cssClass: "primary"
			}]
		}

		if (record.type.indexOf("International") != -1) {
			var mt103 = {
				name: "MT103",
				icon: "<i class='fa fa-download fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog);
					}
				}],
				cssClass: "primary"
			}
			_dialog.buttons.push(mt103)
		}

		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* initialise the view payments grid */
	reviewData = record.payments;
	var reviewItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	reviewDataView = new Slick.Data.DataView({
		reviewItemMetaProvider: reviewItemMetaProvider
	});
	reviewGrid = new Slick.Grid("#viewPaymentsGrid", reviewDataView, reviewColumns, reviewOptions);
	reviewGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	reviewGrid.registerPlugin(reviewItemMetaProvider);
	reviewGrid.onSort.subscribe(function(e, args) {
		reviewDataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	reviewGrid.onClick.subscribe(function(e, args) {
		var cell = reviewGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = reviewDataView.getItem(row);
		triggerInstructionDialog($(e.target), item);
	});
	reviewDataView.beginUpdate();
	reviewDataView.setItems(reviewData);
	reviewDataView.endUpdate();
	reviewGrid.setColumns(reviewColumns);

	$(window).on("resize.reviewgrid", function() {
		reviewGrid.resizeCanvas();
	});
	$(window).on("resize.reviewgrid", _.debounce(function(e) {
		reviewGrid.resizeCanvas();
	}, 100));
}



/**********************************************************************
SEARCHABLE ITEMS
**********************************************************************/
var accounts = [{
	name: "Primary Savings Account",
	number: "113-6677-322",
	currency: "AUD",
	funds: "12,000.00",
	available: "12,000.00",
	balance: "12,000.00"
}, {
	name: "Funding Account Singapore",
	number: "456-8888-125",
	currency: "SGD",
	funds: "32,101.53",
	available: "32,101.53",
	balance: "32,101.53"
}, {
	name: "Loan Repayment Account",
	number: "684-2345-111",
	currency: "SGD",
	funds: "6,130.00",
	available: "6,130.00",
	balance: "6,130.00"
}, {
	name: "Operations Account",
	number: "334-3566-122",
	currency: "AUD",
	funds: "8,456.31",
	available: "8,456.31",
	balance: "8,456.31"
}, {
	name: "Current Account",
	number: "888-3354-355",
	currency: "HKD",
	funds: "17,257.91",
	available: "17,257.91",
	balance: "17,257.91"
}, {
	name: "Funding Account China",
	number: "356-5788-009",
	currency: "HKD",
	funds: "57,774.31",
	available: "57,774.31",
	balance: "57,774.31"
}, {
	name: "India Operations",
	number: "433-3566-123",
	currency: "INR",
	funds: "76,730.00",
	available: "76,730.00",
	balance: "76,730.00"
}, {
	name: "Legal Operations Account",
	number: "112-6578-244",
	currency: "AUD",
	funds: "108,456.31",
	available: "108,456.31",
	balance: "108,456.31"
}, {
	name: "Trade Account",
	number: "333-3555-122",
	currency: "SGD",
	funds: "27,257.31",
	available: "27,257.31",
	balance: "27,257.31"
}, {
	name: "Secondary Savings Account",
	number: "111-1222-245",
	currency: "AUD",
	funds: "207,774.31",
	available: "207,774.31",
	balance: "207,774.31"
}, {
	name: "India Legal",
	number: "344-1678-999",
	currency: "INR",
	funds: "500,000.00",
	available: "500,000.00",
	balance: "500,000.00"
}, {
	name: "India Financing",
	number: "311-3556-133",
	currency: "INR",
	funds: "700,000.00",
	available: "700,000.00",
	balance: "700,000.00"
}, {
	name: "Thai Operations",
	number: "777-3123-663",
	currency: "THB",
	funds: "1,000,000.00",
	available: "1,000,000.00",
	balance: "1,000,000.00"
}, {
	name: "THB Legal",
	number: "334-1456-123",
	currency: "THB",
	funds: "2,632,012.64",
	available: "2,632,012.64",
	balance: "2,632,012.64"
}];

var _currencies = [{
	name: "Australian Dollar",
	number: "AUD"
}, {
	name: "Chinese Renminbi",
	number: "CNY"
}, {
	name: "Hong Kong Dollar",
	number: "HKD"
}, {
	name: "Singapore Dollar",
	number: "SGD"
}, {
	name: "U.S. Dollar",
	number: "USD"
}];


/**********************************************************************
UPDATE THE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='payments-search.html'>Past Payments</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Payment Details");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Past Payments");
	}
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {

	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#paymentSummaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'paymentSearchColumnOrder', 'paymentSearchColumnWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell)
		setupContextMenu();
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedRowStates = [];
		selectedRowWorkflows = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedRowStates.push(item.status);
				selectedRowWorkflows.push(item.workflow);
			}
		}
		if(selectedRowIds.length > 0) {
			$("#pastPaymentSearch .bottom-controls").removeClass("hidden");
			$("#pastPaymentSearch .gutter-30").addClass("has-bottom-controls");
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#pastPaymentSearch .bottom-controls").addClass("hidden");
			$("#pastPaymentSearch .gutter-30").removeClass("has-bottom-controls");
			$("#selectedCount").html('');
		}
		grid.resizeCanvas();
	});
	grid.onClick.subscribe(function(e, args) {
		row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#viewPaymentDetail',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			record = dataView.getItem(row);
			viewPaymentDetails(record);
			grid.setSelectedRows([]);
			selectedRowIds = [];
		}
	});
	grid.onSort.subscribe(function(e, args) {
		dataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('paymentSearchColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('paymentSearchColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i < store.get('paymentSearchColumnOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleAdHocColumns);
	}
	grid.setHeaderRowVisibility(false);

	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));



	/**********************************************************************
							SAVED SEARCH EVENTS
	**********************************************************************/
	$(".manage-searches").on("click", showSearchManagerDialog);
	populateSearches();

	/**********************************************************************
					INITIALIZE SEARCH INDICATORS
	**********************************************************************/
	indicatorSelection();



	/**********************************************************************
					SETUP DEBIT ACCOUNT NUMBER AUTOCOMPLETE
	**********************************************************************/
	var selectize_options = {
		plugins: ['remove_button'],
		maxItems: null,
		maxOptions: 50,
		valueField: 'number',
		labelField: 'name',
		searchField: ['number', 'name'],
		highlight: false,
		hideSelected: true,
		options: accounts,
		render: {
			item: function(item, escape) {
				if (item.name == item.number) return '<div>' + '<span class="name" style="margin-right:0px;">' + escape(item.name) + '</span></div>'
				return '<div>' +
					(item.number ? '<span style="margin-right:8px; font-weight: bold;">' + escape(item.number) + '</span>' : '') +
					(item.name ? '<span>' + escape(item.name) + '</span>' : '') +
					'</div>';
			},
			option: function(item, escape) {
				var label = item.name || item.number;
				var caption = item.name ? item.number : null;
				return '<div>' +
					'<div class="caption" style="font-weight: bold;"">' + escape(caption) + '</div>' +
					(caption ? '<div class="label">' + escape(label) + '</div>' : '') +
					'</div>';
			}
		},
		onItemRemove: function(value) {},
		load: function(query, callback) {},
		persist: false,
		addPrecedence: true,
		openOnFocus: true,
		closeAfterSelect: false,
		create: false,
	};

	var $accountSelectize = $('.account-search').selectize(selectize_options);



	/**********************************************************************
							CURRENCY AUTOCOMPLETE
	**********************************************************************/
	selectize_options.render.item = function(item, escape) {
		return '<div>' +
			'<span style="margin-right:8px;">' + escape(item.number) + '</span>' +
			'</div>';
	}
	selectize_options.render.option = function(item, escape) {
		var label = item.name || item.number;
		var caption = item.name ? item.number : null;
		return '<div>' + '<div class="label" >' + escape(label) + (caption ? ' (' + escape(caption) + ')' : '') + '</div></div>';
	}
	selectize_options.options = _currencies;
	var $currencySelectize = $('.currency-search').selectize(selectize_options);


	/**********************************************************************
							PAYMENT TYPE AUTOCOMPLETE
	**********************************************************************/
	selectize_options.render.item = function(item, escape) {
		return '<div>' + '<span style="margin-right:8px;">' + escape(item.name) + '</span>' + '</div>';
	}
	selectize_options.valueField = 'name';
	selectize_options.searchField = ['name'];
	selectize_options.options = [{
		name: "Domestic"
	}, {
		name: "International"
	}, {
		name: "Transfers"
	}, {
		name: "Domestic Salary"
	}, {
		name: "International Salary"
	}];
	selectize_options.render.option = function(item, escape) {
		var label = item.name;
		return '<div>' + '<div class="label" >' + escape(label) + '</div></div>';
	}
	var $typeSelectize = $('.type-search').selectize(selectize_options);

	/**********************************************************************
							PAYMENT STATUS AUTOCOMPLETE
	**********************************************************************/
	selectize_options.render.item = function(item, escape) {
		return '<div>' + '<span style="margin-right:8px;">' + escape(item.name) + '</span>' + '</div>';
	}
	selectize_options.valueField = 'name';
	selectize_options.searchField = ['name'];
	selectize_options.options = [{
		name: "Bank Rejected"
	}, {
		name: "Completed"
	}, {
		name: "Completed with Errors"
	}];
	selectize_options.render.option = function(item, escape) {
		var label = item.name;
		return '<div>' + '<div class="label" >' + escape(label) + '</div></div>';
	}
	var $statusSelectize = $('.status-search').selectize(selectize_options);


	/**********************************************************************
							DIVISION AUTOCOMPLETE
	**********************************************************************/
	selectize_options.render.item = function(item, escape) {
		return '<div>' + '<span style="margin-right:8px;">' + escape(item.name) + '</span>' + '</div>';
	}
	selectize_options.valueField = 'name';
	selectize_options.searchField = ['name'];
	selectize_options.options = [{
		name: "Customer Division 1"
	}, {
		name: "Customer Division 2"
	}, {
		name: "Customer Division 3"
	}];
	selectize_options.render.option = function(item, escape) {
		var label = item.name;
		return '<div>' + '<div class="label" >' + escape(label) + '</div></div>';
	}
	var $divisionSelectize = $('.division-search').selectize(selectize_options);


	/**********************************************************************
	SEARCH FIELDS
	**********************************************************************/
	$("#show-hide-search").on("click", function(e) {
		e.preventDefault();
		var $this = $(this);
		if ($this.attr("show") == "false") {
			showSearchFields();
		} else {
			hideSearchFields();
		}
	});

	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		}
	});


	/**********************************************************************
							SEARCH FUNCTIONS
	**********************************************************************/
	$(".start-search").click(function(e) {
		e.preventDefault();
		$(".shell").addClass("loading");
		$("#paymentSummaryGrid").addClass("hidden");
		$("#noSearch").show();
		setTimeout(function() {
			$(".shell").removeClass("loading");
			$("#noSearch").hide();
			$("#paymentSummaryGrid").removeClass("hidden");
			hideSearchFields();
		}, 500);
	});

	$(".resetSearch").on("click", function(e) {
		e.preventDefault();
		$("#_noSearch").trigger("click");
	});


	$("#_noSearch").click(function(e) {
		e.preventDefault();
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			$("#paymentSummaryGrid").addClass("hidden");
			$("#noSearch").show();
			clearFormElements("paymentSearchFields");
			$accountSelectize[0].selectize.clearOptions();
			$typeSelectize[0].selectize.clearOptions();
			$statusSelectize[0].selectize.clearOptions();
			$divisionSelectize[0].selectize.clearOptions();
			$currencySelectize[0].selectize.clearOptions();
		}, 500);
	});

	$("#saveNewSearchBtn").on("click", showSaveNewSearchDialog);

	/**********************************************************************
					SETUP THE DATE FUNCTIONS
	**********************************************************************/
	var rollingDates = ["Today", "Yesterday", "Week to Date", "Previous Week", "Month to Date", "Previous Month"];

	$(".valuedaterolling").autocomplete({
		source: rollingDates,
		autoFocus: true,
		delay: 0,
		minLength: 0,
		select: function(e, ui) {
			$(this).autocomplete("close");
		},
		change: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(rollingDates, function() {
				if (this.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this;
					return false;
				}
			});
			$(this).val(matchie);
			if (!valid) {
				$(this).val("");
				return false;
			}
		}
	});

	$(".valuedaterolling").on("focus", function(e) {
		$(this).autocomplete("search", "");
	}).on("click", function(e) {
		$(this).autocomplete("search", "");
	}).on("keydown", function(e) {
		if (e.keyCode == "9") {
			e.stopImmediatePropagation();
		}
	});

	var valuedate = $(".valuedate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});

	var valuedates = $(".valuedatefrom, .valuedateto")
	$(".valuedatefrom").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".valuedateto").datepicker("option", "minDate", selectedDate)
			setTimeout(function() {
				$(".valuedateto").focus()
			}, 50)
		}
	});
	$(".valuedateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".valuedatefrom").datepicker("option", "maxDate", selectedDate)
		}
	});


	/**********************************************************************
						GROUPING INTERACTIONS
	**********************************************************************/
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});

	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});

	/**********************************************************************
						ACTION MENU ITEMS
	**********************************************************************/

	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});

	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	ADD / REMOVE ACCOUNTS MODAL
	**********************************************************************/
	function showAddItems(_target, title, headers, items, SEL_INPUT) {


		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
			if ($("input[name=_addAccount]:checked").length > 0) {
				var ADD_ITEMS = [];
				var checked_items = $("input[name=_addAccount]:checked");

				for (var s = 0; s < checked_items.length; s++) {
					for (var i = s; i < items.length + s; i++) {
						if (i > items.length) i = i - items.length;
						if (items[i].number == checked_items.eq(s).val()) {
							ADD_ITEMS.push(items[i].number);
							break;
						}
					}
				}
				SEL_INPUT[0].selectize.addItems(ADD_ITEMS);
				dialogHider(_dialog);
			} else {
				dialogHider(_dialog);
			}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

			/* build the account filter input */
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Enter search value here...' />").on("keyup", function() {
				if (this.value != '') {
					$("#clearAccountsFilter").show()
				} else {
					$("#clearAccountsFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#AddAccountsFilterInput").val("").trigger("change");
				$(this).hide();
			}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
			$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='_selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=_addAccount]:visible");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv);
		for (var i = 0; i < headers.length; i++) {
			var width = 600 / headers.length;
			if (headers.length > 2) i <= 2 ? width += 20 : width -= 40;
			else i == 0 ? width += 40 : width -= 40;
			$("<div class='fav-header-col' style='width: " + width + "px;'>" + headers[i] + "</div>").appendTo($header);
		}

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
			$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
			$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(items, function() {

			$li = $("<li>").appendTo($ul),
				$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						if ($target.hasClass("fav-data-col")) {
							$target = $target.closest("div.fav-row");
						}
						$target = $target.find("input[name='_addAccount']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='_selectAll']").prop("checked", false)
					}
					if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
						$("input[name='_selectAll']").prop("checked", true)
					}
				}),
				$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
			var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount'/>").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
			});
			for (var i = 0; i < headers.length; i++) {
				var width = 600 / headers.length;
				if (headers.length > 2) i <= 2 ? width += 20 : width -= 40;
				else i == 0 ? width += 40 : width -= 40;
				$("<div class='fav-data-col' style='width: " + width + "px;'>" + (i == 0 ? this.name : (i == 1 ? this.number : this.currency)) + "</div>").appendTo($row);
			}

			if ($.inArray(this.number, SEL_INPUT[0].selectize.items) > -1) {
				$li.remove();
			}
		});

		/* build and show the add accounts dialog */
		var _origin = _target;
		var _dialog = {
			id: "AddAccounts",
			title: title,
			size: "medium",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Add",
				icon: "<i class='fa fa-plus fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						saveSelectedAccounts(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		if (!$("#AddAccountsFilterList").children("li").length) {
			var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}
	}

	$("#showSearchAccountDialog").click(function() {
		showAddItems($(this), "Add Debit Accounts", ["Account Name", "Account Number", "Currency"], accounts, $('.account-search'))
	});

	$("a[data-action='pymdetail']").on("click", showPaymentDetailReportDialog);
	$("a[data-action='pymsummary']").on("click", showPaymentSummaryReportDialog);
	$("[data-action='pymtemplate']").on("click", showPaymentTemplateDialog);

});