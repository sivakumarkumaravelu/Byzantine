/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Accounts Onscreen Guide",
	action: "slider"
}, {
	title: "How do I perform an action on multiple Billing Entities?",
	faq: "<p>Place a tick next to the Billing Entities you want to act on &gt; Right-click to see available actions.</p>"
}, {
	title: "How do I manage my Billing Entities into folders?",
	faq: "<p>Create folders to categorise your billing entities by;<br />&gt; Selecting the Folder menu (the first menu option on the left)<br />&gt; Manage Folders<br />&gt; Enter Name for new folder<br />&gt; Click Add<br />&gt; Click OK.</p><p>Add/Remove Billing Entities from Folders by;<br />&gt; Selecting one or more accounts<br />&gt; Right--click<br />&gt; Move To<br />&gt; Select a folder to add account&#47;s to OR select None to remove the account&#47;s from a folder.</p>"
}, {
	title: "Can the system remember my preferred settings?",
	faq: "<p>By selecting &#39;Remember Settings&#39; from the Action Menu, the application will remember your folder and grouping selections for this screen. </p>"
}, {
	title: "How do I make a screen my Homepage?",
	faq: "<p>&gt; Go to the screen you want to make your home page<br />&gt; Drop down the Settings & Preferences menu (displayed as your User Name on the top right of the screen)<br />&gt; Select &#39;Set this page as my home page&#39;.</p>"
}, {
	title: "How do I customise my view of the Commercial Cards screen?",
	faq: "<p><b>To change the column order:</b><br />&gt; Sort columns by clicking on a column heading.<br />&gt; Drag and drop columns to order them in your preferred sequence.<br />&gt; Right-click on any column heading to set which columns you would like to appear in this screen.</p><p><b>To resize columns:</b><br />&gt; Hover over the column you want to resize and move it until the hand changes to the two arrows pointing away from each other<br />&gt; Left-click and drag to the column width you want</p><p><b>Turn preview mode on/off:</b><br />&gt; Click on your name in the top right of the screen<br />&gt; Select Manage My Preferences<br />&gt; Click the check box next to Enable Preview View<br />&gt; Click Save Changes</p>"
}, {
	title: "How do I perform a search?",
	faq: "<p>&gt; Select your search criteria by clicking on the magnifying glass.<br />&gt; Enter your search parameter in the field and the screen will dynamically display the match results.</p>"
}, {
	title: "How do I download the information on screen?",
	faq: "<p>&gt; Click on the Download icon<br />&gt; Select to Open or Save the file</p>"
}, {
	title: "How do I filter the information on the card summary tab?",
	faq: "<p>&gt; Click on the Active menu item(the first item in the control bar)<br />&gt; Select Card Status menu item&gt; Select a card status<br />&gt; The screen will refresh to display only the cards in the status selected.</p>"
}, {
	title: "How do I group the information on screen?",
	faq: "<p>&gt; Click on the Group menu (second menu item in the control bar)<br />&gt; Select a grouping option</p>"
}, {
	title: "How do I refresh the information on screen?",
	faq: "<p>&gt; Click on the refresh icon (two arrows in a circle)</p>"
}, {
	title: "How do I access the card activity information for a Billing Entity?",
	faq: "<p>&gt; Click on the Billing Entity you want to view<br />Or<br />&gt; Click on the check box next to the Billing Entity you want to view<br />&gt; Click on the Actions menu<br />&gt; Select from the available options:<br />&emsp;&#x25E6; View Card Summary<br />&emsp;&#x25E6; View Account Activity<br />&emsp;&#x25E6; View Outstanding Authorisations<br />&emsp;&#x25E6; View Declined Transactions<br />&emsp;&#x25E6; View Balance Summary<br />&emsp;&#x25E6; Request Statement</p>"
}, {
	title: "How do I access detailed transaction information for a card holder?",
	faq: "<p>&gt; Go to the Account Activity Tab<br />&gt; Click on the line item<br />&gt; The Transaction Details window will appear.<br />&gt; Click the left and right arrows at the top right of the screen to go to the next transaction record.</p>"
}, {
	title: "How do I access an online statement for a Billing Entity?",
	faq: "<p>&gt; Click on the Billing Entity you want to view to open the Card Summary screen<br />&gt; Click View Electonic Statement<br />&gt; Click the statement issue date you want to view<br />or<br/>&gt; Click on the check box next to the Billing Entity you want to view<br />&gt; Click on the Actions menu<br />&gt; Select View Electonic Statement<br />&gt; Click the statement issue date you want to view<br />Or<br />&gt; Right click on the Billing Entity you want to view a statement for<br />&gt; Select View Electronic Statement from the menu<br />&gt; Click the statement issue date you want to view</p><p>To view multiple statements, click on each statement within the pop-up window. Each statement will open as a separate file in your PDF viewing application.</p>"
}, {
	title: "How do I view a card statement for a card holder?",
	faq: "<p>&gt; From the Commercial Card Summary view, click on the Billing Entity you want to view<br />&gt; Right click on the card holder account you want to view and select View Electronic Statement.<br />&gt; From the pop up window select the statement period you wish to view by clicking on the download icon<br />Or<br/>&gt; From the Commercial Card Summary view, click on the Billing Entity you want to view<br />&gt; Click on the check box next to the cardholder account you want to view<br />&gt; Click on the Actions menu and Select View Electronic Statement<br />&gt; From the pop up window select the statement period you wish to view by clicking on the download icon.</p>"
}, {
	title: "How do I save an online statement for a Billing Entity or card statement?",
	faq: "<p>&gt; After opening the electronic statement go to your PDF viewing application and click File<br />&gt; Save As &gt; PDF<br />&gt; Select the location you want to save to and click Save.</p>"
}, {
	title: "How do I raise a service request?",
	faq: "<p>&gt; Right click on the Billing Entity you want to create a new service request for<br />&gt; Select Create new Service Request> the Card Maintenace Requests selection menu will appear<br />or<br/>&gt; Click the menu in the top left of the screen next to the ANZ logo<br />&gt; Click the Service Requests menu option<br />&gt; Click the Commercial Cards menu option&gt; the Commercial Card Service Requests screen will appear.</p><"
}, {
	title: "How do I filter the outstanding authorisations?",
	faq: "<p>&gt; Go to the Outstanding Authorisations Tab<br />&gt; Click on the Date menu (first menu item in the control bar)<br /> &gt; Select a date option </p>"
}, {
	title: "Why are my Service Request options unavailable?",
	faq: "<p><b>Option 1</b> - You have not selected a card to create a new Service Request for:-<br /> &gt; Click on the box next to the card you want to create a Service Request for. A check should appear in the box.<br /> &gt; Click on Actions in the control bar or right click on the record.<br/> &gt; The available options will be active to select from. </p> <p><b>Option 2</b> - The product type does not allow the Service Request type:-<br /> &gt; The ANZ Travel Card does not allow the following Service Request types:<br /> &emsp; &gt; Replace Card<br /> &emsp; &gt; Cancel Card<br /> &emsp; &gt; Card Limit Change<br /> &gt; The ANZ Virtual Card does not allow the following Service Request types:<br /> &emsp; &gt; Replace Card </p>"
}];