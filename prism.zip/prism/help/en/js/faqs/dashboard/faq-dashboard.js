/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Getting Started Onscreen Guide",
	action: "slider"
}, {
	title: "How do I add content to my Workspace?",
	faq: "<p>Click the &#39;Add to Workspace&#39; button &gt; select the image of the content you would like to add.</p><p>The content will be added to the bottom of your workspace.</p><p>You can find out more about the content before you add it by hovering over it and clicking on the information (i) icon.</p>"
}, {
	title: "How do I arrange content on my Workspace?",
	faq: "<p>After you have added content to your workspace, you can drag & drop it into your preferred location. You can also resize the content by dragging the right or bottom edge of the content.</p>"
}, {
	title: "How do I set preferences for my Workspace content?",
	faq: "<p>Most Workspace content can be configured to suit your preferences. Content preferences can be set by clicking on the settings <i class='fa fa-gear fa-fw'></i> icon in the top right hand corner of the content.  Some examples of these preferences are: download settings, showing or hiding additional information, or choosing which accounts to display in the content.</p>"
}, {
	title: "How do I create, rename, delete or change the order of Workspaces?",
	faq: "<p>These actions can be completed by clicking on the Manage Workspaces button to the top right of the screen.</p><p>To create a new Workspace:<br />Enter a name for your new Workspace &gt; click on the Add button or hit enter on your keyboard </p><p>To rename a Workspace: <br />Click on the Workspace name and amend as required</p><p>To delete a Workspace: <br />Click the <i class='fa fa-times fa-fw'></i> next to the Workspace name</p><p>When finished click OK to save your changes.</p>"
}, {
	title: "How do I change the order in which my Workspaces appear?",
	faq: "<p>Click on the Manage Workspaces button  &gt; click on the <i class='fa fa-bars fa-fw'></i> next to a Workspace to drag it into your preferred order &gt; When finished click OK. </p>"
}, {
	title: "How do I access other functionality I am entitled to view (e.g Reporting)?",
	faq: "<p>Click on the menu icon to the top left of the screen to access other functionality available.</p>"
}];