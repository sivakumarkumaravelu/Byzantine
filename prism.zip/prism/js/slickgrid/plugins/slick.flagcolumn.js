(function($) {
    // register namespace
    $.extend(true, window, {
        "Slick": {
            "FlagColumn": FlagColumn
        }
    });

    function FlagColumn(options) {
        var _grid;
        var _dataView;
        var _self = this;
        var _selectedRowsLookup = {};
        var _defaults = {
            columnId: "_flag_column",
            cssClass: null,
            headerCssClass: "flag",
            toolTip: "Payment Alerts",
            visible: true,
            width: 60
        };

        var _options = $.extend(true, {}, _defaults, options);

        function init(grid) {
            _grid = grid;
            _dataView = dataView;
            _grid.onClick.subscribe(handleClick);
        }

        function destroy() {
            _grid.onClick.unsubscribe(handleClick);
        }

        function handleClick(e, args) {
            if (_grid.getColumns()[args.cell].id === _options.columnId) {
                $("#contextMenu").hide();
                var record = _dataView.getItem(args.row);
                if ( record.notices != 0 ) {
                    showPaymentNotificaitonsDialog($(e.target), record);
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                } else {
                    return false;
                }
            }
        }

        function getColumnDefinition() {
            return {
                id: _options.columnId,
                name: "<i class='fa fa-exclamation-triangle fa-fw' style='color: #4D5D65;'></i>",
                toolTip: _options.toolTip,
                field: "notices",
                width: _options.width,
                resizable: false,
                sortable: true,
                visible: true,
                cssClass: _options.cssClass,
                headerCssClass: _options.headerCssClass,
                formatter: flagCellFormatter,
                sorter: "sorterNumeric"
            };
        }

        function flagCellFormatter(row, cell, value, columnDef, dataContext) {
            if ( dataContext.noticeitems.length > 0 ) {
                var hasErrors = false;
                for ( var a = 0, b = dataContext.noticeitems.length; a < b; a++ ) {
                    if (dataContext.noticeitems[a].type == "error") {
                        hasErrors = true;
                        break;
                    }
                }
                if (hasErrors) {
                    return "<i class='fa fa-exclamation-triangle fa-fw' style='color: #DA0000;' title='Click To View Payment Errors and Alerts'></i>";
                } else {
                    return "<i class='fa fa-exclamation-triangle fa-fw' style='color: #e98c3a;' title='Click To View Payment Alerts'></i>";
                }   
            } else {
                return "";
            }
        }

        $.extend(this, {
            "init": init,
            "destroy": destroy,
            "getColumnDefinition": getColumnDefinition
        });
    }
})(jQuery);