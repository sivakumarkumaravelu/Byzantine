/* grid setup */
var data = _tbos_recurring_payments;
var dataView,
	grid,
	record = null,
	selectedRowIds = [],
	selectedRowStates = [],
	selectedRowWorkflows = [],
	columns = [{
		id: "name",
		name: "Beneficiary / Payment Name",
		field: "name",
		width: 250,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "status",
		name: "Status",
		field: "status",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "batchid",
		name: "Payment ID",
		field: "batchid",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "totaldebitamount",
		name: "Debit Amount",
		field: "totaldebitamount",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true,
		cssClass: "num neg",
		headerCssClass: "righted"
	}, {
		id: "debitcurrency",
		name: "Debit Currency",
		field: "debitcurrency",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "debitaccountnumber",
		name: "Debit Account Number",
		field: "debitaccountnumber",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "type",
		name: "Payment Type",
		field: "type",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "totalpaymentamount",
		name: "Payment Amount",
		field: "totalpaymentamount",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true,
		cssClass: "num neg",
		headerCssClass: "righted"
	}, {
		id: "paymentcurrency",
		name: "Payment Currency",
		field: "paymentcurrency",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "numberofpayments",
		name: "No. of Instructions",
		field: "numberofpayments",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}, {
		id: "division",
		name: "Division",
		field: "division",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}];

if (store.get('recurringPaymentSummaryColumnOrder')) {
	columns = store.get('recurringPaymentSummaryColumnOrder');
} else {
	store.set('recurringPaymentSummaryColumnOrder', columns)
}

if (store.get('recurringpaymentSummaryColumnWidths')) {
	var setWidth = store.get('recurringpaymentSummaryColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}

var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());

var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiSelect: true
};

var groupedSetting = 0,
	groupCollapseSetting = 0;

function collapseAllGroups() {
	dataView.beginUpdate();
	for (var i = 0; i < dataView.getGroups().length; i++) {
		if (!dataView.getGroups()[i].collapsed)
			dataView.collapseGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
	dataView.endUpdate();
}

function expandAllGroups() {
	for (var i = 0; i < dataView.getGroups().length; i++) {
		dataView.expandGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
}

function clearGrouping() {
	dataView.groupBy(null);
	groupedSetting = 0;
}

function groupBy(item, text) {
	dataView.groupBy(
		item,
		function(g) {
			return text + ":  " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		function(a, b) {
			var x = a.value
			var y = b.value;
			return (x == y ? 0 : (x > y ? 1 : -1));
		}
	);
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
	grid.scrollRowIntoView(0);
}

var searchString = "",
	statusString = "",
	workflowString = "",
	userString = "",
	searchPoint = "debitaccountnumber";

function myFilter(item, args) {

	if (args.statusString != "" && args.statusString.toLowerCase().indexOf(item["status"].toLowerCase()) == -1)
		return false;

	if (args.workflowString != "" && item["workflow"].toLowerCase().indexOf(args.workflowString.toLowerCase()) == -1)
		return false;

	if (args.userString != "" && item["createdby"].toLowerCase().indexOf(args.userString.toLowerCase()) == -1)
		return false;

	if (searchPoint == "totaldebitamount" || searchPoint == "totalpaymentamount") {
		if (args.searchString != "" && item[searchPoint].replace(/[^\d\.\-\ ]/g, '').indexOf(args.searchString.replace(/[^\d\.\-\ ]/g, '')) == -1)
			return false;
	} else {
		if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1)
			return false;
	}



	return true;
}

function filterPaymentSummaryGrid() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}

function quickFindPayments() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.refresh();
}

function paymentsViewFilter() {
	var rows = grid.getSelectedRows();
	folderString = "";
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	filterPaymentSummaryGrid();
}


/* context menu setup */
function checkStatus(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}

function checkWorkflow(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}

var enableContextItem = function() {
	$(this).children("div.disabled").remove();
	$(this).children("a").show();
};

var disableContextItem = function() {
	if ($(this).children("div.disabled").size()) {
		$(this).children("div.disabled").remove();
	}
	var $a = $(this).children("a"),
		$div = $("<div class='disabled' />"),
		content = $a.html();
	$a.hide();
	$div.html(content).appendTo($(this));
};

function setupContextMenu(record) {
	var sel = selectedRowIds.length,
		$contextItems = $("[data-type='context-item']"),
		statusValue = "",
		workflowValue = "";
	if (record != null) {
		selectedRowStates.push(record.status);
		selectedRowWorkflows.push(record.workflow);
		sel = 1;
	}
	if (!sel) {
		$contextItems.each(disableContextItem);
	} else {
		statusValue = checkStatus(selectedRowStates, "");
		workflowValue = checkWorkflow(selectedRowWorkflows, "");
		if (sel == 1) {
			if (workflowValue == "New") {
				if (statusValue == "Draft" || statusValue == "Approver Rejected") {
					$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='template']").each(enableContextItem);
					$("[data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				} else if (statusValue == "Pending Approval") {
					$("[data-action='view'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				}
			} else if (workflowValue == "Approved") {
				if (statusValue == "Future Dated") {
					$("[data-action='view'], [data-action='copy'], [data-action='delete'], [data-action='template'], [data-action='stop']").each(enableContextItem);
					$("[data-action='edit'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='recall']").each(disableContextItem);
				} else if (statusValue == "Processing") {
					$("[data-action='view'], [data-action='copy'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				} else if (statusValue == "Checking Documents") {
					$("[data-action='view'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				}
			} else if (workflowValue == "Needs Repair") {
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='template']").each(enableContextItem);
				$("[data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
			} else if (workflowValue == "Completed") {
				$("[data-action='copy'], [data-action='template']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
			}
		} else {
			if (statusValue == "Draft" || statusValue == "Approver Rejected" || statusValue == "Needs Repair") {
				$("[data-action='delete'], [data-action='submit']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else if (statusValue == "Pending Approval") {
				$("[data-action='recall'], [data-action='approve'], [data-action='reject']").each(enableContextItem);
				$("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else if (statusValue == "Future Dated") {
				$("[data-action='stop']").each(enableContextItem);
				$("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='template']").each(disableContextItem);
			} else if (!statusValue && (selectedRowStates.indexOf("Draft") > -1 || selectedRowStates.indexOf("Rejected") > -1 || selectedRowStates.indexOf("Needs Repair") > -1) && selectedRowStates.indexOf("Pending Approvel") == -1 && selectedRowStates.indexOf("Processing") == -1 && selectedRowStates.indexOf("Future Dated") == -1) {
				$("[data-action='delete'], [data-action='submit']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else {
				$contextItems.each(disableContextItem);
			}
		}
	}
}

function rejectRecords(dialog) {
	$("#rejectReason").addClass("working");
	var sel = selectedRowIds.length;
	if (!sel || sel == 1) {
		var payment, msg;
		if (record != null) {
			payment = dataView.getItemById(record.id);
		} else {
			payment = data[dataView.getIdxById(selectedRowIds[0])];
		}
		var reloadPaymentGrid = function() {
			payment.rejectedby = "Test User";
			payment.rejectedon = smartDates("today") + " at " + timeFormatter();
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				if (record != null) {
					$("a[data-panel='#paymentsGrid']").trigger("click");
				}
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		payment.status = "Rejected";
		msg = "Approval for payment <strong>" + payment.batchid + "</strong> has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	} else if (sel > 1) {
		var reloadPaymentGrid = function() {
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Rejected";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Approval for selected payment records has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	}
}

function rejectRecordReason(e) {
	e.preventDefault();
	var $target = $(e.target);
	var populateRejectReason = function() {
		var $form = $("<div class='form-section' />");
		var $row = $("<div class='row' />").appendTo($form);
		var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
		var $textarea = $("<textarea style='width: 425px; height: 230px;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
		return $form;
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "rejectReason",
		title: "Enter A Reason For Rejection",
		size: "small",
		icon: "<i class='fa fa-ban'></i>",
		content: function() {
			return populateRejectReason()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					rejectRecords(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#rejectionReasonTextarea").focus();
}

function rejectRecordFromList(e) {
	e.preventDefault();
	var sel = selectedRowIds.length;
	if (sel > 1) {
		buildConfirmDialog("Approval for selected records will be rejected.", "Do you want to continue?", function() {
			rejectRecordReason(e);
		});
	} else {
		rejectRecordReason(e);
	}
}

function recallRecords() {
	$("#paymentsGrid").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#paymentsGrid").removeClass("working");
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#paymentsGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Draft";
		record.recalledby = "Test User";
		record.recalledon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment " + record.batchid + " has been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Draft";
			data[dataView.getIdxById(selectedRowIds[i])].recalledby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].recalledon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected payments have been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	}
}

function recallRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("Payment <strong>" + record.batchid + "</strong> will be recalled and returned to draft status.", "Do you want to continue?", function() {
			recallRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "payments" : "payment";
		buildConfirmDialog("The selected " + rtext + " will be recalled and returned to draft status.", "Do you want to continue?", function() {
			recallRecords();
		});
	}
}

var approvalData = [],
	approvalDataView,
	approvalGrid,
	approvalColumns = [{
		id: "name",
		name: "Beneficiary / Batch Name",
		field: "name",
		width: 250,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "batchid",
		name: "Payment ID",
		field: "batchid",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "totaldebitamount",
		name: "Debit Amount",
		field: "totaldebitamount",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true,
		cssClass: "num neg",
		headerCssClass: "righted"
	}, {
		id: "debitcurrency",
		name: "Debit Currency",
		field: "debitcurrency",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "debitaccountnumber",
		name: "Debit Account Number",
		field: "debitaccountnumber",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "paymentdate",
		name: "Payment Date",
		field: "paymentdate",
		width: 200,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "type",
		name: "Payment Type",
		field: "type",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "numberofpayments",
		name: "No. of Instructions",
		field: "numberofpayments",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}];

var approvalOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiSelect: false
};

function approveRecords(dialog) {
	$("#approvePayments").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#approvePayments").removeClass("working");
			dialogHider(dialog);
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#paymentsGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Processing";
		record.workflow = "Approved";
		record.approvedby = "Test User";
		record.approvedon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment <strong>" + record.batchid + "</strong> has been approved and submitted for processing.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Processing";
			data[dataView.getIdxById(selectedRowIds[i])].workflow = "Approved";
			data[dataView.getIdxById(selectedRowIds[i])].approvedby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].approvedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected payments have been approved and submitted for processing.";
		reloadPaymentGrid();
	}
}

function triggerAuditReportDialog(_target) {

	function downloadReport(_dialog) {
		$("#auditReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "")
		}, 3000);
	};
	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}

		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};
	if (_target) {
		var _origin = _target;
	} else {
		var _origin = $("#generateAuditReportButton");
	}
	var _dialog = {
		id: "auditReportDialog",
		title: "Generate Audit Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function confirmAuditReport() {
	buildConfirmDialog("This will generate audit reports for each of the payments selected for approval. <br /><br />To generate an audit report for a specific payment in this list, right-click the payment and select &quot;Generate Audit Report&quot; from the context menu.", "Generate Audit Reports?", triggerAuditReportDialog);
}

function approveRecordFromList(e) {
	e.preventDefault();
	var $target = $(e.target);
	var populateApprovalDialog = function() {
		var $dialogContent = $("<div style=' height: 100%; box-sizing: border-box; padding: 20px;' />");
		var $approveSummaryGrid = $("<div id='approvalGrid' style='width: 100%; height: 50%; margin-bottom: 20px; border: 1px solid #d9d9d9; border-radius: 4px;' />").appendTo($dialogContent);
		var $noteSection = $("<div id='approvalNote' style='padding: 20px; margin-bottom: 20px; white-space: nowrap; border: 1px solid #d9d9d9; -webkit-border-radius: 4px; -moz-border-radius: 4px; border-radius: 4px;' />").appendTo($dialogContent);
		var $heading = $("<div style='font-size: 24px; color: #334a5e;'>Approve with a Transaction Signature</div>").appendTo($noteSection);
		var $textline1 = $("<div style='font-size: 18px; color: #007dba; margin-top: 15px;'>Your smartcard is required for approval</div>").appendTo($noteSection);
		var $imgline = $("<div class='token-image'></div>").appendTo($noteSection);
		var $textline2 = $("<div style='display: inline-block; vertical-align: top; margin-top: 22px; margin-left: 15px;'>Please click &quot;Approve&quot; and enter your PIN into the pop-up window that opens.<br />Note: Your Smartcard must be connected to your computer.</div>").appendTo($noteSection);
		var $helplink = $("<div style='margin-top: 5px;'><a href='about:blank' target='Security Device Help' style='font-size: 14px; text-decoration: none; color: #007dba;'>Click here for more Security Device help</a></div>").appendTo($textline2);
		return $dialogContent;
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "approvePayments",
		title: "Approve Selected Payments",
		size: "full-screen",
		icon: "<i class='fa fa-check-circle'></i>",
		content: function() {
			return populateApprovalDialog()
		},
		buttons: []
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	var $buttonBar = $("div.dialog-buttons"),
		$div = $("<div style='display: inline-block;' />"),
		$cnclBtnDiv = $("<div style='display: inline-block; vertical-align: middle; margin: 0 5px;' />").appendTo($div),
		$cnclBtn = $("<button style='width: 96px; height: 30px; background: #c0c0c0; cursor: pointer;'>Cancel</button>").appendTo($cnclBtnDiv).on("click", function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}),
		$apprvBtnDiv = $("<div style='display: inline-block; vertical-align: middle; margin: 0 5px;' />").appendTo($div),
		$apprvBtn = $("<button style='width: 96px; height: 30px; background: #c0c0c0; cursor: pointer;'>Approve</button>").appendTo($apprvBtnDiv).on("click", function(e) {
			e.preventDefault();
			approveRecords(_dialog);
		}),
		$auditBtnDiv = $("<div style='display: inline-block; vertical-align: middle; margin: 0 5px;' />").appendTo($div),
		$auditBtn = $("<button style='width: 150px; height: 30px; background: #c0c0c0; cursor: pointer;' id='generateAuditReportButton'>Generate Audit Report</button>").appendTo($auditBtnDiv).on("click", function(e) {
			e.preventDefault();
			confirmAuditReport();
		})
	$div.appendTo($buttonBar);

	approvalData = [];

	if (selectedRowIds.length > 0) {
		for (var i = 0; i < selectedRowIds.length; i++) {
			approvalData.push(data[dataView.getIdxById(selectedRowIds[i])]);
		}
	} else {
		approvalData.push(record);
	}

	setTimeout(function() {
		approvalDataView = new Slick.Data.DataView({});
		approvalGrid = new Slick.Grid("#approvalGrid", approvalDataView, approvalColumns, approvalOptions);
		approvalGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		approvalDataView.setItems(approvalData);
		approvalGrid.setColumns(approvalColumns);
		approvalGrid.onContextMenu.subscribe(function(e, args) {
			e.preventDefault();
			var cell = approvalGrid.getCellFromEvent(e),
				row = cell.row,
				rows = approvalGrid.getSelectedRows(),
				$cmenu = $("#approvalContextMenu");
			var cheight = $cmenu.height(),
				winwidth = $(window).width(),
				winheight = $(window).height(),
				leftpos = e.pageX,
				toppos = e.pageY;
			if (e.pageX + 210 > winwidth) {
				leftpos = e.pageX - 205;
			}
			if (e.pageY + cheight > winheight) {
				toppos = e.pageY - cheight;
				if (toppos < 0) {
					toppos = e.pageY - (cheight - (winheight - e.pageY));
				}
			};
			$(document).off("keyup.hide-context");
			$("body").off("click.hide-context");

			function hideContextMenu() {
				$(".control-menus").children(".control-menu:visible").hide();
				$(".control-list").find(".on").removeClass("on");
				$(".control-menus").find("a.sub-open").removeClass("sub-open");
			}
			hideContextMenu();
			$cmenu.css("top", toppos).css("left", leftpos).css("z-index", 1000).show();
			$(document).on("keyup.hide-context", function(e) {
				if (e.keyCode == 27) {
					hideContextMenu()
				}
			});
			$("body").one("click.hide-context", function() {
				hideContextMenu()
			});
		});
		$(window).bind("resize", function() {
			approvalGrid.resizeAndRender();
		});
		$(window).on("resize", _.debounce(function(e) {
			approvalGrid.resizeAndRender();
		}, 100));
	}, 300);
}

function showPaymentNotificaitonsDialog(_target, item) {
	function renderPaymentNotifications() {

		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewAlertsDialog' />");

		/* system information */
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Payment Information</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Payment ID</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + item.batchid + "</div>").appendTo($dataCol),
			$detailCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Beneficiary / Payment Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + item.name + "</div>").appendTo($dataCol),
			$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Status</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + item.status + "</div>").appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Alerts</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>This payment has the following alerts:</div>").appendTo($dataCol),
			$alertGrid = $("<div class='payment-grid' style='height: auto; max-height: 307px; overflow-y: auto;' id='alertsGrid' />").appendTo($dataCol),
			$alertList = $("<ul class='alert-list' />").appendTo($alertGrid);

		for (var a = 0, b = item.noticeitems.length; a < b; a++) {
			var $alertLI = $("<li><span class='alert-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='alert-text'>" + item.noticeitems[a].description + "</span></li>").appendTo($alertList);
		}

		return $dialogContent;
	}
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "viewPaymentAlerts",
		title: "Payment Alerts",
		size: "xwide",
		icon: "<i class='fa fa-exclamation-triangle'></i>",
		content: function() {
			return renderPaymentNotifications();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showPaymentErrorsDialog(_target, item) {
	function renderPaymentErrors() {
		var $dialogContent = $("<div />");
		return $dialogContent;
	}
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "viewPaymentErrors",
		title: "Payment Errors",
		size: "xl",
		icon: "<i class='fa fa-exclamation-triangle'></i>",
		content: function() {
			return renderPaymentErrors();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showPaymentDetailReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#detailReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}


		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "detailReportDialog",
		title: "Payment Detail Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showPaymentSummaryReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#summaryReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}


		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "summaryReportDialog",
		title: "Payment Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showPaymentTrailReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#trailReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}

		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "trailReportDialog",
		title: "Payment Trail Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showBatchLevelDebitAdviceDialog(e) {
	e.preventDefault();

	var dialogGridDataView;
	var dialogGrid;
	var dialogGridData = record.payments;
	var dialogGridColumns = [{
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: false
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 290,
		sortable: false
	}];
	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: amountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: amountFormatter
		}
	}
	dialogGridColumns.push(currencyColumn);
	dialogGridColumns.push(amountColumn);
	var dialogGridCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	dialogGridColumns.unshift(dialogGridCheckboxSelector.getColumnDefinition());
	var dialogGridOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: false,
		multiSelect: true
	};
	var gridNotLoaded = true;

	function downloadReport(_dialog) {
		$("#generateDebitAdvices").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	function renderDialog() {
		var $dialogContent = $("<div class='data-form' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Format</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 70%;' />").appendTo($dataCol),
			$data = $("<select id='reFormat'><option value='CSV'>CSV</option><option value='PDF'>PDF</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='repName' maxlength='30' style='width: 70%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<textarea id='repDescription' style='width: 70%;'></textarea>").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Generate Debit Advices For</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='radio' name='instructionSetting' id='allInst' checked='checked' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").hide();
					dialogGrid.setSelectedRows([]);
					$("#generateDebitAdvices").find("div.dialog-content").css({
						"overflow-y": "auto"
					});
				}
			}),
			$labelDesc = $("<label class='desc' for='allInst'>All Instructions<label>").appendTo($dataCol),
			$data = $("<input type='radio' name='instructionSetting' id='selectInst' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").show();
					$("#generateDebitAdvices").find("div.dialog-content").css({
						"overflow-y": "scroll"
					});

					if (gridNotLoaded == true) {
						/* initialise the dialog grid */
						var dialogGridItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
						dialogGridDataView = new Slick.Data.DataView({
							dialogGridItemMetaProvider: dialogGridItemMetaProvider
						});
						dialogGrid = new Slick.Grid("#dialogGrid", dialogGridDataView, dialogGridColumns, dialogGridOptions);
						dialogGrid.setSelectionModel(new Slick.RowSelectionModel({
							selectActiveRow: false
						}));
						dialogGrid.registerPlugin(dialogGridItemMetaProvider);
						dialogGrid.registerPlugin(dialogGridCheckboxSelector);
						dialogGridDataView.beginUpdate();
						dialogGridDataView.setItems(dialogGridData);
						dialogGridDataView.endUpdate();
						dialogGrid.setColumns(dialogGridColumns);
					}
				}
			}),
			$labelDesc = $("<label class='desc' for='selectInst'>Select Instructions<label>").appendTo($dataCol),
			$selectionSection = $("<div class='py-ui' id='addInstructionSection' style='display: none;' />").appendTo($formSection),
			$row = $("<div class='row' style='padding: 0;' />").appendTo($selectionSection),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
			$searchDiv = $("<div class='icon-input payment-grid-filter' style='width: 40%;' />").appendTo($inlineSearch),
			$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
			$searchInput = $("<input type='text' placeholder='Search Instructions' />").appendTo($searchDiv),
			$gridDiv = $("<div id='dialogGrid' style='border: 1px solid #cdcdcd; width: 100%; height: 350px; overflow: hidden; border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);

	var _dialog = {
		id: "generateDebitAdvices",
		title: "Generate Debit Advices",
		size: "large",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderDialog();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showBatchLevelBeneAdviceDialog(e) {
	e.preventDefault();

	var dialogGridDataView;
	var dialogGrid;
	var dialogGridData = record.payments;
	var dialogGridColumns = [{
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: false
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 290,
		sortable: false
	}];
	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: amountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: amountFormatter
		}
	}
	dialogGridColumns.push(currencyColumn);
	dialogGridColumns.push(amountColumn);
	var dialogGridCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	dialogGridColumns.unshift(dialogGridCheckboxSelector.getColumnDefinition());
	var dialogGridOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: false,
		multiSelect: true
	};
	var gridNotLoaded = true;

	function downloadReport(_dialog) {
		$("#generateBeneficiaryAdvices").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	function renderDialog() {
		var $dialogContent = $("<div class='data-form' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Format</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 70%;' />").appendTo($dataCol),
			$data = $("<select id='reFormat'><option value='CSV'>CSV</option><option value='PDF'>PDF</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='repName' maxlength='30' style='width: 70%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<textarea id='repDescription' style='width: 70%;'></textarea>").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Generate Beneficiary Advices For</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='radio' name='instructionSetting' id='allInst' checked='checked' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").hide();
					dialogGrid.setSelectedRows([]);
					$("#generateBeneficiaryAdvices").find("div.dialog-content").css({
						"overflow-y": "auto"
					});
				}
			}),
			$labelDesc = $("<label class='desc' for='allInst'>All Instructions<label>").appendTo($dataCol),
			$data = $("<input type='radio' name='instructionSetting' id='selectInst' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").show();
					$("#generateBeneficiaryAdvices").find("div.dialog-content").css({
						"overflow-y": "scroll"
					});

					if (gridNotLoaded == true) {
						/* initialise the dialog grid */
						var dialogGridItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
						dialogGridDataView = new Slick.Data.DataView({
							dialogGridItemMetaProvider: dialogGridItemMetaProvider
						});
						dialogGrid = new Slick.Grid("#dialogGrid", dialogGridDataView, dialogGridColumns, dialogGridOptions);
						dialogGrid.setSelectionModel(new Slick.RowSelectionModel({
							selectActiveRow: false
						}));
						dialogGrid.registerPlugin(dialogGridItemMetaProvider);
						dialogGrid.registerPlugin(dialogGridCheckboxSelector);
						dialogGridDataView.beginUpdate();
						dialogGridDataView.setItems(dialogGridData);
						dialogGridDataView.endUpdate();
						dialogGrid.setColumns(dialogGridColumns);
					}
				}
			}),
			$labelDesc = $("<label class='desc' for='selectInst'>Select Instructions<label>").appendTo($dataCol),
			$selectionSection = $("<div class='py-ui' id='addInstructionSection' style='display: none;' />").appendTo($formSection),
			$row = $("<div class='row' style='padding: 0;' />").appendTo($selectionSection),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
			$searchDiv = $("<div class='icon-input payment-grid-filter' style='width: 40%;' />").appendTo($inlineSearch),
			$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
			$searchInput = $("<input type='text' placeholder='Search Instructions' />").appendTo($searchDiv),
			$gridDiv = $("<div id='dialogGrid' style='border: 1px solid #cdcdcd; width: 100%; height: 350px; overflow: hidden; border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);

	var _dialog = {
		id: "generateBeneficiaryAdvices",
		title: "Generate Beneficiary Advices",
		size: "large",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderDialog();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showPaymentTemplateDialog(e) {
	e.preventDefault();



	function confirmTemplateCreation(_dialog) {
		$("#createTemplateDialog").addClass("working");
		setTimeout(function() {
			buildCustomDialog([{
				text: "Template Name: " + $("#templateName").val(),
				style: "color: #007dba; font-weight: bold;"
			}, {
				text: "Payment template has been successfully created.",
				style: ""
			}], [{
				title: "Ok",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
				}
			}, {
				title: "View This Template",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
					setTimeout(function() {
						document.location.href = "payments-templates.html#detail";
					}, 500);
				}
			}]);
			dialogHider(_dialog);
		}, 1000);
	}


	var populateTemplateCreationDialog = function() {
		var $dialogContent = $("<div class='data-form top-label' id='templateDialogContent' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row mandatory' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateName' style='width: 90%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateDesc' style='width: 90%;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "createTemplateDialog",
		title: "Create A Template From This Payment",
		size: "xsmall",
		icon: "<i class='fa fa-clipboard'></i>",
		content: function() {
			return populateTemplateCreationDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					confirmTemplateCreation(_dialog)
				}
			}],
			attributes: [{
				name: "id",
				value: "createTemplateButton"
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#templateName").focus();
}

function showAuditHistoryDialog(e) {
	e.preventDefault();


	var destroyAuditGrid = function() {
		if (typeof(auditGrid) != 'undefined' && auditGrid != null) {
			auditGrid.destroy();
			$(window).off('resize.auditgrid');
		}
	}

	var loadRecordAuditTable = function() {
		$("#auditHistoryDilaog").addClass("loading");

		setTimeout(function() {
			var auditData = record.audit;
			var $auditGrid = $("<div class='panel' id='auditGrid' style='top: 0;' />").appendTo($("#auditGridContainer"));
			var auditColumns = [{
				id: "action",
				name: "Action",
				field: "action",
				width: 500,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}, {
				id: "by",
				name: "User",
				field: "by",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}, {
				id: "datetime",
				name: "Date / Time",
				field: "datetime",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}];
			var auditOptions = {
				enableCellNavigation: false,
				enableColumnReorder: false,
				syncColumnCellResize: false,
				forceFitColumns: false,
				multiSelect: false,
				multiColumnSort: true
			};

			if (store.get('auditColumnOrder')) {
				auditColumns = store.get('auditColumnOrder');
			} else {
				store.set('auditColumnOrder', auditColumns)
			}

			if (store.get('auditColumnWidths')) {
				var setWidth = store.get('auditColumnWidths');
				for (var i in setWidth) {
					var s = setWidth[i]
					for (c = 0; c < auditColumns.length; c++) {
						if (s.id == auditColumns[c].id) {
							auditColumns[c].width = s.width
						}
					}
				}
			}

			var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
			var auditDataView = new Slick.Data.DataView({
				groupItemMetadataProvider: groupItemMetadataProvider
			});
			auditGrid = new Slick.Grid($auditGrid, auditDataView, auditColumns, auditOptions);
			auditGrid.registerPlugin(groupItemMetadataProvider);
			var auditColumnpicker = new Slick.Controls.ColumnPicker(auditColumns, auditGrid, auditOptions, 'auditColumnOrder', 'auditColumnWidths');
			auditGrid.setSelectionModel(new Slick.RowSelectionModel({
				selectActiveRow: true
			}));
			auditGrid.onSelectedRowsChanged.subscribe(function(e, args) {
				var rows = auditGrid.getSelectedRows();
				for (var i = 0, l = rows.length; i < l; i++) {
					var item = auditDataView.getItem(rows[i])
				}
			});
			auditGrid.onClick.subscribe(function(e, args) {
				var cell = auditGrid.getCellFromEvent(e);
				var row = cell.row;
			});
			auditGrid.onDblClick.subscribe(function(e, args) {
				var cell = auditGrid.getCellFromEvent(e);
				var row = cell.row;
			});
			auditGrid.onKeyDown.subscribe(function(e, args) {
				if (e.which == 13) {
					if (auditGrid.getActiveCell()) {
						var row = auditGrid.getActiveCell().row;
					}
				}
			});
			auditGrid.onSort.subscribe(function(e, args) {
				auditDataView.sort(function(dataRow1, dataRow2) {
					sortdir = args.sortAsc ? 1 : -1;
					sortcol = args.sortCol.field;
					var _sorter = args.sortCol.sorter,
						result;
					if (_sorter == "sorterStringCompare") {
						result = sorterStringCompare(dataRow1, dataRow2);
					} else if (_sorter == "sorterNumeric") {
						result = sorterNumeric(dataRow1, dataRow2);
					} else if (_sorter == "sorterDateIso") {
						result = sorterDateIso(dataRow1, dataRow2);
					} else if (_sorter == "sorterTime") {
						result = sorterTime(dataRow1, dataRow2);
					}
					if (result != 0) {
						return result;
					}
				});
				args.grid.invalidateAllRows();
				args.grid.render();
			});
			auditGrid.onColumnsReordered.subscribe(function(e, args) {
				store.set('auditColumnOrder', auditColumns);
			});

			auditGrid.onColumnsResized.subscribe(function(e, args) {
				store.set('auditColumnWidths', auditGrid.getColumns());
			});
			auditDataView.onRowCountChanged.subscribe(function(e, args) {
				auditGrid.updateRowCount();
				auditGrid.render();
			});
			auditDataView.onRowsChanged.subscribe(function(e, args) {
				auditGrid.invalidateRows(args.rows);
				auditGrid.render();
			});
			auditDataView.beginUpdate();
			auditDataView.setItems(auditData);
			auditDataView.endUpdate();


			auditGrid.setColumns(auditColumns);

			if (store.get('auditColumnOrder')) {
				var visibleAdHocColumns = [];
				for (var i = 0; i < store.get('auditColumnOrder').length; i++) {
					if (auditColumns[i].visible) {
						visibleAdHocColumns.push(auditColumns[i])
					}
				}
				auditGrid.setColumns(visibleAdHocColumns);
			}

			$(window).on('resize.auditgrid', function() {
				auditGrid.resizeAndRender();
			});

			$("#auditHistoryDilaog").removeClass("loading");
			auditGrid.resizeAndRender();
		}, 1000);
	}

	var populateAuditDialog = function() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditHistoryDialogContent' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Audit Information</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$row = $("<div class='row' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($row);

		var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
			$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
			$dataTableCell = $("<div class='data-table-cell' style='width: 50%;'>Action</div>").appendTo($dataTableRow),
			$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>User</div>").appendTo($dataTableRow),
			$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Date / Time</div>").appendTo($dataTableRow);

		for (var i = 0, l = record.audit.length; i < l; i++) {
			var _aud = record.audit[i],
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);


			if (_aud.action == "Modified") {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'/>").appendTo($dataTableRow);
				var $link = $("<a href='javascript:void(0)' style='text-decoration: none;' data-id='" + _aud.id + "'><span style='margin-right: 5px; vertical-align: middle;'>" + _aud.description + "</span><i class='fa fa-external-link fa-fw'></i></a>").appendTo($dataTableCell).on("click", function(e) {
					e.preventDefault();

					var aID = $(this).attr("data-id");

					var auditItem = _.find(record.audit, function(o) {
						return o.id == aID;
					})

					var populateAuditDetailDialog = function() {
						var $auditDialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditDetailDialog' />");

						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Audit Details</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Payment ID</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.record + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.by + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Date / Time</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.datetime + "</div>").appendTo($dataCol);


						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Changed Values</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$dataCol = $("<div class='data-column' />").appendTo($row);

						var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
							$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Field</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Old Value</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>New Value</div>").appendTo($dataTableRow);

						for (var a = 0, b = auditItem.fields.length; a < b; a++) {
							var _field = auditItem.fields[a];
							var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>" + _field.label + "</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>" + _field.from + "</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>" + _field.to + "</div>").appendTo($dataTableRow);
						}


						return $auditDialogContent;
					}

					var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
					var _dialog = {
						id: "auditRecordDetails",
						title: "Audit Details",
						size: "xl",
						icon: "<i class='fa fa-info-circle'></i>",
						content: function() {
							return populateAuditDetailDialog()
						},
						buttons: [{
							name: "Close",
							icon: "<i class='fa fa-times-circle fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog)
								}
							}]
						}]
					}
					dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
				});
			} else if (_aud.action == "Rejected") {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'>" + _aud.description + "</div>").appendTo($dataTableRow),
					$comment = $("<div style='line-height: normal; white-space: normal; padding: 10px 10px 10px 0; width: 175%;'><em>" + _aud.comment + "</em></div>").appendTo($dataTableCell);

			} else {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'>" + _aud.description + "</div>").appendTo($dataTableRow);
			}
			var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.by + "</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.datetime + "</div>").appendTo($dataTableRow);

		}



		/* var $auditGridContainer = $("<div id='auditGridContainer' class='panel' style='top: 0;' />").appendTo($dialogContent); */
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "auditHistoryDilaog",
		title: "View Audit History",
		size: "xxl",
		icon: "<i class='fa fa-calendar'></i>",
		content: function() {
			return populateAuditDialog()
		},
		hasgrid: function() {
			return destroyAuditGrid()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Audit Report",
			icon: "<i class='fa fa-file-text fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	/* loadRecordAuditTable(); 	*/
}

function viewPaymentDetails(record) {


	var showDebitDescriptionDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderBatchDescriptionDialog() {
			var $dialogContent = $("<div class='py-ui' />"),
				$row = $("<div class='row' />").appendTo($dialogContent),
				$dataCol = $("<div class='data-column full' />").appendTo($row),
				$data = $("<textarea style='width: 95%; height: 150px;' disabled='disabled' class='disabled' id='viewBatchDescriptionField'>" + record.batchdescription + "</textarea>").appendTo($dataCol);
			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Advice Description",
			size: "xsmall",
			icon: "<i class='fa fa-edit'></i>",
			content: function() {
				return renderBatchDescriptionDialog();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var showDebitAccountDetailsDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderDebitAccountInformation() {
			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />"),
				$box = $("<div class='box' />").appendTo($dialogContent),
				$boxHeader = $("<div class='box-header'>Account Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Account Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.name + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Debit Account</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.number + " (" + record.debitaccount.currency.code + ")</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Branch Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.name + " " + record.debitaccount.bank.branch + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Address</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$inputGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address1 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address2 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address3 + "</div>").appendTo($inputGroup),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Country</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.country + "</div>").appendTo($dataCol);

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Account Information",
			size: "large",
			icon: "<i class='fa fa-external-link'></i>",
			content: function() {
				return renderDebitAccountInformation();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* setup the review grid */
	var reviewDataView;
	var reviewGrid;
	var reviewData = [];
	var reviewColumns = [{
		id: "number",
		name: "#",
		field: "number",
		toolTip: "Item Number",
		width: 50,
		sortable: true,
		sorter: "sorterStringCompare",
		resizable: false
	}, {
		id: "validated",
		name: "<i class='fa fa-check-circle fa-fw' style='color: #009900;'></i>",
		field: "validated",
		toolTip: "Payment Validation",
		width: 60,
		headerCssClass: "centered",
		cssClass: "centered",
		sortable: false,
		resizable: false,
		formatter: validatedIconFormatter
	}, {
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryaccountnumber",
		name: "Account",
		field: "beneficiaryaccountnumber",
		toolTip: "Beneficiary Account",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "status",
		name: "Status",
		field: "status",
		toolTip: "Status",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}];

	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			formatter: amountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			formatter: amountFormatter
		}
	}
	reviewColumns.push(currencyColumn);
	reviewColumns.push(amountColumn);

	var reviewOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};

	var $paymentDetailSection = $("#paymentDetailScreen");

	/* view payment section */
	var $paymentDetailContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; bottom: 60px; background: #f7f7f7;' id='viewPaymentContent' />");

	/* page title */
	var $pageTitle = $("<div class='page-section' />").appendTo($paymentDetailContainer),
		$titleSpan = $("<span>" + record.type + " Payment</span>").appendTo($pageTitle);

	/* detail section */
	var $paymentDataSection = $("<div class='grid-layout' />").appendTo($paymentDetailContainer);

	/* system information */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Information</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment ID</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.batchid + "</div>").appendTo($dataCol);
	if (record.notices) {
		var $data = $("<div class='data-text' />").appendTo($dataCol),
			$link = $("<a href='javascript:void(0)' title='Click To View Payment Alerts'><i class='fa fa-exclamation-triangle fa-fw'></i></a>").appendTo($data).on("click", function(e) {
				e.preventDefault();
				showPaymentNotificaitonsDialog($(this), record);
			});
	}
	var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Status</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.status + "</div>").appendTo($dataCol);
	if (record.filereference) {
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>File</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + record.filereference + "</div>").appendTo($dataCol);
	}
	if (record.status == "Needs Repair") {
		function dynamicSort(property) {
			var sortOrder = 1;
			if (property[0] === "-") {
				sortOrder = -1;
				property = property.substr(1);
			}
			return function(a, b) {
				var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
				return result * sortOrder;
			}
		}
		record.errors.sort(dynamicSort("type")).reverse();
		var _haserrors = false;
		for (var e = 0, f = record.errors.length; e < f; e++) {
			if (record.errors[e].type == "error") {
				_haserrors = true;
				break;
			}
		}
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		if (_haserrors) {
			var $box = $("<div class='box error' />").appendTo($sectionCell);
		} else {
			var $box = $("<div class='box alert' />").appendTo($sectionCell);
		}
		var $boxHeader = $("<div class='box-header'>Errors and Alerts</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow);
		if (_haserrors) {
			var $data = $("<div class='data-text'>This payment has the following errors:</div>").appendTo($dataCol);
		} else {
			var $data = $("<div class='data-text'>This payment has the following alerts:</div>").appendTo($dataCol);
		}
		var $errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 307px; overflow-y: auto;' id='errorsGrid' />").appendTo($dataCol),
			$errorList = $("<ul class='error-list' />").appendTo($errorGrid);

		for (var e = 0, f = record.errors.length; e < f; e++) {
			var _class = (record.errors[e].type == "error") ? "error-icon" : "alert-icon";
			var $errorLi = $("<li><span class='" + _class + "'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + record.errors[e].description + "</span></li>").appendTo($errorList);
		}
	}

	/* division section */
	var $divisionSection = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($divisionSection),
		$sectionBox = $("<div class='box' />").appendTo($sectionCell),
		$sectionInlineHeader = $("<div class='box-header-inline'>Division</div>").appendTo($sectionBox),
		$sectionInlineContent = $("<div class='box-content-inline' />").appendTo($sectionBox),
		$row = $("<div class='row' />").appendTo($sectionInlineContent),
		$dataCol = $("<div class='data-column' />").appendTo($row),
		$data = $("<div class='data-text' style='padding: 0 5px;'>" + record.division + "</div>").appendTo($dataCol);


	/* details section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell halves' />").appendTo($sectionRow),
		$box = $("<div class='box' style='min-height: 250px;' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>From</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Debit Account</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' />").appendTo($dataCol),
		$debitAccountLink = $("<a href='javascript:void(0)' id='viewDebitAccountDetailsDialog'>" + record.debitaccountnumber + " - " + record.debitaccountname + " (" + record.debitcurrency + ") <i class='fa fa-external-link fa-fw'></i></a>").appendTo($data).on("click", showDebitAccountDetailsDialog),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Available Balance</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>$" + addCommas(record.debitaccount.availablebalance) + "</div>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Available Funds</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>$" + addCommas(record.debitaccount.availablefunds) + "</div>").appendTo($dataCol);

	var $sectionCell = $("<div class='grid-cell halves' />").appendTo($sectionRow),
		$box = $("<div class='box' style='min-height: 250px;' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.name + "</div>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Reference</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.batchreference + "</div>").appendTo($dataCol),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Value Date</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.paymentdate + "</div>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Currency</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.paymentcurrency + "</div>").appendTo($dataCol),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$dataCol = $("<div class='data-column full' />").appendTo($dataRow),
		$data = $("<div class='data-text' style='padding-top: 5px; margin-bottom: -6px;' />").appendTo($dataCol),
		$descriptionLink = $("<a href='javascript:void(0)'><i class='fa fa-edit fa-fw'></i> View Debit Advice Description</a>").appendTo($data).on("click", showDebitDescriptionDialog);


	/* batch settings */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header-inline'>Payment Preferences</div>").appendTo($box),
		$boxContent = $("<div class='box-content-inline' />").appendTo($box),
		$dataRow = $("<div class='row' />").appendTo($boxContent),
		$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow);
	var $data = $("<input type='checkbox' id='viewIndividualDebitsFlag' disabled='disabled' class='disabled' />").appendTo($dataCol),
		$desc = $("<label class='desc' style='cursor: default;'>Individual Debits</label>").appendTo($dataCol);
	if (record.individualdebitsflag) {
		$data.prop("checked", true);
	}
	if (record.type.indexOf("Domestic") != -1) {
		var $data = $("<input type='checkbox' id='viewUrgentFlag' disabled='disabled' />").appendTo($dataCol),
			$desc = $("<label class='desc' style='cursor: default;'>Urgent</label>").appendTo($dataCol);
		if (record.urgentflag) {
			$data.prop("checked", true);
		}
	}
	if (record.paymentcurrency != record.debitcurrency) {
		var $data = $("<input type='checkbox' id='viewDebitFlag' disabled='disabled' class='disabled' />").appendTo($dataCol),
			$desc = $("<label class='desc' style='cursor: default;'>Use Debit Currency</label>").appendTo($dataCol);
		if (record.debitequivalentflag) {
			$data.prop("checked", true);
		}
	}

	/* payment section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Instructions</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$boxDiv = $("<div />").appendTo($boxContent),
		$dataRow = $("<div class='row' />").appendTo($boxDiv),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
		$searchDiv = $("<div class='icon-input payment-grid-filter' />").appendTo($inlineSearch),
		$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
		$searchInput = $("<input type='text' placeholder='Search Payment Instructions' />").appendTo($searchDiv),
		$paymentInstructionGrid = $("<div class='payment-grid' id='viewPaymentsGrid' />").appendTo($dataCol),
		$totalsDiv = $("<div style='padding: 15px 20px 0 20px;' />").appendTo($boxContent),
		$totalsRow = $("<div class='grid-row' />").appendTo($totalsDiv),
		$totalsCell = $("<div class='grid-cell' style='width: 100%; color: #4a494a; font-size: 14px; text-align: right;' />").appendTo($totalsRow),
		$totalInstructions = $("<div style='display: inline-block; vertical-align: top; margin-right: 25px;'>Number Of Instructions: &nbsp;<strong>" + record.numberofpayments + "</strong></div>").appendTo($totalsCell),
		$totalAmountsDiv = $("<div style='display: inline-block; vertical-align: top;' />").appendTo($totalsCell);
	if (record.paymentcurrency != record.debitcurrency) {
		if (record.debitequivalentflag) {
			var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='display: inline-block; margin-left: 25px;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv);
		} else {
			var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='display: inline-block; margin-left: 25px;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);

		}
	} else {
		var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
	}

	/* fx section */
	if ((record.paymentcurrency != record.debitcurrency) && !record.individualdebitsflag) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Rate Type</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + record.ratetype + "</div>").appendTo($dataCol);
		if (record.ratetype == "Carded") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Rate</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.rate + " &nbsp;&nbsp; 1 " + record.fromccy + " &nbsp; = &nbsp; " + (1 * record.rate) + " " + record.toccy + "</div>").appendTo($dataCol);
		} else if (record.ratetype == "Contract") {
			var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
			var _remaining = 0;
			for (var x = 0, y = record.contracts.length; x < y; x++) {
				_remaining = (Number(_remaining) + Number(record.contracts[x].used));
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].reference + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].clientid + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + record.contracts[x].rate + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].used) + "</div>").appendTo($dataTableRow);
			}
			var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
			var _remaining = Number(_remaining).toFixed(2);
			if (record.debitequivalentflag) {
				if (_remaining == removeCommas(record.totaldebitamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totaldebitamount)) {
					var _amt = (Number(removeCommas(record.totaldebitamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totaldebitamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totaldebitamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			} else {
				if (_remaining == removeCommas(record.totalpaymentamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(removeCommas(record.totalpaymentamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totalpaymentamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			}
		}
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
	}

	/* buttons */
	var $paymentButtonContainer = $("<div style='position: absolute; bottom: 0; right: 0; left: 0; border-top: 1px solid #d7d7d7; text-align: center; white-space: nowrap; padding: 10px 0; overflow: hidden; background: #fff;' />");

	var $closeButton = $("<span class='form-button' id='closeButton' />").appendTo($paymentButtonContainer),
		$closeLink = $("<a href='#paymentsGrid' title='Close Payment' data-panel='#paymentsGrid' data-switch='switch-panels'><i class='fa fa-times-circle fa-fw'></i><span>Close</span></a></span>").appendTo($closeButton).on("click", function(e) {
			record = null;
			reviewGrid = null;
			reviewDataView = null;
			reviewData = [];
			reviewColumns = [];
			$(window).off("resize.reviewgrid");
			$("#viewPaymentContent").remove();
		});

	if (record.status == "Draft" || record.status == "Approver Rejected") {
		var $editButton = $("<span class='form-button primary' id='editButton' />").appendTo($paymentButtonContainer),
			$editLink = $("<a href='javascript:void(0)' title='Edit Payment'><i class='fa fa-edit fa-fw'></i>Edit</a>").appendTo($editButton).on("click", function(e) {
				e.preventDefault();
				$("#paymentDetailScreen").empty().addClass("loading");
				reviewGrid.destroy();
				reviewGrid = null;
				reviewDataView = null;
				reviewData = [];
				reviewColumns = [];
				$(window).off("resize.reviewgrid");
				editPaymentDetails(record);
				setTimeout(function() {
					$("#paymentDetailScreen").removeClass("loading").scrollTop(0);
					if ($(".ie8").size() > 0) {
						var $icons = $(target).find(".fa");
						$icons.addClass("repaint");
						setTimeout(function() {
							$icons.removeClass("repaint")
						}, 1)
					}
				}, 500);
			});
		var $submitButton = $("<span class='form-button primary' id='submitButton' />").appendTo($paymentButtonContainer),
			$submitLink = $("<a href='javascript:void(0)' title='Submit Payment'><i class='fa fa-share fa-fw'></i>Submit</a>").appendTo($submitButton);
		var $deleteButton = $("<span class='form-button primary' id='deleteButton' />").appendTo($paymentButtonContainer),
			$deleteLink = $("<a href='javascript:void(0)' title='Delete Payment'><i class='fa fa-trash-o fa-fw'></i>Delete</a>").appendTo($deleteButton);
	} else if (record.status == "Needs Repair") {
		var $editButton = $("<span class='form-button primary' id='editButton' />").appendTo($paymentButtonContainer),
			$editLink = $("<a href='javascript:void(0)' title='Edit Payment'><i class='fa fa-edit fa-fw'></i>Edit</a>").appendTo($editButton).on("click", function(e) {
				e.preventDefault();
				$("#paymentDetailScreen").empty().addClass("loading");
				reviewGrid.destroy();
				reviewGrid = null;
				reviewDataView = null;
				reviewData = [];
				reviewColumns = [];
				$(window).off("resize.reviewgrid");
				editPaymentDetails(record);
				setTimeout(function() {
					$("#paymentDetailScreen").removeClass("loading").scrollTop(0);
					if ($(".ie8").size() > 0) {
						var $icons = $(target).find(".fa");
						$icons.addClass("repaint");
						setTimeout(function() {
							$icons.removeClass("repaint")
						}, 1)
					}
				}, 500);
			});
		var $deleteButton = $("<span class='form-button primary' id='deleteButton' />").appendTo($paymentButtonContainer),
			$deleteLink = $("<a href='javascript:void(0)' title='Delete Payment'><i class='fa fa-trash-o fa-fw'></i>Delete</a>").appendTo($deleteButton);
	} else if (record.status == "Pending Approval") {
		var $approveButton = $("<span class='form-button primary' id='approveButton' />").appendTo($paymentButtonContainer),
			$approveLink = $("<a href='javascript:void(0)' title='Approve Payment'><i class='fa fa-check-circle fa-fw'></i>Approve</a>").appendTo($approveButton).on("click", approveRecordFromList);
		var $rejectButton = $("<span class='form-button primary' id='rejectButton' />").appendTo($paymentButtonContainer),
			$rejectLink = $("<a href='javascript:void(0)' title='Reject Payment'><i class='fa fa-ban fa-fw'></i>Reject</a>").appendTo($rejectButton).on("click", rejectRecordReason);
		var $recallButton = $("<span class='form-button primary' id='recallButton' />").appendTo($paymentButtonContainer),
			$recallLink = $("<a href='javascript:void(0)' title='Recall Payment'><i class='fa fa-undo fa-fw'></i>Recall</a>").appendTo($recallButton).on("click", recallRecordFromList);
	} else if (record.status == "Future Dated") {
		var $stopButton = $("<span class='form-button primary' id='stopButton' />").appendTo($paymentButtonContainer),
			$stopLink = $("<a href='javascript:void(0)' title='Stop Payment'><i class='fa fa-stop fa-fw'></i>Stop</a>").appendTo($stopButton);
	}


	var $moreButton = $("<span class='form-button has-menu dropup' id='moreButton' />").appendTo($paymentButtonContainer).on("click", controlMenuManager),
		$moreLink = $("<a href='#moreActionsButtonMenu' title='More Actions'><i class='fa fa-ellipsis-v fa-fw'></i>More<i class='fa fa-angle-up fa-fw' style='margin-left: 5px;'></i></a>").appendTo($moreButton);


	/* attach the content */
	$paymentDetailContainer.appendTo($paymentDetailSection);
	$paymentButtonContainer.appendTo($paymentDetailSection);


	/* instruction dialog */
	function triggerInstructionDialog(_target, item) {

		function triggerBeneficiaryAdviceDialog(_target) {
			function downloadReport(_dialog) {
				$("#BeneAdviceReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "")
				}, 3000);
			};

			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Encoding",
					id: "repEncoding",
					type: "select",
					data: [{
						option: "UTF-8",
						value: "UTF-8"
					}, {
						option: "ASCII",
						value: "ASCII"
					}, {
						option: "Unicode",
						value: "Unicode"
					}]
				}, {
					name: "Report Language",
					id: "repLanguage",
					type: "select",
					data: [{
						option: "English",
						value: "English"
					}, {
						option: "Chinese (Simplified)",
						value: "Chinese (Simplified)"
					}, {
						option: "Chinese (Traditional)",
						value: "Chinese (Traditional)"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}
				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};


			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "BeneAdviceReportDialog",
				title: "Beneficiary Advice",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function triggerDebitAdviceDialog(_target) {
			function downloadReport(_dialog) {
				$("#DebitAdviceReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
				}, 3000);
			};

			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Encoding",
					id: "repEncoding",
					type: "select",
					data: [{
						option: "UTF-8",
						value: "UTF-8"
					}, {
						option: "ASCII",
						value: "ASCII"
					}, {
						option: "Unicode",
						value: "Unicode"
					}]
				}, {
					name: "Report Language",
					id: "repLanguage",
					type: "select",
					data: [{
						option: "English",
						value: "English"
					}, {
						option: "Chinese (Simplified)",
						value: "Chinese (Simplified)"
					}, {
						option: "Chinese (Traditional)",
						value: "Chinese (Traditional)"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}



				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};

			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "DebitAdviceReportDialog",
				title: "Debit Advice",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function renderPaymentInstructionDetails() {

			var instruction = item;


			function triggerBeneficiaryDialog(_target) {

				function renderBeneficiaryData() {
					var bene = instruction.beneficiary;
					var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewBeneDialog' />");

					/* beneficiary section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Beneficiary Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benename + "</div>").appendTo($dataCol);
					if (bene.benelocalname != "") {
						var $row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Beneficiary Local Language Name</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + bene.benelocalname + "</div>").appendTo($dataCol);
					}
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Number</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneaccount + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Type</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benetype + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress3 + ", " + bene.benepostal + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.benecity + "</div>").appendTo($break),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benecountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>E-mail</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneemail + "</div>").appendTo($dataCol);


					/* bank section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary Bank</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Clearing Code</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Bank Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Branch Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress3 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchcity + "</div>").appendTo($break);

					/* update section
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header-inline'>Update</div>").appendTo($box),
						$boxContent = $("<div class='box-content-inline' />").appendTo($box),
						$dataRow = $("<div class='row' />").appendTo($boxContent),
						$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow),
						$data = $("<input type='checkbox' id='updateAddressBook' />").appendTo($dataCol),
						$desc = $("<label class='desc' for='updateAddressBook'>Update beneficiary details in the Address Book</label>").appendTo($dataCol);
					 */

					return $dialogContent;
				}

				var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
				var _dialog = {
					id: "viewBeneDetails",
					title: "Beneficiary Details",
					size: "xl",
					icon: "<i class='fa fa-book'></i>",
					content: function() {
						return renderBeneficiaryData();
					},
					buttons: [{
						name: "Close",
						icon: "<i class='fa fa-times fa-fw'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								dialogHider(_dialog);
							}
						}]
					}]
				}

				dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			}

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>System Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.id + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.status + "</div>").appendTo($dataCol);


			if (instruction.status == "Needs Repair") {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box error' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$boxDiv = $("<div />").appendTo($boxContent),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>This payment instruction has the following errors:</div>").appendTo($dataCol),
					$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 200px; overflow-y: scroll;' id='errorsGrid' />").appendTo($dataCol),
					$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
				for (var e = 0, f = instruction.errors.length; e < f; e++) {
					var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + instruction.errors[e].description + "</span></li>").appendTo($errorList);
				}
			}


			/* beneficiary section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>To</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Beneficiary</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' />").appendTo($dataCol),
				$link = $("<a href='javacript:void(0)' id='viewBeneDetailTrigger' style='color: #017dba;'>" + instruction.beneficiaryname + " <i class='fa fa-external-link fa-fw' style='vertical-align: middle;'></i></a>").appendTo($data).on("click", function(e) {
					e.preventDefault();
					triggerBeneficiaryDialog($(this))
				}),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.beneficiaryaccountnumber + "</div>").appendTo($dataCol);
			if (instruction.beneficiary.benelocalname != "") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Local Language Name</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.beneficiary.benelocalname + "</div>").appendTo($dataCol);
			}
			if (record.type.indexOf("International") != -1) {
				var bank = instruction.beneficiary.swiftbank,
					bankbranch = instruction.beneficiary.swiftbranch,
					bankcountry = instruction.beneficiary.swiftbankcountry,
					branchaddress1 = instruction.beneficiary.swiftbankaddress1,
					branchaddress2 = instruction.beneficiary.swiftbankaddress2,
					branchaddress3 = instruction.beneficiary.swiftbankaddress3,
					branchpostal = instruction.beneficiary.swiftbankpostal,
					branchcity = instruction.beneficiary.swiftbankcity,
					bankcode = instruction.beneficiary.swiftcode + " (SWIFT)";
			} else {
				var bank = instruction.beneficiary.benebank,
					bankbranch = instruction.beneficiary.benebankbranch,
					bankcountry = instruction.beneficiary.benebankcountry,
					branchaddress1 = instruction.beneficiary.benebankaddress1,
					branchaddress2 = instruction.beneficiary.benebankaddress2,
					branchaddress3 = instruction.beneficiary.benebankaddress3,
					branchpostal = instruction.beneficiary.benebankpostal,
					branchcity = instruction.beneficiary.benebankcity,
					bankcode = instruction.beneficiary.benebankclearingcode + " (" + instruction.beneficiary.benebankclearingtype + ")";
			}
			var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Bank Details</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataGroup),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Clearing</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol);


			/* payment details section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Method</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.paymentmethod + "</div>").appendTo($dataCol),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Date</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentdate + "</div>").appendTo($dataCol);

			if (record.individualdebitsflag) {
				if (record.paymentcurrency != record.debitcurrency) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			} else {
				if (record.debitequivalentflag) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			}


			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Reference</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.paymentreference + "</div>").appendTo($dataCol);

			if (instruction.paymentmethod == "BEPS" || instruction.paymentmethod == "DHVPS" || instruction.paymentmethod == "CBHVPS") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Purpose Code</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.purposecode + "</div>").appendTo($dataCol);
			}

			var $row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Remittance Information</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='max-width: 70%;'>" + instruction.remittanceinformation + "</div>").appendTo($dataCol);

			if ((record.paymentcurrency != record.debitcurrency) && record.individualdebitsflag) {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($dataRow),
					$label = $("<label>Rate Type</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>" + instruction.ratetype + "</div>").appendTo($dataCol);
				if (instruction.ratetype == "Carded") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>Rate</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-text'>" + instruction.rate + " &nbsp;&nbsp; 1 " + instruction.fromccy + " &nbsp; = &nbsp; " + (1 * instruction.rate) + " " + instruction.toccy + "</div>").appendTo($dataCol);
				} else if (instruction.ratetype == "Contract") {
					var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
					var _remaining = 0;
					for (var x = 0, y = instruction.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(instruction.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].reference + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + instruction.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].used) + "</div>").appendTo($dataTableRow);
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					if (record.debitequivalentflag) {
						if (_remaining == instruction.debitequivalentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.debitequivalentamount) {
							var _amt = (Number(instruction.debitequivalentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.debitequivalentamount) {
							var _amt = (Number(_remaining) - Number(instruction.debitequivalentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						if (_remaining == instruction.paymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.paymentamount) {
							var _amt = (Number(instruction.paymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.paymentamount) {
							var _amt = (Number(_remaining) - Number(instruction.paymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}
				}
				var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
			}

			/* supporting documents section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);

			for (var x = 0, y = instruction.supportingdocs.length; x < y; x++) {
				_doc = instruction.supportingdocs[x];
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
			}

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "viewPaymentInstruction",
			title: "Payment Instruction",
			size: "xxl",
			icon: "<i class='fa fa-money'></i>",
			content: function() {
				return renderPaymentInstructionDetails();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Beneficiary Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						triggerBeneficiaryAdviceDialog($(this))
					}
				}],
				cssClass: "primary"
			}, {
				name: "Debit Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						triggerDebitAdviceDialog($(this))
					}
				}],
				cssClass: "primary"
			}]
		}

		if (record.type.indexOf("International") != -1) {
			var mt103 = {
				name: "MT103",
				icon: "<i class='fa fa-download fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog);
					}
				}],
				cssClass: "primary"
			}
			_dialog.buttons.push(mt103)
		}

		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* initialise the view payments grid */
	reviewData = record.payments;
	var reviewItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	reviewDataView = new Slick.Data.DataView({
		reviewItemMetaProvider: reviewItemMetaProvider
	});
	reviewGrid = new Slick.Grid("#viewPaymentsGrid", reviewDataView, reviewColumns, reviewOptions);
	reviewGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	reviewGrid.registerPlugin(reviewItemMetaProvider);
	reviewGrid.onSort.subscribe(function(e, args) {
		reviewDataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	reviewGrid.onClick.subscribe(function(e, args) {
		var cell = reviewGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = reviewDataView.getItem(row);
		triggerInstructionDialog($(e.target), item);
	});
	reviewDataView.beginUpdate();
	reviewDataView.setItems(reviewData);
	reviewDataView.endUpdate();
	reviewGrid.setColumns(reviewColumns);

	$(window).on("resize.reviewgrid", function() {
		reviewGrid.resizeAndRender();
	});

	$(window).on("resize.reviewgrid", _.debounce(function(e) {
		reviewGrid.resizeAndRender();
	}, 100));
}

function editPaymentDetails(record) {

	var editingRecord = jQuery.extend(true, {}, record);

	/* setup the edit payment grid */
	var editDataView;
	var editGrid;
	var editData = [];
	var editSelectedRowIds = [];
	var editColumns = [{
		id: "number",
		name: "#",
		field: "number",
		toolTip: "Item Number",
		width: 50,
		sortable: true,
		sorter: "sorterStringCompare",
		resizable: false
	}, {
		id: "validated",
		name: "<i class='fa fa-check-circle fa-fw' style='color: #009900;'></i>",
		field: "validated",
		toolTip: "Payment Validation",
		width: 60,
		headerCssClass: "centered",
		cssClass: "centered",
		sortable: false,
		resizable: false,
		formatter: validatedIconFormatter
	}, {
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryaccountnumber",
		name: "Account",
		field: "beneficiaryaccountnumber",
		toolTip: "Beneficiary Account",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "status",
		name: "Status",
		field: "status",
		toolTip: "Status",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare"
	}];

	if (editingRecord.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			formatter: amountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			formatter: amountFormatter
		}
	}
	editColumns.push(currencyColumn);
	editColumns.push(amountColumn);
	var editOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};
	var editCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	editColumns.unshift(editCheckboxSelector.getColumnDefinition());

	var $paymentDetailSection = $("#paymentDetailScreen");

	/* clear payment section */
	$paymentDetailSection.empty();

	/* view payment section */
	var $paymentDetailContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; bottom: 60px; background: #f7f7f7;' id='editPaymentContent' />");

	/* page title */
	var $pageTitle = $("<div class='page-section' />").appendTo($paymentDetailContainer),
		$titleSpan = $("<span>" + editingRecord.type + " Payment</span>").appendTo($pageTitle);

	/* detail section */
	var $paymentDataSection = $("<div class='grid-layout' />").appendTo($paymentDetailContainer);

	/* system information */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Information</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment ID</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + editingRecord.batchid + "</div>").appendTo($dataCol);
	if (editingRecord.notices) {
		var $data = $("<div class='data-text' />").appendTo($dataCol),
			$link = $("<a href='javascript:void(0)' title='Click To View Payment Alerts'><i class='fa fa-exclamation-triangle fa-fw'></i></a>").appendTo($data).on("click", function(e) {
				e.preventDefault();
				showPaymentNotificaitonsDialog($(this), editingRecord);
			});
	}
	var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Status</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + editingRecord.status + "</div>").appendTo($dataCol);

	if (record.filereference) {
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>File</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + record.filereference + "</div>").appendTo($dataCol);
	}

	if (record.status == "Needs Repair") {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box error' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>This payment has the following errors:</div>").appendTo($dataCol),
			$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 307px; overflow-y: auto;' id='errorsGrid' />").appendTo($dataCol),
			$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
		for (var e = 0, f = record.errors.length; e < f; e++) {
			var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + record.errors[e].description + "</span></li>").appendTo($errorList);
		}
	}


	/* division section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header-inline'>Division</div>").appendTo($box),
		$boxContent = $("<div class='box-content-inline' />").appendTo($box),
		$dataRow = $("<div class='row' />").appendTo($boxContent),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$customSelect = $("<div class='custom-select' style='min-width: 300px;' />").appendTo($dataCol),
		$select = $("<select id='divisionSelectInput'><option value='Division ABC'>Division ABC</option><option value='Division 123'>Division 123</option></select>").appendTo($customSelect);

	/* debit account and batch details */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell halves' />").appendTo($sectionRow),
		$box = $("<div class='box' style='height: 250px;' />").appendTo($sectionCell),
		boxHeader = $("<div class='box-header'>From</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Debit Account</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$comboBox = $("<div class='combobox-div' style='width: 85%;' />").appendTo($dataCol),
		$input = $("<input type='text' id='debitAccountInput' value='" + editingRecord.debitaccountnumber + " - " + editingRecord.debitaccountname + " (" + editingRecord.debitcurrency + ")' />").appendTo($comboBox),
		$iconDiv = $("<div class='combobox-icon' />").appendTo($comboBox),
		$icon = $("<i class='fa fa-chevron-down fa-fw'></i>").appendTo($iconDiv),
		$searchLink = $("<a href='javascript:void(0)' id='searchDebitAccountsDialog' title='Find A Debit Account' style='color: #007dba;' />").appendTo($dataCol),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchLink),
		$autoCompleteDiv = $("<div id='debitAccountInputAutoComplete' />").appendTo($dataCol),
		$accountDetailSection = $("<div id='debitAccountDetailSection' />").appendTo($boxContent),
		$detailRow = $("<div class='grid-row' />").appendTo($accountDetailSection),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Available Balance</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' id='debitAccountAvailableBalance'>$" + editingRecord.debitaccountavailablebalance + "</div>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Available Funds</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' id='debitAccountAvailableFunds'>$" + editingRecord.debitaccountavailablefunds + "</div>").appendTo($dataCol),
		$sectionCell = $("<div class='grid-cell halves' />").appendTo($sectionRow),
		$box = $("<div class='box' style='height: 250px;' />").appendTo($sectionCell),
		boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<input type='text' id='batchNameInput' style='width: 85%;' value='" + editingRecord.name + "' />").appendTo($dataCol),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Value Date</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$dateDiv = $("<div class='date-input-div' />").appendTo($dataCol),
		$data = $("<input type='text' id='batchPaymentDateInput' class='date-input' value='" + editingRecord.paymentdate + "' />").appendTo($dateDiv).datepicker({
			dateFormat: 'dd/mm/yy',
			constrainInput: true,
			changeMonth: true,
			changeYear: true,
			duration: 0,
			minDate: 0,
			showOn: "button",
			buttonImage: "img/datepicker-icon.png",
			buttonImageOnly: true,
			buttonText: "Select date",
			beforeShow: function() {
				var widget = $("#paymentDateInput").datepicker("widget");
				widget.appendTo($("#paymentDateCalendar"));
				$("#paymentDateCalendar").show();
			},
			onClose: function() {
				var widget = $("#paymentDateInput").datepicker("widget");
				widget.appendTo($("body"));
			}
		}).mask("99/99/9999", {
			placeholder: "dd/mm/yyyy"
		}),
		$datePickerDiv = $("<div class='date-picker-div' id='batchPaymentDateCalendar' />").appendTo($dateDiv),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Currency</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$customSelect = $("<div class='custom-select'  style='width: 100px;' />").appendTo($dataCol),
		$select = $("<select id='batchPaymentCurrencySelection'><option value=''></option><option value='AUD'>AUD</option><option value='CNY'>CNY</option><option value='HKD'>HKD</option><option value='SGD'>SGD</option></select>").appendTo($customSelect).val(editingRecord.paymentcurrency),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$row = $("<div class='row' />").appendTo($detailCell),
		$dataCol = $("<div class='data-column full' />").appendTo($row),
		$data = $("<div class='data-text' style='padding-top: 5px;' />").appendTo($dataCol),
		$link = $("<a href='javascript:void(0)'><i class='fa fa-edit fa-fw'></i> Edit Debit Advice Description</a>").appendTo($data).on("click", function(e) {
			e.preventDefault();
			showEditBatchDescriptionDialog($(this), editingRecord);
		});

	/* batch settings */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header-inline'>Payment Preferences</div>").appendTo($box),
		$boxContent = $("<div class='box-content-inline' />").appendTo($box),
		$dataRow = $("<div class='row' />").appendTo($boxContent),
		$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow);
	var $data = $("<input type='checkbox' id='individualDebitsFlag' />").appendTo($dataCol),
		$desc = $("<label class='desc' for='individualDebitsFlag'>Individual Debits</label>").appendTo($dataCol);
	if (editingRecord.individualdebitsflag) {
		$data.prop("checked", true);
	}
	if (editingRecord.type.indexOf("International") != -1) {
		var $data = $("<input type='checkbox' id='urgentFlag' />").appendTo($dataCol),
			$desc = $("<label class='desc' for='urgentFlag'>Urgent</label>").appendTo($dataCol);
		if (editingRecord.urgentflag) {
			$data.prop("checked", true);
		}
	}
	if (editingRecord.paymentcurrency != editingRecord.debitcurrency) {
		var $data = $("<input type='checkbox' id='debitFlag' />").appendTo($dataCol),
			$desc = $("<label class='desc' for='debitFlag'>Use Debit Currency</label>").appendTo($dataCol);
		if (editingRecord.debitequivalentflag) {
			$data.prop("checked", true);
		}
	}

	/* payment section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Instructions</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$boxDiv = $("<div />").appendTo($boxContent),
		$dataRow = $("<div class='row' />").appendTo($boxDiv),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
		$addBtn = $("<span class='form-button primary' />").appendTo($inlineSearch),
		$addLink = $("<a href='javascript:void(0)' id='addPaymentsToBatch'><i class='fa fa-plus-square fa-fw'></i>Add</a>").appendTo($addBtn),
		$removeBtn = $("<span class='form-button' />").appendTo($inlineSearch),
		$removeLink = $("<a href='javascript:void(0)' id='removePaymentsFromBatch'><i class='fa fa-trash fa-fw'></i>Remove</a>").appendTo($removeBtn),
		$searchDiv = $("<div class='icon-input payment-grid-filter' />").appendTo($inlineSearch),
		$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
		$searchInput = $("<input type='text' placeholder='Search Payment Instructions' />").appendTo($searchDiv),
		$paymentInstructionGrid = $("<div class='payment-grid' id='editPaymentsGrid' />").appendTo($dataCol),
		$totalsDiv = $("<div style='padding: 15px 20px 0 20px;' />").appendTo($boxContent),
		$totalsRow = $("<div class='grid-row' />").appendTo($totalsDiv),
		$totalsCell = $("<div class='grid-cell' style='width: 100%; color: #4a494a; font-size: 14px; text-align: right;' />").appendTo($totalsRow),
		$totalInstructions = $("<div style='display: inline-block; vertical-align: top; margin-right: 25px;'>Number Of Instructions: &nbsp;<strong>" + editingRecord.numberofpayments + "</strong></div>").appendTo($totalsCell),
		$totalAmountsDiv = $("<div style='display: inline-block; vertical-align: top;' />").appendTo($totalsCell);
	if (editingRecord.paymentcurrency != editingRecord.debitcurrency) {
		if (editingRecord.debitequivalentflag) {
			var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.debitcurrency + " $" + addCommas(editingRecord.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='margin-top: 8px;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.paymentcurrency + " $" + addCommas(editingRecord.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
		} else {
			var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.paymentcurrency + " $" + addCommas(editingRecord.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='margin-top: 8px;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.debitcurrency + " $" + addCommas(editingRecord.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv);
		}
	} else {
		var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.paymentcurrency + " $" + addCommas(editingRecord.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
	}

	/* fx section */
	if ((editingRecord.paymentcurrency != editingRecord.debitcurrency) && !editingRecord.individualdebitsflag) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Rate Type</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$customSelect = $("<div class='custom-select' />").appendTo($dataCol),
			$data = $("<select id='fxSelection'><option value='Carded'>Carded</option><option value='Contract'>Contract</option></select>").appendTo($customSelect).val(editingRecord.ratetype);
		if (editingRecord.ratetype == "Carded") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Rate</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + editingRecord.rate + " &nbsp;&nbsp; 1 " + editingRecord.fromccy + " &nbsp; = &nbsp; " + (1 * editingRecord.rate) + " " + editingRecord.toccy + "</div>").appendTo($dataCol),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
		} else if (editingRecord.ratetype == "Contract") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>&nbsp;</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$searchFXBtn = $("<span class='form-button primary' />").appendTo($dataCol),
				$searchFXLink = $("<a href='javascript:void(0)' id='fxContractSearch'><i class='fa fa-search fa-fw'></i>Find &amp; Add Contracts</a>").appendTo($searchFXBtn),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
			var _remaining = 0;
			for (var x = 0, y = editingRecord.contracts.length; x < y; x++) {
				_remaining = (Number(_remaining) + Number(editingRecord.contracts[x].used));
				var $dataTableRow = $("<div class='data-table-row' data-contract-row='true' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' />").appendTo($dataTableRow),
					$removeLink = $("<a href='javascript:void(0)' data-contract-id='" + editingRecord.contracts[x].id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($dataTableCell),
					$contractSpan = $("<span>" + editingRecord.contracts[x].reference + "</span>").appendTo($dataTableCell),
					$dataTableCell = $("<div class='data-table-cell'>" + editingRecord.contracts[x].clientid + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(editingRecord.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + editingRecord.contracts[x].rate + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;' />").appendTo($dataTableRow),
					$usedInput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + editingRecord.contracts[x].id + "' value='" + addCommas(editingRecord.contracts[x].used) + "' />").appendTo($dataTableCell);
			}
			var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
				$cardedRateCheckbox = $("<input type='checkbox' id='usedCardedRateFlag' class='disabled' disabled='disabled' />").appendTo($dataTableCell),
				$cardedRateLabel = $("<label class='desc disabled' id='useCardedRateFlagLabel' for='usedCardedRateFlag'>Use Carded Rate For Remaining Amount</label>").appendTo($dataTableCell),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
			var _remaining = Number(_remaining).toFixed(2);
			if (editingRecord.debitequivalentflag) {
				if (_remaining == editingRecord.totaldebitamount) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < editingRecord.totaldebitamount) {
					var _amt = (Number(editingRecord.totaldebitamount) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > editingRecord.totaldebitamount) {
					var _amt = (Number(_remaining) - Number(editingRecord.totaldebitamount)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			} else {
				if (_remaining == editingRecord.totalpaymentamount) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < editingRecord.totalpaymentamount) {
					var _amt = (Number(editingRecord.totalpaymentamount) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > editingRecord.totalpaymentamount) {
					var _amt = (Number(_remaining) - Number(editingRecord.totalpaymentamount)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			}
		}
	}

	/* buttons */
	var $paymentButtonContainer = $("<div style='position: absolute; bottom: 0; right: 0; left: 0; border-top: 1px solid #d7d7d7; text-align: center; white-space: nowrap; padding: 10px 0; overflow: hidden; background: #fff;' />");
	var $closeButton = $("<span class='form-button' id='closeButton' />").appendTo($paymentButtonContainer),
		$closeLink = $("<a href='#paymentsGrid' title='Close Payment' data-panel='#paymentsGrid' data-switch='switch-panels'><i class='fa fa-times-circle fa-fw'></i><span>Close</span></a></span>").appendTo($closeButton).on("click", function(e) {
			record = null;
		});
	var $reviewButton = $("<span class='form-button primary' id='submitButton' />").appendTo($paymentButtonContainer),
		$reviewLink = $("<a href='#paymentsGrid' title='Review &amp; Submit Payment' data-panel='#paymentsGrid' data-switch='switch-panels'><i class='fa fa-chevron-circle-right fa-fw'></i><span>Review &amp; Submit</span></a></span>").appendTo($reviewButton).on("click", function(e) {
			record = null;
		});

	/* attach the content */
	$paymentDetailContainer.appendTo($paymentDetailSection);
	$paymentButtonContainer.appendTo($paymentDetailSection);

	var $editOverlay = $("<div class='edit-overlay' />").appendTo($paymentDetailSection);


	/* edit batch description dialog */
	function showEditBatchDescriptionDialog(_target, item) {
		function renderBatchDescriptionDialog() {
			var $dialogContent = $("<div class='py-ui' id='editBatchDescription' />"),
				$row = $("<div class='row' />").appendTo($dialogContent),
				$dataCol = $("<div class='data-column full' />").appendTo($row),
				$data = $("<textarea style='width: 95%; height: 150px;' id='batchDescriptionField'>" + editingRecord.batchdescription + "</textarea>").appendTo($dataCol);
			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Advice Description",
			size: "xsmall",
			icon: "<i class='fa fa-edit'></i>",
			content: function() {
				return renderBatchDescriptionDialog();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog);
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		$("#batchDescriptionField").focus();
	}


	/* instruction dialog */
	function triggerInstructionDialog(_target, item) {
		function renderPaymentInstructionDetails() {

			var instruction = item;

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>System Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.id + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.status + "</div>").appendTo($dataCol);


			if (instruction.status == "Needs Repair") {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box error' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$boxDiv = $("<div />").appendTo($boxContent),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>This payment instruction has the following errors:</div>").appendTo($dataCol),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 200px; overflow-y: scroll;' id='errorsGrid' />").appendTo($dataCol),
					$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
				for (var e = 0, f = instruction.errors.length; e < f; e++) {
					var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + instruction.errors[e].description + "</span></li>").appendTo($errorList);
				}
			}


			/* beneficiary section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>To</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row mandatory' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Beneficiary</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$comboBoxDiv = $("<div class='combobox-div' style='width: 65%;' />").appendTo($dataCol),
				$comboBoxInput = $("<input type='text' value='" + instruction.beneficiaryname + "' id='instBene' placeholder='Type in a beneficiary name or account number' />").appendTo($comboBoxDiv),
				$comboBoxIcon = $("<div class='combobox-icon' id='instBeneControl'><i class='fa fa-chevron-down fa-fw'></i></div>").appendTo($comboBoxDiv),
				$comboBoxSearch = $("<a href='javascript:void(0)' id='instBeneSearch' title='Find a beneficiary' class='form-icon'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.beneficiaryaccountnumber + "</div>").appendTo($dataCol);
			if (instruction.beneficiary.benelocalname != "") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Local Language Name</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.beneficiary.benelocalname + "</div>").appendTo($dataCol);
			}
			if (record.type.indexOf("International") != -1) {
				var bank = instruction.beneficiary.swiftbank,
					bankbranch = instruction.beneficiary.swiftbranch,
					bankcountry = instruction.beneficiary.swiftbankcountry,
					bankcode = instruction.beneficiary.swiftcode + " (SWIFT)";
			} else {
				var bank = instruction.beneficiary.benebank,
					bankbranch = instruction.beneficiary.benebankbranch,
					bankcountry = instruction.beneficiary.benebankcountry,
					bankcode = instruction.beneficiary.benebankclearingcode + " (" + instruction.beneficiary.benebankclearingtype + ")";
			}
			var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Bank Details</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataGroup),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Clearing</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol);


			/* payment details section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row mandatory' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Method</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol),
				$select = $("<select id='instPaymentMethod'><option value=''><option><option value='" + instruction.paymentmethod + "'>" + instruction.paymentmethod + "<option></select>").appendTo($customSelect).val(instruction.paymentmethod),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Date</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentdate + "</div>").appendTo($dataCol);

			if (record.individualdebitsflag) {
				if (record.paymentcurrency != record.debitcurrency) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			} else {
				if (record.debitequivalentflag) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			}


			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row mandatory' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Reference</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<input type='text' style='width: 85%' value='" + instruction.paymentreference + "' id='instPaymentReference' />").appendTo($dataCol);

			if (instruction.paymentmethod == "BEPS" || instruction.paymentmethod == "DHVPS" || instruction.paymentmethod == "CBHVPS") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Purpose Code</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$customSelect = $("<div class='custom-select' />").appendTo($dataCol);
				if (instruction.paymentmethod == "CBHVPS") {
					var $select = $("<select id='instPurposeCode'><option value=''></option><option value='02112 - 货物贸易结算 Goods trade settlement'>02112 - 货物贸易结算 Goods trade settlement</option><option value='02113 - 货物贸易结算退款 Goods trade settlement refund'>02113 - 货物贸易结算退款 Goods trade settlement refund</option><option value='02114 - 服务贸易结算 Service trade settlement'>02114 - 服务贸易结算 Service trade settlement</option><option value='02115 - 服务贸易结算退款 Service trade settlement refund'>02115 - 服务贸易结算退款 Service trade settlement refund</option><option value='02116 - 资本项下跨境支付 X-border pmt under capital acc'>02116 - 资本项下跨境支付 X-border pmt under capital acc</option><option value='02117 - 资本项下跨境支付退款 X-border pmt refund capital'>02117 - 资本项下跨境支付退款 X-border pmt refund capital</option><option value='02125 - 其他经常项目支出 Other current acc transactions'>02125 - 其他经常项目支出 Other current acc transactions</option></select>").appendTo($customSelect).val(instruction.purposecode);

				} else {
					var $select = $("<select id='instPurposeCode'><option value=''></option><option value='02102 - 普通汇兑 Common exchange'>02102 - 普通汇兑 Common exchange</option></select>").appendTo($customSelect).val(instruction.purposecode);
				}
			}
			var $row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Remittance Information</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<textarea style='width: 85%; height: 100px;' id='instRemittance'>" + instruction.remittanceinformation + "</textarea>").appendTo($dataCol);

			if ((record.paymentcurrency != record.debitcurrency) && record.individualdebitsflag) {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($dataRow),
					$label = $("<label>Rate Type</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$customSelect = $("<div class='custom-select' />").appendTo($dataCol),
					$selet = $("<select id='instRateType'><option value='Carded'>Carded</option><option value='Contract'>Contract</option></select>").appendTo($customSelect).val(instruction.ratetype);
				if (instruction.ratetype == "Carded") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>Rate</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-text'>" + instruction.rate + " &nbsp;&nbsp; 1 " + instruction.fromccy + " &nbsp; = &nbsp; " + (1 * instruction.rate) + " " + instruction.toccy + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
				} else
				if (instruction.ratetype == "Contract") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>&nbsp;</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$searchFXBtn = $("<span class='form-button primary' />").appendTo($dataCol),
						$searchFXLink = $("<a href='javascript:void(0)' id='instContractSearch'><i class='fa fa-search fa-fw'></i>Find &amp; Add Contracts</a>").appendTo($searchFXBtn),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
					var _remaining = 0;
					for (var x = 0, y = instruction.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(instruction.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' data-contract-row='true' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' />").appendTo($dataTableRow),
							$removeLink = $("<a href='javascript:void(0)' data-contract-id='" + instruction.contracts[x].id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($dataTableCell),
							$contractSpan = $("<span>" + instruction.contracts[x].reference + "</span>").appendTo($dataTableCell),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + instruction.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;' />").appendTo($dataTableRow),
							$usedInput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + instruction.contracts[x].id + "' value='" + addCommas(instruction.contracts[x].used) + "' />").appendTo($dataTableCell);
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$cardedRateCheckbox = $("<input type='checkbox' id='usedInstructionCardedRateFlag' class='disabled' disabled='disabled' />").appendTo($dataTableCell),
						$cardedRateLabel = $("<label class='desc disabled' id='usedInstructionCardedRateLabel' for='usedInstructionCardedRateFlag'>Use Carded Rate For Remaining Amount</label>").appendTo($dataTableCell),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					if (record.debitequivalentflag) {
						if (_remaining == instruction.debitequivalentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.debitequivalentamount) {
							var _amt = (Number(instruction.debitequivalentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.debitequivalentamount) {
							var _amt = (Number(_remaining) - Number(instruction.debitequivalentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						if (_remaining == instruction.paymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.paymentamount) {
							var _amt = (Number(instruction.paymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.paymentamount) {
							var _amt = (Number(_remaining) - Number(instruction.paymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}

				}
			}

			var uploadSupportingDocumentInteraction = function() {
				$("#progressBar").show();
				$(".progress-meter").animate({
					width: "100%"
				}, 3000, function() {
					$("#progressBar").hide();
					$(".progress-meter").css("width", 0);
					$("#instAttachSupportingDoc").val('');
					var _doc = {
						id: randString(20),
						filename: "SupportingDocument1FileName.pdf",
						filesize: "827kb",
						status: "Performing Virus Scan"
					}
					var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />"),
						$fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
						$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell),
						$documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell),
						$statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "<i class='ellipsis-loader' /></div>").appendTo($dataTableRow);
					$dataTableRow.appendTo($("div[data-supporting-docs='" + instruction.id + "']"));
					var _rand = rand(0, 2);
					if (_rand == 0) {
						setTimeout(function() {
							$documentLink.css("color", "#c91b01");
							$removeLink.css("color", "#c91b01");
							$statusTableCell.empty().html("Virus Scan Failed");
							_doc.status == "Virus Scan Failed";
						}, 4000);
					} else {
						setTimeout(function() {
							$documentLink.remove();
							$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($fileInfoCell);
							$statusTableCell.empty().html("Attached");
							_doc.status == "Attached";
						}, 4000);
					}
				});
			}


			/* supporting documents section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$buttonSpan = $("<span class='form-button primary' id='uploadButton' />").appendTo($dataCol),
				$buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Attach File</a>").appendTo($buttonSpan),
				$fileInput = $("<input type='file' name='file' id='instAttachSupportingDoc' style='position: absolute; left: 30px; padding: 0; width: 155px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($buttonSpan).on('change', uploadSupportingDocumentInteraction),
				$progressDiv = $("<div id='progressBar' style='display: none;' />").appendTo($dataCol),
				$progressBar = $("<div class='progress-bar'></div>").appendTo($progressDiv),
				$progressMeter = $("<div class='progress-meter' />").appendTo($progressBar),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' data-supporting-docs='" + instruction.id + "' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 70%;'>File Name</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Status</div>").appendTo($dataTableRow);

			for (var x = 0, y = instruction.supportingdocs.length; x < y; x++) {
				_doc = instruction.supportingdocs[x];
				var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
					$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($dataTableCell),
					$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($dataTableCell),
					$dataTableCell = $("<div class='data-table-cell'>" + _doc.status + "</div>").appendTo($dataTableRow);
			}

			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editPaymentInstruction",
			title: "Payment Instruction",
			size: "xxl",
			icon: "<i class='fa fa-money'></i>",
			content: function() {
				return renderPaymentInstructionDetails();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}


	/* initialise the view payments grid */
	editData = editingRecord.payments;
	var editItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	editDataView = new Slick.Data.DataView({
		editItemMetaProvider: editItemMetaProvider
	});
	editGrid = new Slick.Grid("#editPaymentsGrid", editDataView, editColumns, editOptions);
	editGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	editGrid.registerPlugin(editItemMetaProvider);
	editGrid.registerPlugin(editCheckboxSelector);
	editGrid.onSort.subscribe(function(e, args) {
		editDataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	editGrid.onClick.subscribe(function(e, args) {
		var cell = editGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = editDataView.getItem(row);
		triggerInstructionDialog($(e.target), item);
	});
	editDataView.beginUpdate();
	editDataView.setItems(editData);
	editDataView.endUpdate();
	editGrid.setColumns(editColumns);


	$(window).on("resize.editgrid", function() {
		editGrid.resizeAndRender();
	});

	$(window).on("resize.editgrid", _.debounce(function(e) {
		editGrid.resizeAndRender();
	}, 100));
}

/* DOCUMENT READY */
$(function() {

	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#recurringPaymentSummaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'recurringPaymentSummaryColumnOrder', 'recurringpaymentSummaryColumnWidths');

	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell)
		setupContextMenu();
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});

	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedRowStates = [];
		selectedRowWorkflows = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedRowStates.push(item.status);
				selectedRowWorkflows.push(item.workflow);
			}
		}
		if (selectedRowIds.length > 0) {
			$("#paymentSummaryGrid").addClass("has-bottom-controls");
			$("#paymentsGrid .bottom-controls").removeClass("hidden");
			$("#selectedCount").html(selectedRowIds.length);
			grid.resizeAndRender();
		} else {
			$("#paymentSummaryGrid").removeClass("has-bottom-controls");
			$("#paymentsGrid .bottom-controls").addClass("hidden");
			$("#selectedCount").html('');
			grid.resizeAndRender();
		}
	});

	grid.onClick.subscribe(function(e, args) {
		row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#paymentDetailScreen',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			record = dataView.getItem(row);
			viewPaymentDetails(record);
			grid.setSelectedRows([]);
			selectedRowIds = [];
		}
	});

	grid.onSort.subscribe(function(e, args) {
		dataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});

	grid.onColumnsReordered.subscribe(function(e, args) {
		store.set('recurringPaymentSummaryColumnOrder', columns.slice(1));
	});

	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('recurringpaymentSummaryColumnWidths', grid.getColumns());
	});

	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});

	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});

	dataView.setItems(data);

	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});

	dataView.setFilter(myFilter);

	grid.setColumns(columns);

	if (store.get('recurringPaymentSummaryColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i < store.get('recurringPaymentSummaryColumnOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		visibleAdHocColumns.unshift(columns[0]);
		grid.setColumns(visibleAdHocColumns);
	}

	$(window).bind("resize", function() {
		grid.resizeAndRender();
	});

	$(window).on("resize", _.debounce(function(e) {
		grid.resizeAndRender();
	}, 100));

	/* view filter functions */
	$("#paymentViewFilter").on("click.filter-view", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set")) {
			var status = $target.attr("data-status"),
				workflow = $target.attr("data-workflow"),
				user = $target.attr("data-user");
			if (!status) {
				statusString = ""
			}
			if (statusString != status) {
				statusString = status
			}
			if (!workflow) {
				workflowString = ""
			}
			if (workflowString != workflow) {
				workflowString = workflow
			}
			if (!user) {
				userString = ""
			}
			if (userString != user) {
				userString = user
			}
			paymentsViewFilter();
		}
	});

	/* grouping menu functions */
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});

	/* action menu functions */
	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});
	$("[data-action='reject']").on("click", rejectRecordFromList);
	$("[data-action='recall']").on("click", recallRecordFromList);
	$("[data-action='approve']").on("click", approveRecordFromList);
	$("[data-action='genereateAuditReport']").on("click", function(e) {
		e.preventDefault();
		triggerAuditReportDialog($(this));
	});


	/* quick find functions */
	$("#quickFindPayments").keyup(function(e) {
		if (e.which == 27) {
			$("#clearSearchCriteria").hide();
			this.value = '';
			this.blur()
		}
		searchString = this.value;
		quickFindPayments();
		if (this.value != "") {
			$("#clearSearchCriteria").show()
		} else {
			$("#clearSearchCriteria").hide()
		}
	});

	$("#findMenu").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var placeholderString = $(this).text(),
			searchString = $(this).attr("data-find");
		if (searchPoint != searchString) {
			$("#quickFindPayments").attr("placeholder", placeholderString);
			searchPoint = searchString;
			$("#quickFindPayments").val('').focus();
			$("#clearSearchCriteria").hide();
			searchString = '';
			quickFindPayments();
		}
	});

	$("#clearSearchCriteria").on("click", function() {
		$("#quickFindPayments").val('');
		$("#quickFindPayments").blur();
		$("#clearSearchCriteria").hide();
		searchString = "";
		quickFindPayments();
	});

	$("a[data-action='pymdetail']").on("click", showPaymentDetailReportDialog);
	$("a[data-action='pymsummary']").on("click", showPaymentSummaryReportDialog);
	$("a[data-action='pymtrail']").on("click", showPaymentTrailReportDialog);
	$("a[data-action='pymtemplate']").on("click", showPaymentTemplateDialog);
	$("a[data-action='pymaudit']").on("click", showAuditHistoryDialog);
	$("a[data-action='gendebadvices").on("click", showBatchLevelDebitAdviceDialog);
	$("a[data-action='genbenadvices").on("click", showBatchLevelBeneAdviceDialog);



	/**********************************************************************
	JUMP TO PAYMENT DETAILS
	**********************************************************************/
	var b = document.location.href.split(".html")[1];

	if (b == "#detail") {
		$("#paymentSummaryGrid").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		document.location.hash = '';
	}


});