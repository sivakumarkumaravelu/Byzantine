/**********************************************************************
USERS GRID
**********************************************************************/
var data = _users;
var dataView;
var grid;
var record = null;
var selectedRowIds = [];
var selectedRowStates = [];
var selectedRowWorkflows = [];
var columnFilters = {};
var columns = [{
	id: "userid",
	name: "User ID",
	field: "userid",
	width: 150,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "firstname",
	name: "First Name",
	field: "firstname",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "surname",
	name: "Surname",
	field: "surname",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "preferredname",
	name: "Preferred Name",
	field: "preferredname",
	width: 155,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true

}, {
	id: "usercredenital",
	name: "User Credentials",
	field: "usercredential",
	width: 150,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "userstatus",
	name: "User Status",
	field: "status",
	width: 150,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "workflow",
	name: "Workflow",
	field: "workflow",
	width: 250,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "country",
	name: "Country",
	field: "country",
	width: 150,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "lastlogin",
	name: "Last Login",
	field: "lastlogin",
	width: 180,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('UsersColumnOrder')) {
	columns = store.get('UsersColumnOrder');
} else {
	store.set('UsersColumnOrder', columns)
}
if (store.get('UsersColumnWidths')) {
	var setWidth = store.get('UsersColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var searchString = ""; 
var statusString = ""; 
var workflowString = ""; 
var managedbyString = ""; 
var searchPoint = "debitaccountnumber";
function myFilter(item, args) {

	if (args.statusString != undefined && args.statusString.toLowerCase().indexOf(item["status"].toLowerCase()) == -1) {
		return false;
	}
	

	if (args.workflowString != undefined && item["workflow"].toLowerCase().indexOf(args.workflowString.toLowerCase()) == -1) {
		
		return false;
	}

	if (args.managedbyString != undefined && item["managedby"].toLowerCase().indexOf(args.managedbyString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterPaymentSummaryGrid() { 
	dataView.refresh();
	grid.invalidate();
	grid.render();
	var length = grid.getData().getPagingInfo().totalRows;
	
	if(length ==0 ){
		 grid.invalidateAllRows();
		$('.grid-canvas').html("<span id='noresults' style='position: relative; top: 50%; left: 45%'>No Record Found</span>");
	}
	else{

		$('#noresults').remove();

	
	}
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function quickFindPayments() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.refresh();
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
function paymentsViewFilter() {
	var rows = grid.getSelectedRows();
	folderString = "";
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	
	if(statusString || workflowString || managedbyString){
		
		dataView.setFilterArgs({
			statusString: statusString,
			workflowString: workflowString,
			managedbyString: managedbyString
			
		});
	}
	else {
		dataView.setFilterArgs({});

	}

	filterPaymentSummaryGrid();
}


/**********************************************************************
CONTEXT MENU
**********************************************************************/
function checkStatus(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
function checkWorkflow(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
var enableContextItem = function() {
	$(this).children("div.disabled").remove();
	$(this).children("a").show();
};
var disableContextItem = function() {
	if ($(this).children("div.disabled").size()) {
		$(this).children("div.disabled").remove();
	}
	var $a = $(this).children("a"),
		$div = $("<div class='disabled' />"),
		content = $a.html();
	$a.hide();
	$div.html(content).appendTo($(this));
};
function setupContextMenu() { 
	var sel = selectedRowIds.length;
	var $contextItems = $("[data-type='context-item']");
	var statusValue = "";
	var workflowValue = "";
	if (record != null) {
		selectedRowStates.push(record.status);
		selectedRowWorkflows.push(record.workflow);
		sel = 1;
	}
	if (!sel) {
		$contextItems.each(disableContextItem);
	} else {
		statusValue = checkStatus(selectedRowStates, "");
		workflowValue = checkWorkflow(selectedRowWorkflows, "");
		if (sel == 1) {
			$("[data-action='view']").each(enableContextItem);
			if (workflowValue == "Approved") {
				$("[data-action='edit'], [data-action='delete'], [data-action='viewaudithistory']").each(enableContextItem);
				if (statusValue == "Active") {
					$("[data-action='disable'],	[data-action='generatepassword']").each(enableContextItem);
					$("[data-action='enable'], [data-action='approve'], [data-action='reject']").each(disableContextItem);
				} else if (statusValue == "Disabled") {
					$("[data-action='enable']").each(enableContextItem);
					$("[data-action='generatepassword'], [data-action='disable'], [data-action='approve'], [data-action='reject']").each(disableContextItem);
				}
			} else {
				$("[data-action='approve'], [data-action='reject'], [data-action='viewaudithistory']").each(enableContextItem);
				$("[data-action='generatepassword'], [data-action='delete'], [data-action='disable'], [data-action='enable'], [data-action='edit']").each(disableContextItem);
			}
		} else {
			$contextItems.each(disableContextItem);
		}
		$("[data-action='contextMenuReports']").each(enableContextItem);
	}
}


/**********************************************************************
DELETE
**********************************************************************/
function deleteRecords() {
	var $shell = $(".shell");
	$shell.addClass("loading");
	var reloadPaymentGrid = function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		grid.setSelectedRows([]);
		if (record != null) {
			$("a[data-action='close']").trigger("click");
		}
		$shell.removeClass("loading");
		buildNotification(msg, 500, 5000);
	}
	if (record != null) {
		setTimeout(function() {
			var item = dataView.getItem(grid.getActiveCell().row);
			dataView.deleteItem(item.id)
			msg = "User " + record.userid + " has been deleted.";
			reloadPaymentGrid();
		}, 1500);
	} else {
		setTimeout(function() {
			var rowsForDelete = [];
			for (var i = 0, l = selectedRowIds.length; i < l; i++) {
				var item = selectedRowIds[i];
				if (item) rowsForDelete.unshift(item)
			};
			for (var i = 0; i < rowsForDelete.length; i++) {
				dataView.deleteItem(rowsForDelete[i])
			};
			msg = "Selected user have been deleted.";
			reloadPaymentGrid();			
		}, 1500);
	}
}
function deleteRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("User <strong>" + record.userid + "</strong> will be deleted.", "Do you want to continue?", function() {
			deleteRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "users" : "user";
		buildConfirmDialog("The selected " + rtext + " will be deleted.", "Do you want to continue?", function() {
			deleteRecords();
		});
	}
}


/**********************************************************************
SUBMIT
**********************************************************************/
function submitRecords() {
	$("#usersGrid").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#usersGrid").removeClass("working");
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#usersGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Draft";
		record.recalledby = "Test User";
		record.recalledon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment " + record.batchid + " has been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Draft";
			data[dataView.getIdxById(selectedRowIds[i])].recalledby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].recalledon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected User have been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	}
}
function submitRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("Payment <strong>" + record.batchid + "</strong> will be recalled and returned to draft status.", "Do you want to continue?", function() {
			submitRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "payments" : "payment";
		buildConfirmDialog("The selected " + rtext + " will be recalled and returned to draft status.", "Do you want to continue?", function() {
			submitRecords();
		});
	}
}




/**********************************************************************
APPROVE
**********************************************************************/
var AuthorisationModel = 0;
function approveRecords() {
	$(".shell").addClass("loading");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#usersGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
			$(".shell").removeClass("loading");
		}, 1500);
	}
	if (record != null) {
		record.status = "Processing";
		record.workflow = "Approved";
		record.approvedby = "Test User";
		record.approvedon = smartDates("today") + " at " + timeFormatter();
		msg = "User <strong>" + record.userid + "</strong> has been approved";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Processing";
			data[dataView.getIdxById(selectedRowIds[i])].workflow = "Approved";
			data[dataView.getIdxById(selectedRowIds[i])].approvedby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].approvedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected users have been approved ";
		reloadPaymentGrid();
	}

}

/**********************************************************************
REJECT
**********************************************************************/
function rejectRecords(dialog) {
	$("#rejectReason").addClass("working");
	var sel = selectedRowIds.length;
	if (!sel || sel == 1) {
		var payment, msg;
		if (record != null) {
			payment = dataView.getItemById(record.id);
		} else {
			payment = data[dataView.getIdxById(selectedRowIds[0])];
		}
		var reloadPaymentGrid = function() {
			payment.rejectedby = "Test User";
			payment.rejectedon = smartDates("today") + " at " + timeFormatter();
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				if (record != null) {
					$("a[data-panel='#usersGrid']").trigger("click");
				}
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		payment.workflow = "Rejected";
		msg = "Approval for User <strong>" + payment.userid + "</strong> has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	} else if (sel > 1) {
		var reloadPaymentGrid = function() {
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Rejected";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Approval for selected payment records has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	}
}
function rejectRecordReason(e) {
	e.preventDefault();
	var $target = $(e.target);
	var populateRejectReason = function() {
		var $form = $("<div class='form-section' />");
		var $row = $("<div class='row' />").appendTo($form);
		var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
		var $textarea = $("<textarea style='width: 425px; height: 230px;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
		return $form;
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "rejectReason",
		title: "Enter A Reason For Rejection",
		size: "small",
		icon: "<i class='fa fa-ban'></i>",
		content: function() {
			return populateRejectReason()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					rejectRecords(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#rejectionReasonTextarea").focus();
}
function rejectRecordFromList(e) {
	e.preventDefault();
	$(".shell").addClass("loading");
	//$("#paymentSummaryGrid").addClass("loading");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#approvePayments").removeClass("working");
			//dialogHider(dialog);
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#usersGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
			$(".shell").removeClass("loading");
		}, 1500);
	}

	var sel = selectedRowIds.length;
	if (sel == 0 && record == null) {
		return false;
	} else if ( sel == 1) {
			//rejectRecordReason(e);
			var rows = (grid.getSelectedRows())
			var record = dataView.getItem(rows[0]);
			msg = "Approval for User <strong>" + record.userid + "</strong> has been <strong>rejected</strong>.";
			reloadPaymentGrid();
	} else if ( sel > 1 ) {
		buildConfirmDialog("Approval for selected records will be rejected.", "Do you want to continue?", function() {
			//rejectRecordReason(e);
			msg = "Approval for Users  have been <strong>rejected</strong>.";
			reloadPaymentGrid();
		});
	}
}



/**********************************************************************
DIALOGS
**********************************************************************/
function showAuditHistoryDialog(e) {
	e.preventDefault();


	if (record == null) {
		record = dataView.getItem(grid.getActiveCell().row);
	}

	var destroyAuditGrid = function() {
		if (typeof(auditGrid) != 'undefined' && auditGrid != null) {
			auditGrid.destroy();
			$(window).off('resize.auditgrid');
		}
	}

	var loadRecordAuditTable = function() {
		$("#auditHistoryDilaog").addClass("loading");

		setTimeout(function() {
			var auditData = record.audit;
			var $auditGrid = $("<div class='panel' id='auditGrid' style='top: 0;' />").appendTo($("#auditGridContainer"));
			var auditColumns = [{
				id: "action",
				name: "Action",
				field: "action",
				width: 500,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}, {
				id: "by",
				name: "User",
				field: "by",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}, {
				id: "datetime",
				name: "Date / Time",
				field: "datetime",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}];
			var auditOptions = {
				enableCellNavigation: false,
				enableColumnReorder: false,
				syncColumnCellResize: false,
				forceFitColumns: false,
				multiSelect: false,
				multiColumnSort: true
			};

			if (store.get('auditColumnOrder')) {
				auditColumns = store.get('auditColumnOrder');
			} else {
				store.set('auditColumnOrder', auditColumns)
			}

			if (store.get('auditColumnWidths')) {
				var setWidth = store.get('auditColumnWidths');
				for (var i in setWidth) {
					var s = setWidth[i]
					for (c = 0; c < auditColumns.length; c++) {
						if (s.id == auditColumns[c].id) {
							auditColumns[c].width = s.width
						}
					}
				}
			}

			var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
			var auditDataView = new Slick.Data.DataView({
				groupItemMetadataProvider: groupItemMetadataProvider
			});
			auditGrid = new Slick.Grid($auditGrid, auditDataView, auditColumns, auditOptions);
			auditGrid.registerPlugin(groupItemMetadataProvider);
			var auditColumnpicker = new Slick.Controls.ColumnPicker(auditColumns, auditGrid, auditOptions, 'auditColumnOrder', 'auditColumnWidths');
			auditGrid.setSelectionModel(new Slick.RowSelectionModel({
				selectActiveRow: true
			}));
			auditGrid.onSelectedRowsChanged.subscribe(function(e, args) {
				var rows = auditGrid.getSelectedRows();
				for (var i = 0, l = rows.length; i < l; i++) {
					var item = auditDataView.getItem(rows[i])
				}
			});
			auditGrid.onClick.subscribe(function(e, args) {
				var cell = auditGrid.getCellFromEvent(e);
				var row = cell.row;
			});
			auditGrid.onDblClick.subscribe(function(e, args) {
				var cell = auditGrid.getCellFromEvent(e);
				var row = cell.row;
			});
			auditGrid.onKeyDown.subscribe(function(e, args) {
				if (e.which == 13) {
					if (auditGrid.getActiveCell()) {
						var row = auditGrid.getActiveCell().row;
					}
				}
			});
			auditGrid.onSort.subscribe(function(e, args) {
				auditDataView.sort(function(dataRow1, dataRow2) {
					sortdir = args.sortAsc ? 1 : -1;
					sortcol = args.sortCol.field;
					var _sorter = args.sortCol.sorter,
						result;
					if (_sorter == "sorterStringCompare") {
						result = sorterStringCompare(dataRow1, dataRow2);
					} else if (_sorter == "sorterNumeric") {
						result = sorterNumeric(dataRow1, dataRow2);
					} else if (_sorter == "sorterDateIso") {
						result = sorterDateIso(dataRow1, dataRow2);
					} else if (_sorter == "sorterTime") {
						result = sorterTime(dataRow1, dataRow2);
					}
					if (result != 0) {
						return result;
					}
				});
				args.grid.invalidateAllRows();
				args.grid.render();
			});
			auditGrid.onColumnsReordered.subscribe(function(e, args) {
				store.set('auditColumnOrder', auditColumns);
			});

			auditGrid.onColumnsResized.subscribe(function(e, args) {
				store.set('auditColumnWidths', auditGrid.getColumns());
			});
			auditDataView.onRowCountChanged.subscribe(function(e, args) {
				auditGrid.updateRowCount();
				auditGrid.render();
			});
			auditDataView.onRowsChanged.subscribe(function(e, args) {
				auditGrid.invalidateRows(args.rows);
				auditGrid.render();
			});
			auditDataView.beginUpdate();
			auditDataView.setItems(auditData);
			auditDataView.endUpdate();


			auditGrid.setColumns(auditColumns);

			if (store.get('auditColumnOrder')) {
				var visibleAdHocColumns = [];
				for (var i = 0; i < store.get('auditColumnOrder').length; i++) {
					if (auditColumns[i].visible) {
						visibleAdHocColumns.push(auditColumns[i])
					}
				}
				auditGrid.setColumns(visibleAdHocColumns);
			}

			$(window).on('resize.auditgrid', function() {
				auditGrid.resizeCanvas();
			});

			$("#auditHistoryDilaog").removeClass("loading");
			auditGrid.resizeCanvas();
		}, 1000);
	}

	var populateAuditDialog = function() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditHistoryDialogContent' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box ' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Audit Information</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$row = $("<div class='row' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($row);

		var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
			$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
			$dataTableCell = $("<div class='data-table-cell' style='width: 47%;'>Action</div>").appendTo($dataTableRow),
			$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>User</div>").appendTo($dataTableRow),
			$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Date / Time</div>").appendTo($dataTableRow);


		for (var i = 0, l = record.audit.length; i < l; i++) {
			var _aud = record.audit[i],
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);


			if (_aud.action == "Modified" || _aud.action == "Created") {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'/>").appendTo($dataTableRow);
				var $link = $("<a href='javascript:void(0)' style='text-decoration: none;' data-id='" + _aud.id + "'><span style='margin-right: 5px; vertical-align: middle;'>" + _aud.description + "</span><i class='fa fa-external-link fa-fw'></i></a>").appendTo($dataTableCell).on("click", function(e) {
					e.preventDefault();

					var aID = $(this).attr("data-id");

					var auditItem = _.find(record.audit, function(o) {
						return o.id == aID;
					})


					var populatePermissionAuditDialog = function() {

					function dialog1(){
						var $auditDialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditDetailDialog' />");

						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Audit Details: Permission (1234)</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User ID</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.record + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.by + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Date / Time</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.datetime + "</div>").appendTo($dataCol);


						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Changed Values</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$dataCol = $("<div class='data-column' />").appendTo($row);

						var $dataTable = $("<div class='data-table' style='overflow-y:scroll' />").appendTo($dataCol),
							$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Field</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Old Value</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>New Value</div>").appendTo($dataTableRow);

						
						var $dataTableRow = $("<div class='data-table-row' id='rolerow' style='color: #007dba;font-weight:bold;cursor: pointer' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;background: #f8f8f8;'><i id='rolerowicon'  class='fa fa-plus' aria-hidden='true'></i> Rolename: Approve & Reporting</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;text-align:right'>Action: Modified</div>").appendTo($dataTableRow);
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;' />").appendTo($dataTableRow);

								//var $rows = $('<span id="rolerowcontainer" />').appendTo($dataTable);
								//var $dataTable = $("<div  id='rolerowcontainer'  style='display:none' />").appendTo($dataTable);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Role</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Approve, Create, Reporting</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Approve, Reporting</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Divisioin</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Division ABC</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Division XYZ</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Operating Accounts</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>All</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);


								//
								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Deposits</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345678</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345671</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345671</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345672</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);



								//hello
								var $dataTableRow = $("<div class='data-table-row' id='rolerow1' style='color: #007dba;font-weight:bold;cursor: pointer' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;background: #f8f8f8;'><i id='rolerowicon1'  class='fa fa-plus' aria-hidden='true'></i> Rolename: Approve & Creating</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;text-align:right'>Action: Modified</div>").appendTo($dataTableRow);
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;' />").appendTo($dataTableRow);

								//var $rows = $('<span id="rolerowcontainer" />').appendTo($dataTable);
								//var $dataTable = $("<div  id='rolerowcontainer'  style='display:none' />").appendTo($dataTable);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Role</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Approve, Reporting</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Approve, Create</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Divisioin</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Division ABC</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Division XYZ</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Operating Accounts</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>All</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);


								//
								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Deposits</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345678</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345671</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345671</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>22345672</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);



						return $auditDialogContent;
					}

						setTimeout(function(){

							$('#rolerow').on("click", function(){
								if($( "#rolerowicon" ).hasClass( "fa-plus" )){
									$('#rolerowicon').removeClass("fa-plus").addClass("fa-minus");
									$('.show-hide').show();
								}
								else {
									$('#rolerowicon').removeClass("fa-minus").addClass("fa-plus");
									$('.show-hide').hide();
								}

							});
							$('#rolerow1').on("click", function(){
								if($( "#rolerowicon1" ).hasClass( "fa-plus" )){
									$('#rolerowicon1').removeClass("fa-plus").addClass("fa-minus");
									$('.show-hide1').show();
								}
								else {
									$('#rolerowicon1').removeClass("fa-minus").addClass("fa-plus");
									$('.show-hide1').hide();
								}

							})
						})

					var _origin =  $('#auditRecordDetails');//$(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);

					var _dialog = {
						id: "auditpRecordDetails",
						title: "Permission Audit Details",
						size: "xl",
						icon: "<i class='fa fa-info-circle'></i>",
						content: function() {
							return dialog1()
						},
						buttons: [{
							name: "Close",
							icon: "<i class='fa fa-times-circle fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog)
								}
							}]
						}]
					}
					dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

				}

				var populatePermissionAuditDialog1 = function() {

					function dialog1(){
						var $auditDialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditDetailDialog' />");

						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Audit Details: Permission (1234)</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User ID</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.record + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.by + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Date / Time</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.datetime + "</div>").appendTo($dataCol);


						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Changed Values</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$dataCol = $("<div class='data-column' />").appendTo($row);

						var $dataTable = $("<div class='data-table' style='overflow-y:scroll' />").appendTo($dataCol),
							$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Field</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Old Value</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>New Value</div>").appendTo($dataTableRow);

						
						var $dataTableRow = $("<div class='data-table-row' id='rolerow' style='color: #007dba;font-weight:bold;cursor: pointer' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;background: #f8f8f8;'><i id='rolerowicon'  class='fa fa-plus' aria-hidden='true'></i> Rolename: Approve & Reporting</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;text-align:right'>Action: Added</div>").appendTo($dataTableRow);
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;' />").appendTo($dataTableRow);

								//var $rows = $('<span id="rolerowcontainer" />').appendTo($dataTable);
								//var $dataTable = $("<div  id='rolerowcontainer'  style='display:none' />").appendTo($dataTable);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Role</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Approve, Reporting</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Divisioin</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Division XYZ</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Operating Accounts</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);


								//
								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Deposits</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);



								//hello
								var $dataTableRow = $("<div class='data-table-row' id='rolerow1' style='color: #007dba;font-weight:bold;cursor: pointer' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;background: #f8f8f8;'><i id='rolerowicon1'  class='fa fa-plus' aria-hidden='true'></i> Rolename: Approve & Creating</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;text-align:right'>Action: Added</div>").appendTo($dataTableRow);
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;background: #f8f8f8;' />").appendTo($dataTableRow);

								//var $rows = $('<span id="rolerowcontainer" />').appendTo($dataTable);
								//var $dataTable = $("<div  id='rolerowcontainer'  style='display:none' />").appendTo($dataTable);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Role</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Approve, Create</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Divisioin</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Division XYZ</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Operating Accounts</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);


								//
								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Balance & transaction Reporting:<br> Deposits</div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Selected</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345678</div>").appendTo($rowcontainer);


								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345679</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345672</div>").appendTo($rowcontainer);

								var $rowcontainer = $('<div   class="data-table-row show-hide1" style="display:none " />').appendTo($dataTable);

								//var $dataTableRow = $("<div class='data-table-row' />").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($rowcontainer),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>12345671</div>").appendTo($rowcontainer);



						return $auditDialogContent;
					}

						setTimeout(function(){

							$('#rolerow').on("click", function(){
								if($( "#rolerowicon" ).hasClass( "fa-plus" )){
									$('#rolerowicon').removeClass("fa-plus").addClass("fa-minus");
									$('.show-hide').show();
								}
								else {
									$('#rolerowicon').removeClass("fa-minus").addClass("fa-plus");
									$('.show-hide').hide();
								}

							});
							$('#rolerow1').on("click", function(){
								if($( "#rolerowicon1" ).hasClass( "fa-plus" )){
									$('#rolerowicon1').removeClass("fa-plus").addClass("fa-minus");
									$('.show-hide1').show();
								}
								else {
									$('#rolerowicon1').removeClass("fa-minus").addClass("fa-plus");
									$('.show-hide1').hide();
								}

							})
						})

					var _origin =  $('#auditRecordDetails');//$(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);

					var _dialog = {
						id: "auditpRecordDetails",
						title: "Permission Audit Details",
						size: "xl",
						icon: "<i class='fa fa-info-circle'></i>",
						content: function() {
							return dialog1()
						},
						buttons: [{
							name: "Close",
							icon: "<i class='fa fa-times-circle fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog)
								}
							}]
						}]
					}
					dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

				}

					var populateAuditDetailDialog = function() {
						var $auditDialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditDetailDialog' />");

						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Audit Details</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User ID</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.record + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.by + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Date / Time</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.datetime + "</div>").appendTo($dataCol);


						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Changed Values</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$dataCol = $("<div class='data-column' />").appendTo($row);

						var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
							$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Field</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Old Value</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>New Value</div>").appendTo($dataTableRow);

						for (var a = 0, b = auditItem.fields.length; a < b; a++) {
							var _field = auditItem.fields[a];
							var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>" + _field.label + "</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>" + _field.from + "</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>" + _field.to + "</div>").appendTo($dataTableRow);
						}

						var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Permission (1234)</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;' />").appendTo($dataTableRow);

				var $link = $("<a href='javascript:void(0)' style='text-decoration: none;' data-id=''><span style='margin-right: 5px; vertical-align: middle;'>Added</span><i class='fa fa-external-link fa-fw'></i></a>").appendTo($dataTableCell).on("click", function(e) {
					e.preventDefault();

					populatePermissionAuditDialog1();

					});

					var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Permission (1234)</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'></div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;' />").appendTo($dataTableRow);

					var $link = $("<a href='javascript:void(0)' style='text-decoration: none;' data-id=''><span style='margin-right: 5px; vertical-align: middle;'>Modified</span><i class='fa fa-external-link fa-fw'></i></a>").appendTo($dataTableCell).on("click", function(e) {
					e.preventDefault();

					populatePermissionAuditDialog();

					});

						return $auditDialogContent;
					}

					var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
					var _dialog = {
						id: "auditRecordDetails",
						title: "Audit Details",
						size: "xl",
						icon: "<i class='fa fa-info-circle'></i>",
						content: function() {
							return populateAuditDetailDialog()
						},
						buttons: [{
							name: "Close",
							icon: "<i class='fa fa-times-circle fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog)
								}
							}]
						}]
					}
					dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
				});

				var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.by + "</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.datetime + "</div>").appendTo($dataTableRow);
			} else if (_aud.action == "Rejected") {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'>" + _aud.description + "</div>").appendTo($dataTableRow),
					$comment = $("<div style='line-height: normal; white-space: normal; padding: 10px 10px 10px 0; width: 175%;'><em>" + _aud.comment + "</em></div>").appendTo($dataTableCell);
					var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.by + "</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.datetime + "</div>").appendTo($dataTableRow);
			} 
			else if (_aud.action == "PAdded" || _aud.action == "PRemoved" || _aud.action == "PModified") {
				
			}else {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'>" + _aud.description + "</div>").appendTo($dataTableRow);
				var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.by + "</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.datetime + "</div>").appendTo($dataTableRow);
			}
			

		}



		/* var $auditGridContainer = $("<div id='auditGridContainer' class='panel' style='top: 0;' />").appendTo($dialogContent); */
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "auditHistoryDilaog",
		title: "View Audit History",
		size: "xxl",
		icon: "<i class='fa fa-calendar'></i>",
		content: function() {
			return populateAuditDialog()
		},
		hasgrid: function() {
			record = null;
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	/* loadRecordAuditTable(); 	*/
}

function showSecurityDeviceDetails(e) {
	e.preventDefault();
	var $target = $(e.target);

	var populateSecurityDetailDialog = function() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='securityDeviceDetailContainer' />");
		var $box = $("<div class='box' />").appendTo($dialogContent);
		var $boxContent = $("<div class='box-content transparent no-row-padding' />").appendTo($box);
		var $row = $("<div class='row' />").appendTo($boxContent);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Device Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>Token</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxContent);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Device Type</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>Digipass Token Pin Pad 1 Standard</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxContent);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Status</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>Provisioned</div>").appendTo($dataCol);		
		var $row = $("<div class='row' />").appendTo($boxContent);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>Device Active</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxContent);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Status Details</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>Issued device has been Activated</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxContent);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Expiry Date</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>31/12/2025</div>").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $target;
	var _dialog = {
		id: "securityDeviceDetail",
		title: "Security Device Details",
		size: "small",
		icon: "<i class='fa fa-calculator'></i>",
		content: function() {
			return populateSecurityDetailDialog()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	

}

function downloadReport(_dialog) {
	dialogHider(_dialog);
	$(".shell").addClass("loading");
	setTimeout(function() {
		$(".shell").removeClass("loading");
		buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
	}, 3000);
};

function reportDateSelection() {
	var _date = $(this).val();
	var $note = $("#dateNote");
	var $from = $("#dateFrom");
	var $to = $("#dateTo");
	var $row = $(this).closest("div.row");
	if (_date == "sd") {
		$from.datepicker("destroy").hide();
		$to.datepicker("destroy").hide();
		$note.hide();
		$from.datepicker({
			constrainInput: true,
			duration: 0,
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			maxDate: "0"
		}).attr("placeholder", "Date").show().focus();
	} else if (_date == "dr") {
		$from.datepicker("destroy").hide();
		$to.datepicker("destroy").hide();
		$note.hide();

		$from.attr("placeholder", "From").show();
		$to.show();
		var statementeDatRange = $("#dateFrom, #dateTo").datepicker({
			constrainInput: true,
			duration: 0,
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			numberOfMonths: 1,
			maxDate: "0",
			onSelect: function(selectedDate) {
				var option = this.id == "dateFrom" ? "minDate" : "maxDate",
					instance = $(this).data("datepicker"),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings);
				statementeDatRange.not(this).datepicker("option", option, date);
			}
		});
		$from.focus();
	} else {
		$from.datepicker("destroy").hide();
		$to.datepicker("destroy").hide();
		$note.empty().html($(this).val());
	}
};

function showAuditHistoryReportDialog(e) {
	e.preventDefault();
	var $target = $(e.target);

	var populateAuditReportDialog = function() {
		var $dialogContent = $("<div class='data-form' style='padding: 10px 0;' />");

		var $sectionHeading = $("<div class='section-heading'>Report Information</div>").appendTo($dialogContent);
		var $section = $("<div class='form-section' />").appendTo($dialogContent);
		var $row = $("<div class='row' />").appendTo($section);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Report Type</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>Audity History Report</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($section);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Report Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' id='reportName' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($section);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Report Format</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
		var $select = $("<select id='reportFormat'><option value='CSV'>CSV</option><option value'PDF'>PDF</option></select>").appendTo($customSelect);

		var $sectionHeading = $("<div class='section-heading'>Report Filter</div>").appendTo($dialogContent);
		var $section = $("<div class='form-section' />").appendTo($dialogContent);
		var $row = $("<div class='row' />").appendTo($section);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Date</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
		var $select = $("<select id='reportDate'><option value='"+smartDates('today')+"'>Today</option><option value='"+smartDates('yesterday')+"'>Yesterday</option><option value='"+smartDates('weektodate')+"'>Week To Date</option><option value='"+smartDates('lastweek')+"'>Previous Week</option><option value='"+smartDates('monthtodate')+"'>Month To Date</option><option value='"+smartDates('lastmonth')+"'>Previous Month</option><option value='sd'>Specific Date</option><option value='dr'>Date Range</option></select>").appendTo($customSelect).on("change", reportDateSelection);
		var $div = $("<div style='margin-top: 10px;' />").appendTo($dataCol);
		var $dateNote = $("<div class='data-note' id='dateNote'>"+smartDates('today')+"</div>").appendTo($div);
		var $dateFrom = $("<input type='text' style='width: 120px; display: none;' id='dateFrom' placeholder='From' />").appendTo($div);
		var $dateTo = $("<input type='text' style='width: 120px; display: none;' id='dateTo' placeholder='To' />").appendTo($div);
		var $row = $("<div class='row' />").appendTo($section);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Audit Event Type</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
		var $select = $("<select id='reportEventType'><option value='All'>All</option><option value'Approved'>Approved</option><option value'Created'>Created</option><option value'Deleted'>Deleted</option><option value'Disabled'>Disabled</option><option value'Enabled'>Enabled</option><option value'Modified'>Modified</option><option value'Password Reset'>Password Reset</option><option value'Rejected'>Rejected</option></select>").appendTo($customSelect);


		return $dialogContent;
	}

	var _origin = $target;

	var _dialog = {
		id: "auditHistoryReportDialog",
		title: "Audit History Report",
		size: "medium",
		icon: "<i class='fa fa-file-text fa-fw'></i>",
		content: function() {
			return populateAuditReportDialog()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Submit",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showUserSummaryReportDialog(e) {
	e.preventDefault();
	var $target = $(e.target);

	var populateUserSummaryReportDialog = function() {
		var $dialogContent = $("<div />");

		return $dialogContent;
	}

	var _origin = $target;

	var _dialog = {
		id: "userSummaryReportDialog",
		title: "User Summary Report",
		size: "medium",
		icon: "<i class='fa fa-file-text fa-fw'></i>",
		content: function() {
			return populateUserSummaryReportDialog()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Submit",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showUserDetailReportDialog(e) {
	e.preventDefault();
	var $target = $(e.target);

	var populateUserDetailReportDialog = function() {
		var $dialogContent = $("<div />");

		return $dialogContent;
	}

	var _origin = $target;

	var _dialog = {
		id: "userDetailReportDialog",
		title: "User Detail Report",
		size: "medium",
		icon: "<i class='fa fa-file-text fa-fw'></i>",
		content: function() {
			return populateUserDetailReportDialog()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Submit",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/**********************************************************************
EDIT RECORD FUNCTIONALITY
**********************************************************************/
var users = [{
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid2",
		record: "Role",
		name: "Role 2",
		family: "Role Family",
		description: "Role 2 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid2",
		record: "Role",
		name: "Role 2",
		family: "Role Family",
		description: "Role 2 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid3",
		record: "Role",
		name: "Role 3",
		family: "Role Family",
		description: "Role 3 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid4",
		record: "Role",
		name: "Role 4",
		family: "Role Family",
		description: "Role 4 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}];

var roles = [{
	id: "roleid1",
	record: "Role",
	name: "Role 1",
	family: "Role Family",
	description: "Role 1 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid2",
	record: "Role",
	name: "Role 2",
	family: "Role Family",
	description: "Role 2 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid3",
	record: "Role",
	name: "Role 3",
	family: "Role Family",
	description: "Role 3 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid4",
	record: "Role",
	name: "Role 4",
	family: "Role Family",
	description: "Role 4 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid5",
	record: "Role",
	name: "Role 5",
	family: "Role Family",
	description: "Role 5 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid6",
	record: "Role",
	name: "Role 6",
	family: "Role Family",
	description: "Role 6 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid7",
	record: "Role",
	name: "Role 7",
	family: "Role Family",
	description: "Role 7 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid8",
	record: "Role",
	name: "Role 8",
	family: "Role Family",
	description: "Role 8 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid9",
	record: "Role",
	name: "Role 9",
	family: "Role Family",
	description: "Role 9 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid10",
	record: "Role",
	name: "Role 10",
	family: "Role Family",
	description: "Role 10 Description",
	division: "Division 2",
	type: "System"
}];

var userAssignedRoles = [];

var searchGrid = null;
var searchDataView;
var searchData;
var searchSelectedRowIds;
var searchOptions;
var searchColumns;
var searchList = [];

var rolesGrid = null;
var rolesDataView;
var rolesData;
var rolesSelectedRowIds;
var rolesOptions;
var rolesColumns;

function destroyDialogSearchGrid() {
	if (typeof(searchGrid) != 'undefined' && searchGrid != null) {
		searchGrid.destroy();
		$(window).off('resize.searchgrid');
	}
}

function searchGridFilter(rec) {
	var found;
	for (i = 0; i < searchList.length; i += 1) {
		found = false;
		$.each(rec, function(obj, objValue) {
			if (typeof objValue !== 'undefined' && objValue != null && objValue.toString().toLowerCase().indexOf(searchList[i]) != -1) {
				found = true;
				return false;
			}
		});
		if (!found) {
			return false;
		}
	}
	return true;
}

function createNewRoleDialog(e) {

	e.preventDefault();

	var _target = $(this);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderNewRoleDialogContent = function() { 

		/* system information */
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

		/* system information */
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 11%;' />").appendTo($detailRow);
		var $icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell);
		var $detailCell = $("<div class='grid-cell' style='width: 88%;padding-top: 40px' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label >Role Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $input = $("<input type='text' style='width: 80%;' id='roleName' />").appendTo($dataCol);
		var $dataRow = $("<div class='row' style='padding-top: 20px' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label >Role Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $input = $("<textarea  style='width: 80%;' id='roleDescription' />").appendTo($dataCol);

		return $dialogContent;
	}

	function saveNewRole() {
		data = [{id: randString(20) ,name: $('#roleName').val(), division: $('#divisionSelection :selected').text(),  family: "Role Family", description: $('#roleDescription').val() , type: "System" }];
		userAssignedRoles = userAssignedRoles.concat(data);
		renderAssignedRolesGrid();
	}

	var _dialog = {
		id: "newRoleDialog",
		title: "Create a New Role",
		size: "xxl",
		icon: "<i class='fa fa-edit'></i>",
		content: function() {
			return renderNewRoleDialogContent();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
						dialogHider(_dialog);
				}
			}]
			}, {
				name: "Save",
				icon: "<i class='fa fa-save fa-fw'></i>",
				events: [{
				event: "click",			
				action: function(e) {
					e.preventDefault();
					saveNewRole();
					dialogHider(_dialog);
				}
			}],
			cssClass: "primary"
		}]
	}

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function setupRolePermissions(target, mode) {


	var _target = target;
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderNewRoleDialogContent = function() { 

		/* system information */
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

		/* system information */
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 15%;' />").appendTo($detailRow);
		var $icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell);
		var $detailCell = $("<div class='grid-cell' style='width: 85%; padding-top: 40px' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Division</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px;' />").appendTo($dataRow);
		var $label = $("<label>Select A Division</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $customSelect = $("<div class='custom-select' style='max-width: 100%;' />").appendTo($dataCol);
		var $select = $("<select id='divisionSelection' style='min-width: 250px;'><option value='Customer Division 1'>Customer Division 1</option><option value='Customer Division 2'>Customer Division 2</option><option value='Customer Division 3'>Customer Division 3</option></select>").appendTo($customSelect);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio"  name="accountselection" value="all" id="audc-allaccounts" checked="checked"><label for="audc-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection" value="select" id="audc-selectaccounts"><label for="audc-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection" value="none" id="audc-selectaccounts2"><label for="audc-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-accountsGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='accountsGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Internation Payments</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		$data = $('<div class="checkbox-group"><input type="radio"  name="accountselection5" value="all" id="ip-allaccounts" checked="checked"><label for="ip-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection5" value="select" id="ip-selectaccounts"><label for="ip-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection5" value="none" id="ip-selectaccounts2"><label for="ip-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-paymentsGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account1" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts1" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='paymentsGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Payment Purpose</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="checkbox"  name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox"  name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Approval Discretions</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio" checked="checked" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio"  name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
		var	$boxContent1 = $("<div  id='show-allproducts' class='box-content top-label' style='width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($boxContent),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent1),
		$detailCell1 = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell1);
		$('<div  style=""> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="daily" value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="batch"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="transaction"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
		$dataRow = $("<div class='row product-specific' style='display:none' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var	$boxContent2 = $("<div class='box-content top-label product-specific' style='display:none;width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($detailCell),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent2),
		$detailCell1 = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell1);
		$('<div  style=""> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="daily1" value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="batch1"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="transaction1"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
		$dataRow = $("<div class='row product-specific' style='display:none;'/>").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>International Payments</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var	$boxContent3 = $("<div class='box-content top-label product-specific' style='display:none;width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($detailCell),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent3),
		$detailCell1 = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell1);
		$('<div  style=""> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="daily2" value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="batch2"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="transaction2"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box),
		$boxContent = $("<div class='box-content left-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Operating Accounts</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio"  name="accountselection1" value="all" id="oa-allaccounts" checked="checked"><label for="oa-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection1" value="select" id="oa-selectaccounts"><label for="oa-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection1" value="none" id="oa-selectaccounts2"><label for="oa-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-operatingGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account2" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts2" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='operatingGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Deposits</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio"  name="accountselection2" value="all" id="d-allaccounts" checked="checked"><label for="d-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection2" value="select" id="d-selectaccounts"><label for="d-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection2" value="none" id="d-selectaccounts2"><label for="d-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);					
		var $gridRow = $("<div class='grid-row' id='show-depositGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account3" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts3" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='depositGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box),
		$boxContent = $("<div class='box-content left-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio" checked="checked" name="accountselection3" value="all" id="audd-allaccounts" ><label for="audd-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection3" value="select" id="audd-selectaccounts"><label for="audd-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection3" value="none" id="audd-selectaccounts2"><label for="audd-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-auddGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account4" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts4" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='auddGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio" checked="checked" name="accountselection4" value="all" id="nzdd-allaccounts" ><label for="nzdd-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection4" value="select" id="nzdd-selectaccounts"><label for="nzdd-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection4" value="none" id="nzdd-selectaccounts2"><label for="nzdd-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-nzddGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account5" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts5" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='nzddGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);

		function removeAccount() {
			if(audomesticGrid.getSelectedRows() !="") {
				audomesticGridDataView.setItems([]);
				audomesticGrid.render();
				audomesticGrid.resizeCanvas();
			}
		}

		function addAccount(gridid) {
			_widget = {};
			_widget.data = [];
			_widget.id = "test"

			/* set _data to the widget data and _id to the widget id */
			var _data = _widget.data,
			_id = _widget.id;

			/* function to save and add selected accounts to the widget */
			function saveSelectedAccounts(_dialog) {
				if ($("input[name=_addAccount]:checked").length > 0) {
					for (var i = 0; i < accounts.length; i++) {
						for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
							if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
								accounts[i].id = randString(20);
								accounts[i].accountname = accounts[i].name;
								accounts[i].accountnumber = accounts[i].number;
								accounts[i].bank = 'NSW';
								accounts[i].country = 'Australia';
								_data.push(accounts[i]);
							}
						}
					}
					_data = _data.concat(audomesticGrid.getData().getItems());
					audomesticGridDataView.setItems(_data);
					audomesticGrid.render();
					audomesticGrid.resizeCanvas();
					dialogHider(_dialog);
				} else {
					dialogHider(_dialog);
				}
			}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}


		function removeAccount1(){
		if(paymentsGrid.getSelectedRows() !=""){
		paymentsGridDataView.setItems([]);
		paymentsGrid.render();
		paymentsGrid.resizeCanvas();
		}
		}

		function addAccount1(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(paymentsGrid.getData().getItems());
		paymentsGridDataView.setItems(_data);
		paymentsGrid.render();
		paymentsGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}

		function removeAccount2(){

		if(operatingGrid.getSelectedRows() !=""){
		operatingGridDataView.setItems([]);
		operatingGrid.render();
		operatingGrid.resizeCanvas();
		}

		}

		function addAccount2(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(operatingGrid.getData().getItems());
		operatingGridDataView.setItems(_data);
		operatingGrid.render();
		operatingGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}


		function removeAccount3(){

		if(depositGrid.getSelectedRows() !=""){
		depositGridDataView.setItems([]);
		depositGrid.render();
		depositGrid.resizeCanvas();
		}

		}

		function addAccount3(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(depositGrid.getData().getItems());
		depositGridDataView.setItems(_data);
		depositGrid.render();
		depositGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}


		function removeAccount4(){

		if(auddGrid.getSelectedRows() !=""){
		auddGridDataView.setItems([]);
		auddGrid.render();
		auddGrid.resizeCanvas();
		}

		}

		function addAccount4(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(auddGrid.getData().getItems());
		auddGridDataView.setItems(_data);
		auddGrid.render();
		auddGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}

		function removeAccount5(){

		if(nzddGrid.getSelectedRows() !=""){
		nzddGridDataView.setItems([]);
		nzddGrid.render();
		nzddGrid.resizeCanvas();
		}

		}

		function addAccount5(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		console.log(nzddGrid);
		_data = _data.concat(nzddGrid.getData().getItems());
		nzddGridDataView.setItems(_data);
		nzddGrid.render();
		nzddGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}

		function intializeGrid(){

		function resetaddAccountResourceGridColumns() {
			audomesticGrid.setColumns(audomesticGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = audomesticGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = audomesticGridGridColumns.length; a < b; a++) {
				if (_id == audomesticGridGridColumns[a].id) {
					sortCols[i].sorter =audomesticGridGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		audomesticGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', audomesticGrid.getSortColumns());
		audomesticGrid.invalidateAllRows();
		//audomesticGrid.render();
		}
		var gridId = gridId || "#accountsGrid"; 
		audomesticGridData = [];
		audomesticGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			audomesticGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', audomesticGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < audomesticGridColumns.length; c++) {
					if (s.id == audomesticGridColumns[c].id) {
						audomesticGridColumns[c].width = s.width
					}
				}
			}
		}
		audomesticGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var audomesticGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		audomesticGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: audomesticGridGroupItemMetadataProvider
		});
		audomesticGridDataView.getItemMetadata = addAccountResourceGridMetaData(audomesticGridDataView.getItemMetadata);
		audomesticGrid = new Slick.Grid(gridId, audomesticGridDataView, audomesticGridColumns, audomesticGridOptions);


		audomesticGrid.registerPlugin(audomesticGridGroupItemMetadataProvider);
		audomesticGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var audomesticGridColumnpicker = new Slick.Controls.ColumnPicker(audomesticGridColumns, audomesticGrid, audomesticGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		audomesticGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = audomesticGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = audomesticGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		audomesticGrid.onSort.subscribe(sortaddAccountResourceGrid);
		audomesticGrid.onDblClick.subscribe(function(e, args) {
			var cell = audomesticGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		audomesticGridDataView.onRowCountChanged.subscribe(function(e, args) {
			audomesticGrid.updateRowCount();
			if(audomesticGridDataView.getItems().length >0){
				$('#remove-accounts').removeClass("disabled");
			}
			else {
				$('#remove-accounts').addClass("disabled");
			}
			audomesticGrid.render();
		});
		audomesticGridDataView.onRowsChanged.subscribe(function(e, args) {
			audomesticGrid.invalidateRows(args.rows);
			audomesticGrid.render();
		});
		audomesticGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', audomesticGrid.getColumns());
		});

		audomesticGridDataView.beginUpdate();
		audomesticGridDataView.setItems(audomesticGridData);
		audomesticGridDataView.syncGridSelection(audomesticGrid, true, false);
		audomesticGridDataView.endUpdate();

		//audomesticGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (audomesticGridColumns[i].visible) {
					visibleColumns.push(audomesticGridColumns[i])
				}
			}

			audomesticGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			audomesticGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function intializeGrid1(){

		function resetaddAccountResourceGridColumns() {
			paymentsGrid.setColumns(paymentsGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = paymentsGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = paymentsGridColumns.length; a < b; a++) {
				if (_id == paymentsGridColumns[a].id) {
					sortCols[i].sorter =paymentsGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		paymentsGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', paymentsGrid.getSortColumns());
		paymentsGrid.invalidateAllRows();
		//paymentsGrid.render();
		}
		var gridId = "#paymentsGrid"; 
		paymentsGridData = [];
		paymentsGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			paymentsGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', paymentsGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < paymentsGridColumns.length; c++) {
					if (s.id == paymentsGridColumns[c].id) {
						paymentsGridColumns[c].width = s.width
					}
				}
			}
		}
		paymentsGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var paymentsGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		paymentsGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: paymentsGridGroupItemMetadataProvider
		});
		paymentsGridDataView.getItemMetadata = addAccountResourceGridMetaData(paymentsGridDataView.getItemMetadata);
		paymentsGrid = new Slick.Grid(gridId, paymentsGridDataView, paymentsGridColumns, paymentsGridOptions);


		paymentsGrid.registerPlugin(paymentsGridGroupItemMetadataProvider);
		paymentsGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var paymentsGridColumnpicker = new Slick.Controls.ColumnPicker(paymentsGridColumns, paymentsGrid, paymentsGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		paymentsGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = paymentsGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = paymentsGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		paymentsGrid.onSort.subscribe(sortaddAccountResourceGrid);
		paymentsGrid.onDblClick.subscribe(function(e, args) {
			var cell = paymentsGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		paymentsGridDataView.onRowCountChanged.subscribe(function(e, args) {
			paymentsGrid.updateRowCount();
			if(paymentsGridDataView.getItems().length >0){
				$('#remove-accounts1').removeClass("disabled");
			}
			else {
				$('#remove-accounts1').addClass("disabled");
			}
			paymentsGrid.render();
		});
		paymentsGridDataView.onRowsChanged.subscribe(function(e, args) {
			paymentsGrid.invalidateRows(args.rows);
			paymentsGrid.render();
		});
		paymentsGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', paymentsGrid.getColumns());
		});

		paymentsGridDataView.beginUpdate();
		paymentsGridDataView.setItems(paymentsGridData);
		paymentsGridDataView.syncGridSelection(paymentsGrid, true, false);
		paymentsGridDataView.endUpdate();

		//paymentsGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (paymentsGridColumns[i].visible) {
					visibleColumns.push(paymentsGridColumns[i])
				}
			}

			paymentsGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			paymentsGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}


		function intializeGrid2(){

		function resetaddAccountResourceGridColumns() {
			operatingGrid.setColumns(operatingGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = operatingGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = operatingGridColumns.length; a < b; a++) {
				if (_id == operatingGridColumns[a].id) {
					sortCols[i].sorter =operatingGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		operatingGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', operatingGrid.getSortColumns());
		operatingGrid.invalidateAllRows();
		//operatingGrid.render();
		}
		var gridId = "#operatingGrid"; 
		operatingGridData = [];
		operatingGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			operatingGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', operatingGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < operatingGridColumns.length; c++) {
					if (s.id == operatingGridColumns[c].id) {
						operatingGridColumns[c].width = s.width
					}
				}
			}
		}
		operatingGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var operatingGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		operatingGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: operatingGridGroupItemMetadataProvider
		});
		operatingGridDataView.getItemMetadata = addAccountResourceGridMetaData(operatingGridDataView.getItemMetadata);
		operatingGrid = new Slick.Grid(gridId, operatingGridDataView, operatingGridColumns, operatingGridOptions);


		operatingGrid.registerPlugin(operatingGridGroupItemMetadataProvider);
		operatingGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var operatingGridColumnpicker = new Slick.Controls.ColumnPicker(operatingGridColumns, operatingGrid, operatingGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		operatingGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = operatingGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = operatingGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		operatingGrid.onSort.subscribe(sortaddAccountResourceGrid);
		operatingGrid.onDblClick.subscribe(function(e, args) {
			var cell = operatingGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		operatingGridDataView.onRowCountChanged.subscribe(function(e, args) {
			operatingGrid.updateRowCount();
			if(operatingGridDataView.getItems().length >0){
				$('#remove-accounts2').removeClass("disabled");
			}
			else {
				$('#remove-accounts2').addClass("disabled");
			}
			operatingGrid.render();
		});
		operatingGridDataView.onRowsChanged.subscribe(function(e, args) {
			operatingGrid.invalidateRows(args.rows);
			operatingGrid.render();
		});
		operatingGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', operatingGrid.getColumns());
		});

		operatingGridDataView.beginUpdate();
		operatingGridDataView.setItems(operatingGridData);
		operatingGridDataView.syncGridSelection(operatingGrid, true, false);
		operatingGridDataView.endUpdate();

		//operatingGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (operatingGridColumns[i].visible) {
					visibleColumns.push(operatingGridColumns[i])
				}
			}

			operatingGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			operatingGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}


		function intializeGrid3(){

		function resetaddAccountResourceGridColumns() {
			depositGrid.setColumns(depositGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = depositGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = depositGridColumns.length; a < b; a++) {
				if (_id == depositGridColumns[a].id) {
					sortCols[i].sorter =depositGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		depositGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', depositGrid.getSortColumns());
		depositGrid.invalidateAllRows();
		//depositGrid.render();
		}
		var gridId =  "#depositGrid"; 
		depositGridData = [];
		depositGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			depositGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', depositGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < depositGridColumns.length; c++) {
					if (s.id == depositGridColumns[c].id) {
						depositGridColumns[c].width = s.width
					}
				}
			}
		}
		depositGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var depositGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		depositGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: depositGridGroupItemMetadataProvider
		});
		depositGridDataView.getItemMetadata = addAccountResourceGridMetaData(depositGridDataView.getItemMetadata);
		depositGrid = new Slick.Grid(gridId, depositGridDataView, depositGridColumns, depositGridOptions);


		depositGrid.registerPlugin(depositGridGroupItemMetadataProvider);
		depositGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var depositGridColumnpicker = new Slick.Controls.ColumnPicker(depositGridColumns, depositGrid, depositGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		depositGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = depositGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = depositGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		depositGrid.onSort.subscribe(sortaddAccountResourceGrid);
		depositGrid.onDblClick.subscribe(function(e, args) {
			var cell = depositGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		depositGridDataView.onRowCountChanged.subscribe(function(e, args) {
			depositGrid.updateRowCount();
			if(depositGridDataView.getItems().length >0){
				$('#remove-accounts3').removeClass("disabled");
			}
			else {
				$('#remove-accounts3').addClass("disabled");
			}
			depositGrid.render();
		});
		depositGridDataView.onRowsChanged.subscribe(function(e, args) {
			depositGrid.invalidateRows(args.rows);
			depositGrid.render();
		});
		depositGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', depositGrid.getColumns());
		});

		depositGridDataView.beginUpdate();
		depositGridDataView.setItems(depositGridData);
		depositGridDataView.syncGridSelection(depositGrid, true, false);
		depositGridDataView.endUpdate();

		//depositGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (depositGridColumns[i].visible) {
					visibleColumns.push(depositGridColumns[i])
				}
			}

			depositGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			depositGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function intializeGrid4(){

		function resetaddAccountResourceGridColumns() {
			auddGrid.setColumns(auddGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = auddGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = auddGridColumns.length; a < b; a++) {
				if (_id == auddGridColumns[a].id) {
					sortCols[i].sorter =auddGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		auddGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', auddGrid.getSortColumns());
		auddGrid.invalidateAllRows();
		//auddGrid.render();
		}
		var gridId =  "#auddGrid"; 
		auddGridData = [];
		auddGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			auddGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', auddGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < auddGridColumns.length; c++) {
					if (s.id == auddGridColumns[c].id) {
						auddGridColumns[c].width = s.width
					}
				}
			}
		}
		auddGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var auddGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		auddGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: auddGridGroupItemMetadataProvider
		});
		auddGridDataView.getItemMetadata = addAccountResourceGridMetaData(auddGridDataView.getItemMetadata);
		auddGrid = new Slick.Grid(gridId, auddGridDataView, auddGridColumns, auddGridOptions);


		auddGrid.registerPlugin(auddGridGroupItemMetadataProvider);
		auddGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var auddGridColumnpicker = new Slick.Controls.ColumnPicker(auddGridColumns, auddGrid, auddGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		auddGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = auddGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = auddGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		auddGrid.onSort.subscribe(sortaddAccountResourceGrid);
		auddGrid.onDblClick.subscribe(function(e, args) {
			var cell = auddGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		auddGridDataView.onRowCountChanged.subscribe(function(e, args) {
			auddGrid.updateRowCount();
			if(auddGridDataView.getItems().length >0){
				$('#remove-accounts4').removeClass("disabled");
			}
			else {
				$('#remove-accounts4').addClass("disabled");
			}
			auddGrid.render();
		});
		auddGridDataView.onRowsChanged.subscribe(function(e, args) {
			auddGrid.invalidateRows(args.rows);
			auddGrid.render();
		});
		auddGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', auddGrid.getColumns());
		});

		auddGridDataView.beginUpdate();
		auddGridDataView.setItems(auddGridData);
		auddGridDataView.syncGridSelection(auddGrid, true, false);
		auddGridDataView.endUpdate();

		//auddGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (auddGridColumns[i].visible) {
					visibleColumns.push(auddGridColumns[i])
				}
			}

			auddGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			auddGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function intializeGrid5(){

		function resetaddAccountResourceGridColumns() {
			nzddGrid.setColumns(nzddGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = nzddGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = nzddGridColumns.length; a < b; a++) {
				if (_id == nzddGridColumns[a].id) {
					sortCols[i].sorter =nzddGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		nzddGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', nzddGrid.getSortColumns());
		nzddGrid.invalidateAllRows();
		//nzddGrid.render();
		}
		var gridId =  "#nzddGrid"; 
		nzddGridData = [];
		nzddGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			nzddGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', nzddGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < nzddGridColumns.length; c++) {
					if (s.id == nzddGridColumns[c].id) {
						nzddGridColumns[c].width = s.width
					}
				}
			}
		}
		nzddGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var nzddGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		nzddGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: nzddGridGroupItemMetadataProvider
		});
		nzddGridDataView.getItemMetadata = addAccountResourceGridMetaData(nzddGridDataView.getItemMetadata);
		nzddGrid = new Slick.Grid(gridId, nzddGridDataView, nzddGridColumns, nzddGridOptions);


		nzddGrid.registerPlugin(nzddGridGroupItemMetadataProvider);
		nzddGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var nzddGridColumnpicker = new Slick.Controls.ColumnPicker(nzddGridColumns, nzddGrid, nzddGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		nzddGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = nzddGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = nzddGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		nzddGrid.onSort.subscribe(sortaddAccountResourceGrid);
		nzddGrid.onDblClick.subscribe(function(e, args) {
			var cell = nzddGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		nzddGridDataView.onRowCountChanged.subscribe(function(e, args) {
			nzddGrid.updateRowCount();
			if(nzddGridDataView.getItems().length >0){
				$('#remove-accounts5').removeClass("disabled");
			}
			else {
				$('#remove-accounts5').addClass("disabled");
			}
			nzddGrid.render();
		});
		nzddGridDataView.onRowsChanged.subscribe(function(e, args) {
			nzddGrid.invalidateRows(args.rows);
			nzddGrid.render();
		});
		nzddGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', nzddGrid.getColumns());
		});

		nzddGridDataView.beginUpdate();
		nzddGridDataView.setItems(nzddGridData);
		nzddGridDataView.syncGridSelection(nzddGrid, true, false);
		nzddGridDataView.endUpdate();

		//nzddGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (nzddGridColumns[i].visible) {
					visibleColumns.push(nzddGridColumns[i])
				}
			}

			nzddGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			nzddGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function updateAmount1() { 
		try { 
			var _daily = ($("#daily").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#daily").val())).toFixed(2);
			
		} catch(e) {}

		if(_daily == "0.00" || _daily == undefined){
		$("#daily").css("color", "#585858");
			_daily = "UNLIMITED";
		}
		else
			$("#daily").css("color", "#000");

		$("#daily").val(addCommas(_daily));

		}
		function updateAmount2() {
		try { 
			
			var _batch = ($("#batch").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#batch").val())).toFixed(2);

		} catch(e) {}


		if(_batch == "0.00" || _batch == undefined){
			$("#batch").css("color", "#585858");
			_batch = "UNLIMITED";
		}
		else
			$("#batch").css("color", "#000");
		$("#batch").val(addCommas(_batch));

		}
		function updateAmount3() {
		try { 
			var _transaction = ($("#transaction").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#transaction").val())).toFixed(2);
		} catch(e) {}

		if(_transaction == "0.00" || _transaction == undefined){
		$("#transaction").css("color", "#585858");
			_transaction = "UNLIMITED";
		}
		else
			$("#transaction").css("color", "#000");
		$("#transaction").val(addCommas(_transaction));
		}

		function updateAmount4() { 
		try { 
			var _daily = ($("#daily1").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#daily1").val())).toFixed(2);
			
		} catch(e) {}

		if(_daily == "0.00" || _daily == undefined){
		$("#daily1").css("color", "#585858");
			_daily = "UNLIMITED";
		}
		else
			$("#daily1").css("color", "#000");
		$("#daily1").val(addCommas(_daily));

		}
		function updateAmount5() {
		try { 
			
			var _batch = ($("#batch1").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#batch1").val())).toFixed(2);

		} catch(e) {}


		if(_batch == "0.00" || _batch == undefined){
			$("#batch1").css("color", "#585858");
			_batch = "UNLIMITED";
		}
		else
			$("#batch1").css("color", "#000");
		$("#batch1").val(addCommas(_batch));

		}
		function updateAmount6() {
		try { 
			var _transaction = ($("#transaction1").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#transaction1").val())).toFixed(2);
		} catch(e) {}

		if(_transaction == "0.00" || _transaction == undefined){
		$("#transaction1").css("color", "#585858");
			_transaction = "UNLIMITED";
		}
		else
			$("#transaction1").css("color", "#000");
		$("#transaction1").val(addCommas(_transaction));
		}

		function updateAmount7() { 
		try { 
			var _daily = ($("#daily2").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#daily2").val())).toFixed(2);
			
		} catch(e) {}

		if(_daily == "0.00" || _daily == undefined){
		$("#daily2").css("color", "#585858");
			_daily = "UNLIMITED";
		}
		else
			$("#daily2").css("color", "#000");
		$("#daily2").val(addCommas(_daily));

		}
		function updateAmount8() {
		try { 
			
			var _batch = ($("#batch2").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#batch2").val())).toFixed(2);

		} catch(e) {}


		if(_batch == "0.00" || _batch == undefined){
			$("#batch2").css("color", "#585858");
			_batch = "UNLIMITED";
		}
		else
			$("#batch2").css("color", "#000");
		$("#batch2").val(addCommas(_batch));

		}
		function updateAmount9() {
		try { 
			var _transaction = ($("#transaction2").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#transaction2").val())).toFixed(2);
		} catch(e) {}

		if(_transaction == "0.00" || _transaction == undefined){
		$("#transaction2").css("color", "#585858");
			_transaction = "UNLIMITED";
		}
		else
			$("#transaction2").css("color", "#000");
		$("#transaction2").val(addCommas(_transaction));
		}

		setTimeout( function(){
		$("#daily").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount1).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#batch").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount2).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#transaction").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount3).on("focus", function(){
		if ( $(this).val() == ""  ||  $(this).val() == "UNLIMITED") {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#daily1").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount4).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#batch1").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount5).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#transaction1").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount6).on("focus", function(){
		if ( $(this).val() == ""  ||  $(this).val() == "UNLIMITED") {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#daily2").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount7).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#batch2").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount8).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#transaction2").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount9).on("focus", function(){
		if ( $(this).val() == ""  ||  $(this).val() == "UNLIMITED") {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});


		$('#productspecific').on("click", function(){
		if($(this).is(":checked")){
			$('#show-allproducts').hide();
			$('.product-specific').show();

		}
		else {
		}
		});
		$('#allproducts').on("click", function(){
		if($(this).is(":checked")){
			$('.product-specific').hide();
			$('#show-allproducts').show();
			
			
		}
		});

		$('#audc-selectaccounts').on("click", function(){
		if($(this).is(":checked")){
			$('#show-accountsGrid').slideDown('fast');
		}
		else {
			$('#show-accountsGrid').slideToggle('fast');
		}
		});
		$('#audc-allaccounts, #audc-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-accountsGrid').slideUp('fast');
		}
		});


		$('#ip-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-paymentsGrid').slideDown('fast');
		}
		else {
			$('#show-paymentsGrid').slideToggle('fast');
		}
		});
		$('#ip-allaccounts, #ip-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-paymentsGrid').slideUp('fast');
		}
		});


		$('#oa-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-operatingGrid').slideDown('fast');
		}
		else {
			$('#show-operatingGrid').slideToggle('fast');
		}
		});
		$('#oa-allaccounts, #oa-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-operatingGrid').slideUp('fast');
		}
		});



		$('#d-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-depositGrid').slideDown('fast');
		}
		else {
			$('#show-depositGrid').slideToggle('fast');
		}
		});
		$('#d-allaccounts, #d-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-depositGrid').slideUp('fast');
		}
		});


		$('#audd-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-auddGrid').slideDown('fast');
		}
		else {
			$('#show-auddGrid').slideToggle('fast');
		}
		});
		$('#audd-allaccounts, #audd-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-auddGrid').slideUp('fast');
		}
		});


		$('#nzdd-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-nzddGrid').slideDown('fast');
		}
		else {
			$('#show-nzddGrid').slideToggle('fast');
		}
		});

		$('#nzdd-allaccounts, #nzdd-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-nzddGrid').slideUp('fast');
		}
		});






			$('#add-account').on("click", function(){addAccount()});
			$('#remove-accounts').on("click", function(){removeAccount()});
			$('#add-account1').on("click", function(){addAccount1()});
			$('#remove-accounts1').on("click", function(){removeAccount1()});
			$('#add-account2').on("click", function(){addAccount2()});
			$('#remove-accounts2').on("click", function(){removeAccount2()});
			$('#add-account3').on("click", function(){addAccount3()});
			$('#remove-accounts3').on("click", function(){removeAccount3()});
			$('#add-account4').on("click", function(){addAccount4()});
			$('#remove-accounts4').on("click", function(){removeAccount4()});
			$('#add-account5').on("click", function(){addAccount5()});
			$('#remove-accounts5').on("click", function(){removeAccount5()});
			intializeGrid();  
			intializeGrid1(); 
			intializeGrid2();  
			intializeGrid3();
			intializeGrid4();
			intializeGrid5();      
		}, 400);

		return $dialogContent;
	}

	var _dialog = {
		id: "saveRolePermissionSettings",
		title: "Permission Settings",
		size: "xxl",
		icon: "<i class='fa fa-edit'></i>",
			content: function() {
			return renderNewRoleDialogContent();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
			event: "click",
			action: function(e) {
				e.preventDefault();
				dialogHider(_dialog);
				}
			}]
		}]
	}

	var btn;
	if (mode == "edit") {
		btn = {
			name: "Save",
			icon: "<i class='fa fa-save fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					$("#saveRolePermissionSettings").addClass("working");
					setTimeout(function() {
						dialogHider(_dialog);
						buildNotification("Permissions have successfully been updated.", 500, 2000);
					}, 1000);
				}
			}],
			cssClass: "primary"
		}
	} else {
		btn = {
			name: "Add Permission",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					addRoles();
				}
			}],
			cssClass: "primary"
		}
	}

	_dialog.buttons.splice(1, 0,  btn)

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function triggerRoleDialog(el) {
	
	function viewRole() {

		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 11%;' />").appendTo($detailRow),
			$icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell),
			$detailCell = $("<div class='grid-cell' style='width: 88%;padding-top: 40px' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow),							
			$label = $("<label >Role Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow),
			$label = $("<label >Role Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
			
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Division</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px' />").appendTo($dataRow),
			$label = $("<label>Select a Division</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="custom-select" style="max-width: 100%;"><select id="divisionSelection" disabled="disabled" style="min-width: 250px;"><option value="Customer Division 1">Customer Division 1</option><option value="Customer Division 2">Customer Division 2</option><option value="Customer Division 3">Customer Division 3</option></select></div>').appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Internation Payments</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Payment Purpose</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="checkbox" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox" disabled="disabled" name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Approval Discretions</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
		
		var	$boxContent = $("<div class='box-content top-label' style='width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($boxContent),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$data = $('<div id="approvaldis"> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);


		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Operating Accounts</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Deposits</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
			
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);

		return $dialogContent;
	}

	var _target = el;
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var _dialog = {
		id: "roleDialog",
		title: "View Permission",
		size: "xxl",
		icon: "<i class='fa fa-cog'></i>",
		content: function() {
			return viewRole()
		},
		buttons: [ {
			name: "Close",
			icon: "<i class='fa fa-close fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function renderUserDetailsDialog(el, item) {

	var _target = $(el);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderUserDetailsContent = function() { 
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='userDetailsDialogContent' />");
		var content = '<div class="grid-layout"><div class="grid-row"><div class="grid-cell"><div class="box"><div class="box-header">User Information</div><div class="box-content left-label"><div class="grid-row"><div class="grid-cell" style="width: 50%;"><div class="row"><div class="label-column"><label>User ID</label></div><div class="data-column"><div class="data-text" id="viewUserID">BAUSR3</div></div></div><div class="row"><div class="label-column"><label>Preferred Name</label></div><div class="data-column"><div class="data-text" id="viewPreferredName">BAUSR3</div></div></div><div class="row"><div class="label-column"><label>Status</label></div><div class="data-column"><div class="data-text" id="viewStatus">Active</div></div></div><div class="row"><div class="label-column"><label>Workflow</label></div><div class="data-column"><div class="data-text" id="viewWorkflow">Pending Approval – Delete</div></div></div></div><div class="grid-cell" style="width: 50%;"><div class="row"> <div class="label-column"><label>First Name</label></div> <div class="data-column"><div class="data-text" id="viewFirstName">William</div></div> </div> <div class="row"> <div class="label-column"><label>Last Name</label></div> <div class="data-column"><div class="data-text" id="viewLastName">Jones</div></div> </div> <div class="row"> <div class="label-column"><label>Managed By</label></div> <div class="data-column"><div class="data-text" id="viewManagedBy">company</div></div> </div> <div class="row"> <div class="label-column"><label>User Credentials</label></div> <div class="data-column"><div class="data-text" id="viewUserCredentials">Password</div></div> </div> <div class="row"> <div class="label-column"><label>User Type</label></div> <div class="data-column"><div class="data-text" id="viewUserType">Admin</div></div> </div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">User Contact Details</div> <div class="box-content left-label"> <div class="grid-row"> <div class="grid-cell" style="width: 50%;"> <div class="row"> <div class="label-column"><label>Address</label></div> <div class="data-column"> <div class="break"><div class="data-text" id="viewAddress1">Level 25/100 Queens Street</div></div> <div class="break"><div class="data-text" id="viewAddress2">Institutional Building</div></div> </div> </div> <div class="row"> <div class="label-column"><label>City</label></div> <div class="data-column"><div class="data-text" id="viewCity">Melbourne</div></div> </div> <div class="row"> <div class="label-column"><label>State</label></div> <div class="data-column"><div class="data-text" id="viewState">Victoria</div></div> </div> <div class="row"> <div class="label-column"><label>Country</label></div> <div class="data-column"><div class="data-text" id="viewCountry">Australia</div></div> </div> <div class="row"> <div class="label-column"><label>ZIP</label></div> <div class="data-column"><div class="data-text" id="viewZip">3000</div></div> </div> </div> <div class="grid-cell" style="width: 50%;"> <div class="row"> <div class="label-column"><label>Mobile Number</label></div> <div class="data-column"><div class="data-text" id="viewMobileNumber">+86 20 5555 5555</div></div> </div> <div class="row"> <div class="label-column"><label>Email Address</label></div> <div class="data-column"><div class="data-text" id="viewEmail">williamjones@prototype.com</div></div> </div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">Permissions</div> <div class="box-content top-label transparent no-row-padding"> <div class="row"> <div class="data-column"> <div class="payment-grid" id="viewPermissions" ></div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">Additional Settings</div> <div class="box-content top-label"> <div class="grid-row"> <div class="grid-cell" style="width: 50%;"> <div class="row"> <div class="label-column"><label>Panel Auth Group</label></div> <div class="data-column"><div class="data-text" id="viewPanelGroup">B-Manager</div></div> </div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">Applications</div> <div class="box-content transparent top-label"> <div class="grid-row"> <div class="grid-cell" style="width: 100%;"> <div class="row"> <div class="data-column"> <div class="data-table"> <div class="data-table-row"> <div class="data-table-cell" style="width: 20%;">Application Name</div> <div class="data-table-cell" style="width: 20%;">Application Details</div> </div> <div class="data-table-row"> <div class="data-table-cell">ANZ FX Online</div> <div class="data-table-cell">Contact ANZ for Changes</div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div>';
		$(content).appendTo($dialogContent);
		setTimeout(function() { 
			var grid1;
			var columns1 = [
				{id: "name", name: "Role Name", field: "name",	sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "family", name: "Role Family", field: "family",	sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "description", name: "Role Description", field: "description", sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "division", name: "Division", field: "division", sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "type", name: "Role Type", field: "type", sortable: true,	sorter: "sorterStringCompare",	visible: true}
			];
			var options1 = {
				editable: false,
				autoEdit: false,
				enableCellNavigation: true,
				enableColumnReorder: false,
				enableColumnReorderCheckbox: false,
				syncColumnCellResize: false,
				forceFitColumns: true,
				multiColumnSort: true,
				multiSelect: false,
			};
			var user = searchDataView.getItemById(searchSelectedRowIds);
			var data = user.roles;
			grid1 = new Slick.Grid($('#viewPermissions'), data, columns1, options1);
			grid1.onSort.subscribe(function (e, args) {
			var cols = args.sortCols;
			data.sort(function (dataRow1, dataRow2) {
				for (var i = 0, l = cols.length; i < l; i++) {
				var field = cols[i].sortCol.field;
				var sign = cols[i].sortAsc ? 1 : -1;
				var value1 = dataRow1[field], value2 = dataRow2[field];
				var result = (value1 == value2 ? 0 : (value1 > value2 ? 1 : -1)) * sign;
				if (result != 0) {
					return result;
				}
				}
				return 0;
			});
			grid1.invalidate();
			grid1.render();
			});
			grid1.onClick.subscribe(function(e, args) {
				var cell = grid1.getCellFromEvent(e);
				var row = cell.row;
				var $row = $(e.target).closest(".slick-row");
				triggerRoleDialog($row);
			});
			grid1.init();
		}, 300);

		return $dialogContent;
	}

	var _dialog = {
		id: "userDetailsDialog",
		title: "User Details",
		size: "xxl",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderUserDetailsContent();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function renderSearchUsersGrid() {
	searchData = users;
	searchSelectedRowIds = [];
	searchOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: false,
		headerRowHeight: 40,
		explicitInitialization: true
	};
	searchColumns = [{
		id: "userid",
		name: "User ID",
		field: "userid",
		tooltip: "User ID",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "firstname",
		name: "First Name",
		field: "firstname",
		tooltip: "First Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "lastname",
		name: "Last Name",
		field: "lastname",
		tooltip: "Last Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "id",
		name: "User Details",
		field: "id",
		sortable: false,
		width: 120,
		resizable: false,
		headerCssClass: "centered",
		cssClass: "centered",
		formatter: viewFormatter = function(row, cell, value, columnDef, dataContext) {
			return "<button data-action='view-user-details' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba; cursor: pointer;' id='"+value+"'><i class='fa fa-file-text fa-fw'></i></button>";
		}
	}];
	var searchItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	searchDataView = new Slick.Data.DataView({
		searchItemMetaProvider: searchItemMetaProvider
	});
	searchGrid = new Slick.Grid("#selectUserGrid", searchDataView, searchColumns, searchOptions);
	searchGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	searchGrid.registerPlugin(searchItemMetaProvider);
	searchGrid.onSelectedRowsChanged.subscribe(function(e) {
		searchSelectedRowIds = [];
		var rows = searchGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = searchDataView.getItem(rows[i])
			if (item.id) {
				searchSelectedRowIds.push(item.id);
			}
		}
	});
	searchGrid.onClick.subscribe(function(e, args) {
		var cell = searchGrid.getCellFromEvent(e);
		var row = cell.row;
	});
	searchGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		searchDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});  
	searchDataView.onRowCountChanged.subscribe(function(e, args) {
		searchGrid.updateRowCount();
		searchGrid.render();
	});
	searchDataView.onRowsChanged.subscribe(function(e, args) {
		searchGrid.invalidateRows(args.rows);
		searchGrid.render();
		if (searchSelectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < searchSelectedRowIds.length; i++) {
				var idx = searchDataView.getRowById(searchSelectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			searchGrid.setSelectedRows(selRows);
		}
	});
	searchDataView.beginUpdate();
	searchDataView.setItems(searchData);
	searchDataView.syncGridSelection(searchGrid, true, false);
	searchDataView.syncGridCellCssStyles(searchGrid, "contextMenu");
	searchDataView.endUpdate();
	searchGrid.setColumns(searchColumns);
	$('#selectUserGrid').on("click", "button[data-action='view-user-details']", function(e) {
		var $target = $("#"+$(this).attr("id"));
		var itemID = $target.attr("id");
		renderUserDetailsDialog($target, searchDataView.getItemById(itemID));
		return false;
	});
	setTimeout(function(){
		$("#searchUsers").removeClass("loading");
		searchGrid.init();
		$(window).on('resize.searchgrid', function() {
			searchGrid.resizeCanvas();
		});
	}, 500);
}

function copyFromUser(e) {
	var selectedUser = searchDataView.getItemById(searchSelectedRowIds);
	if ( selectedUser.roles.length == 1 ) {
		setupRolePermissions($(e.target), 'new');
	} else {
		$("#searchUsers").addClass("working");
		setTimeout(function(){
			addRoles()
		}, 500);
	}
}

function searchUsersDialog(e) {

	e.preventDefault();

	var _target = $(this);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderSearchUserContent = function() {
		var $dialogContent = $("<div id='searchUsersDialogContent' />");
		var $wrapper = $("<div class='wrapper' />").appendTo($dialogContent),
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #bfc0c0; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='searchUsersFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Search...' />").on("keyup", function() {
				if (e.which == 27) {
					this.value = "";
				}
				searchList = $.trim(this.value.toLowerCase()).split(' ');
				searchDataView.setFilter(searchGridFilter); 
				searchGrid.invalidate();
				this.focus();
				if (this.value != '') {
					$("#clearUserFilter").show()
				} else {
					$("#clearUserFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearUserFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#searchUsersFilterInput").val('').trigger("keyup");
				$(this).hide();
			}).appendTo($searchDiv);
		var $selectUserGrid = $("<div id='selectUserGrid' style='position: absolute; top: 51px; right: 0; bottom: 0; left: 0;' />").appendTo($dialogContent);

		return $dialogContent;
	}

	var _dialog = {
		id: "searchUsers",
		title: "Select A User",
		size: "xxl",
		icon: "<i class='fa fa-search'></i>",
		content: function() {
			return renderSearchUserContent();
		},
		hasgrid: function() {
			return destroyDialogSearchGrid()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Copy From User",
			icon: "<i class='fa fa-copy fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					copyFromUser(e);
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#searchUsers").addClass("loading");
	renderSearchUsersGrid();
	$("#searchUsersFilterInput").focus();
}

function renderRoleDetailsDialog(el, item) {

	var _target = $(el);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderRoleDetailsContent = function() { 

		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='roleDetailsDialogContent' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 15%;' />").appendTo($detailRow);
		var $icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell);
		var $detailCell = $("<div class='grid-cell' style='width: 85%; padding-top: 40px' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
				
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Division</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $customSelect = $("<div class='data-text'>Division 1</div>").appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Internation Payments</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Payment Purpose</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="checkbox" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox" disabled="disabled" name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Approval Discretions</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($dataRow);
		var	$boxContent = $("<div class='box-content top-label' style='width: 90%; background: #f8f8f8' id='approvaldis' />").appendTo($dataCol);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Daily</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $inputDiv = $("<div class='data-text'>AUD 50,000.00</div>").appendTo($dataCol);
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Batch</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $inputDiv = $("<div class='data-text'>AUD 50,000.00</div>").appendTo($dataCol);
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Transaction</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $inputDiv = $("<div class='data-text'>AUD 50,000.00</div>").appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Operating Accounts</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Deposits</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
			
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);

		return $dialogContent;
	}

	var _dialog = {
		id: "roleDetailsDialog",
		title: "Role Details",
		size: "xxl",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderRoleDetailsContent();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Add &amp; Configure This Role",
			icon: "<i class='fa fa-plus-square fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					setupRolePermissions($(e.target), 'new');
					dialogHider(_dialog);
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function renderSearchRolesGrid() {
	searchData = roles;
	searchSelectedRowIds = [];
	searchOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: false,
		headerRowHeight: 40,
		explicitInitialization: true
	};
	searchColumns = [{
		id: "name",
		name: "Role Name",
		field: "name",
		tooltip: "Role Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "family",
		name: "Role Family",
		field: "family",
		tooltip: "Role Family",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "description",
		name: "Role Description",
		field: "description",
		tooltip: "Role Description",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "division",
		name: "Division",
		field: "division",
		tooltip: "Division",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "type",
		name: "Role Type",
		field: "type",
		tooltip: "Role Type",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}];
	var searchItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	searchDataView = new Slick.Data.DataView({
		searchItemMetaProvider: searchItemMetaProvider
	});
	searchGrid = new Slick.Grid("#selectRoleGrid", searchDataView, searchColumns, searchOptions);
	searchGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	searchGrid.registerPlugin(searchItemMetaProvider);
	searchGrid.onSelectedRowsChanged.subscribe(function(e) {
		searchSelectedRowIds = [];
		var rows = searchGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = searchDataView.getItem(rows[i])
			if (item.id) {
				searchSelectedRowIds.push(item.id);
			}
		}
	});
	searchGrid.onClick.subscribe(function(e, args) {
		var cell = searchGrid.getCellFromEvent(e);
		var row = cell.row;
	});
	searchGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		searchDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});  
	searchDataView.onRowCountChanged.subscribe(function(e, args) {
		searchGrid.updateRowCount();
		searchGrid.render();
	});
	searchDataView.onRowsChanged.subscribe(function(e, args) {
		searchGrid.invalidateRows(args.rows);
		searchGrid.render();
		if (searchSelectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < searchSelectedRowIds.length; i++) {
				var idx = searchDataView.getRowById(searchSelectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			searchGrid.setSelectedRows(selRows);
		}
	});
	searchDataView.beginUpdate();
	searchDataView.setItems(searchData);
	searchDataView.syncGridSelection(searchGrid, true, false);
	searchDataView.syncGridCellCssStyles(searchGrid, "contextMenu");
	searchDataView.endUpdate();
	searchGrid.setColumns(searchColumns);
	setTimeout(function(){
		$("#searchExistingRoles").removeClass("loading");
		searchGrid.init();
		$(window).on('resize.searchgrid', function() {
			searchGrid.resizeCanvas();
		});
	}, 500);
}

function addRoles() {

	var selected = searchDataView.getItemById(searchSelectedRowIds);
	var addedRoles = [];
	var alreadyAdded = false;

	if (selected.record == "Role") {
		for ( var i = 0, l = userAssignedRoles.length; i < l; i++ ) {
			if ( userAssignedRoles[i].id == selected.id ) {
				alreadyAdded = true;
				break;
			}
		}

		if (!alreadyAdded) {
			addedRoles.push(selected);
		}

	} else if (selected.record == "User") {
		for ( var i = 0, l = selected.roles.length; i < l; i++) {
			for ( var a = 0, b = userAssignedRoles.length; a < b; a++) {
				if ( selected.roles[i].id == userAssignedRoles[a].id ) {
					alreadyAdded = true;
					break;
				}
			}
			if (alreadyAdded) {
				break;
			} else {
				addedRoles.push(selected.roles[i]);
			}
		}

	}
	$("#saveRolePermissionSettings").addClass("working");

	setTimeout(function() {

		if (alreadyAdded) {
			if (selected.record == "Role") {
				$("#saveRolePermissionSettings").removeClass("working");
			} else if (selected.record == "User") {
				if (addedRoles.length == 1) {
					$("#searchUsers").removeClass("working");
				} else {
					$("#saveRolePermissionSettings").removeClass("working");
				}
			}
			buildErrorNotification("Errors Were Detected", "The selected role has already been added for this user.", 300);
		} else {
			dialogHider( {id: "saveRolePermissionSettings"} );
			if (selected.record == "Role") {
				dialogHider( {id: "searchExistingRoles", hasgrid: function() {return destroyDialogSearchGrid()}});
			} else if (selected.record == "User") {
				dialogHider( {id: "searchUsers", hasgrid: function() {return destroyDialogSearchGrid()}});
			}
			for (var i = 0, l = addedRoles.length; i < l; i++) {
				userAssignedRoles.push(addedRoles[i]);
			}
			if (grid == null) {
				renderAssignedRolesGrid();
			} else {
				rolesData = userAssignedRoles;
				rolesDataView.setItems(rolesData);
				rolesDataView.refresh();
				rolesGrid.invalidate();
				rolesGrid.render();
			}
			searchGrid.setSelectedRows([]);
			roleAddedConfirmation(addedRoles);
		}
	}, 1000);
}

function searchRoleDialog(e) {

	e.preventDefault();

	var _target = $(this);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderSearchRolesContent = function() {
		var $dialogContent = $("<div id='searchRolesDialogContent' />");
		var $wrapper = $("<div class='wrapper' />").appendTo($dialogContent),
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #bfc0c0; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='searchRolesFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Search...' />").on("keyup", function() {
				if (e.which == 27) {
					this.value = "";
				}
				searchList = $.trim(this.value.toLowerCase()).split(' ');
				searchDataView.setFilter(searchGridFilter); 
				searchGrid.invalidate();
				this.focus();
				if (this.value != '') {
					$("#clearRolesFilter").show()
				} else {
					$("#clearRolesFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearRolesFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#searchRolesFilterInput").val('').trigger("keyup");
				$(this).hide();
			}).appendTo($searchDiv);
		var $selectRoleGrid = $("<div id='selectRoleGrid' style='position: absolute; top: 51px; right: 0; bottom: 0; left: 0;' />").appendTo($dialogContent);

		return $dialogContent;
	}

	var _dialog = {
		id: "searchExistingRoles",
		title: "Select A Role",
		size: "xxl",
		icon: "<i class='fa fa-search'></i>",
		content: function() {
			return renderSearchRolesContent();
		},
		hasgrid: function() {
			return destroyDialogSearchGrid()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Continue",
			icon: "<i class='fa fa-chevron-circle-right fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					setupRolePermissions($(e.target), 'new');
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#searchExistingRoles").addClass("loading");
	renderSearchRolesGrid();
	$("#searchRolesFilterInput").focus();
}

function roleAddedConfirmation(roles) {
	var msg;
	if (roles.length == 1) {
		msg = "<strong>The follwing permission has been added to this user:</strong>";
	} else {
		msg = "<strong>The follwing permissions have been added to this user:</strong>";
	}
	msg = msg + "<span style='display: block; color: #007dba; margin-top: 30px;'>";
	$.each(roles, function(){ msg = msg + this.name+'<br />'});
	msg = msg + "</span>";
	setTimeout(function(){
		buildConfirmDialog(msg, "You can <strong>change the settings account access</strong> for a permission by clicking on the <strong>Edit Permission</strong> icon in the User Permission table.", "");
	}, 300);
}

function removeAssignedRoles() {
	if (rolesSelectedRowIds.length >= 1) {
		var $shell = $(".shell");
		$shell.addClass("loading");
		var reloadAddedRolesGrid = function() {
			rolesGrid.setSelectedRows(0);
			rolesSelectedRowIds = [];
			rolesDataView.refresh();
			rolesGrid.invalidate();
			rolesGrid.render();
			if (!rolesGrid.getDataLength()) {
				$("#removeAddedRolesButton").addClass("disabled").off("click");
				rolesGrid.destroy();
				rolesGrid = null;
				$('#permissionGrid').off("click.editRole");
				var $noPermissions = $("<div class='loading-text'>This user has no assigned roles</div>").appendTo($("#permissionGrid"));
			}
			$shell.removeClass("loading");
		}
		setTimeout(function() {
			var rowsForDelete = [];
			for (var i = 0, l = rolesSelectedRowIds.length; i < l; i++) {
				var item = rolesSelectedRowIds[i];
				if (item) rowsForDelete.unshift(item)
			};
			for (var i = 0; i < rowsForDelete.length; i++) {
				rolesDataView.deleteItem(rowsForDelete[i])
			};
			reloadAddedRolesGrid();	
		}, 500);
	} else {
		return false;
	}
}

function renderAssignedRolesGrid() {

	rolesData = userAssignedRoles;
	rolesSelectedRowIds = [];
	rolesOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: false,
		explicitInitialization: true
	};
	rolesColumns = [{
		id: "name",
		name: "Role Name",
		field: "name",
		tooltip: "Role Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "family",
		name: "Role Family",
		field: "family",
		tooltip: "Role Family",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "description",
		name: "Role Description",
		field: "description",
		tooltip: "Role Description",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "division",
		name: "Division",
		field: "division",
		tooltip: "Division",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "type",
		name: "Role Type",
		field: "type",
		tooltip: "Role Type",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "id",
		name: "Role Details",
		field: "id",
		sortable: false,
		width: 120,
		resizable: false,
		headerCssClass: "centered",
		cssClass: "centered",
		formatter: viewFormatter = function(row, cell, value, columnDef, dataContext) {
			return "<button data-action='edit-role-details' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba; cursor: pointer;' data-id='"+value+"'><i class='fa fa-pencil-square-o fa-fw'></i></button>";
		}
	}];

	var rolesCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	rolesColumns.unshift(rolesCheckboxSelector.getColumnDefinition());

	var rolesItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	rolesDataView = new Slick.Data.DataView({
		rolesItemMetaProvider: rolesItemMetaProvider
	});
	rolesGrid = new Slick.Grid("#permissionGrid", rolesDataView, rolesColumns, rolesOptions);
	rolesGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	rolesGrid.registerPlugin(rolesCheckboxSelector);
	rolesGrid.registerPlugin(rolesItemMetaProvider);
	rolesGrid.onSelectedRowsChanged.subscribe(function(e) {
		rolesSelectedRowIds = [];
		var rows = rolesGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = rolesDataView.getItem(rows[i])
			if (item.id) {
				rolesSelectedRowIds.push(item.id);
			}
		}
	});
	rolesGrid.onClick.subscribe(function(e, args) {
		var cell = rolesGrid.getCellFromEvent(e);
		var row = cell.row;
	});
	rolesGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		rolesDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});   
	rolesDataView.onRowCountChanged.subscribe(function(e, args) {
		rolesGrid.updateRowCount();
		rolesGrid.render();
	});
	rolesDataView.onRowsChanged.subscribe(function(e, args) {
		rolesGrid.invalidateRows(args.rows);
		rolesGrid.render();
		if (rolesSelectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < rolesSelectedRowIds.length; i++) {
				var idx = rolesDataView.getRowById(rolesSelectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			rolesGrid.setSelectedRows(selRows);
		}
	});
	rolesDataView.beginUpdate();
	rolesDataView.setItems(userAssignedRoles);
	rolesDataView.syncGridSelection(rolesGrid, true, false);
	rolesDataView.syncGridCellCssStyles(rolesGrid, "contextMenu");
	rolesDataView.endUpdate();
	rolesGrid.setColumns(rolesColumns);
	$(window).on("resize.rolesgrid", function() {
		rolesGrid.resizeCanvas();
	});
	$(window).on("resize.rolesgrid", _.debounce(function(e) {
		rolesGrid.resizeCanvas();
	}, 100));
	$('#permissionGrid').on("click.editRole", "button[data-action='edit-role-details']", function(e) {
		var $target = $(this);
		var itemID = $target.attr("data-id");
		setupRolePermissions($target, 'edit');
		return false;
	});
	rolesGrid.init();
	$("#removeAddedRolesButton").removeClass("disabled").on("click", removeAssignedRoles);
}



/**********************************************************************
VIEW / EDIT
**********************************************************************/
function viewRecord() {

	updateBreadcrumb("view");

	$("#userDetailScreen").empty();

	var $userContainer = $("#userDetailScreen");

	userAssignedRoles = [{
		id: "roleid1",
		record: "Role",
		name: "Create & Approve",
		family: "Commercial Cards",
		description: "Role description should appear here...",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid2",
		record: "Role",
		name: "Authorised Signatory",
		family: "Cash Management",
		description: "Role description should appear here...",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid3",
		record: "Role",
		name: "Approver",
		family: "Cash Management",
		description: "Role description should appear here...",
		division: "Division 1",
		type: "System"
	}];

	/* top controls */
	var $topControls = $("<div class='top-controls' />");
	var $btnList = $("<div class='control-list' />").appendTo($topControls);
	var $actionBtns = $("<div class='btn-group' />").appendTo($btnList);
	var $editBtn = $("<span class='btn'><a href='javascript:void(0)' title='Edit the record'><i class='fa fa-pencil-square-o fa-fw text-right'></i><span>Edit</span></a></span>").on("click", function(e){
		e.preventDefault();
		var $target = $(e.target);
		$target.attr({
			'data-panel': '#userDetailScreen',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		editRecord();
	});
	var $deleteBtn = $("<span class='btn'><a href='javascript:void(0)' title='Delete the record'><i class='fa fa-trash fa-fw text-right'></i><span>Delete</span></a></span>");
	var $enableBtn = $("<span class='btn'><a href='javascript:void(0)' title='Enable the record'><i class='fa fa-unlock-alt fa-fw text-right'></i><span>Enable</span></a></span>");
	var $disableBtn = $("<span class='btn'><a href='javascript:void(0)' title='Disable the record'><i class='fa fa-lock fa-fw text-right'></i><span>Disable</span></a></span>");
	var $approveBtn = $("<span class='btn'><a href='javascript:void(0)' title='Approve the record'><i class='fa fa-check-square fa-fw text-right pos'></i><span>Approve</span></a></span>");
	var $rejectBtn = $("<span class='btn'><a href='javascript:void(0)' title='Reject the record'><i class='fa fa-window-close fa-fw text-right neg'></i><span>Reject</span></a></span>");
	var $passwordBtn = $("<span class='btn'><a href='javascript:void(0)' title='Generate Password'><i class='fa fa-key fa-fw text-right'></i><span>Generate Password</span></a></span>");
	var $auditBtn = $("<span class='btn'><a href='javascript:void(0)' title='View audit history'><i class='fa fa-calendar fa-fw text-right'></i><span>View Audit History</span></a></span>").on("click", showAuditHistoryDialog);
	var $reportsBtn = $("<span class='btn has-menu'><a href='#reportMenu' title='Reports'><i class='fa fa-file-text fa-fw text-right'></i><span>Reports</span><i class='fa fa-caret-down fa-fw menu-arrow'></i></a></span>").on("click", controlMenuManager);
	if (record.status == "Active") {
		if (record.workflow == "Approved") {
			$editBtn.appendTo($actionBtns);
			$deleteBtn.appendTo($actionBtns);
			$disableBtn.appendTo($actionBtns);
			$passwordBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval – Delete") {
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval - Disable") {
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval – Modify") {
			$editBtn.appendTo($actionBtns);
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval – Register") {
			$editBtn.appendTo($actionBtns);
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		}
	} else if (record.status == "Disabled") {
		if (record.workflow == "Approved") {
			$editBtn.appendTo($actionBtns);
			$deleteBtn.appendTo($actionBtns);
			$enableBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval - Delete") {
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval – Enable") {
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		} else if (record.workflow == "Pending Approval – Modify") {
			$editBtn.appendTo($actionBtns);
			$approveBtn.appendTo($actionBtns);
			$rejectBtn.appendTo($actionBtns);
			$auditBtn.appendTo($actionBtns);
			$reportsBtn.appendTo($actionBtns);
		}
	}
	var $navBtns = $("<div class='btn-group' />").appendTo($btnList);
	var $closeBtn = $("<span class='btn'><a href='#usersGrid' title='Close Record' data-action='close' data-panel='#usersGrid' data-switch='switch-panels'><i class='fa fa-times fa-fw text-right'></i><span>Close</span></a></span>").appendTo($navBtns).on("click", function(e){
		e.preventDefault();
		record = null;
		$("#userDetailScreen").empty();
		$(window).off("resize.rolesgrid");
		updateBreadcrumb("close");
	});
	var $prevBtn = $("<span class='btn'><a href='#previousRecord' title='Previous Record'><i class='fa fa-chevron-left fa-fw text-right'></i><span>Previous Record</span></a></span>").appendTo($navBtns);
	var $prevBtn = $("<span class='btn'><a href='#nextRecord' title='Next Record'><i class='fa fa-chevron-right fa-fw text-right'></i><span>Next Record</span></a></span>").appendTo($navBtns);
	$topControls.appendTo($userContainer);


	/* form container */
	var $formContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; background: #f5f5f5;' />");
	var $gridLayout = $("<div class='grid-layout' />").appendTo($formContainer);


	/* record header details */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxContent = $("<div class='box-content' />").appendTo($box);

	if ( record.workflow.indexOf("Pending") != -1 ) {
		var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
		var $row = $("<div class='row' />").appendTo($boxCell);
		var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
		var $pendingDiv = $("<div style='padding: 20px; width: 70%; margin: 0 auto; text-align: center; border: 1px solid #EB8C2D; background: #FEF0E3; border-radius: 2px; -mox-border-radius: 2px; -webkit-border-radius: 2px; font-size: 14px; color: #4a494a;' />").appendTo($dataCol);
		var $pendingIcon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #EB8C2D; margin-right: 5px;'></i>").appendTo($pendingDiv);
		var $pendingText = $("<span style='margin-right: 5px;'>This user record is pending approval.</span>").appendTo($pendingDiv);
		var $pendingLink = $("<a href='javascript:void(0)' style='color: #007dba; text-decoration: none;'>Click here</a>").appendTo($pendingDiv).on("click", showAuditHistoryDialog);;
		var $pendingText = $("<span style='margin-left: 5px;'>to view audit information.</span>").appendTo($pendingDiv);
	}


	var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $boxCell = $("<div class='grid-cell' />").appendTo($boxRow);
	var $headerContainer = $("<div class='header-style-1' />").appendTo($boxCell);
	var $leftHeader = $("<div style='display: table-cell; padding-top: 15px; width: 50%; vertical-align: middle;' />").appendTo($headerContainer);
	var $iconDiv = $("<div style='display: inline-block; padding: 0 10px 0 20px; vertical-align: middle;' />").appendTo($leftHeader);
	var $icon = $("<i class='fa fa-user-circle fa-fw fa-5x'></i>").appendTo($iconDiv);
	var $detailDiv = $("<div style='display: inline-block; vertical-align: middle;' />").appendTo($leftHeader);
	var $userID = $("<div style='font-size: 24px; color: #017dba;overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>"+record.userid+"</div>").appendTo($detailDiv);
	var $status = $("<div style='margin-top: 2px; color: #484848;overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>Status: <span>"+record.status+"<span></div>").appendTo($detailDiv);
	var $rightHeader = $("<div style='display: table-cell; padding-top: 15px; width: 50%; padding-right: 30px; vertical-align: middle; overflow: hidden; text-align: right;' />").appendTo($headerContainer);
	var $table = $("<table style='color: #484848; font-size: 14px; table-layout: fixed; float: right;' />").appendTo($rightHeader);
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>Workflow</td>").appendTo($tr);
	var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.workflow +"</td>").appendTo($tr);
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>Credential Type</td>").appendTo($tr);
	if (record.usercredential == "Password") {
		var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.usercredential +"</td>").appendTo($tr);
	} else {
		var $td = $("<td style='padding: 1px 0 1px 10px;'></td>").appendTo($tr);
		var $anchor = $("<a href='javascript:void(0)' style='color: #007dba; text-decoration: none;'>" + record.usercredential + " <i class='fa fa-calculator fa-fw'></i></a>").appendTo($td).on("click", showSecurityDeviceDetails);
	}
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>Managed By</td>").appendTo($tr);
	var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.managedby +"</td>").appendTo($tr);
	/*
	is user type needed?
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>User Type</td>").appendTo($tr);
	var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.usertype +"</td>").appendTo($tr);
	*/

	/* user details */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>User Details</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $boxCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>First Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.firstname+"</div>").appendTo($dataCol);
	var $boxCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Last Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.surname+"</div>").appendTo($dataCol);
	var $boxCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Preferred Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.preferredname+"</div>").appendTo($dataCol);
	var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $boxCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Email Address</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.email+"</div>").appendTo($dataCol);
	var $boxCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>User ID</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.userid+"</div>").appendTo($dataCol);
	var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $boxCell = $("<div class='grid-cell' style='width: 67%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Address</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'><span>"+record.address1+"</span>, <span>"+record.address2+"</span>, <span>"+record.city+"</span>, <span>"+record.state+"</span>, <span>"+record.postal+"</span>, <span>"+record.country+"</span></div>").appendTo($dataCol);
	var $boxCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxRow);
	var $row = $("<div class='row' />").appendTo($boxCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Mobile Number</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.phone.country+" "+record.phone.number+"</div>").appendTo($dataCol);

	/* user permissions */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>User Permissions</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
	var $row = $("<div class='row' />").appendTo($boxContent);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $permissionGrid = $("<div class='payment-grid' id='viewPermissions' />").appendTo($dataCol);

	/* additional settings */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Additional Settings</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $row = $("<div class='row' />").appendTo($boxContent);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Panel Auth Group</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+record.panelauthgroup+"</div>").appendTo($dataCol);

	/* user applications */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Applications</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
	var $row = $("<div class='row' />").appendTo($boxContent);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $dataTable = $("<div class='data-table' style='table-layout: fixed;' />").appendTo($dataCol);
	var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Application Name</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Application Status</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Application Details</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Actions <i class='fa fa-info-circle fa-fw fa-lg' style='color: #007dba;' title='Clicking on Edit / View will navigate you to the ANZ Transactive - AU / NZ application for modification of entitlements.'></i></div>").appendTo($dataTableRow);
	var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
	var $dataTableCell = $("<div class='data-table-cell'>ANZ Transactive AU - NZ</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'>Assigned</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'><div><strong>User Group Name:</strong>ACME Group 1</div><div><strong>User Group ID:</strong> 01TEM:SET</div><div><strong>Transactive User ID:</strong> SMITJACM</div></div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='vertical-align: middle;'></div>").appendTo($dataTableRow);
	var $appEditViewBtn = $("<span class='form-button'><a href='javascript:void(0)'>Edit / View</a></span>").appendTo($dataTableCell);
	var $unassignBtn = $("<span class='form-button'><a href='javascript:void(0)'>Unassign</a></span>").appendTo($dataTableCell);
	var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
	var $dataTableCell = $("<div class='data-table-cell'>ANZ Transactive Global</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'>Assigned</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'></div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='vertical-align: middle;'></div>").appendTo($dataTableRow);


	$formContainer.appendTo($userContainer);





	var grid1;
	columns1 = [{
		id: "name",
		name: "Role Name",
		field: "name",
		tooltip: "Role Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "family",
		name: "Role Family",
		field: "family",
		tooltip: "Role Family",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "description",
		name: "Role Description",
		field: "description",
		tooltip: "Role Description",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "division",
		name: "Division",
		field: "division",
		tooltip: "Division",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "type",
		name: "Role Type",
		field: "type",
		tooltip: "Role Type",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "id",
		name: "Role Details",
		field: "id",
		sortable: false,
		width: 120,
		resizable: false,
		headerCssClass: "centered",
		cssClass: "centered",
		formatter: viewFormatter = function(row, cell, value, columnDef, dataContext) {
			return "<button data-action='view-role-details' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba; cursor: pointer;' data-id='"+value+"'><i class='fa fa-file-text fa-fw'></i></button>";
		}
	}];
	var options1 = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnReorderCheckbox: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: false,
		explicitInitialization: true
	};
	var data1 = userAssignedRoles;
	grid1 = new Slick.Grid($('#viewPermissions'), data1, columns1, options1);
	grid1.onSort.subscribe(function (e, args) {
		var cols = args.sortCols;
		data.sort(function (dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				var field = cols[i].sortCol.field;
				var sign = cols[i].sortAsc ? 1 : -1;
				var value1 = dataRow1[field], value2 = dataRow2[field];
				var result = (value1 == value2 ? 0 : (value1 > value2 ? 1 : -1)) * sign;
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		grid1.invalidate();
		grid1.render();
	});
	grid1.onClick.subscribe(function(e, args) {
		var cell = grid1.getCellFromEvent(e);
		var row = cell.row;
	});

	$('#viewPermissions').on("click.editRole", "button[data-action='view-role-details']", function(e) {
		e.preventDefault();
		function triggerRoleDialog(_target) {

			function viewRole() { 
				var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");
				var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxContent = $("<div class='box-content left-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 11%;' />").appendTo($detailRow),
				$icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell),
				$detailCell = $("<div class='grid-cell' style='width: 88%;padding-top: 40px' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow),
				$label = $("<label >Role Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow),
				$label = $("<label >Role Description</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Division</div>").appendTo($box),
				$boxContent = $("<div class='box-content left-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px' />").appendTo($dataRow),
				$label = $("<label>Select a Division</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow);
				$('<div class="custom-select" style="max-width: 100%;"><select id="divisionSelection" disabled="disabled" style="min-width: 250px;"><option value="Customer Division 1">Customer Division 1</option><option value="Customer Division 2">Customer Division 2</option><option value="Customer Division 3">Customer Division 3</option></select></div>').appendTo($dataCol)
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box),
				$boxContent = $("<div class='box-content left-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>Internation Payments</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>Payment Purpose</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="checkbox" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox" disabled="disabled" name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);					
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>Approval Discretions</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
				var	$boxContent = $("<div class='box-content top-label' style='width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($boxContent),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell);
				$('<div id="approvaldis" style="background: #f8f8f8"> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box),
				$boxContent = $("<div class='box-content left-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>Operating Accounts</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>Deposits</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box),
				$boxContent = $("<div class='box-content left-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
				$label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
				return $dialogContent;
			}

			var _origin = (_target) ? _target : $("#viewPermissions");
			
			var _dialog = {
				id: "roleDialog",
				title: "View Permission",
				size: "xwide",
				icon: "<i class='fa fa-file-text'></i>",
				content: function() {
					return viewRole()
				},
				buttons: [{
					name: "Close",
					icon: "<i class='fa fa-close fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}	
		triggerRoleDialog();
		return false;
	});

	grid1.init();

	$(window).bind("resize.rolesgrid", function() {
		grid1.resizeCanvas();
	});
	$(window).on("resize.rolesgrid", _.debounce(function(e) {
		grid1.resizeCanvas();
	}, 100));	

}

function editRecord() {

	var editRecord = jQuery.extend(true, {}, record);

	userAssignedRoles = [{
		id: "roleid1",
		record: "Role",
		name: "Create & Approve",
		family: "Commercial Cards",
		description: "Role description should appear here...",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid2",
		record: "Role",
		name: "Authorised Signatory",
		family: "Cash Management",
		description: "Role description should appear here...",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid3",
		record: "Role",
		name: "Approver",
		family: "Cash Management",
		description: "Role description should appear here...",
		division: "Division 1",
		type: "System"
	}];


	updateBreadcrumb("edit");

	$("#userDetailScreen").empty();
	
	var $userContainer = $("#userDetailScreen");

	/* top controls */
	var $topControls = $("<div class='top-controls' />");
	var $btnList = $("<div class='control-list' />").appendTo($topControls);
	var $actionBtns = $("<div class='btn-group' />").appendTo($btnList);
	var $closeBtn = $("<span class='btn'><a href='#usersGrid' title='Close Record' data-action='close' data-panel='#usersGrid' data-switch='switch-panels'><i class='fa fa-times fa-fw text-right'></i><span>Close</span></a></span>").appendTo($actionBtns).on("click", function(e){
		e.preventDefault();
		record = null;
		$("#userDetailScreen").empty();
		$(window).off("resize.rolesgrid");
		updateBreadcrumb("close");
	});
	var $saveBtn = $("<span class='btn'><a href='javascript:void(0)' title='Save the record'><i class='fa fa-save fa-fw text-right'></i><span>Save</span></a></span>").appendTo($actionBtns);
	$topControls.appendTo($userContainer);	

	/* form container */
	var $formContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; background: #f5f5f5;' />");
	var $gridLayout = $("<div class='grid-layout' />").appendTo($formContainer);


	/* record header details */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxContent = $("<div class='box-content' />").appendTo($box);
	var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $boxCell = $("<div class='grid-cell' />").appendTo($boxRow);
	var $headerContainer = $("<div class='header-style-1' />").appendTo($boxCell);
	var $leftHeader = $("<div style='display: table-cell; padding-top: 15px; width: 50%; vertical-align: middle;' />").appendTo($headerContainer);
	var $iconDiv = $("<div style='display: inline-block; padding: 0 10px 0 20px; vertical-align: middle;' />").appendTo($leftHeader);
	var $icon = $("<i class='fa fa-user-circle fa-fw fa-5x'></i>").appendTo($iconDiv);
	var $detailDiv = $("<div style='display: inline-block; vertical-align: middle;' />").appendTo($leftHeader);
	var $userID = $("<div style='font-size: 24px; color: #017dba;overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>"+record.userid+"</div>").appendTo($detailDiv);
	var $status = $("<div style='margin-top: 2px; color: #484848;overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>Status: <span>"+record.status+"<span></div>").appendTo($detailDiv);
	var $rightHeader = $("<div style='display: table-cell; padding-top: 15px; width: 50%; padding-right: 30px; vertical-align: middle; overflow: hidden; text-align: right;' />").appendTo($headerContainer);
	var $table = $("<table style='color: #484848; font-size: 14px; table-layout: fixed; float: right;' />").appendTo($rightHeader);
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>Workflow</td>").appendTo($tr);
	var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.workflow +"</td>").appendTo($tr);
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>Credential Type</td>").appendTo($tr);
	if (record.usercredential == "Password") {
		var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.usercredential +"</td>").appendTo($tr);
	} else {
		var $td = $("<td style='padding: 1px 0 1px 10px;'></td>").appendTo($tr);
		var $anchor = $("<a href='javascript:void(0)' style='color: #007dba; text-decoration: none;'>" + record.usercredential + " <i class='fa fa-calculator fa-fw'></i></a>").appendTo($td).on("click", showSecurityDeviceDetails);
	}
	var $tr = $("<tr style='vertical-align: middle;' />").appendTo($table);
	var $td = $("<td style='text-align: right; padding: 1px 0; font-weight: bold;'>Managed By</td>").appendTo($tr);
	var $td = $("<td style='padding: 1px 0 1px 10px;'>"+ record.managedby +"</td>").appendTo($tr);



	/* the user details section */
	var $gridRow = $("<div class='grid-row' id='userDetails' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>User Details</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>First Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='firstName' value='"+editRecord.firstname+"' />").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Last Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='lastName' value='"+editRecord.surname+"' />").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Preferred Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='preferredName' value='"+editRecord.preferredname+"' />").appendTo($dataCol);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>E-mail Address</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='userEmail' value='"+editRecord.email+"'/>").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>User ID</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text' id='userID' />").appendTo($dataCol);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 67%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Address</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 90%; max-width: 90%;' />").appendTo($dataCol);
	var $select = $("<select id='userAddress' ><option value=''>Please choose a delivery address</option><option value='new'>+ Add New delivery address</option><option value='address1'>Level 12, 530 Collins Street, Melbourne, Australia, Victoria, 3000</option></select>").appendTo($customSelect);
	var $note = $("<div class='data-note'>Please choose the users physical address as this will be used to deliver physical security devices.</div>").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Phone Number</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 60px;' id='phoneCountryCode' value='"+editRecord.phone.country+"' maxlength='4' />").appendTo($dataCol);
	var $data = $("<input type='text' style='width: 55%;' id='phoneNumber' value='"+editRecord.phone.number+"' maxlength='15' />").appendTo($dataCol);

	/* the user permissions section */
	var $gridRow = $("<div class='grid-row' id='userPermissions' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>User Permissions</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $row = $("<div class='row' style='padding-bottom: 15px;' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $btnSpan = $("<span class='btn' style='max-width: 300px !important;' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)' data-type='copy'><i class='fa fa-copy fa-fw text-right'></i><span>Copy Permissions from Another User</span></a>").appendTo($btnSpan).on("click", searchUsersDialog);
	var $btnSpan = $("<span class='btn' style='max-width: 300px !important;' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)' data-type='select'><i class='fa fa-plus-square fa-fw text-right'></i><span>Add Permissions</span></a>").appendTo($btnSpan).on("click", searchRoleDialog);
	var $btnSpan = $("<span class='btn' style='max-width: 300px !important;' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)'><i class='fa fa-edit fa-fw text-right'></i><span>Create a New Role</span></a>").appendTo($btnSpan).on("click", createNewRoleDialog);
	var $btnSpan = $("<span class='btn disabled' style='max-width: 300px !important;' id='removeAddedRolesButton' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)'><i class='fa fa-trash fa-fw text-right'></i><span>Remove Roles</span></a>").appendTo($btnSpan);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $row = $("<div class='row' style='padding: 0;' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column full' id='searchRoleSection' style='display: none; border-top: 1px solid #cdcdcd;' />").appendTo($row);

	/* added roles */
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%; border-top: 1px solid #cdcdcd;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);
	var $permissionGrid = $("<div class='payment-grid' id='permissionGrid' />").appendTo($dataCol);
	var $noPermissions = $("<div class='loading-text'>This user has no assigned roles</div>").appendTo($permissionGrid);

	/* additional settings */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Additional Settings</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $row = $("<div class='row' />").appendTo($boxContent);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Panel Auth Group</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>"+editRecord.panelauthgroup+"</div>").appendTo($dataCol);

	/* user applications */
	var $gridRow = $("<div class='grid-row' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Applications</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
	var $row = $("<div class='row' />").appendTo($boxContent);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $dataTable = $("<div class='data-table' style='table-layout: fixed;' />").appendTo($dataCol);
	var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Application Name</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Application Status</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Application Details</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Actions <i class='fa fa-info-circle fa-fw fa-lg' style='color: #007dba;' title='Clicking on Edit / View will navigate you to the ANZ Transactive - AU / NZ application for modification of entitlements.'></i></div>").appendTo($dataTableRow);
	var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
	var $dataTableCell = $("<div class='data-table-cell'>ANZ Transactive AU - NZ</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'>Assigned</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'><div><strong>User Group Name:</strong>ACME Group 1</div><div><strong>User Group ID:</strong> 01TEM:SET</div><div><strong>Transactive User ID:</strong> SMITJACM</div></div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='vertical-align: middle;'></div>").appendTo($dataTableRow);
	var $appEditViewBtn = $("<span class='form-button'><a href='javascript:void(0)'>Edit / View</a></span>").appendTo($dataTableCell);
	var $unassignBtn = $("<span class='form-button'><a href='javascript:void(0)'>Unassign</a></span>").appendTo($dataTableCell);
	var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
	var $dataTableCell = $("<div class='data-table-cell'>ANZ Transactive Global</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'>Assigned</div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell'></div>").appendTo($dataTableRow);
	var $dataTableCell = $("<div class='data-table-cell' style='vertical-align: middle;'></div>").appendTo($dataTableRow);

	$formContainer.appendTo($userContainer);

	renderAssignedRolesGrid();

}




/**********************************************************************
UPDATE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='user-management.html'>User Management</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("User Details");
	} else if (update == "edit") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Edit User");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("User Management");
	}
}



/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE PAYMENT GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#paymentSummaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	grid.registerPlugin(new Slick.AutoTooltips({
		enableForHeaderCells: true
	}));
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'UsersColumnOrder', 'UsersColumnWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell)
		setupContextMenu();
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedRowStates = [];
		selectedRowWorkflows = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedRowStates.push(item.status);
				selectedRowWorkflows.push(item.workflow);
			}
		}
		if (selectedRowIds.length > 0) {
			$("#paymentSummaryGrid").addClass("has-bottom-controls");
			$("#UsersGrid .bottom-controls").removeClass("hidden");
			$("#selectedCount").html(selectedRowIds.length);
			grid.resizeCanvas();
		} else {
			$("#paymentSummaryGrid").removeClass("has-bottom-controls");
			$("#UsersGrid .bottom-controls").addClass("hidden");
			$("#selectedCount").html('');
			grid.resizeCanvas();
		}
	});
	grid.onClick.subscribe(function(e, args) {
		row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#userDetailScreen',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			record = dataView.getItem(row);
			viewRecord();
			grid.setSelectedRows([]);
			selectedRowIds = [];
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('UsersColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	if(statusString || workflowString || managedbyString)
		dataView.setFilterArgs({
			statusString: statusString,
			workflowString: workflowString,
			managedbyString: managedbyString
			
		});
	else
		dataView.setFilterArgs({});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('UsersColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i <= store.get('UsersColumnOrder').length; i++) {
			if (columns[i].visible == true) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleAdHocColumns);
	}
	grid.setHeaderRowVisibility(false);

	/**********************************************************************
	GRID RESIZER
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));

	/*********************************************************************
	VIEWS
	**********************************************************************/
	$("#viewMenu, #userStatus , #workflowStatus, #managedBy").on("click.filter-view", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set")) {
			var status = $target.attr("data-status"),
				workflow = $target.attr("data-workflow"),
				managedby = $target.attr("data-managedby");
			if (!status) {
				statusString = ""
			}
			if (statusString != status) {
				statusString = status
			}
			if (!workflow) {
				workflowString = ""
			}
			if (workflowString != workflow) {
				workflowString = workflow
			}
			if (!managedby) {
				managedbyString = ""
			}
			if (managedbyString != managedby) {
				managedbyString = managedby
			}

			
			paymentsViewFilter(); 
		}
	});

	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl, #recordReportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#reportMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#reportMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#reportMenu"
			});
		}
	});


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


	/**********************************************************************
	GROUPING
	**********************************************************************/
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});

	/**********************************************************************
	ACTION MENU AND ACTIONS
	**********************************************************************/
	$("#actionMenuControl").on("click", setupContextMenu);
	$("[data-action='close']").on("click", function(e){
		updateBreadcrumb("close");
	});
	$("[data-action='view']").on("click", function(e) {
		var $target = $(e.target);
		$target.attr({
			'data-panel': '#userDetailScreen',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		record = dataView.getItemById(selectedRowIds[0]);
		viewRecord();
		grid.setSelectedRows([]);
		selectedRowIds = [];
	});
	$("[data-action='edit']").on("click", function(e){
		var $target = $(e.target);
		$target.attr({
			'data-panel': '#userDetailScreen',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		record = dataView.getItemById(selectedRowIds[0]);
		editRecord();
		grid.setSelectedRows([]);
		selectedRowIds = [];
	});
	$("[data-action='delete']").on("click", deleteRecordFromList);
	$("[data-action='reject']").on("click", rejectRecordFromList);
	$("[data-action='approve']").on("click", approveRecords);
	$("[data-action='viewaudithistory']").on("click", showAuditHistoryDialog);
	$("[data-action='auditreport']").on("click", showAuditHistoryReportDialog);
	$("[data-action='usersummaryreport']").on("click", showUserSummaryReportDialog);
	$("[data-action='userdetailreport']").on("click", showUserDetailReportDialog);

	
	/**********************************************************************
	SETTINGS
	**********************************************************************/	
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	JUMP TO PAYMENT DETAILS
	**********************************************************************/
	var b = document.location.href.split(".html")[1];

	if (b == "#detail") {
		$("#usersGrid").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		document.location.hash = '';
	}


});