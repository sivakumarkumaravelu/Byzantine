/* NEW USER RECORD */
var record = {
	id: randString(20),
	firstname: "",
	lastname: "",
	preferredname: "",
	email: "",
	userid: "",
	useridverified: false,
	address1: "",
	address2: "",
	address3: "",
	city: "",
	country: "",
	phonecode: "",
	phonenumber: "",
	login: "",
	dob: "",
	roles: [],
	audit: []
}


/* COPY USERS DATA */
var users = [{
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid2",
		record: "Role",
		name: "Role 2",
		family: "Role Family",
		description: "Role 2 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}, {
		id: "roleid2",
		record: "Role",
		name: "Role 2",
		family: "Role Family",
		description: "Role 2 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid3",
		record: "Role",
		name: "Role 3",
		family: "Role Family",
		description: "Role 3 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid4",
		record: "Role",
		name: "Role 4",
		family: "Role Family",
		description: "Role 4 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}, {
	id: randString(20),
	record: "User",
	userid: "User" + randString(5),
	firstname: "First",
	lastname: "Last",
	roles: [{
		id: "roleid1",
		record: "Role",
		name: "Role 1",
		family: "Role Family",
		description: "Role 1 Description",
		division: "Division 1",
		type: "System"
	}]
}];


/* ROLES DATA */
var roles = [{
	id: "roleid1",
	record: "Role",
	name: "Role 1",
	family: "Role Family",
	description: "Role 1 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid2",
	record: "Role",
	name: "Role 2",
	family: "Role Family",
	description: "Role 2 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid3",
	record: "Role",
	name: "Role 3",
	family: "Role Family",
	description: "Role 3 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid4",
	record: "Role",
	name: "Role 4",
	family: "Role Family",
	description: "Role 4 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid5",
	record: "Role",
	name: "Role 5",
	family: "Role Family",
	description: "Role 5 Description",
	division: "Division 1",
	type: "System"
}, {
	id: "roleid6",
	record: "Role",
	name: "Role 6",
	family: "Role Family",
	description: "Role 6 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid7",
	record: "Role",
	name: "Role 7",
	family: "Role Family",
	description: "Role 7 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid8",
	record: "Role",
	name: "Role 8",
	family: "Role Family",
	description: "Role 8 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid9",
	record: "Role",
	name: "Role 9",
	family: "Role Family",
	description: "Role 9 Description",
	division: "Division 2",
	type: "System"
}, {
	id: "roleid10",
	record: "Role",
	name: "Role 10",
	family: "Role Family",
	description: "Role 10 Description",
	division: "Division 2",
	type: "System"
}];


/* ASSIGNED ROLES */
var assignedRoles = [];


/* PAGE VARIABLES */
var $shell = $(".shell");
var $userForm = $("#userForm");


/* SEARCH GRID */
var searchGrid = null;
var searchDataView;
var searchData;
var searchSelectedRowIds;
var searchOptions;
var searchColumns;
var searchList = [];


/* ASSIGNED ROLES GRID */
var grid = null;
var dataView;
var data;
var selectedRowIds;
var options;
var columns;
var columnFilters = {};


function loginCredentialSelection() {
	var type = $(this).attr("data-login-type");
	$("#loginCredentials").find(".login-type").not(".disabled").removeClass("selected").children(".login-radio-button").removeClass("fa-check-circle").addClass("fa-circle-thin");
	if ( record.logintype != type ) {
		$(this).addClass("selected").children(".login-radio-button").removeClass("fa-circle-thin").addClass("fa-check-circle");
		record.logintype = type;

		if (record.logintype == "token") {
			$("#tokenDetails").show();
		} else {
			$("#tokenDetails").hide();
		}


	} else {
		record.logintype = "";
		$("#tokenDetails").hide();
	}
}

function disableLoginCredential(type) {
}

function checkAvailabilityOfUserID(e) {
	e.preventDefault();
	var _userid = $("#userID").val();
	if ( _userid != "" ) {
		$shell.addClass("loading");
		var randNum = rand(0,10);
		var $icon = $("<i id='userIDVerificationIcon' class='fa fa-fw' style='position: absolute; top: 7px; right: 3px; font-size: 20px;'></i>");
		setTimeout(function() {
			$shell.removeClass("loading");
			$("#userIDVerificationIcon").remove();
			if (randNum > 7) {
				buildErrorNotification("Errors Were Detected", "User ID <strong>"+ _userid +"</strong> is not available. Please enter a new User ID and try again.", 300);
				$icon.appendTo($("#userIdField")).addClass("fa-ban").css({"color" : "#c91b01"});
				record.useridverified = false;
			} else {
				buildNotification("User ID <strong>"+ _userid +"</strong> is available for use", 300, 5000);
				$icon.appendTo($("#userIdField")).addClass("fa-check-circle").css({"color" : "#009900"});
				record.useridverified = true;
			}
		}, 1000);
	}
}

function handleUserIDChange() {
	$("#userIDVerificationIcon").remove();
	record.useridverified = false;
}

/* DESTROY SEARCH GRID */
function destroyDialogSearchGrid() {
	if (typeof(searchGrid) != 'undefined' && searchGrid != null) {
		searchGrid.destroy();
		$(window).off('resize.searchgrid');
	}
}

/* SEARCH GRID FILTER */
function searchGridFilter(rec) {
	var found;
	for (i = 0; i < searchList.length; i += 1) {
		found = false;
		$.each(rec, function(obj, objValue) {
			if (typeof objValue !== 'undefined' && objValue != null && objValue.toString().toLowerCase().indexOf(searchList[i]) != -1) {
				found = true;
				return false;
			}
		});
		if (!found) {
			return false;
		}
	}
	return true;
}


/* SUBMIT */
function submitUser(e) {

	e.preventDefault();

	/* define the steps */
	var steps = ["User Creation", "Password Generation"];

	/* build the content */
	var $content = $("<div class='processing-steps' />"),
		$connector = $("<div class='step-connector' />").appendTo($content),
		$ul = $("<ul />").appendTo($content),
		$li, $div, $text;
	for (var i = 0; i < steps.length; i++) {
		$li = $("<li />").appendTo($ul),
			$div = $("<div class='processing-step' />").appendTo($li),
			$text = $("<span>" + steps[i] + " Pending</span>").appendTo($div);
	}

	/* build and open the dialog */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "ProcessingDialog",
		title: "Your Request is Being Processed",
		size: "xsmall",
		icon: "<i class='fa fa-share-square'></i>",
		content: $content
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("a[data-modal-control='close']").remove();
	setTimeout(function(){
		$(document).off("keydown.dialog-manager");
	}, 300);
	

	/* set the height of the connector line */
	$connector.css({
		"height": $ul.height()
	});

	/* run the sequence */
	var n = 0;

	function runSequence(n) {
		if (n < steps.length) {
			var $div = $ul.children("li").eq(n).children("div"),
				$span = $div.children("span");
			setTimeout(function() {
				$div.addClass("progress");
				$span.html(steps[n] + " In Progress");
				setTimeout(function() {
					$div.addClass("complete");
					$span.html(steps[n] + " Complete");
					n = n + 1;
					runSequence(n);
				}, 2000);
			}, 300);
		} else {

			setTimeout(function(){
				var $confirmContent = $("<div class='py-ui top-label' />");
				var $gridRow = $("<div class='grid-row' />").appendTo($confirmContent);
				var $gridCell = $("<div class='grid-cell' style='width: 60%;' />").appendTo($gridRow);
				var $row = $("<div class='row' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px; color: #004268;'>New password for <span style='color: #007dba; font-weight: 600;'>Test User</span> is: <span style='color: #007dba; font-weight: 600; font-size: 22px; margin-left: 5px;'>"+randString(10)+"</span></div>").appendTo($dataCol);
				var $row = $("<div class='row' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px; color: #004268;'><i class='fa fa-lock fa-fw' style='height: 80px; margin-right: 10px; float: left; font-size: 50px;'></i>Please provide this new password to <span style='color: #007dba; font-weight: 600;'>Test User</span>. Note: This password will no longer be visible upon closing of this window.</div>").appendTo($dataCol);
				var $row = $("<div class='row' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px; color: #004268;'><i class='fa fa-vcard-o fa-fw' style='height: 80px; margin-right: 10px; float: left; font-size: 50px;'></i><span style='color: #007dba; font-weight: 600;'>Test User</span> requires additional identity verification to complete access to all selected entitlements. Please print the KYC Form and follow the instructions to complete identity verification.</div>").appendTo($dataCol);
				var $row = $("<div class='row' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px; color: #004268;'><i class='fa fa-ban fa-fw' style='height: 80px; margin-right: 10px; float: left; font-size: 50px;'></i><span style='color: #007dba; font-weight: 600;'>Test User</span> will have limited access until identity verification steps are complete.</div>").appendTo($dataCol);
				var $gridCell = $("<div class='grid-cell' style='width: 40%; text-align: center;' />").appendTo($gridRow);
				var $row = $("<div class='row' style='padding-top: 50px;' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' style='padding-top: 20px;' />").appendTo($row);
				var $button = $("<span class='form-button'><a href='javascript:void(0)' style='width: 170px;'><i class='fa fa-print fa-fw'></i><span>Print KYC Form</span></a></span>").appendTo($dataCol);
				var $row = $("<div class='row' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' style='padding-top: 30px;' />").appendTo($row);				
				var $button = $("<span class='form-button'><a href='user-management.html' style='width: 170px;'><i class='fa fa-chevron-circle-left fa-fw'></i><span>Return to User List</span></a></span>").appendTo($dataCol);
				var $row = $("<div class='row' />").appendTo($gridCell);
				var $dataCol = $("<div class='data-column' style='padding-top: 30px;' />").appendTo($row);
				var $button = $("<span class='form-button'><a href='user-creation.html' style='width: 170px;'><i class='fa fa-plus-square fa-fw'></i><span>Create New User</span></a></span>").appendTo($dataCol);

				var _confirmOrigin = $("#ProcessingDialog");
				var _confirmdialog = {
					id: "confirmDialog",
					title: "User Successfully Created",
					size: "wide",
					icon: "<i class='fa fa-check'></i>",
					content: $confirmContent
				}
				dialogViewer(_confirmOrigin, _confirmdialog, dialogBuilder(_confirmdialog));
				setTimeout(function(){
					$(document).off("keydown.dialog-manager");
				}, 300);
				$("a[data-modal-control='close']").remove();
				$("#ProcessingDialog").remove();

			}, 500);

			return false;
		}
	}
	runSequence(n);
}


/* CREATE NEW ROLE */
function createNewRoleDialog(e) {

	e.preventDefault();

	var _target = $(this);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderNewRoleDialogContent = function() { 

		/* system information */
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

		/* system information */
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 11%;' />").appendTo($detailRow);
		var $icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell);
		var $detailCell = $("<div class='grid-cell' style='width: 88%;padding-top: 40px' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label >Role Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $input = $("<input type='text' style='width: 80%;' id='roleName' />").appendTo($dataCol);
		var $dataRow = $("<div class='row' style='padding-top: 20px' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label >Role Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $input = $("<textarea  style='width: 80%;' id='roleDescription' />").appendTo($dataCol);

		return $dialogContent;
	}

	function  saveNewRole() {
		data = [{id: randString(20) ,name: $('#roleName').val(), division: $('#divisionSelection :selected').text(),  family: "Role Family", description: $('#roleDescription').val() , type: "System" }];
		assignedRoles = assignedRoles.concat(data);
		renderAssignedRolesGrid();
	}

	var _dialog = {
		id: "newRoleDialog",
		title: "Create a New Role",
		size: "xxl",
		icon: "<i class='fa fa-edit'></i>",
		content: function() {
			return renderNewRoleDialogContent();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
						dialogHider(_dialog);
				}
			}]
			}, {
				name: "Save",
				icon: "<i class='fa fa-save fa-fw'></i>",
				events: [{
				event: "click",			
				action: function(e) {
					e.preventDefault();
					saveNewRole();
					dialogHider(_dialog);
				}
			}],
			cssClass: "primary"
		}]
	}

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/* SETUP ROLE PERMISSIONS */
function setupRolePermissions(target, mode) {


	var _target = target;
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderNewRoleDialogContent = function() { 

		/* system information */
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

		/* system information */
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 15%;' />").appendTo($detailRow);
		var $icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell);
		var $detailCell = $("<div class='grid-cell' style='width: 85%; padding-top: 40px' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Division</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px;' />").appendTo($dataRow);
		var $label = $("<label>Select A Division</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $customSelect = $("<div class='custom-select' style='max-width: 100%;' />").appendTo($dataCol);
		var $select = $("<select id='divisionSelection' style='min-width: 250px;'><option value='Customer Division 1'>Customer Division 1</option><option value='Customer Division 2'>Customer Division 2</option><option value='Customer Division 3'>Customer Division 3</option></select>").appendTo($customSelect);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio"  name="accountselection" value="all" id="audc-allaccounts" checked="checked"><label for="audc-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection" value="select" id="audc-selectaccounts"><label for="audc-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection" value="none" id="audc-selectaccounts2"><label for="audc-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-accountsGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='accountsGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Internation Payments</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		$data = $('<div class="checkbox-group"><input type="radio"  name="accountselection5" value="all" id="ip-allaccounts" checked="checked"><label for="ip-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection5" value="select" id="ip-selectaccounts"><label for="ip-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection5" value="none" id="ip-selectaccounts2"><label for="ip-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-paymentsGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account1" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts1" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='paymentsGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Payment Purpose</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="checkbox"  name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox"  name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Approval Discretions</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio" checked="checked" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio"  name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
		var	$boxContent1 = $("<div  id='show-allproducts' class='box-content top-label' style='width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($boxContent),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent1),
		$detailCell1 = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell1);
		$('<div  style=""> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="daily" value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="batch"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="transaction"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
		$dataRow = $("<div class='row product-specific' style='display:none' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var	$boxContent2 = $("<div class='box-content top-label product-specific' style='display:none;width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($detailCell),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent2),
		$detailCell1 = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell1);
		$('<div  style=""> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="daily1" value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="batch1"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="transaction1"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
		$dataRow = $("<div class='row product-specific' style='display:none;'/>").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>International Payments</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var	$boxContent3 = $("<div class='box-content top-label product-specific' style='display:none;width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($detailCell),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent3),
		$detailCell1 = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell1);
		$('<div  style=""> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="daily2" value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="batch2"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="transaction2"  value="UNLIMITED"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box),
		$boxContent = $("<div class='box-content left-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Operating Accounts</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio"  name="accountselection1" value="all" id="oa-allaccounts" checked="checked"><label for="oa-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection1" value="select" id="oa-selectaccounts"><label for="oa-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection1" value="none" id="oa-selectaccounts2"><label for="oa-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-operatingGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account2" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts2" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='operatingGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>Deposits</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio"  name="accountselection2" value="all" id="d-allaccounts" checked="checked"><label for="d-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection2" value="select" id="d-selectaccounts"><label for="d-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection2" value="none" id="d-selectaccounts2"><label for="d-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);					
		var $gridRow = $("<div class='grid-row' id='show-depositGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account3" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts3" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='depositGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box),
		$boxContent = $("<div class='box-content left-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio" checked="checked" name="accountselection3" value="all" id="audd-allaccounts" ><label for="audd-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection3" value="select" id="audd-selectaccounts"><label for="audd-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection3" value="none" id="audd-selectaccounts2"><label for="audd-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-auddGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account4" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts4" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='auddGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
		$label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $('<div class="checkbox-group"><input type="radio" checked="checked" name="accountselection4" value="all" id="nzdd-allaccounts" ><label for="nzdd-allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio"  name="accountselection4" value="select" id="nzdd-selectaccounts"><label for="nzdd-selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio"  name="accountselection4" value="none" id="nzdd-selectaccounts2"><label for="nzdd-selectaccounts2" class="desc">None</label></div>').appendTo($dataCol);
		var $gridRow = $("<div class='grid-row' id='show-nzddGrid' style='display:none' />").appendTo($detailCell);
		var $gridCell = $("<div class='grid-cell' style='width: 95%;' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;'  />").appendTo($dataCol);
		$('<span class="btn" id="add-account5" style="max-width: 300px !important;margin: 20px 0px 0px 20px"><a href="javascript:void(0)"><i class="fa fa-plus-square fa-fw "></i><span>Add</span></a></span>').appendTo($permissionGrid);
		$('<span class="btn disabled" id="remove-accounts5" style="max-width: 300px !important;margin: 20px 0px 0px 10px"><a href="javascript:void(0)"><i class="fa fa-trash-o fa-fw "></i><span>Remove</span></a></span>').appendTo($permissionGrid);
		var $permissionGrid = $("<div class='payment-grid' style='border-radius: 4px;margin: 5px 20px 20px 20px;width:95%;height: 77%' id='nzddGrid' />").appendTo($permissionGrid);
		var $noPermissions = $("<div class='loading-text'>No accounts selected.</div>").appendTo($permissionGrid);

		function removeAccount() {
			if(audomesticGrid.getSelectedRows() !="") {
				audomesticGridDataView.setItems([]);
				audomesticGrid.render();
				audomesticGrid.resizeCanvas();
			}
		}

		function addAccount(gridid) {
			_widget = {};
			_widget.data = [];
			_widget.id = "test"

			/* set _data to the widget data and _id to the widget id */
			var _data = _widget.data,
			_id = _widget.id;

			/* function to save and add selected accounts to the widget */
			function saveSelectedAccounts(_dialog) {
				if ($("input[name=_addAccount]:checked").length > 0) {
					for (var i = 0; i < accounts.length; i++) {
						for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
							if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
								accounts[i].id = randString(20);
								accounts[i].accountname = accounts[i].name;
								accounts[i].accountnumber = accounts[i].number;
								accounts[i].bank = 'NSW';
								accounts[i].country = 'Australia';
								_data.push(accounts[i]);
							}
						}
					}
					_data = _data.concat(audomesticGrid.getData().getItems());
					audomesticGridDataView.setItems(_data);
					audomesticGrid.render();
					audomesticGrid.resizeCanvas();
					dialogHider(_dialog);
				} else {
					dialogHider(_dialog);
				}
			}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}


		function removeAccount1(){
		if(paymentsGrid.getSelectedRows() !=""){
		paymentsGridDataView.setItems([]);
		paymentsGrid.render();
		paymentsGrid.resizeCanvas();
		}
		}

		function addAccount1(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(paymentsGrid.getData().getItems());
		paymentsGridDataView.setItems(_data);
		paymentsGrid.render();
		paymentsGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}

		function removeAccount2(){

		if(operatingGrid.getSelectedRows() !=""){
		operatingGridDataView.setItems([]);
		operatingGrid.render();
		operatingGrid.resizeCanvas();
		}

		}

		function addAccount2(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(operatingGrid.getData().getItems());
		operatingGridDataView.setItems(_data);
		operatingGrid.render();
		operatingGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}


		function removeAccount3(){

		if(depositGrid.getSelectedRows() !=""){
		depositGridDataView.setItems([]);
		depositGrid.render();
		depositGrid.resizeCanvas();
		}

		}

		function addAccount3(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(depositGrid.getData().getItems());
		depositGridDataView.setItems(_data);
		depositGrid.render();
		depositGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}


		function removeAccount4(){

		if(auddGrid.getSelectedRows() !=""){
		auddGridDataView.setItems([]);
		auddGrid.render();
		auddGrid.resizeCanvas();
		}

		}

		function addAccount4(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		//console.log(audomesticGrid.getData().getItems());
		_data = _data.concat(auddGrid.getData().getItems());
		auddGridDataView.setItems(_data);
		auddGrid.render();
		auddGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}

		function removeAccount5(){

		if(nzddGrid.getSelectedRows() !=""){
		nzddGridDataView.setItems([]);
		nzddGrid.render();
		nzddGrid.resizeCanvas();
		}

		}

		function addAccount5(gridid){
		_widget = {};
		_widget.data = [];
		_widget.id = "test"


		/* set _data to the widget data and _id to the widget id */
		var _data = _widget.data,
		_id = _widget.id;

		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
		for (var i = 0; i < accounts.length; i++) {
		for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
			if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
				accounts[i].id = randString(20);
				accounts[i].accountname = accounts[i].name;
				accounts[i].accountnumber = accounts[i].number;
				accounts[i].bank = 'NSW';
				accounts[i].country = 'Australia';
				_data.push(accounts[i]);
			}
		}
		}
		//console.log(_data);

		console.log(nzddGrid);
		_data = _data.concat(nzddGrid.getData().getItems());
		nzddGridDataView.setItems(_data);
		nzddGrid.render();
		nzddGrid.resizeCanvas();
		dialogHider(_dialog);

		} else {
		dialogHider(_dialog);
		}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
		if (this.value != '') {
		$("#clearAccountsFilter").show()
		} else {
		$("#clearAccountsFilter").hide()
		}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
		$("#AddAccountsFilterInput").val("").trigger("change");
		$(this).hide();
		}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
		var $target = $(e.target);
		if ($target.prop("nodeName") == "DIV") {
		$target = $target.find("input[name='_selectAll']");
		var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
		}
		var checkBoxes = $("input[name=_addAccount]:visible");
		var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 260px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 160px;'>Branch</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 120px;'>Country</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
		if (_data[i].number == this.number) {
		_alreadyAdded = true;
		break;
		}
		}
		if (!_alreadyAdded) {
		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				if ($target.hasClass("fav-data-col")) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		}),
		$name = $("<div class='fav-data-col' style='width: 260px;'>" + this.name + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 160px;'>NSW</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 120px;'>Australia</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
		});

		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
		name: "Cancel",
		icon: "<i class='fa fa-times fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}
		}]
		}, {
		name: "Ok",
		icon: "<i class='fa fa-check fa-fw'></i>",
		events: [{
		event: "click",
		action: function(e) {
			e.preventDefault();
			saveSelectedAccounts(_dialog)
		}
		}],
		cssClass: "primary"
		}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		/* if no accounts are available display a message */
		if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}




		}

		function intializeGrid(){

		function resetaddAccountResourceGridColumns() {
			audomesticGrid.setColumns(audomesticGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = audomesticGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = audomesticGridGridColumns.length; a < b; a++) {
				if (_id == audomesticGridGridColumns[a].id) {
					sortCols[i].sorter =audomesticGridGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		audomesticGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', audomesticGrid.getSortColumns());
		audomesticGrid.invalidateAllRows();
		//audomesticGrid.render();
		}
		var gridId = gridId || "#accountsGrid"; 
		audomesticGridData = [];
		audomesticGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			audomesticGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', audomesticGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < audomesticGridColumns.length; c++) {
					if (s.id == audomesticGridColumns[c].id) {
						audomesticGridColumns[c].width = s.width
					}
				}
			}
		}
		audomesticGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var audomesticGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		audomesticGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: audomesticGridGroupItemMetadataProvider
		});
		audomesticGridDataView.getItemMetadata = addAccountResourceGridMetaData(audomesticGridDataView.getItemMetadata);
		audomesticGrid = new Slick.Grid(gridId, audomesticGridDataView, audomesticGridColumns, audomesticGridOptions);


		audomesticGrid.registerPlugin(audomesticGridGroupItemMetadataProvider);
		audomesticGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var audomesticGridColumnpicker = new Slick.Controls.ColumnPicker(audomesticGridColumns, audomesticGrid, audomesticGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		audomesticGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = audomesticGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = audomesticGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		audomesticGrid.onSort.subscribe(sortaddAccountResourceGrid);
		audomesticGrid.onDblClick.subscribe(function(e, args) {
			var cell = audomesticGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		audomesticGridDataView.onRowCountChanged.subscribe(function(e, args) {
			audomesticGrid.updateRowCount();
			if(audomesticGridDataView.getItems().length >0){
				$('#remove-accounts').removeClass("disabled");
			}
			else {
				$('#remove-accounts').addClass("disabled");
			}
			audomesticGrid.render();
		});
		audomesticGridDataView.onRowsChanged.subscribe(function(e, args) {
			audomesticGrid.invalidateRows(args.rows);
			audomesticGrid.render();
		});
		audomesticGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', audomesticGrid.getColumns());
		});

		audomesticGridDataView.beginUpdate();
		audomesticGridDataView.setItems(audomesticGridData);
		audomesticGridDataView.syncGridSelection(audomesticGrid, true, false);
		audomesticGridDataView.endUpdate();

		//audomesticGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (audomesticGridColumns[i].visible) {
					visibleColumns.push(audomesticGridColumns[i])
				}
			}

			audomesticGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			audomesticGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function intializeGrid1(){

		function resetaddAccountResourceGridColumns() {
			paymentsGrid.setColumns(paymentsGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = paymentsGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = paymentsGridColumns.length; a < b; a++) {
				if (_id == paymentsGridColumns[a].id) {
					sortCols[i].sorter =paymentsGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		paymentsGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', paymentsGrid.getSortColumns());
		paymentsGrid.invalidateAllRows();
		//paymentsGrid.render();
		}
		var gridId = "#paymentsGrid"; 
		paymentsGridData = [];
		paymentsGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			paymentsGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', paymentsGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < paymentsGridColumns.length; c++) {
					if (s.id == paymentsGridColumns[c].id) {
						paymentsGridColumns[c].width = s.width
					}
				}
			}
		}
		paymentsGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var paymentsGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		paymentsGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: paymentsGridGroupItemMetadataProvider
		});
		paymentsGridDataView.getItemMetadata = addAccountResourceGridMetaData(paymentsGridDataView.getItemMetadata);
		paymentsGrid = new Slick.Grid(gridId, paymentsGridDataView, paymentsGridColumns, paymentsGridOptions);


		paymentsGrid.registerPlugin(paymentsGridGroupItemMetadataProvider);
		paymentsGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var paymentsGridColumnpicker = new Slick.Controls.ColumnPicker(paymentsGridColumns, paymentsGrid, paymentsGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		paymentsGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = paymentsGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = paymentsGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		paymentsGrid.onSort.subscribe(sortaddAccountResourceGrid);
		paymentsGrid.onDblClick.subscribe(function(e, args) {
			var cell = paymentsGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		paymentsGridDataView.onRowCountChanged.subscribe(function(e, args) {
			paymentsGrid.updateRowCount();
			if(paymentsGridDataView.getItems().length >0){
				$('#remove-accounts1').removeClass("disabled");
			}
			else {
				$('#remove-accounts1').addClass("disabled");
			}
			paymentsGrid.render();
		});
		paymentsGridDataView.onRowsChanged.subscribe(function(e, args) {
			paymentsGrid.invalidateRows(args.rows);
			paymentsGrid.render();
		});
		paymentsGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', paymentsGrid.getColumns());
		});

		paymentsGridDataView.beginUpdate();
		paymentsGridDataView.setItems(paymentsGridData);
		paymentsGridDataView.syncGridSelection(paymentsGrid, true, false);
		paymentsGridDataView.endUpdate();

		//paymentsGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (paymentsGridColumns[i].visible) {
					visibleColumns.push(paymentsGridColumns[i])
				}
			}

			paymentsGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			paymentsGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}


		function intializeGrid2(){

		function resetaddAccountResourceGridColumns() {
			operatingGrid.setColumns(operatingGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = operatingGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = operatingGridColumns.length; a < b; a++) {
				if (_id == operatingGridColumns[a].id) {
					sortCols[i].sorter =operatingGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		operatingGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', operatingGrid.getSortColumns());
		operatingGrid.invalidateAllRows();
		//operatingGrid.render();
		}
		var gridId = "#operatingGrid"; 
		operatingGridData = [];
		operatingGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			operatingGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', operatingGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < operatingGridColumns.length; c++) {
					if (s.id == operatingGridColumns[c].id) {
						operatingGridColumns[c].width = s.width
					}
				}
			}
		}
		operatingGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var operatingGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		operatingGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: operatingGridGroupItemMetadataProvider
		});
		operatingGridDataView.getItemMetadata = addAccountResourceGridMetaData(operatingGridDataView.getItemMetadata);
		operatingGrid = new Slick.Grid(gridId, operatingGridDataView, operatingGridColumns, operatingGridOptions);


		operatingGrid.registerPlugin(operatingGridGroupItemMetadataProvider);
		operatingGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var operatingGridColumnpicker = new Slick.Controls.ColumnPicker(operatingGridColumns, operatingGrid, operatingGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		operatingGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = operatingGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = operatingGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		operatingGrid.onSort.subscribe(sortaddAccountResourceGrid);
		operatingGrid.onDblClick.subscribe(function(e, args) {
			var cell = operatingGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		operatingGridDataView.onRowCountChanged.subscribe(function(e, args) {
			operatingGrid.updateRowCount();
			if(operatingGridDataView.getItems().length >0){
				$('#remove-accounts2').removeClass("disabled");
			}
			else {
				$('#remove-accounts2').addClass("disabled");
			}
			operatingGrid.render();
		});
		operatingGridDataView.onRowsChanged.subscribe(function(e, args) {
			operatingGrid.invalidateRows(args.rows);
			operatingGrid.render();
		});
		operatingGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', operatingGrid.getColumns());
		});

		operatingGridDataView.beginUpdate();
		operatingGridDataView.setItems(operatingGridData);
		operatingGridDataView.syncGridSelection(operatingGrid, true, false);
		operatingGridDataView.endUpdate();

		//operatingGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (operatingGridColumns[i].visible) {
					visibleColumns.push(operatingGridColumns[i])
				}
			}

			operatingGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			operatingGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}


		function intializeGrid3(){

		function resetaddAccountResourceGridColumns() {
			depositGrid.setColumns(depositGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = depositGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = depositGridColumns.length; a < b; a++) {
				if (_id == depositGridColumns[a].id) {
					sortCols[i].sorter =depositGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		depositGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', depositGrid.getSortColumns());
		depositGrid.invalidateAllRows();
		//depositGrid.render();
		}
		var gridId =  "#depositGrid"; 
		depositGridData = [];
		depositGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			depositGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', depositGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < depositGridColumns.length; c++) {
					if (s.id == depositGridColumns[c].id) {
						depositGridColumns[c].width = s.width
					}
				}
			}
		}
		depositGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var depositGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		depositGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: depositGridGroupItemMetadataProvider
		});
		depositGridDataView.getItemMetadata = addAccountResourceGridMetaData(depositGridDataView.getItemMetadata);
		depositGrid = new Slick.Grid(gridId, depositGridDataView, depositGridColumns, depositGridOptions);


		depositGrid.registerPlugin(depositGridGroupItemMetadataProvider);
		depositGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var depositGridColumnpicker = new Slick.Controls.ColumnPicker(depositGridColumns, depositGrid, depositGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		depositGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = depositGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = depositGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		depositGrid.onSort.subscribe(sortaddAccountResourceGrid);
		depositGrid.onDblClick.subscribe(function(e, args) {
			var cell = depositGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		depositGridDataView.onRowCountChanged.subscribe(function(e, args) {
			depositGrid.updateRowCount();
			if(depositGridDataView.getItems().length >0){
				$('#remove-accounts3').removeClass("disabled");
			}
			else {
				$('#remove-accounts3').addClass("disabled");
			}
			depositGrid.render();
		});
		depositGridDataView.onRowsChanged.subscribe(function(e, args) {
			depositGrid.invalidateRows(args.rows);
			depositGrid.render();
		});
		depositGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', depositGrid.getColumns());
		});

		depositGridDataView.beginUpdate();
		depositGridDataView.setItems(depositGridData);
		depositGridDataView.syncGridSelection(depositGrid, true, false);
		depositGridDataView.endUpdate();

		//depositGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (depositGridColumns[i].visible) {
					visibleColumns.push(depositGridColumns[i])
				}
			}

			depositGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			depositGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function intializeGrid4(){

		function resetaddAccountResourceGridColumns() {
			auddGrid.setColumns(auddGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = auddGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = auddGridColumns.length; a < b; a++) {
				if (_id == auddGridColumns[a].id) {
					sortCols[i].sorter =auddGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		auddGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', auddGrid.getSortColumns());
		auddGrid.invalidateAllRows();
		//auddGrid.render();
		}
		var gridId =  "#auddGrid"; 
		auddGridData = [];
		auddGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			auddGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', auddGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < auddGridColumns.length; c++) {
					if (s.id == auddGridColumns[c].id) {
						auddGridColumns[c].width = s.width
					}
				}
			}
		}
		auddGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var auddGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		auddGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: auddGridGroupItemMetadataProvider
		});
		auddGridDataView.getItemMetadata = addAccountResourceGridMetaData(auddGridDataView.getItemMetadata);
		auddGrid = new Slick.Grid(gridId, auddGridDataView, auddGridColumns, auddGridOptions);


		auddGrid.registerPlugin(auddGridGroupItemMetadataProvider);
		auddGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var auddGridColumnpicker = new Slick.Controls.ColumnPicker(auddGridColumns, auddGrid, auddGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		auddGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = auddGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = auddGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		auddGrid.onSort.subscribe(sortaddAccountResourceGrid);
		auddGrid.onDblClick.subscribe(function(e, args) {
			var cell = auddGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		auddGridDataView.onRowCountChanged.subscribe(function(e, args) {
			auddGrid.updateRowCount();
			if(auddGridDataView.getItems().length >0){
				$('#remove-accounts4').removeClass("disabled");
			}
			else {
				$('#remove-accounts4').addClass("disabled");
			}
			auddGrid.render();
		});
		auddGridDataView.onRowsChanged.subscribe(function(e, args) {
			auddGrid.invalidateRows(args.rows);
			auddGrid.render();
		});
		auddGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', auddGrid.getColumns());
		});

		auddGridDataView.beginUpdate();
		auddGridDataView.setItems(auddGridData);
		auddGridDataView.syncGridSelection(auddGrid, true, false);
		auddGridDataView.endUpdate();

		//auddGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (auddGridColumns[i].visible) {
					visibleColumns.push(auddGridColumns[i])
				}
			}

			auddGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			auddGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function intializeGrid5(){

		function resetaddAccountResourceGridColumns() {
			nzddGrid.setColumns(nzddGridColumns)
		}


		function addAccountResourceGridMetaData(itemMetaData) {
		return function(row) {
			var item = this.getItem(row);
			var ret = (itemMetaData(row) || {});

			if (item) {
				ret.cssClasses = (ret.cssClasses || '');
				if (item.status == "Disabled") {
					ret.cssClasses += "disabled-row";
				}
			}
			return ret;
		}
		}
		function sortaddAccountResourceGrid() {
		var sortCols = nzddGrid.getSortColumns();
		var cols = [];
		for (var i = 0, l = sortCols.length; i < l; i++) {
			var _id = sortCols[i].columnId;
			for (var a = 0, b = nzddGridColumns.length; a < b; a++) {
				if (_id == nzddGridColumns[a].id) {
					sortCols[i].sorter =nzddGridColumns[a].sorter;
					break;
				}
			}
			var col = {
				sortCol: {
					field: sortCols[i].columnId
				},
				sortAsc: sortCols[i].sortAsc,
				sorter: sortCols[i].sorter
			};
			cols.push(col);
		}
		nzddGridDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sorter;
				var result = 0;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		store.set('addAccountResourceGridSortingSetting', nzddGrid.getSortColumns());
		nzddGrid.invalidateAllRows();
		//nzddGrid.render();
		}
		var gridId =  "#nzddGrid"; 
		nzddGridData = [];
		nzddGridColumns = [{
					id: "accountname",
					name: "Account Name",
					field: "accountname",
					width: 250,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, 
				{
					id: "accountnumber",
					name: "Account Number",
					field: "accountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,

				},	{
					id: "bank",
					name: "Bank",
					field: "bank",
					width: 150,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}, {
					id: "country",
					name: "Country",
					field: "country",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				},{
					id: "currency",
					name: "Currency",
					field: "currency",
					width: 100,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true
				}];
		if (store.get('addAccountResourceGridColumnOrder')) {
			nzddGridColumns = store.get('addAccountResourceGridColumnOrder');
		} else {
			store.set('addAccountResourceGridColumnOrder', nzddGridColumns);
		}
		if (store.get('addAccountResourceGridColumnWidths')) {
			var setWidth = store.get('addAccountResourceGridColumnWidths');
			for (var i in setWidth) {
				var s = setWidth[i]
				for (c = 0; c < nzddGridColumns.length; c++) {
					if (s.id == nzddGridColumns[c].id) {
						nzddGridColumns[c].width = s.width
					}
				}
			}
		}
		nzddGridOptions = {
			enableCellNavigation: true,
			autoHeight: false,
			enableColumnReorder: true,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: true,
			multiColumnSort: true,
			explicitInitialization: false,
			showHeaderRow: false,
			headerRowHeight: 40
		};
		var nzddGridGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
		nzddGridDataView = new Slick.Data.DataView({
			groupItemMetadataProvider: nzddGridGroupItemMetadataProvider
		});
		nzddGridDataView.getItemMetadata = addAccountResourceGridMetaData(nzddGridDataView.getItemMetadata);
		nzddGrid = new Slick.Grid(gridId, nzddGridDataView, nzddGridColumns, nzddGridOptions);


		nzddGrid.registerPlugin(nzddGridGroupItemMetadataProvider);
		nzddGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		var nzddGridColumnpicker = new Slick.Controls.ColumnPicker(nzddGridColumns, nzddGrid, nzddGridOptions, "addAccountResourceGridColumnOrder", "addAccountResourceGridColumnWidths", resetaddAccountResourceGridColumns);
		nzddGrid.onSelectedRowsChanged.subscribe(function(e, args) {
			selectedEntitlementAccounts = [];
			var rows = nzddGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = nzddGridDataView.getItem(rows[i])
				if (item) selectedEntitlementAccounts.push(item)
			}
		});
		nzddGrid.onSort.subscribe(sortaddAccountResourceGrid);
		nzddGrid.onDblClick.subscribe(function(e, args) {
			var cell = nzddGrid.getCellFromEvent(e);
			var row = cell.row;
		});
		nzddGridDataView.onRowCountChanged.subscribe(function(e, args) {
			nzddGrid.updateRowCount();
			if(nzddGridDataView.getItems().length >0){
				$('#remove-accounts5').removeClass("disabled");
			}
			else {
				$('#remove-accounts5').addClass("disabled");
			}
			nzddGrid.render();
		});
		nzddGridDataView.onRowsChanged.subscribe(function(e, args) {
			nzddGrid.invalidateRows(args.rows);
			nzddGrid.render();
		});
		nzddGrid.onColumnsResized.subscribe(function(e, args) {
			store.set('addAccountResourceGridColumnWidths', nzddGrid.getColumns());
		});

		nzddGridDataView.beginUpdate();
		nzddGridDataView.setItems(nzddGridData);
		nzddGridDataView.syncGridSelection(nzddGrid, true, false);
		nzddGridDataView.endUpdate();

		//nzddGrid.setHeaderRowVisibility(true);


		if (store.get('addAccountResourceGridColumnOrder')) { 
			var visibleColumns = [];
			for (var i = 0; i < store.get('addAccountResourceGridColumnOrder').length; i++) {
				if (nzddGridColumns[i].visible) {
					visibleColumns.push(nzddGridColumns[i])
				}
			}

			nzddGrid.setColumns(visibleColumns);
		}



		if (store.get('addAccountResourceGridSortingSetting')) {
			nzddGrid.setSortColumns(store.get('addAccountResourceGridSortingSetting'));
			resetaddAccountResourceGridColumns();
		}

		}

		function updateAmount1() { 
		try { 
			var _daily = ($("#daily").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#daily").val())).toFixed(2);
			
		} catch(e) {}

		if(_daily == "0.00" || _daily == undefined){
		$("#daily").css("color", "#585858");
			_daily = "UNLIMITED";
		}
		else
			$("#daily").css("color", "#000");

		$("#daily").val(addCommas(_daily));

		}
		function updateAmount2() {
		try { 
			
			var _batch = ($("#batch").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#batch").val())).toFixed(2);

		} catch(e) {}


		if(_batch == "0.00" || _batch == undefined){
			$("#batch").css("color", "#585858");
			_batch = "UNLIMITED";
		}
		else
			$("#batch").css("color", "#000");
		$("#batch").val(addCommas(_batch));

		}
		function updateAmount3() {
		try { 
			var _transaction = ($("#transaction").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#transaction").val())).toFixed(2);
		} catch(e) {}

		if(_transaction == "0.00" || _transaction == undefined){
		$("#transaction").css("color", "#585858");
			_transaction = "UNLIMITED";
		}
		else
			$("#transaction").css("color", "#000");
		$("#transaction").val(addCommas(_transaction));
		}

		function updateAmount4() { 
		try { 
			var _daily = ($("#daily1").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#daily1").val())).toFixed(2);
			
		} catch(e) {}

		if(_daily == "0.00" || _daily == undefined){
		$("#daily1").css("color", "#585858");
			_daily = "UNLIMITED";
		}
		else
			$("#daily1").css("color", "#000");
		$("#daily1").val(addCommas(_daily));

		}
		function updateAmount5() {
		try { 
			
			var _batch = ($("#batch1").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#batch1").val())).toFixed(2);

		} catch(e) {}


		if(_batch == "0.00" || _batch == undefined){
			$("#batch1").css("color", "#585858");
			_batch = "UNLIMITED";
		}
		else
			$("#batch1").css("color", "#000");
		$("#batch1").val(addCommas(_batch));

		}
		function updateAmount6() {
		try { 
			var _transaction = ($("#transaction1").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#transaction1").val())).toFixed(2);
		} catch(e) {}

		if(_transaction == "0.00" || _transaction == undefined){
		$("#transaction1").css("color", "#585858");
			_transaction = "UNLIMITED";
		}
		else
			$("#transaction1").css("color", "#000");
		$("#transaction1").val(addCommas(_transaction));
		}

		function updateAmount7() { 
		try { 
			var _daily = ($("#daily2").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#daily2").val())).toFixed(2);
			
		} catch(e) {}

		if(_daily == "0.00" || _daily == undefined){
		$("#daily2").css("color", "#585858");
			_daily = "UNLIMITED";
		}
		else
			$("#daily2").css("color", "#000");
		$("#daily2").val(addCommas(_daily));

		}
		function updateAmount8() {
		try { 
			
			var _batch = ($("#batch2").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#batch2").val())).toFixed(2);

		} catch(e) {}


		if(_batch == "0.00" || _batch == undefined){
			$("#batch2").css("color", "#585858");
			_batch = "UNLIMITED";
		}
		else
			$("#batch2").css("color", "#000");
		$("#batch2").val(addCommas(_batch));

		}
		function updateAmount9() {
		try { 
			var _transaction = ($("#transaction2").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#transaction2").val())).toFixed(2);
		} catch(e) {}

		if(_transaction == "0.00" || _transaction == undefined){
		$("#transaction2").css("color", "#585858");
			_transaction = "UNLIMITED";
		}
		else
			$("#transaction2").css("color", "#000");
		$("#transaction2").val(addCommas(_transaction));
		}

		setTimeout( function(){
		$("#daily").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount1).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#batch").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount2).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#transaction").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount3).on("focus", function(){
		if ( $(this).val() == ""  ||  $(this).val() == "UNLIMITED") {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#daily1").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount4).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#batch1").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount5).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#transaction1").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount6).on("focus", function(){
		if ( $(this).val() == ""  ||  $(this).val() == "UNLIMITED") {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#daily2").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount7).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#batch2").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount8).on("focus", function(){
		if ( $(this).val() == "" ||  $(this).val() == "UNLIMITED" ) {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});
		$("#transaction2").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAmount9).on("focus", function(){
		if ( $(this).val() == ""  ||  $(this).val() == "UNLIMITED") {
			$(this).val('');
			$(this).css("color", "#000");
		}
		});


		$('#productspecific').on("click", function(){
		if($(this).is(":checked")){
			$('#show-allproducts').hide();
			$('.product-specific').show();

		}
		else {
		}
		});
		$('#allproducts').on("click", function(){
		if($(this).is(":checked")){
			$('.product-specific').hide();
			$('#show-allproducts').show();
			
			
		}
		});

		$('#audc-selectaccounts').on("click", function(){
		if($(this).is(":checked")){
			$('#show-accountsGrid').slideDown('fast');
		}
		else {
			$('#show-accountsGrid').slideToggle('fast');
		}
		});
		$('#audc-allaccounts, #audc-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-accountsGrid').slideUp('fast');
		}
		});


		$('#ip-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-paymentsGrid').slideDown('fast');
		}
		else {
			$('#show-paymentsGrid').slideToggle('fast');
		}
		});
		$('#ip-allaccounts, #ip-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-paymentsGrid').slideUp('fast');
		}
		});


		$('#oa-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-operatingGrid').slideDown('fast');
		}
		else {
			$('#show-operatingGrid').slideToggle('fast');
		}
		});
		$('#oa-allaccounts, #oa-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-operatingGrid').slideUp('fast');
		}
		});



		$('#d-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-depositGrid').slideDown('fast');
		}
		else {
			$('#show-depositGrid').slideToggle('fast');
		}
		});
		$('#d-allaccounts, #d-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-depositGrid').slideUp('fast');
		}
		});


		$('#audd-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-auddGrid').slideDown('fast');
		}
		else {
			$('#show-auddGrid').slideToggle('fast');
		}
		});
		$('#audd-allaccounts, #audd-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-auddGrid').slideUp('fast');
		}
		});


		$('#nzdd-selectaccounts').on("click", function(){
		if($(this).is(":checked")){  
			$('#show-nzddGrid').slideDown('fast');
		}
		else {
			$('#show-nzddGrid').slideToggle('fast');
		}
		});

		$('#nzdd-allaccounts, #nzdd-selectaccounts2').on("click", function(){
			if($(this).is(":checked")){
			$('#show-nzddGrid').slideUp('fast');
		}
		});






			$('#add-account').on("click", function(){addAccount()});
			$('#remove-accounts').on("click", function(){removeAccount()});
			$('#add-account1').on("click", function(){addAccount1()});
			$('#remove-accounts1').on("click", function(){removeAccount1()});
			$('#add-account2').on("click", function(){addAccount2()});
			$('#remove-accounts2').on("click", function(){removeAccount2()});
			$('#add-account3').on("click", function(){addAccount3()});
			$('#remove-accounts3').on("click", function(){removeAccount3()});
			$('#add-account4').on("click", function(){addAccount4()});
			$('#remove-accounts4').on("click", function(){removeAccount4()});
			$('#add-account5').on("click", function(){addAccount5()});
			$('#remove-accounts5').on("click", function(){removeAccount5()});
			intializeGrid();  
			intializeGrid1(); 
			intializeGrid2();  
			intializeGrid3();
			intializeGrid4();
			intializeGrid5();      
		}, 400);

		return $dialogContent;
	}

	var _dialog = {
		id: "saveRolePermissionSettings",
		title: "Permission Settings",
		size: "xxl",
		icon: "<i class='fa fa-edit'></i>",
			content: function() {
			return renderNewRoleDialogContent();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
			event: "click",
			action: function(e) {
				e.preventDefault();
				dialogHider(_dialog);
				}
			}]
		}]
	}

	var btn;
	if (mode == "edit") {
		btn = {
			name: "Save",
			icon: "<i class='fa fa-save fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					$("#saveRolePermissionSettings").addClass("working");
					setTimeout(function() {
						dialogHider(_dialog);
						buildNotification("Permissions have successfully been updated.", 500, 2000);
					}, 1000);
				}
			}],
			cssClass: "primary"
		}
	} else {
		btn = {
			name: "Add Permission",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					addRoles();
				}
			}],
			cssClass: "primary"
		}
	}

	_dialog.buttons.splice(1, 0,  btn)

	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/* VIEW ROLE DETAILS */
function triggerRoleDialog(el) {
	
	function viewRole() {

		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 11%;' />").appendTo($detailRow),
			$icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell),
			$detailCell = $("<div class='grid-cell' style='width: 88%;padding-top: 40px' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow),							
			$label = $("<label >Role Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow),
			$label = $("<label >Role Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
			
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Division</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px' />").appendTo($dataRow),
			$label = $("<label>Select a Division</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="custom-select" style="max-width: 100%;"><select id="divisionSelection" disabled="disabled" style="min-width: 250px;"><option value="Customer Division 1">Customer Division 1</option><option value="Customer Division 2">Customer Division 2</option><option value="Customer Division 3">Customer Division 3</option></select></div>').appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Internation Payments</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Payment Purpose</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="checkbox" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox" disabled="disabled" name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Approval Discretions</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
		
		var	$boxContent = $("<div class='box-content top-label' style='width: 90%;margin-left: 20px;background: #f8f8f8' />").appendTo($boxContent),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$data = $('<div id="approvaldis"> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Daily</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Batch</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> <div class="grid-cell" style="width: 30%;"> <div class="row" id="paymentAmountRow" style="padding: 0; position: relative;"> <div class="label-column"> <label>Transaction</label> </div> <div class="data-column"> <div class="ccy-amount-input" style="width: 260px"> <input type="text" style="width: 80%;" id="paymentAmount" readonly value="50,000.00"> <div style="background-color: #5d5d5d" class="currency">AUD</div> </div> </div> </div> </div> </div>').appendTo($dataRow);


		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Operating Accounts</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>Deposits</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
			
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box),
			$boxContent = $("<div class='box-content left-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow),
			$label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);

		return $dialogContent;
	}

	var _target = el;
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var _dialog = {
		id: "roleDialog",
		title: "View Permission",
		size: "xxl",
		icon: "<i class='fa fa-cog'></i>",
		content: function() {
			return viewRole()
		},
		buttons: [ {
			name: "Close",
			icon: "<i class='fa fa-close fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/* COPY FROM USER */
function renderUserDetailsDialog(el, item) {

	var _target = $(el);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderUserDetailsContent = function() { 
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='userDetailsDialogContent' />");
		var content = '<div class="grid-layout"><div class="grid-row"><div class="grid-cell"><div class="box"><div class="box-header">User Information</div><div class="box-content left-label"><div class="grid-row"><div class="grid-cell" style="width: 50%;"><div class="row"><div class="label-column"><label>User ID</label></div><div class="data-column"><div class="data-text" id="viewUserID">BAUSR3</div></div></div><div class="row"><div class="label-column"><label>Preferred Name</label></div><div class="data-column"><div class="data-text" id="viewPreferredName">BAUSR3</div></div></div><div class="row"><div class="label-column"><label>Status</label></div><div class="data-column"><div class="data-text" id="viewStatus">Active</div></div></div><div class="row"><div class="label-column"><label>Workflow</label></div><div class="data-column"><div class="data-text" id="viewWorkflow">Pending Approval – Delete</div></div></div></div><div class="grid-cell" style="width: 50%;"><div class="row"> <div class="label-column"><label>First Name</label></div> <div class="data-column"><div class="data-text" id="viewFirstName">William</div></div> </div> <div class="row"> <div class="label-column"><label>Last Name</label></div> <div class="data-column"><div class="data-text" id="viewLastName">Jones</div></div> </div> <div class="row"> <div class="label-column"><label>Managed By</label></div> <div class="data-column"><div class="data-text" id="viewManagedBy">company</div></div> </div> <div class="row"> <div class="label-column"><label>User Credentials</label></div> <div class="data-column"><div class="data-text" id="viewUserCredentials">Password</div></div> </div> <div class="row"> <div class="label-column"><label>User Type</label></div> <div class="data-column"><div class="data-text" id="viewUserType">Admin</div></div> </div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">User Contact Details</div> <div class="box-content left-label"> <div class="grid-row"> <div class="grid-cell" style="width: 50%;"> <div class="row"> <div class="label-column"><label>Address</label></div> <div class="data-column"> <div class="break"><div class="data-text" id="viewAddress1">Level 25/100 Queens Street</div></div> <div class="break"><div class="data-text" id="viewAddress2">Institutional Building</div></div> </div> </div> <div class="row"> <div class="label-column"><label>City</label></div> <div class="data-column"><div class="data-text" id="viewCity">Melbourne</div></div> </div> <div class="row"> <div class="label-column"><label>State</label></div> <div class="data-column"><div class="data-text" id="viewState">Victoria</div></div> </div> <div class="row"> <div class="label-column"><label>Country</label></div> <div class="data-column"><div class="data-text" id="viewCountry">Australia</div></div> </div> <div class="row"> <div class="label-column"><label>ZIP</label></div> <div class="data-column"><div class="data-text" id="viewZip">3000</div></div> </div> </div> <div class="grid-cell" style="width: 50%;"> <div class="row"> <div class="label-column"><label>Mobile Number</label></div> <div class="data-column"><div class="data-text" id="viewMobileNumber">+86 20 5555 5555</div></div> </div> <div class="row"> <div class="label-column"><label>Email Address</label></div> <div class="data-column"><div class="data-text" id="viewEmail">williamjones@prototype.com</div></div> </div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">Permissions</div> <div class="box-content top-label transparent no-row-padding"> <div class="row"> <div class="data-column"> <div class="payment-grid" id="viewPermissions" ></div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">Additional Settings</div> <div class="box-content top-label"> <div class="grid-row"> <div class="grid-cell" style="width: 50%;"> <div class="row"> <div class="label-column"><label>Panel Auth Group</label></div> <div class="data-column"><div class="data-text" id="viewPanelGroup">B-Manager</div></div> </div> </div> </div> </div> </div> </div> </div> <div class="grid-row"> <div class="grid-cell"> <div class="box"> <div class="box-header">Applications</div> <div class="box-content transparent top-label"> <div class="grid-row"> <div class="grid-cell" style="width: 100%;"> <div class="row"> <div class="data-column"> <div class="data-table"> <div class="data-table-row"> <div class="data-table-cell" style="width: 20%;">Application Name</div> <div class="data-table-cell" style="width: 20%;">Application Details</div> </div> <div class="data-table-row"> <div class="data-table-cell">ANZ FX Online</div> <div class="data-table-cell">Contact ANZ for Changes</div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div>';
		$(content).appendTo($dialogContent);
		setTimeout(function() { 
			var grid1;
			var columns1 = [
				{id: "name", name: "Role Name", field: "name",	sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "family", name: "Role Family", field: "family",	sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "description", name: "Role Description", field: "description", sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "division", name: "Division", field: "division", sortable: true,	sorter: "sorterStringCompare",	visible: true},
				{id: "type", name: "Role Type", field: "type", sortable: true,	sorter: "sorterStringCompare",	visible: true}
			];
			var options1 = {
				editable: false,
				autoEdit: false,
				enableCellNavigation: true,
				enableColumnReorder: false,
				enableColumnReorderCheckbox: false,
				syncColumnCellResize: false,
				forceFitColumns: true,
				multiColumnSort: true,
				multiSelect: false,
			};
			var user = searchDataView.getItemById(searchSelectedRowIds);
			var data = user.roles;
			grid1 = new Slick.Grid($('#viewPermissions'), data, columns1, options1);
			grid1.onSort.subscribe(function (e, args) {
			var cols = args.sortCols;
			data.sort(function (dataRow1, dataRow2) {
				for (var i = 0, l = cols.length; i < l; i++) {
				var field = cols[i].sortCol.field;
				var sign = cols[i].sortAsc ? 1 : -1;
				var value1 = dataRow1[field], value2 = dataRow2[field];
				var result = (value1 == value2 ? 0 : (value1 > value2 ? 1 : -1)) * sign;
				if (result != 0) {
					return result;
				}
				}
				return 0;
			});
			grid1.invalidate();
			grid1.render();
			});
			grid1.onClick.subscribe(function(e, args) {
				var cell = grid1.getCellFromEvent(e);
				var row = cell.row;
				var $row = $(e.target).closest(".slick-row");
				triggerRoleDialog($row);
			});
			grid1.init();
		}, 300);

		return $dialogContent;
	}

	var _dialog = {
		id: "userDetailsDialog",
		title: "User Details",
		size: "xxl",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderUserDetailsContent();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function renderSearchUsersGrid() {
	searchData = users;
	searchSelectedRowIds = [];
	searchOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: false,
		headerRowHeight: 40,
		explicitInitialization: true
	};
	searchColumns = [{
		id: "userid",
		name: "User ID",
		field: "userid",
		tooltip: "User ID",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "firstname",
		name: "First Name",
		field: "firstname",
		tooltip: "First Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "lastname",
		name: "Last Name",
		field: "lastname",
		tooltip: "Last Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "id",
		name: "User Details",
		field: "id",
		sortable: false,
		width: 120,
		resizable: false,
		headerCssClass: "centered",
		cssClass: "centered",
		formatter: viewFormatter = function(row, cell, value, columnDef, dataContext) {
			return "<button data-action='view-user-details' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba; cursor: pointer;' id='"+value+"'><i class='fa fa-file-text fa-fw'></i></button>";
		}
	}];
	var searchItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	searchDataView = new Slick.Data.DataView({
		searchItemMetaProvider: searchItemMetaProvider
	});
	searchGrid = new Slick.Grid("#selectUserGrid", searchDataView, searchColumns, searchOptions);
	searchGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	searchGrid.registerPlugin(searchItemMetaProvider);
	searchGrid.onSelectedRowsChanged.subscribe(function(e) {
		searchSelectedRowIds = [];
		var rows = searchGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = searchDataView.getItem(rows[i])
			if (item.id) {
				searchSelectedRowIds.push(item.id);
			}
		}
	});
	searchGrid.onClick.subscribe(function(e, args) {
		var cell = searchGrid.getCellFromEvent(e);
		var row = cell.row;
	});
	searchGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		searchDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});  
	searchDataView.onRowCountChanged.subscribe(function(e, args) {
		searchGrid.updateRowCount();
		searchGrid.render();
	});
	searchDataView.onRowsChanged.subscribe(function(e, args) {
		searchGrid.invalidateRows(args.rows);
		searchGrid.render();
		if (searchSelectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < searchSelectedRowIds.length; i++) {
				var idx = searchDataView.getRowById(searchSelectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			searchGrid.setSelectedRows(selRows);
		}
	});
	searchDataView.beginUpdate();
	searchDataView.setItems(searchData);
	searchDataView.syncGridSelection(searchGrid, true, false);
	searchDataView.syncGridCellCssStyles(searchGrid, "contextMenu");
	searchDataView.endUpdate();
	searchGrid.setColumns(searchColumns);
	$('#selectUserGrid').on("click", "button[data-action='view-user-details']", function(e) {
		var $target = $("#"+$(this).attr("id"));
		var itemID = $target.attr("id");
		renderUserDetailsDialog($target, searchDataView.getItemById(itemID));
		return false;
	});
	setTimeout(function(){
		$("#searchUsers").removeClass("loading");
		searchGrid.init();
		$(window).on('resize.searchgrid', function() {
			searchGrid.resizeCanvas();
		});
	}, 500);
}

function copyFromUser(e) {
	var selectedUser = searchDataView.getItemById(searchSelectedRowIds);
	if ( selectedUser.roles.length == 1 ) {
		setupRolePermissions($(e.target), 'new');
	} else {
		$("#searchUsers").addClass("working");
		setTimeout(function(){
			addRoles()
		}, 500);
	}
}

function searchUsersDialog(e) {

	e.preventDefault();

	var _target = $(this);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderSearchUserContent = function() {
		var $dialogContent = $("<div id='searchUsersDialogContent' />");
		var $wrapper = $("<div class='wrapper' />").appendTo($dialogContent),
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #bfc0c0; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='searchUsersFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Search...' />").on("keyup", function() {
				if (e.which == 27) {
					this.value = "";
				}
				searchList = $.trim(this.value.toLowerCase()).split(' ');
				searchDataView.setFilter(searchGridFilter); 
				searchGrid.invalidate();
				this.focus();
				if (this.value != '') {
					$("#clearUserFilter").show()
				} else {
					$("#clearUserFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearUserFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#searchUsersFilterInput").val('').trigger("keyup");
				$(this).hide();
			}).appendTo($searchDiv);
		var $selectUserGrid = $("<div id='selectUserGrid' style='position: absolute; top: 51px; right: 0; bottom: 0; left: 0;' />").appendTo($dialogContent);

		return $dialogContent;
	}

	var _dialog = {
		id: "searchUsers",
		title: "Select A User",
		size: "xxl",
		icon: "<i class='fa fa-search'></i>",
		content: function() {
			return renderSearchUserContent();
		},
		hasgrid: function() {
			return destroyDialogSearchGrid()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Copy From User",
			icon: "<i class='fa fa-copy fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					copyFromUser(e);
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#searchUsers").addClass("loading");
	renderSearchUsersGrid();
	$("#searchUsersFilterInput").focus();
}


/* ADD EXISTING ROLE */
function renderRoleDetailsDialog(el, item) {

	var _target = $(el);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderRoleDetailsContent = function() { 

		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='roleDetailsDialogContent' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 15%;' />").appendTo($detailRow);
		var $icon = $('<i style="padding: 30px 30px" class="fa fa-user-circle-o fa-5x" aria-hidden="true"></i>').appendTo($detailCell);
		var $detailCell = $("<div class='grid-cell' style='width: 85%; padding-top: 40px' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Cash Management - CM6</div>").appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 140px'/>").appendTo($dataRow);
		var $label = $("<label>Role Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>Create (All Initiation Methods), Approve (Not Own), Reporting</div>").appendTo($dataCol);
				
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Division</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $customSelect = $("<div class='data-text'>Division 1</div>").appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Payments</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>AU Domestic (Direct Credit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Internation Payments</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection5" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Payment Purpose</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="checkbox" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="payrollsaccounts"><label for="payrollsaccounts" class="desc">Standard</label></div><div class="checkbox-group"><input type="checkbox" disabled="disabled" name="payrollsselection" checked="checked" value="no" id="payrollsaccounts1"><label for="payrollsaccounts1" class="desc">Payroll</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Approval Discretions</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" checked="checked"  disabled="disabled" name="payrollsselection" value="yes" id="allproducts"><label for="allproducts" class="desc">Applies to all Payment Products</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="payrollsselection"  value="yes" id="productspecific"><label for="productspecific" class="desc">Product Specific</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($dataRow);
		var	$boxContent = $("<div class='box-content top-label' style='width: 90%; background: #f8f8f8' id='approvaldis' />").appendTo($dataCol);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Daily</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $inputDiv = $("<div class='data-text'>AUD 50,000.00</div>").appendTo($dataCol);
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Batch</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $inputDiv = $("<div class='data-text'>AUD 50,000.00</div>").appendTo($dataCol);
		var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Transaction</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $inputDiv = $("<div class='data-text'>AUD 50,000.00</div>").appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Balance & Transaction Reporting</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Operating Accounts</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection1" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>Deposits</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection2" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
			
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Receivables</div>").appendTo($box);
		var $boxContent = $("<div class='box-content left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>AU Domestic (Direct Debit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection3" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' style='width: 246px'/>").appendTo($dataRow);
		var $label = $("<label>NZ Domestic (Direct Debit)</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $('<div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="all" id="allaccounts" checked="checked"><label for="allaccounts" class="desc">All</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="select" id="selectaccounts"><label for="selectaccounts" class="desc">Selected</label></div><div class="checkbox-group"><input type="radio" disabled="disabled" name="accountselection4" value="none" id="selectaccounts22"><label for="selectaccounts22" class="desc">None</label></div>').appendTo($dataCol);

		return $dialogContent;
	}

	var _dialog = {
		id: "roleDetailsDialog",
		title: "Role Details",
		size: "xxl",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderRoleDetailsContent();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Add &amp; Configure This Role",
			icon: "<i class='fa fa-plus-square fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					setupRolePermissions($(e.target), 'new');
					dialogHider(_dialog);
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function renderSearchRolesGrid() {
	searchData = roles;
	searchSelectedRowIds = [];
	searchOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: false,
		headerRowHeight: 40,
		explicitInitialization: true
	};
	searchColumns = [{
		id: "name",
		name: "Role Name",
		field: "name",
		tooltip: "Role Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "family",
		name: "Role Family",
		field: "family",
		tooltip: "Role Family",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "description",
		name: "Role Description",
		field: "description",
		tooltip: "Role Description",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "division",
		name: "Division",
		field: "division",
		tooltip: "Division",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "type",
		name: "Role Type",
		field: "type",
		tooltip: "Role Type",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}];
	var searchItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	searchDataView = new Slick.Data.DataView({
		searchItemMetaProvider: searchItemMetaProvider
	});
	searchGrid = new Slick.Grid("#selectRoleGrid", searchDataView, searchColumns, searchOptions);
	searchGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	searchGrid.registerPlugin(searchItemMetaProvider);
	searchGrid.onSelectedRowsChanged.subscribe(function(e) {
		searchSelectedRowIds = [];
		var rows = searchGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = searchDataView.getItem(rows[i])
			if (item.id) {
				searchSelectedRowIds.push(item.id);
			}
		}
	});
	searchGrid.onClick.subscribe(function(e, args) {
		var cell = searchGrid.getCellFromEvent(e);
		var row = cell.row;
	});
	searchGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		searchDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});  
	searchDataView.onRowCountChanged.subscribe(function(e, args) {
		searchGrid.updateRowCount();
		searchGrid.render();
	});
	searchDataView.onRowsChanged.subscribe(function(e, args) {
		searchGrid.invalidateRows(args.rows);
		searchGrid.render();
		if (searchSelectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < searchSelectedRowIds.length; i++) {
				var idx = searchDataView.getRowById(searchSelectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			searchGrid.setSelectedRows(selRows);
		}
	});
	searchDataView.beginUpdate();
	searchDataView.setItems(searchData);
	searchDataView.syncGridSelection(searchGrid, true, false);
	searchDataView.syncGridCellCssStyles(searchGrid, "contextMenu");
	searchDataView.endUpdate();
	searchGrid.setColumns(searchColumns);
	setTimeout(function(){
		$("#searchExistingRoles").removeClass("loading");
		searchGrid.init();
		$(window).on('resize.searchgrid', function() {
			searchGrid.resizeCanvas();
		});
	}, 500);
}

function addRoles() {

	var selected = searchDataView.getItemById(searchSelectedRowIds);
	var addedRoles = [];
	var alreadyAdded = false;

	if (selected.record == "Role") {
		for ( var i = 0, l = assignedRoles.length; i < l; i++ ) {
			if ( assignedRoles[i].id == selected.id ) {
				alreadyAdded = true;
				break;
			}
		}

		if (!alreadyAdded) {
			addedRoles.push(selected);
		}

	} else if (selected.record == "User") {
		for ( var i = 0, l = selected.roles.length; i < l; i++) {
			for ( var a = 0, b = assignedRoles.length; a < b; a++) {
				if ( selected.roles[i].id == assignedRoles[a].id ) {
					alreadyAdded = true;
					break;
				}
			}
			if (alreadyAdded) {
				break;
			} else {
				addedRoles.push(selected.roles[i]);
			}
		}

	}
	$("#saveRolePermissionSettings").addClass("working");

	setTimeout(function() {

		if (alreadyAdded) {
			if (selected.record == "Role") {
				$("#saveRolePermissionSettings").removeClass("working");
			} else if (selected.record == "User") {
				if (addedRoles.length == 1) {
					$("#searchUsers").removeClass("working");
				} else {
					$("#saveRolePermissionSettings").removeClass("working");
				}
			}
			buildErrorNotification("Errors Were Detected", "The selected role has already been added for this user.", 300);
		} else {
			dialogHider( {id: "saveRolePermissionSettings"} );
			if (selected.record == "Role") {
				dialogHider( {id: "searchExistingRoles", hasgrid: function() {return destroyDialogSearchGrid()}});
			} else if (selected.record == "User") {
				dialogHider( {id: "searchUsers", hasgrid: function() {return destroyDialogSearchGrid()}});
			}
			for (var i = 0, l = addedRoles.length; i < l; i++) {
				assignedRoles.push(addedRoles[i]);
			}
			if (grid == null) {
				renderAssignedRolesGrid();
			} else {
				data = assignedRoles;
				dataView.setItems(data);
				dataView.refresh();
				grid.invalidate();
				grid.render();
			}
			searchGrid.setSelectedRows([]);
			roleAddedConfirmation(addedRoles);
		}
	}, 1000);
}

function searchRoleDialog(e) {

	e.preventDefault();

	var _target = $(this);
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var renderSearchRolesContent = function() {
		var $dialogContent = $("<div id='searchRolesDialogContent' />");
		var $wrapper = $("<div class='wrapper' />").appendTo($dialogContent),
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #bfc0c0; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='searchRolesFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Search...' />").on("keyup", function() {
				if (e.which == 27) {
					this.value = "";
				}
				searchList = $.trim(this.value.toLowerCase()).split(' ');
				searchDataView.setFilter(searchGridFilter); 
				searchGrid.invalidate();
				this.focus();
				if (this.value != '') {
					$("#clearRolesFilter").show()
				} else {
					$("#clearRolesFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearRolesFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#searchRolesFilterInput").val('').trigger("keyup");
				$(this).hide();
			}).appendTo($searchDiv);
		var $selectRoleGrid = $("<div id='selectRoleGrid' style='position: absolute; top: 51px; right: 0; bottom: 0; left: 0;' />").appendTo($dialogContent);

		return $dialogContent;
	}

	var _dialog = {
		id: "searchExistingRoles",
		title: "Select A Role",
		size: "xxl",
		icon: "<i class='fa fa-search'></i>",
		content: function() {
			return renderSearchRolesContent();
		},
		hasgrid: function() {
			return destroyDialogSearchGrid()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Continue",
			icon: "<i class='fa fa-chevron-circle-right fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					setupRolePermissions($(e.target), 'new');
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#searchExistingRoles").addClass("loading");
	renderSearchRolesGrid();
	$("#searchRolesFilterInput").focus();
}



/* ROLE ADDED CONFIRMATION */
function roleAddedConfirmation(roles) {
	var msg;
	if (roles.length == 1) {
		msg = "<strong>The follwing permission has been added to this user:</strong>";
	} else {
		msg = "<strong>The follwing permissions have been added to this user:</strong>";
	}
	msg = msg + "<span style='display: block; color: #007dba; margin-top: 30px;'>";
	$.each(roles, function(){ msg = msg + this.name+'<br />'});
	msg = msg + "</span>";
	setTimeout(function(){
		buildConfirmDialog(msg, "You can <strong>change the settings account access</strong> for a permission by clicking on the <strong>Edit Permission</strong> icon in the User Permission table.", "");
	}, 300);
}



/* ASSIGNED ROLES */
function removeAssignedRoles() {
	if (selectedRowIds.length >= 1) {
		var $shell = $(".shell");
		$shell.addClass("loading");
		var reloadAddedRolesGrid = function() {
			grid.setSelectedRows(0);
			selectedRowIds = [];
			dataView.refresh();
			grid.invalidate();
			grid.render();
			if (!grid.getDataLength()) {
				$("#removeAddedRolesButton").addClass("disabled").off("click");
				grid.destroy();
				grid = null;
				$('#permissionGrid').off("click.editRole");
				var $noPermissions = $("<div class='loading-text'>This user has no assigned roles</div>").appendTo($("#permissionGrid"));
			}
			$shell.removeClass("loading");
		}
		setTimeout(function() {
			var rowsForDelete = [];
			for (var i = 0, l = selectedRowIds.length; i < l; i++) {
				var item = selectedRowIds[i];
				if (item) rowsForDelete.unshift(item)
			};
			for (var i = 0; i < rowsForDelete.length; i++) {
				dataView.deleteItem(rowsForDelete[i])
			};
			reloadAddedRolesGrid();	
		}, 500);
	} else {
		return false;
	}
}

function renderAssignedRolesGrid() {

	data = assignedRoles;
	selectedRowIds = [];
	options = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: true,
		enableColumnReorder: false,
		enableColumnResize: true,
		syncColumnCellResize: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: false,
		multiColumnSort: true,
		showHeaderRow: true,
		headerRowHeight: 40,
		explicitInitialization: true
	};
	columns = [{
		id: "name",
		name: "Role Name",
		field: "name",
		tooltip: "Role Name",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "family",
		name: "Role Family",
		field: "family",
		tooltip: "Role Family",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "description",
		name: "Role Description",
		field: "description",
		tooltip: "Role Description",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "division",
		name: "Division",
		field: "division",
		tooltip: "Division",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "type",
		name: "Role Type",
		field: "type",
		tooltip: "Role Type",
		width: 120,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: true
	}, {
		id: "id",
		name: "Role Details",
		field: "id",
		sortable: false,
		width: 120,
		resizable: false,
		headerCssClass: "centered",
		cssClass: "centered",
		formatter: viewFormatter = function(row, cell, value, columnDef, dataContext) {
			return "<button data-action='edit-role-details' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba; cursor: pointer;' data-id='"+value+"'><i class='fa fa-pencil-square-o fa-fw'></i></button>";
		}
	}];

	var checkboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	columns.unshift(checkboxSelector.getColumnDefinition());

	function gridFilter(item, args) {
		for (var columnId in columnFilters) {
			if (columnId !== undefined && columnFilters[columnId] !== "") {
				var c = grid.getColumns()[grid.getColumnIndex(columnId)],
					_sorter = c.sorter;
				if (_sorter == "sorterNumeric") {
					var _filter = columnFilters[columnId],
						_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
						_greaterThen, _lessThen, _comparer, _between = false;
					if (_filter.charAt(0) === ">") {
						_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
						if (_filter.indexOf("<") != -1) {
							_between = true
						}
						if (_between) {
							_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
							if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
								return false;
							}
						} else {
							if (parseFloat(_field) < parseFloat(_greaterThen)) {
								return false;
							}
						}
					} else if (_filter.charAt(0) === "<") {
						_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
						if (_filter.indexOf(">") != -1) {
							_between = true
						}
						if (_between) {
							_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
							if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
								return false;
							}
						} else {
							if (parseFloat(_field) > parseFloat(_lessThen)) {
								return false;
							}
						}
					} else {
						if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
							return false;
						}
					}
				} else {
					if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
						return false;
					}
				}
			}
		}
		return true;
	}

	var itemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		itemMetaProvider: itemMetaProvider
	});
	grid = new Slick.Grid("#permissionGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(checkboxSelector);
	grid.registerPlugin(itemMetaProvider);
	grid.onSelectedRowsChanged.subscribe(function(e) {
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
			}
		}
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column" || args.column.id == 'id') {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none; margin-left: -33px;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});	    
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.beginUpdate();
	dataView.setItems(assignedRoles);
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(gridFilter);
	dataView.endUpdate();
	grid.setColumns(columns);
	$(window).on("resize.grid", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize.grid", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));
	$('#permissionGrid').on("click.editRole", "button[data-action='edit-role-details']", function(e) {
		var $target = $(this);
		var itemID = $target.attr("data-id");
		setupRolePermissions($target, 'edit');
		/* renderRoleDetailsDialog($target, dataView.getItemById(itemID)); */
		return false;
	});
	grid.init();
	grid.setHeaderRowVisibility(false);
	$("#removeAddedRolesButton").removeClass("disabled").on("click", removeAssignedRoles);
}


/* RENDER USER CREATION FORM */
function renderUserCreationForm() {

	/* the form grid layout div */
	var $gridLayout = $("<div class='grid-layout' />");

	/* the user details section */
	var $gridRow = $("<div class='grid-row' id='userDetails' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>User Details</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>First Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='firstName' />").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Last Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='lastName' />").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Preferred Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='preferredName' />").appendTo($dataCol);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>E-mail Address</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 80%;' id='userEmail' />").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>User ID</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $div = $("<div id='userIdField' style='position: relative; display: inline-block; width: 80%; margin-right: 10px;' />").appendTo($dataCol);
	var $data = $("<input type='text' style='width: 100%; max-width: 100%; padding-right: 35px;' id='userID' />").appendTo($div).on("change", handleUserIDChange);
	var $icon = $("<i class='fa fa-check-circle fa-fw' style='display: none; position: absolute; top: 7px; right: 3px; font-size: 20px;' />").appendTo($div);
	var $btnSpan = $("<span class='form-button' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)'><i class='fa fa-check fa-fw'></i>Check Availability</a>").appendTo($btnSpan).on("click", checkAvailabilityOfUserID);
	var $dataNote = $("<div class='data-note'>Suggested User ID: </div>").appendTo($dataCol);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 67%;' />").appendTo($gridRow);
	var $row = $("<div class='row mandatory' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Address</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 90%; max-width: 90%;' />").appendTo($dataCol);
	var $select = $("<select id='userAddress' ><option value=''>Please choose a delivery address</option><option value='new'>+ Add New delivery address</option><option value='address1'>Level 12, 530 Collins Street, Melbourne, Australia, Victoria, 3000</option></select>").appendTo($customSelect);
	var $note = $("<div class='data-note'>Please choose the users physical address as this will be used to deliver physical security devices.</div>").appendTo($dataCol);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Phone Number</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<input type='text' style='width: 60px;' id='phoneCountryCode' />").appendTo($dataCol);
	var $data = $("<input type='text' style='width: 55%;' id='phoneNumber' />").appendTo($dataCol);

	/* the user permissions section */
	var $gridRow = $("<div class='grid-row' id='userPermissions' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>User Permissions</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $row = $("<div class='row' style='padding-bottom: 15px;' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $btnSpan = $("<span class='btn' style='max-width: 300px !important;' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)' data-type='copy'><i class='fa fa-copy fa-fw text-right'></i><span>Copy Permissions from Another User</span></a>").appendTo($btnSpan).on("click", searchUsersDialog);
	var $btnSpan = $("<span class='btn' style='max-width: 300px !important;' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)' data-type='select'><i class='fa fa-plus-square fa-fw text-right'></i><span>Add Permissions</span></a>").appendTo($btnSpan).on("click", searchRoleDialog);
	var $btnSpan = $("<span class='btn' style='max-width: 300px !important;' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)'><i class='fa fa-edit fa-fw text-right'></i><span>Create a New Role</span></a>").appendTo($btnSpan).on("click", createNewRoleDialog);
	var $btnSpan = $("<span class='btn disabled' style='max-width: 300px !important;' id='removeAddedRolesButton' />").appendTo($dataCol);
	var $btnAnchor = $("<a href='javascript:void(0)'><i class='fa fa-trash fa-fw text-right'></i><span>Remove Roles</span></a>").appendTo($btnSpan);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $row = $("<div class='row' style='padding: 0;' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column full' id='searchRoleSection' style='display: none; border-top: 1px solid #cdcdcd;' />").appendTo($row);

	/* added roles */
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%; border-top: 1px solid #cdcdcd;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);
	var $permissionGrid = $("<div class='payment-grid' id='permissionGrid' />").appendTo($dataCol);
	var $noPermissions = $("<div class='loading-text'>This user has no assigned roles</div>").appendTo($permissionGrid);

	/* additional settings */
	var $gridRow = $("<div class='grid-row' id='additionalSettings' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Additional Settings</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Panel Authorisation Group</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
	var $select = $("<select id='panelAuthGroup'><option value=''>Panel A</option><option value=''>Panel B</option><option value=''>Panel C</option></select>").appendTo($customSelect);

	/* application section */
	var $gridRow = $("<div class='grid-row' id='applicationSection' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Applications</div>").appendTo($box);
	var $boxContent = $("<div class='box-content' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);
	var $heading = $("<div class='row-subheading'>ANZ Transactive - AU &amp; NZ</div>").appendTo($dataCol);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>User Group ID</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
	var $select = $("<select id='userGroupId'><option value=''>111111</option><option value=''>222222</option><option value=''>33333</option></select>").appendTo($customSelect);
	var $gridCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>User Group Name</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $data = $("<div class='data-text'>Transactive Global Group Name</div>").appendTo($dataCol);

	/* the user login credential section */
	var $gridRow = $("<div class='grid-row' id='loginCredentials' />").appendTo($gridLayout);
	var $gridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($gridRow);
	var $box = $("<div class='box' />").appendTo($gridCell);
	var $boxHeader = $("<div class='box-header'>Login Credentials</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $div = $("<div class='login-type' data-login-type='password' title='User requires only a password to login and access the system' />").appendTo($dataCol).on("click", loginCredentialSelection);
	var $icon = $("<i class='fa fa-lock login-type-image'></i>").appendTo($div);
	var $text = $("<span>Password Only</span>").appendTo($div);
	var $radioIcon = $("<i class='fa fa-circle-thin fa-fw login-radio-button'></i>").appendTo($div);
	var $gridCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $div = $("<div class='login-type' data-login-type='token' title='User requires a Pin-pad Token in order to login and access the system' />").appendTo($dataCol).on("click", loginCredentialSelection);
	var $icon = $("<i class='fa fa-calculator login-type-image'></i>").appendTo($div);
	var $text = $("<span>Pin-pad Token</span>").appendTo($div);
	var $radioIcon = $("<i class='fa fa-circle-thin fa-fw login-radio-button'></i>").appendTo($div);
	var $tokenDiv = $("<div id='tokenDetails' style='display: none;' />").appendTo($gridCell);
	var $row = $("<div class='row mandatory' />").appendTo($tokenDiv);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Date of Birth</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $dateInputDiv = $("<div class='date-input-div' style='width: 178px;' />").appendTo($dataCol);
	var $input = $("<input type='text' id='dob' placeholder='dd/mm/yyyy' value='' />").appendTo($dateInputDiv).datepicker({
		dateFormat: 'dd/mm/yy',
		constrainInput: true,
		changeMonth: true,
		changeYear: true,
		duration: 0,
		maxDate: 0,
		yearRange: "-100:+0",
		beforeShow: function() {
			var widget = $("#dob").datepicker("widget");
			widget.appendTo($("#dobCalendar"));
			$("#dobCalendar").show();
		},
		onClose: function() {
			var widget = $("#dob").datepicker("widget");
			widget.appendTo($("body"));
		}
	}).mask("99/99/9999", {
		placeholder: "dd/mm/yyyy"
	}).on("change", function(){
		record.dob = $(this).val();
	});
	var $dataNote = $("<div class='data-note'>Date of birth information is used by ANZ for meeting our Know Your Customer obligations and user identification. This information is not visible to company administrators after entry.</div>").appendTo($dataCol);
	var $calendarDiv = $("<div id='dobCalendar' class='date-picker-div' style='top: -186px;' />").appendTo($dateInputDiv);
	var $gridCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($gridRow);
	var $row = $("<div class='row' />").appendTo($gridCell);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $div = $("<div class='login-type' data-login-type='usb' title='User requires a USB Smartcard device in order to login and access the system' />").appendTo($dataCol).on("click", loginCredentialSelection);
	var $icon = $("<i class='fa fa-usb login-type-image'></i>").appendTo($div);
	var $text = $("<span>Smart USB</span>").appendTo($div);
	var $radioIcon = $("<i class='fa fa-circle-thin fa-fw login-radio-button'></i>").appendTo($div);

	var $btnGridRow = $("<div class='grid-row' id='submitButtonSection' />").appendTo($gridLayout);
	var $btnGridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($btnGridRow);
	var $btnRow = $("<div class='row' style='padding: 15px 0;' />").appendTo($btnGridCell);
	var $btnDataCol = $("<div class='data-column' style='width: 100%; text-align: right; padding-right: 0;' />").appendTo($btnRow);
	var $submitBtn = $("<span class='form-button action' />").appendTo($btnDataCol);
	var $submitBtnAnchor = $("<a href='javascript:void(0)' />").appendTo($submitBtn).on("click", submitUser);
	var $submitIcon = $("<i class='fa fa-share-square fa-fw'></i>").appendTo($submitBtnAnchor);
	var $submitText = $("<span>Submit</span>").appendTo($submitBtnAnchor);

	$gridLayout.appendTo($userForm);

	function addAddress() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Address Details</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' style='padding-bottom: 25px' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$row = $("<div class='row mandatory' />").appendTo($detailCell),
		$label = $('<div class="label-column"><label>Address Line 1</label></div>').appendTo($row);
		$dataCol = $('<div class="data-column" />').appendTo($row),
		$input = $("<input type='text' style='width: 100%;max-width: 100%' id='address1' />").appendTo($dataCol);
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$row = $("<div class='row mandatory' />").appendTo($detailCell),
		$label = $('<div class="label-column"><label>Address Line 2</label></div>').appendTo($row);
		$dataCol = $('<div class="data-column" />').appendTo($row),
		$input = $("<input type='text' style='width: 100%;max-width: 100%' id='address2' />").appendTo($dataCol);
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$row = $("<div class='row mandatory' />").appendTo($detailCell),
		$label = $('<div class="label-column"><label>City/Suburb</label></div>').appendTo($row);
		$dataCol = $('<div class="data-column" />').appendTo($row),
		$input = $("<input type='text' style='width: 100%;max-width: 100%' id='city' />").appendTo($dataCol);
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$row = $("<div class='row mandatory' />").appendTo($detailCell),
		$label = $('<div class="label-column"><label>Country</label></div>').appendTo($row);
		$dataCol = $('<div class="data-column" />').appendTo($row),
		$('<div class="custom-select" style="max-width: 100%;"><select id="countrySelection" style="width: 208px"><option value="Select Country">Select Country</option><option value="Australia">Australia</option><option value="China">China</option></select></div>').appendTo($dataCol)
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$row = $("<div class='row mandatory' />").appendTo($detailCell),
		$label = $('<div class="label-column"><label>State</label></div>').appendTo($row);
		$dataCol = $('<div class="data-column" />').appendTo($row),
		$('<div class="custom-select" style="max-width: 100%;"><select id="stateSelection" style="width: 208px"><option value="Select State">Select State</option></select></div>').appendTo($dataCol)
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$row = $("<div class='row mandatory' />").appendTo($detailCell),
		$label = $('<div class="label-column"><label>ZIP</label></div>').appendTo($row);
		$dataCol = $('<div class="data-column" />').appendTo($row),
		$input = $("<input type='text' style='width: 100%;max-width: 100%' id='zip' />").appendTo($dataCol);
		setTimeout(function(){ 
			$('#countrySelection').on("click", function(e) {
					$("#stateSelection option[value='Victoria']").remove();
					$("#stateSelection option[value='New South Wales']").remove();
					$("#stateSelection option[value='Hong Kong']").remove();
					$("#stateSelection option[value='Shanghai']").remove();
					if ($(this).val() == "Australia") {
						var newOption = $('<option>');
						newOption.attr('value', 'Victoria').text('Victoria');
						$('#stateSelection').append(newOption);
						var newOption = $('<option>');
						newOption.attr('value', 'New South Wales').text('New South Wales');
						$('#stateSelection').append(newOption);
					} else if ($(this).val() == "China") {
						var newOption = $('<option>');
						newOption.attr('value', 'Hong Kong').text('Hong Kong');
						$('#stateSelection').append(newOption);
						var newOption = $('<option>');
						newOption.attr('value', 'Shanghai').text('Shanghai');
						$('#stateSelection').append(newOption);
					}
				});
		}, 1000);
		return $dialogContent;
	}

	function saveAddress(_dialog) {
		$(".shell").addClass("loading");
		var address = $('#address1').val()+','+ $('#address2').val()+','+ $('#city').val()+','+ $('#countrySelection').val()+','+ $('#stateSelection').val()+','+ $('#zip').val();
		var reloadPage = function() {
			setTimeout(function() {
				var msg = "Address added successfully."
				buildNotification(msg, 500, 5000);
				var newOption = $('<option>');
				newOption.attr('value',address ).text(address);
				$('#userAddress').append(newOption);
				$(".shell").removeClass("loading");
			}, 1500);
		}
		reloadPage();
		dialogHider(_dialog);
	}

	$('#userAddress').on("change", function(e){
		e.preventDefault();
		if($(this).val() == "new") {
			$('#userAddress').val('');
			var _target = $(this);
			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "addaddress",
				title: "Add New Address",
				size: "wide",
				icon: "<i class='fa fa-plus-square'></i>",
				content: function() {
					return addAddress()
				},
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							saveAddress(_dialog);
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}
	});

}



$(function() {
	renderUserCreationForm();
});