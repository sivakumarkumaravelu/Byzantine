/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Accounts Onscreen Guide",
	action: "slider"
}, {
	title: "How do I perform an action on multiple accounts?",
	faq: "<p>Place a tick next to the accounts &gt; Right-click to see available actions (i.e. Request a report or Move Accounts to a folder).</p>"
}, {
	title: "How do I manage my Accounts into Folders?",
	faq: "<p>Create folders to categorise your accounts by;<br />Selecting the Folder menu &gt; Manage Folders &gt; Enter Name for new folder &gt; Click Add &gt; Click OK.</p><p>Add/Remove Accounts from Folders by;<br />Selecting one or more accounts &gt; Right--click &gt; Move To &gt; Select a folder to add account&#47;s to <em>OR</em> select None to remove the account&#47;s from a folder.</p>"
}, {
	title: "Can the system remember my preferred settings?",
	faq: "<p>By selecting &#39;Remember Settings&#39; from the Action Menu, the application will remember your folder and grouping selections for this screen. </p>"
}, {
	title: "How do I make this screen my Homepage?",
	faq: "<p>Drop down the Settings & Preferences menu (displayed as your User Name on the top right of the screen) &gt; select &#39;Set this page as my home page&#39;.</p>"
}, {
	title: "How do I view my account Balance Summary?",
	faq: "<p>Select an account &gt; click on the Balance Summary tab to view and download account balances.</p>"
}, {
	title: "How do I customise my view of the Operating Accounts screen?",
	faq: "<p>&gt; Sort columns by clicking on a column heading. <br />&gt; Drag and drop columns to order them in your preferred sequence.<br />&gt; Right-click on any column heading to set which columns you would like to appear in this screen.</p>"
}];