/**********************************************************************
						MICRO-TEMPLATE
**********************************************************************/
(function(){
  var cache = {};
  this.tmpl = function tmpl(str, data){
	var fn = !/\W/.test(str) ?
	  cache[str] = cache[str] ||
		tmpl(document.getElementById(str).innerHTML) :
	  new Function("obj",
		"var p=[],print=function(){p.push.apply(p,arguments);};" +
		"with(obj){p.push('" +
		str
		  .replace(/[\r\t\n]/g, " ")
		  .split("<%").join("\t")
		  .replace(/((^|%>)[^\t]*)'/g, "$1\r")
		  .replace(/\t=(.*?)%>/g, "',$1,'")
		  .split("\t").join("');")
		  .split("%>").join("p.push('")
		  .split("\r").join("\\'")
	  + "');}return p.join('');");
	return data ? fn( data ) : fn;
  };
})();


/**********************************************************************
SETUP THE REPORT DETAIL SCREEN
**********************************************************************/
var gridMode = "my", loadRecordTimer;
function setupReportDetails(item, mode) {
	if ( typeof(filterGrid) != 'undefined' && filterGrid != null ) {				
		filterGrid.destroy()
		filterData = []
		filterAccountData = []
		filterCurrencyData = []
	}
	if ( jQuery.type(item) === "object" ) {
		$("[data-value='repname']").html(item.repname)
		if ( item.shared != "" ) {
			$("[data-value='shared']").html("<i class='fa fa-check fa-fw' style='margin-right: 4px;'></i> Report Sharing Enabled");
			$("#_sharedfield").prop("checked",true)
		} else {
			$("[data-value='shared']").html('&nbsp;');
			$("#_sharedfield").prop("checked",false)
		}
		$("[data-value='description']").html(item.description)
		$("[data-value='reptype']").html(item.reptype)
		$("[data-value='datefilter']").html(item.datefilter)
		$("[data-value='fromdate']").html(item.fromdate)
		$("[data-value='todate']").html(item.todate)
		$("[data-value='filtertype']").html(item.filtertype)
		$("[data-value='createdon']").html(item.createdon)
		$("[data-value='ownedby']").html(item.ownedby)
		$("#_repnamefield").val(item.repname)
		$("#_descriptionfield").val(item.description)
		$("#_reptypefield").val(item.reptype)
		$("#_filteroption").find("input[value='"+item.filtertype+"']").prop("checked",true)
		$("#_datefilterfield").val(item.datefilter)
	}
	if (mode == "view") {
		$("#_editButtons, #_newButtons, #_filterBtns").hide();
		$("#_viewButtons, #_navButtons, #_repFilter, #_filters, #_auditHistory").show()
		$("#_reportForm").find("span[data-mode='edit']").hide()
		$("#_reportForm").find("span[data-mode='view']").show()
		if (item.ownedby != "PrototypeUser") {
			$("#_editButton, #_deleteButton").hide();
		} else {
			$("#_editButton, #_deleteButton").show();
		}
		if (item.filtertype == "Currency") {
			 $("#_filters").find("label").html("Selected Currencies")
			filterColumns = [{ id:"ccy", name:"Currency Code", field:"ccy",  toolTip:"Click to sort by Currency Code", width: 150, sortable: true, cssClass: "cursor-default" },{ id:"ccyname", name:"Currency Description", field:"ccyname", toolTip:"Click to sort by Currency Description", width: 200, sortable: true, cssClass: "cursor-default" }]
			filterCurrencyData = item.filters
		} else if (item.filtertype == "Account") {
			 $("#_filters").find("label").html("Selected Accounts")
			filterColumns = [{ id:"accountnam", name:"Account Name", field:"accountnam",  toolTip:"Click to sort by Account Name", width: 200, sortable: true, cssClass: "cursor-default" },{ id:"accountnum", name:"Account Number", field:"accountnum", toolTip:"Click to sort by Account Number", width: 200, sortable: true, cssClass: "cursor-default" }]
			filterAccountData = item.filters
		}
		filterData = item.filters;
		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e,args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e,args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});	
		filterDataView.setItems(filterData);
		filterGrid.setColumns(filterColumns);
	}
	else if (mode == "edit") {
		$("#_newButtons, #_viewButtons, #_navButtons").hide();
		$("#_editButtons, #_repFilter, #_filters, #_auditHistory, #_filterBtns").show();
		$("#_reportForm").find("span[data-mode='view']").hide();
		$("#_reportForm").find("span[data-mode='edit']").show();
		if (item.filtertype == "Currency") {
			$("#_filterBtns a[data-action='add-filters']").attr("href","#_addCurrencies")
			$("#_filters").find("label").html("Select Currencies")
			filterColumns = [{ id:"ccy", name:"Currency Code", field:"ccy",  toolTip:"Click to sort by Currency Code", width: 200, sortable: true, cssClass: "cursor-default" },{ id:"ccyname", name:"Currency Description", field:"ccyname", toolTip:"Click to sort by Currency Description", width: 200, sortable: true, cssClass: "cursor-default" }]
			filterCurrencyData = item.filters
		} else if (item.filtertype == "Account") {
			$("#_filterBtns a[data-action='add-filters']").attr("href","#_addAccounts")
			$("#_filters").find("label").html("Select Accounts")
			filterColumns = [{ id:"accountnam", name:"Account Name", field:"accountnam",  toolTip:"Click to sort by Account Name", width: 200, sortable: true, cssClass: "cursor-default" },{ id:"accountnum", name:"Account Number", field:"accountnum", toolTip:"Click to sort by Account Number", width: 200, sortable: true, cssClass: "cursor-default" }]
			filterAccountData = item.filters
		}
		$("#_datefilterfield").trigger("change");
		$("#_datefrom").datepicker("setDate", item.fromdate);
		$("#_dateto").datepicker("setDate", item.todate);
		
		filterData = item.filters;
		var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
			cssClass: "slick-cell-checkboxsel"
		});
		filterColumns.unshift(filterCheckboxSelector.getColumnDefinition());		
		filterDataView = new Slick.Data.DataView({});
		filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
		filterGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
		filterGrid.registerPlugin(filterCheckboxSelector);	
		filterGrid.onSelectedRowsChanged.subscribe(function(e) {
			filterSelectedRowIds = [];
			var rows = filterGrid.getSelectedRows();
			for (var i = 0, l = rows.length; i < l; i++) {
				var item = filterDataView.getItem(rows[i]);
				if (item) filterSelectedRowIds.push(item.id);
			}
		});
		filterGrid.onSort.subscribe(function(e, args) {
			sortcol = args.sortCol.field;
			sortdir = args.sortAsc ? 1 : -1;
			filterDataView.fastSort(sortcol, args.sortAsc);
		});
		filterDataView.onRowCountChanged.subscribe(function(e,args) {
			filterGrid.updateRowCount();
			filterGrid.render();
		});
		filterDataView.onRowsChanged.subscribe(function(e,args) {
			filterGrid.invalidateRows(args.rows);
			filterGrid.render();
		});	
		filterDataView.setItems(filterData);
		filterGrid.setColumns(filterColumns);	
		$("#_datefrom").datepicker("hide");	
		$("#_dateto").datepicker("hide");
		$("#_reptypefield").focus();
	}
	else if (mode == "new") {
		$("#_editButtons, #_viewButtons, #_navButtons, #_repFilter, #_auditHistory").hide();
		$("#_datefrom, #_dateto").attr({"disabled":"disabled"}).datepicker("destroy").val('').hide();
		$("#_newButtons").show()
		$("#_reportForm").find("span[data-mode='view']").hide()
		$("#_reportForm").find("span[data-mode='edit']").show()
		$("#_reportForm").find("input[type='text'],input[type='hidden'],select,textarea").val('');
		$("#_reportForm").find("input[type='checkbox'], input[type='radio']").prop("checked",false);
		$("#_reptypefield").focus()
	}
	if (mode == "edit" || mode == "new") {
		$("#_reptypefield").on("change", function(e) {
			var $target = $(e.target), type = $("#_reptypefield").val();
			if (type == "") {
				$("#_repFilter").hide()
			} else {
				$("#_filters").hide()
				$("#_repFilter").show().find("input[type='checkbox'], input[type='radio']").prop("checked",false)
				if ( typeof(filterGrid) != 'undefined' && filterGrid != null ) { filterGrid.destroy(); filterData = [], filterCurrencyData = [], filterAccountData = [] }
			}
		});
		$("#_reportForm input[name='ftype']").on("change", function(e) {
			var type = $("#_reportForm input[name='ftype']:checked").val()
			if ( !$("#_filters").is(":visible") ) {$("#_filters").show()}		
			if ( typeof(filterGrid) != 'undefined' && filterGrid != null ) { filterGrid.destroy(); filterData = [] }
			if (type == "Currency") {
				$("#_filterBtns").show().find("a[data-action='add-filters']").attr("href","#_addCurrencies")
				$("#_filters").find("label").html("Select Currencies")
				filterColumns = [{ id:"ccy", name:"Currency Code", field:"ccy",  toolTip:"Click to sort by Currency Code", width: 200, sortable: true, cssClass: "cursor-default" },{ id:"ccyname", name:"Currency Description", field:"ccyname", toolTip:"Click to sort by Currency Description", width: 200, sortable: true, cssClass: "cursor-default" }]
				filterData = filterCurrencyData
			} else if (type == "Account") {
				$("#_filterBtns").show().find("a[data-action='add-filters']").attr("href","#_addAccounts")
				$("#_filters").find("label").html("Select Accounts")
				filterColumns = [{ id:"accountnam", name:"Account Name", field:"accountnam",  toolTip:"Click to sort by Account Name", width: 200, sortable: true, cssClass: "cursor-default" },{ id:"accountnum", name:"Account Number", field:"accountnum", toolTip:"Click to sort by Account Number", width: 200, sortable: true, cssClass: "cursor-default" }]
				filterData = filterAccountData
			}			
			var filterCheckboxSelector = new Slick.CheckboxSelectColumn({
				cssClass: "slick-cell-checkboxsel"
			});
			filterColumns.unshift(filterCheckboxSelector.getColumnDefinition());		
			filterDataView = new Slick.Data.DataView({});
			filterGrid = new Slick.Grid("#_addedFilters", filterDataView, filterColumns, filterOptions);
			filterGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
			filterGrid.registerPlugin(filterCheckboxSelector);	
			filterGrid.onSelectedRowsChanged.subscribe(function(e) {
				filterSelectedRowIds = [];
				var rows = filterGrid.getSelectedRows();
				for (var i = 0, l = rows.length; i < l; i++) {
					var item = filterDataView.getItem(rows[i]);
					if (item) filterSelectedRowIds.push(item.id);
				}
			});
			filterGrid.onSort.subscribe(function(e, args) {
				sortcol = args.sortCol.field;
				sortdir = args.sortAsc ? 1 : -1;
				filterDataView.fastSort(sortcol, args.sortAsc);
			});
			filterDataView.onRowCountChanged.subscribe(function(e,args) {
				filterGrid.updateRowCount();
				filterGrid.render();
			});
			filterDataView.onRowsChanged.subscribe(function(e,args) {
				filterGrid.invalidateRows(args.rows);
				filterGrid.render();
			});	
			filterDataView.setItems(filterData);
			filterGrid.setColumns(filterColumns);
		});
		$("[data-action='remove-filters']").on("click", function(e) {
			e.preventDefault();
			var $target = $(e.target);
			if ( filterSelectedRowIds.length > 0 ) {
				function removeFilters() {
					var rowsForDelete = [];
					for (var i = 0, l = filterSelectedRowIds.length; i < l; i++) { var item = filterSelectedRowIds[i]; if (item) rowsForDelete.unshift(item) };
					for (var i=0;i<rowsForDelete.length;i++) {filterDataView.deleteItem(rowsForDelete[i])};
					filterSelectedRowIds = [];
					filterDataView.refresh();
					filterGrid.invalidate();
					filterGrid.render();
					filterGrid.setSelectedRows(0);
					if ( $("#_reportForm input[name='ftype']:checked").val() == "Account" ) {
						filterAccountData = filterDataView.getItems()
					} else {
						filterCurrencyData = filterDataView.getItems()
					}
				}
				buildConfirmDialog( "Remove selected items?", "", function(){removeFilters(e)});
			}
		});
		$("#_addSelectedAccounts").on("click", function(e) {
			if (findSelectedRowIds.length > 0) {
				var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a");
				var addSelected = function() {
					for (var i=findSelectedRowIds.length-1; i >= 0 ; i--) {
						var itemID = "id_"+Math.round(Math.random() * 12345), itemACCNAM = "CURRENT"+Math.round(Math.random() * 1000), itemACCNUM = Math.round(Math.random() * 1000000000).toString();
						filterData.push({id: itemID, accountnam: itemACCNAM, accountnum: itemACCNUM })	
					}
					filterDataView.setItems(filterData);
					filterDataView.refresh();
					filterAccountData = filterDataView.getItems();
					filterGrid.updateRowCount();
					filterGrid.render();
					$primarytab.removeClass("load");
					$loading.addClass("hidden");
					findGrid.setSelectedRows(0);
					$("#_addAccounts").closeDialog();
				}
				$primarytab.addClass("load");
				$loading.removeClass("hidden");
				setTimeout(addSelected, 500);
			} else {
				alert("Select accounts to add them to the report filter");
			}
		});
		$("#_addSelectedCurrencies").on("click", function(e) {
			if (findCCYSelectedRowIds.length > 0) {
				var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a");
				addSelected = function() {
					var rowsToAdd = [];
					for (var i = 0, l = findCCYSelectedRowIds.length; i < l; i++) {
						var item = findCCYSelectedRowIds[i];
						if (item) {
							var itemID = "id_"+Math.round(Math.random() * 12345);
							var itemCCY = findCCYDataView.getItemById(item).ccy;
							var itemName = findCCYDataView.getItemById(item).ccyname;
							rowsToAdd.unshift({id: itemID, ccy: itemCCY, ccyname: itemName})
						}
					};
					for (var i=0; i<rowsToAdd.length; i++) { filterData.push(rowsToAdd[i]) };
					filterDataView.setItems(filterData);
					filterDataView.refresh();
					filterCurrencyData = filterDataView.getItems();
					filterGrid.updateRowCount();
					filterGrid.render();
					$primarytab.removeClass("load");
					$loading.addClass("hidden");
					findCCYGrid.setSelectedRows(0);
					$("#_addCurrencies").closeDialog();
				}
				$primarytab.addClass("load");
				$loading.removeClass("hidden");
				setTimeout(addSelected, 500);
			} else {
				alert("Select currencies to add them to the report filter");
			}
		});
	}
}
function saveNewReport() {
	var sharedSetting, sharedBySetting, filteredData;
	var newID = Math.round(Math.random() * 1000000000);
	if ( $("#_sharedfield").is(":checked") ) {sharedSetting = "Yes"; sharedBySetting = "PrototypeUser"} else {sharedSetting = ""; sharedBySetting = ""}
	if (filterDataView) { filteredData = filterDataView.getItems() } else { filteredData = '' }
	var updatedItem = {
		id: newID,
		reptype: $("#_reptypefield").val(),
		repname: $("#_repnamefield").val(),
		description: $("#_descriptionfield").val(),
		shared: sharedSetting,
		sharedby: sharedBySetting,
		ownedby: "PrototypeUser",
		createdon: $.datepicker.formatDate('dd/mm/yy', new Date()),
		datefilter: $("#_datefilterfield").val(),
		fromdate: $("#_datefrom").val(),
		todate: $("#_dateto").val(),
		filtertype: $("#_filteroption").find("input[name='ftype']:checked").val(),
		filters: filteredData
	};
	data.push(updatedItem)
	dataView.setItems(data)
	if ( $("#_sharedfield").is(":checked") ) {
		sharedData.push(updatedItem)
	}
	grid.setSelectedRows([dataView.getRowById(updatedItem.id)])
}
function updateReport(item) {
	var report = dataView.getItemById(item.id);
	report.reptype = $("#_reptypefield").val();
	report.repname = $("#_repnamefield").val();
	report.description = $("#_descriptionfield").val();
	report.shared = ( $("#_sharedfield").is(":checked") ) ? "Yes" : "";
	report.sharedby =( $("#_sharedfield").is(":checked") ) ? "PrototypeUser" : "";
	report.datefilter =  $("#_datefilterfield").val();
	report.fromdate = $("#_datefrom").val();
	report.todate = $("#_dateto").val();
	report.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
	report.filters = filterDataView.getItems();	
	if (gridMode == "my") {
		if ( $("#_sharedfield").is(":checked") ) {
			var index = $.inArray(item, sharedData);
			if (index != -1) {
				var report = sharedData[index];
				report.reptype = $("#_reptypefield").val();
				report.repname = $("#_repnamefield").val();
				report.description = $("#_descriptionfield").val();
				report.shared = "y";
				report.sharedby ="PrototypeUser";
				report.datefilter =  $("#_datefilterfield").val();
				report.fromdate = $("#_datefrom").val();
				report.todate = $("#_dateto").val();
				report.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
				report.filters = filterDataView.getItems();	
			} else {
				sharedData.push(item)
			}
		} else {
			var index = $.inArray(item, sharedData);
			if(index != -1) {
				sharedData.splice(index, 1)
			}
		}
		dataView.setItems(data)
	} else {
		var index = $.inArray(item, data);
		var rep = data[index];
		rep.reptype = $("#_reptypefield").val();
		rep.repname = $("#_repnamefield").val();
		rep.description = $("#_descriptionfield").val();
		rep.shared = ( $("#_sharedfield").is(":checked") ) ? "&#x2713;" : "";
		rep.sharedby =( $("#_sharedfield").is(":checked") ) ? "PrototypeUser" : "";
		rep.datefilter =  $("#_datefilterfield").val();
		rep.fromdate = $("#_datefrom").val();
		rep.todate = $("#_dateto").val();
		rep.filtertype = $("#_filteroption").find("input[name='ftype']:checked").val();
		rep.filters = filterDataView.getItems();
		if ( rep.shared == "" ) {
			var index = $.inArray(item, sharedData);
			if(index != -1) {
				sharedData.splice(index, 1)
			}	
		}
		dataView.setItems(sharedData)
	}
	dataView.refresh();
	grid.invalidate();
	grid.render();
	setupReportDetails(item, "view")
}


/**********************************************************************
REPORTS GRID SETUP
**********************************************************************/
var dataView;
var grid;
var data = [];
var sharedData = [];
var selectedRowIds = [];
var columns = [
	{id:"repname", name:"Report Profiles", formatter:renderCell, field:"repname", cssClass:"contact-card-cell", type:"preview"}
];
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var options = {
	rowHeight: 70,	
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: true,
	multiSelect: true,
	showHeaderRow: false
};
var groupedSetting = 0, groupCollapseSetting = 0;
var compiled_template = tmpl("cell_template");
function renderCell(row, cell, value, columnDef, dataContext) {
	return compiled_template(dataContext);
};
function expandAllGroups() {
	dataView.expandAllGroups();
	$("#groupMenuControl").removeClass("on");
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
	$("#groupMenuControl").removeClass("on");
}
function clearGrouping() {
	$("#groupMenuControl").removeClass("on");
	dataView.groupBy(null);
	groupedSetting = 0;
}
function groupBy(item,text) {
	dataView.groupBy(
		item,
		function (g) {
			if (item == "sharedby" && g.value == "0") {
				return text+": Not Shared <span>(" + g.count + " items)</span>";
			} else {
				return text+":  " + g.value + "  <span>(" + g.count + " items)</span>";
			}
		},
		function (a, b) {
			return a.value - b.value;
		}
	);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
	$("#groupMenuControl").removeClass("on");
}
var repString = "", repDataPoint = "repname";
function myFilter(item, args) {
		
	if (args.repString != "" && item[repDataPoint].toLowerCase().indexOf(args.repString.toLowerCase()) == -1) {
		return false;
	}

	return true;
}


/**********************************************************************
REPORT PROFILES DATA
**********************************************************************/
for (var i=0; i<10; i++) {
	var d = (data[i] = {});
		d["id"] = Math.round(Math.random() * 1000000000);
		if (i < 5) {
			if (i % 2 == 0) {
				d["reptype"] = "Account Statement";
				d["repname"] = "Opperating Account Statements - "+Math.round(Math.random() * 100);
				d["description"] = "Statements For Manufacturing Inc. Operating Accounts " +Math.round(Math.random() * 100)+" to "+Math.round(Math.random() * 100);
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Today";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{id: "id_0", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_1", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_2", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()}];
			} else {
				d["reptype"] = "Account Balance Summary";
				d["repname"] = "Operating Account Balance Summary - "+Math.round(Math.random() * 100);
				d["description"] = "Balance Summary Report for Manufacturing Inc. Accounts "+Math.round(Math.random() * 100)+" to "+Math.round(Math.random() * 100);
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Specific Date";
				d["fromdate"] = "06/05/2013";
				d["todate"] = "";
				d["filtertype"] = "Currency";
				d["filters"] = [{id: "id_0",ccy: "AUD",ccyname: "Australian Dollars"},{id: "id_1",ccy: "CNY",ccyname: "Chinese Yuan"},{id: "id_2",ccy: "EUR",ccyname: "Euro"}];
			}
		} else {
			if (i % 2 == 0) {
				d["reptype"] = "Account Statement";
				d["repname"] = "Account Statement Report "+Math.round(Math.random() * 100);
				d["description"] = "Consulting Pte. Ltd. Account Statements";
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Yesterday";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{id: "id_0", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_1", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_2", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_3", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_4", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_5", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()}];
			} else {
				d["reptype"] = "Account Balance Summary";
				d["repname"] = "Balance Summary Report "+Math.round(Math.random() * 100);;
				d["description"] = "Consulting Pte. Ltd. Balance Summary Reports";
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Date Range";
				d["fromdate"] = "06/05/2013";
				d["todate"] = "10/05/2013";
				d["filtertype"] = "Currency";
				d["filters"] = [{id: "id_0",ccy: "AUD",ccyname: "Australian Dollars"},{id: "id_1",ccy: "EUR",ccyname: "Euro"}];
			}
		};
}
for (var i=0; i<10; i++) {
	var d = (sharedData[i] = {});
		d["id"] = Math.round(Math.random() * 1000000000);	
		if (i < 5) {
			if (i % 2 == 0) {
				d["reptype"] = "Account Statement";
				d["repname"] = "Opp Statements - "+Math.round(Math.random() * 100);
				d["description"] = "Statement For Various Operating Accounts " +Math.round(Math.random() * 100)+" to "+Math.round(Math.random() * 100);
				d["shared"] = "y";
				d["sharedby"] = "User123";
				d["ownedby"] = "User123";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Date Range";
				d["fromdate"] = "06/05/2013";
				d["todate"] = "10/05/2013";
				d["filtertype"] = "Currency";
				d["filters"] = [{id: "id_0",ccy: "AUD",ccyname: "Australian Dollars"},{id: "id_1",ccy: "EUR",ccyname: "Euro"}];
			} else {
				d["reptype"] = "Balance Summary";
				d["repname"] = "Operating Account Balance Summary - "+Math.round(Math.random() * 100);
				d["description"] = "Balance Summary Report for Manufacturing Inc. Accounts "+Math.round(Math.random() * 100)+" to "+Math.round(Math.random() * 100);
				d["shared"] = "y";
				d["sharedby"] = "userXYZ";
				d["ownedby"] = "userXYZ";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Yesterday";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{id: "id_0", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_1", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_2", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_3", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_4", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_5", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()}];

			}
		} else {
			if (i % 2 == 0) {
				d["reptype"] = "Account Statement";
				d["repname"] = "Account Statement Report "+Math.round(Math.random() * 100);
				d["description"] = "Consulting Pte. Ltd. Account Statements";
				d["shared"] = "y";
				d["sharedby"] = "userXYZ";
				d["ownedby"] = "userXYZ";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Yesterday";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{id: "id_0", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_1", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_2", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_3", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_4", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_5", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()}];

			} else {
				d["reptype"] = "Balance Summary";
				d["repname"] = "Balance Summaries "+Math.round(Math.random() * 100);;
				d["description"] = "Various Balance Summary Report";
				d["shared"] = "y";
				d["sharedby"] = "UserABC";
				d["ownedby"] = "UserABC";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Week To Date";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{id: "id_0", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_1", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()},{id: "id_2", accountnam: "CURRENT"+Math.round(Math.random() * 1000), accountnum: Math.round(Math.random() * 1000000000).toString()}];

			}
		};
}


/**********************************************************************
FIND CURRENCIES GRID
**********************************************************************/
var findCCYDataView;
var findCCYGrid;
var findCCYData = [{id: "id_0",ccy: "AUD",ccyname: "Australian Dollars"},{id: "id_1",ccy: "CNY",ccyname: "Chinese Yuan"},{id: "id_2",ccy: "EUR",ccyname: "Euro"},{id: "id_3",ccy: "HKD",ccyname: "Hong Kong Dollars"},{id: "id_4",ccy: "IDR",ccyname: "Indonesian Rupiah"},{id: "id_5",ccy: "INR",ccyname: "Indian Rupee"},{id: "id_6",ccy: "KRW",ccyname: "Korean Won"},{id: "id_7",ccy: "KHR",ccyname: "Cambodian Riel"},{id: "id_8",ccy: "MYR",ccyname: "Malaysian Ringgit"},{id: "id_9",ccy: "NZD",ccyname: "New Zealand Dollar"},{id: "id_10",ccy: "SGD",ccyname: "Singapore Dollar"},{id: "id_11",ccy: "THB",ccyname: "Thailand Baht"},{id: "id_12",ccy: "USD",ccyname: "United States Dollar"},{id: "id_13",ccy: "VND",ccyname: "Vietnamese Dong"}];
var findCCYSelectedRowIds = [];
var findCCYColumns = [
	{ id:"ccy", name:"Currency Code", field:"ccy",  toolTip:"Click to sort by Currency Code", width: 150, sortable: true, cssClass: "no-pointer" },
	{ id:"ccyname", name:"Currency Description", field:"ccyname", toolTip:"Click to sort by Currency Description", width: 350, sortable: true, cssClass: "no-pointer" }
],
findCCYOptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	autoHeight: false,
	forceFitColumns: true,
	multiSelect: true
};
var findCCYCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
findCCYColumns.unshift(findCCYCheckboxSelector.getColumnDefinition());
var findCCYString = "", findCCYDataPoint = "ccy";
function ccyFilter(item, args) {	
	if (args.findCCYString != "" && item[findCCYDataPoint].toLowerCase().indexOf(args.findCCYString.toLowerCase()) == -1)
		return false;
	return true;
}


/**********************************************************************
FIND ACCOUNTS GRID
**********************************************************************/
var findDataView;
var findGrid;
var findData = [];
var findSelectedRowIds = [];
var findColumns = [
	{ id:"accountnam", name:"Account Name", field:"accountnam",  toolTip:"Click to sort by Account Name", width: 250, sortable: true, cssClass: "no-pointer" },
	{ id:"accountnum", name:"Account Number", field:"accountnum", toolTip:"Click to sort by Account Number", width: 250, sortable: true, cssClass: "no-pointer" }
],
findOptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	autoHeight: false,
	forceFitColumns: true,
	multiSelect: true
};
var findCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
findColumns.unshift(findCheckboxSelector.getColumnDefinition());
var findString = "", findDataPoint = "accountnam";
function accFilter(item, args) {
		
	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1)
		return false;

	return true;
}
for (var i=0; i<30; i++) {
	var d = (findData[i] = {});
	d["id"] = "id_" + i;
	d["accountnam"] = "CURRENT"+Math.round(Math.random() * 1000);
	d["accountnum"] = Math.round(Math.random() * 1000000000).toString();
}

/**********************************************************************
FILTER ITEMS GRID
**********************************************************************/
var filterDataView,
filterGrid,
filterData = [],
filterAccountData = []
filterCurrencyData = []
filterColumns = [],
filterSelectedRowIds = [],
filterOptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	autoHeight: false,
	forceFitColumns: true,
	multiSelect: true
};


/**********************************************************************
SETUP CONTEXT MENU
**********************************************************************/
function checkStatus(arr) {
	var L = arr.length-1;
	while(L) {
		if(arr[L--]!==arr[L]) return false;
	}
	return arr[L];
}
var enableContextItem = function() {
	var text = $(this).children("div.disabled").text();
	if ( $(this).attr("data-action") == "run" ) {
		$(this).children("div.disabled").replaceWith( "<a href='#runFormat' data-value='#runFormat'>" + text + "<i class='fa fa-angle-right fa-fw'></i></a>" );
	} else {
		$(this).children("div.disabled").replaceWith( "<a href='javascript:void(0)'>" + text + "</a>" );
	}
};
var disableContextItem = function() {
	var text = $(this).children("a").text();
	if ( $(this).attr("data-action") == "run" ) {
		$(this).children("a").replaceWith( "<div class='disabled'>" + text + "<i class='fa fa-angle-right fa-fw'></i></div>" );
	} else {
		$(this).children("a").replaceWith( "<div class='disabled'>" + text + "</div>" );
	}
};
var selectedReportOwners = [];
function setupContextMenu() {
	var sel = selectedReportOwners.length, $contextItems = $("[data-type='context-item']");
	var sameOwner;
	if (sel == 0) {
		$contextItems.each(disableContextItem);
	} else if (sel == 1) {
		sameOwner = checkStatus(selectedReportOwners);
		if (sameOwner == "PrototypeUser") {
			$contextItems.each(enableContextItem);
		} else {
			$("[data-action='run'], [data-action='view']").each(enableContextItem);
			$("[data-action='edit'], [data-action='delete']").each(disableContextItem);
		}
	} else if (sel > 1) {
		sameOwner = checkStatus(selectedReportOwners);
		$("[data-action='delete']").each(enableContextItem);
		$("[data-action='run'], [data-action='edit'], [data-action='view']").each(disableContextItem);
		if (!sameOwner || sameOwner != "PrototypeUser") {
			$("[data-action='delete']").each(disableContextItem);
		}
	}
	
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALISE REPORTS GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#adhocReports", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var sortcolumns = [
		{id:"repname", name:"Report Name", field:"repname", toolTip:"Click to sort by Report Name", width: 160, sortable:true, visible: true},
		{id:"reptype", name:"Report Type", field:"reptype", toolTip:"Click to sort by Report Type", width: 160, sortable: true, visible: true}
	];
	new Slick.Controls.SlickPreviewSortPicker(sortcolumns, grid, options);
	var $reportProfileGrid = $(grid.getCanvasNode()),
	$scrollArea = $("#adhocReports").parent("div.scroll-area"),
	$bottomControls = $("#reportSummary .bottom-controls"),
	$selected = $("#selectedCount");
	grid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();	
		var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setActiveCell(row, 1);
		}
		setupContextMenu();
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {		
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		clearTimeout(loadRecordTimer);
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedReportOwners = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedReportOwners.push(item.ownedby)
			}
		}
		if ( !rows.length ) {
			grid.resetActiveCell();
			$(".right-panel").removeClass("loading");
			$(".selection-panel").show().find("div[data-value='multiple-selection']").hide();
			$(".selection-panel").find("div[data-value='no-selection']").show();
			$scrollArea.removeClass("has-bottom-controls");
			$bottomControls.addClass("hidden");
			$selected.html('');
			grid.resizeCanvas();
		} else if ( rows.length === 1 ) {
			if ( !grid.getActiveCell() || grid.getActiveCell().row != rows[0] ) {
				 grid.setActiveCell( rows[0], 1);
			}
			if ( $scrollArea.hasClass("has-bottom-controls") ) {
				$scrollArea.removeClass("has-bottom-controls");
				$bottomControls.addClass("hidden");
				$selected.html('');
				grid.resizeCanvas();
			}
			$(".right-panel").addClass("loading").find(".scroll-area").scrollTop("0");
			loadRecordTimer = setTimeout( function() {
				$(".right-panel").removeClass("loading");
				setupReportDetails( dataView.getItem(rows[0]), "view");
				$(".selection-panel").hide();
			}, 500);
		} else if ( rows.length > 1 ) {
			$(".right-panel").removeClass("loading");
			$(".selection-panel").show().find("div[data-value='no-selection']").hide()
			$(".selection-panel").find("div[data-value='multiple-selection']").show();
			if ( !$scrollArea.hasClass("has-bottom-controls") ) {
				$scrollArea.addClass("has-bottom-controls");
				$bottomControls.removeClass("hidden");
				grid.resizeCanvas();
			}
			$selected.html(selectedRowIds.length);
		}
	});
	grid.onClick.subscribe(function(e, args) {
		var row = args.row;
		if ( grid.getActiveCell() && grid.getActiveCell().row == args.row ) {
			grid.resetActiveCell();
		}
		grid.setSelectedRows([row]);
		grid.setActiveCell(row, 1);
	});
	grid.onActiveCellChanged.subscribe(function(e, args) {
		var item = grid.getActiveCell(), $row = $(grid.getActiveCellNode()).closest(".slick-row");
		if ( $row.is(".slick-group, .slick-group-totals") ) {
			return false;
		} else {
			if ( item ) {
				if ( grid.getActiveCell().row != grid.getSelectedRows([0]) || !grid.getSelectedRows().length ) {
					 grid.setSelectedRows([item.row]);
				}
			}
		}
	});
	grid.onSort.subscribe(function(e, args) {
		sortcol = args.sortCol.field;
		sortdir = args.sortAsc ? 1 : -1;
		dataView.fastSort(sortcol, args.sortAsc);
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		repString: repString
	});
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	dataView.fastSort("repname",true);
		

	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
		if ( typeof(filterGrid) != 'undefined' && filterGrid != null ) {
			filterGrid.resizeCanvas();
		}
	});
		
		
	/**********************************************************************
	REPORT INTERACTIONS
	**********************************************************************/
	$("[data-action='view']").on("click", "a", function(e) {
		var item = dataView.getItem(grid.getSelectedRows());
		$(".right-panel .selections").hide();
		setupReportDetails(item, "view")
	});
	$("[data-action='edit']").on("click", "a", function(e) {
		var item = dataView.getItem(grid.getSelectedRows());
		$(".right-panel .selections").hide();
		setupReportDetails(item, "edit")
	});
	$("[data-action='delete']").on("click.delete-sel", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ( $target.prop("nodeName") == "A" || $target.prop("nodeName") == "I" ) {
			$("#contextMenu").hide();
			function deleteProfiles() {
				var rowsForDelete = [];
				for (var i = 0, l = selectedRowIds.length; i < l; i++) { var item = selectedRowIds[i]; if (item) rowsForDelete.unshift(item) };
				for (var i=0;i<rowsForDelete.length;i++) {dataView.deleteItem(rowsForDelete[i])};
				if (gridMode == "my") {
					for (var i=0;i<rowsForDelete.length;i++) {
						for (var d=0; d < sharedData.length; d++) {
							if (rowsForDelete[i] == sharedData[d].id) {
								sharedData.splice(d,1)
							}
						}
					}
				} else {
					for (var i=0;i<rowsForDelete.length;i++) {
						for (var d=0; d < data.length; d++) {
							if (rowsForDelete[i] == data[d].id) {
								data.splice(d,1)
							}
						}
					}
				}
				grid.setSelectedRows(0);
				selectedRowIds = [];
				dataView.refresh();
				grid.invalidate();
				grid.render();
				if(groupCollapseSetting == 1) {collapseAllGroups()};
				groupedSetting = 1;
				buildNotification("Report profiles have been deleted.", 300, 3000);
			}
			buildConfirmDialog( "Delete selected report profiles?", "", function(){deleteProfiles(e)});
		}
	});
	$("#_newReportButton").on("click", function(e) {
		$("#actionMenuControl").removeClass("on");
		grid.setSelectedRows({});
		grid.resetActiveCell();
		$(".right-panel").addClass("loading").find(".scroll-area").scrollTop("0");
		loadRecordTimer = setTimeout( function() {
			$(".right-panel").removeClass("loading");
			setupReportDetails('', "new");
			$(".selection-panel").hide();
		}, 500);
	});
	$("#_updateReport").on("click", "a", function(e) {
		var item = dataView.getItem(grid.getActiveCell().row);	
		updateReport(item);
		buildNotification(item.repname+" report profile has been updated", 300, 3000);
	});
	$("#_saveNewReport").on("click", "a", function(e) {
		saveNewReport();
		var repName = $("#_repnamefield").val(), repType = $("#_reptypefield").val();
		buildNotification(repName+" report profile has been created.", 300, 3000);
	});
	$("#_discardButton").on("click", "a", function(e) {
		e.preventDefault();
		grid.setSelectedRows({});
		grid.resetActiveCell();
	});
	$("#_closeButton").on("click", "a", function(e) {
		e.preventDefault();
		grid.setSelectedRows({});
		grid.resetActiveCell();
	});
	$("#_editButton").on("click", function(e) {
		var item = dataView.getItem(grid.getActiveCell().row);
		setupReportDetails(item, "edit")
	});
	$("#_cancelButton").on("click", "a", function(e) {
		var item = dataView.getItem(grid.getSelectedRows());
		setupReportDetails(item, "view")
	});
	$("#_deleteButton").on("click", "a", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		function deleteProfile() {
			var item = dataView.getItem(grid.getActiveCell().row);
			dataView.deleteItem(item.id)
			if (gridMode == "my") {
				for (var d=0; d < sharedData.length; d++) {
					if (item.id == sharedData[d].id) {
						sharedData.splice(d,1)
					}
				}
			} else {
				for (var d=0; d < data.length; d++) {
					if (item.id == data[d].id) {
						data.splice(d,1)
					}
				}
			}
			grid.setSelectedRows(0);
			selectedRowIds = [];
			dataView.refresh();
			grid.invalidate();
			grid.render();
			if(groupCollapseSetting == 1) {collapseAllGroups()};
			groupedSetting = 1;
			buildNotification("Report profile has been deleted.", 300, 3000);
		}
		buildConfirmDialog( "Delete this report profile?", "", function(){deleteProfile(e)});
	});
	$("[data-action='previousReport']").on("click", function(e) {
		e.preventDefault();
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow-1;
		if ( $reportProfileGrid.find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
			activeRow = activeRow-1;
		}	
		$reportProfileGrid.find("div[row='"+activeRow+"'] div.slick-cell").eq(1).trigger("click")
	});
	$("[data-action='nextReport']").on("click", function(e) {
		e.preventDefault();
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow+1;
		if ( $reportProfileGrid.find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
			activeRow = activeRow+1;
		}
		$reportProfileGrid.find("div[row='"+activeRow+"'] div.slick-cell").eq(1).trigger("click")
	});
	$("[data-action='closeDetailView']").on("click", function(e){
		e.preventDefault();
		grid.setSelectedRows({});
		grid.resetActiveCell();
	});

	/**********************************************************************
	DATE RANGE FUNCTIONS
	**********************************************************************/
	function getFilterDate(selection) {
		if (selection == "Today") {
			printdate = $.datepicker.formatDate('dd/mm/yy', new Date())
		} else if (selection == "Yesterday") {
			var yesterday = new Date();
			yesterday.setDate(yesterday.getDate() - 1)
			printdate = $.datepicker.formatDate('dd/mm/yy', yesterday)
		} else if (selection == "Week To Date") {
			var fromDate = new Date(), toDate = new Date();
			var startDate = fromDate.getDate() - fromDate.getDay() + ( fromDate.getDay() == 0 ? -6:1)
			fromDate.setDate(startDate)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate)+" - "+$.datepicker.formatDate('dd/mm/yy', toDate)
		} else if (selection == "Previous Week") {
			var fromDate = new Date(), toDate = new Date();
			var startDate = (fromDate.getDate() - 7) - fromDate.getDay() + ( fromDate.getDay() == 0 ? -6:1 )
			fromDate.setDate(startDate)
			var endDate = fromDate.getDate() + 4;
			toDate.setDate(endDate)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate)+" - "+$.datepicker.formatDate('dd/mm/yy', toDate)
		} else if (selection == "Month To Date") {
			var fromDate = new Date(), toDate = new Date();
			fromDate.setDate(1)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate)+" - "+$.datepicker.formatDate('dd/mm/yy', toDate)
		} else if (selection == "Previous Month") {
			var fromDate = new Date(), toDate = new Date();
			fromDate.setMonth( fromDate.getMonth() - 1)
			fromDate.setDate(1)
			toDate.setMonth ( fromDate.getMonth() + 1 ) 
			toDate.setDate(0)
			printdate = $.datepicker.formatDate('dd/mm/yy', fromDate)+" - "+$.datepicker.formatDate('dd/mm/yy', toDate)
		}
		return printdate
	}
	var newRepDates = $("#_newStartDate, #_newEndDate").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_newStartDate" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings );
			newRepDates.not( this ).datepicker( "option", option, date );
		}
	});
	var editRepDates = $("#_editStartDate, #_editEndDate").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_editStartDate" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(
					instance.settings.dateFormat ||
					$.datepicker._defaults.dateFormat,
					selectedDate, instance.settings );
			newRepDates.not( this ).datepicker( "option", option, date );
		}
	});
	$("#_datefilterfield").on("change", function(e) {
		var printDate = $(this).val(), $printDiv = $("#_printdate");
		if (printDate == "Specific Date") {
			$printDiv.html('').hide();
			$("#_datefrom, #_dateto").attr({"disabled":"disabled"}).datepicker("destroy").val('').hide();
			$("#_datefrom").show().removeAttr("disabled").attr("placeholder","Date").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,maxDate: 0}).focus().blur();
		} else if (printDate == "Date Range") {
			$printDiv.html('').hide();
			$("#_datefrom").attr({"disabled":"disabled"}).datepicker("destroy").val('').hide();
			$("#_datefrom").attr("placeholder","From");
			$("#_dateto").attr("placeholder","To");
			$("#_datefrom, #_dateto").removeAttr("disabled").show()
			var dates = $("#_datefrom, #_dateto").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				maxDate: 0,
				onSelect: function( selectedDate ) {
					var option = this.id == "_datefrom" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					dates.not( this ).datepicker( "option", option, date );
				}
			});
			$("#_datefrom").focus().blur();
		} else {
			$("#_datefrom, #_dateto").hide().attr({"disabled":"disabled"}).datepicker("destroy").val('');
		} 
	});


	/**********************************************************************
	CONTROL MENU FUNCTIONS
	**********************************************************************/
	$("[data-action='my-reports']").on("click", function(e) {
		e.preventDefault(); 
		gridMode = "my";
		$("#repSearchClear").trigger('click')
		dataView.setItems(data);
		dataView.refresh();
		grid.invalidate();
		grid.render();
	});
	$("[data-action='shared-reports']").on("click", function(e) {
		e.preventDefault();
		gridMode = "shared";
		$("#repSearchClear").trigger('click')
		dataView.setItems(sharedData);
		dataView.refresh();
		grid.invalidate();
		grid.render();
	});
	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}		
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout( function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

		
	/**********************************************************************
	FIND REPORTS INTERACTION
	**********************************************************************/
	function repFilter() {
		var rows = grid.getSelectedRows();
		if(rows.length > 0) {grid.setSelectedRows(0)};
		if(repString == "") {dataView.setFilterArgs({repString: repString})} else {dataView.setFilterArgs({repString: repString})};
		dataView.refresh();
	}

	$("#repSearchClear").on("click", function() {
		$("#_findReports").val('');
		$("#_findReports").blur();
		$("#repSearchClear").hide();
		repString = "";
		repFilter();
	});

	$("#_findReports").keyup(function (e) {
		if (e.which == 27) {$("#repSearchClear").hide();this.value = '';this.blur()};
    	repString = this.value; repFilter();
    	if ( this.value != "" ) {$("#repSearchClear").show()} else {$("#repSearchClear").hide()}
  	});

	$("#findReportOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var repPlaceholder = $(this).text(), repString = $(this).attr("data-find");
		if (repDataPoint != repString) {
			$("#_findReports").attr("placeholder", repPlaceholder);
			repDataPoint = repString;
			$("#_findReports").val('').focus();
			$("#repSearchClear").hide();
			repString = '';
			repFilter();
		}
	});

	$("#toggleFilter").on("click", function(e) {
		e.preventDefault();
		if ( $(".search-menu").is(":visible") ) {
			$(this).removeClass("btn-on");
			$(".search-menu").hide();
			$("#adhocReports").css({"top": 0});
			grid.resizeCanvas();
		} else {
			$(this).addClass("btn-on");
			$(".search-menu").show().find("input.search-input").focus();
			$("#adhocReports").css({"top": 50});
			grid.resizeCanvas();
		}
	});



	
	$(".search-options").on("click", function(e) {
		e.preventDefault(); e.stopPropagation();
		function hideMenu() {
			$("#findReportOptions").hide();
			$(document).off("keyup.hide-search");
			$(window).off("resize.hide-search");
			$("body").off("click.hide-search");
		}
		if ( $("#findReportOptions").is(":visible") ) {
			hideMenu();
		} else {
			$(".control-menus .control-menu").hide();
			$("#findReportOptions").show().css({"top":"218px"});
			$(window).on("resize.hide-search", function() {
				hideMenu()
			});
			$(document).on("keyup.hide-search", function(e) {
				e.preventDefault();
				if(e.keyCode == 27) {
					hideMenu()
				}
			});
			$("body").on("click.hide-search", function() {
				hideMenu()
			});
		}
	});



		
	/**********************************************************************
	FIND ACCOUNTS INTERACTION
	**********************************************************************/
	function findFilter() {
			var rows = findGrid.getSelectedRows();
			if(rows.length > 0) {findGrid.setSelectedRows(0)};
			if(findString == "") {findDataView.setFilterArgs({findString: findString})} else {findDataView.setFilterArgs({findString: findString})};
			findDataView.refresh();
		}
	$("#_findAccountsClear").on("click", function() {
			$("#_findAccountsInput").val(''); $("#_findAccountsInput").blur(); $("#_findAccountsClear").hide(); findString = "";findFilter();
		});
	$("#_findAccountsInput").keyup(function (e) {
			if (e.which == 27) {$("#_findAccountsClear").hide();this.value = '';this.blur()};
	    	findString = this.value; findFilter();
	    	if ( this.value != "" ) {$("#_findAccountsClear").show()} else {$("#_findAccountsClear").hide()}
	  });
	$("#findAccountOptions").on("click.set-find", "a", function(e) {
			e.preventDefault();
			var findPlaceholder = $(this).text(), findString = $(this).attr("data-find");
			if (findPlaceholder != findString) {
				$("#_findAccountsInput").attr("placeholder", findPlaceholder);
				findDataPoint = findString;
				$("#_findAccountsInput").val('').focus();
				$("#_findAccountsClear").hide();
				findString = '';
				findFilter();
			}
		});


	/**********************************************************************
	FIND CURRENCIES INTERACTION
	**********************************************************************/
	function findCCYFilter() {
			var rows = findCCYGrid.getSelectedRows();
			if(rows.length > 0) {findCCYGrid.setSelectedRows(0)};
			if(findCCYString == "") {findCCYDataView.setFilterArgs({findCCYString: findCCYString})} else {findCCYDataView.setFilterArgs({findCCYString: findCCYString})};
			findCCYDataView.refresh();
		}
	$("#_findCurrencyClear").on("click", function() {
			$("#_findCurrencyInput").val(''); $("#_findCurrencyInput").blur(); $("#_findCurrencyClear").hide(); findCCYString = "";findCCYFilter();
		});
	$("#_findCurrencyInput").keyup(function (e) {
			if (e.which == 27) {$("#_findCurrencyClear").hide();this.value = '';this.blur()};
	    	findCCYString = this.value; findCCYFilter();
	    	if ( this.value != "" ) {$("#_findCurrencyClear").show()} else {$("#_findCurrencyClear").hide()}
	  });
	$("#findCurrencyOptions").on("click.set-find", "a", function(e) {
			e.preventDefault();
			var findCCYPlaceholder = $(this).text(), findCCYString = $(this).attr("data-find");
			if (findCCYPlaceholder != findCCYString) {
				$("#_findCurrencyInput").attr("placeholder", findCCYPlaceholder);
				findCCYDataPoint = findCCYString;
				$("#_findCurrencyInput").val('').focus();
				$("#_findCurrencyClear").hide();
				findCCYString = '';
				findCCYFilter();
			}
		});
		
		
	/**********************************************************************
	SPLIT VIEW

	var $shell = $(".shell"), $leftPanel = $(".left-panel"), $rightPanel = $(".right-panel"), $resizer = $(".resizer");
	$(".resizer").drag("start", function(ev,dd) {
		$("body").trigger("click.hide-menu");
		$resizer.addClass("on");
		dd.limit = $shell.offset();
		dd.limit.left = 400;
		dd.limit.right = $shell.width() - ( 500 );
	}).drag( function(ev,dd) {
		$rightPanel.css({ left: Math.min(dd.limit.right, Math.max(dd.limit.left, dd.offsetX - $shell.position().left )) });
		$leftPanel.css({ width: $rightPanel.position().left });
		grid.resizeCanvas();
		if ( typeof(filterGrid) != 'undefined' && filterGrid != null ) {
			filterGrid.resizeCanvas();
		}
	}, {handle: ".resizer"}).drag("end", function(ev,dd) {
		$resizer.removeClass("on");
		grid.resizeCanvas();
		if ( typeof(filterGrid) != 'undefined' && filterGrid != null ) {
			filterGrid.resizeCanvas();
		}
	});	
	**********************************************************************/

});