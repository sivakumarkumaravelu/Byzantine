/**********************************************************************
						    DOWNLOADS GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [
	{id:"reportdatetime", name:"Report Date and Time", field:"reportdatetime", width: 200, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"reporttype", name:"Report Type", field:"reporttype", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"reportname", name:"Report Name", field:"reportname", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"reportformat", name:"Report Format", field:"reportformat", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"reportstatus", name:"Report Status", field:"reportstatus", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},	
	{id:"filesize", name:"File Size (kb)", field:"filesize", width: 160, sortable:true, sorter: "sorterNumeric", visible: true},
	{id:"runtype", name:"Run Type", field:"runtype", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"reportdescription", name:"Description", field:"reportdescription", width: 300, sortable:true, sorter: "sorterStringCompare", visible: true}
];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if ( store.get('downloadOrder') ) {
	columns = store.get('downloadOrder');
}
if ( store.get('downloadWidths') ) {
	var setWidth = store.get('downloadWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());


var groupedSetting = 0, groupCollapseSetting = 0;
function collapseAllGroups() {
	dataView.beginUpdate();
	for (var i = 0; i < dataView.getGroups().length; i++) {
		if(!dataView.getGroups()[i].collapsed)
			dataView.collapseGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
	dataView.endUpdate();
}
function expandAllGroups() {
	for (var i = 0; i < dataView.getGroups().length; i++) {
		dataView.expandGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
}
function clearGrouping() {
	dataView.groupBy(null);
	groupedSetting = 0;
}
function groupBy(item,text) {
	dataView.groupBy(
		item,
		function (g) {
			return text+":  " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		function (a, b) {
			return a.value - b.value;
		}
	);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var findString = "", findDataPoint = "reportname";
function myFilter(item, args) {
		
	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterAccounts() {
	dataView.refresh();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}

for (var i=0; i<35; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	if(i < 20){d["reporttype"] = "Account Statement"}else{d["reporttype"] = "Balance Summary"};
	if(i < 20){d["reportname"] = "accnt-statements-"+Math.round(Math.random() * 100000)}else{d["reportname"] = "balsum-"+Math.round(Math.random() * 100000)};
	if(i < 20){d["reportformat"] = "PDF"}else{d["reportformat"] = "CSV"};
	d["filesize"] = (Math.round(Math.random() * 10000)/100);
	d["reportstatus"] = "Ready For Download";
	d["reportdatetime"] = $.datepicker.formatDate('dd/mm/yy', new Date()) + " " + timeFormatter();
	if(i % 3 == 0){d["runtype"] = "User Requested Report"}else{d["runtype"] = "Scheduled"};
	d["reportdescription"]="Lorem ipsum dolor sit";
}


$(function() {

	/**********************************************************************
						INITIALIZE DOWNLOADS GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#downloadGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:true}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);	
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'downloadOrder', 'downloadWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();	
		var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			if (rows.length > 1) {
				$cmenu = $("#contextMenu")
			} else {
				$cmenu = $("#contextMenu")
			}
		};
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {		
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});	  
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if(selectedRowIds.length > 0) {
			$("#download .bottom-controls").removeClass("hidden");
			$("#download .gutter-30").addClass("has-bottom-controls");
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#download .bottom-controls").addClass("hidden");
			$("#download .gutter-30").removeClass("has-bottom-controls");
			$("#selectedCount").html('');
		}
		grid.resizeCanvas();
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('downloadWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		findString: findString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if ( store.get('downloadOrder') ) {
		var visibleDownloadColumns = [];
		for (var i = 0; i < store.get('downloadOrder').length+1; i++) {
			if (columns[i].visible) {
				visibleDownloadColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleDownloadColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
							GRID RESIZE EVENT
	**********************************************************************/	
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
		
		
	/**********************************************************************
					      DELETE SELECTED FILES
	**********************************************************************/
	function deleteReports() {
		var rowsForDelete = [];
		for (var i = 0, l = selectedRowIds.length; i < l; i++) { var item = selectedRowIds[i]; if (item) rowsForDelete.unshift(item) };
		for (var i=0;i<rowsForDelete.length;i++) {dataView.deleteItem(rowsForDelete[i])};
		grid.setSelectedRows(0);
		selectedRowIds = [];
		dataView.refresh();
		grid.invalidate();
		grid.render();
		if(groupCollapseSetting == 1) {collapseAllGroups()};
		groupedSetting = 1;
	}
	$("body").on("click.delete-sel", "[data-action='delete-selected']", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ( $target.prop("nodeName") == "A" || $target.prop("nodeName") == "I" ) {
			$("#contextMenu").hide();
			if ( selectedRowIds.length > 0 ) {
				buildConfirmDialog( "Deleted selected files?", "", function(){deleteReports()});
			}
		}
	});


	/**********************************************************************
							GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}		
	});


	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);
		
	/**********************************************************************
			                    DATE FILTERS
	**********************************************************************/
	$("#dateMenu").on("click", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ( $target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set") ) {
			$(this).attr({"data-panel": "#download", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		}
	});
	$("#_specDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#dateMenu").find("li.active").removeClass("active");
			$("#specDateItem").closest("li").addClass("active");
			$("div.control-list").find("a[href='#dateMenu']").children("span.item-text").text(dateText);
			$("div.control-list").find("a[href='#dateMenu']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({"data-panel": "#download", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		}
	}).click(function(e) {e.stopPropagation();});
	var dateRangeSelection = $("#_rangeDateFrom, #_rangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_rangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				dateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {e.stopPropagation();});	
	$("#_dateRangeBtn").on("click", function(e) {
		var fromDate = $('#_rangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_rangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#dateMenu").find("li.active").removeClass("active");
		$("#rangeDateItem").closest("li").addClass("active");
		$("div.control-list").find("a[href='#dateMenu']").children("span.item-text").text(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#dateMenu']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
		$(this).attr({"data-panel": "#download", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
	});

});