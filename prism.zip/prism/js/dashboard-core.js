/********** WORKSPACES **********/

/* workspaces array  */
var workspaces = [{
	name: "Workspace",
	id: "wkspa",
	content: []
},{
	name: "Analytics",
	id: "wkspa2",
	content: []
}];

/* workspace states */
var workspaces_updated = false,
	workspaces_deleted = false,
	workspace_deleting = false,
	current_workspace,
	workspace_loaded = false;

/* grab the current workspace if it exists */
if (store.get('current_workspace')) {
	current_workspace = store.get('current_workspace');
}

/* grab from local storage if available */
if (store.get('saved_workspaces')) {
	workspaces = store.get('saved_workspaces');
};

/* populate workspaces into ui */
function populateWorkspaces() {
	var wkspCount = workspaces.length,
		$li, $a, $wkspLists = $("[data-map='workspaces']");
	$wkspLists.children().remove();
	if (wkspCount > 0) {
		if ($(".gridster").size() > 0) {
			if (!current_workspace) {
				changeWorkspace(workspaces[0].id);
			} else {			
				changeWorkspace(store.get('current_workspace'));
			}
		}
		$.each(workspaces, function() {
			$li = $("<li />").appendTo($wkspLists);
			if ($(".gridster").size() > 0) {
				$a = $("<a href='#" + this.name + "' id='" + this.id + "' title='" + this.name + "'>" + this.name + "</a>").on("click", function(e) {
					e.preventDefault();
					changeWorkspace(this.id)
				}).appendTo($li);
			} else {
				$a = $("<a href='#" + this.name + "' id='" + this.id + "' title='" + this.name + "'>" + this.name + "</a>").on("click", function(e) {
					e.preventDefault();
					current_workspace = this.id;
					store.set('current_workspace', current_workspace);
					document.location.href = 'index.html';
				}).appendTo($li);
			}
			if (this.id == current_workspace) {
				if ($(".gridster").size() > 0) {
					$li.addClass("on");
				}
			}
		});
	}
	showWorkspaceList();
}

/* populate the workspace manager */
function populateWorkspaceManager() {
	workspaces_updated = false;
	workspaces_deleted = false;
	var $wkspSettings = $("<div class='workspace-settings'></div>"),
		$wkspAddLine = $("<p>Create a new workspace.</p>").appendTo($wkspSettings),
		$wkspAddDiv = $("<div class='add-new-workspace' />").appendTo($wkspSettings),
		$wkspAddInput = $("<input type='text' placeholder='Enter name for your new workspace' value='' maxlength='25' id='_addWorkspaceInput'>").on("keyup", function(e) {
			if (e.keyCode == 13) {
				addWorkspace()
			}
		}).appendTo($wkspAddDiv),
		$wkspAddButton = $("<a href='javascript:void(0)' id='_addWorkspaceButton'><i class='fa fa-plus fa-fw'></i> Add</a>").on("click", addWorkspace).appendTo($wkspAddDiv),
		$wkspInstructions = $("<p>Reorder, rename, or remove your workspaces.</p>").appendTo($wkspSettings),
		$wkspList = $("<ul class='workspaces' />").appendTo($wkspSettings).sortable({
			handle: '.reorder-workspace',
			axis: 'y',
			tolerance: "pointer",
			update: function(event, ui) {
				workspaces_updated = true
			}
		}),
		wkspCount = workspaces.length,
		$li, $div, $span, $input, $a;
	if (wkspCount > 0) {
		$.each(workspaces, function() {
			$li = $("<li data-workspace='" + this.name + "' data-workspace-id='" + this.id + "' />").appendTo($wkspList);
			$div = $("<div class='wksp' />").appendTo($li);
			$span = $("<span class='reorder-workspace'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='" + this.name + "' data-workspace-name='" + this.name + "' />").on("change", function() {
				renameWorkspace($(this));
			}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-workspace'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteWorkspace).appendTo($div);
		});
	}
	if (wkspCount == 1) {
		$a.remove();
	}
	return $wkspSettings;
}

/* show the workspaces manager dialog */
function showWorkspaceManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "WorkspaceManager",
		title: "Manage your workspaces",
		size: "medium",
		icon: "<i class='fa fa-pencil'></i>",
		content: function() {
			return populateWorkspaceManager()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateWorkspaces(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#_addWorkspaceInput").focus();
}

/* rename a workspace */
function renameWorkspace(el) {
	var newWkspName = $.trim(el.val());
	if (newWkspName == '' || newWkspName == "undefined") {
		el.val(el.attr("data-workspace-name"));
	} else {
		el.val(newWkspName);
		el.closest("li").attr("data-workspace", newWkspName);
		workspaces_updated = true;
	}
}

/* add a workspace */
function addWorkspace() {
	var workspaceName = $.trim($("#_addWorkspaceInput").val()),
		$workspaceList = $("ul.workspaces"),
		$li, $div, $span, $input, $a;
	if (workspaceName == '' || workspaceName == "undefined") {
		$("#_addWorkspaceInput").val('');
		return false;
	} else {
		$li = $("<li data-workspace='" + workspaceName + "' data-workspace-id='" + randString() + "' class='new' />").appendTo($workspaceList);
		$div = $("<div class='wksp' />").appendTo($li);
		$span = $("<span class='reorder-workspace'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
		$input = $("<input type='text' value='" + workspaceName + "' maxlength='25' data-workspace-name='" + workspaceName + "' />").on("change", function() {
			renameWorkspace($(this));
		}).appendTo($div);
		$a = $("<a href='javascript:void(0)' class='delete-workspace'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteWorkspace).appendTo($div);
		$("#_addWorkspaceInput").val('');
		$(".workspaces").sortable("refresh");
		workspaces_updated = true;
		if ($workspaceList.children('li').length == 2) {
			$("<a href='javascript:void(0)' class='delete-workspace'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteWorkspace).appendTo($workspaceList.children('li').first().children("div.wksp"));
		}
		$("#_addWorkspaceInput").focus();
	}
}

/* delete a workspace */
function deleteWorkspace(e) {
	e.preventDefault();
	if (workspace_deleting == true) {
		return false;
	} else {
		workspace_deleting = true;
		var $target = $(this).closest("li"),
			$list = $target.parent("ul");
		$target.hide('fast', function() {
			if ($target.attr("data-workspace-id") == current_workspace) {
				current_workspace = ''
			}
			if (!$target.hasClass('new')) {
				workspaces_deleted = true;
			}
			$target.remove();
			$(".workspaces").sortable("refresh");
			if ($list.children("li").length == 1) {
				$list.find(".delete-workspace").remove()
			};
			workspace_deleting = false
			workspaces_updated = true;
		});
	}
}

/* save any workspace updates */
function saveWorkspaces(dialog) {
	var $dialog = $("#" + dialog.id);
	$dialog.addClass("working");
	setTimeout(function() {
		workspaces = workspaces_updated;
		if (workspaces_deleted) {
			var _remaining = [],
				_updated = [];
			for (var l = 0; l < workspaces.length; l++) {
				for (var c = 0; c < workspaces[l].content.length; c++) {
					_remaining.push(workspaces[l].content[c].id)
				}
			}
			for (var d = 0; d < widgetDataArray.length; d++) {
				for (var r = 0; r < _remaining.length; r++) {
					if (widgetDataArray[d].id == _remaining[r]) {
						_updated.push(widgetDataArray[d]);
						break;
					}
				}

			}
			widgetDataArray = _updated;
			store.set('saved_widget_data', widgetDataArray);
		}
		populateWorkspaces();
		workspaces_updated = false;
		workspaces_deleted = false;
		store.set('saved_workspaces', workspaces);
		dialogHider(dialog);
	}, 300);
}

/* check if workspaces have been updated */
function updateWorkspaces(dialog) {
	if (workspaces_updated) {
		workspaces_updated = [];
		$(".workspaces li").each(function() {
			var _content = "";
			for (var i = 0; i < workspaces.length; i++) {
				if (workspaces[i].id == $(this).attr("data-workspace-id")) {
					_content = workspaces[i].content
				}
			}
			workspaces_updated.push({
				"name": $(this).attr("data-workspace"),
				"id": $(this).attr("data-workspace-id"),
				"content": _content
			})
		});
		var save_workspaces = false;
		if (workspaces.length != workspaces_updated.length) {
			save_workspaces = true;
		} else {
			for (var i = 0; i < workspaces.length; i++) {
				if (workspaces[i].name != workspaces_updated[i].name || workspaces[i].id != workspaces_updated[i].id) {
					save_workspaces = true;
					break;
				}
			}
		}
		if (save_workspaces || workspaces_deleted) {
			if (workspaces_deleted) {
				buildConfirmDialog("You've removed some saved workspaces.", "Are you sure you want to continue?", function() {
					saveWorkspaces(dialog)
				});
			} else {
				saveWorkspaces(dialog)
			}
		} else {
			dialogHider(dialog);
		}
	} else {
		dialogHider(dialog);
	}
}

/* asynchronously render widget content */
function asyncWidgetRenderer(_content) {
	return $.Deferred(function() {
		var self = this,
			$li = $("#" + _content.id),
			$widgetContainer, min = 1,
			max = 5,
			random = Math.floor(Math.random() * (max - min + 1)) + min;
		for (var i = 0; i < widgets.length; i++) {
			if (widgets[i].name == _content.widget) {
				setTimeout(function() {
					$widgetContainer = buildWidget(widgets[i], _content.id).prependTo($li);
				}, 10 * random);
				break;
			}
		}
		self.resolve();
	});
}

/* asynchronously load gridster lis */
function asyncGridsterLoader(_content) {
	return $.Deferred(function() {
		var self = this;
		var $li = $("<li id='" + _content.id + "' data-type='" + _content.widget + "' data-min-sizex='" + _content.min_size_x + "' data-min-sizey='" + _content.min_size_y + "' />").on("focusin focusout", function() {
			$(this).find(".widget-controls").toggleClass("in-focus")
		});
		gridster.add_widget($li, _content.size_x, _content.size_y, _content.col, _content.row);
		self.resolve();
	});
}

/* change the active workspace */
function changeWorkspace(wksp) {
	if (current_workspace == wksp && workspace_loaded) {
		return false;
	} else {
		$(".gridster li").hide().find("div.widget-container").remove();
		gridster.remove_all_widgets();
		$('head [generated-from="widget"]').remove();
		current_workspace = wksp;
		store.set('current_workspace', current_workspace)
		var $wkspLists = $("[data-map='workspaces']");
		$wkspLists.children("li.on").removeClass("on");
		$wkspLists.find("a#" + wksp).parent("li").addClass("on");
		var _loadContent, _widgets = [], 
			workspace_lis = [];
		for (var i = 0; i < workspaces.length; i++) {
			if (workspaces[i].id == current_workspace) {
				_loadContent = workspaces[i].content;
				break;
			}
		}
		if (_loadContent.length) {
			$(".shell").addClass("loading");
			$(".workspace-message").hide();
			setTimeout(function() {
				for (var i = 0; i < _loadContent.length; i++) {
					workspace_lis.push(asyncGridsterLoader(_loadContent[i]))
				}
				$.when.apply($, workspace_lis).done(function() {
					$(".shell").removeClass("loading");
					workspace_loaded = true;
					responsiveTrigger = false;
					responsiveGridster();
					for (var i = 0; i < _loadContent.length; i++) {
						_widgets.push(asyncWidgetRenderer(_loadContent[i]))
					}
				});
			}, 50);
		} else {
			$(".gridster ul").removeAttr("style");
			$(".workspace-message").show()
		}
	}
}

/* toggle the workspace menu link */
function showWorkspaceList() {
	var $menu = $(".workspace-menu-toggle"),
		$container = $(".workspace-items"),
		containerWidth = $container.outerWidth(true) + 20,
		listWidth = 0;
	$container.children("li").each(function() {
		listWidth += $(this).outerWidth(true)
	});
	if (listWidth > containerWidth) {
		$menu.show()
	} else {
		$menu.hide();
		$(".workspace-menu").hide()
	}
};

/* toggle the workspace menu */
function toggleWorkspaceMenu(e) {
	e.stopPropagation();
	e.preventDefault();
	if ($(".user-menu").is(":visible")) {
		toggleUserMenu(e);
	}
	var $wkmenu = $(".workspace-menu");
	if ($wkmenu.is(":visible")) {
		$wkmenu.hide();
		$(document).off(".workspace-menu");
	} else {
		$wkmenu.show();
		$(document).on("keyup.workspace-menu", function(e) {
			if (e.keyCode == 27) {
				toggleWorkspaceMenu(e)
			}
		});
		$(document).one("click.workspace-menu", function(e) {
			toggleWorkspaceMenu(e)
		});
	}
}

/* save workspace widgets */
function saveWorkspaceData(wksp, callback) {
	var i = 0;
	while (i < workspaces.length) {
		if (workspaces[i].id == wksp) {
			workspaces[i].content = gridster.serialize();
			break;
		}
		i += 1;
	}
	store.set('saved_workspaces', workspaces);
	if (typeof callback == "function") {
		callback();
	}
}

/* ie8 ANZ Live widget fix */
function ie8Fix() {
	var _width = $("body").width();
	if (_width < 1400) {
		$("body").addClass("ie8Fix");
	} else {
		$("body").removeClass("ie8Fix");
	}
}



/********** WIDGET SETUP **********/

/* widget timer and scroller */
var libraryIsScrolling = false,
	widgetIsAdding = false;

/* widgets array */
var widgets = [{
		name: "Applications",
		id: "Applications",
		cssClass: "widget-applications",
		css: "my-applications.css",
		icon: "fa-external-link-square",
		addPNGClass: "add-widget-myExtApp",
		sx: 4,
		sy: 2,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildMyApplicationsWidget(id)
		}
	}, {
		name: "Message Centre",
		id: "Messages",
		cssClass: "widget-messages",
		css: "message-centre.css",
		icon: "fa-phone-square",
		addPNGClass: "add-widget-messageCenter",
		sx: 4,
		sy: 2,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildMessageCentreWidget(id)
		}
	}, {
		name: "Net Position",
		id: "NetPosition",
		cssClass: "widget-net-position",
		css: "net-position.css",
		icon: "fa-file-text",
		addPNGClass: "add-widget-netPositionChart",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showNetPositionSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildNetPosition(id)
		},
		finalise: function(id) {
			return finaliseNetPosition(id)
		},
		data: true
	}, {
		name: "Favourite Accounts",
		id: "FavouriteAccounts",
		cssClass: "widget-accounts",
		css: "favourite-accounts.css",
		icon: "fa-file-text",
		addPNGClass: "add-widget-favAccounts",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Download",
			icon: "fa-download",
			cssClass: "download-widget",
			attributes: [{
				name: "data-action",
				value: "download"
			}, {
				name: "title",
				value: "Download A Report For All The Accounts Above"
			}],
			events: [{
				event: "click",
				action: showFavouriteAccountsDownload
			}]
		}, {
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showFavouriteAccountsSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildFavouriteAccounts(id)
		},
		data: true
	}, {
		name: "Historical Balances",
		id: "HistoricalBalances",
		cssClass: "widget-historical-balances",
		css: "historical-balances.css",
		icon: "fa-file-text",
		addPNGClass: "add-widget-histBalanceChart",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showHistoricalBalancesSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildHistoricalBalances(id)
		},
		data: true
	}, {
		name: "Deposit Summary",
		id: "DepositSummary",
		cssClass: "widget-deposits",
		css: "deposit-summary.css",
		icon: "fa-file-text",
		addPNGClass: "add-widget-depositSummary",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Download",
			icon: "fa-download",
			cssClass: "download-widget",
			attributes: [{
				name: "data-action",
				value: "download"
			}, {
				name: "title",
				value: "Download A Report For All The Accounts Above"
			}],
			events: [{
				event: "click",
				action: showDepositSummaryDownload
			}]
		}, {
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showDepositSummarySettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildDepositSummary(id)
		},
		data: true
	}, {
		name: "Favourite Reports",
		id: "FavouriteReports",
		cssClass: "widget-reports",
		css: "fav-reports.css",
		icon: "fa-file-text",
		addPNGClass: "add-widget-favreports",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showFavoureReportSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildMyFavouriteReports(id)
		},
		data: true
	}, {
		name: "Exchange Rates",
		id: "Rates",
		cssClass: "widget-rates",
		css: "exchange-rates.css",
		icon: "fa-money",
		addPNGClass: "add-widget-fxRate",
		sx: 4,
		sy: 2,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showExchangeRateSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildExchangeRates(id)
		},
		data: true
	}, {
		name: "Insights",
		id: "Live",
		cssClass: "widget-live",
		css: "anz-live.css",
		icon: "fa-lightbulb-o",
		addPNGClass: "add-widget-anzliveMsg",
		sx: 4,
		sy: 2,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildANZLive(id)
		}
	}, {
		name: "Payments Status",
		id: "myPayments",
		cssClass: "widget-my-payments",
		css: "my-payments.css",
		icon: "fa-dollar",
		addPNGClass: "add-widget-my-payments",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showMyPaymentsSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildMyPayments(id)
		},
		data: true
	}, {
		name: "Pending Approvals",
		id: "myApprovals",
		cssClass: "widget-my-approvals",
		css: "my-approvals.css",
		icon: "fa-check-circle",
		addPNGClass: "add-widget-my-approvals",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showMyApprovalsSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildMyApprovals(id)
		},
		data: true
	}, {
		name: "Initiate Payments",
		id: "makePayments",
		cssClass: "widget-make-payments",
		css: "make-payments.css",
		icon: "fa-dollar",
		addPNGClass: "add-widget-make-payments",
		sx: 6,
		sy: 2,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildMakePayments(id)
		}
	}, {
		name: "Cards - Current Balances",
		id: "CardCurrentBalance",
		cssClass: "widget-card-balances",
		css: "card-current-balances.css",
		icon: "fa-credit-card",
		addPNGClass: "add-widget-cardBalances",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showCardCurrentBalancesSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildCardCurrentBalances(id)
		},
		data: true
	}, {
		name: "Cards - Top Spend",
		id: "CardTopSpend",
		cssClass: "widget-card-topspend",
		css: "card-top-spend.css",
		icon: "fa-credit-card",
		addPNGClass: "add-widget-topSpend",
		sx: 6,
		sy: 4,
		msx: 2,
		msy: 2,
		controls: [{
			name: "Refresh",
			icon: "fa-refresh",
			cssClass: "refresh-widget",
			events: [{
				event: "click",
				action: refreshWidgetData
			}]
		}, {
			name: "Settings",
			icon: "fa-gear",
			cssClass: "configure-widget",
			events: [{
				event: "click",
				action: showCardTopSpendSettings
			}]
		}, {
			name: "Remove",
			icon: "fa-times",
			cssClass: "remove-widget",
			events: [{
				event: "click",
				action: removeWidgetCheck
			}]
		}],
		content: function(id) {
			return buildCardTopSpend(id)
		},
		data: true
	}
];

/* widget data and settings array */
var widgetDataArray = [];

/* grab from local storage if available */
if (store.get('saved_widget_data')) {
	widgetDataArray = store.get('saved_widget_data')
};

/* populate the widget library */
function populateWidgetLibrary() {
	var widgetCount = widgets.length,
		$div, $a, $img, $info, $dialog, $slider = $(".widget-slider");
	if (widgetCount > 0) {
		$.each(widgets, function() {
			$div = $("<div class='add-widget " + this.addPNGClass + "' />").on("focusin focusout", function() {
					$(this).children(".widget-information").toggleClass("full-opacity")
				}).appendTo($slider),
				$a = $("<a href='#" + this.id + "' title='Add this content to your workspace' >" + this.name + "</a>").on("click", function(e) {
					e.preventDefault();
					var _link = $(this);
					if (_link.attr("data-clicked")) {
						return false;
					} else {
						_link.attr("data-clicked", true);
						setTimeout(function() {
							_link.removeAttr("data-clicked")
						}, 2000);
						addWidget($(this).attr("href").substring(1));
					}
				}).appendTo($div),
				$img = $("<div class='widget-png " + this.cssClass + "' />").prependTo($a),
				$info = $("<div class='widget-information' />").appendTo($div),
				$dialog = $("<a href='#" + this.id + "' title='Learn more about this content'><i class='fa fa-info-circle'></i></a>").appendTo($info).on("click", function(e) {
					e.preventDefault();
					var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
					var _widgetID = $(this).attr("href").substring(1),
						i = 0,
						_dialog;
					while (i < widgets.length) {
						if (widgets[i].id == _widgetID) {
							_dialog = widgets[i];
							break;
						}
						i += 1;
					}
					_dialog = {
						id: _dialog.id,
						title: "ABOUT " + _dialog.name.toUpperCase(),
						size: "wide",
						icon: "<i class='fa fa-info-circle'></i>",
						content: function() {
							return getAboutWidgetInfo(_dialog)
						},
						buttons: [{
							name: "Close",
							icon: "<i class='fa fa-times fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog)
								}
							}]
						}, {
							name: "Add To Workspace",
							icon: "<i class='fa fa-plus-square fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog);
									addWidget($(this).attr("href").substring(1))
								}
							}],
							cssClass: "primary"
						}]
					}
					dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
				});
		});
	}
}

/* about widget content */
function getAboutWidgetInfo(_dialog) {
	var _id = _dialog.id;
	var $aboutContainer = $("<div />"),
		$aboutImage = $("<div class='about-image' />"),
		$aboutText = $("<div class='about-text' />");
	switch (_id) {
		case "Applications":
			$aboutContainer.addClass("about-widget-applications");
			$aboutText.html("<p>Add My Applications to your workspace to easily and quickly access your ANZ banking services.</p><p>After selecting an application it will automatically open in a new browser tab / window.</p>");
			break;
		case "Messages":
			$aboutContainer.addClass("about-widget-messages");
			$aboutText.html("<p>Add the Message Centre to your workspace for keeping up to date with important information from ANZ:</p><ul><li>News, announcements and service notifications</li><li>New and enhanced ANZ applications</li><li>Training events and materials for using ANZ applications</li></ul>");
			break;
		case "NetPosition":
			$aboutContainer.addClass("about-widget-net-position");
			$aboutText.html("<p>Add Net Position to your workspace for a consolidated graphical view of your current balances.</p><ul><li>Choose between waterfall, bar or pie chart view</li><li>Group by currency, country, company or account type</li><li>Easily download net position reports</li></ul>");
			break;
		case "FavouriteAccounts":
			$aboutContainer.addClass("about-widget-accounts");
			$aboutText.html("<p>Add Favourite Accounts to your workspace for a snapshot of your most frequently used accounts:</p><ul><li>Quickly view account balances</li><li>Easily download account reports</li><li>Access detailed account balance and transaction information</li></ul>");
			break;
		case "DepositSummary":
			$aboutContainer.addClass("about-widget-deposits");
			$aboutText.html("<p>Add Deposit Summary to your workspace for a snapshot of your Deposits:</p><ul><li>Quickly view deposit summary information</li><li>Easily download deposit reports</li><li>Access detailed deposit information</li></ul>");
			break;
		case "HistoricalBalances":
			$aboutContainer.addClass("about-widget-historical-balances");
			$aboutText.html("<p>Add Historical Balances to your workspace for a graphical view of your balance history:</p><ul><li>Add up to seven of your accounts</li><li>View up to 12 months of balance history at a glance</li><li>Easily switch and zoon to different time periods</li></ul>");
			break;
		case "FavouriteReports":
			$aboutContainer.addClass("about-widget-reports");
			$aboutText.html("<p>Add Favourite Reports to your workspace for quick and easy access to your report profiles.</p>");
			break;
		case "Rates":
			$aboutContainer.addClass("about-widget-exchange-rate");
			$aboutText.html("<p>Add Exchange Rates to your workspace for a snapshot of exchange rates:</p><ul><li>Quickly view a custom list of exchange rates</li><li>Easily add new currency pairs</li><li>Rates are indicative and updated daily</li></ul>");
			break;
		case "myPayments":
			$aboutContainer.addClass("about-widget-my-payments");
			$aboutText.html("<p>Add My Payments to your workspace for a snapshot of current payments.</p>");
			break;
		case "myApprovals":
			$aboutContainer.addClass("about-widget-my-payments");
			$aboutText.html("<p>Add Awaiting My Approvals to your workspace to review and approve items that are pending your approval.</p>");
			break;
		case "makePayments":
			$aboutContainer.addClass("about-widget-make-payments");
			$aboutText.html("<p>Add Make Payments to your workspace to quickly initiate or upload new payments.</p>");
			break;
		case "Live":
			$aboutContainer.addClass("about-widget-anz-live");
			$aboutText.html("<p>Add Insights to your workspace for a shortcut into ANZ Live, where you can view the latest ANZ research, publications and thought leadership.</p>");
			break;
		case "NPPPayments":
			$aboutContainer.addClass("about-widget-fast-payments");
			$aboutText.html("<p>Add the Fast Payments widget to your workspace to quickly create and submit NPP Payments.</p>");
			break;
		case "CardCurrentBalance":
			$aboutContainer.addClass("about-widget-cards-current-balances");
			$aboutText.html("<p>Add the Commercial Cards Current Balances widget to your workspace for a view of current card balances, minimum payment amounts, and payment due dates.</p>");
			break;
		case "CardTopSpend":
			$aboutContainer.addClass("about-widget-cards-top-spend");
			$aboutText.html("<p>Add the Commercial Cards Top Spend widget to your workspace for a view of the top ten suppliers and mcc data by spend amount.</p>");
			break;
	}
	$aboutImage.appendTo($aboutContainer);
	$aboutText.appendTo($aboutContainer);
	return $aboutContainer;
}

function toggleWidgetScrollers() {
	var $widgetSlider = $(".widget-slider"),
		$lastWidget = $(".widget-slider .add-widget:last-child");
	if ($widgetSlider.width() > $lastWidget.position().left + $lastWidget.width()) {
		$(".widget-move-left, .widget-move-right").hide();
	} else {
		$(".widget-move-left, .widget-move-right").show();
	}
}

/* toggle the widget library panel */
function toggleWorkspaceLibrary(e) {
	e.preventDefault();
	var $widgetPanel = $(".widget-panel"),
		isVisible = $widgetPanel.is(":visible");
	if (isVisible) {
		if (transitionSupport) {
			$widgetPanel.css({
				"margin-top": -245
			}).on("transitionend.widgets webkitTransitionEnd.widgets oTransitionEnd.widgets MSTransitionEnd.widgets", function() {
				$(".widget-slider").scrollLeft(0);
				$widgetPanel.hide();
				$(this).off(".widgets");
			});
		} else {
			$widgetPanel.animate({
				marginTop: -245
			}, {
				duration: 300,
				queue: false,
				complete: function() {
					$(".widget-slider").scrollLeft(0);
					$widgetPanel.hide();
				}
			});
		}
	} else {
		if (transitionSupport) {
			$widgetPanel.off(".widgets").show(0, function() {
				$widgetPanel.css({
					"margin-top": 0
				});
			})
		} else {
			$widgetPanel.show().animate({
				marginTop: 0
			}, {
				duration: 300,
				queue: false
			});
		}
		toggleWidgetScrollers();
	}
}

/* slide the widget library */
function scrollWidgetsLeft() {
	$(".widget-slider").animate({
		scrollLeft: '-=380'
	}, "fast", "linear", scrollWidgetsLeft);
}

function scrollWidgetsRight() {
	$(".widget-slider").animate({
		scrollLeft: '+=380'
	}, "fast", "linear", scrollWidgetsRight);
}

function stopWidgetScrolling(e) {
	$(".widget-slider").stop();
}

/* remove the widget */
function removeWidget(e) {
	var _content = $("#" + $(e.target).closest("li").attr("id")),
		_id = $(e.target).closest("li").attr("id");
	gridster.remove_widget(_content, true, function() {
		gridster.resize_widget_dimensions({
			widget_base_dimensions: [columnWidths, 100]
		})
		for (var i = 0; i < widgetDataArray.length; i++) {
			if (widgetDataArray[i].id == _id) {
				widgetDataArray.splice(i, 1);
				store.set('saved_widget_data', widgetDataArray);
				break;
			}
		}
		saveWorkspaceData(current_workspace, function() {
			if ($(".gridster ul").children("li").length == 0) {
				$(".gridster ul").removeAttr("style");
				$(".workspace-message").show();
			}
		});
	});
}

/* check to remove widget */
function removeWidgetCheck(e) {
	e.preventDefault();
	buildConfirmDialog("Remove this content from your workspace?", "", function() {
		removeWidget(e)
	});
}

/* refresh widget data */
function refreshWidgetData(e) {
	e.preventDefault();
	var $widget = $(this).closest("div.widget-container").addClass("loading");
	setTimeout(function() {
		$widget.removeClass("loading")
	}, 500);
};

/* build widget and populate the widgetDataArray if required */
function buildWidget(_widget, id) {
	var _id = id;

	if (_widget.data) {
		var _widgetData = {
				id: _id,
				name: _widget.name,
				data: [],
				settings: []
			},
			_exists = false;
		for (var i = 0; i < widgetDataArray.length; i++) {
			if (widgetDataArray[i].id == _id) {
				_exists = true
				break;
			}
		}
		if (!_exists) {
			widgetDataArray.push(_widgetData);
			store.set('saved_widget_data', widgetDataArray);
		}
	}

	/*
	if (!$("head link[href='css/widgets/" + _widget.css + "']").size()) {
		var cssUrl = "css/widgets/" + _widget.css;
		if (document.createStyleSheet) {
			try {
				document.createStyleSheet(cssUrl);
			} catch (e) {}
		} else {
			var css;
			css = document.createElement('link');
			css.rel = 'stylesheet';
			css.type = 'text/css';
			css.href = cssUrl;
			css.setAttribute('generated-from', 'widget');
			document.getElementsByTagName("head")[0].appendChild(css);
		}
	}
	*/


	var $widgetContainer = $("<div class='widget-container " + _widget.cssClass + "' />"),
		$widgetHeader = $("<div class='widget-header'><i class='fa " + _widget.icon + " fa-lg'></i>" + _widget.name + "</div>").appendTo($widgetContainer),
		$widgetControls = $("<div class='widget-controls' />").appendTo($widgetContainer);
	if (_widget.controls) {
		for (var c = 0; c < _widget.controls.length; c++) {
			var $control = $("<a href='#" + _id + "' title='" + _widget.controls[c].name + "' class='" + _widget.controls[c].cssClass + "'><i class='fa " + _widget.controls[c].icon + " fa-fw'></i></a>").appendTo($widgetControls);
			if (_widget.controls[c].attributes) {
				for (var a = 0; a < _widget.controls[c].attributes.length; a++) {
					$control.attr(_widget.controls[c].attributes[a].name, _widget.controls[c].attributes[a].value);
				}
			}
			if (_widget.controls[c].events) {
				for (var e = 0; e < _widget.controls[c].events.length; e++) {
					$control.on(_widget.controls[c].events[e].event, _widget.controls[c].events[e].action);
				}
			}
		}
	}
	var $widgetBody = $("<div class='widget-body' />").appendTo($widgetContainer),
		$widgetContent = $("<div class='widget-content' />").appendTo($widgetBody);
	if (_widget.buttons) {
		$widgetContent.addClass("has-buttons");
		var $widgetButtons = $("<div class='widget-buttons' />").appendTo($widgetBody),
			$a, $icon, $text;
		for (var b = 0; b < _widget.buttons.length; b++) {
			$a = $("<a href='javascript:void(0)' />");
			if (_widget.buttons[b].icon) {
				$icon = $("<i class='fa " + _widget.buttons[b].icon + " fa-fw fa-lg'></i>").appendTo($a);
			}
			if (_widget.buttons[b].attributes) {
				for (var a = 0; a < _widget.buttons[b].attributes.length; a++) {
					$a.attr(_widget.buttons[b].attributes[a].name, _widget.buttons[b].attributes[a].value);
				}
			}
			if (_widget.buttons[b].events) {
				for (var e = 0; e < _widget.buttons[b].events.length; e++) {
					$a.on(_widget.buttons[b].events[e].event, _widget.buttons[b].events[e].action);
				}
			}
			$text = $("<span>" + _widget.buttons[b].name + "</span>").appendTo($a);
			$a.appendTo($widgetButtons)
		}
	}
	var $widgetData = _widget.content(_id);
	$widgetContent.html($widgetData);
	return $widgetContainer;
}

/* add widget to gridster */
function addWidget(widget) {
	if (widgetIsAdding) {
		return false;
	} else {
		widgetIsAdding = true;
		var _widget, i = 0,
			addWidget, widgetID;
		var $li, $widgetContainer;
		while (i < widgets.length) {
			if (widgets[i].id == widget) {
				_widget = widgets[i];
				break;
			}
			i += 1;
		}
		if (typeof(_widget) == "undefined") {
			buildErrorNotification("This widget does not exist in the widget array", "Add widgets to the widgets array in order to link to them.", 200);
			return false;
		} else {
			widgetID = randString(8),
				$li = $("<li data-sizex='" + _widget.sx + "' data-sizey='" + _widget.sy + "' data-min-sizex='" + _widget.msx + "' data-min-sizey='" + _widget.msy + "' id='" + widgetID + "' data-type='" + _widget.name + "' />").on("focusin focusout", function() {
					$(this).find(".widget-controls").toggleClass("in-focus")
				});
			gridster.add_widget($li, _widget.sx, _widget.sy);
			/*
			$("div.workspace").animate({
				scrollTop: $li.position().top - 20
			}, 300);
			*/
			saveWorkspaceData(current_workspace, function() {
				$widgetContainer = buildWidget(_widget, widgetID).prependTo($li);
				buildNotification(_widget.name + " content has been added to your workspace", 300, 4000);
				$(".workspace-message").hide();
				setTimeout(function() {
					widgetIsAdding = false
				}, 100);
			});
		}
	}
}

/* locate the widget data in the workspaces array */
function findWidgetData(id) {
	var _widget;
	for (var i = 0; i < widgetDataArray.length; i++) {
		if (widgetDataArray[i].id == id) {
			_widget = widgetDataArray[i];
			break;
		}
	}
	if (!_widget) {
		buildErrorNotification("Something Went Wrong", "I wasn't able to find a reference to this widget. This should not happen in the prototype.", 200)
		return false;
	} else {
		return _widget;
	}
}



/********** INDIVIDUAL WIDGET FUNCTIONS *********/

/* my applications widget */
function buildMyApplicationsWidget(id) {
	var $ul = $("<ul />"),
		$li, $a;
	if (applications.length > 0) {
		$.each(applications, function() {
			$li = $("<li />").appendTo($ul),
				$a = $("<a href='" + this.url + "' target='" + this.target + "' title='" + this.name + "'><i class='fa fa-external-link fa-fw'></i>" + this.name + "</a>").appendTo($li)
		});
	}
	return $ul;
}


/* message centre widget */
function buildMessageCentreWidget(id) {
	var $ul = $("<ul />"),
		$li, $a, $date, $title, $message, $link, _shortmsg;
	$.each(messages, function() {
		$li = $("<li />").appendTo($ul),
			$a = $("<a href='#" + this.id + "' />").appendTo($li).on("click", function(e) {
				e.preventDefault();
				var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
				var _messageID = $(this).attr("href").substring(1),
					i = 0,
					_dialog;
				while (i < messages.length) {
					if (messages[i].id == _messageID) {
						_dialog = messages[i];
						break;
					}
					i += 1;
				}
				_dialog = {
					id: _dialog.id,
					title: "ANZ Message",
					size: "small",
					icon: "<i class='fa fa-circle'></i>",
					content: "<div class='message-dialog'><div style='position: absolute; top: 10px; right: 10px; color: #394A58;'>" + _dialog.date + "</div><div style='font-size: 18px; color: #004165; margin-top: 10px;'>" + _dialog.title + "</div><div style='color: #394A58;'>" + _dialog.message + "</div><div><a href='" + _dialog.url + "' target='" + _dialog.url + "'>" + _dialog.link + "</a></div></div>"
				}
				dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			}),
			$date = $("<div class='message-title'><i class='fa fa-circle fa-fw'></i>" + this.title + "</div>").appendTo($a),
			$title = $("<div class='message-date'>" + this.date + "</div>").appendTo($a);
		if (this.message.length >= 160) {
			_shortmsg = this.message.substring(0, 160) + '...'
		} else {
			_shortmsg = this.message
		}
		$message = $("<div class='message'>" + _shortmsg + "</div>").appendTo($a),
			$link = $("<a class='message-link' href='" + this.url + "' target='" + this.url + "'>" + this.link + "</a>").appendTo($li);
	});
	return $ul;
}


/* anz live widget */
function buildANZLive(id) {
	var $div = $("<a href='https://anzlive.secure.force.com/' target='_blank'><div class='anz-live-bg'><div class='anz-live-text'><div>View the latest ANZ research, publications and thought leadership. <span>Click here</span> to visit ANZ Live</div></div></div></a>");
	return $div;
}


/* favourite accounts widget */
var accounts = [{
	name: "Primary Savings Account",
	number: "113-6677-322",
	currency: "AUD",
	funds: "12,000.00",
	available: "12,000.00",
	balance: "12,000.00"
}, {
	name: "Funding Account Singapore",
	number: "456-8888-125",
	currency: "SGD",
	funds: "32,101.53",
	available: "32,101.53",
	balance: "32,101.53"
}, {
	name: "Loan Repayment Account",
	number: "684-2345-111",
	currency: "SGD",
	funds: "6,130.00",
	available: "6,130.00",
	balance: "6,130.00"
}, {
	name: "Operations Account",
	number: "334-3566-122",
	currency: "AUD",
	funds: "8,456.31",
	available: "8,456.31",
	balance: "8,456.31"
}, {
	name: "Current Account",
	number: "888-3354-355",
	currency: "HKD",
	funds: "17,257.91",
	available: "17,257.91",
	balance: "17,257.91"
}, {
	name: "Funding Account China",
	number: "356-5788-009",
	currency: "HKD",
	funds: "57,774.31",
	available: "57,774.31",
	balance: "57,774.31"
}, {
	name: "India Operations",
	number: "433-3566-123",
	currency: "INR",
	funds: "76,730.00",
	available: "76,730.00",
	balance: "76,730.00"
}, {
	name: "Legal Operations Account",
	number: "112-6578-244",
	currency: "AUD",
	funds: "108,456.31",
	available: "108,456.31",
	balance: "108,456.31"
}, {
	name: "Trade Account",
	number: "333-3555-122",
	currency: "SGD",
	funds: "27,257.31",
	available: "27,257.31",
	balance: "27,257.31"
}, {
	name: "Secondary Savings Account",
	number: "111-1222-245",
	currency: "AUD",
	funds: "207,774.31",
	available: "207,774.31",
	balance: "207,774.31"
}, {
	name: "India Legal",
	number: "344-1678-999",
	currency: "INR",
	funds: "500,000.00",
	available: "500,000.00",
	balance: "500,000.00"
}, {
	name: "India Financing",
	number: "311-3556-133",
	currency: "INR",
	funds: "700,000.00",
	available: "700,000.00",
	balance: "700,000.00"
}, {
	name: "Thai Operations",
	number: "777-3123-663",
	currency: "THB",
	funds: "1,000,000.00",
	available: "1,000,000.00",
	balance: "1,000,000.00"
}, {
	name: "THB Legal",
	number: "334-1456-123",
	currency: "THB",
	funds: "2,632,012.64",
	available: "2,632,012.64",
	balance: "2,632,012.64"
}];

function showRemoveAccounts(_target, _widget) {

	/* set _data to the widget data and _id to the widget id */
	var _data = _widget.data,
		_id = _widget.id;

	/* function to remove selected accounts from the widget */
	function removeSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
			for (var i = 0; i < _data.length; i++) {
				for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
					if (_data[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
						_data.splice(i, 1);
					}
				}
			}
			dialogHider(_dialog);
			buildFavouriteAccounts(_id, true);
			store.set('saved_widget_data', widgetDataArray);
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the remove accounts list */
	var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='RemoveAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addAccount]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='RemoveAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each(_data, function() {

		$li = $("<li>").appendTo($ul),
			$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					if ($target.hasClass("fav-data-col")) {
						$target = $target.closest("div.fav-row");
					}
					$target = $target.find("input[name='_addAccount']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
				}
				if (!$(this).prop("checked")) {
					$("input[name='_selectAll']").prop("checked", false)
				}
				if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
					$("input[name='_selectAll']").prop("checked", true)
				}
			}),
			$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
			}),
			$name = $("<div class='fav-data-col' style='width: 220px;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
			$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)


	});

	/* build and show the remove accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "RemoveAccounts",
		title: "Remove Accounts",
		size: "medium",
		icon: "<i class='fa fa-minus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					removeSelectedAccounts(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#RemoveAccountsFilterInput").fastLiveFilter('#RemoveAccountsFilterList');

	/* if no accounts are available display a message */
	if (!$("#RemoveAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to remove</div>").appendTo($dataContainer);
	}
}

function showAddAccounts(_target, _widget) {

	/* set _data to the widget data and _id to the widget id */
	var _data = _widget.data,
		_id = _widget.id;

	/* function to save and add selected accounts to the widget */
	function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
			for (var i = 0; i < accounts.length; i++) {
				for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
					if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
						_data.push(accounts[i]);
					}
				}
			}
			dialogHider(_dialog);
			buildFavouriteAccounts(_id, true);
			store.set('saved_widget_data', widgetDataArray);
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='widget-accounts wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearAccountsFilter").show()
			} else {
				$("#clearAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#AddAccountsFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addAccount]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
			if (_data[i].number == this.number) {
				_alreadyAdded = true;
				break;
			}
		}
		if (!_alreadyAdded) {
			$li = $("<li>").appendTo($ul),
				$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						if ($target.hasClass("fav-data-col")) {
							$target = $target.closest("div.fav-row");
						}
						$target = $target.find("input[name='_addAccount']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='_selectAll']").prop("checked", false)
					}
					if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
						$("input[name='_selectAll']").prop("checked", true)
					}
				}),
				$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
			var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
					var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
				}),
				$name = $("<div class='fav-data-col' style='width: 220px;'>" + this.name + "</div>").appendTo($row),
				$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
				$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveSelectedAccounts(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

	/* if no accounts are available display a message */
	if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

function showFavouriteAccountsDownload(e) {

	e.preventDefault();

	/* set the id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id),

		/* set _settings to the widget settings in the widgetDataArray */
		_settings = _widget.settings;

	/* check if the remember settings is enabled */
	if (_settings[0].remember == true) {

		$(e.target).closest(".widget-container").addClass("working")
		setTimeout(function() {
			$(e.target).closest(".widget-container").removeClass("working");
			alert("Here is your " + _widget.settings[0].report + " " + _widget.settings[0].format + " for " + _widget.settings[0].date + ".");
		}, 1000);

	} else {

		/* build the download form */
		var $settings = $("<div class='widget-accounts data-form' />"),
			$downloadSection = $("<div class='form-section' />").appendTo($settings),
			$typeRow = $("<div class='row' />").appendTo($downloadSection),
			$typeLabelCol = $("<div class='label-column' />").appendTo($typeRow),
			$typeLabel = $("<label>Report Type</label>").appendTo($typeLabelCol),
			$typeDataCol = $("<div class='data-column' />").appendTo($typeRow),
			$customTypeSelect = $("<div class='custom-select' />").appendTo($typeDataCol),
			$typeElement = $("<select id='" + _widget.id + "-type'><option value='Account Statement'>Account Statement</option><option value='Balance History'>Balance History</option></select>").appendTo($customTypeSelect).val(_widget.settings[0].report),
			$formatRow = $("<div class='row' />").appendTo($downloadSection),
			$formatLabelCol = $("<div class='label-column' />").appendTo($formatRow),
			$formatLabel = $("<label>Report Format</label>").appendTo($formatLabelCol),
			$formatDataCol = $("<div class='data-column' />").appendTo($formatRow),
			$customFormatSelect = $("<div class='custom-select' />").appendTo($formatDataCol),
			$formatElement = $("<select id='" + _widget.id + "-format'><option value='CSV'>CSV</option><option value='Excel'>Excel</option><option value='MT940'>MT940</option><option value='PDF'>PDF</option></select>").appendTo($customFormatSelect).val(_widget.settings[0].format).on("change", function() {
				if ($(this).val() == "PDF" || $(this).val() == "Excel") {
					$("div[data-value='grouping']").slideDown("fast");
				} else {
					$("div[data-value='grouping']").slideUp("fast");
				}
			}),
			$groupRow = $("<div class='row' data-value='grouping' />").appendTo($downloadSection),
			$groupLabelCol = $("<div class='label-column' />").appendTo($groupRow),
			$groupLabel = $("<label>&nbsp;</label>").appendTo($groupLabelCol),
			$groupDataCol = $("<div class='data-column' />").appendTo($groupRow),
			$groupElement = $("<input type='checkbox' id='" + _widget.id + "-group' />").appendTo($groupDataCol).prop("checked", _widget.settings[0].group),
			$groupLabelDesc = $("<label class='desc' for='" + _widget.id + "-group'>Group Transactions</label>").appendTo($groupDataCol),
			$groupNote = $("<div class='data-note'>When 'Group Transactions' is checked, the transactions for each day will be grouped by debit/credit amount and transaction type.</div>").appendTo($groupDataCol),
			$dateRow = $("<div class='row' />").appendTo($downloadSection),
			$dateLabelCol = $("<div class='label-column' />").appendTo($dateRow),
			$dateLabel = $("<label>Date</label>").appendTo($dateLabelCol),
			$dateDataCol = $("<div class='data-column' />").appendTo($dateRow),
			$customDateSelect = $("<div class='custom-select' />").appendTo($dateDataCol),
			$dateElement = $("<select id='" + _widget.id + "-date'><option value='Today'>Today</option><option value='Yesterday'>Yesterday</option><option value='This Week'>This Week</option><option value='Last Week'>Last Week</option><option value='This Month'>This Month</option><option value='Last Month'>Last Month</option></select>").appendTo($customDateSelect).val(_widget.settings[0].date),
			$rememberRow = $("<div class='row' />").appendTo($downloadSection),
			$rememberLabelCol = $("<div class='label-column' />").appendTo($rememberRow),
			$rememberLabel = $("<label>&nbsp;</label>").appendTo($rememberLabelCol),
			$rememberDataCol = $("<div class='data-column' />").appendTo($rememberRow),
			$rememberElement = $("<input type='checkbox' id='" + _widget.id + "-remember' />").appendTo($rememberDataCol).prop("checked", _widget.settings[0].remember).on("click", function() {
				var _note = $(this).closest("div.row").find("[data-note='remember']");
				if ($(this).prop("checked")) {
					_note.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
				} else {
					_note.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
				}
			}),
			$rememberLabelDesc = $("<label class='desc' for='" + _widget.id + "-remember'>Remember This</label>").appendTo($rememberDataCol),
			$noteText = $("<div class='data-note' data-note='remember'></div>").appendTo($rememberDataCol);

		if ($rememberElement.prop("checked")) {
			$noteText.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
		} else {
			$noteText.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
		}

		if ($formatElement.val() == "PDF" || $formatElement.val() == "Excel") {
			$groupRow.show();
		} else {
			$groupRow.hide();
		}

		/* the download report function */
		function downloadReport(_dialog) {
			if ($rememberElement.prop("checked")) {
				_widget.settings[0].report = $typeElement.val();
				_widget.settings[0].format = $formatElement.val();
				_widget.settings[0].date = $dateElement.val();
				_widget.settings[0].remember = $rememberElement.prop("checked");
				_widget.settings[0].group = $groupElement.prop("checked");
				store.set('saved_widget_data', widgetDataArray);
			}
			dialogHider(_dialog);
			$(e.target).closest(".widget-container").addClass("working");
			setTimeout(function() {
				$(e.target).closest(".widget-container").removeClass("working");
				alert("Here is your " + _widget.settings[0].report + " " + _widget.settings[0].format + " for " + _widget.settings[0].date + ".");
			}, 1000);

		}

		/* open the download dialog */
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: _widget.id + "Download",
			title: "Download",
			size: "small",
			icon: "<i class='fa fa-download'></i>",
			content: $settings,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						downloadReport(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}
}

function showFavouriteAccountsSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id");

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		var _rebuild = false;
		if (_widget.settings[0].showavailablefunds != $viewElement.prop("checked") || _widget.settings[0].showavailablebalance != $viewElement2.prop("checked")) {
			_rebuild = true;
		}
		_widget.settings = [{
			showavailablefunds: $viewElement.prop("checked"),
			showavailablebalance: $viewElement2.prop("checked"),
			report: $typeElement.val(),
			format: $formatElement.val(),
			group: $groupElement.prop("checked"),
			date: $dateElement.val(),
			remember: $rememberElement.prop("checked")
		}];
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		if (_rebuild) {
			buildFavouriteAccounts(id, true);
		}
	}

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-accounts data-form' />"),


		/* build the view settings */
		$viewSectionHeading = $("<div class='section-heading'>View Settings</div>").appendTo($settings),
		$viewSection = $("<div class='form-section' />").appendTo($settings),
		$viewRow = $("<div class='row' />").appendTo($viewSection),
		$viewDataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($viewRow),
		$viewElement = $("<input type='checkbox' id='" + _widget.id + "-funds' />").appendTo($viewDataCol).prop("checked", _widget.settings[0].showavailablefunds),
		$viewLabelDesc = $("<label class='desc' for='" + _widget.id + "-funds'>Show Available Funds</label>").appendTo($viewDataCol),
		$viewElement2 = $("<input type='checkbox' id='" + _widget.id + "-available' />").appendTo($viewDataCol).prop("checked", _widget.settings[0].showavailablebalance),
		$viewLabelDesc2 = $("<label class='desc' for='" + _widget.id + "-available'>Show Available Balance</label>").appendTo($viewDataCol),

		/* build the download settings */
		$downloadSectionHeading = $("<div class='section-heading'>Download Settings</div>").appendTo($settings),
		$downloadSection = $("<div class='form-section' />").appendTo($settings),
		$typeRow = $("<div class='row' />").appendTo($downloadSection),
		$typeLabelCol = $("<div class='label-column' />").appendTo($typeRow),
		$typeLabel = $("<label>Report Type</label>").appendTo($typeLabelCol),
		$typeDataCol = $("<div class='data-column' />").appendTo($typeRow),
		$customTypeSelect = $("<div class='custom-select' />").appendTo($typeDataCol),
		$typeElement = $("<select id='" + _widget.id + "-type'><option value='Account Statement'>Account Statement</option><option value='Balance History'>Balance History</option></select>").appendTo($customTypeSelect).val(_widget.settings[0].report),
		$formatRow = $("<div class='row' />").appendTo($downloadSection),
		$formatLabelCol = $("<div class='label-column' />").appendTo($formatRow),
		$formatLabel = $("<label>Report Format</label>").appendTo($formatLabelCol),
		$formatDataCol = $("<div class='data-column' />").appendTo($formatRow),
		$customFormatSelect = $("<div class='custom-select' />").appendTo($formatDataCol),
		$formatElement = $("<select id='" + _widget.id + "-format'><option value='CSV'>CSV</option><option value='Excel'>Excel</option><option value='MT940'>MT940</option><option value='PDF'>PDF</option></select>").appendTo($customFormatSelect).val(_widget.settings[0].format).on("change", function() {
			if ($(this).val() == "PDF" || $(this).val() == "Excel") {
				$("div[data-value='grouping']").slideDown("fast");
			} else {
				$("div[data-value='grouping']").slideUp("fast");
			}
		}),
		$groupRow = $("<div class='row' data-value='grouping' />").appendTo($downloadSection),
		$groupLabelCol = $("<div class='label-column' />").appendTo($groupRow),
		$groupLabel = $("<label>&nbsp;</label>").appendTo($groupLabelCol),
		$groupDataCol = $("<div class='data-column' />").appendTo($groupRow),
		$groupElement = $("<input type='checkbox' id='" + _widget.id + "-group' />").appendTo($groupDataCol).prop("checked", _widget.settings[0].group),
		$groupLabelDesc = $("<label class='desc' for='" + _widget.id + "-group'>Group Transactions</label>").appendTo($groupDataCol),
		$groupNote = $("<div class='data-note'>When 'Group Transactions' is checked, the transactions for each day will be grouped by debit/credit amount and transaction type.</div>").appendTo($groupDataCol),
		$dateRow = $("<div class='row' />").appendTo($downloadSection),
		$dateLabelCol = $("<div class='label-column' />").appendTo($dateRow),
		$dateLabel = $("<label>Date</label>").appendTo($dateLabelCol),
		$dateDataCol = $("<div class='data-column' />").appendTo($dateRow),
		$customDateSelect = $("<div class='custom-select' />").appendTo($dateDataCol),
		$dateElement = $("<select id='" + _widget.id + "-date'><option value='Today'>Today</option><option value='Yesterday'>Yesterday</option><option value='This Week'>This Week</option><option value='Last Week'>Last Week</option><option value='This Month'>This Month</option><option value='Last Month'>Last Month</option></select>").appendTo($customDateSelect).val(_widget.settings[0].date),
		$rememberRow = $("<div class='row' />").appendTo($downloadSection),
		$rememberLabelCol = $("<div class='label-column' />").appendTo($rememberRow),
		$rememberLabel = $("<label></label>").appendTo($rememberLabelCol),
		$rememberDataCol = $("<div class='data-column' />").appendTo($rememberRow),
		$rememberElement = $("<input type='checkbox' id='" + _widget.id + "-remember' />").appendTo($rememberDataCol).prop("checked", _widget.settings[0].remember).on("click", function() {
			var _note = $(this).closest("div.row").find("[data-note='remember']");
			if ($(this).prop("checked")) {
				_note.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
			} else {
				_note.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
			}
		}),
		$rememberLabelDesc = $("<label class='desc' for='" + _widget.id + "-remember' title=''>Remember This</label>").appendTo($rememberDataCol),
		$noteText = $("<div class='data-note' data-note='remember'></div>").appendTo($rememberDataCol);

	if ($rememberElement.prop("checked")) {
		$noteText.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
	} else {
		$noteText.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
	}

	if (_widget.settings[0].format == "PDF" || _widget.settings[0].format == "Excel") {
		$groupRow.show();
	} else {
		$groupRow.hide();
	}


	/* build the accounts section */
	var $accountSectionHeading = $("<div class='section-heading'>Accounts</div>").appendTo($settings),
		$accountSection = $("<div class='form-section' />").appendTo($settings),
		$accountRow = $("<div class='row' />").appendTo($accountSection),
		$accountDataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($accountRow),
		$accountNoteData,
		$addAccountsButton,
		$removeAccountsButton;

	if (_widget.data.length == 0) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You haven't added any favourite accounts yet.</div>").appendTo($accountDataCol);
		$addAccountsButton = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showAddAccounts($("#" + _widget.id + "Settings"), _widget)
		});
	} else if (_widget.data.length >= 1 && _widget.data.length < 20) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You've added " + _widget.data.length + " favourite account(s).</div>").appendTo($accountDataCol);
		$addAccountsButton = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showAddAccounts($("#" + _widget.id + "Settings"), _widget)
		});
		$removeAccountsButton = $("<a href='javascript:void(0)' class='form-button' ><i class='fa fa-times fa-fw'></i>Remove Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showRemoveAccounts($("#" + _widget.id + "Settings"), _widget);
		});
	} else if (_widget.data.length == 20) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You've added 20 favourite accounts.</div>").appendTo($accountDataCol);
		$removeAccountsButton = $("<a href='javascript:void(0)' class='form-button'><i class='fa fa-times fa-fw' style='margin-right: 5px;'></i>Remove Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showRemoveAccounts($("#" + _widget.id + "Settings"), _widget);
		});
	}



	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Favourite Accounts Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function buildFavouriteAccounts(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length) {
		_widget.settings = [{
			showavailablefunds: false,
			showavailablebalance: false,
			report: "Account Statement",
			format: "PDF",
			group: false,
			date: "Yesterday",
			remember: false
		}];
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	/* the function to save the widget data whenever accounts are re-ordered */
	function saveReorderedAccounts(result) {
		var _reorderdList = [];
		for (var i = 0; i < result.length; i++) {
			for (var d = 0; d < _widget.data.length; d++) {
				if (result[i] == _widget.data[d].number) {
					_reorderdList.push(_widget.data[d])
				}
			}
		}
		_widget.data = _reorderdList;
		store.set('saved_widget_data', widgetDataArray);
	}


	/* build the widget content */
	var $wrapper = $("<div class='wrapper' />"),
		$header = $("<div class='fav-header' />").appendTo($wrapper),
		$account = $("<div class='fav-header-col' style='width: 25%;'>Accounts</div>").appendTo($header),
		$availableFunds = $("<div class='fav-header-col text-right' style='width: 25%;'>Available Funds</div>").appendTo($header),
		$availableBalance = $("<div class='fav-header-col text-right' style='width: 25%;'>Available Balance</div>").appendTo($header),
		$balance = $("<div class='fav-header-col text-right' style='width: 25%;'>Balance</div>").appendTo($header),
		$container = $("<div class='fav-data' />").appendTo($wrapper),

		/* bind the save reorder function to the sortable */
		$ul = $("<ul />").appendTo($container).sortable({
			handle: ".fav-reorder",
			axis: 'y',
			containement: "parent",
			tolerance: "pointer",
			update: function(event, ui) {
				var result = $(this).sortable('toArray', {
					attribute: 'data-account'
				});
				saveReorderedAccounts(result)
			}
		}),

		$li, $row, $account, $link, $funds, $available, $balance, $date, $open, $actions, $close, $reorder, $download, $remove, $addRow, $addLink;

	/* check the settings for the ledger balance column */
	if (_settings[0].showavailablefunds == false && _settings[0].showavailablebalance == false) {
		$availableFunds.remove();
		$availableBalance.remove();
		$account.css({
			"width": "60%"
		});
		$balance.css({
			"width": "40%"
		});
		$.each(_widget.data, function() {

			/* build the list item */
			$li = $("<li data-account='" + this.number + "' />").appendTo($ul).on("mouseover mouseout", function() {
					if (!$(this).hasClass("show-actions")) {
						$(this).find(".fav-actions-show").toggle()
					}
				}),

				/* build the actions div */
				$actions = $("<div class='fav-actions' />").appendTo($li),
				$close = $("<span class='fav-actions-hide' title='Hide Actions'><i class='fa fa-ellipsis-v'></i></span>").appendTo($actions).on("click", function() {
					$(this).closest("li").removeClass("show-actions").find(".fav-actions-show").show()
				}),
				$download = $("<span title='Download A Report For This Account'><i class='fa fa-download'></i></span>").appendTo($actions).on("click", showFavouriteAccountsDownload),
				$remove = $("<span title='Remove This Account'><i class='fa fa-times'></i></span>").appendTo($actions).on("click", function() {
					var _li = $(this).closest("li"),
						_numb = _li.attr("data-account"),
						i = 0;
					while (i < _widget.data.length) {
						if (_widget.data[i].number == _numb) {
							_widget.data.splice(i, 1);
							_li.hide("fast", function() {
								$(this).remove()
							});
							$(this).closest("ul").sortable("refresh");
							store.set('saved_widget_data', widgetDataArray);
							break;
						}
						i += 1;
					}
				}),

				/* build the account data div */
				$row = $("<div class='fav-row fav-reorder' />").appendTo($li),
				$open = $("<div class='fav-actions-show' title='Show Actions'><i class='fa fa-ellipsis-v fa-fw'></i></div>").appendTo($row).on("click", function() {
					$(this).hide().closest("li").addClass("show-actions").siblings().removeClass("show-actions").find(".fav-actions-show").hide();
				}),
				/*$link = $("<a href='javascript:void(0)' />").appendTo($row).on("click", function() { alert("I would take you to the account details"); }),*/
				$account = $("<div class='fav-data-col' style='width: 60%;'><span class='fav-data-account'><a href='operating-accounts.html#detail'>" + this.name + "<br /><span style='font-size: 14px;'>" + this.number + " (" + this.currency + ")</span></a></span></div>").appendTo($row),
				$balance = $("<div class='fav-data-col text-right pos' style='width: 40%;'>" + this.balance + "</div>").appendTo($row);
		});
	} else if (_settings[0].showavailablefunds == true && _settings[0].showavailablebalance == true) {

		$.each(_widget.data, function() {

			/* build the li */
			$li = $("<li data-account='" + this.number + "' />").appendTo($ul).on("mouseover mouseout", function() {
					if (!$(this).hasClass("show-actions")) {
						$(this).find(".fav-actions-show").toggle()
					}
				}),

				$actions = $("<div class='fav-actions' />").appendTo($li),
				$close = $("<span class='fav-actions-hide' title='Hide Actions'><i class='fa fa-ellipsis-v'></i></span>").appendTo($actions).on("click", function() {
					$(this).closest("li").removeClass("show-actions").find(".fav-actions-show").show()
				}),
				/*$reorder = $("<span class='fav-reorder' title='Reorder This Account'><i class='fa fa-arrows-v'></i></span>").appendTo($actions),*/
				$download = $("<span title='Download A Report For This Account'><i class='fa fa-download'></i></span>").appendTo($actions).on("click", showFavouriteAccountsDownload),
				$remove = $("<span title='Remove This Account'><i class='fa fa-times'></i></span>").appendTo($actions).on("click", function() {
					var _li = $(this).closest("li"),
						_numb = _li.attr("data-account"),
						i = 0;
					while (i < _widget.data.length) {
						if (_widget.data[i].number == _numb) {
							_widget.data.splice(i, 1);
							_li.hide("fast", function() {
								$(this).remove()
							});
							$(this).closest("ul").sortable("refresh");
							store.set('saved_widget_data', widgetDataArray);
							break;
						}
						i += 1;
					}
				}),

				/* build the account data div */
				$row = $("<div class='fav-row fav-reorder' />").appendTo($li),
				$open = $("<div class='fav-actions-show' title='Show Actions'><i class='fa fa-ellipsis-v fa-fw'></i></div>").appendTo($row).on("click", function() {
					$(this).hide().closest("li").addClass("show-actions").siblings().removeClass("show-actions").find(".fav-actions-show").hide();
				}),
				/*$link = $("<a href='javascript:void(0)' />").appendTo($row).on("click", function() { alert("I would take you to the account details"); }),*/
				$account = $("<div class='fav-data-col' style='width: 25%;'><span class='fav-data-account'><a href='operating-accounts.html#detail'>" + this.name + "<br /><span style='font-size: 14px;'>" + this.number + " (" + this.currency + ")</span></a></span></div>").appendTo($row),
				$funds = $("<div class='fav-data-col text-right pos' style='width: 25%;'>" + this.funds + "</div>").appendTo($row),
				$available = $("<div class='fav-data-col text-right pos' style='width: 25%;'>" + this.available + "</div>").appendTo($row);
			$balance = $("<div class='fav-data-col text-right pos' style='width: 25%;'>" + this.balance + "</div>").appendTo($row);

		});
	} else if (_settings[0].showavailablefunds == true && _settings[0].showavailablebalance == false) {

		$availableBalance.remove();
		$account.css({
			"width": "40%"
		});
		$availableFunds.css({
			"width": "30%"
		});
		$balance.css({
			"width": "30%"
		});

		$.each(_widget.data, function() {

			/* build the li */
			$li = $("<li data-account='" + this.number + "' />").appendTo($ul).on("mouseover mouseout", function() {
					if (!$(this).hasClass("show-actions")) {
						$(this).find(".fav-actions-show").toggle()
					}
				}),

				$actions = $("<div class='fav-actions' />").appendTo($li),
				$close = $("<span class='fav-actions-hide' title='Hide Actions'><i class='fa fa-ellipsis-v'></i></span>").appendTo($actions).on("click", function() {
					$(this).closest("li").removeClass("show-actions").find(".fav-actions-show").show()
				}),
				/*$reorder = $("<span class='fav-reorder' title='Reorder This Account'><i class='fa fa-arrows-v'></i></span>").appendTo($actions),*/
				$download = $("<span title='Download A Report For This Account'><i class='fa fa-download'></i></span>").appendTo($actions).on("click", showFavouriteAccountsDownload),
				$remove = $("<span title='Remove This Account'><i class='fa fa-times'></i></span>").appendTo($actions).on("click", function() {
					var _li = $(this).closest("li"),
						_numb = _li.attr("data-account"),
						i = 0;
					while (i < _widget.data.length) {
						if (_widget.data[i].number == _numb) {
							_widget.data.splice(i, 1);
							_li.hide("fast", function() {
								$(this).remove()
							});
							$(this).closest("ul").sortable("refresh");
							store.set('saved_widget_data', widgetDataArray);
							break;
						}
						i += 1;
					}
				}),

				/* build the account data div */
				$row = $("<div class='fav-row fav-reorder' />").appendTo($li),
				$open = $("<div class='fav-actions-show' title='Show Actions'><i class='fa fa-ellipsis-v fa-fw'></i></div>").appendTo($row).on("click", function() {
					$(this).hide().closest("li").addClass("show-actions").siblings().removeClass("show-actions").find(".fav-actions-show").hide();
				}),
				/*$link = $("<a href='javascript:void(0)' />").appendTo($row).on("click", function() { alert("I would take you to the account details"); }),*/
				$account = $("<div class='fav-data-col' style='width: 40%;'><span class='fav-data-account'><a href='operating-accounts.html#detail'>" + this.name + "<br /><span style='font-size: 14px;'>" + this.number + " (" + this.currency + ")</span></a></span></div>").appendTo($row),
				$funds = $("<div class='fav-data-col text-right pos' style='width: 30%;'>" + this.funds + "</div>").appendTo($row),
				$balance = $("<div class='fav-data-col text-right pos' style='width: 30%;'>" + this.balance + "</div>").appendTo($row);

		});
	} else if (_settings[0].showavailablefunds == false && _settings[0].showavailablebalance == true) {

		$availableFunds.remove();
		$account.css({
			"width": "40%"
		});
		$availableBalance.css({
			"width": "30%"
		});
		$balance.css({
			"width": "30%"
		});

		$.each(_widget.data, function() {

			/* build the li */
			$li = $("<li data-account='" + this.number + "' />").appendTo($ul).on("mouseover mouseout", function() {
					if (!$(this).hasClass("show-actions")) {
						$(this).find(".fav-actions-show").toggle()
					}
				}),


				$actions = $("<div class='fav-actions' />").appendTo($li),
				$close = $("<span class='fav-actions-hide' title='Hide Actions'><i class='fa fa-ellipsis-v'></i></span>").appendTo($actions).on("click", function() {
					$(this).closest("li").removeClass("show-actions").find(".fav-actions-show").show()
				}),
				/*$reorder = $("<span class='fav-reorder' title='Reorder This Account'><i class='fa fa-arrows-v'></i></span>").appendTo($actions),*/
				$download = $("<span title='Download A Report For This Account'><i class='fa fa-download'></i></span>").appendTo($actions).on("click", showFavouriteAccountsDownload),
				$remove = $("<span title='Remove This Account'><i class='fa fa-times'></i></span>").appendTo($actions).on("click", function() {
					var _li = $(this).closest("li"),
						_numb = _li.attr("data-account"),
						i = 0;
					while (i < _widget.data.length) {
						if (_widget.data[i].number == _numb) {
							_widget.data.splice(i, 1);
							_li.hide("fast", function() {
								$(this).remove()
							});
							$(this).closest("ul").sortable("refresh");
							store.set('saved_widget_data', widgetDataArray);
							break;
						}
						i += 1;
					}
				}),


				/* build the account data div */
				$row = $("<div class='fav-row fav-reorder' />").appendTo($li),
				$open = $("<div class='fav-actions-show' title='Show Actions'><i class='fa fa-ellipsis-v fa-fw'></i></div>").appendTo($row).on("click", function() {
					$(this).hide().closest("li").addClass("show-actions").siblings().removeClass("show-actions").find(".fav-actions-show").hide();
				}),
				/*$link = $("<a href='javascript:void(0)' />").appendTo($row).on("click", function() { alert("I would take you to the account details"); }),*/
				$account = $("<div class='fav-data-col' style='width: 40%;'><span class='fav-data-account'><a href='operating-accounts.html#detail'>" + this.name + "<br /><span style='font-size: 14px;'>" + this.number + " (" + this.currency + ")</span></a></span></div>").appendTo($row),
				$available = $("<div class='fav-data-col text-right pos' style='width: 30%;'>" + this.available + "</div>").appendTo($row),
				$balance = $("<div class='fav-data-col text-right pos' style='width: 30%;'>" + this.balance + "</div>").appendTo($row);

		});
	}

	/* make the add accounts link */
	$addRow = $("<div class='text-center' style='padding: 20px 0;' />").appendTo($container),
		$addRowLink = $("<a href='#AddAccounts' data-action='" + _widget.id + "' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Accounts</a>").appendTo($addRow).on("click", function(e) {
			e.preventDefault();
			showAddAccounts($(e.target), _widget);
			$("#AddAccounts input").first().focus();
		});

	/* return the results. if rebuild is true then just redraw the existing widget, otherwise populate a newly added widget */
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($wrapper);
	} else {
		return $wrapper;
	}
}


/* net positions widget */
var net_position_data = {
	reference_currency: "USD",
	data: [{
		company: "ABC Company",
		country: "New Zealand",
		type: "Deposits",
		number: 8,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "AUD",
		total: 32725.29,
		basetotal: 35000.00
	}, {
		company: "ABC Company",
		country: "New Zealand",
		type: "Deposits",
		number: 8,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "NZD",
		total: 32725.29,
		basetotal: 41000.00
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Deposits",
		number: 8,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "AUD",
		total: 32725.29,
		basetotal: 34210.55
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Deposits",
		number: 3,
		totalnumber: 8,
		fxrate: 1.2311,
		currency: "SGD",
		total: -32987.79,
		basetotal: -25000.00
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Deposits",
		number: 2,
		totalnumber: 8,
		fxrate: 1,
		currency: "USD",
		total: 61004.95,
		basetotal: 61004.95
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Deposits",
		number: 2,
		totalnumber: 2,
		fxrate: 1,
		currency: "USD",
		total: 61004.95,
		basetotal: 61004.95
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 4,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "AUD",
		total: 32725.13,
		basetotal: 32725.50
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 4,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "AUD",
		total: 10509.13,
		basetotal: 11200.00
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 9,
		totalnumber: 12,
		fxrate: 90,
		currency: "JPY",
		total: -19043.53,
		basetotal: -1750000
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 4,
		totalnumber: 8,
		fxrate: 1.2311,
		currency: "SGD",
		total: 26856.12,
		basetotal: 21200.50
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 4,
		totalnumber: 5,
		fxrate: 1.2311,
		currency: "SGD",
		total: 26856.12,
		basetotal: 35000.00
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 4,
		totalnumber: 4,
		fxrate: 1.2311,
		currency: "SGD",
		total: 26856.12,
		basetotal: 35000.00
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 1,
		totalnumber: 8,
		fxrate: 1,
		currency: "USD",
		total: 66791.42,
		basetotal: 66791.42
	}, {
		company: "ABC Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 1,
		totalnumber: 1,
		fxrate: 1,
		currency: "USD",
		total: -66791.42,
		basetotal: -66791.42
	}, {
		company: "CDX Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 1,
		totalnumber: 8,
		fxrate: 1,
		currency: "USD",
		total: -66791.42,
		basetotal: -66791.42
	}, {
		company: "CDX Company",
		country: "Singapore",
		type: "Operating Accounts",
		number: 4,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "AUD",
		total: 10509.13,
		basetotal: 12100.00
	}, {
		company: "CDX Company",
		country: "Singapore",
		type: "Deposits",
		number: 2,
		totalnumber: 8,
		fxrate: 1,
		currency: "USD",
		total: 61004.95,
		basetotal: 61004.95
	}, {
		company: "XYZ Company",
		country: "Australia",
		type: "Operating Accounts",
		number: 6,
		totalnumber: 8,
		fxrate: 0.9311,
		currency: "AUD",
		total: 92921.53,
		basetotal: 105200.21
	}, {
		company: "XYZ Company",
		country: "France",
		type: "Operating Accounts",
		number: 7,
		totalnumber: 8,
		fxrate: 1.6311,
		currency: "EUR",
		total: -13413.65,
		basetotal: -8212.01
	}, {
		company: "XYZ Company",
		country: "Australia",
		type: "Operating Accounts",
		number: 6,
		totalnumber: 6,
		fxrate: 0.9311,
		currency: "AUD",
		total: 92921.53,
		basetotal: 105210.25
	}, {
		company: "XYZ Company",
		country: "France",
		type: "Operating Accounts",
		number: 7,
		totalnumber: 7,
		fxrate: 1.6311,
		currency: "EUR",
		total: -13413.65,
		basetotal: -8250.00
	}, {
		company: "XYZ Company",
		country: "Australia",
		type: "Operating Accounts",
		number: 6,
		totalnumber: 6,
		fxrate: 0.9311,
		currency: "AUD",
		total: 92921.53,
		basetotal: 105000.00
	}, {
		company: "XYZ Company",
		country: "France",
		type: "Operating Accounts",
		number: 7,
		totalnumber: 8,
		fxrate: 1.6311,
		currency: "EUR",
		total: -13413.65,
		basetotal: -8900.00
	}, {
		company: "MNO Company",
		country: "New Zealand",
		type: "Deposits",
		number: 3,
		totalnumber: 8,
		fxrate: 1.2311,
		currency: "USD",
		total: -32987.79,
		basetotal: -32987.79
	}, {
		company: "MNO Company",
		country: "New Zealand",
		type: "Operating Accounts",
		number: 9,
		totalnumber: 9,
		fxrate: 1.2311,
		currency: "SGD",
		total: -19043.53,
		basetotal: -25000.00
	}, {
		company: "CYC Company",
		country: "India",
		type: "Deposits",
		number: 4,
		totalnumber: 5,
		fxrate: 0.0150,
		currency: "INR",
		total: -300000.00,
		basetotal: 3000.00
	}, {
		company: "CYC Company",
		country: "India",
		type: "Operating Accounts",
		number: 10,
		totalnumber: 15,
		fxrate: 0.0150,
		currency: "INR",
		total: 1500000.00,
		basetotal: -150000.00
	}, {
		company: "CYC Company",
		country: "Indonesia",
		type: "Deposits",
		number: 2,
		totalnumber: 3,
		fxrate: 0.000073,
		currency: "IDR",
		total: 230000.00,
		basetotal: -23000.00
	}, {
		company: "CYC Company",
		country: "Indonesia",
		type: "Opearing Accounts",
		number: 4,
		totalnumber: 6,
		fxrate: 0.000073,
		currency: "IDR",
		total: 135000.00,
		basetotal: 135000.00
	}]
}

function buildNetPosition(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length || _widget.settings == "undefined") {
		_widget.settings = [{
			chartOptions: {
				chartType: "waterfall",
				showLabels: true,
				groupBy: "country",
				refCCY: "Default"
			},
			report: "Deposit Summary",
			format: "CSV",
			date: "Yesterday",
			remember: false
		}];
	}

	var $content = $("<div style='width:100%; height:100%;'></div>");
	var $highchart = $("<div class='highchart' id='HC_" + id + "' \>").appendTo($content);
	var $netposition = $("<div class='sum-total'><div class='sum-label'>Total Cash Position</div><div class='sum-amount'></div><i class='fa fa-exclamation-triangle accounts-missing' title='Some account data was not retrieved'></i></div>").appendTo($content);
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($content);
		finaliseNetPosition(id, _widget.settings[0]);
	} else {
		setTimeout(function() {
			finaliseNetPosition(id, _widget.settings[0]);
		}, 250);
		return $content;
	}
}

function finaliseNetPosition(id, _settings) {

	var anz_colours = ["#007DBA", "#5BC6E8", "#747679", "#C6DFEA", "#00C6D7", "#B9C9D0", "#589199", "#394A58", "#AA9C8F", "#DF7A00", "#B9CCC3", "#D3CD8B", "#EDE8C4", "#FDC82F"],
		chart_data = [],
		net_position = 0,
		num_accounts = 0,
		tot_num_accounts = 0;
	if (_settings.chartOptions.refCCY != "Default") {
		net_position_data.reference_currency = _settings.chartOptions.refCCY;
	} else {
		net_position_data.reference_currency = "USD";
	}
	Highcharts.setOptions({
		chart: {
			style: {
				fontFamily: 'Myriad Pro, Helvetica, Arial, sans-serif;'
			}
		}
	});

	//Generic Tooltip Function
	var generate_tooltip = function() {
		var tooltipstring = "<span class='net-pos-tooltip'><span class='tooltip-header'>" + this.point.name + " (" + net_position_data.reference_currency + ")</span>"
		if (this.point.opacc > 0 && this.point.depacc > 0) tooltipstring += "<div class='tooltip-section'><span class='tooltip-label'>Total:</span><span class='tooltip-amt'>" + Highcharts.numberFormat(this.point.y, 2, ".", ",") + "</span></div><div class='tooltip-seperator'></div>";
		if (this.point.opacc > 0) tooltipstring += "<div class='tooltip-section'><span class='tooltip-label'>" + this.point.opacc + " Accounts</span><span class='tooltip-amt'>" + Highcharts.numberFormat(this.point.opamt, 2, ".", ",") + "</span></div>";
		if (this.point.depacc > 0) tooltipstring += "<div class='tooltip-section'><span class='tooltip-label'>" + this.point.depacc + " Deposits</span><span class='tooltip-amt'>" + Highcharts.numberFormat(this.point.depamt, 2, ".", ",") + "</span></div>";

		if (this.point.type == "currency" && this.point.name != "Net Position") {
			tooltipstring += "<span class='tooltip-cur-sec'><div class='tooltip-seperator'></div>" + "<div class='tooltip-section'><span class='tooltip-label'>Rate:</span><span class='tooltip-amt'>" + this.point.fxrate + "</span></div>";
			tooltipstring += "<div class='tooltip-section'><span class='tooltip-label'>Total " + this.point.name + "</span><span class='tooltip-amt'>" + Highcharts.numberFormat(this.point.baseamt, 2, ".", ",") + "</span></div></span>";
		}

		if (this.point.totalacc > this.point.numacc) tooltipstring += "<div class='tooltip-seperator'></div><span class='tooltip-acc-ret'>" + (this.point.totalacc - this.point.numacc) + " of " + this.point.totalacc + " balances not retrieved</span>";
		return tooltipstring + "</span>";
	}

	/* WATERFALL WITH DATA */
	if (_settings.chartOptions.chartType == "waterfall") {
		var np_opamt = 0,
			np_opacc = 0,
			np_depacc = 0,
			np_depamt = 0;


		$.each(net_position_data.data, function(index) {

			//group by options
			var filterOption, cd_index, _groupBy = _settings.chartOptions.groupBy;
			if (_groupBy == "account_type") {
				filterOption = this.type
			} else if (_groupBy == "country") {
				filterOption = this.country
			} else if (_groupBy == "currency") {
				filterOption = this.currency
			} else if (_groupBy == "company") {
				filterOption = this.company
			}

			if (!filterOption || filterOption == "undefined") {
				filterOption = this.country;
			}

			var item = $.grep(chart_data, function(e, i) {
				if (e.name == filterOption) {
					cd_index = i;
					return true;
				}
			});

			if (item.length == 0) {
				cd_index = chart_data.push({
					type: _settings.chartOptions.groupBy,
					name: filterOption,
					fxrate: net_position_data.data[index].fxrate,
					numacc: 0,
					totalacc: 0,
					baseamt: 0,
					depamt: 0,
					depacc: 0,
					opamt: 0,
					opacc: 0,
					y: 0,
					color: anz_colours[chart_data.length % anz_colours.length]
				}) - 1;
			}

			chart_data[cd_index].y += this.total;
			chart_data[cd_index].baseamt += this.basetotal;
			chart_data[cd_index].numacc += this.number;
			chart_data[cd_index].totalacc += this.totalnumber;
			if (this.type == "Operating Accounts") {
				chart_data[cd_index].opamt += this.total;
				chart_data[cd_index].opacc += this.number;
				np_opamt += this.total;
				np_opacc += this.number;
			}
			if (this.type == "Deposits") {
				chart_data[cd_index].depamt += this.total;
				chart_data[cd_index].depacc += this.number;
				np_depamt += this.total;
				np_depacc += this.number;
			}
			num_accounts += this.number;
			tot_num_accounts += this.totalnumber;
			net_position += this.total;

		});

		//sort alphabetically
		chart_data.sort(function(a, b) {
			var aName = a.name.toLowerCase();
			var bName = b.name.toLowerCase();
			return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
		});

		//add 'Net Position' category to end of chart.
		chart_data.push({
			name: "Net Position",
			numacc: num_accounts,
			totalacc: tot_num_accounts,
			depamt: np_depamt,
			depacc: np_depacc,
			opamt: np_opamt,
			opacc: np_opacc,
			isSum: true,
			color: "#004165"
		});



		$("#HC_" + id).highcharts({
			chart: {
				type: 'waterfall'
			},
			title: {
				text: ''
			},
			xAxis: {
				type: 'category'
			},
			yAxis: {
				gridLineColor: "#ebebeb",
				title: {
					enabled: false
				}
			},
			legend: {
				enabled: false
			},
			plotOptions: {
				series: {
					borderWidth: 0
				}
			},
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			series: [{
				name: "Net Position",
				upColor: Highcharts.getOptions().colors[2],
				color: Highcharts.getOptions().colors[3],
				data: chart_data,
				animation: {
					duration: 250
				},
				dataLabels: {
					enabled: false,
					formatter: function() {
						return Highcharts.numberFormat(this.y / 1000, 0, ',') + 'k';
					},
					style: {
						color: '#FFFFFF',
						fontWeight: 'bold',
						textShadow: '0px 0px 3px black'
					}
				},
				pointPadding: 0
			}],
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	} else if (_settings.chartOptions.chartType == "pie") {

		$.each(net_position_data.data, function(index) {
			var filterOption, cd_index;
			if (_settings.chartOptions.groupBy == "account_type") filterOption = net_position_data.data[index].type;
			if (_settings.chartOptions.groupBy == "country") filterOption = net_position_data.data[index].country;
			if (_settings.chartOptions.groupBy == "currency") filterOption = net_position_data.data[index].currency;
			if (_settings.chartOptions.groupBy == "company") filterOption = net_position_data.data[index].company;

			if (!filterOption) filterOption = net_position_data.data[index].country;

			var item = $.grep(chart_data, function(e, i) {
				if (e.name == filterOption) {
					cd_index = i;
					return true;
				}
			});

			if (item.length == 0) {
				cd_index = chart_data.push({
					type: _settings.chartOptions.groupBy,
					name: filterOption,
					fxrate: net_position_data.data[index].fxrate,
					numacc: 0,
					totalacc: 0,
					baseamt: 0,
					depamt: 0,
					depacc: 0,
					opamt: 0,
					opacc: 0,
					y: 0,
					negative: false,
					sign: "",
					color: anz_colours[chart_data.length % anz_colours.length]
				}) - 1;
			}

			chart_data[cd_index].y += net_position_data.data[index].total;
			chart_data[cd_index].baseamt += net_position_data.data[index].basetotal;
			chart_data[cd_index].numacc += net_position_data.data[index].number;
			if (net_position_data.data[index].type == "Operating Accounts") {
				chart_data[cd_index].opamt += net_position_data.data[index].total;
				chart_data[cd_index].opacc += net_position_data.data[index].number;
			}
			if (net_position_data.data[index].type == "Deposits") {
				chart_data[cd_index].depamt += net_position_data.data[index].total;
				chart_data[cd_index].depacc += net_position_data.data[index].number;
			}
			chart_data[cd_index].totalacc += net_position_data.data[index].totalnumber;
			num_accounts += net_position_data.data[index].number;
			tot_num_accounts += net_position_data.data[index].totalnumber;
			net_position += net_position_data.data[index].total;

		});

		var error_colours = ["#CA002A", "#FF1100", "#A12830", "#DB1F2A", "#DB4E4E"];
		//invert negative amounts so they show properly

		$.each(chart_data, function(i, d) {
			if (d.y < 0) {
				chart_data[i].y = -chart_data[i].y;
				chart_data[i].color = error_colours[i % error_colours.length];
				chart_data[i].negative = true;
				chart_data[i].sign = "-"
			}
		});

		chart_data.sort(function(a, b) {
			if (a.negative != b.negative) return a.negative ? 1 : -1;
			if (a.negative) return ((a.y < b.y) ? -1 : ((a.y > b.y) ? 1 : 0));
			return ((a.y < b.y) ? 1 : ((a.y > b.y) ? -1 : 0));
		});

		$("#HC_" + id).highcharts({
			chart: {
				type: "pie",
				plotBackgroundColor: null,
				plotBorderWidth: 0,
				plotShadow: false
			},
			title: {
				text: false,
				align: 'center',
				verticalAlign: 'middle',
				style: {
					color: "#99b3c1",
					fontSize: "14px"
				},
				y: 0
			},
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			exporting: {
				enabled: true
			},
			plotOptions: {
				pie: {
					shadow: false,
					borderWidth: 1,
					size: '80%',
					showInLegend: false,
					innerSize: '70%',
					data: chart_data
				}
			},
			series: [{
				type: 'pie',
				name: 'Net Position',
				animation: {
					duration: 250
				},
				dataLabels: {
					enabled: true,
					distance: 10,
					softConnector: false,
					connectorWidth: 1,
					verticalAlign: 'top',
					style: {
						fontWeight: 'bold',
						color: 'black'
					},
					formatter: function() {
						return this.point.name + " " + this.point.sign + Highcharts.numberFormat(this.y / 1000, 0, ',') + 'k'
					}
				}
			}],
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	} else if (_settings.chartOptions.chartType == "bar") {

		var categories = [];

		//sort - this needs to be from the inward data because of the way the bar chart is created.
		var np_data = net_position_data.data;

		np_data.sort(function(a, b) {
			var aName, bName;
			if (_settings.chartOptions.groupBy == "country") {
				aName = a.country;
				bName = b.country;
			}
			if (_settings.chartOptions.groupBy == "currency") {
				aName = a.currency;
				bName = b.currency;
			}
			if (_settings.chartOptions.groupBy == "company") {
				aName = a.company;
				bName = b.company;
			}
			return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
		});

		$.each(np_data, function(index) {
			var filterOption, cd_index;
			if (_settings.chartOptions.groupBy == "account_type") filterOption = net_position_data.data[index].type;
			if (_settings.chartOptions.groupBy == "country") filterOption = net_position_data.data[index].country;
			if (_settings.chartOptions.groupBy == "currency") filterOption = net_position_data.data[index].currency;
			if (_settings.chartOptions.groupBy == "company") filterOption = net_position_data.data[index].company;

			if (!filterOption) filterOption = net_position_data.data[index].country;

			var item = $.grep(chart_data, function(e, i) {
				if (e.name == filterOption) {
					cd_index = i;
					return true;
				}
			});

			if (item.length == 0) { //populate the initial chart data where option does not exist in chart_data array

				//append null onto the end of existing chart_data[x].data items
				$.each(chart_data, function(i, d) {
					chart_data[i].data.push(null);
				});

				//create chart data (and prepend null filled array to start of chart_data[x].data)
				cd_index = chart_data.push({
					name: filterOption,
					index: chart_data.length,
					data: Array.apply(null, new Array(chart_data.length)).map(function() {
						return null;
					}).concat({
						type: _settings.chartOptions.groupBy,
						name: filterOption,
						y: 0,
						numacc: 0,
						totalacc: 0,
						baseamt: 0,
						depamt: 0,
						depacc: 0,
						opamt: 0,
						opacc: 0,
						fxrate: net_position_data.data[index].fxrate
					}),
					color: anz_colours[chart_data.length % anz_colours.length]
				}) - 1;


			}

			//update running total for amounts and number of accounts
			chart_data[cd_index].data[chart_data[cd_index].index].y += net_position_data.data[index].total;
			chart_data[cd_index].data[chart_data[cd_index].index].baseamt += net_position_data.data[index].basetotal;
			chart_data[cd_index].data[chart_data[cd_index].index].numacc += net_position_data.data[index].number;
			chart_data[cd_index].data[chart_data[cd_index].index].totalacc += net_position_data.data[index].totalnumber;
			if (net_position_data.data[index].type == "Operating Accounts") {
				chart_data[cd_index].data[chart_data[cd_index].index].opamt += net_position_data.data[index].total;
				chart_data[cd_index].data[chart_data[cd_index].index].opacc += net_position_data.data[index].number;
			}
			if (net_position_data.data[index].type == "Deposits") {
				chart_data[cd_index].data[chart_data[cd_index].index].depamt += net_position_data.data[index].total;
				chart_data[cd_index].data[chart_data[cd_index].index].depacc += net_position_data.data[index].number;
			}
			num_accounts += net_position_data.data[index].number;
			tot_num_accounts += net_position_data.data[index].totalnumber;
			net_position += net_position_data.data[index].total;
		});



		//fill categories from chart_data
		$.each(chart_data, function(i, d) {
			categories.push(d.name);
		});

		$("#HC_" + id).highcharts({
			chart: {
				type: 'column'
			},
			xAxis: {
				categories: categories,
				title: ''
			},
			legend: {
				enabled: false
			},
			yAxis: {
				gridLineColor: "#ebebeb",
				title: {
					enabled: false
				},
				labels: {
					overflow: 'justify'
				}
			},
			plotOptions: {
				column: {
					borderWidth: 0,
					stacking: 'normal',
					animation: {
						duration: 250
					},
					groupPadding: 0.01,
					dataLabels: {
						enabled: false,
						formatter: function() {
							if (this.percentage > 0) return Highcharts.numberFormat(this.y / 1000, 0, ',') + 'k';
						},
						style: {
							color: '#FFF',
							fontWeight: 'bold',
							textShadow: '0px 0px 5px #000'
						}
					},
					pointPadding: 0
				}
			},
			title: {
				text: ''
			},
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			series: chart_data,
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	}

	//set the net position in the widget
	$("#" + id).find(".sum-total").show().find(".sum-amount").html(net_position_data.reference_currency + " " + Highcharts.numberFormat(net_position, 2, ".", ","));
	if (tot_num_accounts > num_accounts) $("#" + id).find(".accounts-missing").css({
		"display": "inline-block"
	}).attr("title", num_accounts + " of " + tot_num_accounts + " accounts retrieved.");
}

function showNetPositionSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);


	/* function to save widget settings */
	function updateMySettings(_dialog) {
		_widget.settings = [{
			chartOptions: {
				chartType: $charttypeElement.val(),
				showLables: false,
				groupBy: $groupByElement.val(),
				refCCY: $refByElement.val()
			},
			report: $typeElement.val(),
			format: $formatElement.val(),
			remember: $rememberElement.prop("checked")
		}];
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		buildNetPosition(id, true);
	}

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-accounts data-form' />"),


		/* build the view settings */
		$viewSectionHeading = $("<div class='section-heading'>View Settings</div>").appendTo($settings),
		$downloadSection = $("<div class='form-section' />").appendTo($settings),
		/* Chart Type Row */
		$charttypeRow = $("<div class='row' />").appendTo($downloadSection),
		$charttypeLabelCol = $("<div class='label-column' />").appendTo($charttypeRow),
		$charttypeLabel = $("<label>Chart Type</label>").appendTo($charttypeLabelCol),
		$charttypeDataCol = $("<div class='data-column' />").appendTo($charttypeRow),
		$charttypeCustomSelect = $("<div class='custom-select' />").appendTo($charttypeDataCol),
		$charttypeElement = $("<select id='" + _widget.id + "-type'><option value='bar'>Bar</option><option value='pie'>Pie</option><option value='waterfall'>Waterfall</option></select>").appendTo($charttypeCustomSelect).val(_widget.settings[0].chartOptions.chartType),
		/* Group Option */
		$groupByRow = $("<div class='row' />").appendTo($downloadSection),
		$groupByLabelCol = $("<div class='label-column' />").appendTo($groupByRow),
		$groupByLabel = $("<label>Group By</label>").appendTo($groupByLabelCol),
		$groupByDataCol = $("<div class='data-column' />").appendTo($groupByRow),
		$groupByCustomSelect = $("<div class='custom-select' />").appendTo($groupByDataCol),
		$groupByElement = $("<select id='" + _widget.id + "-type'><option value='account_type'>Account Type</option><option value='company'>Company</option><option value='country'>Country</option><option value='currency'>Currency</option></select>").appendTo($groupByCustomSelect).val(_widget.settings[0].chartOptions.groupBy)


	/* Reference Currency Option */
	$refByRow = $("<div class='row' />").appendTo($downloadSection),
		$refByLabelCol = $("<div class='label-column' />").appendTo($refByRow),
		$refByLabel = $("<label>Reference Currency</label>").appendTo($refByLabelCol),
		$refByDataCol = $("<div class='data-column' />").appendTo($refByRow),
		$refByCustomSelect = $("<div class='custom-select' />").appendTo($refByDataCol),
		$refByElement = $("<select id='" + _widget.id + "-type'><option value='Default'>Default</option><option value='AUD'>AUD</option><option value='EUR'>EUR</option><option value='USD'>USD</option></select>").appendTo($refByCustomSelect).val(_widget.settings[0].chartOptions.refCCY)


	/* build the download settings */
	$downloadSectionHeading = $("<div class='section-heading'>Download Settings</div>").appendTo($settings),
		$downloadSection = $("<div class='form-section' />").appendTo($settings),
		$typeRow = $("<div class='row' />").appendTo($downloadSection),
		$typeLabelCol = $("<div class='label-column' />").appendTo($typeRow),
		$typeLabel = $("<label>Report Type</label>").appendTo($typeLabelCol),
		$typeDataCol = $("<div class='data-column' />").appendTo($typeRow),
		$typeDataCustomSelect = $("<div class='custom-select' />").appendTo($typeDataCol),
		$typeElement = $("<select id='" + _widget.id + "-type'><option value='Net Position'>Net Position</option></select>").appendTo($typeDataCustomSelect).val(_widget.settings[0].report),
		$formatRow = $("<div class='row' />").appendTo($downloadSection),
		$formatLabelCol = $("<div class='label-column' />").appendTo($formatRow),
		$formatLabel = $("<label>Report Format</label>").appendTo($formatLabelCol),
		$formatDataCol = $("<div class='data-column' />").appendTo($formatRow),
		$formatDataCustomSelect = $("<div class='custom-select' />").appendTo($formatDataCol),
		$formatElement = $("<select id='" + _widget.id + "-format'><option value='CSV'>CSV</option><option value='JPG'>JPG</option></select>").appendTo($formatDataCustomSelect).val(_widget.settings[0].format),


		$rememberRow = $("<div class='row' />").appendTo($downloadSection),
		$rememberLabelCol = $("<div class='label-column' />").appendTo($rememberRow),
		$rememberLabel = $("<label></label>").appendTo($rememberLabelCol),
		$rememberDataCol = $("<div class='data-column' />").appendTo($rememberRow),
		$rememberElement = $("<input type='checkbox' id='" + _widget.id + "-remember' />").appendTo($rememberDataCol).prop("checked", _widget.settings[0].remember).on("click", function() {
			var _note = $(this).closest("div.row").find("[data-note='remember']");
			if ($(this).prop("checked")) {
				_note.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
			} else {
				_note.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
			}
		}),
		$rememberLabelDesc = $("<label class='desc' for='" + _widget.id + "-remember' title=''>Remember This</label>").appendTo($rememberDataCol),
		$noteText = $("<div class='data-note' data-note='remember'></div>").appendTo($rememberDataCol);


	if ($rememberElement.prop("checked")) {
		$noteText.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
	} else {
		$noteText.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
	}


	/* open the settings dialog and load the form from the $settings variable */

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Net Position Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showNetPositionDownload(e) {

	e.preventDefault();

	/* set the id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id),

		/* set _settings to the widget settings in the widgetDataArray */
		_settings = _widget.settings;

	/* check if the remember settings is enabled */
	if (_settings[0].remember == true) {
		var export_type;
		if (_widget.settings[0].format == "PDF") export_type = "application/pdf";
		if (_widget.settings[0].format == "PNG") export_type = "image/png";
		if (_widget.settings[0].format == "JPG") export_type = "image/jpeg";
		if (_widget.settings[0].format == "CSV") {
			alert("Here is your " + _widget.settings[0].report + " " + _widget.settings[0].format + ".");
			return;
		}

		$("#" + id).find(".highchart").highcharts().exportChart({
			type: export_type,
			filename: 'Net Position'
		});

	} else {

		/* build the download form */
		var $settings = $("<div class='widget-accounts data-form' />"),
			$downloadSection = $("<div class='form-section' />").appendTo($settings),
			$typeRow = $("<div class='row' />").appendTo($downloadSection),
			$typeLabelCol = $("<div class='label-column' />").appendTo($typeRow),
			$typeLabel = $("<label>Report Type</label>").appendTo($typeLabelCol),
			$typeDataCol = $("<div class='data-column' />").appendTo($typeRow),
			$typeElement = $("<div class='custom-select'><select id='" + _widget.id + "-type'><option value='Net Position'>Net Position</option></select></div>").appendTo($typeDataCol).val("Net Position"),
			$formatRow = $("<div class='row' />").appendTo($downloadSection),
			$formatLabelCol = $("<div class='label-column' />").appendTo($formatRow),
			$formatLabel = $("<label>Report Format</label>").appendTo($formatLabelCol),
			$formatDataCol = $("<div class='data-column' />").appendTo($formatRow),
			$formatElement = $("<div class='custom-select'><select id='" + _widget.id + "-format'><option value='CSV'>CSV</option><option value='JPG'>JPG</option></select></div>").appendTo($formatDataCol).val(_widget.settings[0].format),
			$rememberRow = $("<div class='row' />").appendTo($downloadSection),
			$rememberLabelCol = $("<div class='label-column' />").appendTo($rememberRow),
			$rememberLabel = $("<label></label>").appendTo($rememberLabelCol),
			$rememberDataCol = $("<div class='data-column' />").appendTo($rememberRow);
		var $rememberElement = $("<input type='checkbox' id='" + _widget.id + "-remember' />").appendTo($rememberDataCol).prop("checked", _widget.settings[0].remember).on("click", function() {
				var _note = $(this).closest("div.row").next("div.row").find("[data-note='remember']");
				if ($(this).prop("checked")) {
					_note.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
				} else {
					_note.text("When 'Remember This' is checked the specified report will download immediately.")
				}
			}),
			$rememberLabelDesc = $("<label class='desc' for='" + _widget.id + "-remember'>Remember This</label>").appendTo($rememberDataCol),
			$noteRow = $("<div class='row' />").appendTo($downloadSection),
			$noteDataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($noteRow),
			$noteText = $("<div class='data-text' data-note='remember'></div>").appendTo($noteDataCol);
		if ($rememberElement.prop("checked")) {
			$noteText.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
		} else {
			$noteText.text("When 'Remember This' is checked the specified report will download immediately.")
		}

		/* the download report function */
		function downloadReport(_dialog) {
			_widget.settings[0].report = $typeElement.val();
			_widget.settings[0].format = $formatElement.val();
			_widget.settings[0].remember = $rememberElement.prop("checked");
			store.set('saved_widget_data', widgetDataArray);

			var export_type;
			if ($formatElement.val() == "PDF") export_type = "application/pdf";
			if ($formatElement.val() == "PNG") export_type = "image/png";
			if ($formatElement.val() == "JPG") export_type = "image/jpeg";

			if ($formatElement.val() == "CSV") {
				alert("Here is your " + _widget.settings[0].report + " " + _widget.settings[0].format + ".");
				dialogHider(_dialog);
				return;
			}

			$("#" + id).find(".highchart").highcharts().exportChart({
				type: export_type,
				filename: 'Net Position'
			});
			//alert("Here is your "+_widget.settings[0].report+" "+_widget.settings[0].format+".");
			dialogHider(_dialog);
		}

		/* open the download dialog */
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: _widget.id + "Download",
			title: "Download",
			size: "small",
			icon: "<i class='fa fa-download'></i>",
			content: $settings,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						downloadReport(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}
}


/* deposit summary widget */
var deposit_accounts = {
	data_truncated: true,
	deposit_data: [{
		name: "One MNTH Rolling",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "100.20",
		maturity_amt: "2,100.20",
		deposit_amt: "2,000.00",
		rate: "2.5%",
		term: "90 days"
	}, {
		name: "Loan Repayment Account",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "50.50",
		maturity_amt: "1,050.50",
		deposit_amt: "1,000.00",
		rate: "3.5%",
		term: "30 days"
	}, {
		name: "Term Loan",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "50.50",
		maturity_amt: "1,050.50",
		deposit_amt: "1,000.00",
		rate: "3.5%",
		term: "30 days"
	}, {
		name: "Classic Loan",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "50.50",
		maturity_amt: "1,050.50",
		deposit_amt: "1,000.00",
		rate: "3.5%",
		term: "30 days"
	}, {
		name: "One MNTH Rolling",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "USD",
		accrued_interest: "150.50",
		maturity_amt: "1,226,050.50",
		deposit_amt: "1,000.00",
		rate: "3.5%",
		term: "30 days"
	}, {
		name: "Term Loan",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "USD",
		accrued_interest: "150.50",
		maturity_amt: "1,226,050.50",
		deposit_amt: "1,000.00",
		rate: "3.5%",
		term: "30 days"
	}, {
		name: "One MNTH Rolling",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "USD",
		accrued_interest: "150.50",
		maturity_amt: "1,226,050.50",
		deposit_amt: "1,000.00",
		rate: "3.5%",
		term: "30 days"
	}, {
		name: "Term Loan",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "5,245,199.24",
		maturity_amt: "110,500,050.99",
		deposit_amt: "100,000,000.00",
		rate: "2.1251%",
		term: "1 year"
	}, {
		name: "One MNTH Rolling",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "5,245,199.24",
		maturity_amt: "110,500,050.99",
		deposit_amt: "100,000,000.00",
		rate: "2.1251%",
		term: "1 year"
	}, {
		name: "One MNTH Rolling",
		acct_number: "1001010101",
		start_date: smartDates("randompast"),
		maturity_date: smartDates("randomfuture"),
		currency: "AUD",
		accrued_interest: "5,245,199.24",
		maturity_amt: "110,500,050.99",
		deposit_amt: "100,000,000.00",
		rate: "2.1251%",
		term: "1 year"
	}]
};

function showDepositSummaryDownload(e) {

	e.preventDefault();

	/* set the id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id),

		/* set _settings to the widget settings in the widgetDataArray */
		_settings = _widget.settings;

	/* check if the remember settings is enabled */
	if (_settings[0].remember == true) {

		alert("Here is your " + _widget.settings[0].report + " " + _widget.settings[0].format + " for " + _widget.settings[0].date + ".");

	} else {

		/* build the download form */
		var $settings = $("<div class='widget-accounts data-form' />"),
			$downloadSection = $("<div class='form-section' />").appendTo($settings),
			$typeRow = $("<div class='row' />").appendTo($downloadSection),
			$typeLabelCol = $("<div class='label-column' />").appendTo($typeRow),
			$typeLabel = $("<label>Report Type</label>").appendTo($typeLabelCol),
			$typeDataCol = $("<div class='data-column' />").appendTo($typeRow),
			$typeCustomSelect = $("<div class='custom-select' />").appendTo($typeDataCol),
			$typeElement = $("<select id='" + _widget.id + "-type'><option value='Deposit Summary'>Deposit Summary</option></select>").appendTo($typeCustomSelect).val(_widget.settings[0].report),
			$formatRow = $("<div class='row' />").appendTo($downloadSection),
			$formatLabelCol = $("<div class='label-column' />").appendTo($formatRow),
			$formatLabel = $("<label>Report Format</label>").appendTo($formatLabelCol),
			$formatDataCol = $("<div class='data-column' />").appendTo($formatRow),
			$formatCustomSelect = $("<div class='custom-select' />").appendTo($formatDataCol),
			$formatElement = $("<select id='" + _widget.id + "-format'><option value='CSV'>CSV</option><option value='Excel'>Excel</option><option value='MT940'>MT940</option><option value='PDF'>PDF</option></select>").appendTo($formatCustomSelect).val(_widget.settings[0].format),
			$dateRow = $("<div class='row' />").appendTo($downloadSection),
			$dateLabelCol = $("<div class='label-column' />").appendTo($dateRow),
			$dateLabel = $("<label>Date</label>").appendTo($dateLabelCol),
			$dateDataCol = $("<div class='data-column' />").appendTo($dateRow),
			$dateCustomSelect = $("<div class='custom-select' />").appendTo($dateDataCol),
			$dateElement = $("<select id='" + _widget.id + "-date'><option value='Today'>Today</option><option value='Yesterday'>Yesterday</option><option value='This Week'>This Week</option><option value='Last Week'>Last Week</option><option value='This Month'>This Month</option><option value='Last Month'>Last Month</option></select>").appendTo($dateCustomSelect).val(_widget.settings[0].date),

			$rememberRow = $("<div class='row' />").appendTo($downloadSection),
			$rememberLabelCol = $("<div class='label-column' />").appendTo($rememberRow),
			$rememberLabel = $("<label>&nbsp;</label>").appendTo($rememberLabelCol),
			$rememberDataCol = $("<div class='data-column' />").appendTo($rememberRow),
			$rememberElement = $("<input type='checkbox' id='" + _widget.id + "-remember' />").appendTo($rememberDataCol).prop("checked", _widget.settings[0].remember).on("click", function() {
				var _note = $(this).closest("div.row").find("[data-note='remember']");
				if ($(this).prop("checked")) {
					_note.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
				} else {
					_note.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
				}
			}),
			$rememberLabelDesc = $("<label class='desc' for='" + _widget.id + "-remember'>Remember This</label>").appendTo($rememberDataCol),
			$noteText = $("<div class='data-note' data-note='remember'></div>").appendTo($rememberDataCol);

		if ($rememberElement.prop("checked")) {
			$noteText.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
		} else {
			$noteText.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
		}

		/* the download report function */
		function downloadReport(_dialog) {
			if ($rememberElement.prop("checked")) {
				_widget.settings[0].report = $typeElement.val();
				_widget.settings[0].format = $formatElement.val();
				_widget.settings[0].date = $dateElement.val();
				_widget.settings[0].remember = $rememberElement.prop("checked");
				store.set('saved_widget_data', widgetDataArray);
			}
			alert("Here is your " + _widget.settings[0].report + " " + _widget.settings[0].format + " for " + _widget.settings[0].date + ".");
			dialogHider(_dialog);
		}

		/* open the download dialog */
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: _widget.id + "Download",
			title: "Download",
			size: "small",
			icon: "<i class='fa fa-download'></i>",
			content: $settings,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						downloadReport(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}
}

function showDepositSummarySettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id),

		/* log the current grouping settings */
		_groupings = _widget.settings[0].viewfilter;

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		_widget.settings = [{
			viewfilter: [$viewElement1.prop("checked"), $viewElement2.prop("checked"), $viewElement3.prop("checked"), true],
			report: $typeElement.val(),
			format: $formatElement.val(),
			date: $dateElement.val(),
			remember: $rememberElement.prop("checked")
		}];
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		var _rebuild = false;
		for (var i = _groupings.length; i--;) {
			if (_groupings[i] != _widget.settings[0].viewfilter[i]) {
				_rebuild = true;
				break;
			}
		}
		if (_rebuild) {
			buildDepositSummary(id, true);
		}
	}


	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-accounts data-form' />"),


		/* build the view settings */
		$viewSectionHeading = $("<div class='section-heading'>View Settings</div>").appendTo($settings),
		$viewSection = $("<div class='form-section top-label' />").appendTo($settings),
		$viewRow = $("<div class='row' />").appendTo($viewSection),
		$viewLabelCol = $("<div class='label-column' />").appendTo($viewRow),
		$viewLabel = $("<label>Deposit Groups</label>").appendTo($viewLabelCol),
		$viewDataCol = $("<div class='data-column' />").appendTo($viewRow),
		$viewDiv1 = $("<div style='display: inline-block; vertical-align: top; width: 33%; overflow: hidden; padding: 0 10px; margin: 0 10px; box-sizing: border-box;'>").appendTo($viewDataCol),
		$viewElement1 = $("<input type='checkbox' id='" + _widget.id + "-vs1' />").appendTo($viewDiv1).prop("checked", _widget.settings[0].viewfilter[0]),
		$viewLabelDesc1 = $("<label class='desc' for='" + _widget.id + "-vs1'>Today</label>").appendTo($viewDiv1),
		$viewDiv2 = $("<div style='display: inline-block; vertical-align: top; width: 33%; overflow: hidden; padding: 0 10px; margin: 0 10px; box-sizing: border-box;'>").appendTo($viewDataCol),
		$viewElement2 = $("<input type='checkbox' id='" + _widget.id + "-vs2' />").appendTo($viewDiv2).prop("checked", _widget.settings[0].viewfilter[1]),
		$viewLabelDesc2 = $("<label class='desc' for='" + _widget.id + "-vs2'>This Week</label>").appendTo($viewDiv2),
		$viewDiv3 = $("<div style='display: inline-block; vertical-align: top; width: 33%; overflow: hidden; padding: 0 10px; margin: 0 10px; box-sizing: border-box;'>").appendTo($viewDataCol),
		$viewElement3 = $("<input type='checkbox' id='" + _widget.id + "-vs3' />").appendTo($viewDiv3).prop("checked", _widget.settings[0].viewfilter[2]),
		$viewLabelDesc3 = $("<label class='desc' for='" + _widget.id + "-vs3'>This Month</label>").appendTo($viewDiv3),

		/* build the download settings */
		$downloadSectionHeading = $("<div class='section-heading'>Download Settings</div>").appendTo($settings),
		$downloadSection = $("<div class='form-section' />").appendTo($settings),
		$typeRow = $("<div class='row' />").appendTo($downloadSection),
		$typeLabelCol = $("<div class='label-column' />").appendTo($typeRow),
		$typeLabel = $("<label>Report Type</label>").appendTo($typeLabelCol),
		$typeDataCol = $("<div class='data-column' />").appendTo($typeRow),
		$typeCustomSelect = $("<div class='custom-select' />").appendTo($typeDataCol),
		$typeElement = $("<select id='" + _widget.id + "-type'><option value='Deposit Summary'>Deposit Summary</option></select>").appendTo($typeCustomSelect).val(_widget.settings[0].report),
		$formatRow = $("<div class='row' />").appendTo($downloadSection),
		$formatLabelCol = $("<div class='label-column' />").appendTo($formatRow),
		$formatLabel = $("<label>Report Format</label>").appendTo($formatLabelCol),
		$formatDataCol = $("<div class='data-column' />").appendTo($formatRow),
		$formatCustomSelect = $("<div class='custom-select' />").appendTo($formatDataCol),
		$formatElement = $("<select id='" + _widget.id + "-format'><option value='CSV'>CSV</option><option value='Excel'>Excel</option><option value='MT940'>MT940</option><option value='PDF'>PDF</option></select>").appendTo($formatCustomSelect).val(_widget.settings[0].format),
		$dateRow = $("<div class='row' />").appendTo($downloadSection),
		$dateLabelCol = $("<div class='label-column' />").appendTo($dateRow),
		$dateLabel = $("<label>Date</label>").appendTo($dateLabelCol),
		$dateDataCol = $("<div class='data-column' />").appendTo($dateRow),
		$dateCustomSelect = $("<div class='custom-select' />").appendTo($dateDataCol),
		$dateElement = $("<select id='" + _widget.id + "-date'><option value='Today'>Today</option><option value='Yesterday'>Yesterday</option><option value='This Week'>This Week</option><option value='Last Week'>Last Week</option><option value='This Month'>This Month</option><option value='Last Month'>Last Month</option></select>").appendTo($dateCustomSelect).val(_widget.settings[0].date),

		$rememberRow = $("<div class='row' />").appendTo($downloadSection),
		$rememberLabelCol = $("<div class='label-column' />").appendTo($rememberRow),
		$rememberLabel = $("<label></label>").appendTo($rememberLabelCol),
		$rememberDataCol = $("<div class='data-column' />").appendTo($rememberRow),
		$rememberElement = $("<input type='checkbox' id='" + _widget.id + "-remember' />").appendTo($rememberDataCol).prop("checked", _widget.settings[0].remember).on("click", function() {
			var _note = $(this).closest("div.row").find("[data-note='remember']");
			if ($(this).prop("checked")) {
				_note.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
			} else {
				_note.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
			}
		}),
		$rememberLabelDesc = $("<label class='desc' for='" + _widget.id + "-remember' title=''>Remember This</label>").appendTo($rememberDataCol),
		$noteText = $("<div class='data-note' data-note='remember'></div>").appendTo($rememberDataCol);

	if ($rememberElement.prop("checked")) {
		$noteText.text("Uncheck 'Remember This' to see the Download Options dialog when downloading a report.")
	} else {
		$noteText.text("When 'Remember This' is checked the report settings you have chosen will automatically be used for your future downloads.")
	}


	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Deposit Summary Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function buildDepositSummary(id, rebuild) {


	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length) {
		_widget.settings = [{
			viewfilter: [true, true, true, true],
			report: "Deposit Summary",
			format: "PDF",
			date: "Yesterday",
			remember: false
		}];
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	var check_range = function(mdate, compare) {
		var today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
		var md = new Date(mdate.substr(6, 4), mdate.substr(3, 2) - 1, mdate.substr(0, 2)).getTime();
		if (md < today) return false;
		if (compare[0] && md == today.getTime()) return "Today";
		if (compare[1] && md >= today.getTime() && md <= new Date().setDate(today.getDate() + (7 - (today.getDay() == 0 ? 7 : today.getDay())))) return "This Week"; //Week until Sunday
		if (compare[2] && md >= today.getTime() && md <= new Date(today.getFullYear(), today.getMonth() + 1, 0).getTime()) return "This Month"; //until last day of current month
		return "Later";
	}

	var check_groups = function(compare, i) {
		var today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

		//today is the last day of the week - no need to show group.
		if (i == 1 && compare[0] && today.getTime() == new Date(today.getFullYear(), today.getMonth(), today.getDate()).setDate(today.getDate() + (7 - (today.getDay() == 0 ? 7 : today.getDay())))) return false;
		//today is the last day of the month - no need to show group.
		if (i == 2 && compare[0] && today.getTime() == new Date(today.getFullYear(), today.getMonth() + 1, 0).getTime()) return false; //until last day of current month
		//this week encompasses the end of the month - no need to show group.
		if (i == 2 && compare[1] && new Date(today.getFullYear(), today.getMonth(), today.getDate()).setDate(today.getDate() + (7 - (today.getDay() == 0 ? 7 : today.getDay()))) >= new Date(today.getFullYear(), today.getMonth() + 1, 0).getTime()) return false;

		return true;
	}

	var MD = "";
	var $group;
	var $content = $("<div />");
	$("<div class='dep-header'><div class='dep-header-col' style='width:30%'>Deposit</div><div class='dep-header-col text-right' style='width:20%'>Rate</div><div class='dep-header-col text-right' style='width:25%'>Principal</div><div class='dep-header-col text-right' style='width:25%'>Maturity</div></div>").appendTo($content);
	var $deposits = $("<div class='dep-table' />").appendTo($content);

	//build group headings.
	$.each(_settings[0].viewfilter, function(i, v) {
		var groupname;

		if (!v || !check_groups(_settings[0].viewfilter, i)) return; //no need to add the group - it is redundant.

		if (i == 0) groupname = "Today"
		if (i == 1) groupname = "This Week"
		if (i == 2) groupname = "This Month"
		if (i == 3) groupname = "Later"


		if (i == 3 && !_settings[0].viewfilter[0] && !_settings[0].viewfilter[1] && !_settings[0].viewfilter[2]) {} else {
			$("<div class='dep-group' style='display:none;'><div class='dep-group-name'><i class='fa fa-minus-square fa-fw'></i>Maturing " + groupname + "</div></div>")
				.click(function() {
					$(this).next().slideToggle('fast');
					if ($(this).find(".fa-plus-square").size() > 0) $(this).find(".fa-plus-square").removeClass("fa-plus-square").addClass("fa-minus-square");
					else $(this).find(".fa-minus-square").removeClass("fa-minus-square").addClass("fa-plus-square");
				})
				.appendTo($deposits);
		}
		$group = $("<div group='" + groupname + "'  />").appendTo($deposits);

	});

	if (deposit_accounts.data_truncated) {
		$('<div class="text-center" style="padding: 20px 0;"><a href="#Deposits" class="form-button primary"><i class="fa fa-plus-square fa-fw"></i>Show More</a></div>')
			.click(function() {
				alert("I would take you to the deposit summary reporting screen.");
			})
			.appendTo($deposits);
	}

	//loop through accounts by maturity date.
	$.each(deposit_accounts.deposit_data, function() {
		/* group accounts by maturity date - collapsable */

		if (!check_range(this.maturity_date, _settings[0].viewfilter)) return;

		$group = $deposits.find("[group='" + check_range(this.maturity_date, _settings[0].viewfilter) + "']");
		//$group.find(".no-deals-display").remove();
		$group.prev().show();
		/* deposit row item */
		$li = $("<div class='dep-row' data-account='" + this.acct_number + "' />").appendTo($group).on("mouseover mouseout", function() {
				if (!$(this).hasClass("show-actions")) {
					$(this).find(".dep-actions-show").toggle()
				}
			}),

			/* build the action div */
			$actions = $("<div class='dep-actions' />").appendTo($li),
			$close = $("<span class='dep-actions-hide' title='Hide Actions'><i class='fa fa-ellipsis-v'></i></span>").appendTo($actions).on("click", function() {
				$(this).parents(".dep-row").removeClass("show-actions").find(".dep-actions-show").show()
			}),
			$download = $("<span title='Download A Report For This Account'><i class='fa fa-download'></i></span>").appendTo($actions).on("click", showDepositSummaryDownload),

			/* build the account data */
			$row = $("<div class='dep-inner' />").appendTo($li),
			//actions pencil
			$open = $("<div class='dep-actions-show' title='Show Actions'><i class='fa fa-ellipsis-v fa-fw'></i></div>").appendTo($row).on("click", function() {
				$(this).closest(".dep-table").find(".show-actions").removeClass("show-actions").find(".dep-actions-show").hide();
				$(this).hide().parents(".dep-row").addClass("show-actions");
			}),
			//action when clicking row
			$link = $("<a href='javascript:void(0)' />").appendTo($row).on("click", function() {
				alert("I would take you to the deposit details");
			}),
			//deposit account name & number
			$account = $("<div class='dep-data-col' style='width: 30%;'><span class='dep-data-account'>" + this.name + "<br /><span style='font-size: 14px;'>" + this.acct_number + " (" + this.currency + ")</span></span></div>").appendTo($link),
			//interest and term information
			$term = $("<div class='dep-data-col text-right' style='width: 20%;'>" + this.rate + "</div>").appendTo($link),
			//date
			$date = $("<div class='dep-data-col text-right' style='width: 25%;'><span class='dep-data-account'><span class='pos'>" + this.deposit_amt + "</span><br /><span style='font-size: 14px;'>" + this.start_date + "</span></span></div>").appendTo($link),
			//principle and maturity amounts
			$available = $("<div class='dep-data-col text-right' style='width: 25%;'><span class='dep-data-account'><span class='pos'>" + this.maturity_amt + "</span><br /><span style='font-size: 14px;'>" + this.maturity_date + "</span></span></div>").appendTo($link);


	});
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($content);
	} else {
		return $content;
	}
}


/* loan summary widget */
var loan_data = [{
	id: randString(20),
	name: "ABC Deal 250M AUD",
	number: "12333-2332-1222",
	limit: "250,000,000.00",
	undrawn: "50,000,000.00",
	drawn: "200,000,000.00",
	nodrawings: "5"
}, {
	id: randString(20),
	name: "ABC Deal 50M AUD",
	number: "12332-3242-5233",
	limit: "50,000,000.00",
	undrawn: "10,000,000.00",
	drawn: "40,000,000.00",
	nodrawings: "6"
}, {
	id: randString(20),
	name: "ABC Deal 10M AUD",
	number: "12332-5332-1212",
	limit: "10,000,000.00",
	undrawn: "1,000,000.00",
	drawn: "9,000,000.00",
	nodrawings: "3"
}];

function buildLoanSummary(id, rebuild) {
	var $ul = $("<ul />"),
		$li, $a, $name, $number, $limit, $drawn, $undrawn, $nodrawings;
	$.each(loan_data, function() {
		$li = $("<li />").appendTo($ul),
			$a = $("<a href='#" + this.name + "'>" + this.name + "</a>").appendTo($li).on("click", function(e) {
				e.preventDefault();
			});
	});
	return $ul;
}

function showLoanSummarySettings(e) {
	e.preventDefault();
}


/* historical balances widget */
var hide_weekends = 2;
var historical_balance_data = (function() {
	var bala = [];
	$.each(accounts, function(index) {
		bala.push({
			account_name: accounts[index].name,
			data: []
		});
		var bal = Math.round(Math.random() * 300000);
		var bdate = new Date(new Date().getFullYear(), new Date().getMonth() - 12, new Date().getDate())
		for (var i = 0; i < 365; i++) {
			if (hide_weekends && (i % 7 == 0 || i % 7 == 1)) {
				bala[index].data.push({
					day: bdate.setDate(bdate.getDate() + 1),
					Balance: hide_weekends == 1 ? null : bal
				});
			} else {
				bala[index].data.push({
					day: bdate.setDate(bdate.getDate() + 1),
					Balance: bal += Math.round(Math.random() * 20000) - ((bdate.getDate() == 20 ? Math.round(Math.random() * 200000) - 80000 : 10000))
				});
			}
		}
	});
	return bala;
})();

function showAddAccountsHistoricalBalances(_target, _widget) {

	/* set _data to the widget data and _id to the widget id */
	var _data = _widget.data,
		_id = _widget.id;

	/* function to save and add selected accounts to the widget */
	function saveSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
			for (var i = 0; i < accounts.length; i++) {
				for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
					if (accounts[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
						_data.push(accounts[i]);
					}
				}
			}
			dialogHider(_dialog);
			buildHistoricalBalances(_id, true);
			store.set('saved_widget_data', widgetDataArray);
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='widget-historical-balances wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addAccount]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each(accounts, function() {

		/* check to see if an account is already added to the widget favourite accounts and if so ignore it */
		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
			if (_data[i].number == this.number) {
				_alreadyAdded = true;
				break;
			}
		}
		if (!_alreadyAdded) {
			$li = $("<li>").appendTo($ul),
				$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						if ($target.hasClass("fav-data-col")) {
							$target = $target.closest("div.fav-row");
						}
						$target = $target.find("input[name='_addAccount']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='_selectAll']").prop("checked", false)
					}
					if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
						$("input[name='_selectAll']").prop("checked", true)
					}
				}),
				$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
			var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
					var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
				}),
				$name = $("<div class='fav-data-col' style='width: 220px;'>" + this.name + "</div>").appendTo($row),
				$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
				$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)
		}
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Accounts",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveSelectedAccounts(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

	/* if no accounts are available display a message */
	if (!$("#AddAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

function showRemoveAccountsHistoricalBalances(_target, _widget) {

	/* set _data to the widget data and _id to the widget id */
	var _data = _widget.data,
		_id = _widget.id;

	/* function to remove selected accounts from the widget */
	function removeSelectedAccounts(_dialog) {
		if ($("input[name=_addAccount]:checked").length > 0) {
			for (var i = 0; i < _data.length; i++) {
				for (var s = 0; s < $("input[name=_addAccount]:checked").length; s++) {
					if (_data[i].number == $("input[name=_addAccount]:checked").eq(s).val()) {
						_data.splice(i, 1);
					}
				}
			}
			dialogHider(_dialog);
			buildHistoricalBalances(_id, true);
			store.set('saved_widget_data', widgetDataArray);
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='widget-historical-balances wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='RemoveAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addAccount]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$nameHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 220px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='fav-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='RemoveAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each(_data, function() {

		$li = $("<li>").appendTo($ul),
			$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					if ($target.hasClass("fav-data-col")) {
						$target = $target.closest("div.fav-row");
					}
					$target = $target.find("input[name='_addAccount']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
				}
				if (!$(this).prop("checked")) {
					$("input[name='_selectAll']").prop("checked", false)
				}
				if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
					$("input[name='_selectAll']").prop("checked", true)
				}
			}),
			$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount' />").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
			}),
			$name = $("<div class='fav-data-col' style='width: 220px;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='fav-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
			$currency = $("<div class='fav-data-col' style='width: 160px;'>" + this.currency + "</div>").appendTo($row)

	});

	/* build and show the remove accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "RemoveAccounts",
		title: "Remove Accounts",
		size: "medium",
		icon: "<i class='fa fa-minus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					removeSelectedAccounts(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#RemoveAccountsFilterInput").fastLiveFilter('#RemoveAccountsFilterList');

	/* if no accounts are available display a message */
	if (!$("#RemoveAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

function buildHistoricalBalances(id, rebuild) {
	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length) {
		_widget.settings = [{
			daterange: "LW",
			charttype: "line",
			hidden_series: [],
			refCCY: "Default"
		}];
	}

	var $content = $("<div class='graph-canvas'></div>");
	var $empty = $("<div class='ha-empty'><a href='javascript:void(0)' class='form-button primary' data-action='" + _widget.id + "'><i class='fa fa-plus-square fa-fw'></i>Add Accounts</a></div>").appendTo($content).on("click", function() {
		showAddAccountsHistoricalBalances($(this), _widget);
	}).hide();

	var $highchart = $("<div class='highchart' id='HC_" + id + "' \>").appendTo($content);
	var $dateoptions = $("<div class=date-container><div class='date-options'><div class='last-week' DR='LW'><i class='fa fa-calendar'></i>Last Week</div><div class='3-months' DR='3M'><i class='fa fa-calendar'></i>3 Months</div><div class='6-months' DR='6M'><i class='fa fa-calendar'></i>6 Months</div><div class='12-months' DR='12M'><i class='fa fa-calendar'></i>12 Months</div></div><div class='date-close'><i class='fa fa-times fa-fw'></i></div></div>").appendTo($content);
	if (_widget.settings[0].daterange == "LW") $dateoptions.find(".last-week").addClass("selected");
	if (_widget.settings[0].daterange == "3M") $dateoptions.find(".3-months").addClass("selected");
	if (_widget.settings[0].daterange == "6M") $dateoptions.find(".6-months").addClass("selected");
	if (_widget.settings[0].daterange == "12M") $dateoptions.find(".12-months").addClass("selected");

	$dateoptions.find("div>div").on("click", function() {
		var DR = $(this).attr("DR");
		$(this).parents(".date-container").animate({
			bottom: -41
		}, 400, function() {
			_widget.settings[0].daterange = DR;
			store.set('saved_widget_data', widgetDataArray);
			buildHistoricalBalances(id, true);
		});
	});

	$dateoptions.find(".date-close").click(function() {
		$(this).parent().parent().find(".date-container").animate({
			bottom: -41
		}, 400);
	});

	var $chartoptions = $("<div class='ha-options'></div>").appendTo($content);
	var $datebutton = $("<div class='date-button' title='Change Date Range'><i class='fa fa-calendar'></i></div>").on("click", function() {
		$(this).parent().parent().find(".date-container").animate({
			bottom: 0
		}, 250);
	}).appendTo($chartoptions);

	/* hide content and show default message if no accounts loaded into widget */
	if (!_widget.data.length) {
		$dateoptions.hide();
		$datebutton.hide();
		$empty.show();
	};

	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($content);
		finaliseHistoricalBalances(id, _widget.settings[0], _widget.data);
	} else {
		setTimeout(function() {
			finaliseHistoricalBalances(id, _widget.settings[0], _widget.data);
		}, 100);
		return $content;
	}
}

function finaliseHistoricalBalances(id, _settings, _accounts) {
	var anz_colours = ["#007DBA", "#747679", "#5BC6E8", "#C6DFEA", "#00C6D7", "#B9C9D0", "#589199", "#394A58", "#AA9C8F", "#DF7A00", "#B9CCC3", "#D3CD8B", "#EDE8C4", "#FDC82F"];

	var chart_data = [],
		_dateCompare;

	if (_settings.daterange == "LW") {
		_dateCompare = new Date(new Date().setDate(new Date().getDate() - 7))
	} else if (_settings.daterange == "3M") {
		_dateCompare = new Date(new Date().setDate(new Date().getDate() - 90))
	} else if (_settings.daterange == "6M") {
		_dateCompare = new Date(new Date().setDate(new Date().getDate() - 180))
	} else if (_settings.daterange == "12M") {
		_dateCompare = new Date(new Date().setDate(new Date().getDate() - 365))
	}



	$.each(_accounts, function(account_index) {

		var index = chart_data.push({
			name: this.name,
			data: [],
			color: anz_colours[account_index % anz_colours.length],
			visible: $.inArray(this.name, _settings.hidden_series) == -1 ? true : false
		}) - 1;

		var i = -1;
		$.each(historical_balance_data, function(hbd_index, value) {
			if (value.account_name == _accounts[account_index].name) {
				i = hbd_index;
				return false;
			}
		});
		if (i == -1) return;

		$.each(historical_balance_data[i].data, function(i2) {
			if (historical_balance_data[i].data[i2].day < _dateCompare) {
				return;
			}
			chart_data[index].data.push({
				x: historical_balance_data[i].data[i2].day,
				y: historical_balance_data[i].data[i2].Balance
			});
		});
	});

	var hc_chart = $("#HC_" + id).highcharts({
		chart: {
			type: (_settings.charttype == "area" || _settings.charttype == "stacked area") ? "area" : "line",
			zoomType: 'x',
			resetZoomButton: {
				position: {
					x: 0,
					y: -10
				},
				theme: {
					style: {
						zIndex: 20,
						lineHeight: "20px"
					},
					fill: 'white',
					stroke: 'silver',
					r: 3,
					states: {
						hover: {
							fill: '#007dba',
							style: {
								color: 'white'
							}
						}
					}
				}
			}
		},
		xAxis: {
			type: 'datetime',
			lineWidth: 0,
			tickWidth: 0,
			maxPadding: 0,
			dateTimeLabelFormats: {
				day: '%e. %b',
				year: '%Y'
			},
			events: {
				setExtremes: function() {
					$("#" + id).find(".reset-zoom").show();
				}
			}
		},
		legend: {
			align: "middle",
			verticalAlign: "bottom",
			layout: "horizontal",
			itemMarginBottom: 5,
			itemMarginTop: 0,
			x: 32,
			itemStyle: {
				color: "#999",
				maxWidth: "160px",
				overflow: "hidden",
				textOverflow: "ellipsis",
				lineHeight: "18px",
				fontWeight: "normal"
			},
			itemHoverStyle: {
				color: '#007dba'
			},
			enabled: true,
			useHTML: true,
			itemWidth: 200
		},
		yAxis: {
			maxPadding: 0,
			minPadding: 0,
			minorTickLength: 0,
			tickLength: 0,
			lineWidth: 0,
			gridLineColor: "#ebebeb",
			title: {
				enabled: false
			},
			labels: {
				//enabled: false,
				overflow: 'justify'
			}
		},
		plotOptions: {
			series: {
				marker: {
					radius: 0
				},
				events: {
					legendItemClick: function() {
						if (this.visible) _settings.hidden_series.push(this.name)
						else _settings.hidden_series.splice($.inArray(this.name, _settings.hidden_series), 1);
						store.set('saved_widget_data', widgetDataArray);
					}
				},
				animation: {
					duration: 250
				}
			},
			area: {
				stacking: _settings.charttype == "stacked area" ? 'normal' : '',
				/* created stacked chart */
				fillOpacity: 0.5,
				marker: {
					enabled: false,
					symbol: 'circle',
					radius: 2,
					states: {
						hover: {
							enabled: true
						}
					}
				}
			}
		},
		title: {
			text: ''
		},
		tooltip: {
			shared: true,
			backgroundColor: "#EDE8C4",
			borderColor: "#004165",
			useHTML: true,
			formatter: function() {
				var tooltipstring = "<span class='his-bal-tooltip'><div class='tooltip-header'>" + Highcharts.dateFormat("%d/%m/%Y", this.x) + "<span class='tooltip-ref-ccy'>" + (_settings.refCCY == "Default" ? "USD" : _settings.refCCY) + "</div>"

				this.points.sort(function(a, b) {
					if (a.y < b.y) return 1;
					if (a.y > b.y) return -1;
					return 0;
				});

				$.each(this.points, function(i, v) {
					tooltipstring += "<div class='tooltip-account' >" + v.series.name + "</div><div class='tooltip-amt'>" + Highcharts.numberFormat(v.y, 2, ".", ",") + "</div><br>";
				});

				return tooltipstring + "</span>";
			}
		},
		series: chart_data,
		exporting: {
			buttons: {
				contextButton: {
					enabled: false
				}
			}
		},
		credits: {
			enabled: false
		}
	});
}

function rezoomHistoricalBalances(e) {
	e.preventDefault();
	var $highchart = $(this).closest("div.widget-container").find(".highchart").data('highchartsChart');
	Highcharts.charts[$highchart].zoomOut();
	$(this).hide();
}

function showHistoricalBalancesSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id),

		/* log the current grouping settings */
		_groupings = _widget.settings[0].viewfilter;

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		if (_widget.settings[0].charttype == $viewElement.val() && _widget.settings[0].refCCY == $refByElement.val()) {
			dialogHider(_dialog);
		} else {
			_widget.settings[0].charttype = $viewElement.val();
			_widget.settings[0].refCCY = $refByElement.val();
			store.set('saved_widget_data', widgetDataArray);
			dialogHider(_dialog);
			buildHistoricalBalances(id, true);
		}

	}

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-accounts data-form' />"),

		/* build the view settings */
		$viewSectionHeading = $("<div class='section-heading'>View Settings</div>").appendTo($settings),
		$viewSection = $("<div class='form-section' />").appendTo($settings),
		$viewRow = $("<div class='row' />").appendTo($viewSection),
		$viewLabelCol = $("<div class='label-column' />").appendTo($viewRow),
		$viewLabel = $("<label>Chart Type</label>").appendTo($viewLabelCol),
		$viewDataCol = $("<div class='data-column' />").appendTo($viewRow),
		$viewElementCustomSelect = $("<div class='custom-select' />").appendTo($viewDataCol),
		$viewElement = $("<select id='" + _widget.id + "-style'><option value='line'>Line</option><option value='area'>Area</option></select>").appendTo($viewElementCustomSelect).val(_widget.settings[0].charttype);

	/* Reference Currency Option */
	$refByRow = $("<div class='row' />").appendTo($viewSection),
		$refByLabelCol = $("<div class='label-column' />").appendTo($refByRow),
		$refByLabel = $("<label>Reference Currency</label>").appendTo($refByLabelCol),
		$refByDataCol = $("<div class='data-column' style='width:80%' />").appendTo($refByRow),
		$refByCustomSelect = $("<div class='custom-select' />").appendTo($refByDataCol),
		$refByElement = $("<select id='" + _widget.id + "-type'><option value='Default'>Default</option><option value='AUD'>AUD</option><option value='EUR'>EUR</option><option value='USD'>USD</option></select>").appendTo($refByCustomSelect).val(_widget.settings[0].refCCY)

	/* build the accounts section */
	var $accountSectionHeading = $("<div class='section-heading'>Accounts</div>").appendTo($settings),
		$accountSection = $("<div class='form-section' />").appendTo($settings),
		$accountRow = $("<div class='row' />").appendTo($accountSection),
		$accountDataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($accountRow),
		$accountNoteData,
		$addAccountsButton,
		$removeAccountsButton;
	if (_widget.data.length == 0) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You haven't added any historical balance accounts yet.</div>").appendTo($accountDataCol);
		$addAccountsButton = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			updateMySettings(_dialog, true);
			showAddAccountsHistoricalBalances($("#" + _widget.id + "Settings"), _widget);
		});
	} else if (_widget.data.length >= 1 && _widget.data.length < 7) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You've added " + _widget.data.length + " historical balance account(s).</div>").appendTo($accountDataCol);
		$addAccountsButton = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			updateMySettings(_dialog, true);
			showAddAccountsHistoricalBalances($("#" + _widget.id + "Settings"), _widget)
		});
		$removeAccountsButton = $("<a href='javascript:void(0)' class='form-button'><i class='fa fa-times fa-fw'></i>Remove Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showRemoveAccountsHistoricalBalances($("#" + _widget.id + "Settings"), _widget);
		});
	} else if (_widget.data.length >= 7) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You've added " + _widget.data.length + " historical balance accounts.</div>").appendTo($accountDataCol);
		$removeAccountsButton = $("<a href='javascript:void(0)' class='form-button'><i class='fa fa-times fa-fw'></i>Remove Accounts</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showRemoveAccountsHistoricalBalances($("#" + _widget.id + "Settings"), _widget);
		});
	}

	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Deposit Summary Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showHistoricalBalancesDownload(e) {
	e.preventDefault();
}


/* exchange rates widget */
var xrates = {
	AUD: 0.9421,
	BRL: 21.5,
	CHF: 1.15,
	EUR: 1.21,
	GBP: 1.45,
	IDR: 0.000086,
	JPY: 0.0145,
	NZD: 0.81,
	SGD: 0.78,
	USD: 1,
	VND: 0.000047
}

function showExchangeRateSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		if (_updateRequired) {
			_widget.settings = [{
				ccypairs: temp_ccypairs.slice(0)
			}];
			store.set('saved_widget_data', widgetDataArray);
			dialogHider(_dialog);
			buildExchangeRates(id, true);
		} else {
			dialogHider(_dialog);
		}
	}

	/* check if an update is required */
	var _updateRequired = false;

	/* take a temporary copy of the rates setup in widget. */
	var temp_ccypairs = _widget.settings[0].ccypairs.slice(0);

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-rates data-form' />"),

		/* build the settings */
		$sectionHeading = $("<div class='section-heading'>Add Exchange Rates</div>").appendTo($settings),
		$formSection = $("<div class='form-section' />").appendTo($settings),
		$addRatesDiv = $("<div class='add-rates' />").appendTo($formSection),
		$ccyFrom = $("<div class='custom-select' style='margin-right: 10px;'><select name='ccy' class='ccyfrom'><option value='' disabled='disabled' selected='selected' style='display: none;'>From</option></select></div>").appendTo($addRatesDiv),
		$ccyTo = $("<div class='custom-select' style='margin-right: 10px;'><select name='ccy' class='ccyto'><option value='' disabled='disabled' selected='selected' style='display:none;'>To</option></select></div>").appendTo($addRatesDiv),
		$addPairBtn = $("<div class='add-pair-btn'><i class='fa fa-check fa-fw'></i>Add</div>").appendTo($addRatesDiv).on('click', function() {
			var fromccy = $(".ccyfrom").val().toUpperCase(),
				toccy = $(".ccyto").val().toUpperCase();
			if (fromccy.length != 3 || toccy.length != 3 || $.inArray(fromccy, ccyoptions) == -1 || $.inArray(toccy, ccyoptions) == -1) {
				return;
			}
			if (fromccy == toccy) {
				buildErrorNotification("From Currency same as To Currency", "You cannot add the same currency twice.", 200);
				return;
			}
			if ($.inArray(fromccy + toccy, temp_ccypairs) > -1) {
				buildErrorNotification("Currency pair already added", "That currency pair has already been added.", 200);
				return;
			}
			var rateRow = $("<div class='rates-row' data-pair='" + fromccy + toccy + "'><div class='reorder-pair'><i class='fa fa-bars fa-fw'></i></div><div>" + fromccy + "</div><div>" + toccy + "</div><a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i></a></div>").appendTo($currentSelection);
			rateRow.find("a").on("click", function() {
				temp_ccypairs = $.grep(temp_ccypairs, function(value) {
					return value != fromccy + toccy;
				});
				$(this).parent().hide("fast", function() {
					$(this).remove();
				});
				_updateRequired = true;
			});
			temp_ccypairs.push(fromccy + toccy);
			$(".ccyfrom").val("").children("option:gt(0)").show().attr("disabled", false);
			$(".ccyto").val("").children("option:gt(0)").show().attr("disabled", false);
			$(this).removeClass("active");
			_updateRequired = true;
		});

	var $currentSelection = $("<div class='form-section' />").appendTo($settings).sortable({
		handle: '.reorder-pair',
		axis: 'y',
		tolerance: "pointer",
		update: function(event, ui) {
			temp_ccypairs = [];
			$currentSelection.children("div.rates-row").each(function() {
				temp_ccypairs.push($(this).attr("data-pair"))
			});
			_updateRequired = true;
		}
	});

	/* add existing rates to table. */
	$.each(temp_ccypairs, function(i, v) {
		var xraterow = $("<div class='rates-row' data-pair='" + v.substr(0, 3) + v.substr(3, 3) + "'><div class='reorder-pair'><i class='fa fa-bars fa-fw'></i></div><div>" + v.substr(0, 3) + "</div><div>" + v.substr(3, 3) + "</div><a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i></a></div>").appendTo($currentSelection);
		xraterow.find("a").on("click", function() {
			temp_ccypairs = $.grep(temp_ccypairs, function(value) {
				return value != v;
			});
			$(this).parent().hide("fast", function() {
				$(this).remove();
			});
			_updateRequired = true;
		});
	});

	var ccyoptions = [];

	/* populate xrate select box with options */
	for (var property in xrates) {
		if (xrates.hasOwnProperty(property)) {
			ccyoptions.push(property.toUpperCase());
		}
	}

	/* add options to currency dropdowns */
	$.each(ccyoptions, function(i, v) {
		$addRatesDiv.find("select").append('<option value="' + v + '">' + v + '</option>');
	});

	/* enable add-rate button when two rates are selected. */
	$addRatesDiv.find("select").on("change", function() {
		if ($(this).hasClass("ccyfrom")) {
			$(".ccyto>option:gt(0)").show().attr("disabled", false);
			$(".ccyto>option[value='" + $(this).val() + "']").hide().attr("disabled", true);
		} else {
			$(".ccyfrom>option:gt(0)").show().attr("disabled", false);
			$(".ccyfrom>option[value='" + $(this).val() + "']").hide().attr("disabled", true);
		}
		if ($(".ccyfrom").val() != "" && $(".ccyto").val() != "") {
			$(".add-pair-btn").addClass("active");
		}
	});

	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Exchange Rate Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function buildExchangeRates(id, rebuild) {

	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length) {
		_widget.settings = [{
			ccypairs: []
		}];
	}

	var calc_rate = function(cross) {
		var fromccy = cross.substr(0, 3),
			toccy = cross.substr(3, 3);
		return parseFloat(xrates[fromccy] / xrates[toccy]).toFixed(4);
	}

	var $content = $("<div class='rate-content' />"),
		$default = $("<div class='text-center' style='display: none' />").appendTo($content),
		$addPairLink = $("<a href='#AddPairs' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Exchange Rates</a>").on("click", showExchangeRateSettings).appendTo($default);



	var $ratecontainer = $("<ul class='rate-container' />").appendTo($content);

	//adds an array of currency pairs ["AUDCHF", "JPYAUD"]
	var add_rates = function(new_rates) {
		$.each(new_rates, function(i, v) {

			//create new rate box.
			var $rateRow = $("<li class='xraterow' />").appendTo($ratecontainer),
				$rateDiv = $("<div class='ratecont' />").appendTo($rateRow).on("mouseover", function() {
					$(this).children(".deleterate").show();
				}).on("mouseout", function() {
					$(this).children(".deleterate").hide();
				}),
				$fromRate = $("<div class='fromrate' />").appendTo($rateDiv),
				$rateName = $("<div class='ratename' data-xrate='" + v + "'>" + v.substr(0, 3) + " / " + v.substr(3, 3) + "</div>").appendTo($fromRate),
				$xrate = $("<div class='xrate'>" + calc_rate(v) + "</div>").appendTo($rateDiv),
				$deteleRate = $("<a href='javascript:void(0)' class='deleterate'><i class='fa fa-times fa-fw'></i></a>").appendTo($rateDiv).on("click", function() {
					_widget = findWidgetData(id);
					_widget.settings[0].ccypairs = $.grep(_widget.settings[0].ccypairs, function(value) {
						return value != v;
					});
					store.set('saved_widget_data', widgetDataArray);
					$(this).closest(".xraterow").hide("fast", function() {
						$(this).remove();
						if (_widget.settings[0].ccypairs.length == 0) {
							$default.show();
						}
					});
				})


		});

		//sort rates.
		$ratecontainer.sortable({
			tolerance: "pointer",
			containment: "parent",
			update: function(event, ui) {
				_widget = findWidgetData(id);
				_widget.settings[0].ccypairs = [];
				$ratecontainer.find(".ratename").each(function() {
					_widget.settings[0].ccypairs.push($(this).attr("data-xrate"));
				});
				store.set('saved_widget_data', widgetDataArray);
			}
		});
	}

	add_rates(_widget.settings[0].ccypairs);

	if (_widget.settings[0].ccypairs.length == 0) $default.show();

	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($content);
	} else {
		return $content;
	}
}



/* fast payments widget */
var _fastpayaccounts = [{
		name: "AUD Account",
		number: "95575318782877253239",
		ccy: "AUD"
	}, {
		name: "AUD Current Account",
		number: "58869546554585157444",
		ccy: "AUD"
	}, {
		name: "AUD Funding Account",
		number: "38732577519452589365",
		ccy: "AUD"
	}, {
		name: "AUD Operations",
		number: "77589459392123198864",
		ccy: "AUD"
	}, {
		name: "AUD Operations Funding",
		number: "74436262358383999149",
		ccy: "AUD"
	}, {
		name: "AUD Savings",
		number: "41147432945828632516",
		ccy: "AUD"
	}, {
		name: "Financing Account",
		number: "98587179483361683488",
		ccy: "AUD"
	}, {
		name: "Melbourne Operations",
		number: "91632348751876399625",
		ccy: "AUD"
	}, {
		name: "Melbourne Savings",
		number: "84441154497368484385",
		ccy: "AUD"
	}, {
		name: "Vic Funding",
		number: "28637434185586694649",
		ccy: "AUD"
	}],
	_fastpaytypeahead = [];
for (var j in _fastpayaccounts) {
	_fastpaytypeahead.push(_fastpayaccounts[j].name + " - " + _fastpayaccounts[j].number)
}
var _fastpaybenes = [{
	name: "Sam Taylor",
	email: "samtaylor_blues@email.com",
	phone: "555-555-1111"
}, {
	name: "Gina Giocare",
	email: "gina@giocare.com",
	phone: "555-555-2222"
}, {
	name: "Chris Hendricks",
	email: "Chris.Hendricks@email.com",
	phone: "555-555-3333"
}, {
	name: "Paul G. Washington",
	email: "paul.g.washington@email.com",
	phone: "555-555-4444"
}, {
	name: "Sally Fieldser",
	email: "sally@email.com",
	phone: "555-555-5555"
}, {
	name: "Miles Miller",
	email: "MilesMiller@email.com",
	phone: "555-555-6666"
}, {
	name: "William P. Aye",
	email: "will.p.aye@email.com",
	phone: "555-555-7777"
}];
for (var j in _fastpaybenes) {
	_fastpaybenes[j].label = _fastpaybenes[j].name + "\n" + _fastpaybenes[j].email + "\n" + _fastpaybenes[j].phone;
}
var _pastfastpayments = [{
	id: 001,
	accountname: "AUD Account",
	accountnumber: "95575318782877253239",
	bene: "samtaylor_blues@email.com",
	reason: "Personal Loan Repayment",
	amount: "350.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 002,
	accountname: "AUD Operations",
	accountnumber: "77589459392123198864",
	bene: "Chris.Hendricks@email.com",
	reason: "Bills",
	amount: "500.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 003,
	accountname: "AUD Savings",
	accountnumber: "41147432945828632516",
	bene: "555-555-4444",
	reason: "Loan Repayment",
	amount: "1500.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 004,
	accountname: "Vic Funding",
	accountnumber: "28637434185586694649",
	bene: "MilesMiller@email.com",
	reason: "Share of proceeds",
	amount: "51.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 005,
	accountname: "Financing Account",
	accountnumber: "98587179483361683488",
	bene: "555-555-7777",
	reason: "Share of proceeds",
	amount: "175.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 006,
	accountname: "AUD Account",
	accountnumber: "95575318782877253239",
	bene: "will.p.aye@email.com",
	reason: "Bills",
	amount: "95.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 007,
	accountname: "Melbourne Savings",
	accountnumber: "84441154497368484385",
	bene: "gina@giocare.com",
	reason: "Loan Repayment",
	amount: "36.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}, {
	id: 008,
	accountname: "AUD Savings",
	accountnumber: "41147432945828632516",
	bene: "555-555-5555",
	reason: "Bills",
	amount: "725.00",
	date: smartDates('randompast'),
	time: timeFormatter()
}];

function viewPastPayments(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),
		_target = $(e.target);

	var $wrapper = $("<div class='widget-fast-payments wrapper' />");

	/* build the payment filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='PastPaymentsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a payment...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearAccountsFilter").show()
			} else {
				$("#clearAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#PastPaymentsFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$accountHeader = $("<div class='fav-header-col' style='width: 20%;'>Account</div>").appendTo($header),
		$beneHeader = $("<div class='fav-header-col' style='width: 20%;'>Pay To</div>").appendTo($header),
		$amountHeader = $("<div class='fav-header-col' style='width: 20%;'>Amount</div>").appendTo($header),
		$reasonHeader = $("<div class='fav-header-col' style='width: 20%;'>Reason</div>").appendTo($header),
		$dateHeader = $("<div class='fav-header-col' style='width: 20%;'>Date | Time</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='PastPaymentsFilterList' />").appendTo($dataContainer),
		$li, $row, $account, $bene, $amount, $reason, $date;

	$.each(_pastfastpayments, function(x) {
		$li = $("<li />").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li),
			$account = $("<div class='dialog-search-data-col' style='width: 20%; line-height: normal; padding-top: 12px;'><span>" + this.accountname + "<br />" + this.accountnumber + "</span></div>").appendTo($row),
			$bene = $("<div class='dialog-search-data-col' style='width: 20%; line-height: normal; padding-top: 20px;'><span>" + this.bene + "</span></div>").appendTo($row),
			$amount = $("<div class='dialog-search-data-col' style='width: 20%; line-height: normal; padding-top: 20px;'><span style='color: #009900;'> AUD $" + addCommas(Number(this.amount.replace(/[^0-9\.]+/g, "")).toFixed(2)) + "</span></div>").appendTo($row),
			$reason = $("<div class='dialog-search-data-col' style='width: 20%; line-height: normal; padding-top: 20px;'><span>" + this.reason + "</span></div>").appendTo($row),
			$date = $("<div class='dialog-search-data-col' style='width: 20%; line-height: normal; padding-top: 20px;'><span>" + this.date + " at " + this.time + "</span></div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "ViewPastPayments",
		title: "View Recent Payments",
		size: "full-screen",
		icon: "<i class='fa fa-list-alt'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#PastPaymentsFilterInput").fastLiveFilter('#PastPaymentsFilterList');
}

function findFastPayAccounts(_target, id) {

	var $wrapper = $("<div class='widget-fast-payments wrapper' />");

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='SelectFastPayAccountFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearAccountsFilter").show()
			} else {
				$("#clearAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#SelectFastPayAccountFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$nameHeader = $("<div class='fav-header-col' style='width: 50%;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='fav-header-col' style='width: 50%;'>Account Number</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='SelectFastPayAccountFilterList' />").appendTo($dataContainer),
		$li, $row, $name, $number;
	$.each(_fastpayaccounts, function() {
		$li = $("<li data-name='" + this.name + "' data-number='" + this.number + "' />").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.closest("li");
				}
				$("#account" + id).val($target.attr("data-name") + " - " + $target.attr("data-number"));
				dialogHider(_dialog);
			}),
			$name = $("<div class='dialog-search-data-col' style='width: 50%;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='dialog-search-data-col' style='width: 50%;'>" + this.number + "</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "SelectFastPayAccount",
		title: "Select Account",
		size: "medium",
		icon: "<i class='fa fa-search'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#SelectFastPayAccountFilterInput").fastLiveFilter('#SelectFastPayAccountFilterList');
}

function findFastPayBene(_target, id) {

	/* set _widget to be the widget data and settings from the widgetDataArray */
	_widget = findWidgetData(id);

	var $wrapper = $("<div class='widget-fast-payments wrapper' />");

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='SelectFastPayBeneFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a beneficiary...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearAccountsFilter").show()
			} else {
				$("#clearAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#SelectFastPayBeneFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$nameHeader = $("<div class='fav-header-col' style='width: 30%;'>Name</div>").appendTo($header),
		$emailHeader = $("<div class='fav-header-col' style='width: 40%;'>Email</div>").appendTo($header),
		$phoneHeader = $("<div class='fav-header-col' style='width: 30%;'>Phone</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='SelectFastPayBeneFilterList' />").appendTo($dataContainer),
		$li, $row, $name, $email, $phone;
	$.each(_fastpaybenes, function() {
		$li = $("<li data-name='" + this.name + "' data-email='" + this.email + "' data-phone='" + this.phone + "' />").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.closest("li");
				}

				if (_widget.settings[0].nppOption == 'email') {
					$("#bene" + id).val($target.attr("data-email"));
				} else {
					$("#bene" + id).val($target.attr("data-phone"));
				}
				dialogHider(_dialog);
			}),
			$name = $("<div class='dialog-search-data-col' style='width: 30%;'>" + this.name + "</div>").appendTo($row),
			$email = $("<div class='dialog-search-data-col' style='width: 40%;'>" + this.email + "</div>").appendTo($row),
			$phone = $("<div class='dialog-search-data-col' style='width: 30%;'>" + this.phone + "</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "SelectFastPayBene",
		title: "Pay To",
		size: "medium",
		icon: "<i class='fa fa-search'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#SelectFastPayBeneFilterInput").fastLiveFilter('#SelectFastPayBeneFilterList');
}

function buildFastPayments(id) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length) {
		_widget.settings = [{
			nppOption: "email"
		}];
	}

	/* input values */
	var _account, _bene, _amount;

	/* pay option setting */
	var nppOptionSetting = function(e) {
		e.preventDefault();
		var $target = $(e.target),
			_nppOption = _widget.settings[0].nppOption,
			_setting;

		if ($target.nodeName == "I") {
			$target = $target.parent("a");
		}

		_setting = $target.attr("data-option");

		if (_setting != _nppOption) {
			if ($target.attr("id") == "nppEmail") {
				$("#nppPhone").children("i").removeClass("fa-check");
				$target.children("i").addClass("fa-check");
			} else if ($target.attr("id") == "nppPhone") {
				$("#nppEmail").children("i").removeClass("fa-check");
				$target.children("i").addClass("fa-check");
			}
			_widget.settings[0].nppOption = _setting;
			store.set('saved_widget_data', widgetDataArray);
			$beneInput.val('');
		}
	}

	/* clear form function */
	var clearFastPayForm = function() {
		$accountInput.val('');
		$beneInput.val('');
		$amountInput.val('');
		$reasonInput.val('');
	};

	/* reset the payment form */
	var resetFastPayment = function() {
		$successMessage.removeClass("show-message");
		setTimeout(function() {
			$successMessage.empty().remove();
			$accountInput.val('');
			$beneInput.val('');
			$amountInput.val('');
			$reasonInput.val('');
			$dataForm.show();
			backToForm();
		}, 500);
	}

	/* error check function */
	var errorCheck = function() {};

	/* review and submit function */
	var continueFastPayment = function() {

		/* add working class */
		$widget.children("div.widget-container").addClass("working");

		/* get input values */
		_account = $accountInput.val(),
			_bene = $beneInput.val().replace(/\n/g, "<br />"),
			_amount = addCommas(Number($amountInput.val().replace(/[^0-9\.]+/g, "")).toFixed(2)),
			_reason = $reasonInput.val();

		/* setup timeout function */
		setTimeout(function() {

			/* hide inputs and search */
			$accountInput.hide();
			$accountSearch.hide();
			$beneInput.hide();
			$beneSearch.hide();
			$currencyDiv.hide();
			$amountInput.hide();
			$reasonInput.hide();
			$payOption.hide();

			/* show text and add values */
			$fastPayHeading.html("Review and confirm payment details");
			$accountLabel.html("Account");
			$accountDataText.empty().html(_account).show();
			$beneDataText.empty().html(_bene).show();
			$amountDataText.empty().html("AUD $" + _amount).show();
			$reasonDataText.empty().html(_reason).show();

			/* empty and attach buttons */
			$buttonDiv.empty();
			$backButton.appendTo($buttonDiv).on('click', backToForm);
			$submitButton.appendTo($buttonDiv).on('click', successfulSubmit);

			$widget.children("div.widget-container").removeClass("working");

		}, 500);
	};

	/* back to form function */
	var backToForm = function() {

		/* hide text */
		$accountDataText.hide();
		$beneDataText.hide();
		$amountDataText.hide();
		$reasonDataText.hide();

		/* show inputs and search */
		$fastPayHeading.html("Enter NPP Payment Details");
		$accountLabel.html("Select Account");
		$accountInput.show();
		$accountSearch.show();
		$beneInput.show();
		$beneSearch.show();
		$currencyDiv.show();
		$amountInput.show();
		$reasonInput.show();
		$payOption.show();

		/* clear and attach buttons */
		$buttonDiv.empty();
		$clearButton.appendTo($buttonDiv).on("click", clearFastPayForm);
		$continueButton.appendTo($buttonDiv).on("click", continueFastPayment);
	};

	/* success function */
	var successfulSubmit = function() {

		/* add working class */
		$widget.children("div.widget-container").addClass("working");

		var $message = $("<div class='message-content' />").appendTo($successMessage),
			$icon = $("<i class='fa fa-check-circle fa-lg' style='font-size: 200%; vertical-align: middle;'></i>").appendTo($message),
			$header = $("<span style='margin: 0 10px; vertical-align: middle; font-weight: bold;'>Your payment has been successfully processed</span>").appendTo($message),
			$summary = $("<div class='form-section' style='margin-top: 10px !important;' />").appendTo($message),
			$row = $("<div class='row' />").appendTo($summary),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Account</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<div class='data-text'>" + _account + "</div>").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($summary),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Pay To</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<div class='data-text'>" + _bene + "</div>").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($summary),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Amount</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<div class='data-text'> AUD $" + _amount + "</div>").appendTo($dataCol);
		$row = $("<div class='row' />").appendTo($summary),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Reason</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<div class='data-text'>" + _reason + "</div>").appendTo($dataCol);
		$row = $("<div class='row' />").appendTo($summary),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Date &amp; Time</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<div class='data-text'>" + smartDates('today') + " at " + timeFormatter() + "</div>").appendTo($dataCol);


		$successMessage.appendTo($content);

		setTimeout(function() {

			$widget.children("div.widget-container").removeClass("working");

			$dataForm.hide();
			$successMessage.addClass("show-message");

			/* empty and attach buttons */
			$buttonDiv.empty();
			$okButton.appendTo($buttonDiv).on('click', resetFastPayment);



		}, 750);
	};

	/* account inputs and search */
	var $accountInput = $("<input type='text' style='width: 90%; max-width: 90%;' id='account" + id + "' value='' placeholder='Type in an account name or number' />").autocomplete({
		autoFocus: false,
		delay: 0,
		minLength: 0,
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_fastpaytypeahead, extractLast(request.term));
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				this.value = "";
				return false;
			} else {
				this.value = ui.item.value;
				return false;
			}
		},
		change: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(_fastpaytypeahead, function() {
				if (this.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this;
					return false;
				}
			});
			$(this).val(matchie);
			if (!valid) {
				$(this).val("");
				return false;
			}
		}
	}).on("focus", function() {
		$(this).one("mouseup", function() {
			$(this).select();
		});
	}).on("click", function() {
		$(this).autocomplete("search", "");
	});
	var $accountSearch = $("<a href='javascript:void(0)' style='color: #007dba;' title='Find An Account'><i class='fa fa-search fa-fw'></i></a>").on("click", function(e) {
		e.preventDefault();
		findFastPayAccounts($(e.target), id)
	});
	var $accountDataText = $("<div class='data-text' style='font-size: 100%; display: none;' />");

	/* bene inputs and search */
	var $beneInput = $("<input type='text' style='width: 90%; max-width: 90%;' value='' id='bene" + id + "' />").autocomplete({
		autoFocus: false,
		delay: 0,
		minLength: 0,
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_fastpaybenes, extractLast(request.term));
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		focus: function() {
			return false;
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				this.value = "";
				return false;
			} else {
				if (_widget.settings[0].nppOption == 'email') {
					this.value = ui.item.email;
				} else {
					this.value = ui.item.phone;
				}
				return false;
			}
		},
		change: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(_fastpaybenes, function() {
				if (_widget.settings[0].nppOption == 'email') {
					if (this.email.toLowerCase() == matcher.toLowerCase()) {
						valid = true;
						matchie = this.email;
						return false;
					}
				} else {
					if (this.phone.toLowerCase() == matcher.toLowerCase()) {
						valid = true;
						matchie = this.phone;
						return false;
					}
				}
			});
			$(this).val(matchie);
			if (!valid) {
				$(this).val("");
				return false;
			}
		}
	}).on("focus", function() {
		$(this).one("mouseup", function() {
			$(this).select();
		});
	}).on("click", function() {
		$(this).autocomplete("search", "");
	});
	var $beneSearch = $("<a href='javascript:void(0)' style='color: #007dba;' title='Find A Payee'><i class='fa fa-search fa-fw'></i></a>").on("click", function(e) {
		e.preventDefault();
		findFastPayBene($(e.target), id)
	});
	var $beneDataText = $("<div class='data-text' style='font-size: 100%; display: none;' />");

	/* amount input */
	var $currencyDiv = $("<div class='data-text' style='position: absolute; margin: 1px 0 0 1px; line-height: 33px; padding: 0 10px; z-index: 1; background: #fbfbfb; border-right: 1px solid #a5a5a5; -webit-border-radius: 4px 0 0 4px; -moz-border-radius: 4px 0 0 4px; border-radius: 4px 0 0 4px;'>AUD $</div>");
	var $amountInput = $("<input type='text' style='width: 90%; max-width: 90%; text-indent: 55px;' id='amount" + id + "' value='' />").keydown(function(e) {
		// Allow: backspace, delete, tab, escape, enter and . and ,
		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 188, 190]) !== -1 ||
			// Allow: Ctrl+A
			(e.keyCode == 65 && e.ctrlKey === true) ||
			// Allow: Ctrl+C
			(e.keyCode == 67 && e.ctrlKey === true) ||
			// Allow: Ctrl+X
			(e.keyCode == 88 && e.ctrlKey === true) ||
			// Allow: home, end, left, right
			(e.keyCode >= 35 && e.keyCode <= 39)) {
			// let it happen, don't do anything
			return;
		}
		// Ensure that it is a number and stop the keypress
		if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
			e.preventDefault();
		}
	}).on("focus", function() {
		$(this).one("mouseup", function() {
			$(this).select();
		});
	});
	var $amountDataText = $("<div class='data-text' style='font-size: 100%; display: none;' />");

	/* reason input */
	var $reasonInput = $("<input type='text' style='width: 90%; max-width: 90%;' value='' id='reason'" + id + "' />");
	var $reasonDataText = $("<div class='data-text' style='font-size: 100%; display: none;' />");

	/* buttons */
	var $buttonDiv = $("<div class='fastpay-buttons' />");
	var $clearButton = $("<a href='javascript: void(0)' class='form-button' style='margin-top: 12px' title='Clear'><i class='fa fa-times-circle fa-fw'></i><span>Clear</span></a>");
	var $continueButton = $("<a href='javascript: void(0)' class='form-button primary' style='margin-top: 12px;' title='Continue'><i class='fa fa-chevron-circle-right fa-fw'></i><span>Continue</span></a>");
	var $backButton = $("<a href='javascript: void(0)' class='form-button' style='margin-top: 12px;' title='Back'><i class='fa fa-chevron-circle-left fa-fw'></i><span>Back</span></a>");
	var $submitButton = $("<a href='javascript: void(0)' class='form-button primary' style='margin-top: 12px;' title='Submit Payment'><i class='fa fa-check-circle fa-fw'></i><span>Submit</span></a>");
	var $okButton = $("<a href='javascript:void(0)' class='form-button primary' style='margin-top: 12px;' title='Ok'><i class='fa fa-check fa-fw'></i><span>Ok</span></a>");

	/* success message */
	var $successMessage = $("<div class='fastpay-message' />");

	/* build the widget html */
	var $div = $("<div class='fastpay-container' id='fastpayform" + id + "' />"),
		$content = $("<div class='fastpay-content' />").appendTo($div),
		$dataForm = $("<div />").appendTo($content),
		$fastPayHeading = $("<div class='section-heading'>Enter NPP Payment Details</div>").appendTo($dataForm),
		$formSection = $("<div class='form-section top-label' />").appendTo($dataForm),
		/* account section */
		$row = $("<div class='row' />").appendTo($formSection),
		$labelCol = $("<div class='label-column' />").appendTo($row),
		$accountLabel = $("<label>Select Account</label>").appendTo($labelCol),
		$accountDataCol = $("<div class='data-column' />").appendTo($row);
	$accountInput.appendTo($accountDataCol);
	$accountSearch.appendTo($accountDataCol);
	$accountDataText.appendTo($accountDataCol);
	/* bene section */
	var $row = $("<div class='row' />").appendTo($formSection),
		$labelCol = $("<div class='label-column' style='width: 90%;' />").appendTo($row),
		$benelabel = $("<label>Pay To</label>").appendTo($labelCol),
		$payOption = $("<div style='position: absolute; top: 2px; right: 0; font-size: 80%;' />").appendTo($labelCol);
	if (_widget.settings[0].nppOption == 'email') {
		var $emailOption = $("<a href='javascript:void(0)' id='nppEmail' data-option='email' title='Pay to an email address' style='text-decoration: none; color: #007dba;'><i class='fa fa-check fa-fw'></i> Email</a>").appendTo($payOption).on("click", nppOptionSetting),
			$spacer = $("<span>&nbsp;&nbsp;&nbsp;</span>").appendTo($payOption),
			$phoneOption = $("<a href='javascript:void(0)' id='nppPhone' data-option='phone' title='Pay to a phone number' style='text-decoration: none; color: #007dba;'><i class='fa fa-fw'></i> Phone</a>").appendTo($payOption).on("click", nppOptionSetting);
	} else {
		var $emailOption = $("<a href='javascript:void(0)' id='nppEmail' data-option='email' title='Pay to an email address' style='text-decoration: none; color: #007dba;'><i class='fa fa-fw'></i> Email</a>").appendTo($payOption).on("click", nppOptionSetting),
			$spacer = $("<span>&nbsp;&nbsp;&nbsp;</span>").appendTo($payOption),
			$phoneOption = $("<a href='javascript:void(0)' id='nppPhone' data-option='phone' title='Pay to a phone number' style='text-decoration: none; color: #007dba;'><i class='fa fa-check fa-fw'></i> Phone</a>").appendTo($payOption).on("click", nppOptionSetting);
	}
	var $beneDataCol = $("<div class='data-column' />").appendTo($row);
	$beneInput.appendTo($beneDataCol).data("autocomplete")._renderItem = function(ul, item) {
		if (item.value == "No Matches Found") {
			return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
		} else {
			return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br>" + item.email + "<br />" + item.phone + "</a>").appendTo(ul);
		}
	};
	$beneSearch.appendTo($beneDataCol);
	$beneDataText.appendTo($beneDataCol);
	/* amount section */
	var $row = $("<div class='row' />").appendTo($formSection),
		$labelCol = $("<div class='label-column' />").appendTo($row),
		$amountlabel = $("<label>Amount</label>").appendTo($labelCol),
		$amountDataCol = $("<div class='data-column' />").appendTo($row);
	$currencyDiv.appendTo($amountDataCol);
	$amountInput.appendTo($amountDataCol);
	$amountDataText.appendTo($amountDataCol);
	/* reason section */
	var $row = $("<div class='row' />").appendTo($formSection),
		$labelCol = $("<div class='label-column' />").appendTo($row),
		$reasonlabel = $("<label>Reason</label>").appendTo($labelCol),
		$reasonDataCol = $("<div class='data-column' />").appendTo($row);
	$reasonInput.appendTo($reasonDataCol);
	$reasonDataText.appendTo($reasonDataCol);
	/* button section */
	$buttonDiv.appendTo($div);
	$clearButton.appendTo($buttonDiv).on('click', clearFastPayForm);
	$continueButton.appendTo($buttonDiv).on('click', continueFastPayment);

	return $div;
}



/* card current balance widget */
var card_current_data = {
	reference_currency: "AUD",
	data: [{
		company: "AUS Farms",
		country: "Australia",
		currency: "AUD",
		number: "45799535599426476785",
		type: "Commercial Card",
		amount: 8146.00,
		minpayamount: 400.00,
		duedate: smartDates("randomfuture"),
		records: 5,
		retrieved: 3
	}, {
		company: "BSW Farms",
		country: "Australia",
		currency: "AUD",
		number: "76537172394632723511",
		type: "Commercial Card",
		amount: 4230.00,
		minpayamount: 100.00,
		duedate: smartDates("randomfuture"),
		records: 10,
		retrieved: 9
	}, {
		company: "QLD Farms",
		country: "Australia",
		currency: "AUD",
		number: "35152124564795888267",
		type: "Commercial Card",
		amount: 5051.00,
		minpayamount: 100.00,
		duedate: smartDates("randomfuture"),
		records: 2,
		retrieved: 2
	}, {
		company: "NZ Farms",
		country: "New Zealand",
		currency: "NZD",
		number: "74594275227143128457",
		type: "Commercial Card",
		amount: 7230.00,
		minpayamount: 300.00,
		duedate: smartDates("randomfuture"),
		records: 4,
		retrieved: 4
	}, {
		company: "TAS Farms",
		country: "New Zealand",
		currency: "NZD",
		number: "88915329238828874832",
		type: "Commercial Card",
		amount: 2010.00,
		minpayamount: 50.00,
		duedate: smartDates("randomfuture"),
		records: 6,
		retrieved: 5
	}, {
		company: "Build Farms",
		country: "Australia",
		currency: "AUD",
		number: "52271433899426473114",
		type: "Commercial Card",
		amount: 400.00,
		minpayamount: 40.00,
		duedate: smartDates("randomfuture"),
		records: 2,
		retrieved: 1
	}]
};

function showCardCurrentBalancesSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		_widget.settings = [{
			chartOptions: {
				chartType: $charttypeElement.val(),
				refCCY: $refByElement.val()
			}
		}];
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		buildCardCurrentBalances(id, true);
	}

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-accounts data-form' />"),

		/* build the view settings */
		$viewSectionHeading = $("<div class='section-heading'>View Settings</div>").appendTo($settings),
		$downloadSection = $("<div class='form-section' />").appendTo($settings),

		/* Chart Type Row */
		$charttypeRow = $("<div class='row' />").appendTo($downloadSection),
		$charttypeLabelCol = $("<div class='label-column' />").appendTo($charttypeRow),
		$charttypeLabel = $("<label>Chart Type</label>").appendTo($charttypeLabelCol),
		$charttypeDataCol = $("<div class='data-column' />").appendTo($charttypeRow),
		$charttypeCustomSelect = $("<div class='custom-select' />").appendTo($charttypeDataCol),
		$charttypeElement = $("<select id='" + _widget.id + "-type'><option value='bar'>Bar</option><option value='pie'>Pie</option></select>").appendTo($charttypeCustomSelect).val(_widget.settings[0].chartOptions.chartType),

		/* Reference Currency Option */
		$refByRow = $("<div class='row' />").appendTo($downloadSection),
		$refByLabelCol = $("<div class='label-column' />").appendTo($refByRow),
		$refByLabel = $("<label>Reference Currency</label>").appendTo($refByLabelCol),
		$refByDataCol = $("<div class='data-column' />").appendTo($refByRow),
		$refByCustomSelect = $("<div class='custom-select' />").appendTo($refByDataCol),
		$refByElement = $("<select id='" + _widget.id + "-type'><option value='Default'>Default</option><option value='AUD'>AUD</option><option value='NZD'>NZD</option></select>").appendTo($refByCustomSelect).val(_widget.settings[0].chartOptions.refCCY)

	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Cards - Current Balances Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function finalizeCardCurrentBalances(id, _settings) {

	var anz_colours = ["#007DBA", "#5BC6E8", "#747679", "#394A58", "#AA9C8F", "#DF7A00", "#B9CCC3", "#D3CD8B", "#EDE8C4", "#FDC82F", "#C6DFEA", "#00C6D7", "#B9C9D0", "#589199"];
	var chart_data = [];
	var sum_total_balances = 0,
		number_records = 0,
		total_records = 0;

	if (_settings.chartOptions.refCCY != "Default") {
		card_current_data.reference_currency = _settings.chartOptions.refCCY;
	} else {
		card_current_data.reference_currency = "AUD";
	}

	Highcharts.setOptions({
		chart: {
			style: {
				fontFamily: 'Myriad Pro, Helvetica, Arial, sans-serif;'
			}
		}
	});

	//Generic Tooltip Function
	var generate_tooltip = function() {

		var tooltipstring = "<span class='card-balances-tooltip'><span class='tooltip-header'>" + this.point.company + "</span>";
		tooltipstring += "<div class='tooltop-section'><span class='tooltip-label'>" + this.point.number + " (" + this.point.currency + ")</span></div><div class='tooltip-seperator'></div>";
		tooltipstring += "<div class='tooltip-section'><span class='tooltip-label'>Minimum Payment Due:</span><span class='tooltip-amt'>$" + Highcharts.numberFormat(this.point.minpayamount, 2, ".", ",") + "</span></div>";
		tooltipstring += "<div class='tooltip-section'><span class='tooltip-label'>Payment Due Date:</span><span class='tooltip-amt'>" + this.point.duedate + "</span></div>";


		if (this.point.currency != card_current_data.reference_currency) {
			if (this.point.currency == "AUD") {
				var rate = 1.91
			} else if (this.point.currency == "NZD") {
				var rate = 0.91
			}
			tooltipstring += "<span class='tooltip-cur-sec'><div class='tooltip-seperator'></div><div class='tooltip-section'><span class='tooltip-label'>" + this.point.currency + " - " + card_current_data.reference_currency + " Rate:</span><span class='tooltip-amt'>" + rate + "</span></div></span>";
		}

		if (this.point.records != this.point.retrieved) {
			tooltipstring += "<div class='tooltip-seperator'></div><span class='tooltip-acc-ret'>" + (this.point.records - this.point.retrieved) + " of " + this.point.records + " balances not retrieved</span>";
		}

		tooltipstring += "<div class='tooltip-seperator'></div><span class='tooltip-acc-ret'>Amounts retrieved on " + smartDates("today") + " at " + timeFormatter() + "</span>";

		return tooltipstring + "</span>";
	}

	if (_settings.chartOptions.chartType == "bar") {

		var categories = [];

		var cb_data = card_current_data.data;

		cb_data.sort(function(a, b) {
			var aName, bName;
			if (_settings.chartOptions.groupBy == "company") {
				aName = a.company;
				bName = b.company;
			}
			return ((aName < bName) ? -1 : ((aName > bName) ? 1 : 0));
		});

		$.each(cb_data, function(index) {

			var filterOption = card_current_data.data[index].company,
				cd_index;

			var item = $.grep(chart_data, function(e, i) {
				if (e.name == filterOption) {
					cd_index = i;
					return true;
				}
			});

			if (item.length == 0) {
				$.each(chart_data, function(i, d) {
					chart_data[i].data.push(null);
				});
				cd_index = chart_data.push({
					name: filterOption,
					index: chart_data.length,
					data: Array.apply(null, new Array(chart_data.length)).map(function() {
						return null;
					}).concat({
						type: _settings.chartOptions.groupBy,
						name: filterOption,
						y: 0,
						company: "",
						number: "",
						currency: "",
						duedate: "",
						minpayamount: 0,
						records: 0,
						retrieved: 0
					}),
					color: anz_colours[chart_data.length % anz_colours.length]
				}) - 1;
			}
			chart_data[cd_index].data[chart_data[cd_index].index].y = card_current_data.data[index].amount;
			chart_data[cd_index].data[chart_data[cd_index].index].company = card_current_data.data[index].company;
			chart_data[cd_index].data[chart_data[cd_index].index].number = card_current_data.data[index].number;
			chart_data[cd_index].data[chart_data[cd_index].index].currency = card_current_data.data[index].currency;
			chart_data[cd_index].data[chart_data[cd_index].index].minpayamount = card_current_data.data[index].minpayamount;
			chart_data[cd_index].data[chart_data[cd_index].index].duedate = card_current_data.data[index].duedate;
			chart_data[cd_index].data[chart_data[cd_index].index].records = card_current_data.data[index].records;
			chart_data[cd_index].data[chart_data[cd_index].index].retrieved = card_current_data.data[index].retrieved;
			number_records += card_current_data.data[index].retrieved;
			total_records += card_current_data.data[index].records;
			sum_total_balances += card_current_data.data[index].amount;
		});

		$.each(chart_data, function(i, d) {
			categories.push(d.name);
		});

		$("#HC_" + id).highcharts({
			chart: {
				type: 'column'
			},
			title: {
				text: null
			},
			legend: {
				enabled: false
			},
			xAxis: {
				categories: categories
			},
			yAxis: {
				gridLineColor: "#ebebeb",
				title: {
					enabled: false
				},
				labels: {
					overflow: 'justify'
				}
			},
			plotOptions: {
				column: {
					borderWidth: 0,
					stacking: 'normal',
					animation: {
						duration: 250
					},
					groupPadding: 0.05,
					dataLabels: {
						enabled: true,
						verticalAlign: "top",
						y: -22,
						formatter: function() {
							if (this.percentage > 0) return '$' + Highcharts.numberFormat(this.y);
						},
						style: {
							color: '#333',
							fontWeight: 'bold',
							textShadow: '0px 0px 3px white'
						}
					},
					pointPadding: 0
				}
			},
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			series: chart_data,
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	} else if (_settings.chartOptions.chartType == "pie") {

		$.each(card_current_data.data, function(index) {

			var filterOption = card_current_data.data[index].company,
				cd_index;

			var item = $.grep(chart_data, function(e, i) {
				if (e.name == filterOption) {
					cd_index = i;
					return true;
				}
			});

			if (item.length == 0) {
				cd_index = chart_data.push({
					type: _settings.chartOptions.groupBy,
					name: filterOption,
					y: 0,
					company: "",
					number: "",
					currency: "",
					duedate: "",
					minpayamount: 0,
					records: 0,
					retrieved: 0,
					negative: false,
					sign: "",
					color: anz_colours[chart_data.length % anz_colours.length]
				}) - 1;
			}

			chart_data[cd_index].y = card_current_data.data[index].amount;
			chart_data[cd_index].company = card_current_data.data[index].company;
			chart_data[cd_index].number = card_current_data.data[index].number;
			chart_data[cd_index].currency = card_current_data.data[index].currency;
			chart_data[cd_index].minpayamount = card_current_data.data[index].minpayamount;
			chart_data[cd_index].duedate = card_current_data.data[index].duedate;
			chart_data[cd_index].records = card_current_data.data[index].records;
			chart_data[cd_index].retrieved = card_current_data.data[index].retrieved;
			number_records += card_current_data.data[index].retrieved;
			total_records += card_current_data.data[index].records;
			sum_total_balances += card_current_data.data[index].amount;
		});

		var error_colours = ["#CA002A", "#FF1100", "#A12830", "#DB1F2A", "#DB4E4E"];
		//invert negative amounts so they show properly

		$.each(chart_data, function(i, d) {
			if (d.y < 0) {
				chart_data[i].y = -chart_data[i].y;
				chart_data[i].color = error_colours[i % error_colours.length];
				chart_data[i].negative = true;
				chart_data[i].sign = "-"
			}
		});

		chart_data.sort(function(a, b) {
			if (a.negative != b.negative) return a.negative ? 1 : -1;
			if (a.negative) return ((a.y < b.y) ? -1 : ((a.y > b.y) ? 1 : 0));
			return ((a.y < b.y) ? 1 : ((a.y > b.y) ? -1 : 0));
		});

		$("#HC_" + id).highcharts({
			chart: {
				type: "pie",
				plotBackgroundColor: null,
				plotBorderWidth: 0,
				plotShadow: false
			},
			title: {
				text: false,
				align: 'center',
				verticalAlign: 'middle',
				style: {
					color: "#99b3c1",
					fontSize: "14px"
				},
				y: 0
			},
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			plotOptions: {
				pie: {
					shadow: false,
					borderWidth: 1,
					size: '80%',
					showInLegend: false,
					innerSize: '70%',
					data: chart_data
				}
			},
			series: [{
				type: 'pie',
				name: 'Net Position',
				animation: {
					duration: 250
				},
				dataLabels: {
					enabled: true,
					distance: 10,
					softConnector: false,
					connectorWidth: 1,
					verticalAlign: 'top',
					style: {
						fontWeight: 'bold',
						color: '#333',
						textShadow: '0px 0px 3px white'
					},
					formatter: function() {
						return this.point.name + " $" + this.point.sign + Highcharts.numberFormat(this.y)
					}
				}
			}],
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	}

	//set the total balances and missing records icon
	$("#" + id).find(".sum-total").show().find(".sum-amount").html(card_current_data.reference_currency + " " + Highcharts.numberFormat(sum_total_balances, 2, ".", ","));
	if (total_records > number_records) $("#" + id).find(".accounts-missing").css({
		"display": "inline-block"
	}).attr("title", number_records + " of " + total_records + " accounts retrieved.");
}

function buildCardCurrentBalances(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length || _widget.settings == "undefined") {
		_widget.settings = [{
			chartOptions: {
				chartType: "bar",
				groupBy: "company",
				refCCY: "Default"
			}
		}];
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	var $content = $("<div style='width:100%; height:100%;'></div>");
	var $highchart = $("<div class='highchart' id='HC_" + id + "' \>").appendTo($content);
	var $totalbalances = $("<div class='sum-total'><div class='sum-label'>Total Current Balance</div><div class='sum-amount'></div><i class='fa fa-exclamation-triangle accounts-missing' title='Some account data was not retrieved'></i></div>").appendTo($content);
	var $disclaimericon = $("<div class='disclaimer-icon'><i class='fa fa-exclamation-circle fa-fw'></i></div>").appendTo($content).on("mouseover", function() {
		$("div.disclaimer-text").show();
	}).on("mouseout", function() {
		$("div.disclaimer-text").hide();
	});
	var $disclaimerdiv = $("<div class='disclaimer-text'></div>").appendTo($content);
	var $valuenote = $("<div>* Unless noted otherwise, all values are accurate as at end of previous business day.</div>").appendTo($disclaimerdiv);
	var $indicativenote = $("<div>* Indicative values only, should not be solely relied upon to make decisions or set policy.</div>").appendTo($disclaimerdiv);
	var $exchangenote = $("<div>* Exchange rates used to convert balances to a reference currency are indicative only.</div>").appendTo($disclaimerdiv);
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($content);
		finalizeCardCurrentBalances(id, _settings[0]);
	} else {
		setTimeout(function() {
			finalizeCardCurrentBalances(id, _settings[0]);
		}, 250);
		return $content;
	}
}



/* card top spend widget */
var card_top_spend_data = {
	reference_currency: "AUD",
	supplier_data: [{
		name: "Visy Packing",
		y: 50500.00
	}, {
		name: "QTS Airlines",
		y: 45000.00
	}, {
		name: "VRG Manufacturing",
		y: 25000.00
	}, {
		name: "HR Car Rentals",
		y: 15000.00
	}, {
		name: "Bunnings LLC",
		y: 8500.00
	}, {
		name: "LL Catering Services",
		y: 4000.00
	}, {
		name: "Air Supplies",
		y: 1500.00
	}, {
		name: "US Airway Services",
		y: 12000.00
	}, {
		name: "Shipping Inc.",
		y: 6000.00
	}, {
		name: "Tech Support Specialists",
		y: 1500.00
	}],
	mcc_data: [{
		name: "Food Services",
		y: 5500.00
	}, {
		name: "Retail",
		y: 7000.00
	}, {
		name: "Car Rental",
		y: 15000.00
	}, {
		name: "Manufacturing",
		y: 75500.00
	}, {
		name: "Airlines",
		y: 45000.00
	}, {
		name: "Services",
		y: 13500.00
	}, {
		name: "Shipping",
		y: 7500.00
	}]
};

function showCardTopSpendSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id"),

		/* set _widget to be the widget data and settings from the widgetDataArray */
		_widget = findWidgetData(id);

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		_widget.settings = [{
			chartOptions: {
				chartType: $charttypeElement.val(),
				dataSetting: $groupByElement.val(),
				refCCY: $refByElement.val()
			}
		}];
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		buildCardTopSpend(id, true);
	}

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-accounts data-form' />"),

		/* build the view settings */
		$viewSectionHeading = $("<div class='section-heading'>View Settings</div>").appendTo($settings),
		$downloadSection = $("<div class='form-section' />").appendTo($settings),

		/* Chart Type Row */
		$charttypeRow = $("<div class='row' />").appendTo($downloadSection),
		$charttypeLabelCol = $("<div class='label-column' />").appendTo($charttypeRow),
		$charttypeLabel = $("<label>Chart Type</label>").appendTo($charttypeLabelCol),
		$charttypeDataCol = $("<div class='data-column' />").appendTo($charttypeRow),
		$charttypeCustomSelect = $("<div class='custom-select' />").appendTo($charttypeDataCol),
		$charttypeElement = $("<select id='" + _widget.id + "-type'><option value='bar'>Bar</option><option value='pie'>Pie</option></select>").appendTo($charttypeCustomSelect).val(_widget.settings[0].chartOptions.chartType),

		/* Data Option */
		$groupByRow = $("<div class='row' />").appendTo($downloadSection),
		$groupByLabelCol = $("<div class='label-column' />").appendTo($groupByRow),
		$groupByLabel = $("<label>Group By</label>").appendTo($groupByLabelCol),
		$groupByDataCol = $("<div class='data-column' />").appendTo($groupByRow),
		$groupByCustomSelect = $("<div class='custom-select' />").appendTo($groupByDataCol),
		$groupByElement = $("<select id='" + _widget.id + "-type'><option value='suppliers'>Suppliers</option><option value='mcc'>MCC</option></select>").appendTo($groupByCustomSelect).val(_widget.settings[0].chartOptions.dataSetting)

	/* Reference Currency Option */
	$refByRow = $("<div class='row' />").appendTo($downloadSection),
		$refByLabelCol = $("<div class='label-column' />").appendTo($refByRow),
		$refByLabel = $("<label>Reference Currency</label>").appendTo($refByLabelCol),
		$refByDataCol = $("<div class='data-column' />").appendTo($refByRow),
		$refByCustomSelect = $("<div class='custom-select' />").appendTo($refByDataCol),
		$refByElement = $("<select id='" + _widget.id + "-type'><option value='Default'>Default</option><option value='AUD'>AUD</option><option value='NZD'>NZD</option></select>").appendTo($refByCustomSelect).val(_widget.settings[0].chartOptions.refCCY)

	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Cards - Top Spend Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function finalizeCardTopSpend(id, _settings) {

	//Generic Tooltip Function
	var generate_tooltip = function() {
		var tooltipstring = "<span class='card-balances-tooltip'><span class='tooltip-header'>" + this.point.name + "</span>";
		tooltipstring += "<div class='tooltop-section'><span class='tooltip-label'>$" + Highcharts.numberFormat(this.point.y, 2, ".", ",") + "</span></div>";
		return tooltipstring + "</span>";
	}

	/* sort the data by amount value */
	card_top_spend_data.supplier_data.sort(function(a, b) {
		return ((b.y < a.y) ? -1 : ((b.y > a.y) ? 1 : 0));
	});

	card_top_spend_data.mcc_data.sort(function(a, b) {
		return ((b.y < a.y) ? -1 : ((b.y > a.y) ? 1 : 0));
	});

	Highcharts.setOptions({
		chart: {
			style: {
				fontFamily: 'Myriad Pro, Helvetica, Arial, sans-serif;'
			}
		},
		colors: ["#007DBA", "#747679", "#5BC6E8", "#C6DFEA", "#00C6D7", "#B9C9D0", "#589199", "#394A58", "#AA9C8F", "#DF7A00", "#B9CCC3", "#D3CD8B", "#EDE8C4", "#FDC82F"]
	});

	var _data, _name;
	if (_settings.chartOptions.dataSetting == 'suppliers') {
		_data = card_top_spend_data.supplier_data;
		_name = "Suppliers";
	} else if (_settings.chartOptions.dataSetting == 'mcc') {
		_data = card_top_spend_data.mcc_data;
		_name = "MCC";
	}

	if (_settings.chartOptions.chartType == 'pie') {
		$("#HC_" + id).highcharts({
			chart: {
				type: "pie",
				plotBackgroundColor: null,
				plotBorderWidth: 0,
				plotShadow: false
			},
			title: {
				text: null
			},
			legend: {
				align: "middle",
				verticalAlign: "bottom",
				layout: "horizontal",
				itemMarginBottom: 1,
				itemMarginTop: 0,
				x: 32,
				itemStyle: {
					color: "#999",
					maxWidth: "160px",
					overflow: "hidden",
					textOverflow: "ellipsis",
					lineHeight: "16px",
					fontWeight: "normal"
				},
				itemHoverStyle: {
					color: '#007dba'
				},
				enabled: true,
				useHTML: true,
				itemWidth: 200
			},
			plotOptions: {
				pie: {
					shadow: false,
					borderWidth: 1,
					showInLegend: true,
					colorByPoint: true,
					data: _data
				}
			},
			series: [{
				type: 'pie',
				name: _name,
				animation: {
					duration: 250
				},
				dataLabels: {
					enabled: true,
					softConnector: true,
					connectorWidth: 1,
					style: {
						fontWeight: 'bold',
						color: '#333',
						textShadow: '0px 0px 3px white'
					},
					formatter: function() {
						return '$' + Highcharts.numberFormat(this.y);
					}
				}
			}],
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	} else if (_settings.chartOptions.chartType == 'bar') {
		$("#HC_" + id).highcharts({
			chart: {
				type: 'bar'
			},
			title: {
				text: null
			},
			legend: {
				enabled: false
			},
			xAxis: {
				type: 'category'
			},
			yAxis: {
				gridLineColor: "#ebebeb",
				title: {
					enabled: false
				},
				labels: {
					overflow: 'justify'
				}
			},
			plotOptions: {
				series: {
					borderWidth: 0,
					animation: {
						duration: 250
					},
					groupPadding: 0,
					dataLabels: {
						enabled: true,
						verticalAlign: "middle",
						y: -3,
						formatter: function() {
							return '$' + Highcharts.numberFormat(this.y);
						},
						style: {
							color: '#333',
							fontWeight: 'bold',
							textShadow: '0px 0px 3px white'
						},
						pointPadding: 0
					}
				}
			},
			series: [{
				name: _name,
				colorByPoint: true,
				data: _data
			}],
			tooltip: {
				backgroundColor: "#EDE8C4",
				borderColor: "#004165",
				formatter: generate_tooltip,
				useHTML: true
			},
			exporting: {
				buttons: {
					contextButton: {
						enabled: false
					}
				}
			},
			credits: {
				enabled: false
			}
		});
	}
}

function buildCardTopSpend(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	_widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length || _widget.settings == "undefined") {
		_widget.settings = [{
			chartOptions: {
				chartType: "bar",
				dataSetting: "suppliers",
				refCCY: "Default"
			}
		}];
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	var $content = $("<div style='width:100%; height:100%;'></div>");
	var $highchart = $("<div class='highchart' id='HC_" + id + "' \>").appendTo($content);
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($content);
		finalizeCardTopSpend(id, _settings[0]);
	} else {
		setTimeout(function() {
			finalizeCardTopSpend(id, _settings[0]);
		}, 250);
		return $content;
	}
}


/* card limit utilisation widget */
var card_limit_utilisation_data = {
	reference_currency: "AUD",
	data: []
};

function showLimitUtilisationSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id");
}

function finalizeLimitUtilisation(id, _settings, _data) {}

function buildLimitUtilisation(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);
}


/* card program summary widget */
function buildCardProgramSummary(id) {}


/* card outstanding tasks widget */
function buildCardTasks(id) {}


/* my favourite reports */
var dashboard_reports = [];

if (store.get('stored_dashboard_reports')) {
	dashboard_reports = store.get('stored_dashboard_reports');
} else {
	for (var i = 0; i < 10; i++) {
		var d = (dashboard_reports[i] = {});
		d["id"] = Math.round(Math.random() * 1000000000);
		if (i < 5) {
			if (i % 2 == 0) {
				d["reptype"] = "Account Statement";
				d["repname"] = "Report Profile Name - " + randString(3) + Math.round(Math.random() * 100);
				d["repformat"] = "PDF"
				d["grouped"] = true
				d["description"] = "Statements For Manufacturing Inc. Operating Accounts " + Math.round(Math.random() * 100) + " to " + Math.round(Math.random() * 100);
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Today";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{
					id: "id_0",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_1",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_2",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}];
			} else {
				d["reptype"] = "Account Balance Summary";
				d["repname"] = "Report Profile Name - " + randString(3) + Math.round(Math.random() * 100);
				d["repformat"] = "CSV"
				d["grouped"] = false
				d["description"] = "Balance Summary Report for Manufacturing Inc. Accounts " + Math.round(Math.random() * 100) + " to " + Math.round(Math.random() * 100);
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Specific Date";
				d["fromdate"] = "06/05/2013";
				d["todate"] = "";
				d["filtertype"] = "Currency";
				d["filters"] = [{
					id: "id_0",
					ccy: "AUD",
					ccyname: "Australian Dollars"
				}, {
					id: "id_1",
					ccy: "CNY",
					ccyname: "Chinese Yuan"
				}, {
					id: "id_2",
					ccy: "EUR",
					ccyname: "Euro"
				}];
			}
		} else {
			if (i % 2 == 0) {
				d["reptype"] = "Account Statement";
				d["repname"] = "Report Profile Name " + randString(3) + Math.round(Math.random() * 100);
				d["repformat"] = "Excel"
				d["grouped"] = true
				d["description"] = "Consulting Pte. Ltd. Account Statements";
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Yesterday";
				d["fromdate"] = "";
				d["todate"] = "";
				d["filtertype"] = "Account";
				d["filters"] = [{
					id: "id_0",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_1",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_2",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_3",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_4",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}, {
					id: "id_5",
					accountnam: "CURRENT" + Math.round(Math.random() * 1000),
					accountnum: Math.round(Math.random() * 1000000000).toString()
				}];
			} else {
				d["reptype"] = "Account Balance Summary";
				d["repname"] = "Report Profile Name " + randString(3) + Math.round(Math.random() * 100);
				d["repformat"] = "PDF";
				d["grouped"] = false
				d["description"] = "Consulting Pte. Ltd. Balance Summary Reports";
				d["shared"] = "";
				d["sharedby"] = "";
				d["ownedby"] = "PrototypeUser";
				d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
				d["datefilter"] = "Date Range";
				d["fromdate"] = "06/05/2013";
				d["todate"] = "10/05/2013";
				d["filtertype"] = "Currency";
				d["filters"] = [{
					id: "id_0",
					ccy: "AUD",
					ccyname: "Australian Dollars"
				}, {
					id: "id_1",
					ccy: "EUR",
					ccyname: "Euro"
				}];
			}
		};
	}
	store.set('stored_dashboard_reports', dashboard_reports);
}

function showRemoveReports(_target, _widget) {

	/* set _data to the widget data and _id to the widget id */
	var _data = _widget.data,
		_id = _widget.id;

	/* function to remove selected accounts from the widget */
	function removeSelectedReports(_dialog) {
		if ($("input[name=_addProfile]:checked").length > 0) {
			for (var i = 0; i < _data.length; i++) {
				for (var s = 0; s < $("input[name=_addProfile]:checked").length; s++) {
					if (_data[i].id == $("input[name=_addProfile]:checked").eq(s).val()) {
						_data.splice(i, 1);
					}
				}
			}
			dialogHider(_dialog);
			buildMyFavouriteReports(_id, true);
			store.set('saved_widget_data', widgetDataArray);
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the add report profiles list */
	var $wrapper = $("<div class='widget-reports wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='RemoveAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a report profile...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearProfilesFilter").show()
			} else {
				$("#clearProfilesFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearProfilesFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#RemoveAccountsFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addProfile]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$profileHeader = $("<div class='fav-header-col' style='width: 600px;'>Report Profiles</div>").appendTo($header);

	/* build the report profiles list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='RemoveAccountsFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $profilerow, $repinfo;



	$.each(_data, function() {

		$li = $("<li>").appendTo($ul);
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
			var $target = $(e.target);
			if (!$target.hasClass("fav-row") && $target.prop("nodeName") != "INPUT") {
				$target = $target.closest("div.fav-row").find("input[name='_addProfile']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if (!$(this).prop("checked")) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if ($("input[name=_addProfile]:checked").length == $("input[name=_addProfile]").length) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		});
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		$checkInput = $("<input value='" + this.id + "' type='checkbox' name='_addProfile' />").appendTo($checkDiv).on("change", function() {
			var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		});
		$profilerow = $("<div class='fav-data-col' style='width: 600px; padding: 0 25px;' />").appendTo($row);
		$repdetail = $("<div class='fav-data-report-profile' />").appendTo($profilerow);
		$repinfo = $("<span style='font-size: 16px; font-weight: 600;'>" + this.repname + "</span><br />").appendTo($repdetail);
		$repinfo = $("<span style='font-size: 12px; margin-top: 2px;'>" + this.reptype + " (" + this.repformat + ")</span><br />").appendTo($repdetail);
		$repinfo = $("<span style='font-size: 14px; margin-top: 2px;'>" + this.description + "</span>").appendTo($repdetail);


	});

	/* build and show the remove accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "RemoveReportProfiles",
		title: "Remove Favourite Reports",
		size: "medium",
		icon: "<i class='fa fa-minus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					removeSelectedReports(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#RemoveAccountsFilterInput").fastLiveFilter('#RemoveAccountsFilterList');

	/* if no accounts are available display a message */
	if (!$("#RemoveAccountsFilterList").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no report profiles to remove</div>").appendTo($dataContainer);
	}
}

function showAddReports(_target, _widget) {

	/* set _data to the widget data and _id to the widget id */
	var _data = _widget.data,
		_id = _widget.id;

	/* function to save and add selected report profiles to the widget */
	function saveSelectedProfiles(_dialog) {
		if ($("input[name=_addProfile]:checked").length > 0) {
			for (var i = 0; i < dashboard_reports.length; i++) {
				for (var s = 0; s < $("input[name=_addProfile]:checked").length; s++) {
					if (dashboard_reports[i].id == $("input[name=_addProfile]:checked").eq(s).val()) {
						_data.push(dashboard_reports[i]);
					}
				}
			}
			dialogHider(_dialog);
			buildMyFavouriteReports(_id, true);
			store.set('saved_widget_data', widgetDataArray);
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the add report profiles list */
	var $wrapper = $("<div class='widget-reports wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddProfilesFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a report profile...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearProfilesFilter").show()
			} else {
				$("#clearProfilesFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearProfilesFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#AddProfilesFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addProfile]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$profileHeader = $("<div class='fav-header-col' style='width: 600px;'>Report Profiles</div>").appendTo($header);

	/* build the report profiles list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul id='AddProfilesFilterList' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $profilerow, $repinfo;

	$.each(dashboard_reports, function() {

		var _alreadyAdded = false;
		for (var i = 0; i < _data.length; i++) {
			if (_data[i].id == this.id) {
				_alreadyAdded = true;
				break;
			}
		}

		if (!_alreadyAdded) {
			$li = $("<li>").appendTo($ul);
			$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if (!$target.hasClass("fav-row") && $target.prop("nodeName") != "INPUT") {
					$target = $target.closest("div.fav-row").find("input[name='_addProfile']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
				}
				if (!$(this).prop("checked")) {
					$("input[name='_selectAll']").prop("checked", false)
				}
				if ($("input[name=_addProfile]:checked").length == $("input[name=_addProfile]").length) {
					$("input[name='_selectAll']").prop("checked", true)
				}
			});
			$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
			$checkInput = $("<input value='" + this.id + "' type='checkbox' name='_addProfile' />").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
			});
			$profilerow = $("<div class='fav-data-col' style='width: 600px; padding: 0 25px;' />").appendTo($row);
			$repdetail = $("<div class='fav-data-report-profile' />").appendTo($profilerow);
			$repinfo = $("<span style='font-size: 16px; font-weight: 600;'>" + this.repname + "</span><br />").appendTo($repdetail);
			$repinfo = $("<span style='font-size: 12px; margin-top: 2px;'>" + this.reptype + " (" + this.repformat + ")</span><br />").appendTo($repdetail);
			$repinfo = $("<span style='font-size: 14px; margin-top: 2px;'>" + this.description + "</span>").appendTo($repdetail);
		}
	});

	/* build and show the add report profiles dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddReportProfiles",
		title: "Add Favourite Reports",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveSelectedProfiles(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddProfilesFilterInput").fastLiveFilter('#AddProfilesFilterList');

	/* if no accounts are available display a message */
	if (!$("#AddProfilesFilterList").children("li").length) {
		var $noProfiles = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no report profiles to add</div>").appendTo($dataContainer);
	}
}

function showFavoureReportSettings(e) {

	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id");

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		var _rebuild = false;
		_widget.settings = [{
			newlyadded: false
		}];
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		if (_rebuild) {
			buildMyFavouriteReports(id, true);
		}
	};

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-reports data-form' />");

	/* build the reports section */
	var $accountSectionHeading = $("<div class='section-heading'>Report Profiles</div>").appendTo($settings),
		$accountSection = $("<div class='form-section' />").appendTo($settings),
		$accountRow = $("<div class='row' />").appendTo($accountSection),
		$accountDataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($accountRow),
		$accountNoteData,
		$addAccountsButton,
		$removeAccountsButton;

	if (_widget.data.length == 0) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You haven't added any favourite reports profiles yet.</div>").appendTo($accountDataCol);
		$addAccountsButton = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Favourite Reports</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showAddReports($("[data-modal-parent-of='" + _widget.id + "Settings']"), _widget)
		});
	} else if (_widget.data.length >= 1 && _widget.data.length < 20) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You've added " + _widget.data.length + " favourite report profile(s).</div>").appendTo($accountDataCol);
		$addAccountsButton = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-plus-square fa-fw'></i>Add Favourite Reports</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showAddReports($("[data-modal-parent-of='" + _widget.id + "Settings']"), _widget)
		});
		$removeAccountsButton = $("<a href='javascript:void(0)' class='form-button' ><i class='fa fa-times fa-fw'></i>Remove Favourite Reports</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showRemoveReports($("[data-modal-parent-of='" + _widget.id + "Settings']"), _widget);
		});
	} else if (_widget.data.length == 20) {
		$accountNoteData = $("<div class='data-note' style='padding-bottom: 10px;'>You've added 20 favourite accounts.</div>").appendTo($accountDataCol);
		$removeAccountsButton = $("<a href='javascript:void(0)' class='form-button'><i class='fa fa-times fa-fw' style='margin-right: 5px;'></i>Remove Favourite Reports</a>").appendTo($accountDataCol).on("click", function(e) {
			e.preventDefault();
			showRemoveReports($("[data-modal-parent-of='" + _widget.id + "Settings']"), _widget);
		});
	}

	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Favourite Report Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function buildMyFavouriteReports(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	if (!_widget.settings.length) {
		_widget.settings = [{
			newlyadded: true
		}];
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;


	if (_widget.settings[0].newlyadded) {
		_widget.data = store.get("stored_dashboard_reports");
		_widget.settings[0].newlyadded = false;
	}

	var $addLink = $("<div class='ha-empty'><a href='javascript:void(0)' class='form-button primary' data-action='" + _widget.id + "'><i class='fa fa-plus-square fa-fw'></i>Add Favourite Reports</a></div>");

	/* build the widget content */
	var $wrapper = $("<div class='wrapper' />"),
		$header = $("<div class='fav-header' />").appendTo($wrapper),
		$account = $("<div class='fav-header-col' style='width: 75%;'>Report Profiles</div>").appendTo($header),
		$account = $("<div class='fav-header-col text-right' style='width: 25%;'>Actions</div>").appendTo($header),
		$container = $("<div class='fav-data' />").appendTo($wrapper);

	if (_widget.data.length > 0) {
		/* the function to save the widget data whenever accounts are re-ordered */
		function saveReorderedReports(result) {
			var _reorderdList = [];
			for (var i = 0; i < result.length; i++) {
				for (var d = 0; d < _widget.data.length; d++) {
					if (result[i] == _widget.data[d].id) {
						_reorderdList.push(_widget.data[d])
					}
				}
			}
			_widget.data = _reorderdList;
			store.set('saved_widget_data', widgetDataArray);
		}
		/* bind the save reorder function to the sortable */
		var $ul = $("<ul />").appendTo($container).sortable({
			handle: ".fav-reorder",
			axis: 'y',
			containement: "parent",
			tolerance: "pointer",
			update: function(event, ui) {
				var result = $(this).sortable('toArray', {
					attribute: 'data-report'
				});
				saveReorderedReports(result)
			}
		});
		$.each(_widget.data, function() {
			var $li = $("<li data-report='" + this.id + "' />").appendTo($ul).on("mouseover mouseout", function() {
				if (!$(this).hasClass("show-actions")) {
					$(this).find(".fav-actions-show").toggle()
				}
			});
			/* build the actions div */
			var $actions = $("<div class='fav-actions' />").appendTo($li),
				$close = $("<span class='fav-actions-hide' title='Hide Actions'><i class='fa fa-ellipsis-v'></i></span>").appendTo($actions).on("click", function() {
					$(this).closest("li").removeClass("show-actions").find(".fav-actions-show").show()
				}),
				$remove = $("<span title='Remove This Account'><i class='fa fa-times'></i></span>").appendTo($actions).on("click", function() {
					var _li = $(this).closest("li"),
						_numb = _li.attr("data-report"),
						i = 0;
					while (i < _widget.data.length) {
						if (_widget.data[i].id == _numb) {
							_widget.data.splice(i, 1);
							_li.hide("fast", function() {
								$(this).remove()
							});
							$(this).closest("ul").sortable("refresh");
							store.set('saved_widget_data', widgetDataArray);
							break;
						}
						i += 1;
					}
					if (_widget.data.length == 0) {
						$addLink.appendTo($wrapper).on("click", function(e) {
							e.preventDefault();
							showAddReports($(e.target), _widget);
							$("#AddReportProfiles input").first().focus();
						});
					}
				});
			var $row = $("<div class='fav-row fav-reorder' />").appendTo($li);
			$open = $("<div class='fav-actions-show' title='Show Actions'><i class='fa fa-ellipsis-v fa-fw'></i></div>").appendTo($row).on("click", function() {
				$(this).hide().closest("li").addClass("show-actions").siblings().removeClass("show-actions").find(".fav-actions-show").hide();
			});
			var $profileDiv = $("<div class='fav-data-col' style='width: 75%; padding: 0 0 0 25px;' />").appendTo($row);
			var $dataDiv = $("<div class='fav-data-report-profile' />").appendTo($profileDiv);
			var $anchor = $("<a href='report-profiles.html#detail' />").appendTo($dataDiv);
			var $name = $("<span style='font-size: 16px; font-weight: 600;'>" + this.repname + "</span><br />").appendTo($anchor);
			var $type = $("<span style='font-size: 12px; margin-top: 2px;'>" + this.reptype + " (" + this.repformat + ")</span><br />").appendTo($anchor);
			var $desc = $("<span style='font-size: 14px; margin-top: 2px;'>" + this.description + "</span>").appendTo($anchor);
			var $actionDiv = $("<div class='fav-data-col text-right' style='width: 25%; padding: 0 25px 0 0;' />").appendTo($row);
			var $anchor = $("<a href='javascript:void(0)' title='Run this report profile' class='report-profile-action' />").appendTo($actionDiv);
			var $icon = $("<i class='fa fa-file-text fa-fw'></i>").appendTo($anchor);
		});
	} else {
		$addLink.appendTo($wrapper).on("click", function(e) {
			e.preventDefault();
			showAddReports($(e.target), _widget);
			$("#AddReportProfiles input").first().focus();
		});
	}

	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($wrapper);
	} else {
		return $wrapper;
	}
}


/* my paymnets widget */
function showMyPaymentsSettings(e) {
	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id");

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		var _rebuild = false;
		if ($("input[name='viewStyle']:checked").val() != _widget.settings[0].view) {
			_rebuild = true;
		} else {
			for (var i = 0, l = _widget.settings[0].selections.length; i < l; i++) {
				if ($("#" + _widget.settings[0].selections[i].id).prop("checked") != _widget.settings[0].selections[i].on) {
					_rebuild = true;
					break;
				}
			}
		}
		for (var i = 0, l = _widget.settings[0].selections.length; i < l; i++) {
			_widget.settings[0].selections[i].on = $("#" + _widget.settings[0].selections[i].id).prop("checked");
		}
		_widget.settings[0].view = $("input[name='viewStyle']:checked").val();
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		if (_rebuild) {
			buildMyPayments(id, true);
		}
	};

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-my-payments data-form' />");

	/* build the my payments settings section */
	var $sectionHeading = $("<div class='section-heading'>Payment Status Selection</div>").appendTo($settings),
		$formSection = $("<div class='form-section' />").appendTo($settings),
		$row = $("<div class='row' />").appendTo($formSection),
		$dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row),
		$inputGroup, $data, $label;

	for (var i = 0, l = _widget.settings[0].selections.length; i < l; i++) {
		var _item = _widget.settings[0].selections[i];
		$inputGroup = $("<div class='input-group' />").appendTo($dataCol),
			$data = $("<input type='checkbox' id='" + _item.id + "' value='" + _item.name + "' />").appendTo($inputGroup).prop("checked", _item.on),
			$label = $("<label class='desc' for='" + _item.id + "'>" + _item.name + "</label>").appendTo($inputGroup);
		$inputGroup.appendTo($dataCol);
	}

	var $sectionHeading = $("<div class='section-heading'>View Preference</div>").appendTo($settings),
		$formSection = $("<div class='form-section' />").appendTo($settings),
		$row = $("<div class='row' />").appendTo($formSection),
		$dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row),
		$data = $("<input type='radio' name='viewStyle' id='viewStyleList' value='list' />").appendTo($dataCol),
		$label = $("<label class='desc' for='viewStyleList'><i class='fa fa-list fa-fw'></i> (List)</label>").appendTo($dataCol),
		$data = $("<input type='radio' name='viewStyle' id='viewStyleGrid' value='grid' />").appendTo($dataCol),
		$label = $("<label class='desc' for='viewStyleGrid'><i class='fa fa-th-large fa-fw'></i> (Grid)</label>").appendTo($dataCol);

	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Payments Status Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	if (_widget.settings[0].view == "list") {
		$("#viewStyleList").prop("checked", true);
	} else {
		$("#viewStyleGrid").prop("checked", true);
	}
}

function buildMyPayments(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	/* check if there are is any settings data for this widget and if not load some default ones */
	if (!_widget.settings.length) {
		_widget.settings = [{
			selections: [{
				name: "Draft",
				id: "myPaymentsDraft",
				on: true
			}, {
				name: "Completed",
				id: "myPaymentsCompleted",
				on: true
			}, {
				name: "Future Dated",
				id: "myPaymentsFutureDated",
				on: true
			}, {
				name: "Insufficient Funds",
				id: "myPaymentsInsufficientFunds",
				on: true
			}, {
				name: "Needs Repair",
				id: "myPaymentsNeedsRepair",
				on: true
			}, {
				name: "Pending Approval",
				id: "myPaymentsPendingApproval",
				on: true
			}, {
				name: "Processed",
				id: "myPaymentsProcessed",
				on: true
			}, {
				name: "Rejected By Bank",
				id: "myPaymentsRejected",
				on: true
			}],
			view: "grid",
			division: "All Divisions"
		}]
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	var $wrapper = $("<div class='wrapper my-payments-view' />");

	/* division section */
	var $formSection = $("<div class='form-section' />").appendTo($wrapper),
		$row = $("<div class='row' />").appendTo($formSection),
		$dataCol = $("<div class='data-column full' />").appendTo($row),
		$customSelect = $("<div class='custom-select' style='width: 80%; max-width: 400px;' />").appendTo($dataCol),
		$select = $("<select id='" + id + "division'><option value='All Divisions'>All Divisions</option><option value='Customer Division 1'>Customer Division 1</option><option value='Customer Division 2'>Customer Division 2</option></select>").appendTo($customSelect).on("change", function() {
			var $widget = $(this).closest("div.widget-container").addClass("working");
			_widget.settings[0].division = $(this).val();
			store.set('saved_widget_data', widgetDataArray);
			setTimeout(function() {
				$widget.removeClass("working");
				buildMyPayments(id, true);
			}, 300);
		});
	$select.val(_widget.settings[0].division);

	/* list */
	var $listcontainer = $("<ul class='status-list' />").appendTo($wrapper);

	var updateWidget = function() {
		_widget.settings[0].selections = [];
		$listcontainer.children("li").each(function() {
			var _on = $(this).attr("data-visible") == "true" ? true : false;
			var _item = {
				name: $(this).attr("data-name"),
				id: $(this).attr("data-id"),
				on: _on
			}
			_widget.settings[0].selections.push(_item);
		});
		store.set('saved_widget_data', widgetDataArray);
	}

	var buildList = function(settings) {
		$.each(settings[0].selections, function(i, v) {
			var $item = $("<li data-id='" + this.id + "' data-name='" + this.name + "' data-visible='" + this.on + "' />").on("mouseover", function() {
				$(this).find("a.hide-icon").show();
			}).on("mouseout", function() {
				$(this).find("a.hide-icon").hide();
			});
			var $link = $("<a href='javascript:void(0)' class='my-payments-item'>" + this.name + "</a>").appendTo($item).on("click", function() {
				document.location.href = 'payments-summary.html';
			});
			var $hideIcon = $("<a href='javascript:void(0)' class='hide-icon'><i class='fa fa-times'></i></a>").appendTo($item).on("click", function(e) {
				e.preventDefault();
				$(this).closest("li").attr("data-visible", false).hide("fast", function() {
					updateWidget();
				});
			});
			var $count = $("<div class='item-count'>" + randNumber(2) + "</div>").appendTo($link);
			if (this.on != true) {
				$item.addClass("display-none");
			}
			if (settings[0].view == "grid") {
				$item.addClass("grid-style");
			}
			$item.appendTo($listcontainer);
		});

		//sort rates.
		$listcontainer.sortable({
			tolerance: "pointer",
			containment: "parent",
			update: updateWidget
		});
	}

	buildList(_widget.settings);

	/* return the results. if rebuild is true then just redraw the existing widget, otherwise populate a newly added widget */
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($wrapper);
	} else {
		return $wrapper;
	}
}



/* make paymnets widget */
function buildMakePayments(id, rebuild) {

	/* file upload functions */
	function checkFormat() {
		var _gcp = ($(this).val() == "GCP Delimited") ? true : false;
		if (_gcp) {
			$("#debitIndicatorRow, #purposeRow").show();
		} else {
			$("#debitIndicatorRow, #purposeRow").hide();
		}
	}

	function clearErrors() {
		if ($(this).val() != '' && $(this).closest("div.row").hasClass("error")) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
	}

	function clearAllErrors() {
		$("#fileUploadForm").find('div.error').removeClass("error").find("div.data-error").remove();
	}

	function cancelUpload() {
		$("#fileSection").hide();
		$("#uploadFileInput").val('');
		$("#uploadButton, #startUpload").removeClass("disabled");
		$(".progress-meter").stop(true, true).css({
			width: 0
		});
		clearAllErrors();
	}

	function showFileUploadSection() {
		$("#uploadMessage").hide();
		$("#fileSection, #fileUploadActions").show();
		$(".progress-meter").stop(true, true).css({
			width: 0
		});

		var str = $(this).val();
		var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);
		$("#filenamevalue").html(filename);

		if (window.ActiveXObject) {
			var myFSO = new ActiveXObject("Scripting.FileSystemObject");
			var filepath = document.getElementById('uploadFileInput').value;
			var thefile = myFSO.getFile(filepath);
			var size = thefile.size;
		} else {
			var size = this.files[0].size;
		}

		var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
		fSize = size;
		i = 0;
		while (fSize > 900) {
			fSize /= 1024;
			i++;
		}
		$("#filesize").html("(" + (Math.round(fSize * 100) / 100) + ' ' + fSExt[i] + ")");
	}

	function checkUploadSettings() {
		var _passed = true,
			_division = $("#divisionField").val(),
			_format = $("#formatField").val(),
			_encoding = $("#encodingField").val(),
			_indicator = $("#debitIndicatorField").val(),
			_purpose = $("#purposeField").val();

		if (!_division) {
			_passed = false;
			$("#divisionField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>Division is required</div>");
				}
			});
		}
		if (!_format) {
			_passed = false;
			$("#formatField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>File Format is required</div>");
				}
			});
		}
		if (!_encoding) {
			_passed = false;
			$("#encodingField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>File Encoding is required</div>");
				}
			});
		}

		if (_format == "GCP Delimited") {
			if (!_indicator) {
				_passed = false;
				$("#debitIndicatorField").closest("div.row").addClass("error").find("div.data-column").append(function() {
					if ($(this).children("div.data-error").size() == 0) {
						$(this).append("<div class='data-error'>Debit Indicator is required</div>");
					}
				});
			}
			if (!_purpose) {
				_passed = false;
				$("#purposeField").closest("div.row").addClass("error").find("div.data-column").append(function() {
					if ($(this).children("div.data-error").size() == 0) {
						$(this).append("<div class='data-error'>Payment Purpose is required</div>");
					}
				});
			}
		}

		if (_passed) {
			$("#fileUploadSection").closest("div.row").removeClass("error").find("div.data-error").remove();
			$("#uploadButton, #startUpload").addClass("disabled");
			$(".progress-meter").animate({
				width: "100%"
			}, 3000, function() {
				$("#uploadButton, #startUpload").removeClass("disabled");
				$("#fileUploadActions").hide();
				$("#uploadMessage").show();
				$("#uploadFileInput").val('');
			});
		} else {
			$("#fileUploadSection").closest("div.row").addClass("error").find("div.data-column").append($("<div class='data-error'>File does not match selection criteria</div>"));
		}
	}

	function populateFileUploadDialog() {
		var $dialogContent = $("<div class='py-ui' style='padding: 10px;' id='fileUploadForm' />");
		var $div = $("<div class=' top-label' />").appendTo($dialogContent);

		var $gridrow = $("<div class='grid-row' />").appendTo($div);
		var $gridcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridrow);

		var $row = $("<div class='row mandatory' />").appendTo($gridcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Division</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='divisionField'><option value=''></option><option value='Division ABC'>Division ABC</option><option value='Division 123'>Division 123</option><option value='Division XYZ'>Division XYZ</option></select>").appendTo($customSelect).on("change", clearErrors);

		var $row = $("<div class='row mandatory' />").appendTo($gridcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>File Format</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='formatField'><option value=''></option><option value='PAC File Format'>PAC File Format</option><option value='OTL Fixed Length'>OTL Fixed Length</option><option value='OTL Delimited'>OTL Delimited</option><option value='GCP Delimited'>GCP Delimited</option></select>").appendTo($customSelect).on("change", checkFormat).on("change", clearErrors);

		var $row = $("<div class='row mandatory' />").appendTo($gridcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>File Encoding</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='encodingField'><option value=''></option><option value='UTF-8'>UTF-8</option><option value='ASCII'>ASCII</option><option value='Unicode'>Unicode</option><option value='GB2312'>GB2312</option><option value='GB2312-80'>GB2312-80</option><option value='BIG5'>BIG5</option><option value='BIG5-HKSCS'>BIG5-HKSCS</option><option value='Shift-JIS'>Shift-JIS</option></select>").appendTo($customSelect).on("change", clearErrors);

		var $gridcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridrow);

		var $row = $("<div class='row mandatory' id='debitIndicatorRow' style='display: none;' />").appendTo($gridcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Debit Indicator</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='debitIndicatorField'><option value=''></option><option value='Bulk Debit'>Bulk Debit</option><option value='Itemised Debit'>Itemised Debit</option></select>").appendTo($customSelect).on("change", clearErrors);

		var $row = $("<div class='row mandatory' id='purposeRow' style='display: none;' />").appendTo($gridcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment Purpose</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='purposeField'><option value=''></option><option value='Non-Salary Payment'>Non-Salary Payment</option><option value='Salary Payment'>Salary Payment</option></select>").appendTo($customSelect).on("change", clearErrors);


		var $gridrow = $("<div class='grid-row' />").appendTo($div);
		var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);

		var $row = $("<div class='row' />").appendTo($gridcell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $buttonSpan = $("<span class='form-button primary' id='uploadButton' />").appendTo($dataCol);
		var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Browse Files</a>").appendTo($buttonSpan);
		var $fileInput = $("<input type='file' name='file' id='uploadFileInput' style='position: absolute; left: 30px; padding: 0; width: 155px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($buttonSpan).on('change', showFileUploadSection);


		var $gridrow = $("<div class='grid-row' style='display: none;' id='fileSection' />").appendTo($div);
		var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);
		var $row = $("<div class='row' />").appendTo($gridcell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);

		var $uploadDiv = $("<div class='file-upload-section' id='fileUploadSection' />").appendTo($dataCol);
		var $fileDiv = $("<div id='fileNameDiv' />").appendTo($uploadDiv);
		var $data = $("<div class='file-name'><i class='fa fa-paperclip fa-fw'></i> <strong id='filenamevalue'></strong></div>").appendTo($fileDiv);
		var $data = $("<div class='file-size'><span id='filesize'></span></div>").appendTo($fileDiv);
		var $uploadActions = $("<div id='fileUploadActions' />").appendTo($uploadDiv);
		var $btndiv = $("<div class='file-upload-buttons' />").appendTo($uploadActions);
		var $buttonSpan = $("<span class='form-button primary' id='startUpload' />").appendTo($btndiv);
		var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-upload fa-fw'></i>Start</a>").appendTo($buttonSpan).on("click", checkUploadSettings);
		var $buttonSpan = $("<span class='form-button' id='cancelUpload' />").appendTo($btndiv);
		var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i>Cancel</a>").appendTo($buttonSpan).on("click", cancelUpload);
		var $data = $("<div class='progress-bar'></div>").appendTo($uploadActions);
		var $meter = $("<div class='progress-meter' />").appendTo($data);
		var $messageDiv = $("<div class='file-upload-message' id='uploadMessage' style='display: none;' />").appendTo($uploadDiv);
		var $fileMessage = $("<div style='white-space: normal;'>This file has been <span style='color: #009900; font-weight: bold;'>successfully uploaded</span>. It will now be scanned and processed. You can find this file in the Payments File page with <strong>File ID: 34234234</strong>.</div>").appendTo($messageDiv);

		return $dialogContent;
	}

	function triggerUploadDialog(e) {
		e.preventDefault();
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: "uploadFile",
			title: "Upload Payment File",
			size: "xwide",
			icon: "<i class='fa fa-upload'></i>",
			content: function() {
				return populateFileUploadDialog()
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times-circle fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* template functions */

	var _payment_templates = [{
		"id": "GbkYhXZmaOVUDXkQWLln",
		"category": "batch",
		"templateid": "auwRmlOlUZTMP",
		"templatename": "Template - kOU",
		"templatedescription": "This is a sample template description.",
		"type": "Domestic Salary",
		"debitcredit": "DR",
		"batchid": "BxtgDy23/11/2016",
		"batchreference": "aqCaa-BatchPay",
		"name": "Batch - ljUGD - 23/11/2016",
		"batchdescription": "This is a sample payment description.",
		"division": "Customer Division 2",
		"paymentdate": "23/11/2016",
		"paymentcurrency": "HKD",
		"debitaccount": {
			"id": "pkyXsGYTHY",
			"owner": {
				"id": "OPCUST11",
				"name": "Expat Financial Services Inc.",
				"localname": "外籍金融服务公司",
				"address1": "L234 China Central Place",
				"address2": "No. 79 Jianguo Road",
				"address3": "Cjaoyang District",
				"address4": "Beijing",
				"postal": "100025",
				"country": "China",
				"email": "customer10@tbos.prototype.com"
			},
			"bank": {
				"id": "OPCBANK02",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团有限公司北京分行",
				"branch": "Beijing Branch",
				"address1": "Tower 2, Floor 17",
				"address2": "Beijing Bright China Chang An Building",
				"address3": "Dong Cheng District, Beijing",
				"postal": "100005",
				"country": "China",
				"swift": "ANZBCNSHBJG",
				"clearing": {
					"type": "CNAPS",
					"code": "761100000012"
				}
			},
			"swiftbank": {
				"id": "OPCBANK02",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团有限公司北京分行",
				"branch": "Beijing Branch",
				"address1": "Tower 2, Floor 17",
				"address2": "Beijing Bright China Chang An Building",
				"address3": "Dong Cheng District, Beijing",
				"postal": "100005",
				"country": "China",
				"swift": "ANZBCNSHBJG",
				"clearing": {
					"type": "CNAPS",
					"code": "761100000012"
				}
			},
			"type": "Savings",
			"currency": {
				"country": "Singapore",
				"code": "SGD",
				"currency": "Singapore Dollar"
			},
			"number": "6275515156",
			"name": "OPCUST11 Savings XLTPY",
			"resident": "Resident",
			"availablebalance": "17303.55",
			"availablefunds": "195876.82"
		},
		"debitaccountnumber": "6275515156",
		"debitaccountname": "OPCUST11 Savings XLTPY",
		"debitcurrency": "SGD",
		"debitaccountavailablebalance": "17303.55",
		"debitaccountavailablefunds": "195876.82",
		"individualdebitsflag": 0,
		"urgentflag": 0,
		"debitequivalentflag": 0,
		"ratetype": "Carded",
		"rate": 0.17,
		"fromccy": "HKD",
		"toccy": "SGD",
		"contracts": [],
		"totalpaymentamount": "46,801.55",
		"totaldebitamount": "7,956.26",
		"payments": [{
			"id": "cqlddufwRzQPkMhhqASV",
			"number": 1,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "fOZODpJGqp",
				"beneid": "kQTTDS",
				"benename": "Guardian Suppliers",
				"benelocalname": "卫供应商",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1685353523",
				"beneaccountccy": "CNY",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary19@opee.prototype.com",
				"benebank": "CITIBANK (CHINA) CO., LTD.",
				"benebanklocalname": "美国花旗银行有限公司北京分行",
				"benebankbranch": "Beijing Branch",
				"benebankaddress1": "Floor 18, Citic International Building",
				"benebankaddress2": "19 Jianguomenwai Da Jie",
				"benebankaddress3": "Beijing",
				"benebankpostal": "100004",
				"benebankcity": "Beijing",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "531100000018",
				"swiftbank": "CITIBANK (CHINA) CO., LTD.",
				"swiftbanklocalname": "美国花旗银行有限公司北京分行",
				"swiftbranch": "Beijing Branch",
				"swiftbankaddress1": "Floor 18, Citic International Building",
				"swiftbankaddress2": "19 Jianguomenwai Da Jie",
				"swiftbankaddress3": "Beijing",
				"swiftbankpostal": "100004",
				"swiftbankcity": "Beijing",
				"swiftbankcountry": "China",
				"swiftcode": "CITICNSXBJG",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "17/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Guardian Suppliers",
			"beneficiaryaccountnumber": "1685353523",
			"beneficiaryid": "kQTTDS",
			"paymentreference": "PsldzLkpImd",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "5671.21"
		}, {
			"id": "MEGkPVpFTsyJZoZSReOc",
			"number": 2,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "ShHUzxXzOo",
				"beneid": "dgFZYz",
				"benename": "Shin Low Trading Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "3464814185",
				"beneaccountccy": "NZD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary11@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Deleted",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "30/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Shin Low Trading Inc.",
			"beneficiaryaccountnumber": "3464814185",
			"beneficiaryid": "dgFZYz",
			"paymentreference": "PtcRUpvvnNO",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "2346.10"
		}, {
			"id": "ZttQECMRMlenRvzntBaI",
			"number": 3,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "XauMhRiSlH",
				"beneid": "XhTVhM",
				"benename": "CBGB Global Enterprises",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8853151111",
				"beneaccountccy": "NZD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "14/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "CBGB Global Enterprises",
			"beneficiaryaccountnumber": "8853151111",
			"beneficiaryid": "XhTVhM",
			"paymentreference": "PjYPjVorRGF",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02113 - 货物贸易结算退款 Goods trade settlement refund",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "2792.01"
		}, {
			"id": "kyHUcgcBZWFiNioDuoli",
			"number": 4,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "GzzyZasJyJ",
				"beneid": "MJtoaZ",
				"benename": "Flow Water Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1243652139",
				"beneaccountccy": "AUD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary10@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "07/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Flow Water Incorporated",
			"beneficiaryaccountnumber": "1243652139",
			"beneficiaryid": "MJtoaZ",
			"paymentreference": "PRJbWMczfRu",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "5407.50"
		}, {
			"id": "pnzhmNlAtPrEXYAiAcmk",
			"number": 5,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "wQuiMnTsqz",
				"beneid": "iMAkZV",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "7341726427",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "HSBC BANK",
				"benebanklocalname": "",
				"benebankbranch": "Alliance Branch",
				"benebankaddress1": "Level 9 HSBC House",
				"benebankaddress2": "One Queen Street",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "302-935",
				"swiftbank": "HSBC BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Alliance Branch",
				"swiftbankaddress1": "Level 9 HSBC House",
				"swiftbankaddress2": "One Queen Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "HSBCNZ2A",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "01/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "7341726427",
			"beneficiaryid": "iMAkZV",
			"paymentreference": "PurjRPCmqAM",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "5285.90"
		}, {
			"id": "BCvZjqEMZzTIAkfqRSrR",
			"number": 6,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "UvzIVCfwDq",
				"beneid": "PoYYiY",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7154122512",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "02/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "7154122512",
			"beneficiaryid": "PoYYiY",
			"paymentreference": "PjowGJezxlW",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "8307.95"
		}, {
			"id": "QoIcFfpTJDBPPHZUsyTV",
			"number": 7,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "yUjgJJDvnG",
				"beneid": "caAaac",
				"benename": "Emilio Carloti Imports & Exports",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8627156286",
				"beneaccountccy": "HKD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "15/05/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Emilio Carloti Imports & Exports",
			"beneficiaryaccountnumber": "8627156286",
			"beneficiaryid": "caAaac",
			"paymentreference": "PhKRmOPdeHL",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "2907.85"
		}, {
			"id": "KxrZkPjXXTGAqBSGsgxP",
			"number": 8,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "RTdVohgRRF",
				"beneid": "SRLuiW",
				"benename": "White Lotus Holdings",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7769861673",
				"beneaccountccy": "AUD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary12@opee.prototype.com",
				"benebank": "BANK OF MELBOURNE",
				"benebanklocalname": "",
				"benebankbranch": "Payments Branch",
				"benebankaddress1": "Level 8",
				"benebankaddress2": "530 Collins Street",
				"benebankaddress3": "",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "193-911",
				"swiftbank": "BANK OF MELBOURNE",
				"swiftbanklocalname": "",
				"swiftbranch": "Payments Branch",
				"swiftbankaddress1": "Level 8",
				"swiftbankaddress2": "530 Collins Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftcode": "BNKMDL2123",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "10/04/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "White Lotus Holdings",
			"beneficiaryaccountnumber": "7769861673",
			"beneficiaryid": "SRLuiW",
			"paymentreference": "PwcRKGALupH",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "714.08"
		}, {
			"id": "UiyKwjLgddHhCPbAwTML",
			"number": 9,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "wZdCpgDOBb",
				"beneid": "RKJSht",
				"benename": "Emilio Carloti Imports & Exports",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "7428482968",
				"beneaccountccy": "AUD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "30/06/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Emilio Carloti Imports & Exports",
			"beneficiaryaccountnumber": "7428482968",
			"beneficiaryid": "RKJSht",
			"paymentreference": "PcIgQeoewjq",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "6748.71"
		}, {
			"id": "tkBZjiRSSmkzkRafINom",
			"number": 10,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "rDiJurZfHE",
				"beneid": "lICsiy",
				"benename": "K-Media Creative Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "3759875381",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary9@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Tawa Branch",
				"benebankaddress1": "C/-0546 12 Hagley Street",
				"benebankaddress2": "Porirua",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "010-553",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Tawa Branch",
				"swiftbankaddress1": "C/-0546 12 Hagley Street",
				"swiftbankaddress2": "Porirua",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "ANZBNZ22",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "13/08/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "K-Media Creative Services",
			"beneficiaryaccountnumber": "3759875381",
			"beneficiaryid": "lICsiy",
			"paymentreference": "PJAveqrtANH",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02115 - 服务贸易结算退款 Service trade settlement refund",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "1764.12"
		}, {
			"id": "ALkTNlngXfKStGBYFVCU",
			"number": 11,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "MQpjUoRZmv",
				"beneid": "aBBjme",
				"benename": "Farm To Table Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7888324994",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "WESTPAC",
				"benebanklocalname": "",
				"benebankbranch": "Queen Street Branch",
				"benebankaddress1": "Westpac Tower",
				"benebankaddress2": "488 Queen Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "030-253",
				"swiftbank": "WESTPAC",
				"swiftbanklocalname": "",
				"swiftbranch": "Queen Street Branch",
				"swiftbankaddress1": "Westpac Tower",
				"swiftbankaddress2": "488 Queen Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "COOKNZ2A",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "23/07/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Farm To Table Inc.",
			"beneficiaryaccountnumber": "7888324994",
			"beneficiaryid": "aBBjme",
			"paymentreference": "PgWtYgLxWDc",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "4414.71"
		}, {
			"id": "NQEtmCceTFNCYTiCjtLu",
			"number": 12,
			"validated": true,
			"batchreference": "aqCaa-BatchPay",
			"beneficiary": {
				"id": "kvWjElOSdA",
				"beneid": "gdERzS",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "6364354895",
				"beneaccountccy": "SGD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Ocean Financial Centre",
				"benebankaddress1": "Ocean Financial Centre",
				"benebankaddress2": "10 Collyer Quay",
				"benebankaddress3": "30-00",
				"benebankpostal": "049315",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "ANZBSGSX",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Ocean Financial Centre",
				"swiftbankaddress1": "Ocean Financial Centre",
				"swiftbankaddress2": "10 Collyer Quay",
				"swiftbankaddress3": "30-00",
				"swiftbankpostal": "049315",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "ANZBSGSX",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "26/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "6364354895",
			"beneficiaryid": "gdERzS",
			"paymentreference": "PgzrSgmOrTw",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "SGD",
			"workflow": "New",
			"status": "Needs Repair",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "441.41"
		}],
		"numberofpayments": 12,
		"workflow": "New",
		"status": "Needs Repair",
		"errors": [],
		"audit": [{
			"record": "GbkYhXZmaOVUDXkQWLln",
			"action": "Created",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Created",
			"fields": [],
			"comment": ""
		}, {
			"record": "GbkYhXZmaOVUDXkQWLln",
			"action": "Modified",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Modified",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "18/12/2016"
			}],
			"comment": ""
		}, {
			"record": "GbkYhXZmaOVUDXkQWLln",
			"action": "Approved",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "TBOS Approver",
			"description": "Record Approved",
			"fields": [],
			"comment": ""
		}],
		"createdby": "Test User",
		"createdon": "23/11/2016",
		"lastmodifiedby": "Test User",
		"lastmodifiedon": "23/11/2016",
		"lastapprovedby": "TBOS Approver",
		"lastapprovedon": "23/11/2016"
	}, {
		"id": "ulPuMHQYOYIOORCrPaiV",
		"category": "batch",
		"templateid": "WcCOltcHlZTMP",
		"templatename": "Template - THA",
		"templatedescription": "This is a sample template description.",
		"type": "Domestic",
		"debitcredit": "DR",
		"batchid": "BPNGWQ23/11/2016",
		"batchreference": "OWJYH-BatchPay",
		"name": "Batch - ansGl - 23/11/2016",
		"batchdescription": "This is a sample payment description.",
		"division": "Customer Division 2",
		"paymentdate": "23/11/2016",
		"paymentcurrency": "SGD",
		"debitaccount": {
			"id": "VHsxcHtyKW",
			"owner": {
				"id": "OPCUST15",
				"name": "AMCORP China Division",
				"localname": "AMCORP中国事业部",
				"address1": "L234 China Central Place",
				"address2": "No. 79 Jianguo Road",
				"address3": "Cjaoyang District",
				"address4": "Beijing",
				"postal": "100025",
				"country": "China",
				"email": "customer10@tbos.prototype.com"
			},
			"bank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"swiftbank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"type": "Savings",
			"currency": {
				"country": "Hong Kong",
				"code": "HKD",
				"currency": "Hong Kong Dollar"
			},
			"number": "8381986911",
			"name": "OPCUST15 Savings INWHS",
			"resident": "Resident",
			"availablebalance": "206515.49",
			"availablefunds": "482016.70"
		},
		"debitaccountnumber": "8381986911",
		"debitaccountname": "OPCUST15 Savings INWHS",
		"debitcurrency": "HKD",
		"debitaccountavailablebalance": "206515.49",
		"debitaccountavailablefunds": "482016.70",
		"individualdebitsflag": 1,
		"urgentflag": 0,
		"debitequivalentflag": 1,
		"ratetype": "",
		"rate": "",
		"fromccy": "",
		"toccy": "",
		"contracts": [],
		"totalpaymentamount": "6,743.55",
		"totaldebitamount": "39,667.86",
		"payments": [{
			"id": "xubapZUlnnGBLVKgMOFw",
			"number": 1,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "yQsrMgGwQX",
				"beneid": "JiqAhJ",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "8493789771",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "07/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "8493789771",
			"beneficiaryid": "JiqAhJ",
			"paymentreference": "PUSKBGyEtCr",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02125 - 其他经常项目支出 Other current acc transactions",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "3715.98",
			"paymentamount": "631.72"
		}, {
			"id": "sOJfGQCLiHjpIUsDpbKc",
			"number": 2,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "apkaZIISjg",
				"beneid": "fSahLW",
				"benename": "Omolon Technologies LLC.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1641827948",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "CITIBANK",
				"benebanklocalname": "",
				"benebankbranch": "Auckland Branch",
				"benebankaddress1": "Level 11 Citibank Centre",
				"benebankaddress2": "23 Customs Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "312-825",
				"swiftbank": "CITIBANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Auckland Branch",
				"swiftbankaddress1": "Level 11 Citibank Centre",
				"swiftbankaddress2": "23 Customs Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "CITINZ2102W",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "11/02/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Omolon Technologies LLC.",
			"beneficiaryaccountnumber": "1641827948",
			"beneficiaryid": "fSahLW",
			"paymentreference": "PcAnsNTJcqZ",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02115 - 服务贸易结算退款 Service trade settlement refund",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "664.64",
			"paymentamount": "112.99"
		}, {
			"id": "lWAofFzGoaqexQzGUrcI",
			"number": 3,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "vFoVpMDOUv",
				"beneid": "gIIXqy",
				"benename": "Omolon Technologies LLC.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "7279721395",
				"beneaccountccy": "AUD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "BANK OF MELBOURNE",
				"benebanklocalname": "",
				"benebankbranch": "Payments Branch",
				"benebankaddress1": "Level 8",
				"benebankaddress2": "530 Collins Street",
				"benebankaddress3": "",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "193-911",
				"swiftbank": "BANK OF MELBOURNE",
				"swiftbanklocalname": "",
				"swiftbranch": "Payments Branch",
				"swiftbankaddress1": "Level 8",
				"swiftbankaddress2": "530 Collins Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftcode": "BNKMDL2123",
				"benestatus": "Deleted",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "25/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Omolon Technologies LLC.",
			"beneficiaryaccountnumber": "7279721395",
			"beneficiaryid": "gIIXqy",
			"paymentreference": "PctsjGVEGTL",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02114 - 服务贸易结算 Service trade settlement",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "5573.45",
			"paymentamount": "947.49"
		}, {
			"id": "eHVGziDiSzBRAjOfNbcJ",
			"number": 4,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "sctiIQBtym",
				"beneid": "PIspzr",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8414282528",
				"beneaccountccy": "CNY",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"benebanklocalname": "英国渣打银行有限责任公司上海分行",
				"benebankbranch": "Shanghai Branch",
				"benebankaddress1": "Unit 1077/1079/108",
				"benebankaddress2": "No. 1018, Chang Ning Road",
				"benebankaddress3": "Shanghai",
				"benebankpostal": "200042",
				"benebankcity": "Shanghai",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "671290000017",
				"swiftbank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"swiftbanklocalname": "英国渣打银行有限责任公司上海分行",
				"swiftbranch": "Shanghai Branch",
				"swiftbankaddress1": "Unit 1077/1079/108",
				"swiftbankaddress2": "No. 1018, Chang Ning Road",
				"swiftbankaddress3": "Shanghai",
				"swiftbankpostal": "200042",
				"swiftbankcity": "Shanghai",
				"swiftbankcountry": "China",
				"swiftcode": "SCBLCNSXSHA",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "05/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "8414282528",
			"beneficiaryid": "PIspzr",
			"paymentreference": "PdQsMbPoVIN",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "6534.05",
			"paymentamount": "1110.79"
		}, {
			"id": "igkaXLIuLHWPFxmMFJiM",
			"number": 5,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "olMhJEeine",
				"beneid": "qMCySU",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "9626271547",
				"beneaccountccy": "SGD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "DBS BANK LTD SINGAPORE",
				"benebanklocalname": "",
				"benebankbranch": "DBS Shenton Way",
				"benebankaddress1": "MBFC Tower 3",
				"benebankaddress2": "12 Marina Boulevard",
				"benebankaddress3": "",
				"benebankpostal": "018982",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "DBSSSGSG",
				"swiftbank": "DBS BANK LTD SINGAPORE",
				"swiftbanklocalname": "",
				"swiftbranch": "DBS Shenton Way",
				"swiftbankaddress1": "MBFC Tower 3",
				"swiftbankaddress2": "12 Marina Boulevard",
				"swiftbankaddress3": "",
				"swiftbankpostal": "018982",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "DBSSSGSG",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "23/05/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "9626271547",
			"beneficiaryid": "qMCySU",
			"paymentreference": "PPLFRpdVGgE",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "5671.27",
			"paymentamount": "964.12"
		}, {
			"id": "suUeAkKdOAeBGBGjEJoT",
			"number": 6,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "wIwFQrGukW",
				"beneid": "xQDrXm",
				"benename": "Shield Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5324432951",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary13@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "30/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Shield Incorporated",
			"beneficiaryaccountnumber": "5324432951",
			"beneficiaryid": "xQDrXm",
			"paymentreference": "PLASclfEhJk",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "7823.06",
			"paymentamount": "1329.92"
		}, {
			"id": "MoAzonpGqJCoAjflMIXf",
			"number": 7,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "YmZEnHsTHT",
				"beneid": "hUUQac",
				"benename": "Farm To Table Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7523178956",
				"beneaccountccy": "CNY",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"benebanklocalname": "英国渣打银行有限责任公司上海分行",
				"benebankbranch": "Shanghai Branch",
				"benebankaddress1": "Unit 1077/1079/108",
				"benebankaddress2": "No. 1018, Chang Ning Road",
				"benebankaddress3": "Shanghai",
				"benebankpostal": "200042",
				"benebankcity": "Shanghai",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "671290000017",
				"swiftbank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"swiftbanklocalname": "英国渣打银行有限责任公司上海分行",
				"swiftbranch": "Shanghai Branch",
				"swiftbankaddress1": "Unit 1077/1079/108",
				"swiftbankaddress2": "No. 1018, Chang Ning Road",
				"swiftbankaddress3": "Shanghai",
				"swiftbankpostal": "200042",
				"swiftbankcity": "Shanghai",
				"swiftbankcountry": "China",
				"swiftcode": "SCBLCNSXSHA",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "13/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Farm To Table Inc.",
			"beneficiaryaccountnumber": "7523178956",
			"beneficiaryid": "hUUQac",
			"paymentreference": "PrHyuqfUlQv",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "4039.67",
			"paymentamount": "686.74"
		}, {
			"id": "FLowmkgVQdRlMaJOZrSh",
			"number": 8,
			"validated": true,
			"batchreference": "OWJYH-BatchPay",
			"beneficiary": {
				"id": "symlxiYwiP",
				"beneid": "IBSfjK",
				"benename": "Wallaby Services Pte. Ltd.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8455631618",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary14@opee.prototype.com",
				"benebank": "WESTPAC",
				"benebanklocalname": "",
				"benebankbranch": "Queen Street Branch",
				"benebankaddress1": "Westpac Tower",
				"benebankaddress2": "488 Queen Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "030-253",
				"swiftbank": "WESTPAC",
				"swiftbanklocalname": "",
				"swiftbranch": "Queen Street Branch",
				"swiftbankaddress1": "Westpac Tower",
				"swiftbankaddress2": "488 Queen Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "COOKNZ2A",
				"benestatus": "New",
				"beneworkflow": "Pending Approval - New",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "17/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Wallaby Services Pte. Ltd.",
			"beneficiaryaccountnumber": "8455631618",
			"beneficiaryid": "IBSfjK",
			"paymentreference": "PXzcrbFwEzs",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "Carded",
			"rate": 0.17,
			"contracts": [],
			"fromccy": "HKD",
			"toccy": "SGD",
			"debitequivalentamount": "5645.74",
			"paymentamount": "959.78"
		}],
		"numberofpayments": 8,
		"workflow": "New",
		"status": "Draft",
		"errors": [],
		"audit": [{
			"record": "ulPuMHQYOYIOORCrPaiV",
			"action": "Created",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Created",
			"fields": [],
			"comment": ""
		}, {
			"record": "ulPuMHQYOYIOORCrPaiV",
			"action": "Modified",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Modified",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "25/11/2016"
			}],
			"comment": ""
		}],
		"createdby": "Test User",
		"createdon": "23/11/2016",
		"lastmodifiedby": "Test User",
		"lastmodifiedon": "23/11/2016"
	}, {
		"id": "WbPAqJSVJNoCKlCPblFt",
		"category": "batch",
		"templateid": "TloDmHPNeHTMP",
		"templatename": "Template - Gww",
		"templatedescription": "This is a sample template description.",
		"type": "International Salary",
		"debitcredit": "DR",
		"batchid": "BKdnOn23/11/2016",
		"batchreference": "TSonM-BatchPay",
		"name": "Batch - GEaPD - 23/11/2016",
		"batchdescription": "This is a sample payment description.",
		"division": "Customer Division 2",
		"paymentdate": "23/11/2016",
		"paymentcurrency": "SGD",
		"debitaccount": {
			"id": "ovngIrepTr",
			"owner": {
				"id": "OPCUST13",
				"name": "Beijing Chemical Corporation",
				"localname": "北京化工股份有限公司",
				"address1": "L234 China Central Place",
				"address2": "No. 79 Jianguo Road",
				"address3": "Cjaoyang District",
				"address4": "Beijing",
				"postal": "100025",
				"country": "China",
				"email": "customer10@tbos.prototype.com"
			},
			"bank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"swiftbank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"type": "Current",
			"currency": {
				"country": "Hong Kong",
				"code": "HKD",
				"currency": "Hong Kong Dollar"
			},
			"number": "7582373588",
			"name": "OPCUST13 Current HIDOF",
			"resident": "Resident",
			"availablebalance": "367803.74",
			"availablefunds": "713952.99"
		},
		"debitaccountnumber": "7582373588",
		"debitaccountname": "OPCUST13 Current HIDOF",
		"debitcurrency": "HKD",
		"debitaccountavailablebalance": "367803.74",
		"debitaccountavailablefunds": "713952.99",
		"individualdebitsflag": 0,
		"urgentflag": 0,
		"debitequivalentflag": 1,
		"ratetype": "Carded",
		"rate": 0.17,
		"fromccy": "HKD",
		"toccy": "SGD",
		"contracts": [],
		"totalpaymentamount": "14,027.67",
		"totaldebitamount": "82,515.73",
		"payments": [{
			"id": "pBRjSWFRfacTmYlaIRNc",
			"number": 1,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "BlXzjwKRCI",
				"beneid": "klrnrB",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "9969921496",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Deleted",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "13/04/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "9969921496",
			"beneficiaryid": "klrnrB",
			"paymentreference": "PodNPzUkuia",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "1454.09"
		}, {
			"id": "YWiYtgzFQOWjTBhzMFBG",
			"number": 2,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "RzGzdTUCPl",
				"beneid": "ntszYY",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8883481438",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "COMMONWEALTH BANK",
				"benebanklocalname": "",
				"benebankbranch": "Commonwealth Bank",
				"benebankaddress1": "367 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "063-032",
				"swiftbank": "COMMONWEALTH BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Commonwealth Bank",
				"swiftbankaddress1": "367 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "CTBAAU2S",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "18/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "8883481438",
			"beneficiaryid": "ntszYY",
			"paymentreference": "PHQyArXDatw",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "8967.41"
		}, {
			"id": "inkPtsaYXcuSSDFncrtV",
			"number": 3,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "MsNpMsDwYB",
				"beneid": "MRypTG",
				"benename": "K-Media Creative Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1445998566",
				"beneaccountccy": "CNY",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary9@opee.prototype.com",
				"benebank": "CITIBANK (CHINA) CO., LTD.",
				"benebanklocalname": "美国花旗银行有限公司北京分行",
				"benebankbranch": "Beijing Branch",
				"benebankaddress1": "Floor 18, Citic International Building",
				"benebankaddress2": "19 Jianguomenwai Da Jie",
				"benebankaddress3": "Beijing",
				"benebankpostal": "100004",
				"benebankcity": "Beijing",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "531100000018",
				"swiftbank": "CITIBANK (CHINA) CO., LTD.",
				"swiftbanklocalname": "美国花旗银行有限公司北京分行",
				"swiftbranch": "Beijing Branch",
				"swiftbankaddress1": "Floor 18, Citic International Building",
				"swiftbankaddress2": "19 Jianguomenwai Da Jie",
				"swiftbankaddress3": "Beijing",
				"swiftbankpostal": "100004",
				"swiftbankcity": "Beijing",
				"swiftbankcountry": "China",
				"swiftcode": "CITICNSXBJG",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Deleted",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "18/04/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "K-Media Creative Services",
			"beneficiaryaccountnumber": "1445998566",
			"beneficiaryid": "MRypTG",
			"paymentreference": "PdfsIcZbRdZ",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "7484.40"
		}, {
			"id": "XdZTWLqRqmKvuhQZvYgx",
			"number": 4,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "XjljcNMkMJ",
				"beneid": "jqOfUe",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "9728343638",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "30/04/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "9728343638",
			"beneficiaryid": "jqOfUe",
			"paymentreference": "PyRUKgaMjlv",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "7224.91"
		}, {
			"id": "RgpjZeZGGilOktYcRgxo",
			"number": 5,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "lZgeyKOziU",
				"beneid": "WZxvJW",
				"benename": "Guardian Suppliers",
				"benelocalname": "卫供应商",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "6187199794",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary19@opee.prototype.com",
				"benebank": "CITIBANK",
				"benebanklocalname": "",
				"benebankbranch": "Auckland Branch",
				"benebankaddress1": "Level 11 Citibank Centre",
				"benebankaddress2": "23 Customs Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "312-825",
				"swiftbank": "CITIBANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Auckland Branch",
				"swiftbankaddress1": "Level 11 Citibank Centre",
				"swiftbankaddress2": "23 Customs Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "CITINZ2102W",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "05/06/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Guardian Suppliers",
			"beneficiaryaccountnumber": "6187199794",
			"beneficiaryid": "WZxvJW",
			"paymentreference": "PnPMtLztOQU",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "1168.35"
		}, {
			"id": "iJaDBfEWwuwZIvLRirAW",
			"number": 6,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "EZamnIYxmK",
				"beneid": "IWBJGN",
				"benename": "Omolon Technologies LLC.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "4849882221",
				"beneaccountccy": "AUD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "15/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Omolon Technologies LLC.",
			"beneficiaryaccountnumber": "4849882221",
			"beneficiaryid": "IWBJGN",
			"paymentreference": "PlUkFrKamxx",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "2401.77"
		}, {
			"id": "NWkTpVFQobsKFYzkzbNt",
			"number": 7,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "ZNleNtKBUl",
				"beneid": "kvRHCf",
				"benename": "CBGB Global Enterprises",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "9783525792",
				"beneaccountccy": "HKD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "08/11/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "CBGB Global Enterprises",
			"beneficiaryaccountnumber": "9783525792",
			"beneficiaryid": "kvRHCf",
			"paymentreference": "PJilgAMNdRX",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "8853.06"
		}, {
			"id": "yBnrOzLgSsmLRYbvEqoc",
			"number": 8,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "hFXrPVIYQC",
				"beneid": "OYgfsO",
				"benename": "Shield Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7238584274",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary13@opee.prototype.com",
				"benebank": "WESTPAC",
				"benebanklocalname": "",
				"benebankbranch": "Queen Street Branch",
				"benebankaddress1": "Westpac Tower",
				"benebankaddress2": "488 Queen Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "030-253",
				"swiftbank": "WESTPAC",
				"swiftbanklocalname": "",
				"swiftbranch": "Queen Street Branch",
				"swiftbankaddress1": "Westpac Tower",
				"swiftbankaddress2": "488 Queen Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "COOKNZ2A",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "14/04/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Shield Incorporated",
			"beneficiaryaccountnumber": "7238584274",
			"beneficiaryid": "OYgfsO",
			"paymentreference": "PUzSgsFlmoE",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "5084.66"
		}, {
			"id": "CPpsLFOtlOJdurrMDvry",
			"number": 9,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "ituDcVUHeD",
				"beneid": "pXWwHV",
				"benename": "CBGB Global Enterprises",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5153156142",
				"beneaccountccy": "NZD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "13/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "CBGB Global Enterprises",
			"beneficiaryaccountnumber": "5153156142",
			"beneficiaryid": "pXWwHV",
			"paymentreference": "PrMbndrlfFV",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "7088.85"
		}, {
			"id": "MAjmOjVAftYPbLNXBIBm",
			"number": 10,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "zmOJsrezrF",
				"beneid": "cReMtd",
				"benename": "Bear Logistics Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5723852657",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary5@opee.prototype.com",
				"benebank": "COMMONWEALTH BANK",
				"benebanklocalname": "",
				"benebankbranch": "Commonwealth Bank",
				"benebankaddress1": "367 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "063-032",
				"swiftbank": "COMMONWEALTH BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Commonwealth Bank",
				"swiftbankaddress1": "367 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "CTBAAU2S",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "21/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Bear Logistics Services",
			"beneficiaryaccountnumber": "5723852657",
			"beneficiaryid": "cReMtd",
			"paymentreference": "PsQequWMIfq",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "8098.04"
		}, {
			"id": "BineFTEFXEzSKYFEHRFo",
			"number": 11,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "hDJaYwFWmr",
				"beneid": "jEOUJJ",
				"benename": "The Hawthorne Group",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7327953445",
				"beneaccountccy": "CNY",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary8@opee.prototype.com",
				"benebank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"benebanklocalname": "英国渣打银行有限责任公司上海分行",
				"benebankbranch": "Shanghai Branch",
				"benebankaddress1": "Unit 1077/1079/108",
				"benebankaddress2": "No. 1018, Chang Ning Road",
				"benebankaddress3": "Shanghai",
				"benebankpostal": "200042",
				"benebankcity": "Shanghai",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "671290000017",
				"swiftbank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"swiftbanklocalname": "英国渣打银行有限责任公司上海分行",
				"swiftbranch": "Shanghai Branch",
				"swiftbankaddress1": "Unit 1077/1079/108",
				"swiftbankaddress2": "No. 1018, Chang Ning Road",
				"swiftbankaddress3": "Shanghai",
				"swiftbankpostal": "200042",
				"swiftbankcity": "Shanghai",
				"swiftbankcountry": "China",
				"swiftcode": "SCBLCNSXSHA",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "21/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "The Hawthorne Group",
			"beneficiaryaccountnumber": "7327953445",
			"beneficiaryid": "jEOUJJ",
			"paymentreference": "PjXivzArXZG",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "6457.37"
		}, {
			"id": "dkNctKrCanAoWFxolRUV",
			"number": 12,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "pLwBXOcYOa",
				"beneid": "GfpWvk",
				"benename": "Simple Delights",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "5533589759",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary1@opee.prototype.com",
				"benebank": "CITIBANK",
				"benebanklocalname": "",
				"benebankbranch": "Auckland Branch",
				"benebankaddress1": "Level 11 Citibank Centre",
				"benebankaddress2": "23 Customs Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "312-825",
				"swiftbank": "CITIBANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Auckland Branch",
				"swiftbankaddress1": "Level 11 Citibank Centre",
				"swiftbankaddress2": "23 Customs Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "CITINZ2102W",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "10/11/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Simple Delights",
			"beneficiaryaccountnumber": "5533589759",
			"beneficiaryid": "GfpWvk",
			"paymentreference": "PosFIVOahzl",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "3728.55"
		}, {
			"id": "cSYMonectEfmpxJtXGCB",
			"number": 13,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "GqLrmiYxLb",
				"beneid": "UGXFjE",
				"benename": "Specialist Data Analysis Centre Of New Zealand",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5595444418",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary6@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "New",
				"beneworkflow": "Pending Approval - New",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "19/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Specialist Data Analysis Centre Of New Zealand",
			"beneficiaryaccountnumber": "5595444418",
			"beneficiaryid": "UGXFjE",
			"paymentreference": "PkOtQIwAxxE",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "6635.59"
		}, {
			"id": "gXSzgHTcTWjNNtmgsZrl",
			"number": 14,
			"validated": true,
			"batchreference": "TSonM-BatchPay",
			"beneficiary": {
				"id": "symlxiYwiP",
				"beneid": "IBSfjK",
				"benename": "Wallaby Services Pte. Ltd.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8455631618",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary14@opee.prototype.com",
				"benebank": "WESTPAC",
				"benebanklocalname": "",
				"benebankbranch": "Queen Street Branch",
				"benebankaddress1": "Westpac Tower",
				"benebankaddress2": "488 Queen Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "030-253",
				"swiftbank": "WESTPAC",
				"swiftbanklocalname": "",
				"swiftbranch": "Queen Street Branch",
				"swiftbankaddress1": "Westpac Tower",
				"swiftbankaddress2": "488 Queen Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "COOKNZ2A",
				"benestatus": "New",
				"beneworkflow": "Pending Approval - New",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "17/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Wallaby Services Pte. Ltd.",
			"beneficiaryaccountnumber": "8455631618",
			"beneficiaryid": "IBSfjK",
			"paymentreference": "PSKjXAkmpaH",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Rejected",
			"errors": [],
			"paymentmethod": "Telegraphic Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "7868.68"
		}],
		"numberofpayments": 14,
		"workflow": "New",
		"status": "Rejected",
		"errors": [],
		"audit": [{
			"record": "WbPAqJSVJNoCKlCPblFt",
			"action": "Created",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Created",
			"fields": [],
			"comment": ""
		}, {
			"record": "WbPAqJSVJNoCKlCPblFt",
			"action": "Modified",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Modified",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "23/12/2016"
			}],
			"comment": ""
		}],
		"createdby": "Test User",
		"createdon": "23/11/2016",
		"lastmodifiedby": "Test User",
		"lastmodifiedon": "23/11/2016"
	}, {
		"id": "tibXUcobgAYtlVewvZkc",
		"category": "batch",
		"templateid": "OdSKOscYvYTMP",
		"templatename": "Template - vCW",
		"templatedescription": "This is a sample template description.",
		"type": "Domestic",
		"debitcredit": "DR",
		"batchid": "BePNIX23/11/2016",
		"batchreference": "geeoN-BatchPay",
		"name": "Batch - Fqiam - 23/11/2016",
		"batchdescription": "This is a sample payment description.",
		"division": "Customer Division 2",
		"paymentdate": "23/11/2016",
		"paymentcurrency": "HKD",
		"debitaccount": {
			"id": "UOsgeuDWXX",
			"owner": {
				"id": "OPCUST05",
				"name": "Clear Sky Financial Services",
				"localname": "晴空金融服務",
				"address1": "L234 China Central Place",
				"address2": "No. 79 Jianguo Road",
				"address3": "Cjaoyang District",
				"address4": "Beijing",
				"postal": "100025",
				"country": "China",
				"email": "customer5@tbos.prototype.com"
			},
			"bank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"swiftbank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"type": "Current",
			"currency": {
				"country": "Hong Kong",
				"code": "HKD",
				"currency": "Hong Kong Dollar"
			},
			"number": "2265911258",
			"name": "OPCUST05 Current VQGPF",
			"resident": "Resident",
			"availablebalance": "672633.09",
			"availablefunds": "124334.59"
		},
		"debitaccountnumber": "2265911258",
		"debitaccountname": "OPCUST05 Current VQGPF",
		"debitcurrency": "HKD",
		"debitaccountavailablebalance": "672633.09",
		"debitaccountavailablefunds": "124334.59",
		"individualdebitsflag": 1,
		"urgentflag": 0,
		"debitequivalentflag": 0,
		"ratetype": "",
		"rate": "",
		"fromccy": "",
		"toccy": "",
		"contracts": [],
		"totalpaymentamount": "53,763.49",
		"totaldebitamount": "53,763.49",
		"payments": [{
			"id": "zkWMzOGoUyXAVpVvciOp",
			"number": 1,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "GqLrmiYxLb",
				"beneid": "UGXFjE",
				"benename": "Specialist Data Analysis Centre Of New Zealand",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5595444418",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary6@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "New",
				"beneworkflow": "Pending Approval - New",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "19/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Specialist Data Analysis Centre Of New Zealand",
			"beneficiaryaccountnumber": "5595444418",
			"beneficiaryid": "UGXFjE",
			"paymentreference": "PsAOLSHNHCp",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02116 - 资本项下跨境支付 X-border pmt under capital acc",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "5075.87",
			"debitequivalentamount": "5075.87"
		}, {
			"id": "OVsrwlhGLxaSwWexqfgI",
			"number": 2,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "CZrWgKeBnB",
				"beneid": "OSVUfq",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "4419389765",
				"beneaccountccy": "HKD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "29/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "4419389765",
			"beneficiaryid": "OSVUfq",
			"paymentreference": "PagNxyjFLiQ",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02113 - 货物贸易结算退款 Goods trade settlement refund",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "8523.07",
			"debitequivalentamount": "8523.07"
		}, {
			"id": "RCaQFZRjHyOGtcxJEAgq",
			"number": 3,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "zmOJsrezrF",
				"beneid": "cReMtd",
				"benename": "Bear Logistics Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5723852657",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary5@opee.prototype.com",
				"benebank": "COMMONWEALTH BANK",
				"benebanklocalname": "",
				"benebankbranch": "Commonwealth Bank",
				"benebankaddress1": "367 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "063-032",
				"swiftbank": "COMMONWEALTH BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Commonwealth Bank",
				"swiftbankaddress1": "367 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "CTBAAU2S",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "21/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Bear Logistics Services",
			"beneficiaryaccountnumber": "5723852657",
			"beneficiaryid": "cReMtd",
			"paymentreference": "PxMdUNhdCLn",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "6068.09",
			"debitequivalentamount": "6068.09"
		}, {
			"id": "ysPcCQcfQdvFTjRmWNjp",
			"number": 4,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "kpEJKZFcwK",
				"beneid": "ZJSMVg",
				"benename": "Flow Water Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "6877688931",
				"beneaccountccy": "NZD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary10@opee.prototype.com",
				"benebank": "CITIBANK",
				"benebanklocalname": "",
				"benebankbranch": "Auckland Branch",
				"benebankaddress1": "Level 11 Citibank Centre",
				"benebankaddress2": "23 Customs Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "312-825",
				"swiftbank": "CITIBANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Auckland Branch",
				"swiftbankaddress1": "Level 11 Citibank Centre",
				"swiftbankaddress2": "23 Customs Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "CITINZ2102W",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "12/06/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Flow Water Incorporated",
			"beneficiaryaccountnumber": "6877688931",
			"beneficiaryid": "ZJSMVg",
			"paymentreference": "PoSWVIUrwNZ",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02115 - 服务贸易结算退款 Service trade settlement refund",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "7928.15",
			"debitequivalentamount": "7928.15"
		}, {
			"id": "vkNGmqoixRqPQEsQOIwi",
			"number": 5,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "IJaKKypvwE",
				"beneid": "LGRVrm",
				"benename": "Flow Water Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "9991223648",
				"beneaccountccy": "HKD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary10@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "10/05/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Flow Water Incorporated",
			"beneficiaryaccountnumber": "9991223648",
			"beneficiaryid": "LGRVrm",
			"paymentreference": "PawRFlNdPVt",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "1948.72",
			"debitequivalentamount": "1948.72"
		}, {
			"id": "qQlMcfibDVHgCPrwWGry",
			"number": 6,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "ySDuzRjzpk",
				"beneid": "ZYFLHt",
				"benename": "Emilio Carloti Imports & Exports",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "4668798589",
				"beneaccountccy": "HKD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "03/02/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Emilio Carloti Imports & Exports",
			"beneficiaryaccountnumber": "4668798589",
			"beneficiaryid": "ZYFLHt",
			"paymentreference": "PDlupxwxcWb",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "3933.39",
			"debitequivalentamount": "3933.39"
		}, {
			"id": "PvMJyDnTCqQbZWjvUFtp",
			"number": 7,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "zmOJsrezrF",
				"beneid": "cReMtd",
				"benename": "Bear Logistics Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "5723852657",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary5@opee.prototype.com",
				"benebank": "COMMONWEALTH BANK",
				"benebanklocalname": "",
				"benebankbranch": "Commonwealth Bank",
				"benebankaddress1": "367 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "063-032",
				"swiftbank": "COMMONWEALTH BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Commonwealth Bank",
				"swiftbankaddress1": "367 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "CTBAAU2S",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "21/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Bear Logistics Services",
			"beneficiaryaccountnumber": "5723852657",
			"beneficiaryid": "cReMtd",
			"paymentreference": "PzHebQJQsZF",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "9198.01",
			"debitequivalentamount": "9198.01"
		}, {
			"id": "JSmoecoBssnRXFPTjQbC",
			"number": 8,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "wQuiMnTsqz",
				"beneid": "iMAkZV",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "7341726427",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "HSBC BANK",
				"benebanklocalname": "",
				"benebankbranch": "Alliance Branch",
				"benebankaddress1": "Level 9 HSBC House",
				"benebankaddress2": "One Queen Street",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "302-935",
				"swiftbank": "HSBC BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Alliance Branch",
				"swiftbankaddress1": "Level 9 HSBC House",
				"swiftbankaddress2": "One Queen Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "HSBCNZ2A",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "01/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "7341726427",
			"beneficiaryid": "iMAkZV",
			"paymentreference": "PANKsmtvIdF",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "8833.90",
			"debitequivalentamount": "8833.90"
		}, {
			"id": "RiScUgUXflNzfKwXGVcA",
			"number": 9,
			"validated": true,
			"batchreference": "geeoN-BatchPay",
			"beneficiary": {
				"id": "jawCBcWYlA",
				"beneid": "RvExSV",
				"benename": "Shin Low Trading Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "3895384644",
				"beneaccountccy": "CNY",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary11@opee.prototype.com",
				"benebank": "CITIBANK (CHINA) CO., LTD.",
				"benebanklocalname": "美国花旗银行有限公司北京分行",
				"benebankbranch": "Beijing Branch",
				"benebankaddress1": "Floor 18, Citic International Building",
				"benebankaddress2": "19 Jianguomenwai Da Jie",
				"benebankaddress3": "Beijing",
				"benebankpostal": "100004",
				"benebankcity": "Beijing",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "531100000018",
				"swiftbank": "CITIBANK (CHINA) CO., LTD.",
				"swiftbanklocalname": "美国花旗银行有限公司北京分行",
				"swiftbranch": "Beijing Branch",
				"swiftbankaddress1": "Floor 18, Citic International Building",
				"swiftbankaddress2": "19 Jianguomenwai Da Jie",
				"swiftbankaddress3": "Beijing",
				"swiftbankpostal": "100004",
				"swiftbankcity": "Beijing",
				"swiftbankcountry": "China",
				"swiftcode": "CITICNSXBJG",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "27/05/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Shin Low Trading Inc.",
			"beneficiaryaccountnumber": "3895384644",
			"beneficiaryid": "RvExSV",
			"paymentreference": "PhrUwFokvCv",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "HKD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Draft",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"paymentamount": "2254.29",
			"debitequivalentamount": "2254.29"
		}],
		"numberofpayments": 9,
		"workflow": "New",
		"status": "Draft",
		"errors": [],
		"audit": [{
			"record": "tibXUcobgAYtlVewvZkc",
			"action": "Created",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Created",
			"fields": [],
			"comment": ""
		}, {
			"record": "tibXUcobgAYtlVewvZkc",
			"action": "Modified",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Modified",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "24/11/2016"
			}],
			"comment": ""
		}],
		"createdby": "Test User",
		"createdon": "23/11/2016",
		"lastmodifiedby": "Test User",
		"lastmodifiedon": "23/11/2016"
	}, {
		"id": "tddrDyGNGDzRrMtvxFmh",
		"category": "batch",
		"templateid": "rKyxCdrZwUTMP",
		"templatename": "Template - CbE",
		"templatedescription": "This is a sample template description.",
		"type": "Domestic",
		"debitcredit": "DR",
		"batchid": "BcfcdI23/11/2016",
		"batchreference": "LEzYw-BatchPay",
		"name": "Batch - pUUMi - 23/11/2016",
		"batchdescription": "This is a sample payment description.",
		"division": "Customer Division 1",
		"paymentdate": "23/11/2016",
		"paymentcurrency": "SGD",
		"debitaccount": {
			"id": "ovngIrepTr",
			"owner": {
				"id": "OPCUST13",
				"name": "Beijing Chemical Corporation",
				"localname": "北京化工股份有限公司",
				"address1": "L234 China Central Place",
				"address2": "No. 79 Jianguo Road",
				"address3": "Cjaoyang District",
				"address4": "Beijing",
				"postal": "100025",
				"country": "China",
				"email": "customer10@tbos.prototype.com"
			},
			"bank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"swiftbank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"type": "Current",
			"currency": {
				"country": "Hong Kong",
				"code": "HKD",
				"currency": "Hong Kong Dollar"
			},
			"number": "7582373588",
			"name": "OPCUST13 Current HIDOF",
			"resident": "Resident",
			"availablebalance": "367803.74",
			"availablefunds": "713952.99"
		},
		"debitaccountnumber": "7582373588",
		"debitaccountname": "OPCUST13 Current HIDOF",
		"debitcurrency": "HKD",
		"debitaccountavailablebalance": "367803.74",
		"debitaccountavailablefunds": "713952.99",
		"individualdebitsflag": 1,
		"urgentflag": 0,
		"debitequivalentflag": 0,
		"ratetype": "",
		"rate": "",
		"fromccy": "",
		"toccy": "",
		"contracts": [],
		"totalpaymentamount": "28,194.85",
		"totaldebitamount": "162,966.22",
		"payments": [{
			"id": "HMJkoehokJcLQOQnPAlb",
			"number": 1,
			"validated": true,
			"batchreference": "LEzYw-BatchPay",
			"beneficiary": {
				"id": "CZrWgKeBnB",
				"beneid": "OSVUfq",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "4419389765",
				"beneaccountccy": "HKD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "29/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "4419389765",
			"beneficiaryid": "OSVUfq",
			"paymentreference": "PNmWLHBunpc",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Pending Approval",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "Carded",
			"rate": 5.78,
			"contracts": [],
			"fromccy": "SGD",
			"toccy": "HKD",
			"paymentamount": "9536.07",
			"debitequivalentamount": "55118.48"
		}, {
			"id": "eiCBnluotldNjscpVlNY",
			"number": 2,
			"validated": true,
			"batchreference": "LEzYw-BatchPay",
			"beneficiary": {
				"id": "kvWjElOSdA",
				"beneid": "gdERzS",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "6364354895",
				"beneaccountccy": "SGD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Ocean Financial Centre",
				"benebankaddress1": "Ocean Financial Centre",
				"benebankaddress2": "10 Collyer Quay",
				"benebankaddress3": "30-00",
				"benebankpostal": "049315",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "ANZBSGSX",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Ocean Financial Centre",
				"swiftbankaddress1": "Ocean Financial Centre",
				"swiftbankaddress2": "10 Collyer Quay",
				"swiftbankaddress3": "30-00",
				"swiftbankpostal": "049315",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "ANZBSGSX",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "26/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "6364354895",
			"beneficiaryid": "gdERzS",
			"paymentreference": "PbEZvzjuxDS",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Pending Approval",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "Carded",
			"rate": 5.78,
			"contracts": [],
			"fromccy": "SGD",
			"toccy": "HKD",
			"paymentamount": "2400.76",
			"debitequivalentamount": "13876.39"
		}, {
			"id": "HlhBjFmBvUGKuGGlYQEH",
			"number": 3,
			"validated": true,
			"batchreference": "LEzYw-BatchPay",
			"beneficiary": {
				"id": "ZNleNtKBUl",
				"beneid": "kvRHCf",
				"benename": "CBGB Global Enterprises",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "9783525792",
				"beneaccountccy": "HKD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "Deutsche Bank AG",
				"benebanklocalname": "",
				"benebankbranch": "Kownloon Branch",
				"benebankaddress1": "1 Austin Road West",
				"benebankaddress2": "Level 52, International Commerce Centre",
				"benebankaddress3": "Kowloon",
				"benebankpostal": "",
				"benebankcity": "Hong Kong",
				"benebankcountry": "Hong Kong",
				"benebankclearingtype": "China National Clearing Code",
				"benebankclearingcode": "CN989584005403",
				"swiftbank": "Deutsche Bank AG",
				"swiftbanklocalname": "",
				"swiftbranch": "Kownloon Branch",
				"swiftbankaddress1": "1 Austin Road West",
				"swiftbankaddress2": "Kowloon",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Hong Kong",
				"swiftbankcountry": "Hong Kong",
				"swiftcode": "DEUTHKHHXXX",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "08/11/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "CBGB Global Enterprises",
			"beneficiaryaccountnumber": "9783525792",
			"beneficiaryid": "kvRHCf",
			"paymentreference": "PzPjgBhoSlo",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Pending Approval",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02113 - 货物贸易结算退款 Goods trade settlement refund",
			"ratetype": "Carded",
			"rate": 5.78,
			"contracts": [],
			"fromccy": "SGD",
			"toccy": "HKD",
			"paymentamount": "5437.09",
			"debitequivalentamount": "31426.38"
		}, {
			"id": "MmznzOmKHcLVjZDHNnYX",
			"number": 4,
			"validated": true,
			"batchreference": "LEzYw-BatchPay",
			"beneficiary": {
				"id": "UvzIVCfwDq",
				"beneid": "PoYYiY",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7154122512",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "02/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "7154122512",
			"beneficiaryid": "PoYYiY",
			"paymentreference": "PMzeQZCPUDh",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Pending Approval",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "Carded",
			"rate": 5.78,
			"contracts": [],
			"fromccy": "SGD",
			"toccy": "HKD",
			"paymentamount": "6902.80",
			"debitequivalentamount": "39898.18"
		}, {
			"id": "dKUFgYYfuIQdFvLOiUAx",
			"number": 5,
			"validated": true,
			"batchreference": "LEzYw-BatchPay",
			"beneficiary": {
				"id": "xfwMaFvyIg",
				"beneid": "ioSfEi",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8448994282",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "BANK OF MELBOURNE",
				"benebanklocalname": "",
				"benebankbranch": "Payments Branch",
				"benebankaddress1": "Level 8",
				"benebankaddress2": "530 Collins Street",
				"benebankaddress3": "",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "193-911",
				"swiftbank": "BANK OF MELBOURNE",
				"swiftbanklocalname": "",
				"swiftbranch": "Payments Branch",
				"swiftbankaddress1": "Level 8",
				"swiftbankaddress2": "530 Collins Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftcode": "BNKMDL2123",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Deleted",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "07/08/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "8448994282",
			"beneficiaryid": "ioSfEi",
			"paymentreference": "PgXDlIMWitb",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "SGD",
			"debitaccountcurrency": "HKD",
			"workflow": "New",
			"status": "Pending Approval",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "Carded",
			"rate": 5.78,
			"contracts": [],
			"fromccy": "SGD",
			"toccy": "HKD",
			"paymentamount": "3918.13",
			"debitequivalentamount": "22646.79"
		}],
		"numberofpayments": 5,
		"workflow": "New",
		"status": "Pending Approval",
		"errors": [],
		"audit": [{
			"record": "tddrDyGNGDzRrMtvxFmh",
			"action": "Created",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Created",
			"fields": [],
			"comment": ""
		}, {
			"record": "tddrDyGNGDzRrMtvxFmh",
			"action": "Modified",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Modified",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "20/12/2016"
			}],
			"comment": ""
		}, {
			"record": "tddrDyGNGDzRrMtvxFmh",
			"action": "Submitted For Approval",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Submitted For Approval",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "27/11/2016"
			}],
			"comment": ""
		}],
		"createdby": "Test User",
		"createdon": "23/11/2016",
		"lastmodifiedby": "Test User",
		"lastmodifiedon": "23/11/2016"
	}, {
		"id": "zPNdbVslnCNShQaRnMJX",
		"category": "batch",
		"templateid": "vkuErMmElnTMP",
		"templatename": "Template - AFT",
		"templatedescription": "This is a sample template description.",
		"type": "Domestic",
		"debitcredit": "DR",
		"batchid": "BYOXLP23/11/2016",
		"batchreference": "tAKkt-BatchPay",
		"name": "Batch - QxIKi - 23/11/2016",
		"batchdescription": "This is a sample payment description.",
		"division": "Customer Division 2",
		"paymentdate": "23/11/2016",
		"paymentcurrency": "CNY",
		"debitaccount": {
			"id": "SIEcyJbrCP",
			"owner": {
				"id": "OPCUST13",
				"name": "Beijing Chemical Corporation",
				"localname": "北京化工股份有限公司",
				"address1": "L234 China Central Place",
				"address2": "No. 79 Jianguo Road",
				"address3": "Cjaoyang District",
				"address4": "Beijing",
				"postal": "100025",
				"country": "China",
				"email": "customer10@tbos.prototype.com"
			},
			"bank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"swiftbank": {
				"id": "OPCBANK01",
				"name": "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
				"localname": "澳大利亚和新西兰银行集团上海分行",
				"branch": "Shanghai Branch",
				"address1": "Raffles City, Floor 22",
				"address2": "268 Xizang Middle Road",
				"address3": "Shanghai",
				"postal": "200001",
				"country": "China",
				"swift": "ANZBCNSH",
				"clearing": {
					"type": "CNAPS",
					"code": "761290013606"
				}
			},
			"type": "Savings",
			"currency": {
				"country": "Hong Kong",
				"code": "HKD",
				"currency": "Hong Kong Dollar"
			},
			"number": "9246695379",
			"name": "OPCUST13 Savings GVHKH",
			"resident": "Resident",
			"availablebalance": "226245.25",
			"availablefunds": "782363.03"
		},
		"debitaccountnumber": "9246695379",
		"debitaccountname": "OPCUST13 Savings GVHKH",
		"debitcurrency": "HKD",
		"debitaccountavailablebalance": "226245.25",
		"debitaccountavailablefunds": "782363.03",
		"individualdebitsflag": 0,
		"urgentflag": 0,
		"debitequivalentflag": 1,
		"ratetype": "Carded",
		"rate": 0.85,
		"fromccy": "HKD",
		"toccy": "CNY",
		"contracts": [],
		"totalpaymentamount": "83,611.95",
		"totaldebitamount": "98,367.00",
		"payments": [{
			"id": "OWtSJmBsaAjLBrRaUMEY",
			"number": 1,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "LOVmcOXCft",
				"beneid": "SBuJLT",
				"benename": "Flow Water Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1237855859",
				"beneaccountccy": "NZD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary10@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Tawa Branch",
				"benebankaddress1": "C/-0546 12 Hagley Street",
				"benebankaddress2": "Porirua",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "010-553",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Tawa Branch",
				"swiftbankaddress1": "C/-0546 12 Hagley Street",
				"swiftbankaddress2": "Porirua",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "ANZBNZ22",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "08/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Flow Water Incorporated",
			"beneficiaryaccountnumber": "1237855859",
			"beneficiaryid": "SBuJLT",
			"paymentreference": "PwSymZXCWBB",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "9466.37"
		}, {
			"id": "CzrUBOLDaUbNMFlftubL",
			"number": 2,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "rxrgWlywiI",
				"beneid": "bSwpoB",
				"benename": "Shin Low Trading Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "7418878749",
				"beneaccountccy": "SGD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary11@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Ocean Financial Centre",
				"benebankaddress1": "Ocean Financial Centre",
				"benebankaddress2": "10 Collyer Quay",
				"benebankaddress3": "30-00",
				"benebankpostal": "049315",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "ANZBSGSX",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Ocean Financial Centre",
				"swiftbankaddress1": "Ocean Financial Centre",
				"swiftbankaddress2": "10 Collyer Quay",
				"swiftbankaddress3": "30-00",
				"swiftbankpostal": "049315",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "ANZBSGSX",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "28/07/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Shin Low Trading Inc.",
			"beneficiaryaccountnumber": "7418878749",
			"beneficiaryid": "bSwpoB",
			"paymentreference": "PFBHoRaPkyI",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02113 - 货物贸易结算退款 Goods trade settlement refund",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "4217.86"
		}, {
			"id": "PunQkoVujNDZqSznhzZG",
			"number": 3,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "eOUNwGaDgb",
				"beneid": "VBZMOP",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "9522696526",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "01/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "9522696526",
			"beneficiaryid": "VBZMOP",
			"paymentreference": "PYiTCBkTRnP",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02117 - 资本项下跨境支付退款 X-border pmt refund capital",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "4796.69"
		}, {
			"id": "nHPkqiaMJtmiHDsVNAyx",
			"number": 4,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "XauMhRiSlH",
				"beneid": "XhTVhM",
				"benename": "CBGB Global Enterprises",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8853151111",
				"beneaccountccy": "NZD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "14/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "CBGB Global Enterprises",
			"beneficiaryaccountnumber": "8853151111",
			"beneficiaryid": "XhTVhM",
			"paymentreference": "POIBMbpCiyY",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "7794.14"
		}, {
			"id": "QwqpAdRWcOThKSUSvnUK",
			"number": 5,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "rDiJurZfHE",
				"beneid": "lICsiy",
				"benename": "K-Media Creative Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "3759875381",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary9@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Tawa Branch",
				"benebankaddress1": "C/-0546 12 Hagley Street",
				"benebankaddress2": "Porirua",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "010-553",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Tawa Branch",
				"swiftbankaddress1": "C/-0546 12 Hagley Street",
				"swiftbankaddress2": "Porirua",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "ANZBNZ22",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "13/08/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "K-Media Creative Services",
			"beneficiaryaccountnumber": "3759875381",
			"beneficiaryid": "lICsiy",
			"paymentreference": "PMALrayOzcE",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "247.50"
		}, {
			"id": "YbaJYZHmltsEIEVJHHnx",
			"number": 6,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "ZzArwobhac",
				"beneid": "HxpaCE",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "5914628776",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "HSBC BANK",
				"benebanklocalname": "",
				"benebankbranch": "Alliance Branch",
				"benebankaddress1": "Level 9 HSBC House",
				"benebankaddress2": "One Queen Street",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "302-935",
				"swiftbank": "HSBC BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Alliance Branch",
				"swiftbankaddress1": "Level 9 HSBC House",
				"swiftbankaddress2": "One Queen Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "HSBCNZ2A",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Deleted",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "10/11/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "5914628776",
			"beneficiaryid": "HxpaCE",
			"paymentreference": "PaBLzxIMoqn",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "8594.92"
		}, {
			"id": "zRywwLWzZNYtlnpPsySK",
			"number": 7,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "MQpjUoRZmv",
				"beneid": "aBBjme",
				"benename": "Farm To Table Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "7888324994",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "WESTPAC",
				"benebanklocalname": "",
				"benebankbranch": "Queen Street Branch",
				"benebankaddress1": "Westpac Tower",
				"benebankaddress2": "488 Queen Street",
				"benebankaddress3": "Auckland",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "030-253",
				"swiftbank": "WESTPAC",
				"swiftbanklocalname": "",
				"swiftbranch": "Queen Street Branch",
				"swiftbankaddress1": "Westpac Tower",
				"swiftbankaddress2": "488 Queen Street",
				"swiftbankaddress3": "Auckland",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "COOKNZ2A",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "23/07/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Farm To Table Inc.",
			"beneficiaryaccountnumber": "7888324994",
			"beneficiaryid": "aBBjme",
			"paymentreference": "POUFqUpROpI",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "109.09"
		}, {
			"id": "lbIhRbkvUdPRVgxNLsUH",
			"number": 8,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "eotYmuTNRu",
				"beneid": "rFTDaM",
				"benename": "20/20 Financial Services",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "6863673966",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary7@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "05/10/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "20/20 Financial Services",
			"beneficiaryaccountnumber": "6863673966",
			"beneficiaryid": "rFTDaM",
			"paymentreference": "PRrGWtxUrTh",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "6975.77"
		}, {
			"id": "QutZCYTUUReyiKgFtXaG",
			"number": 9,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "EZamnIYxmK",
				"beneid": "IWBJGN",
				"benename": "Omolon Technologies LLC.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "4849882221",
				"beneaccountccy": "AUD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "15/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Omolon Technologies LLC.",
			"beneficiaryaccountnumber": "4849882221",
			"beneficiaryid": "IWBJGN",
			"paymentreference": "PdIfGAYMlyz",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "8351.70"
		}, {
			"id": "UcBWSzREZTzkXZpqidzK",
			"number": 10,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "UNSNzdgEqk",
				"beneid": "gJKWAD",
				"benename": "King Corporate Training",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "9174874476",
				"beneaccountccy": "CNY",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary3@opee.prototype.com",
				"benebank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"benebanklocalname": "英国渣打银行有限责任公司上海分行",
				"benebankbranch": "Shanghai Branch",
				"benebankaddress1": "Unit 1077/1079/108",
				"benebankaddress2": "No. 1018, Chang Ning Road",
				"benebankaddress3": "Shanghai",
				"benebankpostal": "200042",
				"benebankcity": "Shanghai",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "671290000017",
				"swiftbank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"swiftbanklocalname": "英国渣打银行有限责任公司上海分行",
				"swiftbranch": "Shanghai Branch",
				"swiftbankaddress1": "Unit 1077/1079/108",
				"swiftbankaddress2": "No. 1018, Chang Ning Road",
				"swiftbankaddress3": "Shanghai",
				"swiftbankpostal": "200042",
				"swiftbankcity": "Shanghai",
				"swiftbankcountry": "China",
				"swiftcode": "SCBLCNSXSHA",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Deleted",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "15/11/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "King Corporate Training",
			"beneficiaryaccountnumber": "9174874476",
			"beneficiaryid": "gJKWAD",
			"paymentreference": "PLVkXweLYnw",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "1352.31"
		}, {
			"id": "wlpaFicrALkEUnAxsiUg",
			"number": 11,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "QrpHqHWAqd",
				"beneid": "ECnpnc",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "2467951238",
				"beneaccountccy": "NZD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "BANK OF NEW ZEALAND",
				"benebanklocalname": "",
				"benebankbranch": "The Cooperative Bank 2",
				"benebankaddress1": "C/-BNZ Business Centre",
				"benebankaddress2": "L5 Harbour Quay",
				"benebankaddress3": "60 Waterloo Quay",
				"benebankpostal": "",
				"benebankcity": "Wellington",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "021-246",
				"swiftbank": "BANK OF NEW ZEALAND",
				"swiftbanklocalname": "",
				"swiftbranch": "The Cooperative Bank 2",
				"swiftbankaddress1": "C/-BNZ Business Centre",
				"swiftbankaddress2": "L5 Harbour Quay",
				"swiftbankaddress3": "60 Waterloo Quay",
				"swiftbankpostal": "",
				"swiftbankcity": "Wellington",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "BKNZN222500",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Modified",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "23/05/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "2467951238",
			"beneficiaryid": "ECnpnc",
			"paymentreference": "PREwLbVwgFP",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "2236.27"
		}, {
			"id": "rpnBSZEZyBTqXrRabZiK",
			"number": 12,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "lHNUUbyrBF",
				"beneid": "IyOvBP",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "3159582825",
				"beneaccountccy": "CNY",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"benebanklocalname": "英国渣打银行有限责任公司上海分行",
				"benebankbranch": "Shanghai Branch",
				"benebankaddress1": "Unit 1077/1079/108",
				"benebankaddress2": "No. 1018, Chang Ning Road",
				"benebankaddress3": "Shanghai",
				"benebankpostal": "200042",
				"benebankcity": "Shanghai",
				"benebankcountry": "China",
				"benebankclearingtype": "CNAPS",
				"benebankclearingcode": "671290000017",
				"swiftbank": "STANDARD CHARTERED BANK CORPORATION LIMITED",
				"swiftbanklocalname": "英国渣打银行有限责任公司上海分行",
				"swiftbranch": "Shanghai Branch",
				"swiftbankaddress1": "Unit 1077/1079/108",
				"swiftbankaddress2": "No. 1018, Chang Ning Road",
				"swiftbankaddress3": "Shanghai",
				"swiftbankpostal": "200042",
				"swiftbankcity": "Shanghai",
				"swiftbankcountry": "China",
				"swiftcode": "SCBLCNSXSHA",
				"benestatus": "New",
				"beneworkflow": "Creation Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "12/07/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "3159582825",
			"beneficiaryid": "IyOvBP",
			"paymentreference": "PiaRiRYdsjn",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "3036.11"
		}, {
			"id": "esFybxSwokyDPdKCJBAs",
			"number": 13,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "yaqjtkYTGt",
				"beneid": "WxcJRz",
				"benename": "Farm To Table Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "6491765197",
				"beneaccountccy": "AUD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Deleted",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "24/03/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Farm To Table Inc.",
			"beneficiaryaccountnumber": "6491765197",
			"beneficiaryid": "WxcJRz",
			"paymentreference": "PrWcOsjoxzm",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "5344.02"
		}, {
			"id": "dhehvlKZWikvwFQDRbli",
			"number": 14,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "GzzyZasJyJ",
				"beneid": "MJtoaZ",
				"benename": "Flow Water Incorporated",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1243652139",
				"beneaccountccy": "AUD",
				"beneaddress1": "#10-01 Mapletree Business City",
				"beneaddress2": "20 Pasir Panjang Road",
				"beneaddress3": "Singapore",
				"benecity": "Singapore",
				"benepostal": "117439",
				"benecountry": "Singapore",
				"benephone": "+65 5555 5555",
				"benefax": "+65 5555 5555",
				"beneemail": "beneficiary10@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "07/01/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Flow Water Incorporated",
			"beneficiaryaccountnumber": "1243652139",
			"beneficiaryid": "MJtoaZ",
			"paymentreference": "PGEYtGYvILc",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "9668.93"
		}, {
			"id": "KjPsZKqsJcxoglFoJKsS",
			"number": 15,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "jAEcIlIGcM",
				"beneid": "eQzgaG",
				"benename": "Near And Far Transport Inc.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "2712566282",
				"beneaccountccy": "SGD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary4@opee.prototype.com",
				"benebank": "DBS BANK LTD SINGAPORE",
				"benebanklocalname": "",
				"benebankbranch": "DBS Shenton Way",
				"benebankaddress1": "MBFC Tower 3",
				"benebankaddress2": "12 Marina Boulevard",
				"benebankaddress3": "",
				"benebankpostal": "018982",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "DBSSSGSG",
				"swiftbank": "DBS BANK LTD SINGAPORE",
				"swiftbanklocalname": "",
				"swiftbranch": "DBS Shenton Way",
				"swiftbankaddress1": "MBFC Tower 3",
				"swiftbankaddress2": "12 Marina Boulevard",
				"swiftbankaddress3": "",
				"swiftbankpostal": "018982",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "DBSSSGSG",
				"benestatus": "Deleted",
				"beneworkflow": "Approved",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "03/06/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Near And Far Transport Inc.",
			"beneficiaryaccountnumber": "2712566282",
			"beneficiaryid": "eQzgaG",
			"paymentreference": "POhemIQymgq",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "7289.92"
		}, {
			"id": "lFQpqAzWwTiPzgBenDuE",
			"number": 16,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "NaXXfwkWZp",
				"beneid": "unQZjI",
				"benename": "Omolon Technologies LLC.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "8537154163",
				"beneaccountccy": "NZD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "HSBC BANK",
				"benebanklocalname": "",
				"benebankbranch": "Alliance Branch",
				"benebankaddress1": "Level 9 HSBC House",
				"benebankaddress2": "One Queen Street",
				"benebankaddress3": "",
				"benebankpostal": "",
				"benebankcity": "Auckland",
				"benebankcountry": "New Zealand",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "302-935",
				"swiftbank": "HSBC BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Alliance Branch",
				"swiftbankaddress1": "Level 9 HSBC House",
				"swiftbankaddress2": "One Queen Street",
				"swiftbankaddress3": "",
				"swiftbankpostal": "",
				"swiftbankcity": "Auckland",
				"swiftbankcountry": "New Zealand",
				"swiftcode": "HSBCNZ2A",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "20/08/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Omolon Technologies LLC.",
			"beneficiaryaccountnumber": "8537154163",
			"beneficiaryid": "unQZjI",
			"paymentreference": "PfDRSwBMcnz",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "DHVPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "6596.47"
		}, {
			"id": "sZjYDmvzLgtVSSQySKKj",
			"number": 17,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "NimFrqegtL",
				"beneid": "vmYXhx",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1388146326",
				"beneaccountccy": "SGD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Ocean Financial Centre",
				"benebankaddress1": "Ocean Financial Centre",
				"benebankaddress2": "10 Collyer Quay",
				"benebankaddress3": "30-00",
				"benebankpostal": "049315",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "ANZBSGSX",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Ocean Financial Centre",
				"swiftbankaddress1": "Ocean Financial Centre",
				"swiftbankaddress2": "10 Collyer Quay",
				"swiftbankaddress3": "30-00",
				"swiftbankpostal": "049315",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "ANZBSGSX",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "07/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "1388146326",
			"beneficiaryid": "vmYXhx",
			"paymentreference": "PZgFeodWAci",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "CBHVPS",
			"purposecode": "02113 - 货物贸易结算退款 Goods trade settlement refund",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "4014.55"
		}, {
			"id": "VrbImTesbxnHGbcHYLln",
			"number": 18,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "EZamnIYxmK",
				"beneid": "IWBJGN",
				"benename": "Omolon Technologies LLC.",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Resident Individual",
				"beneaccount": "4849882221",
				"beneaccountccy": "AUD",
				"beneaddress1": "600 Bourke Street",
				"beneaddress2": "Melbourne",
				"beneaddress3": "Victoria",
				"benecity": "Melbourne",
				"benepostal": "3000",
				"benecountry": "Australia",
				"benephone": "+61 3 5555 5555",
				"benefax": "+61 3 5555 5555",
				"beneemail": "beneficiary15@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "ANZ Banking Group Limited",
				"benebankaddress1": "Level 12, 530 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "013-988",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "ANZ Banking Group Limited",
				"swiftbankaddress1": "Level 12, 530 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "ANZBAU3M",
				"benestatus": "Active",
				"beneworkflow": "Changes Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "15/09/2016 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Omolon Technologies LLC.",
			"beneficiaryaccountnumber": "4849882221",
			"beneficiaryid": "IWBJGN",
			"paymentreference": "PxyQLCKvRvv",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "4181.01"
		}, {
			"id": "wpXyAVXFHxrBJwpeZpxq",
			"number": 19,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "eQOzpYIQYI",
				"beneid": "RSrSph",
				"benename": "Specialist Data Analysis Centre Of New Zealand",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "4432948997",
				"beneaccountccy": "AUD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary6@opee.prototype.com",
				"benebank": "COMMONWEALTH BANK",
				"benebanklocalname": "",
				"benebankbranch": "Commonwealth Bank",
				"benebankaddress1": "367 Collins Street",
				"benebankaddress2": "Melbourne",
				"benebankaddress3": "Victoria",
				"benebankpostal": "3000",
				"benebankcity": "Melbourne",
				"benebankcountry": "Australia",
				"benebankclearingtype": "BSB",
				"benebankclearingcode": "063-032",
				"swiftbank": "COMMONWEALTH BANK",
				"swiftbanklocalname": "",
				"swiftbranch": "Commonwealth Bank",
				"swiftbankaddress1": "367 Collins Street",
				"swiftbankaddress2": "Melbourne",
				"swiftbankaddress3": "Victoria",
				"swiftbankpostal": "3000",
				"swiftbankcity": "Melbourne",
				"swiftbankcountry": "Australia",
				"swiftcode": "CTBAAU2S",
				"benestatus": "Active",
				"beneworkflow": "Pending Approval - Deleted",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "18/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "Specialist Data Analysis Centre Of New Zealand",
			"beneficiaryaccountnumber": "4432948997",
			"beneficiaryid": "RSrSph",
			"paymentreference": "PdPWvoKrdRh",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "BEPS",
			"purposecode": "02102 - 普通汇兑 Common exchange",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "3505.38"
		}, {
			"id": "jfcZlvdGnWseBjmZCewJ",
			"number": 20,
			"validated": true,
			"batchreference": "tAKkt-BatchPay",
			"beneficiary": {
				"id": "NimFrqegtL",
				"beneid": "vmYXhx",
				"benename": "European Car Association of Auckland",
				"benelocalname": "",
				"benenickname": "Nickname Here",
				"benetype": "Non-Resident Individual",
				"beneaccount": "1388146326",
				"beneaccountccy": "SGD",
				"beneaddress1": "Level 10/15",
				"beneaddress2": "One Queen Street",
				"beneaddress3": "",
				"benecity": "Auckland",
				"benepostal": "200120",
				"benecountry": "New Zealand",
				"benephone": "+86 20 5555 5555",
				"benefax": "+86 20 5555 5555",
				"beneemail": "beneficiary2@opee.prototype.com",
				"benebank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"benebanklocalname": "",
				"benebankbranch": "Ocean Financial Centre",
				"benebankaddress1": "Ocean Financial Centre",
				"benebankaddress2": "10 Collyer Quay",
				"benebankaddress3": "30-00",
				"benebankpostal": "049315",
				"benebankcity": "Singapore",
				"benebankcountry": "Singapore",
				"benebankclearingtype": "SWIFT",
				"benebankclearingcode": "ANZBSGSX",
				"swiftbank": "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
				"swiftbanklocalname": "",
				"swiftbranch": "Ocean Financial Centre",
				"swiftbankaddress1": "Ocean Financial Centre",
				"swiftbankaddress2": "10 Collyer Quay",
				"swiftbankaddress3": "30-00",
				"swiftbankpostal": "049315",
				"swiftbankcity": "Singapore",
				"swiftbankcountry": "Singapore",
				"swiftcode": "ANZBSGSX",
				"benestatus": "Active",
				"beneworkflow": "Deletion Rejected",
				"benedivision": "Customer Division",
				"entrymethod": "Online",
				"folder": "None",
				"folderid": "None",
				"audit": [],
				"enteredby": "Test User 1",
				"enteredon": "07/12/2015 at 16:46:04",
				"lastupdateby": "Test User 1",
				"lastupdate": "21/11/2016 at 16:46:04",
				"approvedby": "Test User 2",
				"approvedon": "22/11/2016 at 16:46:04",
				"rejectedby": "Test User 2",
				"rejectedon": "22/11/2016 at 16:46:04",
				"deletedby": "Test User 1",
				"deletedon": "22/11/2016 at 16:46:04"
			},
			"beneficiaryname": "European Car Association of Auckland",
			"beneficiaryaccountnumber": "1388146326",
			"beneficiaryid": "vmYXhx",
			"paymentreference": "PGDKRZcvhSg",
			"paymentdate": "23/11/2016",
			"remittanceinformation": "This is sample remittance information",
			"supportingdocs": [],
			"paymentcurrency": "CNY",
			"debitaccountcurrency": "HKD",
			"workflow": "Approved",
			"status": "Approved",
			"errors": [],
			"paymentmethod": "Book Transfer",
			"purposecode": "",
			"ratetype": "",
			"rate": "",
			"contracts": [],
			"debitequivalentamount": "587.99"
		}],
		"numberofpayments": 20,
		"workflow": "Approved",
		"status": "Approved",
		"errors": [],
		"audit": [{
			"record": "zPNdbVslnCNShQaRnMJX",
			"action": "Created",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Created",
			"fields": [],
			"comment": ""
		}, {
			"record": "zPNdbVslnCNShQaRnMJX",
			"action": "Modified",
			"date": "23/11/2016",
			"time": "14:09:45",
			"by": "Test User",
			"description": "Record Modified",
			"fields": [{
				"field": "valuedate",
				"label": "Value Date",
				"to": "06/12/2016"
			}],
			"comment": ""
		}],
		"createdby": "Test User",
		"createdon": "23/11/2016",
		"lastmodifiedby": "Test User",
		"lastmodifiedon": "23/11/2016"
	}];

	function destroyDialogSearchGrid() {
		if (typeof(searchGrid) != 'undefined' && searchGrid != null) {
			searchGrid.destroy();
			$(window).off('resize.searchgrid');
		}
	}

	function searchTemplates() {
		var _results = [];
		var _tempName = $("#searchTemplateName").val() ? $("#searchTemplateName").val() : "",
			_tempType = $("#searchPaymentTypes").val() ? $("#searchPaymentTypes").val() : "",
			_tempDebitCCy = $("#searchDebitCurrency").val() ? $("#searchDebitCurrency").val() : "",
			_tempDebitAcc = $("#searchDebitAccountNumber").val() ? $("#searchDebitAccountNumber").val() : "";
		for (var i = 0, l = _payment_templates.length; i < l; i++) {
			var _tmp = _payment_templates[i];
			if (_tmp.templatename.toLowerCase().indexOf(_tempName.toLowerCase()) != -1 && _tmp.type.toLowerCase().indexOf(_tempType.toLowerCase()) != -1 && _tmp.debitcurrency.toLowerCase().indexOf(_tempDebitCCy.toLowerCase()) != -1 && _tmp.debitaccountnumber.toLowerCase().indexOf(_tempDebitAcc.toLowerCase()) != -1) {
				_results.push(_tmp);
			}
		}
		return _results;
	}

	function loadTemplateResults(resultSet) {
		if (!resultSet) {
			$("#templateSearchResults").addClass("loading");
		}

		$("#templateSearchResults").find("div.loading-text").hide();

		var _results = (resultSet) ? resultSet : searchTemplates();

		setTimeout(function() {
			if (_results.length) {
				searchData = _results;
				if ($("div#searchGrid").size()) {
					searchGrid.setSelectedRows([]);
					searchDataView.beginUpdate();
					searchDataView.setItems(searchData);
					searchDataView.endUpdate();
					searchGrid.invalidateAllRows();
					searchGrid.render();
				} else {
					var $searchGrid = $("<div class='panel' id='searchGrid' />");
					$searchGrid.appendTo($("#templateSearchResults"));
					searchColumnFilters = {};
					searchGrouping = [];
					searchColumns = [{
						id: "templatename",
						name: "Template Name",
						field: "templatename",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "type",
						name: "Template Type",
						field: "type",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "debitaccountnumber",
						name: "Debit Account Number",
						field: "debitaccountnumber",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "debitcurrency",
						name: "Debit Currency",
						field: "debitcurrency",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}];
					searchOptions = {
						enableCellNavigation: true,
						enableColumnReorder: true,
						syncColumnCellResize: false,
						forceFitColumns: true,
						multiSelect: false,
						multiColumnSort: true,
						explicitInitialization: true,
						showHeaderRow: false,
						dataItemColumnValueExtractor: getDataItemValue
					};

					function searchGridFilter(item, args) {
						for (var columnId in searchColumnFilters) {
							if (columnId !== undefined && searchColumnFilters[columnId] !== "") {
								var c = searchGrid.getColumns()[searchGrid.getColumnIndex(columnId)];
								if (item[c.field].toLowerCase().indexOf(searchColumnFilters[columnId].toLowerCase()) == -1) {
									return false;
								}
							}
						}
						return true;
					}
					var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
					searchDataView = new Slick.Data.DataView({
						groupItemMetadataProvider: groupItemMetadataProvider
					});
					searchGrid = new Slick.Grid($searchGrid, searchDataView, searchColumns, searchOptions);
					searchGrid.registerPlugin(groupItemMetadataProvider);
					searchGrid.setSelectionModel(new Slick.RowSelectionModel({
						selectActiveRow: true
					}));
					searchGrid.onSelectedRowsChanged.subscribe(function(e, args) {
						selectedDivisions = [];
						var rows = searchGrid.getSelectedRows();
						for (var i = 0, l = rows.length; i < l; i++) {
							var item = searchDataView.getItem(rows[i])
							if (item) selectedDivisions.push(item)
						}
					});
					searchGrid.onClick.subscribe(function(e, args) {
						var cell = searchGrid.getCellFromEvent(e);
						var row = cell.row;
					});
					searchGrid.onDblClick.subscribe(function(e, args) {
						var cell = searchGrid.getCellFromEvent(e);
						var row = cell.row;
					});
					searchGrid.onKeyDown.subscribe(function(e, args) {
						if (e.which == 13) {
							if (searchGrid.getActiveCell()) {
								var row = searchGrid.getActiveCell().row;
							}
						}
					});
					searchGrid.onSort.subscribe(function(e, args) {
						var cols = args.sortCols;
						searchDataView.sort(function(dataRow1, dataRow2) {
							for (var i = 0, l = cols.length; i < l; i++) {
								sortdir = cols[i].sortAsc ? 1 : -1;
								sortcol = cols[i].sortCol.field;
								var _sorter = cols[i].sortCol.sorter,
									idx = cols[i].sortCol.fieldIdx,
									result;
								if (_sorter == "sorterStringCompare") {
									result = sorterStringCompare(dataRow1, dataRow2);
								} else if (_sorter == "sorterNumeric") {
									result = sorterNumeric(dataRow1, dataRow2);
								} else if (_sorter == "sorterDateIso") {
									result = sorterDateIso(dataRow1, dataRow2);
								} else if (_sorter == "sorterStringCompareWithFieldIDX") {
									result = sorterStringCompareWithFieldIDX(dataRow1, dataRow2, idx);
								}
								if (result != 0) {
									return result;
								}
							}
							return 0;
						});
						args.grid.invalidateAllRows();
						args.grid.render();
					});
					searchDataView.onRowCountChanged.subscribe(function(e, args) {
						searchGrid.updateRowCount();
						searchGrid.render();
					});
					searchDataView.onRowsChanged.subscribe(function(e, args) {
						searchGrid.invalidateRows(args.rows);
						searchGrid.render();
					});
					searchDataView.beginUpdate();
					searchDataView.setItems(searchData);
					searchDataView.setFilter(searchGridFilter);
					searchDataView.endUpdate();
					searchGrid.init();
					$(window).on('resize.searchgrid', function() {
						searchGrid.resizeCanvas();
					});
				}
			} else {
				if ($("div#searchGrid").size()) {
					destroyDialogSearchGrid();
					$("div#searchGrid").remove();
				}
				$("#templateSearchResults").find("div.loading-text").html("No Results Found").show();
			}
			$("#templateSearchResults").removeClass("loading");
			searchGrid.resizeCanvas();
		}, 1000);
	}

	function populateTemplateSearchDialog() {
		var $dialogContent = $("<div class='py-ui' id='templateSearch' />"),
			$searchBar = $("<div class='search-bar' />").appendTo($dialogContent),
			$dialogGrid = $("<div class='panel' id='templateSearchResults' />").appendTo($dialogContent),
			$searchInstructions = $("<div class='loading-text'>Use the search fields above to find a payment template</div>").appendTo($dialogGrid);

		var $searchDiv = $("<div class='search-bar-container' />").appendTo($searchBar),
			$searchFields = $("<div class='search-bar-fields' />").appendTo($searchDiv),
			$searchFieldRow = $("<div class='search-bar-field-row' />").appendTo($searchFields),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Template Name</label>").appendTo($searchField),
			$searchInput = $("<input type='text' style='width: 95%;' value='' id='searchTemplateName' />").appendTo($searchField),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Payment Type</label>").appendTo($searchField),
			$customSelect = $("<div class='custom-select' style='width: 95%;' />").appendTo($searchField),
			$searchSelect = $("<select id='searchPaymentTypes'><option value=''></option><option value='Domestic'>Domestic</option><option value='International'>International</option><option value='Transfers'>Transfers</option><option value='Domestic Salary'>Domestic Salary</option><option value='International Salary'>International Salary</option></select>").appendTo($customSelect),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Debit Currency</label>").appendTo($searchField),
			$customSelect = $("<div class='custom-select' style='width: 95%;' />").appendTo($searchField),
			$searchSelect = $("<select id='searchDebitCurrency'><option value=''></option><option value='AUD'>AUD</option><option value='CNY'>CNY</option><option value='HKD'>HKD</option><option value='SGD'>SGD</option><option value='USD'>USD</option></select>").appendTo($customSelect),
			$searchFieldRow = $("<div class='search-bar-field-row' />").appendTo($searchFields),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Debit Account Number</label>").appendTo($searchField),
			$searchInput = $("<input type='text' style='width: 95%;' value='' id='searchDebitAccountNumber' />").appendTo($searchField),
			$searchButtonDiv = $("<div class='search-bar-button' />").appendTo($searchDiv),
			$resetButton = $("<span class='form-button'><a href='javascrit:void(0)'><i class='fa fa-refresh fa-fw'></i>Reset</a></span>").appendTo($searchButtonDiv),
			$searchButton = $("<span class='form-button primary'><a href='javascrit:void(0)'><i class='fa fa-search fa-fw'></i>Search</a></span>").appendTo($searchButtonDiv).on("click", function(e) {
				e.preventDefault();
				loadTemplateResults();
			});

		return $dialogContent;
	}

	function triggerTemplateDialog(e) {
		e.preventDefault();
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: "searchTemplates",
			title: "Use Payment Template",
			size: "full-screen",
			icon: "<i class='fa fa-clipboard'></i>",
			content: function() {
				return populateTemplateSearchDialog()
			},
			hasgrid: function() {
				return destroyDialogSearchGrid()
			}
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		loadTemplateResults();
	}

	var randomPastDate = smartDates("randompast");

	var _past_payments = [{
		id: randString(20),
		type: "Domestic Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "10,000.00"
	}, {
		id: randString(20),
		type: "International Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "International Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "Domestic Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "International Salary Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "Domestic Salary Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "International Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "Domestic Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "Domestic Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}, {
		id: randString(20),
		type: "Domestic Payment",
		batchid: "B" + randString(5) + randomPastDate,
		name: "Batch - " + randString(5) + randomPastDate,
		paymentcurrency: "AUD",
		debitaccountnumber: randNumber(10),
		totalpaymentamount: "12,000.00"
	}];

	/* past payment search */
	function indicatorSelection() {
		var alphaIndicators = ["*", "Like", "=", "Equal To", "&ne;", "Not Equal To"],
			numIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "&gt;", "Greater Than", "&lt;", "Less Than", "&hArr;", "Between"],
			dateIndicatores = ["=", "Specific Date", "&hArr;", "Date Range", "Rd", "Rolling Dates"],
			autoCompleteIndicators = ["=", "Equal To", "&ne;", "Not Equal To"];
		var $indicatorMenu, whichArray, indicator, mainInput, fromInput, toInput, rollingInput, hiddenInput;
		var sibs;

		function init() {
			$indicatorMenu = $("<div class='indicator-menu' style='display:none;position:absolute;' />").appendTo(document.body);
			$indicatorMenu.bind("click", setIndicator);
			setupIndicators();
		}

		function setupIndicators() {
			var $indicatorItem;
			$(".indicator").bind("click", function(e) {
				e.stopPropagation();
				if ($indicatorMenu.is(":visible") && $indicatorMenu.attr("id") == $(this).attr("id") + "m") {
					$indicatorMenu.empty().hide();
					return;
				}
				$indicatorMenu.empty();
				indicator = $(this);
				sibs = $(this).siblings("input").not("input[type='hidden']");
				mainInput = $(this).next("input");
				fromInput = mainInput.next("input");
				toInput = fromInput.next("input");
				rollingInput = toInput.next("input");
				hiddenInput = $(this).siblings("input[type='hidden']");
				$indicatorMenu.attr("id", indicator.attr("id") + "m");
				whichArray = alphaIndicators;
				if ($(this).hasClass("num")) whichArray = numIndicators;
				if ($(this).hasClass("date")) whichArray = dateIndicatores;
				if ($(this).hasClass("auto")) whichArray = autoCompleteIndicators;
				for (var i = 0; i < whichArray.length; i++) {
					$indicatorItem = $("<div />").attr("id", i).html("<strong id=" + i + ">" + whichArray[i] + "</strong> " + whichArray[i + 1]).appendTo($indicatorMenu);
					i = i + 1;
				}
				var pleft = $(this).offset().left;
				var ptop = $(this).offset().top + $(this).height() + 2;
				$indicatorMenu.css("top", ptop).css("left", pleft).show();
				$(".control-menus").children(".control-menu:visible").hide();
				$(".control-list").children(".on").removeClass("on");
				$("body").one("click", function() {
					$indicatorMenu.empty().hide();
				});
				$(document).on("keyup.hideIndicator", function(e) {
					if (e.keyCode == 27) {
						$indicatorMenu.empty().hide();
						$(document).off("keyup.hideIndicator");
					}
				});
			});
		}

		function setIndicator(e) {
			var indset = whichArray[parseInt(e.target.id)];
			var hidset = whichArray[parseInt(e.target.id) + 1];
			indicator.html(indset).attr("title", hidset);
			hiddenInput.val(hidset);
			if (hidset == "Date Range" || hidset == "Between") {
				mainInput.addClass("display-none").prop("disabled", "disabled");
				rollingInput.addClass("display-none").prop("disabled", "disabled");
				fromInput.removeClass("display-none").prop("disabled", "").focus();
				toInput.removeClass("display-none").prop("disabled", "");
			}
			if (hidset == "Rolling Dates") {
				mainInput.addClass("display-none").prop("disabled", "disabled");
				fromInput.addClass("display-none").prop("disabled", "disabled");
				toInput.addClass("display-none").prop("disabled", "disabled");
				rollingInput.removeClass("display-none").prop("disabled", "").focus();
			}
			if (hidset != "Date Range" && hidset != "Rolling Dates" && hidset != "Between") {
				rollingInput.addClass("display-none").prop("disabled", "disabled");
				fromInput.addClass("display-none").prop("disabled", "disabled");
				toInput.addClass("display-none").prop("disabled", "disabled");
				mainInput.removeClass("display-none").prop("disabled", "").focus();
			}
		}
		init();
	}

	function searchPastPayments() {
		var _results = [];
		var _pymname = $("#searchPaymentName").val() ? $("#searchPaymentName").val() : "",
			_pymacct = $("#searchAccountNumber").val() ? $("#searchAccountNumber").val() : "",
			_pymtype = $("#searchPaymentType").val() ? $("#searchPaymentType").val() : "",
			_pymccy = $("#searchPaymentCurrency").val() ? $("#searchPaymentCurrency").val() : "",
			_pymamnt = $("#searchPaymentAmount").val() ? $("#searchPaymentAmount").val() : "";
		for (var i = 0, l = _tbos_past_payment_batches.length; i < l; i++) {
			var _tmp = _tbos_past_payment_batches[i];
			if (_pymtype != "") {
				if (_tmp.name.toLowerCase().indexOf(_pymname.toLowerCase()) != -1 && _tmp.type.toLowerCase() == _pymtype.toLowerCase() && _tmp.paymentcurrency.toLowerCase().indexOf(_pymccy.toLowerCase()) != -1 && _tmp.debitaccountnumber.toLowerCase().indexOf(_pymacct.toLowerCase()) != -1 && _tmp.totalpaymentamount.replace(/[^\d\.\-\ ]/g, '').indexOf(_pymamnt.replace(/[^\d\.\-\ ]/g, '')) != -1) {
					_results.push(_tmp);
				}
			} else {
				if (_tmp.name.toLowerCase().indexOf(_pymname.toLowerCase()) != -1 && _tmp.type.toLowerCase().indexOf(_pymtype.toLowerCase()) != -1 && _tmp.paymentcurrency.toLowerCase().indexOf(_pymccy.toLowerCase()) != -1 && _tmp.debitaccountnumber.toLowerCase().indexOf(_pymacct.toLowerCase()) != -1 && _tmp.totalpaymentamount.replace(/[^\d\.\-\ ]/g, '').indexOf(_pymamnt.replace(/[^\d\.\-\ ]/g, '')) != -1) {
					_results.push(_tmp);
				}
			}
		}
		return _results;
	}

	function loadPastPaymentResults(resultSet) {
		if (!resultSet) {
			$("#pastPaymentSearchResults").addClass("loading");
		}

		$("#pastPaymentSearchResults").find("div.loading-text").hide();

		var _results = (resultSet) ? resultSet : searchPastPayments();

		setTimeout(function() {
			if (_results.length) {
				searchData = _results;
				if ($("div#searchGrid").size()) {
					searchGrid.setSelectedRows([]);
					searchDataView.beginUpdate();
					searchDataView.setItems(searchData);
					searchDataView.endUpdate();
					searchGrid.invalidateAllRows();
					searchGrid.render();
				} else {
					var $searchGrid = $("<div class='panel' id='searchGrid' />");
					$searchGrid.appendTo($("#pastPaymentSearchResults"));
					searchColumnFilters = {};
					searchGrouping = [];
					searchColumns = [{
						id: "batchid",
						name: "Payment ID",
						field: "batchid",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "name",
						name: "Payment Name",
						field: "name",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "debitaccountnumber",
						name: "Debit Account",
						field: "debitaccountnumber",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "type",
						name: "Payment Type",
						field: "type",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "paymentcurrency",
						name: "Payment Currency",
						field: "paymentcurrency",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "totalpaymentamount",
						name: "Payment Amount",
						field: "totalpaymentamount",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "numberofpayments",
						name: "No. of Items",
						field: "numberofpayments",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}, {
						id: "paymentdate",
						name: "Value Date",
						field: "paymentdate",
						width: 200,
						sortable: true,
						sorter: "sorterStringCompare",
						visible: true,
					}];
					searchOptions = {
						enableCellNavigation: true,
						enableColumnReorder: true,
						syncColumnCellResize: false,
						forceFitColumns: false,
						multiSelect: false,
						multiColumnSort: true,
						explicitInitialization: true,
						showHeaderRow: false,
						dataItemColumnValueExtractor: getDataItemValue
					};

					function searchGridFilter(item, args) {
						for (var columnId in searchColumnFilters) {
							if (columnId !== undefined && searchColumnFilters[columnId] !== "") {
								var c = searchGrid.getColumns()[searchGrid.getColumnIndex(columnId)];
								if (item[c.field].toLowerCase().indexOf(searchColumnFilters[columnId].toLowerCase()) == -1) {
									return false;
								}
							}
						}
						return true;
					}
					var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
					searchDataView = new Slick.Data.DataView({
						groupItemMetadataProvider: groupItemMetadataProvider
					});
					searchGrid = new Slick.Grid($searchGrid, searchDataView, searchColumns, searchOptions);
					searchGrid.registerPlugin(groupItemMetadataProvider);
					searchGrid.setSelectionModel(new Slick.RowSelectionModel({
						selectActiveRow: true
					}));
					searchGrid.onSelectedRowsChanged.subscribe(function(e, args) {
						selectedDivisions = [];
						var rows = searchGrid.getSelectedRows();
						for (var i = 0, l = rows.length; i < l; i++) {
							var item = searchDataView.getItem(rows[i])
							if (item) selectedDivisions.push(item)
						}
					});
					searchGrid.onClick.subscribe(function(e, args) {
						var cell = searchGrid.getCellFromEvent(e);
						var row = cell.row;
					});
					searchGrid.onDblClick.subscribe(function(e, args) {
						var cell = searchGrid.getCellFromEvent(e);
						var row = cell.row;
					});
					searchGrid.onKeyDown.subscribe(function(e, args) {
						if (e.which == 13) {
							if (searchGrid.getActiveCell()) {
								var row = searchGrid.getActiveCell().row;
							}
						}
					});
					searchGrid.onSort.subscribe(function(e, args) {
						var cols = args.sortCols;
						searchDataView.sort(function(dataRow1, dataRow2) {
							for (var i = 0, l = cols.length; i < l; i++) {
								sortdir = cols[i].sortAsc ? 1 : -1;
								sortcol = cols[i].sortCol.field;
								var _sorter = cols[i].sortCol.sorter,
									idx = cols[i].sortCol.fieldIdx,
									result;
								if (_sorter == "sorterStringCompare") {
									result = sorterStringCompare(dataRow1, dataRow2);
								} else if (_sorter == "sorterNumeric") {
									result = sorterNumeric(dataRow1, dataRow2);
								} else if (_sorter == "sorterDateIso") {
									result = sorterDateIso(dataRow1, dataRow2);
								} else if (_sorter == "sorterStringCompareWithFieldIDX") {
									result = sorterStringCompareWithFieldIDX(dataRow1, dataRow2, idx);
								}
								if (result != 0) {
									return result;
								}
							}
							return 0;
						});
						args.grid.invalidateAllRows();
						args.grid.render();
					});
					searchDataView.onRowCountChanged.subscribe(function(e, args) {
						searchGrid.updateRowCount();
						searchGrid.render();
					});
					searchDataView.onRowsChanged.subscribe(function(e, args) {
						searchGrid.invalidateRows(args.rows);
						searchGrid.render();
					});
					searchDataView.beginUpdate();
					searchDataView.setItems(searchData);
					searchDataView.setFilter(searchGridFilter);
					searchDataView.endUpdate();
					searchGrid.init();
					$(window).on('resize.searchgrid', function() {
						searchGrid.resizeCanvas();
					});
					$(window).on("resize.searchgrid", _.debounce(function(e) {
						searchGrid.resizeCanvas();
					}, 100));
				}
				$("#pastPaymentSearchResults").removeClass("loading");
				searchGrid.autosizeColumns();
				searchGrid.resizeCanvas();
			} else {
				if ($("div#searchGrid").size()) {
					destroyDialogSearchGrid();
					$("div#searchGrid").remove();
				}
				$("#pastPaymentSearchResults").find("div.loading-text").html("No Results Found").show();
				$("#pastPaymentSearchResults").removeClass("loading");
			}
		}, 1000);
	}

	function populatePastPaymentSearchDialog() {
		var $dialogContent = $("<div class='py-ui' id='pastPaymentSearch' />"),
			$searchBar = $("<div class='search-bar' />").appendTo($dialogContent),
			$dialogGrid = $("<div class='panel' id='pastPaymentSearchResults' />").appendTo($dialogContent),
			$searchInstructions = $("<div class='loading-text'>Use the search fields above to find a past payment</div>").appendTo($dialogGrid);

		var $searchDiv = $("<div class='search-bar-container' />").appendTo($searchBar),
			$searchFields = $("<div class='search-bar-fields' />").appendTo($searchDiv),
			$searchFieldRow = $("<div class='search-bar-field-row' />").appendTo($searchFields),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Payment Name</label>").appendTo($searchField),
			$searchSpan = $("<span class='indicator-group' />").appendTo($searchField),
			$indicator = $("<span class='indicator alpha' title='Like' id='i_searchPaymentName'>*</span>").appendTo($searchSpan),
			$searchInput = $("<input type='text' style='width: 100%;' value='' id='searchPaymentName' />").appendTo($searchSpan),
			$hiddenInput = $("<input type='hidden' name='hsearchPaymentName' id='searchPaymentName_h' value='Like' />").appendTo($searchSpan),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Debit Account</label>").appendTo($searchField),
			$addAccountIcon = $("<i class='fa fa-fw fa-plus-square' style='font-size: 18px; margin-left:5px; vertical-align: middle; cursor: pointer; color: #007dba;' title='Search Accounts' id='showSearchAccountDialog'></i>").appendTo($searchFieldLabel),
			$searchSpan = $("<span class='indicator-group' />").appendTo($searchField),
			$indicator = $("<span class='indicator auto' title='Equal To' id='i_searchAccountNumber'>=</span>").appendTo($searchSpan),
			$searchInput = $("<input type='text' style='width: 100%;' value='' id='searchAccountNumber' />").appendTo($searchSpan),
			$hiddenInput = $("<input type='hidden' name='hsearchAccountNumber' id='searchAccountNumber_h' value='Equal To' />").appendTo($searchSpan),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Payment Type</label>").appendTo($searchField),
			$searchSpan = $("<span class='indicator-group' />").appendTo($searchField),
			$indicator = $("<span class='indicator auto' title='Equal To' id='i_searchPaymentType'>=</span>").appendTo($searchSpan),
			$searchInput = $("<input type='text' style='width: 100%;' value='' id='searchPaymentType' />").appendTo($searchSpan),
			$hiddenInput = $("<input type='hidden' name='hsearchPaymentType' id='searchPaymentType_h' value='Equal To' />").appendTo($searchSpan),
			$searchFieldRow = $("<div class='search-bar-field-row' />").appendTo($searchFields),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Payment Currency</label>").appendTo($searchField),
			$searchSpan = $("<span class='indicator-group' />").appendTo($searchField),
			$indicator = $("<span class='indicator auto' title='Equal To' id='i_searchPaymentCurrency'>=</span>").appendTo($searchSpan),
			$searchInput = $("<input type='text' style='width: 100%;' value='' id='searchPaymentCurrency' />").appendTo($searchSpan),
			$hiddenInput = $("<input type='hidden' name='hsearchPaymentCurrency' id='searchPaymentCurrency_h' value='Equal To' />").appendTo($searchSpan),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Payment Amount</label>").appendTo($searchField),
			$searchSpan = $("<span class='indicator-group' />").appendTo($searchField),
			$indicator = $("<span class='indicator num' title='Equal To' id='i_searchPaymentAmount'>=</span>").appendTo($searchSpan),
			$searchInput = $("<input type='text' style='width: 100%;' value='' id='searchPaymentAmount' />").appendTo($searchSpan),
			$fromInput = $("<input type='text' name='searchPaymentAmountFrom' id='searchPaymentAmountFrom' style='width: 49%;' class='display-none' />").appendTo($searchSpan),
			$toInput = $("<input type='text' name='searchPaymentAmountTo id='searchPaymentAmountTo' style='width: 49%; margin-left: 2%; -webkit-border-radius: 4px; -moz-border-radius: 4px; border-radius: 4px;' class='display-none' />").appendTo($searchSpan),
			$hiddenInput = $("<input type='hidden' name='hsearchPaymentAmount' id='searchPaymentAmount_h' value='Equal To' />").appendTo($searchSpan),
			$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
			$searchFieldLabel = $("<label>Value Date</label>").appendTo($searchField),
			$searchSpan = $("<span class='indicator-group' />").appendTo($searchField),
			$indicator = $("<span class='indicator date' title='Equal To' id='i_searchValueDate'>=</span>").appendTo($searchSpan),
			$searchInput = $("<input type='text' style='width: 100%;' value='' id='searchValueDate' />").appendTo($searchSpan),
			$fromInput = $("<input type='text' name='searchValueDateFrom' id='searchValueDateFrom' style='width: 49%;' class='display-none' />").appendTo($searchSpan),
			$toInput = $("<input type='text' name='searchValueDateTo' id='searchValueDateTo' style='width: 49%; margin-left: 2%; -webkit-border-radius: 4px; -moz-border-radius: 4px; border-radius: 4px;' class='display-none' />").appendTo($searchSpan),
			$rollingInput = $("<input type='text' id='searchValueDateRolling' value='' style='width: 100%;' class='display-none' />").appendTo($searchSpan),
			$hiddenInput = $("<input type='hidden' name='hsearchValueDate' id='searchValueDate_h' value='Equal To' />").appendTo($searchSpan),
			$searchButtonDiv = $("<div class='search-bar-button' />").appendTo($searchDiv),
			$resetButton = $("<span class='form-button'><a href='javascrit:void(0)'><i class='fa fa-refresh fa-fw'></i>Reset</a></span>").appendTo($searchButtonDiv).on("click", function(e) {
				e.preventDefault();
				clearFormElements("pastPaymentSearch");
				$('#searchAccountNumber')[0].selectize.clearOptions();
				$('#searchPaymentType')[0].selectize.clearOptions();
				$('#searchPaymentCurrency')[0].selectize.clearOptions();
				loadPastPaymentResults();
			}),
			$searchButton = $("<span class='form-button primary'><a href='javascrit:void(0)'><i class='fa fa-search fa-fw'></i>Search</a></span>").appendTo($searchButtonDiv).on("click", function(e) {
				e.preventDefault();
				loadPastPaymentResults();
			});
		return $dialogContent;
	}

	function triggerPastPaymentDialog(e) {
		e.preventDefault();
		var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
		var _dialog = {
			id: "searchPastPayments",
			title: "Use Past Payments",
			size: "full-screen",
			icon: "<i class='fa fa-arrow-circle-left'></i>",
			content: function() {
				return populatePastPaymentSearchDialog()
			},
			hasgrid: function() {
				return destroyDialogSearchGrid()
			},
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		indicatorSelection();


		/* account selectize */
		var selectize_options = {
			plugins: ['remove_button'],
			maxItems: null,
			maxOptions: 50,
			valueField: 'number',
			labelField: 'name',
			searchField: ['number', 'name'],
			highlight: false,
			hideSelected: true,
			options: _tbos_customer_accounts,
			render: {
				item: function(item, escape) {
					if (item.name == item.number) return '<div>' + '<span class="name" style="margin-right:0px;">' + escape(item.name) + '</span></div>'
					return '<div>' +
						(item.number ? '<span style="margin-right:8px; font-weight: bold;">' + escape(item.number) + '</span>' : '') +
						(item.name ? '<span>' + escape(item.name) + ' &nbsp;&nbsp; (' + escape(item.currency.code) + ')</span>' : '') +
						'</div>';
				},
				option: function(item, escape) {
					var label = item.name || item.number;
					var caption = item.name ? item.number : null;
					return '<div>' +
						'<div class="caption" style="font-weight: bold;"">' + escape(caption) + '</div>' +
						(caption ? '<div class="label">' + escape(label) + '&nbsp;&nbsp; (' + escape(item.currency.code) + ')</div>' : '') +
						'</div>';
				}
			},
			onItemRemove: function(value) {},
			load: function(query, callback) {},
			persist: false,
			addPrecedence: true,
			openOnFocus: true,
			closeAfterSelect: false,
			create: false,
		};



		var $accountSelectize = $('#searchAccountNumber').selectize(selectize_options);

		/* currency selectize */
		var _currencies =
			[{
				name: "Australian Dollar",
				number: "AUD"
			}, {
				name: "Chinese Renminbi",
				number: "CNY"
			}, {
				name: "Hong Kong Dollar",
				number: "HKD"
			}, {
				name: "Singapore Dollar",
				number: "SGD"
			}, {
				name: "U.S. Dollar",
				number: "USD"
			}];
		selectize_options.render.item = function(item, escape) {
			return '<div>' +
				'<span style="margin-right:8px;">' + escape(item.number) + '</span>' +
				'</div>';
		}
		selectize_options.render.option = function(item, escape) {
			var label = item.name || item.number;
			var caption = item.name ? item.number : null;
			return '<div>' + '<div class="label" >' + escape(label) + (caption ? ' (' + escape(caption) + ')' : '') + '</div></div>';
		}
		selectize_options.options = _currencies;
		var $currencySelectize = $('#searchPaymentCurrency').selectize(selectize_options);

		/* payment type selectize */
		selectize_options.render.item = function(item, escape) {
			return '<div>' + '<span style="margin-right:8px;">' + escape(item.name) + '</span>' + '</div>';
		}
		selectize_options.valueField = 'name';
		selectize_options.searchField = ['name'];
		selectize_options.options = [{
			name: "Domestic"
		}, {
			name: "International"
		}, {
			name: "Transfers"
		}, {
			name: "Domestic Salary"
		}, {
			name: "International Salary"
		}];
		selectize_options.render.option = function(item, escape) {
			var label = item.name;
			return '<div>' + '<div class="label" >' + escape(label) + '</div></div>';
		}
		var $typeSelectize = $('#searchPaymentType').selectize(selectize_options);

		/* value date search */
		var rollingDates = ["Today", "Yesterday", "Week to Date", "Previous Week", "Month to Date", "Previous Month"];

		$("#searchValueDateRolling").autocomplete({
			source: rollingDates,
			autoFocus: true,
			delay: 0,
			minLength: 0,
			select: function(e, ui) {
				$(this).autocomplete("close");
			},
			change: function(e, ui) {
				var matcher = $(this).val();
				var matchie = "";
				var valid = false;
				$.each(rollingDates, function() {
					if (this.toLowerCase() == matcher.toLowerCase()) {
						valid = true;
						matchie = this;
						return false;
					}
				});
				$(this).val(matchie);
				if (!valid) {
					$(this).val("");
					return false;
				}
			}
		});

		$("#searchValueDateRolling").on("focus", function(e) {
			$(this).autocomplete("search", "");
		}).on("click", function(e) {
			$(this).autocomplete("search", "");
		}).on("keydown", function(e) {
			if (e.keyCode == "9") {
				e.stopImmediatePropagation();
			}
		});

		$("#searchValueDate").datepicker({
			duration: 0,
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true
		});

		$("#searchValueDateFrom").datepicker({
			dateFormat: 'dd/mm/yy',
			defaultDate: "-1m",
			changeMonth: true,
			changeYear: true,
			numberOfMonths: 1,
			onSelect: function(selectedDate) {
				$("#searchValueDateTo").datepicker("option", "minDate", selectedDate)
				setTimeout(function() {
					$("#searchValueDateTo").focus()
				}, 50)
			}
		});
		$("#searchValueDateTo").datepicker({
			dateFormat: 'dd/mm/yy',
			defaultDate: "-1m",
			changeMonth: true,
			changeYear: true,
			numberOfMonths: 1,
			onSelect: function(selectedDate) {
				$("#searchValueDateFrom").datepicker("option", "maxDate", selectedDate)
			}
		});

		function showAddItems(_target, title, headers, items, SEL_INPUT) {


			/* function to save and add selected accounts to the widget */
			function saveSelectedAccounts(_dialog) {
				if ($("input[name=_addAccount]:checked").length > 0) {
					var ADD_ITEMS = [];
					var checked_items = $("input[name=_addAccount]:checked");

					for (var s = 0; s < checked_items.length; s++) {
						for (var i = s; i < _tbos_customer_accounts.length + s; i++) {
							if (i > _tbos_customer_accounts.length) i = i - _tbos_customer_accounts.length;
							if (_tbos_customer_accounts[i].number == checked_items.eq(s).val()) {
								ADD_ITEMS.push(_tbos_customer_accounts[i].number);
								break;
							}
						}
					}
					$("#searchAccountNumber")[0].selectize.addItems(ADD_ITEMS);
					dialogHider(_dialog);
				} else {
					dialogHider(_dialog);
				}
			}

			/* set $wrapper to hold the add accounts list */
			var $wrapper = $("<div class='wrapper' />"),

				/* build the account filter input */
				$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
				$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
				$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Enter search value here...' />").on("keyup", function() {
					if (this.value != '') {
						$("#clearAccountsFilter").show()
					} else {
						$("#clearAccountsFilter").hide()
					}
				}).appendTo($searchDiv),
				$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
					$("#AddAccountsFilterInput").val("").trigger("change");
					$(this).hide();
				}).appendTo($searchDiv);

			/* build the header row */
			var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
				$checkHeaderDiv = $("<div class='dialog-search-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						$target = $target.find("input[name='_selectAll']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
					}
					var checkBoxes = $("input[name=_addAccount]:visible");
					var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
				}),
				$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
				$accountName = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Name</div>").appendTo($header),
				$accountNumber = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Number</div>").appendTo($header),
				$accountNumber = $("<div class='dialog-search-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);


			/* build the accounts list */
			var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
				$ul = $("<ul id='AddAccountsFilterList' class='dialog-search-list' />").appendTo($dataContainer),
				$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
			$.each(_tbos_customer_accounts, function() {

				if ($.inArray(this.number, SEL_INPUT[0].selectize.items) == -1) {
					$li = $("<li>").appendTo($ul),
						$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
							var $target = $(e.target);
							if ($target.prop("nodeName") == "DIV") {
								if ($target.hasClass("dialog-search-data-col")) {
									$target = $target.closest("div.dialog-search-row");
								}
								$target = $target.find("input[name='_addAccount']");
								var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
							}
							if (!$(this).prop("checked")) {
								$("input[name='_selectAll']").prop("checked", false)
							}
							if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
								$("input[name='_selectAll']").prop("checked", true)
							}
						}),
						$checkDiv = $("<div class='dialog-search-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
					var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount'/>").appendTo($checkDiv).on("change", function() {
						var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
					});
					var $name = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.name + "</div>").appendTo($row),
						$number = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.number + "</div>").appendTo($row),
						$ccy = $("<div class='dialog-search-data-col' style='width: 160px; border-right: 0;'>" + this.currency.code + "</div>").appendTo($row);


				}
			});

			/* build and show the add accounts dialog */
			var _origin = _target;
			var _dialog = {
				id: "AddAccounts",
				title: title,
				size: "xxl",
				icon: "<i class='fa fa-plus-square'></i>",
				content: $wrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							saveSelectedAccounts(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

			$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

			if (!$("#AddAccountsFilterList").children("li").length) {
				var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
			}
		}

		$("#showSearchAccountDialog").click(function() {
			showAddItems($(this), "Add Debit Accounts", ["Account Name", "Account Number", "Currency"], accounts, $('#searchAccountNumber'))
		});


		loadPastPaymentResults();
	}


	var $widget = $("#" + id);
	var $wrapper = $("<div class='wrapper' />"),
		$container = $("<ul class='create-container' />").appendTo($wrapper),
		$li = $("<li />").appendTo($container),
		$link = $("<a href='javascript:void(0)' class='create-item use-template'><div>Use Template</div></a>").appendTo($li).on("click", triggerTemplateDialog),
		$li = $("<li />").appendTo($container),
		$link = $("<a href='javascript:void(0)' class='create-item upload-file'><div>Upload File</div></a>").appendTo($li).on("click", triggerUploadDialog),		
		$li = $("<li />").appendTo($container),
		$link = $("<a href='payments-new.html' class='create-item manual-payment'><div>Create New Payment</div></a>").appendTo($li),
		$li = $("<li />").appendTo($container),
		$link = $("<a href='javascript:void(0)' class='create-item past-payment'><div>Use Past Payment</div></a>").appendTo($li).on("click", triggerPastPaymentDialog);

	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($wrapper);
	} else {
		return $wrapper;
	}
}


/* my approvals widget */
var myApprovals = [{
	type: "payments",
	items: [{
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "Domestic Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 120,
		notifications: true
	}, {
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "International Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 90,
		notifications: true
	}, {
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "International Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 40,
		notifications: false
	}, {
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "Domestic Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 220,
		notifications: false
	}, {
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "International Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 70,
		notifications: true
	}, {
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "Domestic Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 15,
		notifications: false
	}, {
		id: randString(20),
		paymentid: "B" + randString(5) + smartDates("today"),
		debitaccount: randNumber(10),
		status: "Pending Approval",
		name: "Batch - " + smartDates("today") + " - " + randString(rand(7, 20)),
		valuedate: smartDates("today"),
		type: "Domestic Payment",
		amount: (parseFloat((Math.random() * 1000000) / 100)).toFixed(2),
		ccy: "AUD",
		count: 30,
		notifications: false
	}]
}, {
	type: "beneficiaries",
	items: [{
		id: randString(20),
		name: "Josephine P. Ayee",
		account: randNumber(10),
		action: "Modified",
		status: "Active"
	}, {
		id: randString(20),
		name: "McKnichole Harris",
		account: randNumber(10),
		action: "New",
		status: "New"
	}, {
		id: randString(20),
		name: "Catherty Williams",
		account: randNumber(10),
		action: "Deleted",
		status: "Active"
	}, {
		id: randString(20),
		name: "Doughbert Jones Jr.",
		account: randNumber(10),
		action: "Modified",
		status: "Active"
	}, {
		id: randString(20),
		name: "Wallas Thornhampton III",
		account: randNumber(10),
		action: "Modified",
		status: "Active"
	}]
}, {
	type: "templates",
	items: [{
		id: randString(20),
		name: "Template-" + randString(5),
		account: randNumber(10),
		count: 30,
		type: "Domestic Payment",
		action: "Modified"
	}, {
		id: randString(20),
		name: "Template-" + randString(5),
		account: randNumber(10),
		count: 50,
		type: "International Payment",
		action: "Deleted"
	}, {
		id: randString(20),
		name: "Template-" + randString(5),
		account: randNumber(10),
		count: 10,
		type: "Domestic Payment",
		action: "New"
	}]
}];

function showMyApprovalsSettings(e) {
	e.preventDefault();

	/* set id from the widget DOM element */
	var id = $(e.target).closest(".widget-container").parent("li").attr("id");

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	/* function to save widget settings */
	function updateMySettings(_dialog) {
		var _rebuild = false;
		for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
			if ($("#setting-" + _settings[0].selections[i].type).prop("checked") != _settings[0].selections[i].visible) {
				_rebuild = true;
				break;
			}
		}
		for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
			_settings[0].selections[i].visible = $("#setting-" + _settings[0].selections[i].type).prop("checked");
			if (_settings[0].selections[i].visible == false) {
				_settings[0].selections[i].open = false;
			}
		}
		store.set('saved_widget_data', widgetDataArray);
		dialogHider(_dialog);
		if (_rebuild) {
			var $widget = $("#" + id).find(".widget-container").addClass("working");
			setTimeout(function() {
				buildMyApprovals(id, true);
				$widget.removeClass("working")
			}, 500);
		}
	};

	/* create the $settings variable that will contain the settings form */
	var $settings = $("<div class='widget-my-approvals' />"),
		$setupDiv = $("<div class='no-settings' />").appendTo($settings),
		$sectionHeading = $("<div class='section-heading'>Show records pending approval for the following:</div>").appendTo($setupDiv),
		$formSection = $("<div class='form-section' />").appendTo($setupDiv),
		$row = $("<div class='row' />").appendTo($formSection),
		$dataCol = $("<div class='data-column full' />").appendTo($row);

	for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
		var _item = _settings[0].selections[i];
		var $dataGroup = $("<div class='input-group' />").appendTo($dataCol),
			$input = $("<input type='checkbox' name='" + _item.type + "' id='setting-" + _item.type + "' />").appendTo($dataGroup).prop("checked", _item.visible),
			$label = $("<label class='desc' for='setting-" + _item.type + "'><i class='fa " + _item.icon + " fa-fw'></i> " + _item.title + "</label>").appendTo($dataGroup);
	}


	/* open the settings dialog and load the form from the $settings variable */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: _widget.id + "Settings",
		title: "Pending Approvals Settings",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: $settings,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateMySettings(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function buildMyApprovals(id, rebuild) {

	/* set $widget to be the widget DOM element */
	var $widget = $("#" + id);

	/* set _widget to be the widget data and settings from the widgetDataArray */
	var _widget = findWidgetData(id);

	/* widget settings */
	if (!_widget.settings.length) {
		_widget.settings = [{
			selections: [{
				type: "payments",
				title: "Payments",
				icon: "fa-dollar",
				visible: false,
				sort: "",
				sortdirection: "asc",
				open: false
			}, {
				type: "beneficiaries",
				title: "Beneficiaries",
				icon: "fa-book",
				visible: false,
				sort: "",
				sortdirection: "asc",
				open: false
			}, {
				type: "templates",
				title: "Payment Templates",
				icon: "fa-clipboard",
				visible: false,
				sort: "",
				sortdirection: "asc",
				open: false
			}]
		}];
	}

	/* set _settings to be the widget settings */
	var _settings = _widget.settings;

	/* check for any enabled items */
	var _hasVisibleItem = false;

	for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
		if (_settings[0].selections[i].visible) {
			_hasVisibleItem = true;
			break;
		}
	}

	var approvePayments = function() {

		var _target = $(this);

		function approveRecords(dialog) {
			$("#approvePayments").addClass("working");
			setTimeout(function() {
				for (var i = 0, l = approvalData.length; i < l; i++) {
					var _record = approvalData[i];
					for (var a = myApprovals[0].items.length - 1; a >= 0; a--) {
						if (_record.id == myApprovals[0].items[a].id) {
							myApprovals[0].items.splice(a, 1);
						}
					}
				}
				$("#approvePayments").removeClass("working");
				dialogHider(dialog);
				msg = "Sected payments have been approved and submitted for processing.";
				$widget.find(".widget-container").addClass("working");
				setTimeout(function() {
					buildMyApprovals(id, true);
					$widget.find(".widget-container").removeClass("working");
					buildNotification(msg, 300, 5000);
				}, 500);
			}, 500);
		}

		function triggerAuditReportDialog(_target) {

			function downloadReport(_dialog) {
				$("#auditReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "")
				}, 3000);
			};
			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Encoding",
					id: "repEncoding",
					type: "select",
					data: [{
						option: "UTF-8",
						value: "UTF-8"
					}, {
						option: "ASCII",
						value: "ASCII"
					}, {
						option: "Unicode",
						value: "Unicode"
					}]
				}, {
					name: "Report Language",
					id: "repLanguage",
					type: "select",
					data: [{
						option: "English",
						value: "English"
					}, {
						option: "Chinese (Simplified)",
						value: "Chinese (Simplified)"
					}, {
						option: "Chinese (Traditional)",
						value: "Chinese (Traditional)"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}



				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};
			if (_target) {
				var _origin = _target;
			} else {
				var _origin = $("#generateAuditReportButton");
			}
			var _dialog = {
				id: "auditReportDialog",
				title: "Generate Audit Report",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function confirmAuditReport() {
			buildConfirmDialog("This will generate audit reports for each of the payments selected for approval. <br /><br />To generate an audit report for a specific payment in this list, right-click the payment and select &quot;Generate Audit Report&quot; from the context menu.", "Generate Audit Reports?", triggerAuditReportDialog);
		}

		var populateApprovalDialog = function() {
			var $dialogContent = $("<div style=' height: 100%; box-sizing: border-box; padding: 20px;' />");
			var $approveSummaryGrid = $("<div id='approvalGrid' style='width: 100%; height: 50%; margin-bottom: 20px; border: 1px solid #d9d9d9; border-radius: 4px;' />").appendTo($dialogContent);
			var $noteSection = $("<div id='approvalNote' style='padding: 20px; margin-bottom: 20px; white-space: nowrap; border: 1px solid #d9d9d9; -webkit-border-radius: 4px; -moz-border-radius: 4px; border-radius: 4px;' />").appendTo($dialogContent);
			var $heading = $("<div style='font-size: 24px; color: #334a5e;'>Approve with a Transaction Signature</div>").appendTo($noteSection);
			var $textline1 = $("<div style='font-size: 18px; color: #007dba; margin-top: 15px;'>Your smartcard is required for approval</div>").appendTo($noteSection);
			var $imgline = $("<div class='token-image'></div>").appendTo($noteSection);
			var $textline2 = $("<div style='display: inline-block; vertical-align: top; margin-top: 22px; margin-left: 15px;'>Please click &quot;Approve&quot; and enter your PIN into the pop-up window that opens.<br />Note: Your Smartcard must be connected to your computer.</div>").appendTo($noteSection);
			var $helplink = $("<div style='margin-top: 5px;'><a href='about:blank' target='Security Device Help' style='font-size: 14px; text-decoration: none; color: #007dba;'>Click here for more Security Device help</a></div>").appendTo($textline2);
			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : _target;

		var _dialog = {
			id: "approvePayments",
			title: "Approve Selected Payments",
			size: "full-screen",
			icon: "<i class='fa fa-check-circle'></i>",
			content: function() {
				return populateApprovalDialog()
			},
			buttons: []
		}

		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		var $buttonBar = $("div.dialog-buttons"),
			$div = $("<div style='display: inline-block;' />"),
			$cnclBtnDiv = $("<div style='display: inline-block; vertical-align: middle; margin: 0 5px;' />").appendTo($div),
			$cnclBtn = $("<button style='width: 96px; height: 30px; background: #c0c0c0; cursor: pointer;'>Cancel</button>").appendTo($cnclBtnDiv).on("click", function(e) {
				e.preventDefault();
				dialogHider(_dialog)
			}),
			$apprvBtnDiv = $("<div style='display: inline-block; vertical-align: middle; margin: 0 5px;' />").appendTo($div),
			$apprvBtn = $("<button style='width: 96px; height: 30px; background: #c0c0c0; cursor: pointer;'>Approve</button>").appendTo($apprvBtnDiv).on("click", function(e) {
				e.preventDefault();
				approveRecords(_dialog);
			}),
			$auditBtnDiv = $("<div style='display: inline-block; vertical-align: middle; margin: 0 5px;' />").appendTo($div),
			$auditBtn = $("<button style='width: 150px; height: 30px; background: #c0c0c0; cursor: pointer;' id='generateAuditReportButton'>Generate Audit Report</button>").appendTo($auditBtnDiv).on("click", function(e) {
				e.preventDefault();
				confirmAuditReport();
			})
		$div.appendTo($buttonBar);

		var selectedItems = $("input[name=itemCheck]:checked");

		var approvalData = [],
			approvalDataView,
			approvalGrid,
			approvalColumns = [{
				id: "name",
				name: "Beneficiary / Payment Name",
				field: "name",
				width: 250,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true
			}, {
				id: "paymentid",
				name: "Payment ID",
				field: "paymentid",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true
			}, {
				id: "amount",
				name: "Payment Amount",
				field: "amount",
				width: 200,
				sortable: true,
				sorter: "sorterNumeric",
				visible: true,
				cssClass: "num neg",
				headerCssClass: "righted",
				formatter: amountFormatter
			}, {
				id: "ccy",
				name: "Payment Currency",
				field: "ccy",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true
			}, {
				id: "debitaccount",
				name: "Debit Account Number",
				field: "debitaccount",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true
			}, {
				id: "valuedate",
				name: "Value Date",
				field: "valuedate",
				width: 200,
				sortable: true,
				sorter: "sorterDateIso",
				visible: true
			}, {
				id: "type",
				name: "Payment Type",
				field: "type",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true
			}, {
				id: "count",
				name: "No. of Instructions",
				field: "count",
				width: 200,
				sortable: true,
				sorter: "sorterNumeric",
				visible: true
			}];

		var approvalOptions = {
			editable: false,
			autoEdit: false,
			enableCellNavigation: false,
			enableColumnReorder: false,
			enableColumnReorderCheckbox: false,
			syncColumnCellResize: false,
			forceFitColumns: false,
			multiSelect: false
		};

		for (var i = 0, l = selectedItems.length; i < l; i++) {
			var _id = selectedItems[i].value;
			for (var a = 0, b = myApprovals[0].items.length; a < b; a++) {
				if (_id == myApprovals[0].items[a].id) {
					approvalData.push(myApprovals[0].items[a]);
				}
			}
		}

		setTimeout(function() {
			approvalDataView = new Slick.Data.DataView({});
			approvalGrid = new Slick.Grid("#approvalGrid", approvalDataView, approvalColumns, approvalOptions);
			approvalGrid.setSelectionModel(new Slick.RowSelectionModel({
				selectActiveRow: false
			}));
			approvalDataView.setItems(approvalData);
			approvalGrid.setColumns(approvalColumns);
			approvalGrid.onContextMenu.subscribe(function(e, args) {
				e.preventDefault();
				var cell = approvalGrid.getCellFromEvent(e),
					row = cell.row,
					rows = approvalGrid.getSelectedRows(),
					$cmenu = $("#approvalContextMenu");
				var cheight = $cmenu.height(),
					winwidth = $(window).width(),
					winheight = $(window).height(),
					leftpos = e.pageX,
					toppos = e.pageY;
				if (e.pageX + 210 > winwidth) {
					leftpos = e.pageX - 205;
				}
				if (e.pageY + cheight > winheight) {
					toppos = e.pageY - cheight;
					if (toppos < 0) {
						toppos = e.pageY - (cheight - (winheight - e.pageY));
					}
				};
				$(document).off("keyup.hide-context");
				$("body").off("click.hide-context");

				function hideContextMenu() {
					$(".control-menus").children(".control-menu:visible").hide();
					$(".control-list").find(".on").removeClass("on");
					$(".control-menus").find("a.sub-open").removeClass("sub-open");
				}
				hideContextMenu();
				$cmenu.css("top", toppos).css("left", leftpos).css("z-index", 1000).show();
				$(document).on("keyup.hide-context", function(e) {
					if (e.keyCode == 27) {
						hideContextMenu()
					}
				});
				$("body").one("click.hide-context", function() {
					hideContextMenu()
				});
			});
			$(window).bind("resize", function() {
				approvalGrid.resizeCanvas();
			});
			$(window).on("resize", _.debounce(function(e) {
				approvalGrid.resizeCanvas();
			}, 100));
		}, 400);
	}

	var approveNewBeneficiary = function(records) {
		for (var i = 0, l = records.length; i < l; i++) {
			var _record = records[i];
			for (var a = myApprovals[1].items.length - 1; a >= 0; a--) {
				if (_record.id == myApprovals[1].items[a].id) {
					myApprovals[1].items.splice(a, 1);
				}
			}
		}
		if (records.length == 1) {
			msg = "The beneficiary record for <strong>" + records[0].name + " (" + records[0].id + ")</strong> has been approved and is now active.";
		} else {
			msg = "Selected beneficiary records have been approved and are now active.";
		}
		$widget.find(".widget-container").addClass("working");
		setTimeout(function() {
			buildMyApprovals(id, true);
			$widget.find(".widget-container").removeClass("working");
			buildNotification(msg, 300, 5000);
		}, 500);
	}

	var approveSelectedBeneficiaries = function(records) {

		var confirmBeneficiaryApproval = function(_dialog) {
			for (var i = 0, l = records.length; i < l; i++) {
				var _record = records[i];
				for (var a = myApprovals[1].items.length - 1; a >= 0; a--) {
					if (_record.id == myApprovals[1].items[a].id) {
						myApprovals[1].items.splice(a, 1);
					}
				}
			}
			msg = "Selected beneficiary records have been approved.";
			dialogHider(_dialog);
			$widget.find(".widget-container").addClass("working");
			setTimeout(function() {
				buildMyApprovals(id, true);
				$widget.find(".widget-container").removeClass("working");
				buildNotification(msg, 300, 5000);
			}, 500);
		}

		function viewImpactedPayments(e) {
			e.preventDefault();

			var $target = $(e.target),
				beneName = $target.attr("data-beneficiary"),
				beneStatus = $target.attr("data-status"),
				dialogMessage = (beneStatus.indexOf("Deleted") != -1) ? "Upon approval, this beneficiary (" + beneName + ") will be deleted from your address book and the following payments containing this beneficiary <strong>will be moved</strong> into a &quot;Needs Repair&quot; status. The beneficiary will continue to remain in these payments." : "Upon approval, this beneficiary (" + beneName + ") <strong>will be automatically updated</strong> in the following payments:";

			var impactedPaymentData = function() {
				var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
					$p = $("<p>" + dialogMessage + "</p>").appendTo($dialogContent),
					$tableDiv = $("<div style='margin-top: 20px;'>").appendTo($dialogContent),
					$dataTable = $("<div class='data-table' />").appendTo($tableDiv),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment ID</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Beneficiary / Payment Name</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment Type</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>Value Date</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Status</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Draft</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Draft</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Draft</div>").appendTo($dataTableRow),

					$noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
					$note = $("<p><strong>NOTE:</strong><br />The records above have been identified based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".<br />Access to view the above records will be based on your entitlements.</p>").appendTo($noteDiv);
				return $dialogContent;
			}

			var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

			var _dialog = {
				id: "impactedPayments",
				title: "Impact Summary for " + beneName,
				size: "xxl",
				icon: "<i class='fa fa-info-circle'></i>",
				content: function() {
					return impactedPaymentData()
				},
				buttons: [{
					name: "Close",
					icon: "<i class='fa fa-times-circle fa-fw fa-lg'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}]
			}

			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function viewNonImpactedPayments(e) {
			e.preventDefault();

			var $target = $(e.target),
				beneName = $target.attr("data-beneficiary"),
				beneStatus = $target.attr("data-status"),
				dialogMessage = (beneStatus.indexOf("Deleted") != -1) ? "This beneficiary (" + beneName + ") <strong>will not be removed</strong> from the following payments. Please consider removing the beneficiary from these payments manually." : "This beneficiary (" + beneName + ") <strong>will not be updated</strong> in the following payments because the payments have been partially approved or have been sent to the bank. Please consider updating these payments manually.";

			var nonImpactedPaymentData = function() {
				var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
					$p = $("<p>" + dialogMessage + "</p>").appendTo($dialogContent),
					$tableDiv = $("<div style='margin-top: 20px;'>").appendTo($dialogContent),
					$dataTable = $("<div class='data-table' />").appendTo($tableDiv),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment ID</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Beneficiary / Payment Name</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Payment Type</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>Value Date</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Bcwsal28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - bPyKE - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>International Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSQchI28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - YZimf - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>BSmBiu28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Batch - ceRVP - 28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 15%;'>28/11/2016</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Submitted</div>").appendTo($dataTableRow),
					$noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
					$note = $("<p><strong>NOTE:</strong><br />The records above have been identified based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".<br />Access to view the above records will be based on your entitlements.</p>").appendTo($noteDiv);
				return $dialogContent;
			}

			var $target = $(e.target),
				beneName = $target.attr("data-beneficiary");

			var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

			var _dialog = {
				id: "nonImpactedPayments",
				title: "Impact Summary for " + beneName,
				size: "xxl",
				icon: "<i class='fa fa-info-circle'></i>",
				content: function() {
					return nonImpactedPaymentData()
				},
				buttons: [{
					name: "Close",
					icon: "<i class='fa fa-times-circle fa-fw fa-lg'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}]
			}

			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function viewImpactedTemplates(e) {
			e.preventDefault();

			var $target = $(e.target),
				beneName = $target.attr("data-beneficiary"),
				beneStatus = $target.attr("data-status"),
				dialogMessage = (beneStatus.indexOf("Deleted") != -1) ? "Upon approval, this beneficiary (" + beneName + ") <strong>will be automatically removed</strong> from the following templates:" : "Upon approval, this beneficiary (" + beneName + ") <strong>will be automatically updated</strong> in the following templates:";

			var impactedTemplateData = function() {
				var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
					$p = $("<p>" + dialogMessage + "</p>").appendTo($dialogContent),
					$tableDiv = $("<div style='margin-top: 20px;'>").appendTo($dialogContent),
					$dataTable = $("<div class='data-table' />").appendTo($tableDiv),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template ID</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template Name</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Payment Type</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Status</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>lGMDjZMDKOTMP</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template - GTF</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Domestic Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Draft</div>").appendTo($dataTableRow),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>KpldUSpockTMP</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Template - EiT</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>International Payment</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Draft</div>").appendTo($dataTableRow),
					$noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
					$note = $("<p><strong>NOTE:</strong><br />The records above have been identified based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".<br />Access to view the above records will be based on your entitlements.</p>").appendTo($noteDiv);
				return $dialogContent;
			}

			var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

			var _dialog = {
				id: "impactedTemplates",
				title: "Impact Summary for " + beneName,
				size: "xxl",
				icon: "<i class='fa fa-info-circle'></i>",
				content: function() {
					return impactedTemplateData()
				},
				buttons: [{
					name: "Close",
					icon: "<i class='fa fa-times-circle fa-fw fa-lg'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}]
			}

			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		var impactSummaryDialog = function() {
			var $dialogContent = $("<div style='padding: 20px; color: #394A58;' />"),
				$msgDiv = $("<p>The following beneficiaries exist in current payments and templates which may be impacted by confirming your approval. Refer to the table below to view records that will have beneficiary updates applied.</p>").appendTo($dialogContent),
				$tableDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
				$table = $("<table style='width: 100%; font-size: 14px; border-collapse: collapse; border-spacing: 0;' />").appendTo($tableDiv),
				$tr = $("<tr />").appendTo($table),
				$td = $("<td style='width: 15%; padding: 11px 10px;' />").appendTo($tr),
				$td = $("<td style='width: 28%; padding: 11px 10px;' />").appendTo($tr),
				$td = $("<td style='width: 12%; padding: 11px 10px;' />").appendTo($tr),
				$td = $("<td colspan='2' style='width: 30%; padding: 11px 10px; text-align: center;font-weight: bold;  background: #f8f8f8; border: 1px solid #cdcdcd;'>Payments</td>").appendTo($tr),
				$td = $("<td style='width: 15%; padding: 11px 10px; text-align: center; font-weight: bold; background: #f8f8f8; border: 1px solid #cdcdcd; border-left: 0;'>Templates</td>").appendTo($tr),
				$tr = $("<tr />").appendTo($table),
				$td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px;'>Beneficiary ID</td>").appendTo($tr),
				$td = $("<td style='width: 28%; border: 1px solid #cdcdcd; padding: 11px 10px;'>Beneficiary Name</td>").appendTo($tr),
				$td = $("<td style='width: 12%; border: 1px solid #cdcdcd; padding: 11px 10px;'>Action</td>").appendTo($tr),
				$td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px; background: #f8f8f8; text-align: center;'>No. to be updated</td>").appendTo($tr),
				$td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px; background: #f8f8f8; text-align: center;'>No. that will <strong>not be</strong> updated</td>").appendTo($tr),
				$td = $("<td style='width: 15%; border: 1px solid #cdcdcd; padding: 11px 10px; background: #f8f8f8; text-align: center;'>No. to be updated</td>").appendTo($tr);

			for (var i = 0, l = records.length; i < l; i++) {
				var _record = records[i];
				var _action;
				if (_record.action.indexOf("Deleted") != -1) {
					_action = "Deleted";
					var $tr = $("<tr />").appendTo($table),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.id + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.name + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _action + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>0</span>").appendTo($td),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>10</a>").appendTo($td).on("click", viewNonImpactedPayments),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>2</a>").appendTo($td).on("click", viewImpactedTemplates);
				} else if (_record.action.indexOf("Modified") != -1) {
					_action = "Modified";
					var $tr = $("<tr />").appendTo($table),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.id + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.name + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _action + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>3</a>").appendTo($td).on("click", viewImpactedPayments),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>10</a>").appendTo($td).on("click", viewNonImpactedPayments),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<a href='javascript:void(0)' style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>2</a>").appendTo($td).on("click", viewImpactedTemplates);
				} else if (_record.action.indexOf("New") != -1) {
					_action = "Created";
					var $tr = $("<tr />").appendTo($table),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.id + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _record.name + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px;'>" + _action + "</td>").appendTo($tr),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>0</span>").appendTo($td),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>0</span>").appendTo($td),
						$td = $("<td style='border: 1px solid #cdcdcd; padding: 11px 10px; text-align: center;' />").appendTo($tr),
						$a = $("<span style='color: #007dba; font-weight: bold;' data-beneficiary='" + _record.name + "' data-status='" + _record.action + "'>0</span>").appendTo($td);
				}
			}

			var $noteDiv = $("<div style='margin-top: 20px;' />").appendTo($dialogContent),
				$note = $("<p><strong>NOTE:</strong></p>").appendTo($noteDiv),
				$note1 = $("<p style='margin-top: 10px;'>The records above are impacted based on their current status as at " + smartDates('today') + ", " + timeFormatter() + ".</p>").appendTo($noteDiv),
				$note2 = $("<p style='margin-top: 10px;'>Select Approve to continue.</p>").appendTo($noteDiv);
			return $dialogContent;
		}

		var _dialog = {
			id: "impactSummaryDialog",
			title: "Impact Summary",
			size: "xxl",
			icon: "<i class='fa fa-info-circle'></i>",
			content: function() {
				return impactSummaryDialog()
			},
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Approve",
				icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						confirmBeneficiaryApproval(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}

		dialogViewer('', _dialog, dialogBuilder(_dialog));
	}

	var approveBeneficiaries = function() {
		var selectedItems = $("input[name=itemCheck]:checked"),
			sel = selectedItems.length;
		if (sel == 1) {
			var record;
			for (var i = 0, l = myApprovals[1].items.length; i < l; i++) {
				if (selectedItems[0].value == myApprovals[1].items[i].id) {
					record = myApprovals[1].items[i];
					break;
				}
			}
			if (record.status == "Active") {
				if (record.action == "Modified") {
					buildConfirmDialog("Changes to this beneficiary record will be approved and saved.", "Do you want to continue?", function() {
						$("body").addClass("loading");
						setTimeout(function() {
							$("body").removeClass("loading");
							approveSelectedBeneficiaries([record]);
						}, 500);
					});
				} else if (record.action == "Deleted") {
					buildConfirmDialog("This beneficiary record will be deleted. It will be available in the &quot;Deleted&quot; queue for a period of time.", "Do you want to continue?", function() {
						$("body").addClass("loading");
						setTimeout(function() {
							$("body").removeClass("loading");
							approveSelectedBeneficiaries([record]);
						}, 500);
					});
				}
			} else if (record.status == "New") {
				buildConfirmDialog("On approval this beneficiary record will become active and available for use in payment instructions.", "Do you want to continue?", function() {
					approveNewBeneficiary([record]);
				});
			}
		} else if (sel > 1) {
			var selected = [],
				selectedWorkflows = [];
			for (var i = 0, l = selectedItems.length; i < l; i++) {
				var _id = selectedItems[i].value;
				for (var a = 0, b = myApprovals[1].items.length; a < b; a++) {
					if (_id == myApprovals[1].items[a].id) {
						selected.push(myApprovals[1].items[a]);
						selectedWorkflows.push(myApprovals[1].items[a].action);
					}
				}
			}
			if (selectedWorkflows.indexOf("Deleted") > -1 && selectedWorkflows.indexOf("Modified") == -1 && selectedWorkflows.indexOf("New") == -1) {
				buildConfirmDialog("Selected beneficiary records will be deleted. They will be available in the &quot;Deleted&quot; queue for a period of time.", "Do you want to continue?", function() {
					$("body").addClass("loading");
					setTimeout(function() {
						$("body").removeClass("loading");
						approveSelectedBeneficiaries(selected);
					}, 500);
				});
			} else if (selectedWorkflows.indexOf("Deleted") == -1 && selectedWorkflows.indexOf("Modified") > -1 && selectedWorkflows.indexOf("New") == -1) {
				buildConfirmDialog("Changes to selected beneficiary records will be approved and saved.", "Do you want to continue?", function() {
					$("body").addClass("loading");
					setTimeout(function() {
						$("body").removeClass("loading");
						approveSelectedBeneficiaries(selected);
					}, 500);
				});
			} else if (selectedWorkflows.indexOf("Deleted") == -1 && selectedWorkflows.indexOf("Modified") == -1 && selectedWorkflows.indexOf("New") > -1) {
				buildConfirmDialog("On approval, selected beneficiary records will become active and available for use in payment instructions.", "Do you want to continue?", function() {
					approveNewBeneficiary(selected);
				});
			} else {
				buildConfirmDialog("On approval, selected beneficiary records will be updated.<div style='font-size: 85%; margin-top: 15px;'>New beneficiary records will become approved and active.<br /><br />Beneficiary records pending changes will be saved and updated.<br /><br />Beneficiary records pending deletion will be deleted.</div>", "Do you want to continue?", function() {
					$("body").addClass("loading");
					setTimeout(function() {
						$("body").removeClass("loading");
						approveSelectedBeneficiaries(selected);
					}, 500);
				});
			}
		}
	}

	var approveSelectedTemplates = function(records) {
		for (var i = 0, l = records.length; i < l; i++) {
			var _record = records[i];
			for (var a = myApprovals[2].items.length - 1; a >= 0; a--) {
				if (_record.id == myApprovals[2].items[a].id) {
					myApprovals[2].items.splice(a, 1);
				}
			}
		}
		msg = "Selected payment templates have been approved.";
		$widget.find(".widget-container").addClass("working");
		setTimeout(function() {
			buildMyApprovals(id, true);
			$widget.find(".widget-container").removeClass("working");
			buildNotification(msg, 300, 5000);
		}, 500);
	}

	var approveTemplates = function() {
		var selectedItems = $("input[name=itemCheck]:checked"),
			sel = selectedItems.length,
			msg;

		if (sel == 1) {
			var record;
			for (var i = 0, l = myApprovals[2].items.length; i < l; i++) {
				if (selectedItems[0].value == myApprovals[2].items[i].id) {
					record = myApprovals[2].items[i];
					break;
				}
			}
			if (record.action == "Modified") {
				msg = "Changes to this payment template will be approved and saved."
			} else if (record.action == "Deleted") {
				msg = "This payment template will be deleted."
			} else if (record.action == "New") {
				msg = "This payment template will become active and available for use."
			}
			buildConfirmDialog(msg, "Do you want to continue?", function() {
				approveSelectedTemplates([record]);
			});
		} else if (sel > 1) {
			var selected = [],
				selectedWorkflows = [];
			for (var i = 0, l = selectedItems.length; i < l; i++) {
				var _id = selectedItems[i].value;
				for (var a = 0, b = myApprovals[2].items.length; a < b; a++) {
					if (_id == myApprovals[2].items[a].id) {
						selected.push(myApprovals[2].items[a]);
						selectedWorkflows.push(myApprovals[2].items[a].action);
					}
				}
			}
			if (selectedWorkflows.indexOf("Deleted") > -1 && selectedWorkflows.indexOf("Modified") == -1 && selectedWorkflows.indexOf("New") == -1) {
				msg = "Selected payment templates will be deleted.";
			} else if (selectedWorkflows.indexOf("Deleted") == -1 && selectedWorkflows.indexOf("Modified") > -1 && selectedWorkflows.indexOf("New") == -1) {
				msg = "Changes to selected payment templates will be approved and saved.";
			} else if (selectedWorkflows.indexOf("Deleted") == -1 && selectedWorkflows.indexOf("Modified") == -1 && selectedWorkflows.indexOf("New") > -1) {
				msg = "Selected payment templates will become active and available for use.";
			} else {
				msg = "On approval, selected payment templates will be approved.<div style='font-size: 85%; margin-top: 15px;'>New payment templates will become active and available for use.<br /><br />Payment templates pending changes will be saved and updated.<br /><br />Payment templates pending deletion will be deleted.</div>";
			}
			buildConfirmDialog(msg, "Do you want to continue?", function() {
				approveSelectedTemplates(selected);
			});
		}
	}

	var rejectSelectedItems = function() {

		var _target = $(this),
			type = $(this).attr("type");

		var rejectAndClearItems = function(_dialog) {
			var _itemsForRejection = $("input[name=itemCheck]:checked");
			for (var i = 0, l = _itemsForRejection.length; i < l; i++) {
				var _id = _itemsForRejection[i].value
				if (type == "payments") {
					for (var a = myApprovals[0].items.length - 1; a >= 0; a--) {
						if (_id == myApprovals[0].items[a].id) {
							myApprovals[0].items.splice(a, 1);
						}
					}
				} else if (type == "beneficiaries") {
					for (var a = myApprovals[1].items.length - 1; a >= 0; a--) {
						if (_id == myApprovals[1].items[a].id) {
							myApprovals[1].items.splice(a, 1);
						}
					}
				} else if (type == "templates") {
					for (var a = myApprovals[2].items.length - 1; a >= 0; a--) {
						if (_id == myApprovals[2].items[a].id) {
							myApprovals[2].items.splice(a, 1);
						}
					}
				}
			}
			if (_itemsForRejection.length == 1) {
				msg = "This record has been rejected.";
			} else {
				msg = "Selected records have been rejected.";
			}
			dialogHider(_dialog);
			$widget.find(".widget-container").addClass("working");
			setTimeout(function() {
				buildMyApprovals(id, true);
				$widget.find(".widget-container").removeClass("working");
				buildNotification(msg, 300, 5000);
			}, 500);
		}

		var renderRejectContent = function() {
			var $form = $("<div class='form-section' />");
			var $row = $("<div class='row' />").appendTo($form);
			var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
			var $textarea = $("<textarea style='width: 425px; height: 230px;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
			return $form;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "rejectSelectedItems",
			title: "Enter A Reason For Rejection",
			size: "small",
			icon: "<i class='fa fa-ban'></i>",
			content: function() {
				return renderRejectContent();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog);
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						rejectAndClearItems(_dialog);
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var showPaymentNotificaitonsDialog = function(e) {

		e.preventDefault();

		var _target = $(this);

		var item;

		for (var i = 0, l = myApprovals[0].items.length; i < l; i++) {
			if (_target.attr("data-item") == myApprovals[0].items[i].id) {
				item = myApprovals[0].items[i];
				break;
			}
		}

		function renderPaymentNotifications() {

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewAlertsDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payment Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + item.paymentid + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Beneficiary / Payment Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + item.name + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + item.status + "</div>").appendTo($dataCol);

			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Alerts</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$boxDiv = $("<div />").appendTo($boxContent),
				$dataRow = $("<div class='row' />").appendTo($boxDiv),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>This payment has the following alerts:</div>").appendTo($dataCol),
				$alertGrid = $("<div class='payment-grid' style='height: auto; max-height: 307px; overflow-y: auto;' id='alertsGrid' />").appendTo($dataCol),
				$ul = $("<ul class='alert-list' />").appendTo($alertGrid),
				$li = $("<li><span class='alert-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='alert-text'>This is a sample notification message. Lorem ipsum dolor sit ament...</span></li>").appendTo($ul),
				$li = $("<li><span class='alert-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='alert-text'>This is a sample notification message. Lorem ipsum dolor sit ament...</span></li>").appendTo($ul),
				$li = $("<li><span class='alert-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='alert-text'>This is a sample notification message. Lorem ipsum dolor sit ament...</span></li>").appendTo($ul);

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "viewPaymentAlerts",
			title: "Payment Alerts",
			size: "xwide",
			icon: "<i class='fa fa-exclamation-triangle'></i>",
			content: function() {
				return renderPaymentNotifications();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var updateWidgetSettings = function() {
		var _rebuild = false;
		for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
			if ($("#" + _settings[0].selections[i].type).prop("checked") != _settings[0].selections[i].visible) {
				_rebuild = true;
				break;
			}
		}
		for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
			_settings[0].selections[i].visible = $("#" + _settings[0].selections[i].type).prop("checked");
		}
		store.set('saved_widget_data', widgetDataArray);
		if (_rebuild) {
			var $widget = $(this).closest("div.widget-container").addClass("loading");
			setTimeout(function() {
				buildMyApprovals(id, true);
				$widget.removeClass("loading")
			}, 500);
		}
	}

	var updateWidgetOpenView = function(e) {
		e.preventDefault();
		var _type = $(this).attr("data-toggle");
		var _group = $("div.group-container").attr("data-group");
		for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
			if (_type == _settings[0].selections[i].type) {
				if (_type == _group) {
					_settings[0].selections[i].open = false
				} else {
					_settings[0].selections[i].open = true
				}
			} else {
				_settings[0].selections[i].open = false
			}
		}
		store.set('saved_widget_data', widgetDataArray);
		var $widget = $(this).closest("div.widget-container").addClass("working");
		setTimeout(function() {
			buildMyApprovals(id, true);
			$widget.removeClass("working")
		}, 500);
	}

	var updateWidgetSorting = function(_dialog) {

		var _target = $(this),
			_title = _target.attr("data-sort"),
			_sort = _target.attr("data-sort-by"),
			_direction = _target.attr("data-sort-direction");

		var saveSortSettings = function() {
			for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
				if (_title == _settings[0].selections[i].title) {
					_settings[0].selections[i].sort = $("#sortSettings").val();
					break;
				}
			}
			_settings[0].selections[i].sortdirection = $('input[name=sortdirection]:checked').val();
			store.set('saved_widget_data', widgetDataArray);
			dialogHider(_dialog);
			$widget.find("div.widget-container").addClass("working");
			setTimeout(function() {
				buildMyApprovals(id, true);
				$widget.find("div.widget-container").removeClass("working")
			}, 500);
		}

		var renderSortSettings = function() {
			var $dialogContent = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section top-label' />").appendTo($dialogContent),
				$row = $("<div class='row' />").appendTo($formSection),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Sort " + _title + " By</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol),
				$select = $("<select id='sortSettings'></select>").appendTo($customSelect),
				$row = $("<div class='row' />").appendTo($formSection),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$inputGroup = $("<div class='input-group'>").appendTo($dataCol),
				$radio = $("<input type='radio' value='asc' name='sortdirection' id='ascending' />").appendTo($inputGroup),
				$labeldesc = $("<label class='desc' for='ascending'>Ascending</label>").appendTo($inputGroup),
				$inputGroup = $("<div class='input-group'>").appendTo($dataCol),
				$radio = $("<input type='radio' value='dsc' name='sortdirection' id='descending' />").appendTo($inputGroup),
				$labeldesc = $("<label class='desc' for='descending'>Descending</label>").appendTo($inputGroup);
			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "setItemSorting",
			title: "Sort Settings",
			size: "xsmall",
			icon: "<i class='fa fa-sort'></i>",
			content: function() {
				return renderSortSettings();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Ok",
				icon: "<i class='fa fa-check fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						saveSortSettings(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		var _options;
		if (_title == "Payments") {
			_options = [{
				val: "",
				text: ""
			}, {
				val: "name",
				text: "Payment / Beneficiary Name"
			}, {
				val: "amount",
				text: "Payment Amount"
			}, {
				val: "ccy",
				text: "Payment Currency"
			}, {
				val: "type",
				text: "Payment Type"
			}, {
				val: "count",
				text: "No. of Items"
			}, {
				val: "valuedate",
				text: "Value Date"
			}];
		} else if (_title == "Beneficiaries") {
			_options = [{
				val: "",
				text: ""
			}, {
				val: "action",
				text: "Action"
			}, {
				val: "name",
				text: "Beneficiary Name",
			}]
		} else if (_title == "Payment Templates") {
			_options = [{
				val: "",
				text: ""
			}, {
				val: "action",
				text: "Action"
			}, {
				val: "account",
				text: "Funding Account"
			}, {
				val: "count",
				text: "No. of Items"
			}, {
				val: "type",
				text: "Payment Type"
			}, {
				val: "name",
				text: "Template Name"
			}];
		}
		for (var i = 0, l = _options.length; i < l; i++) {
			var $option = $("<option value='" + _options[i].val + "'>" + _options[i].text + "</option>").appendTo($("#sortSettings"));
			if (_options[i].val == _sort) {
				$option.attr("selected", true);
			}
		}
		if (_direction == "asc") {
			$("#ascending").prop("checked", true);
		} else {
			$("#descending").prop("checked", true);
		}
	}

	var loadPaymentData = function(group) {
		var $groupContainer = $("<div class='group-container' data-group='" + _group.type + "' />"),
			$div = $("<div />").appendTo($groupContainer),
			$row = $("<div class='approval-header-row' />").appendTo($div),
			$col = $("<div class='approval-header-col' style='position: absolute; top: 0; left: 0; text-align: center; padding: 0; width: 60px; cursor: pointer;' />").appendTo($row).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=itemCheck]");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$input = $("<input type='checkbox' name='selectAll' />").appendTo($col),
			$col = $("<div class='approval-header-col' style='position: absolute; top: 0; left: 60px; padding: 0; width: 40px;' />").appendTo($row),
			$notice = $("<i class='fa fa-exclamation-triangle fa-fw'></i>").appendTo($col),
			$col = $("<div class='approval-header-col' style='width: 50%; padding-left: 100px;'>Payment Information</div>").appendTo($row),
			$col = $("<div class='approval-header-col' style='width: 20%;'>Value Date</div>").appendTo($row),
			$col = $("<div class='approval-header-col' style='text-align: right; width: 30%;'>Payment Amount</div>").appendTo($row);

		for (var i = 0, l = myApprovals[0].items.length; i < l; i++) {
			var _item = myApprovals[0].items[i];
			var $row = $("<div class='approval-data-row' />").appendTo($div).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						$target = $target.closest("div.approval-data-row").find("input[name='itemCheck']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='selectAll']").prop("checked", false)
					}
					if ($("input[name=itemCheck]:checked").length == $("input[name=itemCheck]").length) {
						$("input[name='selectAll']").prop("checked", true)
					}
				}),
				$col = $("<div class='approval-data-col' style='position: absolute; top: 0; left: 0; text-align: center; padding: 0; width: 60px;' />").appendTo($row),
				$input = $("<input type='checkbox' name='itemCheck' value='" + _item.id + "' />").appendTo($col).on("change", function() {
					var selected = ($(this).is(":checked")) ? $(this).closest("div.approval-data-row").addClass("selected") : $(this).closest("div.approval-data-row").removeClass("selected");
				}),
				$col = $("<div class='approval-header-col' style='position: absolute; top: 0; left: 60px; padding: 0; width: 40px;' />").appendTo($row);
			if (_item.notifications) {
				var $notifications = $("<a href='javascript:void(0)' class='notice' data-item='" + _item.id + "' title='View Payment Alerts'><i class='fa fa-exclamation-triangle fa-fw'></i></a>").appendTo($col).on("click", showPaymentNotificaitonsDialog);
			}
			var $col = $("<div class='approval-data-col' style='width: 50%; padding-left: 100px;' />").appendTo($row),
				$infoDiv = $("<div class='payment-info' />").appendTo($col),
				$link = $("<a href='payments-summary.html#detail' title='Go to Payment Details'>" + _item.name + "</a>").appendTo($infoDiv),
				$info = $("<div style='font-size: 14px;'>" + _item.type + " - " + _item.count + " Items</div>").appendTo($infoDiv),
				$col = $("<div class='approval-data-col' style='width: 20%;'>" + _item.valuedate + "</div>").appendTo($row),
				$col = $("<div class='approval-data-col' style='text-align: right; width: 30%;'>" + _item.ccy + " &nbsp; $" + addCommas(_item.amount) + "</div>").appendTo($row);
		}

		return $groupContainer;
	}

	var loadBeneData = function(group) {
		var $groupContainer = $("<div class='group-container' data-group='" + _group.type + "' />"),
			$div = $("<div />").appendTo($groupContainer),
			$row = $("<div class='approval-header-row' />").appendTo($div),
			$col = $("<div class='approval-header-col' style='position: absolute; top: 0; left: 0; text-align: center; padding: 0; width: 60px; cursor: pointer;' />").appendTo($row).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=itemCheck]");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$input = $("<input type='checkbox' name='selectAll' />").appendTo($col),
			$col = $("<div class='approval-header-col' style='width: 50%; padding-left: 60px;'>Beneficiary Name</div>").appendTo($row),
			$col = $("<div class='approval-header-col' style='width: 30%;'>Account Number</div>").appendTo($row),
			$col = $("<div class='approval-header-col' style='width: 20%;'>Action</div>").appendTo($row);

		for (var i = 0, l = myApprovals[1].items.length; i < l; i++) {
			var _item = myApprovals[1].items[i];
			var $row = $("<div class='approval-data-row' />").appendTo($div).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						$target = $target.closest("div.approval-data-row").find("input[name='itemCheck']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='selectAll']").prop("checked", false)
					}
					if ($("input[name=itemCheck]:checked").length == $("input[name=itemCheck]").length) {
						$("input[name='selectAll']").prop("checked", true)
					}
				}),
				$col = $("<div class='approval-data-col' style='position: absolute; top: 0; left: 0; text-align: center; padding: 0; width: 60px;' />").appendTo($row),
				$input = $("<input type='checkbox' name='itemCheck' value='" + _item.id + "'/>").appendTo($col).on("change", function() {
					var selected = ($(this).is(":checked")) ? $(this).closest("div.approval-data-row").addClass("selected") : $(this).closest("div.approval-data-row").removeClass("selected");
				}),
				$col = $("<div class='approval-data-col' style='width: 50%; padding-left: 60px;' />").appendTo($row),
				$link = $("<a href='payments-beneficiaries.html#detail' title='Go to Beneficiary Details'>" + _item.name + "</a>").appendTo($col),
				$col = $("<div class='approval-data-col' style='width: 30%;'>" + _item.account + "</div>").appendTo($row),
				$col = $("<div class='approval-data-col' style='width: 20%;'>" + _item.action + "</div>").appendTo($row);
		}
		return $groupContainer;
	}

	var loadTemplateData = function(group) {
		var $groupContainer = $("<div class='group-container' data-group='" + _group.type + "' />"),
			$div = $("<div />").appendTo($groupContainer),
			$row = $("<div class='approval-header-row' />").appendTo($div),
			$col = $("<div class='approval-header-col' style='position: absolute; top: 0; left: 0; text-align: center; padding: 0; width: 60px; cursor: pointer;' />").appendTo($row).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=itemCheck]");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$input = $("<input type='checkbox' name='selectAll' />").appendTo($col),
			$col = $("<div class='approval-header-col' style='width: 50%; padding-left: 60px;'>Template Information</div>").appendTo($row),
			$col = $("<div class='approval-header-col' style='width: 30%;'>Funding Account</div>").appendTo($row),
			$col = $("<div class='approval-header-col' style='width: 20%;'>Action</div>").appendTo($row);

		for (var i = 0, l = myApprovals[2].items.length; i < l; i++) {
			var _item = myApprovals[2].items[i];
			var $row = $("<div class='approval-data-row' />").appendTo($div).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						$target = $target.closest("div.approval-data-row").find("input[name='itemCheck']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='selectAll']").prop("checked", false)
					}
					if ($("input[name=itemCheck]:checked").length == $("input[name=itemCheck]").length) {
						$("input[name='selectAll']").prop("checked", true)
					}
				}),
				$col = $("<div class='approval-data-col' style='position: absolute; top: 0; left: 0; text-align: center; padding: 0; width: 60px;' />").appendTo($row),
				$input = $("<input type='checkbox' name='itemCheck' value='" + _item.id + "' />").appendTo($col).on("change", function() {
					var selected = ($(this).is(":checked")) ? $(this).closest("div.approval-data-row").addClass("selected") : $(this).closest("div.approval-data-row").removeClass("selected");
				}),
				$col = $("<div class='approval-data-col' style='width: 50%; padding-left: 60px;' />").appendTo($row),
				$infoDiv = $("<div class='payment-info' />").appendTo($col),
				$link = $("<a href='payments-templates.html#detail' title='Go to Template Details'>" + _item.name + "</a>").appendTo($infoDiv),
				$info = $("<div style='font-size: 14px;'>" + _item.type + " - " + _item.count + " Items</div>").appendTo($infoDiv),
				$col = $("<div class='approval-data-col' style='width: 30%;'>" + _item.account + "</div>").appendTo($row),
				$col = $("<div class='approval-data-col' style='width: 20%;'>" + _item.action + "</div>").appendTo($row);
		}
		return $groupContainer;
	}

	/* build the widget content */
	var $wrapper = $("<div class='wrapper' />");

	if (_hasVisibleItem) {
		var $container = $("<div class='approvals-container' />").appendTo($wrapper);
		for (var i = 0, l = _settings[0].selections.length; i < l; i++) {
			if (_settings[0].selections[i].visible) {
				var _group = _settings[0].selections[i];
				var _count;
				for (var a = 0, b = myApprovals.length; a < b; a++) {
					if (_group.type == myApprovals[a].type) {
						_count = myApprovals[a].items.length;
						break;
					}
				}
				if (_count == 0) {
					_settings[0].selections[i].open = false;
				}
				var _toggleIcon = (_group.open) ? "fa-minus-square" : "fa-plus-square";
				var $groupRow = $("<div class='group-row' />");
				var $toggleLink = $("<a href='javascript:void(0)' class='toggle-link' data-toggle='" + _group.type + "' />").appendTo($groupRow).on("click", updateWidgetOpenView);
				var $toggleIcon = $("<i class='fa " + _toggleIcon + " fa-fw' style='margin-right: 10px;'></i>").appendTo($toggleLink);
				var $heading = $("<span><i class='fa " + _group.icon + " fa-fw'></i> " + _group.title + " (" + _count + ")</span>").appendTo($toggleLink);
				var $sortToggle = $("<a href='javascript:void(0)' class='toggle-sort' data-sort='" + _group.title + "' data-sort-by='" + _group.sort + "' data-sort-direction='" + _group.sortdirection + "' title='Sort Settings for " + _group.title + "'><i class='fa fa-sort fa-fw'></i></a>").appendTo($groupRow).on("click", updateWidgetSorting);
				$groupRow.appendTo($container);
				if (_group.open) {
					$container.addClass("open");
					var $approvalButtons = $("<div class='approvals-buttons' />").appendTo($wrapper),
						$rejectButton = $("<a href='javascript:void(0)' id='" + id + "-reject' class='form-button'><i class='fa fa-ban fa-fw'></i>Reject</a>").appendTo($approvalButtons),
						$approveButton = $("<a href='javascript:void(0)' id='" + id + "-approve' class='form-button primary'><i class='fa fa-check fa-fw'></i>Approve</a>").appendTo($approvalButtons);
					if (_group.type == "payments") {
						loadPaymentData(_group).appendTo($container);
						$rejectButton.attr("type", _group.type).on("click", rejectSelectedItems);
						$approveButton.on("click", approvePayments);
					} else if (_group.type == "beneficiaries") {
						loadBeneData(_group).appendTo($container);
						$rejectButton.attr("type", _group.type).on("click", rejectSelectedItems);
						$approveButton.on("click", approveBeneficiaries);
					} else if (_group.type == "templates") {
						loadTemplateData(_group).appendTo($container);
						$rejectButton.attr("type", _group.type).on("click", rejectSelectedItems);
						$approveButton.on("click", approveTemplates);
					}
				}
			}
		}
	} else {
		var $setupDiv = $("<div class='no-settings' />"),
			$sectionHeading = $("<div class='section-heading'>Show records pending approval for the following:</div>").appendTo($setupDiv),
			$formSection = $("<div class='form-section' />").appendTo($setupDiv),
			$row = $("<div class='row' />").appendTo($formSection),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
			$input = $("<input type='checkbox' name='payments' id='payments' />").appendTo($dataGroup),
			$label = $("<label class='desc' for='payments'><i class='fa fa-dollar fa-fw'></i> Payments</label>").appendTo($dataGroup),
			$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
			$input = $("<input type='checkbox' name='beneficiaries' id='beneficiaries' />").appendTo($dataGroup),
			$label = $("<label class='desc' for='beneficiaries'><i class='fa fa-book fa-fw'></i> Beneficiaries</label>").appendTo($dataGroup),
			$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
			$input = $("<input type='checkbox' name='templates' id='templates' />").appendTo($dataGroup),
			$label = $("<label class='desc' for='templates'><i class='fa fa-clipboard fa-fw'></i> Payment Templates</label>").appendTo($dataGroup),
			$row = $("<div class='row' />").appendTo($formSection),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$saveButton = $("<a href='javascript:void(0)' class='form-button primary' data-id='" + _widget.id + "'><i class='fa fa-check fa-fw'></i>Ok</a>").appendTo($dataCol).on("click", updateWidgetSettings);
		$setupDiv.appendTo($wrapper);
	}

	/* attach the content */
	if (rebuild == true) {
		$widget.find(".widget-content").empty().html($wrapper);
	} else {
		return $wrapper;
	}
}



/********** GRIDSTER **********/

var columnWidths, resizing_handle, responsiveTrigger = false;

function responsiveGridster() {
	columnWidths = Math.floor((($(".gridster").width()) / 12) - (12 * 2));
	gridster.resize_widget_dimensions({
		widget_base_dimensions: [columnWidths, 100]
	});
	if ($(window).width() <= 800) {
		if (!responsiveTrigger) {
			responsiveTrigger = true;
			var $wrapper = $(".gridster > ul"),
				$li = $wrapper.children("li");
			$li.sort(function(a, b) {
				if ($(a).attr("data-row") === $(b).attr("data-row")) {
					var x = $(a).attr("data-col"),
						y = $(b).attr("data-col");
					return x < y ? -1 : x > y ? 1 : 0;
				}
				return +$(a).attr('data-row') - +$(b).attr('data-row');
			}).each(function() {
				$wrapper.append(this);
			});
			gridster.disable();
			gridster.disable_resize();
		}
	} else {
		gridster.enable();
		gridster.enable_resize();
		responsiveTrigger = false;
	}
	if ($(".highchart").size()) {
		$(".highchart").parents(".widget-content").css("display", "none");
		clearTimeout(resizing_handle);
		resizing_handle = setTimeout(function() {
			$(".highchart").each(function() {
				$(this).parents(".widget-content").css("display", "");
				Highcharts.charts[$(this).data('highchartsChart')].setSize($(this).width(), $(this).height(), false)
			});
		}, 500);
	}
}


/***** ON READY BINDINGS *****/

$(function() {

	if ($(".gridster").size() > 0) {

		/* initialise gridster */
		columnWidths = Math.floor((($(".gridster").width()) / 12) - (12 * 2));
		gridster = $(".gridster > ul").gridster({
			widget_margins: [12, 12],
			widget_base_dimensions: [columnWidths, 100],
			serialize_params: function($w, wgd) {
				return {
					widget: $($w).attr("data-type"),
					id: $($w).attr('id'),
					col: wgd.col,
					row: wgd.row,
					size_x: wgd.size_x,
					size_y: wgd.size_y,
					min_size_x: wgd.min_size_x,
					min_size_y: wgd.min_size_y
				};
			},
			resize: {
				enabled: true,
				max_size: [12, 8],
				start: function() {
					if (this.$resized_widget.find(".highchart").size()) {
						this.$resized_widget.find(".widget-content").hide();
					}
				},
				stop: function() {
					if (this.$resized_widget.find(".highchart").size()) {
						var $wig = this.$resized_widget.find(".widget-content");
						setTimeout(function() {
							$wig.show();
							Highcharts.charts[$wig.find(".highchart").data('highchartsChart')].setSize($wig.find(".highchart").width(), $wig.find(".highchart").height(), false)
						}, 300);
					};
					saveWorkspaceData(current_workspace);
				}
			},
			draggable: {
				handle: ".widget-header, .widget-header i",
				stop: function() {
					saveWorkspaceData(current_workspace)
				}
			}
		}).data('gridster');

		/* build workspaces and widget library */
		populateWorkspaces();
		populateWidgetLibrary();

		/* resize gridster columns and highchart graphs */
		$(window).on("resize", responsiveGridster);

		/* workspace menu */
		$(window).on("resize", showWorkspaceList);
		$(".workspace-menu-toggle > a").on("click", toggleWorkspaceMenu);

		/* ANZ Live Widget IE8 Fix */
		ie8Fix();
		$(window).on("resize", ie8Fix);

		/* widget library */
		$(window).on("resize", toggleWidgetScrollers);
		$(".toggle-widget-panel").on("click", toggleWorkspaceLibrary);
		$("a[data-action='browse-widgets']").on("mousedown.browse-widgets", function() {
			var scrlDirection = $(this).parent().hasClass("widget-move-left") ? "left" : "right";
			if (scrlDirection == "left") {
				scrollWidgetsLeft()
			} else {
				scrollWidgetsRight()
			}
		});
		$("a[data-action='browse-widgets']").on("mouseup.browse-widgets", stopWidgetScrolling);

		/* dialog bindings */
		$(".show-workspace-manager").on("click", showWorkspaceManagerDialog);

		/* set initial Highcharts options */
		Highcharts.setOptions({
			chart: {
				style: {
					fontFamily: 'Myriad Pro, Helvetica, Arial, sans-serif'
				}
			}
		});

	} else {

		populateWorkspaces();

	}

});