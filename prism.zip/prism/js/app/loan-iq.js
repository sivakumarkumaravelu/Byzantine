/**********************************************************************
LOANS GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [{
	id: "dealid",
	name: "Deal ID",
	field: "dealid",
	toolTip: "Click to sort by Deal ID. Right-Click to hide or show",
	width: 140,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "dealname",
	name: "Deal Name",
	field: "dealname",
	toolTip: "Click to sort by Deal name. Right-Click to hide or show",
	width: 260,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "facilityname",
	name: "Facility Name",
	field: "facilityname",
	toolTip: "Click to sort by Facility Name. Right-Click to hide or show",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "currency",
	name: "Currency",
	field: "currency",
	toolTip: "Click to sort by Currency. Right-Click to hide or show",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "limit",
	name: "Current Limit",
	field: "limit",
	toolTip: "Click to sort by Limit. Right-Click to hide or show",
	width: 200,
	sortable: true,
	visible: true,
	cssClass: "num pos",
	headerCssClass: "righted",
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	groupTotalsFormatter: sumTotalsFormatter
}, {
	id: "drawn",
	name: "Drawn Amount",
	field: "drawn",
	toolTip: "Click to sort by Drawn. Right-Click to hide or show",
	width: 200,
	sortable: true,
	visible: true,
	cssClass: "num pos",
	headerCssClass: "righted",
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	groupTotalsFormatter: sumTotalsFormatter
}, {
	id: "undrwarn",
	name: "Undrawn Amount",
	field: "undrwarn",
	toolTip: "Click to sort by Undrawn Amount. Right-Click to hide or show",
	width: 200,
	sortable: true,
	visible: true,
	cssClass: "num pos",
	headerCssClass: "righted",
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	groupTotalsFormatter: sumTotalsFormatter
}, {
	id: "noofdrawings",
	name: "Number Of Loans",
	field: "noofdrawings",
	toolTip: "Click to sort by Number Of Loans. Right-Click to hide or show",
	width: 160,
	sortable: true,
	cssClass: "num",
	sorter: "sorterNumeric",
	headerCssClass: "righted",
	visible: true
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('loansColumnOrder')) {
	columns = store.get('loansColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "limit" || columns[i].id == "drawn" || columns[i].id == "undrwarn") {
			columns[i].formatter = Slick.Formatters.AmountFormatter
			columns[i].groupTotalsFormatter = sumTotalsFormatter
		}
	}
}
if (store.get('loansColumnWidths')) {
	var setWidth = store.get('loansColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var groupedSetting = 0;
var	groupCollapseSetting = 0;
var	groupCCYSetting = "USD";
function sumTotalsFormatter(totals, columnDef) {
	return groupCCYSetting + " " + addCommas(Math.round((totals.sum[columnDef.field] * 100) / 100).toFixed(2));
}
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);

	dataView.setAggregators([
		new Slick.Data.Aggregators.Sum("limit"),
		new Slick.Data.Aggregators.Sum("drawn"),
		new Slick.Data.Aggregators.Sum("undrwarn")
	], true);

	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var labelString = "";
var	findString = "";
var	findDataPoint = "facilityname";
function myFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}

	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function calculateTotals() {
	var totalbalance = 0,
		totallimit = 0;
	for (var i = 0; i < dataView.getLength(); i++) {
		if (dataView.getItem(i).id) {
			//console.log(dataView.getItem(i));
			totalbalance = parseFloat(totalbalance) + parseFloat(dataView.getItem(i).undrwarn.replace(',', ''));
			totallimit = parseFloat(totallimit) + parseFloat(dataView.getItem(i).limit.replace(',', ''));
		}
	}
	totalbalance = addCommas(totalbalance.toFixed(2))
	$("[data-value='totalbalance']").html(totalbalance)
	totallimit = addCommas(totallimit.toFixed(2))
	$("[data-value='totallimit']").html(totallimit)
}
function filterAccounts() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	calculateTotals()
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
for (var i = 0; i < 3; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	d["label"] = "None";
	d["labelid"] = "None";
	d["dealid"] = "10788";
	d["currency"] = "AUD";
	d["fxrate"] = 0.91;
	if (i == 0) {
		d["dealname"] = "*MAHELKCIM UNIT ABC 3200000 20JUL2015";
		d["facilityname"] = "CASH ADVANCE";
		d["facilityid"] = "00000919";
		d["facilitystartdate"] = smartDates("randompast");
		d["facilityexpirtydate"] = smartDates("randomfuture");
		d["noofdrawings"] = 2;
		d["limit"] = parseInt(randNumber(5)).toFixed(2);
		d["undrwarn"] = parseInt(randNumber(5)).toFixed(2);
		d["drawn"] = parseInt(randNumber(5)).toFixed(2);
		d["unavailablefunds"] = parseInt(randNumber(5)).toFixed(2);
		d["availabletodraw"] = parseInt(randNumber(5)).toFixed(2);
	} else if (i == 1) {
		d["dealname"] = "*MAHELKCIM UNIT ABC 3200000 20JUL2015";
		d["facilityname"] = "TRANCHE 1";
		d["noofdrawings"] = 1;
		d["limit"] = parseInt(randNumber(5)).toFixed(2);
		d["undrwarn"] = parseInt(randNumber(5)).toFixed(2);
		d["drawn"] = parseInt(randNumber(5)).toFixed(2);
		d["unavailablefunds"] = parseInt(randNumber(5)).toFixed(2);
		d["availabletodraw"] = parseInt(randNumber(5)).toFixed(2);
	} else if (i == 2) {
		d["dealname"] = "*MAHELKCIM UNIT ABC 3200000 20JUL2015";
		d["facilityname"] = "FACILITY C";
		d["noofdrawings"] = 0;
		d["limit"] = parseInt(randNumber(5)).toFixed(2);
		d["undrwarn"] = parseInt(randNumber(5)).toFixed(2);
		d["drawn"] = parseInt(randNumber(5)).toFixed(2);
		d["unavailablefunds"] = parseInt(randNumber(5)).toFixed(2);
		d["availabletodraw"] = parseInt(randNumber(5)).toFixed(2);
	}
};



/**********************************************************************
LOAN SUMMARY GRID
**********************************************************************/
var loanSummary;
var loanSummaryGrid;
var loanData = [];
var loanColumnFilters = {};
var loanColumns = [{
		id: "loanborrowername",
		name: "Loan Borrower Name",
		field: "loanborrowername",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "loanname",
		name: "Loan Name",
		field: "loanname",
		width: 175,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "currency",
		name: "Currency",
		field: "currency",
		width: 175,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "loanstartdate",
		name: "Loan Start Date",
		field: "loanstartdate",
		width: 175,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "loanmaturitydate",
		name: "Loan Maturity Date",
		field: "loanmaturitydate",
		width: 175,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "loanamount",
		name: "Loan Amount",
		field: "loanamount",
		width: 175,
		sortable: true,
		sorter: "sorterNumeric",
		cssClass: "num pos",
		headerCssClass: "righted",
		formatter: Slick.Formatters.AmountFormatter,
		visible: true
	}, {
		id: "pricingoption",
		name: "Pricing Option",
		field: "pricingoption",
		width: 175,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "cyclestartdate",
		name: "Cycle Start Date",
		field: "cyclestartdate",
		width: 175,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "cycleenddate",
		name: "Cycle End Date",
		field: "cycleenddate",
		width: 175,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "duedate",
		name: "Due Date",
		field: "duedate",
		width: 175,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "interestdue",
		name: "Current Projected Interest Due",
		field: "interestdue",
		width: 175,
		sortable: true,
		sorter: "sorterNumeric",
		cssClass: "num pos",
		headerCssClass: "righted",
		formatter: Slick.Formatters.AmountFormatter,
		visible: true
	}, {
		id: "interestcycle",
		name: "Interest Cycle",
		field: "interestcycle",
		width: 175,
		sortable: true,
		orter: "sorterStringCompare",
		visible: true
	}, {
		id: "baserate",
		name: "Base Rate",
		field: "baserate",
		width: 175,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}, {
		id: "alluprate",
		name: "All Up Rate",
		field: "alluprate",
		width: 175,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}, {
		id: "repaymentschedule",
		name: "Repayment Schedule",
		field: "repaymentschedule",
		width: 175,
		sortable: true,
		orter: "sorterStringCompare",
		visible: false
	}, {
		id: "fxrate",
		name: "FX Rate",
		field: "fxrate",
		width: 175,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}, {
		id: "averagerate",
		name: "Weighted Average Rate",
		field: "averagerate",
		width: 175,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}];
var	loanOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('loanColumnOrder')) {
	loanColumns = store.get('loanColumnOrder');
	for (i = 0; i < loanColumns.length; i++) {
		if (loanColumns[i].id == "loanamount" || loanColumns[i].id == "interestdue") {
			loanColumns[i].formatter = Slick.Formatters.AmountFormatter
		}

	}
}
if (store.get('loanColumnWidths')) {
	var setBalanceWidth = store.get('loanColumnWidths');
	for (var i in setBalanceWidth) {
		var s = setBalanceWidth[i]
		for (c = 0; c < loanColumns.length; c++) {
			if (s.id == loanColumns[c].id) {
				loanColumns[c].width = s.width
			}
		}
	}
}
var labelString1 = "";
var	findString1 = "";
var	findDataPoint1 = "loanname";
function myLoanFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}

	if (args.findString != "" && item[findDataPoint1].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in loanColumnFilters) {
		if (columnId !== undefined && loanColumnFilters[columnId] !== "") {
			var c = loanSummaryGrid.getColumns()[loanSummaryGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = loanColumnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(loanColumnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function toggleLoanFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in loanColumnFilters) {
		loanColumnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		loanSummaryGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		loanSummaryGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	loanSummary.refresh();
}


/**********************************************************************
AMORTISATION GRID
**********************************************************************/
var amortisationDataView;
var amortisationGrid;
var amortisationData = [];
var amortisationSelectedRowIds = [];
var amortisationColumnFilters = {};
var amortisationColumns = [{
		id: "item",
		name: "Item",
		field: "item",
		sortable: true,
		sorter: "sorterNumeric",
		width: 100
	}, {
		id: "amount",
		name: "Amount",
		field: "amount",
		width: 110,
		cssClass: "num pos",
		headerCssClass: "righted",
		sortable: true,
		sorter: "sorterNumeric",
		formatter: Slick.Formatters.AmountFormatter
	}, {
		id: "duedate",
		name: "Due Date",
		field: "duedate",
		sortable: true,
		sorter: "sorterDateIso",
		width: 200
	}, {
		id: "remainingamount",
		name: "Remaining Amount",
		field: "remainingamount",
		cssClass: "num pos",
		headerCssClass: "righted",
		sortable: true,
		sorter: "sorterNumeric",
		formatter: Slick.Formatters.AmountFormatter,
		width: 200
	}];
var	amortisationOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('amortisationColumnOrder')) {
	amortisationColumns = store.get('amortisationColumnOrder');
	for (i = 0; i < amortisationColumns.length; i++) {
		if (amortisationColumns[i].id == "amount" || amortisationColumns[i].id == "remainingamount") {
			amortisationColumns[i].formatter = Slick.Formatters.AmountFormatter
		}
	}
}
if (store.get('amortisationColumnWidths')) {
	var setActivityWidth = store.get('amortisationColumnWidths');
	for (var i in setActivityWidth) {
		var s = setActivityWidth[i]
		for (c = 0; c < amortisationColumns.length; c++) {
			if (s.id == amortisationColumns[c].id) {
				amortisationColumns[c].width = s.width
			}
		}
	}
}
var labelString2 = "";
var	findString2 = "";
var	findDataPoint2 = "amount";
function myAmortisationFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}

	if (args.findString != "" && item[findDataPoint2].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in amortisationColumnFilters) {
		if (columnId !== undefined && amortisationColumnFilters[columnId] !== "") {
			var c = amortisationGrid.getColumns()[amortisationGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = amortisationColumnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(amortisationColumnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
for (var i = 0; i < 13; i++) {
	var d = (amortisationData[i] = {});
	d["id"] = "id_" + i;
	d["item"] = i + 1;
	if (i == 0) {
		d["amount"] = parseInt(0).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2015, 6, 22));
		d["remainingamount"] = parseInt(36200000.00).toFixed(2);
	} else if (i == 1) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2015, 9, 22));
		d["remainingamount"] = parseInt(34200000.00).toFixed(2);
	} else if (i == 2) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2015, 12, 22));
		d["remainingamount"] = parseInt(32200000.00).toFixed(2);
	} else if (i == 3) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2016, 3, 22));
		d["remainingamount"] = parseInt(30200000.00).toFixed(2);
	} else if (i == 4) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2016, 6, 22));
		d["remainingamount"] = parseInt(28200000.00).toFixed(2);
	} else if (i == 5) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2016, 9, 22));
		d["remainingamount"] = parseInt(26200000.00).toFixed(2);
	} else if (i == 6) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2016, 12, 22));
		d["remainingamount"] = parseInt(24200000.00).toFixed(2);
	} else if (i == 7) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 3, 22));
		d["remainingamount"] = parseInt(22200000.00).toFixed(2);
	} else if (i == 8) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 6, 22));
		d["remainingamount"] = parseInt(20200000.00).toFixed(2);
	} else if (i == 9) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 9, 22));
		d["remainingamount"] = parseInt(18200000.00).toFixed(2);
	} else if (i == 10) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 12, 22));
		d["remainingamount"] = parseInt(16200000.00).toFixed(2);
	} else if (i == 11) {
		d["amount"] = parseInt(2000000).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2018, 3, 22));
		d["remainingamount"] = parseInt(14200000.00).toFixed(2);
	} else if (i == 12) {
		d["amount"] = parseInt(14200000.00).toFixed(2);
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2018, 6, 22));
		d["remainingamount"] = parseInt(0.00).toFixed(2);

	}
}
function toggleAmortisationFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in amortisationColumnFilters) {
		amortisationColumnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		amortisationGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		amortisationGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	amortisationDataView.refresh();
}


/**********************************************************************
PAST DUE GRID
**********************************************************************/
var pastDeuDataView;
var pastDueGrid;
var pastDueData = [];
var pastDueSelectedRowIds = [];
var pastDueColumnFilters = {};
var pastDueColumns = [{
		id: "item",
		name: "Applicable To",
		field: "item",
		sortable: true,
		sorter: "sorterStringCompare",
		width: 160
	}, {
		id: "reference",
		name: "Reference",
		field: "reference",
		width: 160,
		sortable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "duedate",
		name: "Due Date",
		field: "duedate",
		sortable: true,
		sorter: "sorterDateIso",
		width: 200
	}, {
		id: "remainingamount",
		name: "Total Past Due Amount",
		field: "remainingamount",
		cssClass: "num pos",
		headerCssClass: "righted",
		sortable: true,
		sorter: "sorterNumeric",
		formatter: Slick.Formatters.AmountFormatter,
		width: 200
	}];
var	pastDueOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('pastDueColumnOrder')) {
	pastDueColumns = store.get('pastDueColumnOrder');
	for (i = 0; i < pastDueColumns.length; i++) {
		if (pastDueColumns[i].id == "remainingamount") {
			pastDueColumns[i].formatter = Slick.Formatters.AmountFormatter
		}
	}
}
if (store.get('pastDueColumnWidths')) {
	var setActivity6Width = store.get('pastDueColumnWidths');
	for (var i in setActivity6Width) {
		var s = setActivity6Width[i]
		for (c = 0; c < pastDueColumns.length; c++) {
			if (s.id == pastDueColumns[c].id) {
				pastDueColumns[c].width = s.width
			}
		}
	}
}
var labelString3 = "";
var	findString3 = "";
var	findDataPoint3 = "item";
function myFilter3(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}

	if (args.findString != "" && item[findDataPoint3].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in pastDueColumnFilters) {
		if (columnId !== undefined && pastDueColumnFilters[columnId] !== "") {
			var c = pastDueGrid.getColumns()[pastDueGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = pastDueColumnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(pastDueColumnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
for (var i = 0; i < 5; i++) {
	var d = (pastDueData[i] = {});
	d["id"] = "id_" + i;
	if (i == 0) {
		d["item"] = "Fee";
		d["reference"] = "Commitment Fee";
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
		d["remainingamount"] = addCommas("150000.00");
	} else if (i == 1) {
		d["item"] = "Fee";
		d["reference"] = "Line Fee";
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
		d["remainingamount"] = addCommas("450000.00");

	} else if (i == 2) {
		d["item"] = "Fee";
		d["reference"] = "Undrawn Commitment Fee";
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 2, 23));
		d["remainingamount"] = addCommas("50000.00");

	} else if (i == 3) {
		d["item"] = "Interest";
		d["reference"] = "MAHELKCIM 0003";
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
		d["remainingamount"] = addCommas("100000.00");
	} else if (i == 4) {
		d["item"] = "Principal";
		d["reference"] = "MAHELKCIM 0001";
		d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 5, 23));
		d["remainingamount"] = addCommas("50000.00");
	}
}
function togglePastDueFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in pastDueColumnFilters) {
		pastDueColumnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		pastDueGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		pastDueGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	pastDeuDataView.refresh();
}

/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var user_loan_folders = [],
	folders_updated = false,
	folders_deleted = false;
$folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Loans</p><p style='font-size: 14px;'>Folders help you keep your loans organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move loans into a folder by selecting them in the loans grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-th-list fa-fw'></i> View Menu.</p></div>"),
	$folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if (store.get('loan_folders')) {
	user_loan_folders = store.get('loan_folders')
};
function folderFilter() {
	var rows = grid.getSelectedRows()
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	}
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	})
	filterAccounts()
}
function folderChecker(val) {
	var _folder = val,
		error = false,
		$folderList = $(".folder-list").children("li"),
		existingFolders = [];
	for (var i = 0; i < $folderList.length; i++) {
		existingFolders.push($folderList.eq(i).attr("data-folder"));
	}
	if ($.inArray(_folder, existingFolders) != -1) {
		error = "existing"
	}
	return error;
}
function renameFolder(el) {
	var newFolderName = $.trim(el.val());
	if (newFolderName == '' || newFolderName == "undefined") {
		el.val(el.attr("data-folder-name"));
	} else {
		el.val(newFolderName);
		el.closest("li").attr("data-folder", newFolderName);
		folders_updated = true;
	}
}
function addFolder() {
	var folderName = $.trim($("#newFolderInput").val()),
		$folderList = $("ul.folder-list"),
		$newFolderDiv = $("div.new-folder"),
		$li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
	if (folderName == '' || folderName == "undefined") {
		$("#newFolderInput").val('');
		return false;
	} else {
		if (folderCheck == "existing") {
			$newFolderDiv.addClass("error");
			$("#newFolderInput").focus().select().one("keyup.remove-error", function() {
				$newFolderDiv.removeClass("error");
			});
		} else {
			if ($newFolderDiv.hasClass("error")) {
				$newFolderDiv.removeClass("error");
			}
			if ($(".folder-message").size()) {
				$(".folder-message").remove();
				$folderListInstruction.insertBefore($folderList);
			}
			$li = $("<li data-folder='" + folderName + "' data-folder-id='" + randString() + "' class='row new' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' value='" + folderName + "' maxlength='25' data-folder-name='" + folderName + "' />").on("change", function() {
				renameFolder($(this));
			}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
			$("#newFolderInput").val('');
			$folderList.sortable("refresh");
			folders_updated = true;
		}
	}
}
function addFolderInline() {
	var folderName = $.trim($("#_inlineFolderInput").val()),
		folderExists = false;
	if (folderName == '' || folderName == "undefined") {
		$("#_inlineFolderInput").val('');
		return false;
	} else {
		for (var i = 0; i < user_loan_folders.length; i++) {
			if (folderName == user_loan_folders[i].name) {
				folderExists = true;
				break;
			}
		}
		if (folderExists) {
			alert("A folder with that name already exists.");
		} else {
			var _id = randString();
			var _new = {
				name: folderName,
				id: _id
			};
			user_loan_folders.push(_new);
			populateFolders();
			store.set('loan_folders', user_loan_folders);
			$("#_inlineFolderInput").val('');
			moveAccounts(_id);
		}
	}
}
function deleteFolder(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function() {
		if (!$target.hasClass('new')) {
			folders_deleted = true;
		}
		$target.remove();
		$(".folder-list").sortable("refresh");
		folders_updated = true;
		if (!$(".folder-list").children("li").size()) {
			$(".folder-list-instructions").remove();
			$folderMessage.appendTo(".folder-settings");
		}
		if ($("div.new-folder").hasClass("error")) {
			$("div.new-folder").removeClass("error");
		}
	});
}
function populateFolders() {
	var $assignFolders = $(".assign-folders"),
		folderCount = user_loan_folders.length,
		activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
	$assignFolders.children().remove();
	if ($("#removeFromFolder").size() > 0) {
		$("#removeFromFolder").remove();
	}
	if (folderCount > 0) {
		var $li, $a
		$assignFolders.each(function() {
			var _this = $(this);
			if (_this.parents().attr("id") == "folderMenu") {
				$.each(user_loan_folders, function() {
					$li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' />").appendTo(_this);
					$a = $("<a href='javascript:void(0)' title='" + this.name + "' data-folder='" + this.name + "' data-folder-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
						e.preventDefault();
						moveAccounts($(this).attr("data-folder-id"));
					}).appendTo($li);
				});
				var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
					$spacer = $("<li class='menu-section' />").appendTo($ul),
					$li = $("<li />").appendTo($ul),
					$a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected loans from folders' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
						e.preventDefault();
						moveAccounts($(this).attr("data-folder-id"));
					}).appendTo($li),
					$spacer = $("<li class='menu-section' />").appendTo($ul);
			} else if (_this.parents().attr("id") == "viewMenu") {
				$.each(user_loan_folders, function() {
					$li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' />").appendTo(_this);
					if (this.id == activeFolder) {
						$li.addClass("active");
						$("#viewMenuControl").children("a").children("span").html(this.name);
					}
					$a = $("<a href='javascript:void(0)' title='" + this.name + "' data-folder='" + this.name + "' data-folder-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
						e.preventDefault();
						var _folderID = $(this).attr("data-folder-id"),
							_folderName = $(this).attr("data-folder");
						if (labelString != _folderID) {
							labelString = _folderID;
						}
						folderFilter();
						$("#selectedFolder").html(_folderName);
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
			$li = $("<li class='no-set' />").appendTo($viewMenu),
			$a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Folders</div>Folders help keep your data organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
	}
}
function populateFolderManager() {
	folders_updated = false;
	folders_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
		$folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
		$folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
		$folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e) {
			if (e.keyCode == 13) {
				addFolder()
			}
		}).appendTo($folderAddDiv),
		$folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
		$folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
		$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({
			handle: '.reorder-folder',
			axis: 'y',
			tolerance: "pointer",
			update: function(event, ui) {
				folders_updated = true
			}
		}),
		folderCount = user_loan_folders.length,
		$li, $div, $span, $input, $a, $error;
	if (folderCount > 0) {
		$folderListInstruction.insertBefore($folderList);
		$.each(user_loan_folders, function() {
			$li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='" + this.name + "' data-folder-name='" + this.name + "' />").on("change", function() {
				renameFolder($(this));
			}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
		});
	} else {
		$folderMessage.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showFolderManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Loans Folders",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function() {
			return populateFolderManager()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateFolders(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveFolders(dialog) {
	var $dialog = $("#" + dialog.id),
		$active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
	$dialog.addClass("working");
	user_loan_folders = folders_updated;

	var active_deleted = true;

	for (f = 0; f < user_loan_folders.length; f++) {
		if ($active == user_loan_folders[f].id) {
			active_deleted = false;
			break;
		}
	}

	for (var i = 0; i < data.length; i++) {
		var _resetFolder = true;
		for (var n = 0; n < user_loan_folders.length; n++) {
			if (data[i].labelid == user_loan_folders[n].id) {
				data[i].label = user_loan_folders[n].name;
				_resetFolder = false;
				break;
			}
		}
		if (_resetFolder) {
			data[i].label = "None";
			data[i].labelid = "None";
		}

	}
	folders_updated = false;
	folders_deleted = false;
	store.set('loan_folders', user_loan_folders);
	setTimeout(function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateFolders();
		if (!user_loan_folders.length || active_deleted) {
			$("#_allAccounts").trigger("click");
		}
		dialogHider(dialog);
	}, 300);
}
function updateFolders(dialog) {
	if (folders_updated) {
		folders_updated = [];
		var duplicate_names = false,
			$folderList = $(".folder-list");
		$folderList.find("li.error").removeClass("error");
		$folderList.children("li").each(function() {
			folders_updated.push({
				"name": $(this).attr("data-folder"),
				"id": $(this).attr("data-folder-id")
			});
			var _name = $(this).attr("data-folder");
			$(this).siblings().each(function() {
				if ($(this).attr("data-folder") == _name) {
					$(this).addClass("error");
				}
			});
		});
		if ($folderList.find("li.error").size()) {
			duplicate_names = true;
		}
		if (duplicate_names) {
			return false;
		} else {
			var save_folders = false;
			if (user_loan_folders.length != folders_updated.length) {
				save_folders = true;
			} else {
				for (var i = 0; i < user_loan_folders.length; i++) {
					if (user_loan_folders[i].name != folders_updated[i].name || user_loan_folders[i].id != folders_updated[i].id) {
						save_folders = true;
						break;
					}
				}
			}
			if (save_folders || folders_deleted) {
				if (folders_deleted) {
					buildConfirmDialog("You've removed some existing folders.", "Are you sure you want to continue?", function() {
						saveFolders(dialog)
					});
				} else {
					saveFolders(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}
function moveAccounts(_id) {
	var _folder, _message, _rowsForUpdate = [],
		_sel = selectedRowIds.length;
	for (var i = 0; i < user_loan_folders.length; i++) {
		if (user_loan_folders[i].id == _id) {
			_folder = user_loan_folders[i];
			_message = "Selected loans were moved to &quot;" + _folder.name + "&quot;";
			break;
		}
	}
	if (_id == "None") {
		_folder = [{
			name: "None",
			id: "None"
		}];
		_message = "Selected loans were removed from their folders";
	}
	for (var i = 0, l = _sel; i < l; i++) {
		var _item = selectedRowIds[i];
		if (_item) {
			_rowsForUpdate.unshift(_item);
		}
	}
	for (var i = 0; i < _rowsForUpdate.length; i++) {
		data[dataView.getIdxById(_rowsForUpdate[i])].label = _folder.name;
		data[dataView.getIdxById(_rowsForUpdate[i])].labelid = _folder.id;
	}
	grid.setSelectedRows(0);
	selectedRowIds = [];
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
	buildNotification(_message, 300, 3000);
	$("#viewMenu .assign-folders").find("a[data-folder-id='" + _folder.id + "']").trigger("click");
}


/**********************************************************************
BUILD DOWNLOAD DIALOG
**********************************************************************/
function downloadFormRules(el) {

	/* check if any form element has been passed */

	if (el) {
		/* if an element exists execute the correct action */

		var _id = el.attr("id");

		if (_id == "downloadType1") {
			$("#reportSelection, #reportType, #reportFormat").show();
			$("#gridExportSection, #exportType, #exportFormat").hide();
			if (!$("#reportTypeSelect").val()) {
				$("#reportTypeSelect").trigger("change")
			} else {
				$("#reportOptions").show();
				if ($("#reportTypeSelect").val() == "account-statement") {
					$("#statementHeader").show();
					if ($("#formatTypeSelect").val() == "PDF" || $("#formatTypeSelect").val() == "XLS") {
						$("#groupOption").show();
					}

				}
			}
		}

		if (_id == "downloadType2") {
			$("#reportSelection, #exportType, #exportFormat").show();
			$("#gridExportSection, #reportType, #reportFormat, #groupOption").hide();
			if (!$("#exportTypeSelect").val()) {
				$("#exportTypeSelect").trigger("change")
			}
		}

		if (_id == "downloadType3") {
			$("#gridExportSection").show();
			$("#reportSelection, #reportOptions").hide();
		}

		if (_id == "reportTypeSelect") {
			$("#formatTypeSelect").val("").trigger("change");
			if ($("#reportTypeSelect").val()) {
				$("#reportFormat").removeClass("disabled");
				$("#formatTypeSelect").removeClass("disabled").attr("disabled", false);
				$("#reportOptions").show();
				if ($("#reportTypeSelect").val() == "account-statement") {
					$("#statementHeader").show();
				} else {
					$("#statementHeader").hide();
				}
			} else {
				$("#reportFormat").addClass("disabled");
				$("#formatTypeSelect").addClass("disabled").attr("disabled", "disabled");
				$("#reportOptions").hide();
			}
		}

		if (_id == "formatTypeSelect") {
			if ($("#formatTypeSelect").val() == "PDF" || $("#formatTypeSelect").val() == "XLS") {
				if ($("#reportTypeSelect").val() == "account-statement") {
					$("#groupOption").slideDown("fast");
				} else {
					$("#groupOption").slideUp("fast");
				}
			} else {
				$("#groupOption").slideUp("fast");
			}
		}

		if (_id == "exportTypeSelect") {
			$("#exportFormatSelect").val("").trigger;
			if ($("#exportTypeSelect").val()) {
				$("#exportFormat").removeClass("disabled");
				$("#exportFormatSelect").removeClass("disabled").attr("disabled", false);
				$("#reportOptions").show();
				$("#statementHeader").hide();
			} else {
				$("#exportFormat").addClass("disabled");
				$("#exportFormatSelect").addClass("disabled").attr("disabled", "disabled");
				$("#reportOptions").hide();
			}
		}



	} else {
		/* if no element is passed setup the default form */

		/* check if any records have been selected in the grid */
		if (selectedRowIds.length) {
			$("#downloadType1").prop("checked", true).trigger("click");
			$("#gridExportSection, #exportType, #exportFormat, #reportOptions").hide();
		} else {
			$("#downloadType3").prop("checked", true); /*.prevAll().addClass("disabled").attr("disabled","disabled");*/
			$("#gridExportSection").show();
			$("#reportSelection, #reportOptions").hide();
		}
	}
}
var downloadFormDefinition = {
	name: "_downloadForm",
	id: "downloadForm",
	cssClass: false,
	method: "downloadFormRules()",
	sections: [{
		heading: "What type of download you want?",
		id: "downloadType",
		rows: [{
			id: "downloadOptions",
			mandatory: true,
			label: false,
			dataColumnAttributes: [{
				name: "style",
				value: "width: 100%;"
			}],
			elements: [{
				id: "downloadType1",
				type: "radio",
				name: "_downloadType",
				description: "Formatted Report",
				value: "Formatted Report",
				events: [{
					event: "click",
					action: function(e) {
						return downloadFormRules($(e.target))
					}
				}]
			}, {
				id: "downloadType2",
				type: "radio",
				name: "_downloadType",
				description: "Data Export",
				value: "Data Export",
				events: [{
					event: "click",
					action: function(e) {
						return downloadFormRules($(e.target))
					}
				}]
			}, {
				id: "downloadType3",
				type: "radio",
				name: "_downloadType",
				description: "Grid Export",
				value: "Grid Export",
				attributes: [{
					name: "checked",
					value: "checked"
				}],
				events: [{
					event: "click",
					action: function(e) {
						return downloadFormRules($(e.target))
					}
				}]
			}]
		}]
	}, {
		heading: false,
		id: "gridExportSection",
		rows: [{
			id: "gridExportSectionRow",
			mandatory: false,
			label: false,
			dataColumnAttributes: [{
				name: "style",
				value: "width: 100%;"
			}],
			elements: [{
				id: "gridExportSectionText",
				type: "note",
				value: "Exports the contents of the grid to a CSV file."
			}]
		}]
	}, {
		heading: "Enter details for your download",
		id: "reportSelection",
		rows: [{
			id: "reportType",
			mandatory: true,
			label: "Report Type",
			elements: [{
				id: "reportTypeSelect",
				type: "select",
				name: "_reportTypeSelect",
				description: false,
				data: [{
					option: "",
					value: ""
				}, {
					option: "Account Statement",
					value: "account-statement"
				}, {
					option: "Account Summary",
					value: "account-summary"
				}, {
					option: "Balance Summary",
					value: "balance-summary"
				}, {
					option: "Returned Items",
					value: "returned-items"
				}, {
					option: "Transaction Details",
					value: "transaction-details"
				}],
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}],
				events: [{
					event: "change",
					action: function(e) {
						return downloadFormRules($(e.target))
					}
				}]
			}]
		}, {
			id: "reportFormat",
			mandatory: true,
			label: "Report Format",
			elements: [{
				id: "formatTypeSelect",
				type: "select",
				name: "_formatTypeSelect",
				description: false,
				data: [{
					option: "",
					value: ""
				}, {
					option: "PDF",
					value: "PDF"
				}, {
					option: "XLS",
					value: "XLS"
				}],
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}],
				events: [{
					event: "change",
					action: function(e) {
						return downloadFormRules($(e.target))
					}
				}]
			}]
		}, {
			id: "exportType",
			mandatory: true,
			label: "Export Type",
			elements: [{
				id: "exportTypeSelect",
				type: "select",
				name: "_exportTypeSelect",
				description: false,
				data: [{
					option: "",
					value: ""
				}, {
					option: "Account Statement",
					value: "account-statement"
				}, {
					option: "Account Summary",
					value: "account-summary"
				}, {
					option: "Balance Summary",
					value: "balance-summary"
				}, {
					option: "Returned Items",
					value: "returned-items"
				}, {
					option: "Transaction Details",
					value: "transaction-details"
				}],
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}],
				events: [{
					event: "change",
					action: function(e) {
						return downloadFormRules($(e.target))
					}
				}]
			}]
		}, {
			id: "exportFormat",
			mandatory: true,
			label: "Export Format",
			elements: [{
				id: "exportFormatSelect",
				type: "select",
				name: "_exportFormatSelect",
				description: false,
				data: [{
					option: "",
					value: ""
				}, {
					option: "BAI2",
					value: "BAI2"
				}, {
					option: "CSV",
					value: "CSV"
				}, {
					option: "Multicash",
					value: "Multicash"
				}, {
					option: "NZ Statment",
					value: "NZ Statment"
				}, {
					option: "Statement File",
					value: "Statement File"
				}, {
					option: "Returned Items File",
					value: "Returned Items File"
				}],
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}]
			}]
		}, {
			id: "groupOption",
			mandatory: false,
			label: "&nbsp;",
			attributes: [{
				name: "style",
				value: "display:none;"
			}],
			elements: [{
				id: "groupTransactions",
				type: "checkbox",
				name: "_groupTransactions",
				description: "Group Transactions",
				value: "Group Transactions"
			}, {
				id: "groupNote",
				type: "note",
				value: "When 'Group Transactions' is checked, the transactions for each day will be grouped by debit/credit amount and transaction type.",
				attributes: [{
					name: "style",
					value: "max-width: 315px;"
				}]
			}]
		}, {
			id: "reporName",
			mandatory: true,
			label: "Name",
			elements: [{
				id: "reportNameInput",
				type: "input",
				name: "_reportNameInput",
				description: false,
				placeholder: "",
				value: "",
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}]
			}]
		}, {
			id: "reportDescription",
			mandatory: false,
			label: "Description",
			elements: [{
				id: "reportDescriptionInput",
				type: "input",
				name: "_reportDescriptionInput",
				description: false,
				placeholder: "",
				value: "",
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}]
			}]
		}]
	}, {
		heading: false,
		id: "reportOptions",
		rows: [{
			id: "reportDate",
			mandatory: true,
			label: "Date Range",
			elements: [{
				id: "reportDateSelect",
				type: "select",
				name: "_reportDateSelect",
				description: false,
				data: [{
					option: "",
					value: ""
				}, {
					option: "Today",
					value: smartDates("today")
				}, {
					option: "Yesterday",
					value: smartDates("yesterday")
				}, {
					option: "Week To Date",
					value: smartDates("weektodate")
				}, {
					option: "Last Week",
					value: smartDates("lastweek")
				}, {
					option: "Month To Date",
					value: smartDates("monthtodate")
				}, {
					option: "Last Month",
					value: smartDates("lastmonth")
				}, {
					option: "Specific Date",
					value: "sd"
				}, {
					option: "Date Range",
					value: "dr"
				}],
				attributes: [{
					name: "style",
					value: "width: 250px;"
				}],
				events: [{
					event: "change",
					value: downloadFormRules
				}]
			}, {
				id: "dateNote",
				type: "note",
				value: "",
				attributes: [{
					name: "style",
					value: "padding-top: 10px; padding-right: 90px;"
				}]
			}]
		}, {
			id: "statementHeader",
			mandatory: false,
			label: "Statement Header",
			attributes: [{
				name: "style",
				value: "display:none;"
			}],
			elements: [{
				id: "onePerDay",
				type: "radio",
				name: "_statementHeaderOptions",
				description: "One Per Day"
			}, {
				id: "onePerRange",
				type: "radio",
				name: "_statementHeaderOptions",
				description: "One Per Date Range"
			}]
		}]
	}]
}
function buildDownloadDialog() {
	var $wrapper = $("<div id='downloadDialogContent' />");
	formBuilder(downloadFormDefinition).appendTo($wrapper);
	return $wrapper;
}
function showDownloadDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "downloadDialog",
		title: "Download",
		size: "medium",
		icon: "<i class='fa fa-download'></i>",
		content: function() {
			return buildDownloadDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/**********************************************************************
REQUEST REPORTS
**********************************************************************/
function showAccountStatementModal(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	function dateRefresh() {
		var _date = $(this).val(),
			$dateNote = $(this).closest("div.data-column").find("div.data-note"),
			$row = $(this).closest("div.row");
		if (_date == "sd") {
			$("#statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='statementSpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true
			}).appendTo($dateNote).focus();
		} else if (_date == "dr") {
			$("#statementSpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='statementFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='statementToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var statementeDatRange = $("#statementFromDate, #statementToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function(selectedDate) {
					var option = this.id == "statementFromDate" ? "minDate" : "maxDate",
						instance = $(this).data("datepicker"),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings);
					statementeDatRange.not(this).datepicker("option", option, date);
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#statementSpecificDate, #statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty().html($(this).val());
		}
	};

	var formElements = [{
			name: "Report Format",
			id: "stmt-format",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "MT940",
				value: "MT940"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "File Name",
			id: "stmt-name",
			type: "input",
			max: 30
		}, {
			name: "Description",
			id: "stmt-desc",
			type: "input",
			max: 75
		}, {
			name: "Data From",
			id: "stmt-date",
			type: "select",
			data: [{
				option: "Today",
				value: smartDates("today")
			}, {
				option: "Yesterday",
				value: smartDates("yesterday")
			}, {
				option: "Week To Date",
				value: smartDates("weektodate")
			}, {
				option: "Last Week",
				value: smartDates("lastweek")
			}, {
				option: "Month To Date",
				value: smartDates("monthtodate")
			}, {
				option: "Last Month",
				value: smartDates("lastmonth")
			}, {
				option: "Specific Date",
				value: "sd"
			}, {
				option: "Date Range",
				value: "dr"
			}],
			events: [{
				event: "change",
				action: dateRefresh
			}],
			note: true,
			notevalue: smartDates("today")
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' />");
		}

		if (_type == "select") {
			$custom = $("<div class='custom-select' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestStatement",
		title: "Loan Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showBalanceHistoryModal(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report took more than 3 seconds to generate.", "It will be available for download in the &quot;Downloads&quot; section shortly.", "");
		}, 3000);
	};

	function dateRefresh() {
		var _date = $(this).val(),
			$dateNote = $(this).parent("div.data-column").find("div.data-text"),
			$row = $(this).closest("div.row");
		if (_date == "sd") {
			$("#summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='summarySpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true
			}).appendTo($dateNote).focus();
		} else if (_date == "dr") {
			$("#summarySpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='summaryFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='summaryToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var summaryDateRange = $("#summaryFromDate, #summaryToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function(selectedDate) {
					var option = this.id == "summaryFromDate" ? "minDate" : "maxDate",
						instance = $(this).data("datepicker"),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings);
					summaryDateRange.not(this).datepicker("option", option, date);
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#summarySpecificDate, #summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty().html($(this).val());
		}
		$row.add("focused");
	};
	var formElements = [{
			name: "Report Format",
			id: "bal-format",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "MT940",
				value: "MT940"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "File Name",
			id: "bal-name",
			type: "input",
			max: 30
		}, {
			name: "Description",
			id: "bal-desc",
			type: "input",
			max: 75
		}, {
			name: "Data From",
			id: "bal-date",
			type: "select",
			data: [{
				option: "Today",
				value: smartDates("today")
			}, {
				option: "Yesterday",
				value: smartDates("yesterday")
			}, {
				option: "Week To Date",
				value: smartDates("weektodate")
			}, {
				option: "Last Week",
				value: smartDates("lastweek")
			}, {
				option: "Month To Date",
				value: smartDates("monthtodate")
			}, {
				option: "Last Month",
				value: smartDates("lastmonth")
			}, {
				option: "Specific Date",
				value: "sd"
			}, {
				option: "Date Range",
				value: "dr"
			}],
			events: [{
				event: "change",
				action: dateRefresh
			}],
			note: true,
			notevalue: smartDates("today")
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function() {
				$(this).addClass("focused")
			}).on("focusout", function() {
				$(this).removeClass("focused")
			}).appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $note;
		if (formElements[i].type == "select") {
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
		} else if (formElements[i].type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' />");
		}
		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}
		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}
		$el.appendTo($data);
		if (formElements[i].note) {
			$note = $("<div class='data-text'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestBalances",
		title: "Ammortisation Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}


/**********************************************************************
SERVICE REQUEST WARNING
**********************************************************************/
function navigateToServiceRequests(e) {
	document.location.href = "service-requests-from-account.html#new";
}
function createServiceRequestWarning(e) {
	e.preventDefault();
	buildConfirmDialog("This will take you to the Service Requests Application to create a new account related service request.", "Do you want to proceed?", function() {
		navigateToServiceRequests(e)
	});
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE ACCOUNT SUMMARY GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#summaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, "loansColumnOrder", "loansColumnWidths", ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			if (rows.length > 1) {
				$cmenu = $("#multipleContextMenu")
			} else {
				$cmenu = $("#contextMenu")
			}
		};
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if (selectedRowIds.length > 0) {
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#selectedCount").html('');
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
		var data = dataView.getItem(row)
		var $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#accountDetail',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels');
			$("#facilitySummaryTab").trigger("click");
			$row.removeAttr("data-panel data-switch");
			grid.setSelectedRows(0);
			selectedRowIds = [];
			$('#facilityname').text("Facility " + data.facilityname);
			$('#dealname').text(data.dealname);
			$('#facilityid').text(data.facilityid);
			$('#facilitystartdate').text(data.facilitystartdate);
			$('#facilityexpirydate').text(data.facilityexpirtydate);
			$('#facilitycurrency').text(data.currency);
			$('#currentlimit').text(addCommas(data.limit));
			$('#drawnamount').text(addCommas(data.drawn));
			$('#noofloans').text(data.noofdrawings);
			$('#undrawnamount').text(addCommas(data.undrwarn));
			$('#availablefunds').text(addCommas(data.unavailablefunds));
			$('#availabletodraw').text(addCommas(data.availabletodraw));
			if (data.facilityname == "CASH ADVANCE") {
				$('.noloanschedule').css("display", "none");
				$('.noammortisation').css("display", "none");
				$('.nopastdueschedule').css("display", "none");
				var loanData = [];
				for (var i = 0; i < 4; i++) {
					var d = (loanData[i] = {});
					d["id"] = "id_" + i;
					if (i % 2 == 0) {
						d["loanborrowername"] = "MAHELKCIM UNIT";
						d["loanname"] = "MAHELKCIM 0002";
						d["currency"] = "AUD";
						d["loanstartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
						d["loanmaturitydate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 22));
						d["loanamount"] = parseInt(randNumber(5)).toFixed(2);
						d["pricingoption"] = "BBSY";
						d["cyclestartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
						d["cycleenddate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 22));
						d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 23));
						d["interestdue"] = parseInt(randNumber(5)).toFixed(2);
						d["interestcycle"] = "Monthly";
						d["baserate"] = parseFloat(3.40).toFixed(2);
						d["alluprate"] = parseFloat(3.55).toFixed(2);
						d["repaymentschedule"] = 1
						d["fxrate"] = "";
						d["averagerate"] = 1.2250;
					} else {
						d["loanborrowername"] = "MAHELKCIM UNIT VIC";
						d["loanname"] = "MAHELKCIM 0003";
						d["currency"] = "USD";
						d["loanstartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2016, 11, 22));
						d["loanmaturitydate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 5, 22));
						d["loanamount"] = parseInt(randNumber(5)).toFixed(2);
						d["pricingoption"] = "DBB1M";
						d["cyclestartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
						d["cycleenddate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 22));
						d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 23));
						d["interestdue"] = parseInt(randNumber(5)).toFixed(2);
						d["interestcycle"] = "Monthly";
						d["baserate"] = parseFloat(0.85).toFixed(2);
						d["alluprate"] = parseFloat(3.00).toFixed(2);
						d["repaymentschedule"] = 0;
						d["fxrate"] = 0.7300;
						d["averagerate"] = 1.2250;
					}
				}
				loanSummaryGrid.invalidateAllRows();
				loanSummary.setItems(loanData);
				loanSummaryGrid.render();
			} else if (data.facilityname == "TRANCHE 1") {
				$('.noloanschedule').css("display", "none");
				$('.noammortisation').css("display", "none");
				$('.nopastdueschedule').css("display", "none");
				var loanData = [];
				for (var i = 0; i < 4; i++) {
					var d = (loanData[i] = {});
					d["id"] = "id_" + i;
					if (i % 2 == 0) {
						d["loanborrowername"] = "MAHELKCIM UNIT";
						d["loanname"] = "MAHELKCIM 0002";
						d["currency"] = "AUD";
						d["loanstartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
						d["loanmaturitydate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 22));
						d["loanamount"] = parseInt(randNumber(5)).toFixed(2);
						d["pricingoption"] = "BBSY";
						d["cyclestartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
						d["cycleenddate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 22));
						d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 23));
						d["interestdue"] = parseInt(randNumber(5)).toFixed(2);
						d["interestcycle"] = "Monthly";
						d["baserate"] = "3.40%";
						d["alluprate"] = "3.55%";
						d["repaymentschedule"] = 1
						d["fxrate"] = "-";
						d["averagerate"] = "1.2250%";
					} else {
						d["loanborrowername"] = "MAHELKCIM UNIT VIC";
						d["loanname"] = "MAHELKCIM 0003";
						d["currency"] = "USD";
						d["loanstartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2016, 11, 22));
						d["loanmaturitydate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 5, 22));
						d["loanamount"] = parseInt(randNumber(5)).toFixed(2);
						d["pricingoption"] = "DBB1M";
						d["cyclestartdate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 0, 22));
						d["cycleenddate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 22));
						d["duedate"] = $.datepicker.formatDate('dd-mm-yy', new Date(2017, 1, 23));
						d["interestdue"] = parseInt(randNumber(5)).toFixed(2);
						d["interestcycle"] = "Monthly";
						d["baserate"] = "0.85%";
						d["alluprate"] = "3.00%";
						d["repaymentschedule"] = 0;
						d["fxrate"] = "0.7300";
						d["averagerate"] = "1.2250%";
					}
				}
				loanSummaryGrid.invalidateAllRows();
				loanSummary.setItems(loanData);
				loanSummaryGrid.render();
			} else if (data.facilityname == "FACILITY C") {
				$('.noloanschedule').css("display", "block");
				$('.noammortisation').css("display", "block");
				$('.nopastdueschedule').css("display", "block");
			}
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('loansColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('loansColumnOrder')) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('loansColumnOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleColumns);
	}
	grid.setHeaderRowVisibility(false);

	/**********************************************************************
	INITIALIZE Ammortisation SUMMARY GRID
	**********************************************************************/
	var amortisationGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	amortisationDataView = new Slick.Data.DataView({
		groupItemMetadataProvider: amortisationGroupItemMetadataProvider
	});
	amortisationGrid = new Slick.Grid("#ammortisationGrid", amortisationDataView, amortisationColumns, amortisationOptions);
	amortisationGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	amortisationGrid.registerPlugin(amortisationGroupItemMetadataProvider);
	amortisationGrid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		var rows = amortisationGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = amortisationDataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if (selectedRowIds.length > 0) {
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#selectedCount").html('');
		}
	});
	var amortisationcolumnpicker = new Slick.Controls.ColumnPicker(amortisationColumns, amortisationGrid, amortisationOptions, "amortisationColumnOrder", "amortisationColumnWidths", []);
	amortisationGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		amortisationDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	amortisationGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('amortisationColumnWidths', amortisationGrid.getColumns());
	});
	$(amortisationGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			amortisationColumnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			amortisationDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	amortisationGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(amortisationColumnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	amortisationDataView.onRowCountChanged.subscribe(function(e, args) {
		amortisationGrid.updateRowCount();
		amortisationGrid.render();
	});
	amortisationDataView.onRowsChanged.subscribe(function(e, args) {
		amortisationGrid.invalidateRows(args.rows);
		amortisationGrid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = amortisationDataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			amortisationGrid.setSelectedRows(selRows);
		}
	});
	amortisationDataView.setItems(amortisationData);
	amortisationDataView.setFilterArgs({
		labelString: labelString2,
		findString: findString2
	});
	amortisationDataView.syncGridSelection(amortisationGrid, true, false);
	amortisationDataView.syncGridCellCssStyles(amortisationGrid, "contextMenu");
	amortisationDataView.setFilter(myAmortisationFilter);
	amortisationGrid.setColumns(amortisationColumns);
	if (store.get('amortisationColumnOrder')) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('amortisationColumnOrder').length; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		amortisationGrid.setColumns(visibleColumns);
	}
	amortisationGrid.setHeaderRowVisibility(false);


	/**********************************************************************
	INITIALIZE Past Due SUMMARY GRID
	**********************************************************************/
	var pastDueGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	pastDeuDataView = new Slick.Data.DataView({
		groupItemMetadataProvider: pastDueGroupItemMetadataProvider
	});
	pastDueGrid = new Slick.Grid("#pastdueGrid", pastDeuDataView, pastDueColumns, pastDueOptions);
	pastDueGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	pastDueGrid.registerPlugin(pastDueGroupItemMetadataProvider);
	var pastduecolumnpicker = new Slick.Controls.ColumnPicker(pastDueColumns, pastDueGrid, pastDueOptions, "pastDueColumnOrder", "pastDueColumnWidths", []);
	pastDueGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		pastDeuDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	pastDueGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('pastDueColumnWidths', pastDueGrid.getColumns());
	});
	$(pastDueGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			pastDueColumnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			pastDeuDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	pastDueGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(pastDueColumnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	pastDeuDataView.onRowCountChanged.subscribe(function(e, args) {
		pastDueGrid.updateRowCount();
		pastDueGrid.render();
	});
	pastDeuDataView.onRowsChanged.subscribe(function(e, args) {
		pastDueGrid.invalidateRows(args.rows);
		pastDueGrid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = amortisationDataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			pastDueGrid.setSelectedRows(selRows);
		}
	});
	pastDeuDataView.setItems(pastDueData);
	pastDeuDataView.setFilterArgs({
		labelString: labelString3,
		findString: findString3
	});
	pastDeuDataView.syncGridSelection(pastDueGrid, true, false);
	pastDeuDataView.syncGridCellCssStyles(pastDueGrid, "contextMenu");
	pastDeuDataView.setFilter(myFilter3);
	pastDueGrid.setColumns(pastDueColumns);
	if (store.get('pastDueColumnOrder')) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('pastDueColumnOrder').length; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		pastDueGrid.setColumns(visibleColumns);
	}
	pastDueGrid.setHeaderRowVisibility(false);

	/**********************************************************************
	CALCULATE GRAND TOTALS
	**********************************************************************/
	calculateTotals()


	/**********************************************************************
	INITIALIZE LOAN SUMMARY GRID
	**********************************************************************/
	var loanSummaryItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	loanSummary = new Slick.Data.DataView({
		loanSummaryItemMetaProvider: loanSummaryItemMetaProvider
	});
	loanSummaryGrid = new Slick.Grid("#balanceGrid", loanSummary, loanColumns, loanOptions);
	loanSummaryGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	loanSummaryGrid.registerPlugin(loanSummaryItemMetaProvider);
	var balancehistorycolumnpicker = new Slick.Controls.ColumnPicker(loanColumns, loanSummaryGrid, loanOptions, "loanColumnOrder", "loanColumnWidths", []);
	loanSummaryGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		loanSummary.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	handleClick = function(e, args) {
		if (loanSummaryGrid.getColumns()[args.cell].id === 'repaymentschedule') {
			viewRepaymentTrigger(e);
			e.stopPropagation();
			e.stopImmediatePropagation();
		}
	}
	loanSummaryGrid.onClick.subscribe(handleClick);
	loanSummaryGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('loanColumnWidths', loanSummaryGrid.getColumns());
	});
	$(loanSummaryGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			loanColumnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			loanSummary.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	loanSummaryGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(loanColumnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	loanSummary.onRowCountChanged.subscribe(function(e, args) {
		loanSummaryGrid.updateRowCount();
		loanSummaryGrid.render();
	});
	loanSummary.onRowsChanged.subscribe(function(e, args) {
		loanSummaryGrid.invalidateRows(args.rows);
		loanSummaryGrid.render();
	});
	loanSummary.setItems(loanData);
	loanSummary.setFilterArgs({
		labelString: labelString1,
		findString: findString1
	});
	loanSummary.syncGridSelection(loanSummaryGrid, true, false);
	loanSummary.syncGridCellCssStyles(loanSummaryGrid, "contextMenu");
	loanSummary.setFilter(myLoanFilter);
	loanSummaryGrid.setColumns(loanColumns);
	if (store.get('loanColumnOrder')) {
		var visibleLoanSummaryColumns = [];
		for (var i = 0; i < store.get('loanColumnOrder').length; i++) {
			if (loanColumns[i].visible) {
				visibleLoanSummaryColumns.push(loanColumns[i])
			}
		}
		loanSummaryGrid.setColumns(visibleLoanSummaryColumns);
	}
	loanSummaryGrid.setHeaderRowVisibility(false);

	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
		loanSummaryGrid.resizeCanvas();
		amortisationGrid.resizeCanvas();
		pastDueGrid.resizeCanvas();
	});

	function viewRepaymentTrigger(e) {
		function showTransactionDetails() {
			var $transactionDetails = $("<div class='py-ui' style='padding: 20px;' />");
			var	$facility = "<div class='grid-cell' style='width: 33%;'><div class='row'><div class='label-column'><label>Loan Name</label></div><div class='data-column'><div class='data-text'>MAHELKCIM 0002</div></div></div></div><div class='grid-cell' style='width: 33%;'><div class='row'><div class='label-column'><label>Loan Start Date</label></div><div class='data-column'><div class='data-text'>22-12-2016</div></div></div></div><div class='grid-cell' style='width: 33%;'><div class='row'><div class='label-column'><label>Loan Expiry Date</label></div><div class='data-column'><div class='data-text'>22-06-2017</div></div></div></div>";
			var	$table = '<table id="loaniqfeesummary" class="loans-data-table"><tbody><tr><th>Item</th><th>Payment Amount</th><th>Next Payment Date</th><th>Principal</th><th>Remaining Balance</th></tr><tr><td>1</td><td>0.00</td><td>22-12-2016</td><td>0.00</td><td>6,000,000.00</td></tr><tr><td>2</td><td>1,000,000.00</td><td>22-01-2017</td><td>1,000,000.00</td><td>5,000,000.00</td></tr><tr><td>3</td><td>1,000,000.00</td><td>22-02-2017</td><td>1,000,000.00</td><td>4,000,000.00</td></tr><tr><td>4</td><td>1,000,000.00</td><td>22-03-2017</td><td>1,000,000.00</td><td>3,000,000.00</td></tr><tr><td>5</td><td>1,000,000.00</td><td>22-04-2017</td><td>1,000,000.00</td><td>2,000,000.00</td></tr><tr><td>6</td><td>1,000,000.00</td><td>22-05-2017</td><td>1,000,000.00</td><td>1,000,000.00</td></tr><tr><td>7</td><td>1,000,000.00</td><td>22-06-2017</td><td>1,000,000.00</td><td>0.00</td></tr></table>';
			var	$grid = $("<div class='grid-layout'><div class='grid-row'><div class='grid-cell'><div class='box'><div class='box-header'>Loan</div><div class='box-content top-label'><div class='grid-row'>" + $facility + "</div></div></div></div></div><div class='grid-row'><div class='grid-cell'><div class='box'><div class='box-header'>Cycles</div><div class='box-content transparent no-row-padding'><div class='grid-row'><div class='grid-cell' style='width: 100%;'><div class='row'><div class='data-column full'>" + $table + "</div></div></div></div></div></div></div></div></div>").appendTo($transactionDetails);
			return $transactionDetails;
		}
		var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
		var _dialog = {
			id: "transactionDetails",
			title: "Repayment Summary",
			size: "xxl",
			icon: "<i class='fa fa-file-text'></i>",
			content: function() {
				return showTransactionDetails()
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	$('.viewFeeSummaryTrigger').on("click", function(e) {

		function showTransactionDetails() {
			var $transactionDetails = $("<div class='py-ui' style='padding: 20px;' />"),
				$facility = "<div class='grid-cell' style='width: 33%;'><div class='row'><div class='label-column'><label>Facility ID</label></div><div class='data-column'><div class='data-text'>00000919</div></div></div></div><div class='grid-cell' style='width: 33%;'><div class='row'><div class='label-column'><label>Facility Name</label></div><div class='data-column'><div class='data-text'>CASH ADVANCE</div></div></div></div><div class='grid-cell' style='width: 33%;'><div class='row'><div class='label-column'><label>Fee Type</label></div><div class='data-column'><div class='data-text'>Undrawn Commitment Fee</div></div></div></div>";
				$table = '<table id="loaniqfeesummaryd" class="loans-data-table"><tbody><tr><th>Cycle</th><th>Start Date</th><th>End Date</th><th>Cycle Due</th><th>Accrued to Date</th><th>Paid to Date</th></tr><tr><td>1</td><td>09-12-2015</td><td>09-03-2016</td><td>10-03-2016</td><td>912.36</td><td>912.36</td></tr><tr><td>2</td><td>11-03-2016</td><td>12-06-2016</td><td>13-06-2016</td><td>1,000.01</td><td>1,000.01</td></tr><tr><td>3</td><td>14-06-2016</td><td>14-09-2106</td><td>15-09-2106</td><td>950.01</td><td>950.01</td></tr><tr><td>4</td><td>16-09-2106</td><td>17-09-2016</td><td>18-09-2016</td><td>912.36</td><td>912.36</td></tr><tr><td>5</td><td>19-09-2016</td><td>19-12-2016</td><td>20-12-2016</td><td>959.26</td><td>959.26</td></tr><tr><td>6</td><td>21-12-2016</td><td>21-03-2017</td><td>22-03-2017</td><td>999.25</td><td>999.25</td></tr><tr><td>7</td><td>23-03-2017</td><td>22-06-2017</td><td>23-06-2017</td><td>300.01</td><td>0.00</td></tr><tr><td colspan=4><strong>Total</strong></td><td><strong>6,033.26</strong></td><td><strong>5,733.25</strong></td></tr></tbody></table>';
				$grid = $("<div class='grid-layout'><div class='grid-row'><div class='grid-cell'><div class='box'><div class='box-header'>Facility</div><div class='box-content top-label'><div class='grid-row'>" + $facility + "</div></div></div></div></div><div class='grid-row'><div class='grid-cell'><div class='box'><div class='box-header'>Cycles</div><div class='box-content transparent no-row-padding'><div class='grid-row'><div class='grid-cell' style='width: 100%;'><div class='row'><div class='data-column full'>" + $table + "</div></div></div></div></div></div></div></div></div>").appendTo($transactionDetails);
			return $transactionDetails;
		}

		var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);

		var _dialog = {
			id: "transactionDetails1",
			title: "Fee Summary Details",
			size: "xxl",
			icon: "<i class='fa fa-file-text'></i>",
			content: function() {
				return showTransactionDetails()
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	});

	/**********************************************************************
	FOLDER VIEW INTERACTIONS
	**********************************************************************/
	$("#_allAccounts").on("click", function(e) {
		e.preventDefault();
		var _folder = "";
		if (labelString != _folder) {
			labelString = _folder;
		}
		folderFilter();
		$("#selectedFolder").html("All")
	});
	$(".manage-folders").on("click", showFolderManagerDialog);
	$("#_inlineFolderButton").on("click", addFolderInline);
	$("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
		if (e.keyCode == 13) {
			addFolderInline();
		}
	});
	populateFolders();

	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$("body").on("click.trxngroup-by", "#trxnGroupBy [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		trxngroupByfee(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});


	/**********************************************************************
	CURRENCY INTERACTION
	**********************************************************************/
	function returnRate(a, b) {
		var rate;
		if (a == "AUD") {
			if (b == "AUD") {
				rate = 1.0000
			} else if (b == "SGD") {
				rate = 0.8222
			}
		} else if (a == "CNY") {
			if (b == "AUD") {
				rate = 5.9200
			} else if (b == "SGD") {
				rate = 4.8400
			}
		} else if (a == "EUR") {
			if (b == "AUD") {
				rate = 0.7502
			} else if (b == "SGD") {
				rate = 0.6100
			}
		} else if (a == "HKD") {
			if (b == "AUD") {
				rate = 7.4910
			} else if (b == "SGD") {
				rate = 6.1230
			}
		} else if (a == "IDR") {
			if (b == "AUD") {
				rate = 9426.0710
			} else if (b == "SGD") {
				rate = 7708.4500
			}
		} else if (a == "INR") {
			if (b == "AUD") {
				rate = 53.8600
			} else if (b == "SGD") {
				rate = 43.8700
			}
		} else if (a == "KRW") {
			if (b == "AUD") {
				rate = 1081.8300
			} else if (b == "SGD") {
				rate = 886.1722
			}
		} else if (a == "KHR") {
			if (b == "AUD") {
				rate = 3852.6700
			} else if (b == "SGD") {
				rate = 3164.1900
			}
		} else if (a == "MYR") {
			if (b == "AUD") {
				rate = 2.9201
			} else if (b == "SGD") {
				rate = 2.3902
			}
		} else if (a == "NZD") {
			if (b == "AUD") {
				rate = 1.2000
			} else if (b == "SGD") {
				rate = 0.9800
			}
		} else if (a == "SGD") {
			if (b == "AUD") {
				rate = 1.2222
			} else if (b == "SGD") {
				rate = 1.0000
			}
		} else if (a == "THB") {
			if (b == "AUD") {
				rate = 28.9100
			} else if (b == "SGD") {
				rate = 23.7100
			}
		} else if (a == "USD") {
			if (b == "AUD") {
				rate = 0.9600
			} else if (b == "SGD") {
				rate = 0.7900
			}
		} else if (a == "VND") {
			if (b == "AUD") {
				rate = 20208.5600
			} else if (b == "SGD") {
				rate = 16565.4300
			}
		};
		return (rate)
	}
	$("#ccyMenu").on("click.set-ccy", "a", function(e) {
		e.preventDefault();
		groupCCYSetting = $(this).attr("data-value");
		for (var i = 0; i < data.length; i++) {
			data[i].fxrate = returnRate(groupCCYSetting, data[i].currency).toFixed(2);
		}
		dataView.setItems(data)
		filterAccounts();
		$("#_totalsRow [data-value='totalccy']").html(groupCCYSetting);
	});


	/**********************************************************************
	ACTION MENU INTERACTION
	**********************************************************************/
	$("#actionMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#actionMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#actionMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#actionMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#actionMenuMultiSelected"
			});
		}
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-reportsMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		}
	});

	/**********************************************************************
	DOWNLOAD DIALOG
	**********************************************************************/
	$("[data-action='downloadDialog']").on("click", showDownloadDialog);



	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);
	$("#toggleLoanFilter").on("click", toggleLoanFilterRow);
	$("#toggleAmortisationFilter").on("click", toggleAmortisationFilterRow);
	$("#togglePastDueFilter").on("click", togglePastDueFilterRow);


	/**********************************************************************
	REQUEST REPORT MODALS
	**********************************************************************/
	$(".request-statement").on("click", showAccountStatementModal);
	$(".request-balances").on("click", showBalanceHistoryModal);

	/**********************************************************************
	CREATE NEW SERVICE REQUEST
	**********************************************************************/
	$(".new-service-request").on("click", createServiceRequestWarning);

	/**********************************************************************
	JUMP TO ACCOUNT DETAILS
	**********************************************************************/
	var b = document.location.href.split(".html")[1];

	if (b == "#detail") {
		$("#summaryGrid").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		$('#accountActivityTab').trigger('click');
		document.location.hash = '';
	}



});