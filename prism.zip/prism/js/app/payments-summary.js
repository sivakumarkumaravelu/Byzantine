/**********************************************************************
PAYMENT GRID
**********************************************************************/
var data = _tbos_payment_batches;
var dataView;
var grid;
var record = null;
var selectedRowIds = [];
var selectedRowStates = [];
var selectedRowWorkflows = [];
var columnFilters = {};
var columns = [{
	id: "name",
	name: "Beneficiary / Payment Name",
	field: "name",
	width: 250,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "status",
	name: "Status",
	field: "status",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "batchid",
	name: "Payment ID",
	field: "batchid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "totaldebitamount",
	name: "Debit Amount",
	field: "totaldebitamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "debitcurrency",
	name: "Debit Currency",
	field: "debitcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitcredit",
	name: "Debit / Credit",
	field: "debitcredit",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "debitaccountnumber",
	name: "Debit Account Number",
	field: "debitaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "paymentdate",
	name: "Value Date",
	field: "paymentdate",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "type",
	name: "Payment Type",
	field: "type",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitaccountname",
	name: "Debit Account Name",
	field: "debitaccountname",
	width: 220,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "totalpaymentamount",
	name: "Payment Amount",
	field: "totalpaymentamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "paymentcurrency",
	name: "Payment Currency",
	field: "paymentcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "rate",
	name: "Exchange Rate",
	field: "rate",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	cssClass: "num",
	headerCssClass: "righted",
	visible: false
}, {
	id: "beneficiaryaccountnumber",
	name: "Beneficiary Account",
	field: "beneficiaryaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiaryid",
	name: "Beneficiary ID",
	field: "beneficiaryid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiarybankid",
	name: "Beneficiary Bank ID",
	field: "beneficiarybankid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiarybankname",
	name: "Beneficiary Bank Name",
	field: "beneficiarybankname",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "createdby",
	name: "Created By",
	field: "createdby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false,
}, {
	id: "createdon",
	name: "Creation Date",
	field: "createdon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: false
}, {
	id: "lastmodifiedby",
	name: "Last Modified By",
	field: "lastmodifiedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "lastmodifiedon",
	name: "Last Modified Date",
	field: "lastmodifiedon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: false
}, {
	id: "lastapprovedby",
	name: "Last Approver",
	field: "lastapprovedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "numberofpayments",
	name: "No. of Instructions",
	field: "numberofpayments",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	cssClass: "num",
	headerCssClass: "righted",
	visible: true
}, {
	id: "filereference",
	name: "File",
	field: "filereference",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "contractid",
	name: "Contract ID",
	field: "contractid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "division",
	name: "Division",
	field: "division",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('paymentSummaryColumnOrder')) {
	columns = store.get('paymentSummaryColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if ( columns[i].id == "totaldebitamount" || columns[i].id == "totalpaymentamount") {
			columns[i].formatter = Slick.Formatters.AmountFormatter
		}
	}
} else {
	store.set('paymentSummaryColumnOrder', columns)
}
if (store.get('paymentSummaryColumnWidths')) {
	var setWidth = store.get('paymentSummaryColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var flagColumn = new Slick.FlagColumn();
columns.unshift(flagColumn.getColumnDefinition());
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());

var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var searchString = "", statusString = "", workflowString = "", userString = "", searchPoint = "debitaccountnumber";
function myFilter(item, args) {

	if (args.statusString != "" && args.statusString.toLowerCase().indexOf(item["status"].toLowerCase()) == -1) {
		return false;
	}

	if (args.workflowString != "" && item["workflow"].toLowerCase().indexOf(args.workflowString.toLowerCase()) == -1) {
		return false;
	}

	if (args.userString != "" && item["createdby"].toLowerCase().indexOf(args.userString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterPaymentSummaryGrid() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function quickFindPayments() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.refresh();
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
function paymentsViewFilter() {
	var rows = grid.getSelectedRows();
	folderString = "";
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	filterPaymentSummaryGrid();
}


/**********************************************************************
CONTEXT MENU
**********************************************************************/
function checkStatus(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
function checkWorkflow(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
var enableContextItem = function() {
	$(this).children("div.disabled").remove();
	$(this).children("a").show();
};
var disableContextItem = function() {
	if ($(this).children("div.disabled").size()) {
		$(this).children("div.disabled").remove();
	}
	var $a = $(this).children("a"),
		$div = $("<div class='disabled' />"),
		content = $a.html();
	$a.hide();
	$div.html(content).appendTo($(this));
};
function setupContextMenu(record) {
	var sel = selectedRowIds.length,
		$contextItems = $("[data-type='context-item']"),
		statusValue = "",
		workflowValue = "";
	if (record != null) {
		selectedRowStates.push(record.status);
		selectedRowWorkflows.push(record.workflow);
		sel = 1;
	}
	if (!sel) {
		$contextItems.each(disableContextItem);
	} else {
		statusValue = checkStatus(selectedRowStates, "");
		workflowValue = checkWorkflow(selectedRowWorkflows, "");
		if (sel == 1) {
			if (workflowValue == "New") {
				if (statusValue == "Draft" || statusValue == "Approver Rejected") {
					$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='template']").each(enableContextItem);
					$("[data-action='recall'], [data-action='rate'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				} else if (statusValue == "Pending Approval") {
					$("[data-action='view'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='delete'], [data-action='rate'], [data-action='submit'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				}
			} else if (workflowValue == "Approved") {
				if (statusValue == "Warehoused") {
					$("[data-action='view'], [data-action='copy'], [data-action='delete'], [data-action='template'], [data-action='stop']").each(enableContextItem);
					$("[data-action='edit'], [data-action='submit'], [data-action='rate'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='recall']").each(disableContextItem);
				} else if (statusValue == "Processing") {
					$("[data-action='view'], [data-action='copy'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='delete'], [data-action='rate'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				} else if (statusValue == "Checking Documents") {
					$("[data-action='view'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='copy'], [data-action='rate'], [data-action='delete'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				}
			} else if (workflowValue == "Needs Repair") {
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='template']").each(enableContextItem);
				$("[data-action='recall'], [data-action='approve'], [data-action='rate'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
			} else if (workflowValue == "Completed") {
				$("[data-action='copy'], [data-action='template']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='rate'], [data-action='delete'], [data-action='submit'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
			} else if (workflowValue == "Needs Rate") {
				$("[data-action='recall'], [data-action='rate'], [data-action='template'], [data-action='copy']").each(enableContextItem);
				$("[data-action='view'], [data-action='approve'], [data-action='reject'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);	
			}
		} else {
			if (statusValue == "Draft" || statusValue == "Approver Rejected" || statusValue == "Needs Repair") {
				$("[data-action='delete'], [data-action='submit']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='rate'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else if (statusValue == "Pending Approval") {
				$("[data-action='recall'], [data-action='approve'], [data-action='reject']").each(enableContextItem);
				$("[data-action='view'], [data-action='copy'], [data-action='rate'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else if (statusValue == "Warehoused") {
				$("[data-action='stop'], [data-action='copy'], [data-action='template']").each(enableContextItem);
				$("[data-action='view'], [data-action='rate'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='approve'], [data-action='reject'], [data-action='recall']").each(disableContextItem);
			} else if (!statusValue && (selectedRowStates.indexOf("Draft") > -1 || selectedRowStates.indexOf("Rejected") > -1 || selectedRowStates.indexOf("Needs Repair") > -1) && selectedRowStates.indexOf("Pending Approvel") == -1 && selectedRowStates.indexOf("Processing") == -1 && selectedRowStates.indexOf("Warehoused") == -1) {
				$("[data-action='delete'], [data-action='submit']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='rate'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else {
				$contextItems.each(disableContextItem);
			}
		}
	}
}


/**********************************************************************
RECALL PAYMENT
**********************************************************************/
function recallRecords() {
	$("#paymentsGrid").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#paymentsGrid").removeClass("working");
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#paymentsGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Draft";
		record.recalledby = "Test User";
		record.recalledon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment " + record.batchid + " has been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Draft";
			data[dataView.getIdxById(selectedRowIds[i])].recalledby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].recalledon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected payments have been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	}
}
function recallRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("Payment <strong>" + record.batchid + "</strong> will be recalled and returned to draft status.", "Do you want to continue?", function() {
			recallRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "payments" : "payment";
		buildConfirmDialog("The selected " + rtext + " will be recalled and returned to draft status.", "Do you want to continue?", function() {
			recallRecords();
		});
	}
}


/**********************************************************************
DELETE PAYMENT
**********************************************************************/
function deleteRecords() {
	var $shell = $(".shell");
	$shell.addClass("loading");
	var reloadPaymentGrid = function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		grid.setSelectedRows([]);
		if (record != null) {
			$("a[data-action='close']").trigger("click");
		}
		$shell.removeClass("loading");
		buildNotification(msg, 500, 5000);
	}
	if (record != null) {
		setTimeout(function() {
			var item = dataView.getItem(grid.getActiveCell().row);
			dataView.deleteItem(item.id)
			msg = "Payment " + record.batchid + " has been deleted.";
			reloadPaymentGrid();
		}, 1500);
	} else {
		setTimeout(function() {
			var rowsForDelete = [];
			for (var i = 0, l = selectedRowIds.length; i < l; i++) {
				var item = selectedRowIds[i];
				if (item) rowsForDelete.unshift(item)
			};
			for (var i = 0; i < rowsForDelete.length; i++) {
				dataView.deleteItem(rowsForDelete[i])
			};
			msg = "Selected payments have been deleted.";
			reloadPaymentGrid();			
		}, 1500);
	}
}
function deleteRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("Payment <strong>" + record.batchid + "</strong> will be deleted.", "Do you want to continue?", function() {
			deleteRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "payments" : "payment";
		buildConfirmDialog("The selected " + rtext + " will be deleted.", "Do you want to continue?", function() {
			deleteRecords();
		});
	}
}


/**********************************************************************
RECALL PAYMENT
**********************************************************************/
function submitRecords() {
	$("#paymentsGrid").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#paymentsGrid").removeClass("working");
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#paymentsGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Draft";
		record.recalledby = "Test User";
		record.recalledon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment " + record.batchid + " has been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Draft";
			data[dataView.getIdxById(selectedRowIds[i])].recalledby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].recalledon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected payments have been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	}
}
function submitRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("Payment <strong>" + record.batchid + "</strong> will be recalled and returned to draft status.", "Do you want to continue?", function() {
			submitRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "payments" : "payment";
		buildConfirmDialog("The selected " + rtext + " will be recalled and returned to draft status.", "Do you want to continue?", function() {
			submitRecords();
		});
	}
}


/**********************************************************************
STOP PAYMENT
**********************************************************************/
function stopRecords() {
	$("#paymentsGrid").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#paymentsGrid").removeClass("working");
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#paymentsGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Draft";
		record.recalledby = "Test User";
		record.recalledon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment " + record.batchid + " has been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Draft";
			data[dataView.getIdxById(selectedRowIds[i])].recalledby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].recalledon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected payments have been recalled and returned to <strong>draft</strong> status.";
		reloadPaymentGrid();
	}
}
function stopRecordFromList(e) {
	e.preventDefault();
	if (record != null) {
		buildConfirmDialog("Payment <strong>" + record.batchid + "</strong> will be recalled and returned to draft status.", "Do you want to continue?", function() {
			stopRecords();
		});
	} else {
		var sel = selectedRowIds.length,
			rtext = (sel > 1) ? "payments" : "payment";
		buildConfirmDialog("The selected " + rtext + " will be recalled and returned to draft status.", "Do you want to continue?", function() {
			stopRecords();
		});
	}
}

/**********************************************************************
APPROVE PAYMENT
**********************************************************************/
var approvalData = [];
var	approvalDataView;
var	approvalGrid;
var	approvalColumns = [{
	id: "name",
	name: "Beneficiary / Batch Name",
	field: "name",
	width: 250,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "batchid",
	name: "Payment ID",
	field: "batchid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "totaldebitamount",
	name: "Debit Amount",
	field: "totaldebitamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "debitcurrency",
	name: "Debit Currency",
	field: "debitcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitaccountnumber",
	name: "Debit Account Number",
	field: "debitaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "paymentdate",
	name: "Payment Date",
	field: "paymentdate",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "type",
	name: "Payment Type",
	field: "type",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "numberofpayments",
	name: "No. of Instructions",
	field: "numberofpayments",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}];
var approvalOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiSelect: false
};
var AuthorisationModel = 0;
function approveRecords(dialog) {
	$("#approvePayments").addClass("working");
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#approvePayments").removeClass("working");
			dialogHider(dialog);
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			if (record != null) {
				$("a[data-panel='#paymentsGrid']").trigger("click");
			}
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	if (record != null) {
		record.status = "Processing";
		record.workflow = "Approved";
		record.approvedby = "Test User";
		record.approvedon = smartDates("today") + " at " + timeFormatter();
		msg = "Payment <strong>" + record.batchid + "</strong> has been approved and submitted for processing.";
		reloadPaymentGrid();
	} else {
		var sel = selectedRowIds.length;
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Processing";
			data[dataView.getIdxById(selectedRowIds[i])].workflow = "Approved";
			data[dataView.getIdxById(selectedRowIds[i])].approvedby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].approvedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Selected payments have been approved and submitted for processing.";
		reloadPaymentGrid();
	}
}
function approveRecordFromList(e) {
	e.preventDefault();
	if ( selectedRowIds.length == 0 && record == null) {
		return false;
	} else {
		var $target = $(e.target);

		var populateApprovalDialog = function() {
			var $dialogContent = $("<div class='box approval-dialog' />");
			var $generateApprovalWarning = $("<div class='approval-warning'>In order to protect your account from fraud risk, please conduct your payments carefully</div>").appendTo($dialogContent);
			var $generateAuditReportsDiv = $("<div class='approval-audit-reports' />").appendTo($dialogContent);
			var $generateAuditReportLink = $("<a href='javascript:void(0)' id='generateAuditReportButton'><i class='fa fa-file-text fa-fw'></i> Generate Audit Reports</a>").appendTo($generateAuditReportsDiv).on("click", function(e) {
				e.preventDefault();
				confirmAuditReport();
			});
			var $approveSummaryGrid = $("<div id='approvalGrid' class='approval-grid' />").appendTo($dialogContent);

			if (AuthorisationModel === 0) {
				$approveSummaryGrid.css({"height": "90%"});
			} else if (AuthorisationModel === 1) {
				// SmartCard
				var $div = $("<div class='smartcard-approval' />").appendTo($dialogContent);
				var $heading = $("<h3>Approve with a Transaction Signature</h3>").appendTo($div);
				var $textline1 = $("<h4>Your smartcard is required for approval</h4>").appendTo($div);
				var $img = $("<div class='smartcard-image'></div>").appendTo($div);
				var $instructions = $("<div class='instructions'>Please click &quot;Approve&quot; and enter your PIN into the pop-up window that opens.</div>").appendTo($div);
				var $note = $("<div><strong>Note:</strong> Your Smartcard must be connected to your computer.</div>").appendTo($instructions);
				var $help = $("<div><a href='about:blank' target='Security Device Help' class='help'>Click here for more Security Device help</a></div>").appendTo($instructions);			
			} else if (AuthorisationModel === 2) {
				// Single Token
				var $div = $("<div class='token-approval' />").appendTo($dialogContent);
				var $step = $("<div class='step1' />").appendTo($div);
				var $heading = $("<h3>Step 1: Generate your authorisation code</h3>").appendTo($step);
				var $stepList = $("<ul />").appendTo($step);
				var $li = $("<li class='token-step'>Turn on the token by holding down <div class='tkimg token-on'></div> and pressing <div class='tkimg token-unlock'></div></li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Enter your 6-digit PIN</li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Press <div class='tkimg token-sig'></div> and enter the following code in into the Token: <span class='token-code'>12345</span></li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Press <div class='tkimg token-on'></div> to display the authorisation code</li>").appendTo($stepList);
				var $help = $("<div><a href='about:blank' target='Token Help' class='help'>Click Here for Token Help</a></div>").appendTo($step);
				var $step = $("<div class='step2' />").appendTo($div);
				var $heading = $("<h3>Step 2: Enter your authorisation code</h3>").appendTo($step);
				var $authDiv = $("<div class='auth-field' />").appendTo($step);
				var $authInput = $("<input class='auth-input' maxlength='6' />").appendTo($authDiv);
			}  else if (AuthorisationModel === 3) {
				// Confirm Token
				var $div = $("<div class='token-approval' />").appendTo($dialogContent);
				var $step = $("<div class='step1' />").appendTo($div);
				var $heading = $("<h3>Step 1: Confirm Token</h3>").appendTo($step);
				var $tokenSelection = $("<div />").appendTo($step);
				var $tokenDiv = $("<div class='token-selection' />").appendTo($tokenSelection);
				var $token = $("<div class='token-img tk270' />").appendTo($tokenDiv);
				var $tokenRadio = $("<input type='radio' name='token-selection' id='tk1' />").appendTo($tokenDiv);
				var $tokenText = $("<div class='token-name'>270</div>").appendTo($tokenDiv);
				var $stepList = $("<ul />").appendTo($step);
				var $li = $("<li class='token-step' style='max-width: 250px;'>Ensure you are using the token pictured above to complete this authorisation</li>").appendTo($stepList);
				var $step = $("<div class='step2' />").appendTo($div);
				var $heading = $("<h3>Step 2: Generate your authorisation code</h3>").appendTo($step);
				var $stepList = $("<ul />").appendTo($step);
				var $li = $("<li class='token-step'>Turn on the token by holding down <div class='tkimg token-on'></div> and pressing <div class='tkimg token-unlock'></div></li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Enter your 6-digit PIN</li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Press <div class='tkimg token-sig'></div> and enter the following code in into the Token: <span class='token-code'>12345</span></li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Press <div class='tkimg token-on'></div> to display the authorisation code</li>").appendTo($stepList);
				var $help = $("<div><a href='about:blank' target='Token Help' class='help'>Click Here for Token Help</a></div>").appendTo($step);
				var $step = $("<div class='step3' />").appendTo($div);
				var $heading = $("<h3>Step 3: Enter your authorisation code</h3>").appendTo($step);
				var $authDiv = $("<div class='auth-field' />").appendTo($step);
				var $authInput = $("<input class='auth-input' maxlength='6' />").appendTo($authDiv);
			}  else if (AuthorisationModel === 4) {
				// Multiple Tokens
				var $div = $("<div class='token-approval' />").appendTo($dialogContent);
				var $step = $("<div class='step1' />").appendTo($div);
				var $heading = $("<h3>Step 1: Select Token</h3>").appendTo($step);
				var $tokenSelection = $("<div />").appendTo($step);
				var $tokenDiv = $("<div class='token-selection' />").appendTo($tokenSelection);
				var $token = $("<div class='token-img tk270' />").appendTo($tokenDiv);
				var $tokenRadio = $("<input type='radio' name='token-selection' id='tk1' />").appendTo($tokenDiv);
				var $tokenText = $("<div class='token-name'>270</div>").appendTo($tokenDiv);
				var $tokenDiv = $("<div class='token-selection' />").appendTo($tokenSelection);
				var $token = $("<div class='token-img tk270Xpress' />").appendTo($tokenDiv);
				var $tokenRadio = $("<input type='radio' name='token-selection' id='tk2' />").appendTo($tokenDiv);
				var $tokenText = $("<div class='token-name'>270 Xpress</div>").appendTo($tokenDiv);
				var $step = $("<div class='step2' />").appendTo($div);
				var $heading = $("<h3>Step 2: Generate your authorisation code</h3>").appendTo($step);
				var $stepList = $("<ul />").appendTo($step);
				var $li = $("<li class='token-step'>Turn on the token by holding down <div class='tkimg token-on'></div> and pressing <div class='tkimg token-unlock'></div></li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Enter your 6-digit PIN</li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Press <div class='tkimg token-sig'></div> and enter the following code in into the Token: <span class='token-code'>12345</span></li>").appendTo($stepList);
				var $li = $("<li class='token-step'>Press <div class='tkimg token-on'></div> to display the authorisation code</li>").appendTo($stepList);
				var $help = $("<div><a href='about:blank' target='Token Help' class='help'>Click Here for Token Help</a></div>").appendTo($step);
				var $step = $("<div class='step3' />").appendTo($div);
				var $heading = $("<h3>Step 3: Enter your authorisation code</h3>").appendTo($step);
				var $authDiv = $("<div class='auth-field' />").appendTo($step);
				var $authInput = $("<input class='auth-input' maxlength='6' />").appendTo($authDiv);
			}
			return $dialogContent;
		}
		var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
		var _dialog = {
			id: "approvePayments",
			title: "Approve Selected Payments",
			size: "full-screen",
			icon: "<i class='fa fa-check-circle'></i>",
			content: function() {
				return populateApprovalDialog()
			},
			buttons: []
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		var $buttonBar = $("div.dialog-buttons");
			if (AuthorisationModel === 1) {
				// Smartcard
				var $div = $("<div />"),
					$cnclBtnDiv = $("<div class='smartcard-button-section' />").appendTo($div),
					$cnclBtn = $("<button class='smartcard-buttons'>Cancel</button>").appendTo($cnclBtnDiv).on("click", function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}),
					$apprvBtnDiv = $("<div class='smartcard-button-section' />").appendTo($div),
					$apprvBtn = $("<button class='smartcard-buttons'>Approve</button>").appendTo($apprvBtnDiv).on("click", function(e) {
						e.preventDefault();
						approveRecords(_dialog);
					});
				$div.appendTo($buttonBar);	
			} else {
				var $div = $("<div />"),
					$cnclBtn = $("<a href='javascript:void(0)' class='form-button'><i class='fa fa-times fa-fw'></i>Cancel</a>").appendTo($div).on("click", function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}),
					$apprvBtn = $("<a href='javascript:void(0)' class='form-button primary'><i class='fa fa-check fa-fw'></i>Submit</a>").appendTo($div).on("click", function(e) {
						e.preventDefault();
						approveRecords(_dialog);
					});
				$div.appendTo($buttonBar);				
			}

		approvalData = [];

		if (selectedRowIds.length > 0) {
			for (var i = 0; i < selectedRowIds.length; i++) {
				approvalData.push(data[dataView.getIdxById(selectedRowIds[i])]);
			}
		} else {
			approvalData.push(record);
		}

		setTimeout(function() {
			approvalDataView = new Slick.Data.DataView({});
			approvalGrid = new Slick.Grid("#approvalGrid", approvalDataView, approvalColumns, approvalOptions);
			approvalGrid.setSelectionModel(new Slick.RowSelectionModel({
				selectActiveRow: false
			}));
			approvalDataView.setItems(approvalData);
			approvalGrid.setColumns(approvalColumns);
			approvalGrid.onContextMenu.subscribe(function(e, args) {
				e.preventDefault();
				var cell = approvalGrid.getCellFromEvent(e),
					row = cell.row,
					rows = approvalGrid.getSelectedRows(),
					$cmenu = $("#approvalContextMenu");
				var cheight = $cmenu.height(),
					winwidth = $(window).width(),
					winheight = $(window).height(),
					leftpos = e.pageX,
					toppos = e.pageY;
				if (e.pageX + 210 > winwidth) {
					leftpos = e.pageX - 205;
				}
				if (e.pageY + cheight > winheight) {
					toppos = e.pageY - cheight;
					if (toppos < 0) {
						toppos = e.pageY - (cheight - (winheight - e.pageY));
					}
				};
				$(document).off("keyup.hide-context");
				$("body").off("click.hide-context");

				function hideContextMenu() {
					$(".control-menus").children(".control-menu:visible").hide();
					$(".control-list").find(".on").removeClass("on");
					$(".control-menus").find("a.sub-open").removeClass("sub-open");
				}
				hideContextMenu();
				$cmenu.css("top", toppos).css("left", leftpos).css("z-index", 1000).show();
				$(document).on("keyup.hide-context", function(e) {
					if (e.keyCode == 27) {
						hideContextMenu()
					}
				});
				$("body").one("click.hide-context", function() {
					hideContextMenu()
				});
			});
			$(window).bind("resize", function() {
				approvalGrid.resizeCanvas();
			});
			$(window).on("resize", _.debounce(function(e) {
				approvalGrid.resizeCanvas();
			}, 100));
			approvalGrid.autosizeColumns();

			if ( AuthorisationModel === 4 ) {
				AuthorisationModel = 0
			} else {
				AuthorisationModel = AuthorisationModel + 1;
			}
		}, 300);
	}
}


/**********************************************************************
GET RATE
**********************************************************************/
function getDynamicRate(e) {
	e.preventDefault();
	var item = null;
	var item = (record != null) ? record : dataView.getItemById(selectedRowIds[0]);
	var $target = $(e.target);
	var timeLeft, $elem, timerId;
	var countdowntimer = function() {
		if (timeLeft == 0) {
			clearTimeout(timerId);
			$elem.html("0");
			$("#rateReturnedSection").hide();
			$("#rateExpiredSection").show();
			$("#getDynamicRateDialog").find("a[data-action='dialog-trade']").hide();
		} else {
			$elem.html(timeLeft);
			timeLeft--;
		}
	}
	var populateGetRateDialog = function() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='getRateContent' />");
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxContent = $("<div class='box-content transparent no-row-padding left-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Beneficiary / Payment Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>"+ item.name +"</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment ID</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>"+ item.batchid +"</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Debit Account Number</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>"+ item.debitaccountnumber +"</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment Type</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>"+ item.type +"</div>").appendTo($dataCol);
		var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Value Date</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text'>"+ item.paymentdate +"</div>").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Total Amount</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = (item.debitequivalentflag) ? $("<div class='data-text'>"+ item.debitcurrency + " " + addCommas(item.totaldebitamount) +"</div>") : $("<div class='data-text'>"+ item.paymentcurrency + " " + addCommas(item.totalpaymentamount) +"</div>");
		$data.appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Amount Requiring Rate</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = (item.debitequivalentflag) ? $("<div class='data-text'>"+ item.debitcurrency + " " + addCommas(item.totaldebitamount) +"</div>") : $("<div class='data-text'>"+ item.paymentcurrency + " " + addCommas(item.totalpaymentamount) +"</div>");
		$data.appendTo($dataCol);			
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>FX Currency</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = (item.debitequivalentflag) ? $("<div class='data-text'>"+ item.paymentcurrency +"</div>") : $("<div class='data-text'>"+ item.debitcurrency +"</div>");
		$data.appendTo($dataCol);
		var $detailRow = $("<div class='grid-row' id='rateSection' style='display: none;' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $row = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column full' style='text-align: center;' />").appendTo($row);
		var $dynamicRateSection = $("<div class='dynamic-rate-section' />").appendTo($dataCol);
		var $countdownContainer = $("<div class='countdown-container' />").appendTo($dynamicRateSection);
		var $note = $("<div class='countdown-note'>Time Remaning</div>").appendTo($countdownContainer);
		var $count = $("<div class='countdown-timer' id='countDownTimer'>30</div>").appendTo($countdownContainer);
		var $rateDetailSection = $("<div class='rate-detail-section' id='rateReturnedSection' />").appendTo($dynamicRateSection);
		if (item.debitequivalentflag) {
			var $rateAmount = $("<div class='rate-detail'>"+ item.debitcurrency +" <div class='rate-detail-large'>"+ addCommas(item.totaldebitamount) +"</div></div>").appendTo($rateDetailSection);
			var $rateIcon = $("<div class='rate-detail rate-icon'><i class='fa fa-exchange fa-fw'></i></div>").appendTo($rateDetailSection);
			var $rateAmount = $("<div class='rate-detail'>"+ item.paymentcurrency +" <div class='rate-detail-large'>"+ addCommas(item.totalpaymentamount) +"</div></div>").appendTo($rateDetailSection);
			var $rate = $("<div class='rate-detail returned-rate'>Rate: <span class='rate-detail-large' style='margin-left: 5px;'>"+ returnRate() +"</span><div style='font-size: 14px;'>"+ smartDates("today") + " " + timeFormatter() +"</div></div>").appendTo($rateDetailSection);				
		} else {
			var $rateAmount = $("<div class='rate-detail'>"+ item.paymentcurrency +" <div class='rate-detail-large'>"+ addCommas(item.totalpaymentamount) +"</div></div>").appendTo($rateDetailSection);
			var $rateIcon = $("<div class='rate-detail rate-icon'><i class='fa fa-exchange fa-fw'></i></div>").appendTo($rateDetailSection);
			var $rateAmount = $("<div class='rate-detail'>"+ item.debitcurrency +" <div class='rate-detail-large'>"+ addCommas(item.totaldebitamount) +"</div></div>").appendTo($rateDetailSection);
			var $rate = $("<div class='rate-detail returned-rate'>Rate: <span class='rate-detail-large' style='margin-left: 5px;'>"+ returnRate() +"</span><div style='font-size: 14px;'>"+ smartDates("today") + " " + timeFormatter() +"</div></div>").appendTo($rateDetailSection);		
		}

		var $rateExpired = $("<div class='rate-expired' id='rateExpiredSection' style='display: none;'>Rate Expired</div>").appendTo($dynamicRateSection);

		return $dialogContent;
	}
	var returnRate = function() {
		var returnedRate;
		if (item.debitequivalentflag) {
			for (var i = 0; i < _payment_system_rates.length; i++) {
				var psr = _payment_system_rates[i];
				if (item.debitaccount.currency.code == psr.from && item.paymentcurrency == psr.to) {
					returnedRate = psr.rate;
					break;
				}
			}
		} else {
			for (var i = 0; i < _payment_system_rates.length; i++) {
				var psr = _payment_system_rates[i];
				if (item.debitaccount.currency.code == psr.to && item.paymentcurrency == psr.from) {
					returnedRate = psr.rate;
					break;
				}
			}
		}
		return returnedRate.toFixed(4);
	}
	var getRateAction = function() {
		$("#getDynamicRateDialog").addClass("working");
		timeLeft = 30;
		$elem = $('#countDownTimer');
		timerId = setInterval(countdowntimer, 1000);		
		setTimeout(function() {
			$("#rateSection").show();
			$("#getDynamicRateDialog").find("a[data-action='dialog-get-rate']").hide();
			$("#getDynamicRateDialog").find("a[data-action='dialog-trade']").removeClass("display-none");
			$("#getDynamicRateDialog").removeClass("working");
		}, 1000);
	}
	var executeTrade = function() {
		$("#getDynamicRateDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			setTimeout(function() {
				var msg = "FX Contract ID: <strong>" + randString(10) + "</strong> with a rate of <strong>"+ returnRate() +"</strong> has been applied to Payment ID <strong>" + item.batchid + "</strong>";
				buildConfirmDialog("<strong>Trade Successfully Executed</strong>", msg, "");
			}, 300);
		}, 1000);
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "getDynamicRateDialog",
		title: "Get Rate",
		size: "get-rate",
		icon: "<i class='fa fa-exchange'></i>",
		content: function() {
			return populateGetRateDialog()
		},
		hasgrid: function() {
			clearTimeout(timerId);
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Get Rate",
			icon: "<i class='fa fa-exchange fa-fw fa-lg'></i>",
			attributes: [{
				name: "data-action",
				value: "dialog-get-rate"
			}],
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					getRateAction();
				}
			}],
			cssClass: "primary"
		}, {
			name: "Trade",
			icon: "<i class='fa fa-exchange fa-fw fa-lg'></i>",
			attributes: [{
				name: "data-action",
				value: "dialog-trade"
			}],
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					executeTrade();
				}
			}],
			cssClass: "action display-none"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}



/**********************************************************************
REJECT PAYMENT
**********************************************************************/
function rejectRecords(dialog) {
	$("#rejectReason").addClass("working");
	var sel = selectedRowIds.length;
	if (!sel || sel == 1) {
		var payment, msg;
		if (record != null) {
			payment = dataView.getItemById(record.id);
		} else {
			payment = data[dataView.getIdxById(selectedRowIds[0])];
		}
		var reloadPaymentGrid = function() {
			payment.rejectedby = "Test User";
			payment.rejectedon = smartDates("today") + " at " + timeFormatter();
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				if (record != null) {
					$("a[data-panel='#paymentsGrid']").trigger("click");
				}
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		payment.status = "Rejected";
		msg = "Approval for payment <strong>" + payment.batchid + "</strong> has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	} else if (sel > 1) {
		var reloadPaymentGrid = function() {
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Rejected";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedby = "Test User";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Approval for selected payment records has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	}
}
function rejectRecordReason(e) {
	e.preventDefault();
	var $target = $(e.target);
	var populateRejectReason = function() {
		var $form = $("<div class='form-section' />");
		var $row = $("<div class='row' />").appendTo($form);
		var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
		var $textarea = $("<textarea style='width: 425px; height: 230px;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
		return $form;
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "rejectReason",
		title: "Enter A Reason For Rejection",
		size: "small",
		icon: "<i class='fa fa-ban'></i>",
		content: function() {
			return populateRejectReason()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					rejectRecords(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#rejectionReasonTextarea").focus();
}
function rejectRecordFromList(e) {
	e.preventDefault();
	var sel = selectedRowIds.length;
	if (sel == 0 && record == null) {
		return false;
	} else if ( sel == 1) {
			rejectRecordReason(e);
	} else if ( sel > 1 ) {
		buildConfirmDialog("Approval for selected records will be rejected.", "Do you want to continue?", function() {
			rejectRecordReason(e);
		});
	}
}



/**********************************************************************
DIALOGS
**********************************************************************/
function triggerAuditReportDialog(_target) {

	function downloadReport(_dialog) {
		$("#auditReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "")
		}, 3000);
	};
	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}

		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};
	if (_target) {
		var _origin = _target;
	} else {
		var _origin = $("#generateAuditReportButton");
	}
	var _dialog = {
		id: "auditReportDialog",
		title: "Generate Audit Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function confirmAuditReport() {
	buildConfirmDialog("This will generate audit reports for each of the payments selected for approval. <br /><br />To generate an audit report for a specific payment in this list, right-click the payment and select &quot;Generate Audit Report&quot; from the context menu.", "Generate Audit Reports?", triggerAuditReportDialog);
}
function showPaymentDetailReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#detailReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}


		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "detailReportDialog",
		title: "Payment Detail Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentSummaryReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#summaryReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}


		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "summaryReportDialog",
		title: "Payment Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentTrailReportDialog(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		$("#trailReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var formElements = [{
			name: "Report Format",
			id: "repFormat",
			type: "select",
			data: [{
				option: "CSV",
				value: "CSV"
			}, {
				option: "PDF",
				value: "PDF"
			}]
		}, {
			name: "Report Encoding",
			id: "repEncoding",
			type: "select",
			data: [{
				option: "UTF-8",
				value: "UTF-8"
			}, {
				option: "ASCII",
				value: "ASCII"
			}, {
				option: "Unicode",
				value: "Unicode"
			}]
		}, {
			name: "Report Language",
			id: "repLanguage",
			type: "select",
			data: [{
				option: "English",
				value: "English"
			}, {
				option: "Chinese (Simplified)",
				value: "Chinese (Simplified)"
			}, {
				option: "Chinese (Traditional)",
				value: "Chinese (Traditional)"
			}]
		}, {
			name: "Report Name",
			id: "repName",
			type: "input",
			max: 30
		}, {
			name: "Report Description",
			id: "redDescription",
			type: "textarea",
			max: 75
		}],
		$formWrapper = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$el, $custom, $note, _type = formElements[i].type;

		if (_type == "input") {
			$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
		}

		if (_type == "textarea") {
			$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
		}

		if (_type == "select") {
			$custom = $("<div class='custom-select' style='width: 90%;' />");
			$el = $("<select id='" + formElements[i].id + "'></select>");
			if (formElements[i].data) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if (formElements[i].attributes) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
			}
		}

		if (formElements[i].events) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
			}
		}

		if (_type == "select") {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if (formElements[i].note) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
		}
	};

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "trailReportDialog",
		title: "Payment Trail Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showBatchLevelDebitAdviceDialog(e) {
	e.preventDefault();

	var dialogGridDataView;
	var dialogGrid;
	var dialogGridData = record.payments;
	var dialogGridColumns = [{
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: false
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 290,
		sortable: false
	}];
	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: Slick.Formatters.AmountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: Slick.Formatters.AmountFormatter
		}
	}
	dialogGridColumns.push(currencyColumn);
	dialogGridColumns.push(amountColumn);
	var dialogGridCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	dialogGridColumns.unshift(dialogGridCheckboxSelector.getColumnDefinition());
	var dialogGridOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: false,
		multiSelect: true
	};
	var gridNotLoaded = true;

	function downloadReport(_dialog) {
		$("#generateDebitAdvices").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	function renderDialog() {
		var $dialogContent = $("<div class='data-form' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Format</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 70%;' />").appendTo($dataCol),
			$data = $("<select id='reFormat'><option value='CSV'>CSV</option><option value='PDF'>PDF</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='repName' maxlength='30' style='width: 70%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<textarea id='repDescription' style='width: 70%;'></textarea>").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Generate Debit Advices For</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='radio' name='instructionSetting' id='allInst' checked='checked' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").hide();
					dialogGrid.setSelectedRows([]);
					$("#generateDebitAdvices").find("div.dialog-content").css({
						"overflow-y": "auto"
					});
				}
			}),
			$labelDesc = $("<label class='desc' for='allInst'>All Instructions<label>").appendTo($dataCol),
			$data = $("<input type='radio' name='instructionSetting' id='selectInst' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").show();
					$("#generateDebitAdvices").find("div.dialog-content").css({
						"overflow-y": "scroll"
					});

					if (gridNotLoaded == true) {
						/* initialise the dialog grid */
						var dialogGridItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
						dialogGridDataView = new Slick.Data.DataView({
							dialogGridItemMetaProvider: dialogGridItemMetaProvider
						});
						dialogGrid = new Slick.Grid("#dialogGrid", dialogGridDataView, dialogGridColumns, dialogGridOptions);
						dialogGrid.setSelectionModel(new Slick.RowSelectionModel({
							selectActiveRow: false
						}));
						dialogGrid.registerPlugin(dialogGridItemMetaProvider);
						dialogGrid.registerPlugin(dialogGridCheckboxSelector);
						dialogGridDataView.beginUpdate();
						dialogGridDataView.setItems(dialogGridData);
						dialogGridDataView.endUpdate();
						dialogGrid.setColumns(dialogGridColumns);
					}
				}
			}),
			$labelDesc = $("<label class='desc' for='selectInst'>Select Instructions<label>").appendTo($dataCol),
			$selectionSection = $("<div class='py-ui' id='addInstructionSection' style='display: none;' />").appendTo($formSection),
			$row = $("<div class='row' style='padding: 0;' />").appendTo($selectionSection),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
			$searchDiv = $("<div class='icon-input payment-grid-filter' style='width: 40%;' />").appendTo($inlineSearch),
			$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
			$searchInput = $("<input type='text' placeholder='Search Instructions' />").appendTo($searchDiv),
			$gridDiv = $("<div id='dialogGrid' style='border: 1px solid #cdcdcd; width: 100%; height: 350px; overflow: hidden; border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);

	var _dialog = {
		id: "generateDebitAdvices",
		title: "Generate Debit Advices",
		size: "large",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderDialog();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showBatchLevelBeneAdviceDialog(e) {
	e.preventDefault();

	var dialogGridDataView;
	var dialogGrid;
	var dialogGridData = record.payments;
	var dialogGridColumns = [{
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: false
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 290,
		sortable: false
	}];
	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: Slick.Formatters.AmountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 80,
			sortable: false
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			width: 100,
			sortable: false,
			formatter: Slick.Formatters.AmountFormatter
		}
	}
	dialogGridColumns.push(currencyColumn);
	dialogGridColumns.push(amountColumn);
	var dialogGridCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	dialogGridColumns.unshift(dialogGridCheckboxSelector.getColumnDefinition());
	var dialogGridOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: false,
		multiSelect: true
	};
	var gridNotLoaded = true;

	function downloadReport(_dialog) {
		$("#generateBeneficiaryAdvices").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	function renderDialog() {
		var $dialogContent = $("<div class='data-form' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Format</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 70%;' />").appendTo($dataCol),
			$data = $("<select id='reFormat'><option value='CSV'>CSV</option><option value='PDF'>PDF</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='repName' maxlength='30' style='width: 70%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<textarea id='repDescription' style='width: 70%;'></textarea>").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Generate Beneficiary Advices For</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='radio' name='instructionSetting' id='allInst' checked='checked' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").hide();
					dialogGrid.setSelectedRows([]);
					$("#generateBeneficiaryAdvices").find("div.dialog-content").css({
						"overflow-y": "auto"
					});
				}
			}),
			$labelDesc = $("<label class='desc' for='allInst'>All Instructions<label>").appendTo($dataCol),
			$data = $("<input type='radio' name='instructionSetting' id='selectInst' />").appendTo($dataCol).on("change", function() {
				if ($(this).prop('checked')) {
					$("#addInstructionSection").show();
					$("#generateBeneficiaryAdvices").find("div.dialog-content").css({
						"overflow-y": "scroll"
					});

					if (gridNotLoaded == true) {
						/* initialise the dialog grid */
						var dialogGridItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
						dialogGridDataView = new Slick.Data.DataView({
							dialogGridItemMetaProvider: dialogGridItemMetaProvider
						});
						dialogGrid = new Slick.Grid("#dialogGrid", dialogGridDataView, dialogGridColumns, dialogGridOptions);
						dialogGrid.setSelectionModel(new Slick.RowSelectionModel({
							selectActiveRow: false
						}));
						dialogGrid.registerPlugin(dialogGridItemMetaProvider);
						dialogGrid.registerPlugin(dialogGridCheckboxSelector);
						dialogGridDataView.beginUpdate();
						dialogGridDataView.setItems(dialogGridData);
						dialogGridDataView.endUpdate();
						dialogGrid.setColumns(dialogGridColumns);
					}
				}
			}),
			$labelDesc = $("<label class='desc' for='selectInst'>Select Instructions<label>").appendTo($dataCol),
			$selectionSection = $("<div class='py-ui' id='addInstructionSection' style='display: none;' />").appendTo($formSection),
			$row = $("<div class='row' style='padding: 0;' />").appendTo($selectionSection),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
			$searchDiv = $("<div class='icon-input payment-grid-filter' style='width: 40%;' />").appendTo($inlineSearch),
			$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
			$searchInput = $("<input type='text' placeholder='Search Instructions' />").appendTo($searchDiv),
			$gridDiv = $("<div id='dialogGrid' style='border: 1px solid #cdcdcd; width: 100%; height: 350px; overflow: hidden; border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);

	var _dialog = {
		id: "generateBeneficiaryAdvices",
		title: "Generate Beneficiary Advices",
		size: "large",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return renderDialog();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentNotificaitonsDialog(_target, item) {
	function renderPaymentNotifications() {

		function dynamicSort(property) {
			var sortOrder = 1;
			if (property[0] === "-") {
				sortOrder = -1;
				property = property.substr(1);
			}
			return function(a, b) {
				var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
				return result * sortOrder;
			}
		}

		item.noticeitems.sort(dynamicSort("type")).reverse();

		var _haserrors = false;

		for (var e = 0, f = item.noticeitems.length; e < f; e++) {
			if (item.noticeitems[e].type == "error") {
				_haserrors = true;
				break;
			}
		}

		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewAlertsDialog' />");

		/* system information */
		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Payment Information</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Payment ID</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + item.batchid + "</div>").appendTo($dataCol),
			$detailCell = $("<div class='grid-cell' style='width: 34%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Beneficiary / Payment Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + item.name + "</div>").appendTo($dataCol),
			$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Status</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + item.status + "</div>").appendTo($dataCol);

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell);
		if (_haserrors) {
			var $boxHeader = $("<div class='box-header'>Payment Errors and Alerts</div>").appendTo($box);
		} else {
			var $boxHeader = $("<div class='box-header'>Payment Alerts</div>").appendTo($box);
		}
		var	$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$noticesGrid = $("<div class='error-grid' id='alertsGrid' />").appendTo($dataCol),
			$noticesList = $("<ul class='error-list' />").appendTo($noticesGrid);

		for (var e = 0, f = item.noticeitems.length; e < f; e++) {
			var _class = (item.noticeitems[e].type == "error") ? "error-icon" : "alert-icon";
			var $li = $("<li><span class='" + _class + "'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + item.noticeitems[e].description + "</span></li>").appendTo($noticesList);
		}

		return $dialogContent;
	}
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "viewPaymentAlerts",
		title: "Payment Errors and Alerts",
		size: "xwide",
		icon: "<i class='fa fa-exclamation-triangle'></i>",
		content: function() {
			return renderPaymentNotifications();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentErrorsDialog(_target, item) {
	function renderPaymentErrors() {
		var $dialogContent = $("<div />");
		return $dialogContent;
	}
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "viewPaymentErrors",
		title: "Payment Errors",
		size: "xl",
		icon: "<i class='fa fa-exclamation-triangle'></i>",
		content: function() {
			return renderPaymentErrors();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showPaymentTemplateDialog(e) {
	e.preventDefault();



	function confirmTemplateCreation(_dialog) {
		$("#createTemplateDialog").addClass("working");
		setTimeout(function() {
			buildCustomDialog([{
				text: "Template Name: " + $("#templateName").val(),
				style: "color: #007dba; font-weight: bold;"
			}, {
				text: "Payment template has been successfully created.",
				style: ""
			}], [{
				title: "Ok",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
				}
			}, {
				title: "View This Template",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
					setTimeout(function() {
						document.location.href = "payments-templates.html#detail";
					}, 500);
				}
			}]);
			dialogHider(_dialog);
		}, 1000);
	}


	var populateTemplateCreationDialog = function() {
		var $dialogContent = $("<div class='data-form top-label' id='templateDialogContent' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row mandatory' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateName' style='width: 90%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateDesc' style='width: 90%;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "createTemplateDialog",
		title: "Create A Template From This Payment",
		size: "xsmall",
		icon: "<i class='fa fa-clipboard'></i>",
		content: function() {
			return populateTemplateCreationDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					confirmTemplateCreation(_dialog)
				}
			}],
			attributes: [{
				name: "id",
				value: "createTemplateButton"
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#templateName").focus();
}
function showAuditHistoryDialog(e) {
	e.preventDefault();


	var destroyAuditGrid = function() {
		if (typeof(auditGrid) != 'undefined' && auditGrid != null) {
			auditGrid.destroy();
			$(window).off('resize.auditgrid');
		}
	}

	var loadRecordAuditTable = function() {
		$("#auditHistoryDilaog").addClass("loading");

		setTimeout(function() {
			var auditData = record.audit;
			var $auditGrid = $("<div class='panel' id='auditGrid' style='top: 0;' />").appendTo($("#auditGridContainer"));
			var auditColumns = [{
				id: "action",
				name: "Action",
				field: "action",
				width: 500,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}, {
				id: "by",
				name: "User",
				field: "by",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}, {
				id: "datetime",
				name: "Date / Time",
				field: "datetime",
				width: 200,
				sortable: true,
				sorter: "sorterStringCompare",
				visible: true,
			}];
			var auditOptions = {
				enableCellNavigation: false,
				enableColumnReorder: false,
				syncColumnCellResize: false,
				forceFitColumns: false,
				multiSelect: false,
				multiColumnSort: true
			};

			if (store.get('auditColumnOrder')) {
				auditColumns = store.get('auditColumnOrder');
			} else {
				store.set('auditColumnOrder', auditColumns)
			}

			if (store.get('auditColumnWidths')) {
				var setWidth = store.get('auditColumnWidths');
				for (var i in setWidth) {
					var s = setWidth[i]
					for (c = 0; c < auditColumns.length; c++) {
						if (s.id == auditColumns[c].id) {
							auditColumns[c].width = s.width
						}
					}
				}
			}

			var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
			var auditDataView = new Slick.Data.DataView({
				groupItemMetadataProvider: groupItemMetadataProvider
			});
			auditGrid = new Slick.Grid($auditGrid, auditDataView, auditColumns, auditOptions);
			auditGrid.registerPlugin(groupItemMetadataProvider);
			var auditColumnpicker = new Slick.Controls.ColumnPicker(auditColumns, auditGrid, auditOptions, 'auditColumnOrder', 'auditColumnWidths');
			auditGrid.setSelectionModel(new Slick.RowSelectionModel({
				selectActiveRow: true
			}));
			auditGrid.onSelectedRowsChanged.subscribe(function(e, args) {
				var rows = auditGrid.getSelectedRows();
				for (var i = 0, l = rows.length; i < l; i++) {
					var item = auditDataView.getItem(rows[i])
				}
			});
			auditGrid.onClick.subscribe(function(e, args) {
				var cell = auditGrid.getCellFromEvent(e);
				var row = cell.row;
			});
			auditGrid.onDblClick.subscribe(function(e, args) {
				var cell = auditGrid.getCellFromEvent(e);
				var row = cell.row;
			});
			auditGrid.onKeyDown.subscribe(function(e, args) {
				if (e.which == 13) {
					if (auditGrid.getActiveCell()) {
						var row = auditGrid.getActiveCell().row;
					}
				}
			});
			auditGrid.onSort.subscribe(function(e, args) {
				auditDataView.sort(function(dataRow1, dataRow2) {
					sortdir = args.sortAsc ? 1 : -1;
					sortcol = args.sortCol.field;
					var _sorter = args.sortCol.sorter,
						result;
					if (_sorter == "sorterStringCompare") {
						result = sorterStringCompare(dataRow1, dataRow2);
					} else if (_sorter == "sorterNumeric") {
						result = sorterNumeric(dataRow1, dataRow2);
					} else if (_sorter == "sorterDateIso") {
						result = sorterDateIso(dataRow1, dataRow2);
					} else if (_sorter == "sorterTime") {
						result = sorterTime(dataRow1, dataRow2);
					}
					if (result != 0) {
						return result;
					}
				});
				args.grid.invalidateAllRows();
				args.grid.render();
			});
			auditGrid.onColumnsReordered.subscribe(function(e, args) {
				store.set('auditColumnOrder', auditColumns);
			});

			auditGrid.onColumnsResized.subscribe(function(e, args) {
				store.set('auditColumnWidths', auditGrid.getColumns());
			});
			auditDataView.onRowCountChanged.subscribe(function(e, args) {
				auditGrid.updateRowCount();
				auditGrid.render();
			});
			auditDataView.onRowsChanged.subscribe(function(e, args) {
				auditGrid.invalidateRows(args.rows);
				auditGrid.render();
			});
			auditDataView.beginUpdate();
			auditDataView.setItems(auditData);
			auditDataView.endUpdate();


			auditGrid.setColumns(auditColumns);

			if (store.get('auditColumnOrder')) {
				var visibleAdHocColumns = [];
				for (var i = 0; i < store.get('auditColumnOrder').length; i++) {
					if (auditColumns[i].visible) {
						visibleAdHocColumns.push(auditColumns[i])
					}
				}
				auditGrid.setColumns(visibleAdHocColumns);
			}

			$(window).on('resize.auditgrid', function() {
				auditGrid.resizeCanvas();
			});

			$("#auditHistoryDilaog").removeClass("loading");
			auditGrid.resizeCanvas();
		}, 1000);
	}

	var populateAuditDialog = function() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditHistoryDialogContent' />");

		var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Audit Information</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$row = $("<div class='row' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($row);

		var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
			$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
			$dataTableCell = $("<div class='data-table-cell' style='width: 50%;'>Action</div>").appendTo($dataTableRow),
			$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>User</div>").appendTo($dataTableRow),
			$dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Date / Time</div>").appendTo($dataTableRow);

		for (var i = 0, l = record.audit.length; i < l; i++) {
			var _aud = record.audit[i],
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);


			if (_aud.action == "Modified") {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'/>").appendTo($dataTableRow);
				var $link = $("<a href='javascript:void(0)' style='text-decoration: none;' data-id='" + _aud.id + "'><span style='margin-right: 5px; vertical-align: middle;'>" + _aud.description + "</span><i class='fa fa-external-link fa-fw'></i></a>").appendTo($dataTableCell).on("click", function(e) {
					e.preventDefault();

					var aID = $(this).attr("data-id");

					var auditItem = _.find(record.audit, function(o) {
						return o.id == aID;
					})

					var populateAuditDetailDialog = function() {
						var $auditDialogContent = $("<div class='py-ui' style='padding: 20px;' id='auditDetailDialog' />");

						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Audit Details</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Payment ID</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.record + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>User</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.by + "</div>").appendTo($dataCol),
							$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Date / Time</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + auditItem.datetime + "</div>").appendTo($dataCol);


						var $sectionRow = $("<div class='grid-row' />").appendTo($auditDialogContent),
							$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
							$box = $("<div class='box' />").appendTo($sectionCell),
							$boxHeader = $("<div class='box-header'>Changed Values</div>").appendTo($box),
							$boxContent = $("<div class='box-content top-label' />").appendTo($box),
							$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
							$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
							$row = $("<div class='row' />").appendTo($detailCell),
							$dataCol = $("<div class='data-column' />").appendTo($row);

						var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
							$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>Field</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>Old Value</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>New Value</div>").appendTo($dataTableRow);

						for (var a = 0, b = auditItem.fields.length; a < b; a++) {
							var _field = auditItem.fields[a];
							var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
								$dataTableCell = $("<div class='data-table-cell' style='width: 34%;'>" + _field.label + "</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>" + _field.from + "</div>").appendTo($dataTableRow),
								$dataTableCell = $("<div class='data-table-cell' style='width: 33%;'>" + _field.to + "</div>").appendTo($dataTableRow);
						}


						return $auditDialogContent;
					}

					var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
					var _dialog = {
						id: "auditRecordDetails",
						title: "Audit Details",
						size: "xl",
						icon: "<i class='fa fa-info-circle'></i>",
						content: function() {
							return populateAuditDetailDialog()
						},
						buttons: [{
							name: "Close",
							icon: "<i class='fa fa-times-circle fa-fw'></i>",
							events: [{
								event: "click",
								action: function(e) {
									e.preventDefault();
									dialogHider(_dialog)
								}
							}]
						}]
					}
					dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
				});
			} else if (_aud.action == "Rejected") {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'>" + _aud.description + "</div>").appendTo($dataTableRow),
					$comment = $("<div style='line-height: normal; white-space: normal; padding: 10px 10px 10px 0; width: 175%;'><em>" + _aud.comment + "</em></div>").appendTo($dataTableCell);

			} else {
				var $dataTableCell = $("<div class='data-table-cell' style='width: 40%;'>" + _aud.description + "</div>").appendTo($dataTableRow);
			}
			var $dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.by + "</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>" + _aud.datetime + "</div>").appendTo($dataTableRow);

		}



		/* var $auditGridContainer = $("<div id='auditGridContainer' class='panel' style='top: 0;' />").appendTo($dialogContent); */
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "auditHistoryDilaog",
		title: "View Audit History",
		size: "xxl",
		icon: "<i class='fa fa-calendar'></i>",
		content: function() {
			return populateAuditDialog()
		},
		hasgrid: function() {
			return destroyAuditGrid()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Audit Report",
			icon: "<i class='fa fa-file-text fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	/* loadRecordAuditTable(); 	*/
}





















/**********************************************************************
VIEW / EDIT PAYMENT
**********************************************************************/
function viewPaymentDetails(record) {

	/* BREADCRUMB UPDATE */
	updateBreadcrumb("view");

	/* DIALOG WINDOWS */
	var showDebitDescriptionDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderBatchDescriptionDialog() {
			var $dialogContent = $("<div class='py-ui' />"),
				$row = $("<div class='row' />").appendTo($dialogContent),
				$dataCol = $("<div class='data-column full' />").appendTo($row),
				$data = $("<textarea style='width: 95%; height: 150px;' disabled='disabled' class='disabled' id='viewBatchDescriptionField'>" + record.batchdescription + "</textarea>").appendTo($dataCol);
			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Advice Description",
			size: "xsmall",
			icon: "<i class='fa fa-edit'></i>",
			content: function() {
				return renderBatchDescriptionDialog();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var showDebitAccountDetailsDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderDebitAccountInformation() {
			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />"),
				$box = $("<div class='box' />").appendTo($dialogContent),
				$boxHeader = $("<div class='box-header'>Account Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Account Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.name + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.number + " (" + record.debitaccount.currency.code + ")</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Branch Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.name + " " + record.debitaccount.bank.branch + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Address</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$inputGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address1 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address2 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.address3 + "</div>").appendTo($inputGroup),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Country</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.debitaccount.bank.country + "</div>").appendTo($dataCol);

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Debit Account Information",
			size: "large",
			icon: "<i class='fa fa-info-circle'></i>",
			content: function() {
				return renderDebitAccountInformation();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var showCreditAccountDetailsDialog = function(e) {
		e.preventDefault();
		var _target = $(e.target);

		function renderCreditAccountInformation() {
			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />"),
				$box = $("<div class='box' />").appendTo($dialogContent),
				$boxHeader = $("<div class='box-header'>Account Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Account Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.creditaccount.name + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.creditaccount.number + " (" + record.creditaccount.currency.code + ")</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Branch Name</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.creditaccount.bank.name + " " + record.creditaccount.bank.branch + "</div>").appendTo($dataCol),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Address</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$inputGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + record.creditaccount.bank.address1 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.creditaccount.bank.address2 + "</div>").appendTo($inputGroup),
				$data = $("<div class='data-text'>" + record.creditaccount.bank.address3 + "</div>").appendTo($inputGroup),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Country</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.creditaccount.bank.country + "</div>").appendTo($dataCol);

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editBatchDescription",
			title: "Credit Account Information",
			size: "large",
			icon: "<i class='fa fa-info-circle'></i>",
			content: function() {
				return renderCreditAccountInformation();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	var triggerInstructionDialog = function(_target, item) {

		function triggerBeneficiaryAdviceDialog(_target) {
			function downloadReport(_dialog) {
				$("#BeneAdviceReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "")
				}, 3000);
			};

			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Encoding",
					id: "repEncoding",
					type: "select",
					data: [{
						option: "UTF-8",
						value: "UTF-8"
					}, {
						option: "ASCII",
						value: "ASCII"
					}, {
						option: "Unicode",
						value: "Unicode"
					}]
				}, {
					name: "Report Language",
					id: "repLanguage",
					type: "select",
					data: [{
						option: "English",
						value: "English"
					}, {
						option: "Chinese (Simplified)",
						value: "Chinese (Simplified)"
					}, {
						option: "Chinese (Traditional)",
						value: "Chinese (Traditional)"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}
				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};


			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "BeneAdviceReportDialog",
				title: "Beneficiary Advice",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function triggerDebitAdviceDialog(_target) {
			function downloadReport(_dialog) {
				$("#DebitAdviceReportDialog").addClass("working");
				setTimeout(function() {
					dialogHider(_dialog);
					buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
				}, 3000);
			};

			var formElements = [{
					name: "Report Format",
					id: "repFormat",
					type: "select",
					data: [{
						option: "CSV",
						value: "CSV"
					}, {
						option: "PDF",
						value: "PDF"
					}]
				}, {
					name: "Report Encoding",
					id: "repEncoding",
					type: "select",
					data: [{
						option: "UTF-8",
						value: "UTF-8"
					}, {
						option: "ASCII",
						value: "ASCII"
					}, {
						option: "Unicode",
						value: "Unicode"
					}]
				}, {
					name: "Report Language",
					id: "repLanguage",
					type: "select",
					data: [{
						option: "English",
						value: "English"
					}, {
						option: "Chinese (Simplified)",
						value: "Chinese (Simplified)"
					}, {
						option: "Chinese (Traditional)",
						value: "Chinese (Traditional)"
					}]
				}, {
					name: "Report Name",
					id: "repName",
					type: "input",
					max: 30
				}, {
					name: "Report Description",
					id: "redDescription",
					type: "textarea",
					max: 75
				}],
				$formWrapper = $("<div class='data-form' />"),
				$formSection = $("<div class='form-section' />").appendTo($formWrapper);

			for (var i = 0; i < formElements.length; i++) {
				var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>" + formElements[i].name + "</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el, $custom, $note, _type = formElements[i].type;

				if (_type == "input") {
					$el = $("<input type='text' id='" + formElements[i].id + "' maxlength='" + formElements[i].max + "' style='width: 90%;' />");
				}

				if (_type == "textarea") {
					$el = $("<textarea id='" + formElements[i].id + "' style='width: 90%;'></textarea>");
				}

				if (_type == "select") {
					$custom = $("<div class='custom-select' style='width: 90%;' />");
					$el = $("<select id='" + formElements[i].id + "'></select>");
					if (formElements[i].data) {
						for (var d = 0; d < formElements[i].data.length; d++) {
							var $option = $("<option value=" + formElements[i].data[d].value + ">" + formElements[i].data[d].option + "</option>").appendTo($el)
						}
					}
					$el.appendTo($custom)
				}

				if (formElements[i].attributes) {
					for (var a = 0; a < formElements[i].attributes.length; a++) {
						$el.attr(formElements[i].attributes[a].name, formElements[i].attributes[a].value);
					}
				}

				if (formElements[i].events) {
					for (var e = 0; e < formElements[i].events.length; e++) {
						$el.on(formElements[i].events[e].event, formElements[i].events[e].action);
					}
				}

				if (_type == "select") {
					$custom.appendTo($data);
				} else {
					$el.appendTo($data);
				}



				if (formElements[i].note) {
					$note = $("<div class='data-note' style='margin-top: 10px;'>" + formElements[i].notevalue + "</div>").appendTo($data);
				}
			};

			var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
			var _dialog = {
				id: "DebitAdviceReportDialog",
				title: "Debit Advice",
				size: "small",
				icon: "<i class='fa fa-file-text'></i>",
				content: $formWrapper,
				buttons: [{
					name: "Cancel",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Ok",
					icon: "<i class='fa fa-check fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							downloadReport(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}

		function rejectInstructionReason(_target, item, instructionDialog) {
			var $target = _target;
			var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;

			var remainingamount;

			function rejectInstrution(dialog, instructionDialog) {

				var rejectReasonPassed = true;

				if ( $("#rejectReasonSelection").val() == '' ) {
					$("#rejectReasonRow").addClass("error");
					$("#rejectReasonError").show();
					rejectReasonPassed = false;
				} else {
					if ( $("#rejectReasonSelection").val() == 'r5' ) {
						if ( $("#rejectionReasonTextarea").val() === "" ) {
							$("#rejectReasonRow").addClass("error");
							$("#rejectReasonError").show();
							rejectReasonPassed = false;
						}						
					} else {
						$("#rejectReasonRow").removeClass("error");
						$("#rejectReasonError").hide();
						rejectReasonPassed = true;
					}			
				}



				var contractAmountsPassed = true;
				if (record.ratetype == "Contract" && record.individualdebitsflag == 0) {
					if (remainingamount == 0) {
						$("#fxContractUpdateRow").removeClass("error");
						$("#fxContractUpdateError").hide();
						contractAmountsPassed = true;
					} else {
						$("#fxContractUpdateRow").addClass("error");
						$("#fxContractUpdateError").show();
						contractAmountsPassed = false;
					}				
				}

				if ( rejectReasonPassed == true && contractAmountsPassed == true ) {
					$(".shell").addClass("loading");
					dialogHider(dialog)
					dialogHider(instructionDialog);
					setTimeout(function() {
						item.status = "Rejected";
						item.validated = "rejected";
						record.numberofrejectedpayments = record.numberofrejectedpayments + 1;
						record.numberofvalidpayments = parseInt(record.numberofpayments - record.numberofrejectedpayments);
						record.totalrejectedpaymentamount = parseFloat(record.totalrejectedpaymentamount + item.paymentamount).toFixed(2);
						record.totalrejecteddebitamount = parseFloat(record.totalrejecteddebitamount + item.debitequivalentamount).toFixed(2);
						record.netpaymentamount = parseFloat(record.totalpaymentamount - record.totalrejectedpaymentamount).toFixed(2);
						record.netdebitamount = parseFloat(record.totaldebitamount - record.totalrejecteddebitamount).toFixed(2);
						if ( record.numberofrejectedpayments > 1 ) {
							$("#numberOfRejectedItems").empty().html(record.numberofrejectedpayments);
							$("#numberOfValidItems").empty().html(record.numberofvalidpayments);
							$("#totalRejectedPaymentAmount").empty().html(record.paymentcurrency + " $" + addCommas(record.totalrejectedpaymentamount));
							$("#netPaymentAmount").empty().html(addCommas(record.paymentcurrency + " $" + record.netpaymentamount));
							if ( record.paymentcurrency != record.debitcurrency ) {
								$("#totalRejectedDebitAmount").empty().html(addCommas(record.debitcurrency + " $" + record.totalrejecteddebitamount));
								$("#netDebitAmount").empty().html(addCommas(record.debitcurrency + " $" + record.netdebitamount));
							}
						} else {
							var $rejectedCount = $("<div><span>Rejected Items:</span><span id='numberOfRejectedItems'>" + record.numberofrejectedpayments + "</span></div>").appendTo($("#totalBatchItems"));
							var $validCount = $("<div><span>Valid Items:</span><span id='numberOfValidItems'>" + record.numberofvalidpayments + "</span></div>").appendTo($("#totalBatchItems"));
							var $rejectedPaymentAmount = $("<div><span>Rejected Payment Amount:</span><span id='totalRejectedPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalrejectedpaymentamount) + "</span></div>").appendTo($("#totalBatchPaymentAmount"));
							var $netPaymentAmount = $("<div><span>Net Payment Amount:</span><span id='netPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.netpaymentamount) + "</span></div>").appendTo($("#totalBatchPaymentAmount"));
							if ( record.paymentcurrency != record.debitcurrency ) {
								var $rejectedDebitAmount = $("<div><span>Rejected Debit Amount:</span><span id='totalRejectedDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totalrejecteddebitamount) + "</span></div>").appendTo($("#totalBatchDebitAmount"));
								var $netDebitAmount = $("<div><span>Net Debit Amount:</span><span id='netDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.netdebitamount) + "</span></div>").appendTo($("#totalBatchDebitAmount"));
							}
						}
						reviewDataView.refresh();
						reviewGrid.invalidateAllRows();
						reviewGrid.render();
						dataView.refresh();
						grid.invalidateAllRows();
						grid.render();
						$(".shell").removeClass("loading");
						var msg = "Payment ID: <strong>" + item.id + "</strong> has been rejected."
						buildNotification(msg, 500, 5000);
					}, 1500);
				}
			}

			function handleContractUsedAmount(item) {
				var totalamount = (record.debitequivalentflag) ? parseFloat(record.totaldebitamount - item.debitequivalentamount).toFixed(2) : parseFloat(record.totalpaymentamount - item.paymentamount).toFixed(2),
					usedamount = 0,
					$span = $("<span />"),
					$remainingDiv = $("#remainingPaymentAmount");
				$remainingDiv.empty();
				if (totalamount > 0) {
					if ($("#useCardedRateFlag").attr("disabled")) {
						$("#useCardedRateFlag").attr("disabled", false).removeClass("disabled");
						$("#useCardedRateFlagLabel").removeClass("disabled");
					}
					if ($("input[data-contract-id]").size()) {
						$("input[data-contract-id]").each(function() {
							var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
							usedamount = usedamount + thisamount;
						});
					}
					remainingamount = (totalamount - usedamount).toFixed(2);
					if (remainingamount < 0 && !record.usecardedratewithcontrats) {
						$("#useCardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
						$("#useCardedRateFlagLabel").addClass("disabled");
					}
					if (record.usecardedratewithcontrats) {
						var cardedAmount = parseFloat($("#cardedRateRow").val().replace(/[^0-9\.]+/g, "")),
							updatedCardedAmount;
						if (remainingamount > 0) {
							updatedCardedAmount = (remainingamount + cardedAmount).toFixed(2);
							$("#cardedRateRow").val(addCommas(updatedCardedAmount));
							remainingamount = 0;
						} else if (remainingamount < 0) {
							updatedCardedAmount = (cardedAmount + remainingamount).toFixed(2);
							if (updatedCardedAmount >= 0) {
								$("#cardedRateRow").val(addCommas(updatedCardedAmount));
								remainingamount = 0;
							}
						}
					}
					batchRemainingAmount = remainingamount;
					if (remainingamount < 0) {
						$span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(remainingamount * -1) + "</span>");
					} else if (remainingamount > 0) {
						$span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(remainingamount) + "</span>");
					} else if (remainingamount == 0) {
						$span = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i> Remaining Amount: " + addCommas(remainingamount) + "</span>");
					}
					$span.appendTo($remainingDiv);
				} else {
					record.usecardedratewithcontrats = false;
					$("#useCardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
					$("#useCardedRateFlagLabel").addClass("disabled");
				}
			}

			if (record.ratetype == "Contract" && record.individualdebitsflag == 0) {
				var populateRejectReason = function(item) {
					var $form = $("<div class='form-section top-label' />");
					var $row = $("<div class='row' id='rejectReasonRow' />").appendTo($form);
					var $labelCol = $("<div class='label-column' />").appendTo($row);
					var $label = $("<label for='rejectionReasonTextarea'>Reason For Rejection</label>").appendTo($labelCol);
					var $dataCol = $("<div class='data-column' />").appendTo($row);
					var $customSelect = $("<div class='custom-select' style='width: 80%; display: block;' />").appendTo($dataCol);
					var $select = $("<select id='rejectReasonSelection'><option value=''></option><option value='r1'>Reason 1</option><option value='r2'>Reason 2</option><option value='r3'>Reason 3</option><option value='r4'>Reason 4</option><option value='r5'>Enter Other Reject Reason</option>").appendTo($customSelect).on("change", function(){
						$("#rejectReasonRow").removeClass("error");
						$("#rejectReasonError").hide();
						if ( $(this).val() === 'r5' ) {
							$("#rejectionReasonTextarea").show().focus();
						} else {
							$("#rejectionReasonTextarea").hide();
						}
					});					
					var $textarea = $("<textarea style='width: 425px; margin-top: 10px; height: 175px; display: none;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
					var $reasonError = $("<div class='data-error' id='rejectReasonError' style='display: none;'>Reject Reason is Required</div>").appendTo($dataCol);
					var $row = $("<div class='row' id='fxContractUpdateRow' />").appendTo($form);
					var $labelCol = $("<div class='label-column' />").appendTo($row);
					var $label = $("<label>Updates to the FX Contract Details are required when rejecting an instruction for this payment batch.</label>").appendTo($labelCol);
					var $dataCol = $("<div class='data-column' />").appendTo($row);
					var	$errorNotice = $("<div class='data-error' id='fxContractUpdateError' style='display: none;'>FX Contract Amounts must be corrected</div>").appendTo($dataCol);
					var	$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);

					var _remaining = 0;
					for (var x = 0, y = record.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(record.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' data-contract-row='true' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' />").appendTo($dataTableRow),
							$contractSpan = $("<span>" + record.contracts[x].reference + "</span>").appendTo($dataTableCell),
							$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + record.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;' />").appendTo($dataTableRow),
							$usedInput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + record.contracts[x].id + "' value='" + addCommas(record.contracts[x].used) + "' />").appendTo($dataTableCell).on("keydown", preventAlphaKeys).on("change", function() {
								var val = $(this).val(),
									cid = $(this).attr("data-contract-id"),
									_amount;
								if (val != '') {
									_amount = val.replace(/[^0-9\.]+/g, "");
									_amount = parseFloat(_amount).toFixed(2);
									$(this).val(addCommas(_amount));
								} else {
									$(this).val(0);
								}
								handleContractUsedAmount(item);
							});
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$cardedRateCheckbox = $("<input type='checkbox' id='usedCardedRateFlag' class='disabled' disabled='disabled' />").appendTo($dataTableCell),
						$cardedRateLabel = $("<label class='desc disabled no-error' id='useCardedRateFlagLabel' for='usedCardedRateFlag'>Use Carded Rate For Remaining Amount</label>").appendTo($dataTableCell),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' id='remainingPaymentAmount' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					var _totaldebitamount = record.totaldebitamount.replace(/[^0-9\.]+/g, "");
					var _totalpaymentamount = record.totalpaymentamount.replace(/[^0-9\.]+/g, "");			
					if (record.debitequivalentflag) {
						var _paymentdebitequivalentamount = item.debitequivalentamount.replace(/[^0-9\.]+/g, "");
						_totaldebitamount = _totaldebitamount - _paymentdebitequivalentamount;
						if (_remaining == _totaldebitamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < _totaldebitamount) {
							var _amt = (Number(_totaldebitamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > _totaldebitamount) {
							var _amt = (Number(_remaining) - Number(_totaldebitamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						var _paymentamount = item.paymentamount.replace(/[^0-9\.]+/g, "");
						_totalpaymentamount = _totalpaymentamount - _paymentamount;
						if (_remaining == _totalpaymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < _totalpaymentamount) {
							var _amt = (Number(_totalpaymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > _totalpaymentamount) {
							var _amt = (Number(_remaining) - Number(_totalpaymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}
					return $form;
				}

				var _dialog = {
					id: "rejectReason",
					title: "Enter A Reason For Rejection",
					size: "xxl",
					icon: "<i class='fa fa-ban'></i>",
					content: function() {
						return populateRejectReason(item)
					},
					buttons: [{
						name: "Cancel",
						icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								dialogHider(_dialog)
							}
						}]
					}, {
						name: "Ok",
						icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								rejectInstrution(_dialog, instructionDialog)
							}
						}],
						cssClass: "primary"
					}]
				}
			} else {
				var populateRejectReason = function() {
					var $form = $("<div class='form-section top-label' />");
					var $row = $("<div class='row' id='rejectReasonRow' />").appendTo($form);
					var $labelCol = $("<div class='label-column' />").appendTo($row);
					var $label = $("<label for='rejectionReasonTextarea'>Reason For Rejection</label>").appendTo($labelCol);
					var $dataCol = $("<div class='data-column' />").appendTo($row);
					var $customSelect = $("<div class='custom-select' style='width: 80%; display: block;' />").appendTo($dataCol);
					var $select = $("<select id='rejectReasonSelection'><option value=''></option><option value='r1'>Reason 1</option><option value='r2'>Reason 2</option><option value='r3'>Reason 3</option><option value='r4'>Reason 4</option><option value='r5'>Enter Other Reject Reason</option>").appendTo($customSelect).on("change", function(){
						$("#rejectReasonRow").removeClass("error");
						$("#rejectReasonError").hide();
						if ( $(this).val() === 'r5' ) {
							$("#rejectionReasonTextarea").show().focus();
						} else {
							$("#rejectionReasonTextarea").hide();
						}
					});
					var $textarea = $("<textarea style='width: 425px; height: 175px; margin-top: 10px; display:none;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
					var $reasonError = $("<div class='data-error' id='rejectReasonError' style='display: none;'>Reject Reason is Required</div>").appendTo($dataCol);
					return $form;
				}
				var _dialog = {
					id: "rejectReason",
					title: "Enter A Reason For Rejection",
					size: "small",
					icon: "<i class='fa fa-ban'></i>",
					content: function() {
						return populateRejectReason()
					},
					buttons: [{
						name: "Cancel",
						icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								dialogHider(_dialog)
							}
						}]
					}, {
						name: "Ok",
						icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								rejectInstrution(_dialog, instructionDialog)
							}
						}],
						cssClass: "primary"
					}]
				}
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			$("#rejectionReasonTextarea").focus();
		}

		function renderPaymentInstructionDetails() {

			var instruction = item;

			function triggerBeneficiaryDialog(_target) {

				function renderBeneficiaryData() {
					var bene = instruction.beneficiary;
					var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewBeneDialog' />");

					/* beneficiary section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Beneficiary Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benename + "</div>").appendTo($dataCol);
					if (bene.benelocalname != "") {
						var $row = $("<div class='row' />").appendTo($detailCell),
							$labelCol = $("<div class='label-column' />").appendTo($row),
							$label = $("<label>Beneficiary Local Language Name</label>").appendTo($labelCol),
							$dataCol = $("<div class='data-column' />").appendTo($row),
							$data = $("<div class='data-text'>" + bene.benelocalname + "</div>").appendTo($dataCol);
					}
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Number</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneaccount + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Type</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benetype + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress3 + ", " + bene.benepostal + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.benecity + "</div>").appendTo($break),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benecountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>E-mail</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneemail + "</div>").appendTo($dataCol);


					/* bank section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary Bank</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Clearing Code</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Bank Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Branch Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress3 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchcity + "</div>").appendTo($break);

					/* update section
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header-inline'>Update</div>").appendTo($box),
						$boxContent = $("<div class='box-content-inline' />").appendTo($box),
						$dataRow = $("<div class='row' />").appendTo($boxContent),
						$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow),
						$data = $("<input type='checkbox' id='updateAddressBook' />").appendTo($dataCol),
						$desc = $("<label class='desc' for='updateAddressBook'>Update beneficiary details in the Address Book</label>").appendTo($dataCol);
					 */

					return $dialogContent;
				}

				var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
				var _dialog = {
					id: "viewBeneDetails",
					title: "Beneficiary Details",
					size: "xl",
					icon: "<i class='fa fa-book'></i>",
					content: function() {
						return renderBeneficiaryData();
					},
					buttons: [{
						name: "Close",
						icon: "<i class='fa fa-times fa-fw'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								dialogHider(_dialog);
							}
						}]
					}]
				}

				dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			}

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.id + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.status + "</div>").appendTo($dataCol);


			if (instruction.status == "Needs Repair") {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
					$boxDiv = $("<div />").appendTo($boxContent),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>This payment instruction has the following errors:</div>").appendTo($dataCol),
					$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 200px; margin-top: 10px; overflow-y: scroll;' id='errorsGrid' />").appendTo($dataCol),
					$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
				for (var e = 0, f = instruction.errors.length; e < f; e++) {
					var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + instruction.errors[e].description + "</span></li>").appendTo($errorList);
				}
			}

			/* beneficiary section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>To</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Beneficiary</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' />").appendTo($dataCol),
				$link = $("<a href='javacript:void(0)' id='viewBeneDetailTrigger' style='color: #017dba;'>" + instruction.beneficiaryname + " <i class='fa fa-external-link fa-fw' style='vertical-align: middle;'></i></a>").appendTo($data).on("click", function(e) {
					e.preventDefault();
					triggerBeneficiaryDialog($(this))
				}),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.beneficiaryaccountnumber + "</div>").appendTo($dataCol);
			if (instruction.beneficiary.benelocalname != "") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Local Language Name</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.beneficiary.benelocalname + "</div>").appendTo($dataCol);
			}
			if (record.type.indexOf("International") != -1) {
				var bank = instruction.beneficiary.swiftbank,
					bankbranch = instruction.beneficiary.swiftbranch,
					bankcountry = instruction.beneficiary.swiftbankcountry,
					branchaddress1 = instruction.beneficiary.swiftbankaddress1,
					branchaddress2 = instruction.beneficiary.swiftbankaddress2,
					branchaddress3 = instruction.beneficiary.swiftbankaddress3,
					branchpostal = instruction.beneficiary.swiftbankpostal,
					branchcity = instruction.beneficiary.swiftbankcity,
					bankcode = instruction.beneficiary.swiftcode + " (SWIFT)";
			} else {
				var bank = instruction.beneficiary.benebank,
					bankbranch = instruction.beneficiary.benebankbranch,
					bankcountry = instruction.beneficiary.benebankcountry,
					branchaddress1 = instruction.beneficiary.benebankaddress1,
					branchaddress2 = instruction.beneficiary.benebankaddress2,
					branchaddress3 = instruction.beneficiary.benebankaddress3,
					branchpostal = instruction.beneficiary.benebankpostal,
					branchcity = instruction.beneficiary.benebankcity,
					bankcode = instruction.beneficiary.benebankclearingcode + " (" + instruction.beneficiary.benebankclearingtype + ")";
			}
			var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Bank Details</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataGroup),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Clearing</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol);

			/* payment details section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
			var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
			var $box = $("<div class='box' />").appendTo($sectionCell);
			var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
			var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
			var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);

			if (record.debitaccount.bank.country == "China") {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Payment Method</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text'>" + instruction.paymentmethod + "</div>").appendTo($dataCol);
			}

			if ( record.paymentcurrency != record.debitcurrency ) {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
	            var $innerRow = $("<div class='grid-row' />").appendTo($dataCol);
	            var $innerCell = $("<div class='grid-cell' style='margin-right: 50px;' />").appendTo($innerRow);
				var $row = $("<div class='row' style='padding: 0;' />").appendTo($innerCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
	            var $innerCell = $("<div class='grid-cell' />").appendTo($innerRow);
				var $row = $("<div class='row' style='padding: 0;' />").appendTo($innerCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
			} else {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
			}

			if (record.debitaccount.bank.country == "China" || record.paymentmethod == "RTGS") {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text'>" + instruction.paymentreference + "</div>").appendTo($dataCol);
			} else if (record.paymentmethod == "Direct Entry") {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Lodgement Reference</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text'>" + instruction.paymentreference + "</div>").appendTo($dataCol);
			} else if (record.paymentmethod == "Osko") {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>End-to-End ID</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text'>" + instruction.paymentreference + "</div>").appendTo($dataCol);
			}

			if (record.paymentmethod == "RTGS") {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Charges</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text'>" + instruction.charges + "</div>").appendTo($dataCol);
			}


			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);


			if (record.paymentmethod == "Direct Entry") {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Witholding Tax</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<div class='data-text'>" + instruction.witholdingtaxindicator + "</div>").appendTo($dataCol);
				var $data = $("<div class='data-text'>" + instruction.witholdingtaxamount + "</div>").appendTo($dataCol);
			}


			if ( record.debitaccount.bank.country == "Australia") {
				if (record.paymentmethod == "Direct Entry" || record.paymentmethod == "Osko") {
					var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
					var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
					var $row = $("<div class='row' />").appendTo($detailCell);
					var $labelCol = $("<div class='label-column' />").appendTo($row);
					var $label = $("<label>Remitter Name</label>").appendTo($labelCol);
					var $dataCol = $("<div class='data-column' />").appendTo($row);
					var $data = $("<div class='data-text'>" + instruction.remitter + "</div>").appendTo($dataCol);
					if (record.paymentmethod == "Direct Entry") {
						var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
						var $row = $("<div class='row' />").appendTo($detailCell);
						var $labelCol = $("<div class='label-column' />").appendTo($row);
						var $label = $("<label>Transaction Code</label>").appendTo($labelCol);
						var $dataCol = $("<div class='data-column' />").appendTo($row);
						var $data = $("<div class='data-text'>" + instruction.transactioncode + "</div>").appendTo($dataCol);
						var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
						var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
						var $row = $("<div class='row' />").appendTo($detailCell);
						var $labelCol = $("<div class='label-column' />").appendTo($row);
						var $label = $("<label>Trace Account</label>").appendTo($labelCol);
						var $dataCol = $("<div class='data-column' />").appendTo($row);
						var $data = $("<div class='data-text'>" + instruction.traceaccount + "</div>").appendTo($dataCol);
					}
				}
			}


			/* OPTIONAL INFORMATION */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
			var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
			var $box = $("<div class='box' />").appendTo($sectionCell);
			var $boxHeader = $("<div class='box-header'>Optional Information</div>").appendTo($box);
			var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
			var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
			var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
			if (record.individualdebitsflag) {
				var $row = $("<div class='row' />").appendTo($detailCell);
				var $labelCol = $("<div class='label-column' />").appendTo($row);
				var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
				var $dataCol = $("<div class='data-column' />").appendTo($row);
				var $data = $("<textarea id='paymentDebitAdviceDescription' style='width: 80%; height: 80px;' disabled='disabled' >" + instruction.debitadvicedescription + "</textarea>").appendTo($dataCol);
			}
			var $row = $("<div class='row' />").appendTo($detailCell);
			var $labelCol = $("<div class='label-column' />").appendTo($row);
			var $label = $("<label>Invoice Details</label>").appendTo($labelCol);
			var $dataCol = $("<div class='data-column' />").appendTo($row);
			var $data = $("<textarea id='invoiceDetails' style='width: 80%; height: 175px;' disabled='disabled' ></textarea>").appendTo($dataCol);




			/* FX SECTION */
			if ((record.paymentcurrency != record.debitcurrency) && record.individualdebitsflag) {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($dataRow),
					$label = $("<label>Rate Type</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>" + instruction.ratetype + "</div>").appendTo($dataCol);
				if (instruction.ratetype == "Carded") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>Rate</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-text'>" + instruction.rate + " &nbsp;&nbsp; 1 " + instruction.fromccy + " &nbsp; = &nbsp; " + (1 * instruction.rate) + " " + instruction.toccy + "</div>").appendTo($dataCol);
				} else if (instruction.ratetype == "Contract") {
					var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
					var _remaining = 0;
					for (var x = 0, y = instruction.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(instruction.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].reference + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + instruction.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].used) + "</div>").appendTo($dataTableRow);
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					if (record.debitequivalentflag) {
						if (_remaining == instruction.debitequivalentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.debitequivalentamount) {
							var _amt = (Number(instruction.debitequivalentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.debitequivalentamount) {
							var _amt = (Number(_remaining) - Number(instruction.debitequivalentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						if (_remaining == instruction.paymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.paymentamount) {
							var _amt = (Number(instruction.paymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.paymentamount) {
							var _amt = (Number(_remaining) - Number(instruction.paymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}
				}
				var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
			}

			/* supporting documents section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);

			for (var x = 0, y = instruction.supportingdocs.length; x < y; x++) {
				_doc = instruction.supportingdocs[x];
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
			}

			return $dialogContent;
		}

		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "viewPaymentInstruction",
			title: "Beneficiary Payment Instruction",
			size: "xxl",
			icon: "<i class='fa fa-money'></i>",
			content: function() {
				return renderPaymentInstructionDetails();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Beneficiary Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						triggerBeneficiaryAdviceDialog($(this))
					}
				}],
				cssClass: "primary"
			}, {
				name: "Debit Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						triggerDebitAdviceDialog($(this))
					}
				}],
				cssClass: "primary"
			}]
		}
		if (record.type.indexOf("International") != -1) {
			var mt103 = {
				name: "MT103",
				icon: "<i class='fa fa-download fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog);
					}
				}],
				cssClass: "primary"
			}
			_dialog.buttons.push(mt103)
		}
		if (record.status == "Pending Approval") {
			var rejectInstruction = {
				name: "Reject",
				icon: "<i class='fa fa-ban fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e){
						e.preventDefault();
						rejectInstructionReason($(e.target), item, _dialog)
					}
				}]
			}
			_dialog.buttons.push(rejectInstruction)
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* SETUP THE REVIEW GRID */
	var reviewDataView;
	var reviewGrid;
	var reviewData = [];
	var reviewColumns = [{
		id: "number",
		name: "#",
		field: "number",
		toolTip: "Item Number",
		width: 40,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: false,
	    focusable: false,
        maxWidth: 75,
        minWidth: 40
	}, {
		id: "validated",
		name: "<i class='fa fa-check-circle fa-fw' style='color: #4d5d69;'></i>",
		field: "validated",
		toolTip: "Payment Validation",
		width: 50,
		headerCssClass: "centered",
		cssClass: "centered",
        sortable: false,
        visible: true,
        resizable: false,
        focusable: true,
		formatter: Slick.Formatters.ValidatedIconFormatter
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 200,
        sortable: true,
        visible: true,
        resizable: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryaccountnumber",
		name: "Account",
		field: "beneficiaryaccountnumber",
		toolTip: "Beneficiary Account",
        width: 175,
        sortable: true,
        visible: true,
        resizable: true,
        focusable: false,
		sorter: "sorterStringCompare"
	}, {
		id: "status",
		name: "Status",
		field: "status",
		toolTip: "Status",
		width: 150,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}];
	if (record.debitequivalentflag) {
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
            width: 125,
            sortable: true,
            visible: true,
            resizable: true,
			formatter: CurrencyAndAmountFormatter
		}
	} else {
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
            width: 125,
            sortable: true,
            visible: true,
            resizable: true,
			formatter: CurrencyAndAmountFormatter
		}
	}
	reviewColumns.push(amountColumn);
	if (record.paymentmethod == "Osko") {
		var refColumn = {
            id: "paymentreference",
            name: "End-to-End ID",
            field: "paymentreference",
            toolTip: "End-to-End ID",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare"
        }
        reviewColumns.splice(5, 0, refColumn);
	} else {
		var refColumn = {
            id: "paymentreference",
            name: "Reference",
            field: "paymentreference",
            toolTip: "Reference",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare"
        }
        reviewColumns.splice(4, 0, refColumn);
	}
    if ( record.debitaccount.bank.country == "China" && record.type.indexOf("Domestic") != -1 ) {
        var methodColumn = {
            id: "paymentmethod",
            name: "Method",
            field: "paymentmethod",
            toolTip: "Method",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare"
        }
        reviewColumns.splice(4, 0, methodColumn);
    }
    function CurrencyAndAmountFormatter(row, cell, value, columnDev, dataContext) {
        if (record.debitequivalentflag) {
            return dataContext.debitaccountcurrency + " $" + addCommas(parseFloat(dataContext.debitequivalentamount).toFixed(2));
        } else {
            return dataContext.paymentcurrency + " $" + addCommas(parseFloat(dataContext.paymentamount).toFixed(2));
        }
    }
	var reviewOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};

	/* PAYMENT PAGE */
	var $paymentDetailSection = $("#paymentDetailScreen");
	$paymentDetailSection.empty();


	/* CONTROL BAR */
	var $topControls = $("<div class='top-controls' />");
	var $controlList = $("<ul class='control-list' />").appendTo($topControls);


	/* ACTION BUTTON GROUP */
	var $recordActionButtonGroup = $("<div class='btn-group' />");
	if ( record.status == "Draft" || record.status == "Approver Rejected" || record.status == "Needs Repair" ) {
		var $editButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$editAnchor = $("<a href='#edit' title='Edit Payment' />").appendTo($editButton).on("click", function(e) {
				e.preventDefault();
				$("#paymentDetailScreen").empty().addClass("loading");
				reviewGrid.destroy();
				reviewGrid = null;
				reviewDataView = null;
				reviewData = [];
				reviewColumns = [];
				$(window).off("resize.reviewgrid");
				editPaymentDetails(record);
				setTimeout(function() {
					$("#paymentDetailScreen").removeClass("loading").scrollTop(0);
					if ($(".ie8").size() > 0) {
						var $icons = $(target).find(".fa");
						$icons.addClass("repaint");
						setTimeout(function() {
							$icons.removeClass("repaint")
						}, 1)
					}
				}, 500);
			}),
			$editIcon = $("<i class='fa fa-pencil-square-o fa-fw text-right'></i>").appendTo($editAnchor),
			$editText = $("<span>Edit</span>").appendTo($editAnchor);
		var $deleteButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$deleteAnchor = $("<a href='#delete' title='Delete Payment' />").appendTo($deleteButton).on("click", deleteRecordFromList),
			$deleteIcon = $("<i class='fa fa-trash fa-fw text-right'></i>").appendTo($deleteAnchor),
			$deleteText = $("<span>Delete</span>").appendTo($deleteAnchor);
		if (record.status != "Needs Repair") {
			var $submitButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
				$submitAnchor = $("<a href='#submit' title='Submit Payment' />").appendTo($submitButton).on("click", submitRecordFromList),
				$submitIcon = $("<i class='fa fa-share-square-o fa-fw text-right'></i>").appendTo($submitAnchor),
				$submitText = $("<span>Submit</span>").appendTo($submitAnchor);
		}
	} else if ( record.status == "Needs Rate") {
		var $rateButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$rateAnchor = $("<a href='#rate' title='Get Rate' />").appendTo($rateButton).on("click", getDynamicRate),
			$rateIcon = $("<i class='fa fa-exchange fa-fw text-right'></i>").appendTo($rateAnchor),
			$rateText = $("<span>Get Rate</span>").appendTo($rateAnchor);
		var $recallButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$recallAnchor = $("<a href='#recall' title='Recall Payment' />").appendTo($recallButton).on("click", recallRecordFromList),
			$recallIcon = $("<i class='fa fa-rotate-left fa-fw text-right'></i>").appendTo($recallAnchor),
			$recallText = $("<span>Recall</span>").appendTo($recallAnchor);
	} else if ( record.status == "Pending Approval" ) {
		var $approveButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$approveAnchor = $("<a href='#approve' title='Approve Payment' />").appendTo($approveButton).on("click", approveRecordFromList),
			$approveIcon = $("<i class='fa fa-check-square fa-fw text-right pos'></i>").appendTo($approveAnchor),
			$approveText = $("<span>Approve</span>").appendTo($approveAnchor);
		var $rejectButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$rejectAnchor = $("<a href='#reject' title='Reject Payment' />").appendTo($rejectButton).on("click", rejectRecordReason),
			$rejectIcon = $("<i class='fa fa-window-close fa-fw text-right neg'></i>").appendTo($rejectAnchor),
			$rejectText = $("<span>Reject</span>").appendTo($rejectAnchor);
		var $recallButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$recallAnchor = $("<a href='#recall' title='Recall Payment' />").appendTo($recallButton).on("click", recallRecordFromList),
			$recallIcon = $("<i class='fa fa-rotate-left fa-fw text-right'></i>").appendTo($recallAnchor),
			$recallText = $("<span>Recall</span>").appendTo($recallAnchor);
	} else if ( record.status == "Warehoused" ) {
		var $stopButton = $("<span class='btn' />").appendTo($recordActionButtonGroup),
			$stopAnchor = $("<a href='#stop' title='Stop Payment' />").appendTo($stopButton).on("click", stopRecordFromList),
			$stopIcon = $("<i class='fa fa-stop fa-fw text-right'></i>").appendTo($stopAnchor),
			$stopText = $("<span>Stop</span>").appendTo($stopAnchor);
	}
	var $reportsButton = $("<span class='btn has-menu' />").appendTo($recordActionButtonGroup).on("click", controlMenuManager),
		$reportsAnchor = $("<a href='#detailScreenReportMenu' title='Reports' />").appendTo($reportsButton),
		$reportsIcon = $("<i class='fa fa-file-text fa-fw text-right'></i>").appendTo($reportsAnchor),
		$reportsText = $("<span>Reports</span>").appendTo($reportsAnchor);
		$reportsMenuIcon = $("<i class='fa fa-caret-down fa-fw menu-arrow'></i>").appendTo($reportsAnchor);
	var $actionButton = $("<span class='btn has-menu' />").appendTo($recordActionButtonGroup).on("click", controlMenuManager),
		$actionAnchor = $("<a href='#moreActionsMenu' title='Actions' />").appendTo($actionButton),
		$actionIcon = $("<i class='fa fa-ellipsis-v fa-fw text-right'></i>").appendTo($actionAnchor),
		$actionText = $("<span>Actions</span>").appendTo($actionAnchor);
		$actionMenuIcon = $("<i class='fa fa-caret-down fa-fw menu-arrow'></i>").appendTo($actionAnchor);


	/* CLOSE PREVIOUS NEXT BUTTON GROUP */
	var $recordNavigationButtonGroup = $("<div class='btn-group' />");
	var $closeButton = $("<span class='btn' />").appendTo($recordNavigationButtonGroup),
		$closeAnchor = $("<a href='#paymentsGrid' title='Close Record' data-action='close' data-panel='#paymentsGrid' data-switch='switch-panels' />").appendTo($closeButton).appendTo($closeButton).on("click", function(e) {
			window.record = null;
			reviewGrid = null;
			reviewDataView = null;
			reviewData = [];
			reviewColumns = [];
			$(window).off("resize.reviewgrid");
			$("#viewPaymentContent").remove();
			updateBreadcrumb("close");
		}),
		$closeIcon = $("<i class='fa fa-times fa-fw text-right'></i>").appendTo($closeAnchor),
		$closeText = $("<span>Close</span>").appendTo($closeAnchor);
	var $previousButton = $("<span class='btn' />").appendTo($recordNavigationButtonGroup),
		$previousAnchor = $("<a href='#previousRecord' title='Previous Record' data-action='previous' />").appendTo($previousButton),
		$previousIcon = $("<i class='fa fa-chevron-left fa-fw text-right'></i>").appendTo($previousAnchor),
		$previousText = $("<span>Previous Record</span>").appendTo($previousAnchor);
	var $nextButton = $("<span class='btn' />").appendTo($recordNavigationButtonGroup),
		$nextAnchor = $("<a href='#nextRecord' title='Next Record' data-action='previous' />").appendTo($nextButton),
		$nextIcon = $("<i class='fa fa-chevron-right fa-fw text-right'></i>").appendTo($nextAnchor),
		$nextText = $("<span>Next Record</span>").appendTo($nextAnchor);


	/* ATTACH BUTTONS AND CONTROL BAR */
	$recordActionButtonGroup.appendTo($controlList);
	$recordNavigationButtonGroup.appendTo($controlList);
	$topControls.appendTo($paymentDetailSection);


	/* PAYMENT DETAIL CONTAINER */
	var $paymentDetailContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; background: #f5f5f5;' id='viewPaymentContent' />");
	

	/* PAYMENT LAYOUT CONTAINER */
	var $paymentDataSection = $("<div class='grid-layout' />").appendTo($paymentDetailContainer);


	/* HEADING SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
	var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
	var $box = $("<div class='box' />").appendTo($sectionCell);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $detailCell = $("<div class='grid-cell' style='width: 65%;' />").appendTo($detailRow);
	var $dataRow = $("<div class='row' />").appendTo($detailCell);
	var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
	var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
	var	$data = $("<div class='data-text'><span class='large-blue-text'>" + record.type + " Payment ID: " + record.batchid + "</span></div>").appendTo($dataGroup);
	var	$detailCell = $("<div class='grid-cell' style='width: 35%;' />").appendTo($detailRow);
	var $dataRow = $("<div class='row' />").appendTo($detailCell);
	var $dataCol = $("<div class='data-column text-right' />").appendTo($dataRow);
	var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
	var $data = $("<div class='data-text'><strong style='font-size: 16px;'>"+record.paymentcurrency+"</strong> <span class='large-blue-text'>$" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($dataGroup);
	var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $detailCell = $("<div class='grid-cell' style='width: 65%;' />").appendTo($detailRow);
	var $dataRow = $("<div class='row' style='padding-top: 5px;' />").appendTo($detailCell);
	var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
	var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
	var $data = $("<div class='data-text'><strong>Value Date:</strong> " + record.paymentdate + " - <strong>Cut off time:</strong> " + record.cutofftime + "</div>").appendTo($dataGroup);
	if (record.filereference) {
		var $data = $("<div class='data-text'><strong>File Reference:</strong> " + record.filereference + "</div>").appendTo($dataGroup);
	}
	var	$detailCell = $("<div class='grid-cell' style='width: 35%;' />").appendTo($detailRow);
	var $dataRow = $("<div class='row' style='padding-top: 5px;' />").appendTo($detailCell);
	var $dataCol = $("<div class='data-column text-right' />").appendTo($dataRow);
	var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
	var $data = $("<div class='data-text'><strong>Status:</strong> " + record.status + "</div>").appendTo($dataGroup);


	/* ALERTS AND ERRORS SECTION */
	if (record.notices == 1) {
		function dynamicSort(property) {
			var sortOrder = 1;
			if (property[0] === "-") {
				sortOrder = -1;
				property = property.substr(1);
			}
			return function(a, b) {
				var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
				return result * sortOrder;
			}
		}
		record.noticeitems.sort(dynamicSort("type")).reverse();
		var _haserrors = false;
		for (var e = 0, f = record.noticeitems.length; e < f; e++) {
			if (record.noticeitems[e].type == "error") {
				_haserrors = true;
				break;
			}
		}
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell);
		if (_haserrors) {
			var $boxHeader = $("<div class='box-header'>Payment Errors and Alerts</div>").appendTo($box);
		} else {
			var $boxHeader = $("<div class='box-header'>Payment Alerts</div>").appendTo($box);
		}
		var	$boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$errorGrid = $("<div class='error-grid' id='errorsGrid' />").appendTo($dataCol),
			$errorList = $("<ul class='error-list' />").appendTo($errorGrid);

		for (var e = 0, f = record.noticeitems.length; e < f; e++) {
			var _class = (record.noticeitems[e].type == "error") ? "error-icon" : "alert-icon";
			var $errorLi = $("<li><span class='" + _class + "'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + record.noticeitems[e].description + "</span></li>").appendTo($errorList);
		}
	}


	/* DIVISION & FROM ACCOUNT SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
	var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
	var $box = $("<div class='box'/>").appendTo($sectionCell);
	var $boxHeader = $("<div class='box-header'>From</div>").appendTo($box);
	var $boxContent = $("<div class='box-content' />").appendTo($box);
	var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
	var $dataRow = $("<div class='row' />").appendTo($detailCell);
	var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
	var $data = $("<div class='data-text'><strong>"+record.division+"</strong></div>").appendTo($dataCol);
	var $dataRow = $("<div class='row' />").appendTo($detailCell);
	var $dataCol = $("<div class='data-column full' />").appendTo($dataRow);
	var	$selectionComponentDiv = $("<div class='selection-display' />").appendTo($dataCol);
	var $selectionDetail = $("<div class='selection-display-detail' />").appendTo($selectionComponentDiv);
	var $selectionContent = $("<div class='selection-content' />").appendTo($selectionDetail);
	var $selectionContentLeft = $("<div class='selection-content-left' />").appendTo($selectionContent);
	var $selectionAccountCurrency = $("<div class='selected-account-currency'>"+record.debitcurrency+"</div>").appendTo($selectionContentLeft);
	var $selectionAccountName = $("<div class='selected-account-name'>"+record.debitaccountname+"</div>").appendTo($selectionContentLeft);
	var $selectionAccountNumber = $("<div class='selected-account-number'>"+record.debitaccountnumber+"</div>").appendTo($selectionContentLeft);
	var $selectionContentRight = $("<div class='selection-content-right' />").appendTo($selectionContent);
	var $selectionAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectionContentRight);
	var $selectionAccountBalanceLabel = $("<div>Available Balance</div>").appendTo($selectionAccountBalance);
	var $selectionAccountBalanceValue = $("<div>"+addCommas(record.debitaccount.availablebalance)+"</div>").appendTo($selectionAccountBalance);
	var $selectionAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectionContentRight);
	var $selectionAccountFundsLabel = $("<div>Available Funds</div>").appendTo($selectionAccountFunds);
	var $selectionAccountFundsValue = $("<div>"+addCommas(record.debitaccount.availablefunds)+"</div>").appendTo($selectionAccountFunds);
	var $selectionAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectionContentRight);
	var $selectionAccountDetailAnchor = $("<a href='#accountdetail' title='View Account Details' id='viewDebitAccountDetailsDialog'><i class='fa fa-file-text fa-fw'></i></a>").appendTo($selectionAccountDetail).on("click", showDebitAccountDetailsDialog);


	/* CREDIT ACCOUNT SECTION */
	if (record.type == "Account Transfer") {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
		var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
		var $box = $("<div class='box'/>").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>To</div>").appendTo($box);
		var $boxContent = $("<div class='box-content' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column full' />").appendTo($dataRow);
		var	$selectionComponentDiv = $("<div class='selection-display' />").appendTo($dataCol);
		var $selectionDetail = $("<div class='selection-display-detail' />").appendTo($selectionComponentDiv);
		var $selectionContent = $("<div class='selection-content' />").appendTo($selectionDetail);
		var $selectionContentLeft = $("<div class='selection-content-left' />").appendTo($selectionContent);
		var $selectionAccountCurrency = $("<div class='selected-account-currency'>"+record.creditcurrency+"</div>").appendTo($selectionContentLeft);
		var $selectionAccountName = $("<div class='selected-account-name'>"+record.creditaccountname+"</div>").appendTo($selectionContentLeft);
		var $selectionAccountNumber = $("<div class='selected-account-number'>"+record.creditaccountnumber+"</div>").appendTo($selectionContentLeft);
		var $selectionContentRight = $("<div class='selection-content-right' />").appendTo($selectionContent);
		var $selectionAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectionContentRight);
		var $selectionAccountBalanceLabel = $("<div>Available Balance</div>").appendTo($selectionAccountBalance);
		var $selectionAccountBalanceValue = $("<div>"+addCommas(record.creditaccount.availablebalance)+"</div>").appendTo($selectionAccountBalance);
		var $selectionAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectionContentRight);
		var $selectionAccountFundsLabel = $("<div>Available Funds</div>").appendTo($selectionAccountFunds);
		var $selectionAccountFundsValue = $("<div>"+addCommas(record.creditaccount.availablefunds)+"</div>").appendTo($selectionAccountFunds);
		var $selectionAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectionContentRight);
		var $selectionAccountDetailAnchor = $("<a href='#accountdetail' title='View Account Details' id='viewDebitAccountDetailsDialog'><i class='fa fa-file-text fa-fw'></i></a>").appendTo($selectionAccountDetail).on("click", showCreditAccountDetailsDialog);
	}


	/* PAYMENT METHOD SECTION */
	if (record.type == "Domestic" || record.type == "Domestic Salary") {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
		var	$sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
		var	$box = $("<div class='box'/>").appendTo($sectionCell);
		var	$boxHeader = $("<div class='box-header'>Payment Method</div>").appendTo($box);
		var	$boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var	$detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var	$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var	$dataRow = $("<div class='row' />").appendTo($detailCell);
		var	$dataCol = $("<div class='data-column' />").appendTo($dataRow);
		if ( record.debitaccount.bank.country == "China" ) {
			var $data = $("<div class='data-text'>For domestic payments originating in China the Payment Method is selected along with the beneficiary account.</div>").appendTo($dataCol);
		} else if ( record.debitaccount.bank.country == "Australia" ) {
			var $data = $("<div class='data-text'>"+record.paymentmethod+"</div>").appendTo($dataCol);
		}
	}


	/* BATCH DETAILS SECTION */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
	var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
	var $box = $("<div class='box' />").appendTo($sectionCell);
	var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
	var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
	var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
	var $dataRow = $("<div class='row' />").appendTo($detailCell);
	var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
	var $label = $("<label>Value Date</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
	var $data = $("<div class='data-text'>" + record.paymentdate + "</div>").appendTo($dataCol);
	var $data = $("<div class='data-text'>Cut-off Time: 23:59 AEST</div>").appendTo($dataCol);
	var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
	var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
	if (record.type == "Account Transfer") {
		if (record.paymentcurrency != record.debitcurrency) {
			var $dataRow = $("<div class='row' />").appendTo($detailCell);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $gridRow = $("<div class='grid-row' />").appendTo($dataCol);
			var $gridCell = $("<div class='grid-cell' style='margin-right: 20px;' />").appendTo($gridRow);
			var $dataRow = $("<div class='row' style='padding: 0;' />").appendTo($gridCell);
			var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
			var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $data = $("<div class='data-text'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</div>").appendTo($dataCol);
			var $gridCell = $("<div class='grid-cell' />").appendTo($gridRow);
			var $dataRow = $("<div class='row' style='padding: 0;' />").appendTo($gridCell);
			var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
			var $label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $data = $("<div class='data-text'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</div>").appendTo($dataCol);
			var $dataRow = $("<div class='row' style='padding-top: 5px; margin-bottom: -15px;' />").appendTo($detailCell);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $data = $("<input type='checkbox' disabled='disabled' class='disabled' />").appendTo($dataCol);
			var $desc = $("<label class='desc' style='cursor: default;'>Enter Amounts in Debit Currency</label>").appendTo($dataCol);
			if (record.debitequivalentflag) {
				$data.prop("checked", true);
			}
		} else {
			var $dataRow = $("<div class='row' />").appendTo($detailCell);
			var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
			var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $data = $("<div class='data-text'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</div>").appendTo($dataCol);
		}
	} else {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Payment Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.name + "</div>").appendTo($dataCol);
	}
	if (record.debitaccount.bank.country == "Australia" && record.paymentmethod == "Osko") {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>End-to-End ID</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.batchreference + "</div>").appendTo($dataCol);
	} else {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.batchreference + "</div>").appendTo($dataCol);
	}
	if (record.type != "Account Transfer" && record.debitaccount.bank.country != "Australia") {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Payment Currency</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.paymentcurrency + "</div>").appendTo($dataCol);
		if (record.paymentcurrency != record.debitcurrency) {
			var $dataRow = $("<div class='row' style='padding-top: 5px;' />").appendTo($detailCell);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $data = $("<input type='checkbox' disabled='disabled' class='disabled' />").appendTo($dataCol);
			var $desc = $("<label class='desc' style='cursor: default;'>Enter Amounts in Debit Currency</label>").appendTo($dataCol);
			if (record.debitequivalentflag) {
				$data.prop("checked", true);
			}
		}
	}
	if ( record.type != "Account Transfer" && (record.paymentmethod == "Osko" || record.debitaccount.bank.country == "China")) {
		var $dataRow = $("<div class='row' style='padding-top: 5px;' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<input type='checkbox' disabled='disabled' class='disabled' />").appendTo($dataCol);
		var $desc = $("<label class='desc' style='cursor: default;'>Individual Debits</label>").appendTo($dataCol);
		if (record.individualdebitsflag) {
			$data.prop("checked", true);
		}
		if (record.debitaccount.bank.country == "China" && record.type.indexOf("Domestic") != -1) {
			var $data = $("<input type='checkbox' disabled='disabled' class='disabled' />").appendTo($dataCol);
			var $desc = $("<label class='desc' style='cursor: default;'>Urgent</label>").appendTo($dataCol);
			if (record.urgentflag) {
				$data.prop("checked", true);
			}
		}
	}
	var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
	if (record.type == "Account Transfer") {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Debit Statement Narrative</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.debitstatementnarrative + "</div>").appendTo($dataCol);

		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Credit Statement Narrative</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.creditstatementnarrative + "</div>").appendTo($dataCol);
	}
	if (record.paymentmethod != "RTGS" && record.type.indexOf("Domestic") != -1 && record.debitaccount.bank.country != "China") {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Statement Narrative</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.paymentcurrency + "</div>").appendTo($dataCol);		
	}
	if (record.paymentmethod == "Direct Entry") {
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Direct Entry ID</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<div class='data-text'>" + record.paymentcurrency + "</div>").appendTo($dataCol);
	}
	if ( (record.type.indexOf("Domestic") != -1 && record.debitaccount.bank.country == "China") || record.paymentmethod == "Osko") {
		if (!record.individualdebitsflag) {
			var $dataRow = $("<div class='row' />").appendTo($detailCell);
			var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
			var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
			var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
			var $data = $("<textarea style='width: 95%; height: 100px;' disabled='disabled' class='disabled' id='viewBatchDescriptionField'>" + record.debitadvicedescription + "</textarea>").appendTo($dataCol);
		}
	}

	/* BENEFICIARIES SECTION */
	if (record.type != "Account Transfer") {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Beneficiaries</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
		var $boxDiv = $("<div />").appendTo($boxContent);
		var $dataRow = $("<div class='row' />").appendTo($boxDiv);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $div = $("<div style='padding: 0 0 10px 0;' />").appendTo($dataCol);
	    var $filterButton = $("<span class='btn'>").appendTo($div);
	    var $filterAnchor = $("<a href='javascript:void(0)' title='Filter beneficiary instructions'><i class='fa fa-filter fa-fw text-right'></i><span>Filter</span></a>").appendTo($filterButton).on("focus blur", function(e) {
	        $(this).parent().toggleClass("focused", e.type === "focus")
	    });
		var $paymentInstructionGrid = $("<div class='payment-grid' id='viewPaymentsGrid' />").appendTo($dataCol);
		var $batchTotalsSection = $("<div class='bottom-controls' />").appendTo($dataCol);
		var $batchTotalsTable = $("<div class='bottom-control-table' />").appendTo($batchTotalsSection);
		var $selectedItemsCount = $("<div class='control-list' style='width: 100%;' />").appendTo($batchTotalsTable);
		var $batchTotalControlList = $("<div class='control-list' />").appendTo($batchTotalsTable);
		var $batchTotalsDiv = $("<div style='display: inline-block;' />").appendTo($batchTotalControlList);
		var $batchTotalsRow = $("<div class='totals-row' />").appendTo($batchTotalsDiv);
		var $batchTotalItems = $("<div class='payment-amount-total' id='totalBatchItems' />").appendTo($batchTotalsRow);
		var $batchTotalItemCount = $("<div><span>Total Number of Items:</span><span id='NumberOfPayments'>" + record.numberofpayments + "</span></div>").appendTo($batchTotalItems);
		if (record.paymentcurrency != record.debitcurrency) {
			if (record.debitequivalentflag) {
				var $totalPYAmount = $("<div class='payment-amount-total' id='totalBatchPaymentAmount' />").appendTo($batchTotalsRow),
					$totalAmountItem = $("<div><span>Total Payment Amount:</span><span id='TotalPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($totalPYAmount),
					$totalDBAmount = $("<div class='payment-amount-total' id='totalBatchDebitAmount' />").appendTo($batchTotalsRow),
					$totalAmountItem = $("<div><span>Total Debit Amount:</span><span id='TotalDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</span></div>").appendTo($totalDBAmount);
			} else {
				var $totalDBAmount = $("<div class='payment-amount-total' id='totalBatchDebitAmount' />").appendTo($batchTotalsRow),
					$totalAmountItem = $("<div><span>Total Debit Amount:</span><span id='TotalDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</span></div>").appendTo($totalDBAmount),
					$totalPYAmount = $("<div class='payment-amount-total' id='totalBatchPaymentAmount' />").appendTo($batchTotalsRow),
					$totalAmountItem = $("<div><span>Total Payment Amount:</span><span id='TotalPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($totalPYAmount);
			}
		} else {
			var $totalPYAmount = $("<div class='payment-amount-total' id='totalBatchPaymentAmount' />").appendTo($batchTotalsRow),
				$totalAmountItem = $("<div><span>Total Payment Amount:</span><span id='TotalPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</span></div>").appendTo($totalPYAmount);
		}
		if ( record.numberofrejectedpayments != 0 ) {
			var $batchTotalRejectedCount = $("<div><span>Rejected Items:</span><span id='numberOfRejectedItems'>" + record.numberofrejectedpayments + "</span></div>").appendTo($batchTotalItems);
			var $batchTotaValidCount = $("<div><span>Valid Items:</span><span id='numberOfValidItems'>" + record.numberofvalidpayments + "</span></div>").appendTo($batchTotalItems);
			var $rejectedPaymentAmount = $("<div><span>Rejected Payment Amount:</span><span id='totalRejectedPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.totalrejectedpaymentamount) + "</span></div>").appendTo($totalPYAmount);
			var $netPaymentAmount = $("<div><span>Net Payment Amount:</span><span id='netPaymentAmount'>" + record.paymentcurrency + " $" + addCommas(record.netpaymentamount) + "</span></div>").appendTo($totalPYAmount);		
			if (record.paymentcurrency != record.debitcurrency) {
				var $rejectedDebitAmount = $("<div><span>Rejected Debit Amount:</span><span id='totalRejectedDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.totalrejecteddebitamount) + "</span></div>").appendTo($totalDBAmount);
				var $netDebitAmount = $("<div><span>Net Debit Amount:</span><span id='netDebitAmount'>" + record.debitcurrency + " $" + addCommas(record.netdebitamount) + "</span></div>").appendTo($totalDBAmount);	
			}
		}
	}

	/* FX SECTION */
	if ((record.paymentcurrency != record.debitcurrency) && !record.individualdebitsflag) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Rate Type</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + record.ratetype + "</div>").appendTo($dataCol);
		if (record.ratetype == "Carded") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Rate</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.rate + " &nbsp;&nbsp; 1 " + record.fromccy + " &nbsp; = &nbsp; " + (1 * record.rate) + " " + record.toccy + "</div>").appendTo($dataCol);
		} else if (record.ratetype == "Contract") {
			var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
			var _remaining = 0;
			for (var x = 0, y = record.contracts.length; x < y; x++) {
				_remaining = (Number(_remaining) + Number(record.contracts[x].used));
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].reference + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].clientid + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + record.contracts[x].rate + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].used) + "</div>").appendTo($dataTableRow);
			}
			var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
			var _remaining = Number(_remaining).toFixed(2);
			if (record.debitequivalentflag) {
				if (_remaining == removeCommas(record.totaldebitamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totaldebitamount)) {
					var _amt = (Number(removeCommas(record.totaldebitamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totaldebitamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totaldebitamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			} else {
				if (_remaining == removeCommas(record.totalpaymentamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(removeCommas(record.totalpaymentamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totalpaymentamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			}
		}
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' style='padding-top: 0;' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
	}

	/* OPTIONAL INFORMATION & SUPPORTING DOCUMENTS */
	if (record.type == "Account Transfer") {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
		var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
		var $box = $("<div class='box'/>").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Optional Information</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<textarea style='width: 95%; height: 100px;' disabled='disabled' class='disabled'>" + record.debitadvicedescription + "</textarea>").appendTo($dataCol);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
		var $label = $("<label>Invoice Details</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $data = $("<textarea style='width: 95%; height: 175px;' disabled='disabled' class='disabled'>" + record.invoicedetails + "</textarea>").appendTo($dataCol);
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection);
		var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
		var $box = $("<div class='box' />").appendTo($sectionCell);
		var $boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
		var $dataRow = $("<div class='row' />").appendTo($detailCell);
		var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
		var $dataTable = $("<div class='data-table' />").appendTo($dataCol);
		var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
		var $dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);
		for (var x = 0, y = record.supportingdocs.length; x < y; x++) {
			_doc = record.supportingdocs[x];
			var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
			var $dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
		}
	}

	/* ATTACH PAYMENT DETAIL */
	$paymentDetailContainer.appendTo($paymentDetailSection);

	/* INITIALIZE INSTRUCTION GRID */
	if ( record.type != "Account Transfer") {

		function metadata(itemMetaData) {
			return function(row) {
				var item = this.getItem(row);
				var ret = (itemMetaData(row) || {});
				if (item) {
					ret.cssClasses = (ret.cssClasses || '');
					if (item.status == "Rejected") {
						ret.cssClasses += "rejected-item";
					}
				}
				return ret;
			}
		}

		reviewData = record.payments;
		var reviewItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
		reviewDataView = new Slick.Data.DataView({
			reviewItemMetaProvider: reviewItemMetaProvider
		});
		reviewDataView.getItemMetadata = metadata(reviewDataView.getItemMetadata);
		reviewGrid = new Slick.Grid("#viewPaymentsGrid", reviewDataView, reviewColumns, reviewOptions);
		reviewGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: true
		}));
		reviewGrid.registerPlugin(reviewItemMetaProvider);
		reviewGrid.onSort.subscribe(function(e, args) {
			reviewDataView.sort(function(dataRow1, dataRow2) {
				sortdir = args.sortAsc ? 1 : -1;
				sortcol = args.sortCol.field;
				var _sorter = args.sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			});
			args.grid.invalidateAllRows();
			args.grid.render();
		});
		reviewGrid.onClick.subscribe(function(e, args) {
			var cell = reviewGrid.getCellFromEvent(e);
			var row = cell.row;
			var $row = $(e.target).closest(".slick-row");
			var item = reviewDataView.getItem(row);
			triggerInstructionDialog($(e.target), item);
		});
		reviewDataView.beginUpdate();
		reviewDataView.setItems(reviewData);
		reviewDataView.endUpdate();
		reviewGrid.setColumns(reviewColumns);

		$(window).on("resize.reviewgrid", function() {
			reviewGrid.resizeCanvas();
		});
		$(window).on("resize.reviewgrid", _.debounce(function(e) {
			reviewGrid.resizeCanvas();
		}, 100));
	}
}




function editPaymentDetails(record) {

	/* BREADCRUMB UPDATE */
	updateBreadcrumb("edit");


}


/**********************************************************************
UPDATE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='payments-summary.html'>Current Payments</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Payment Details");
	} else if (update == "edit") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Edit Payment");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Current Payments");
	}
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE PAYMENT GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#paymentSummaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(flagColumn);
	grid.registerPlugin(checkboxSelector);
	grid.registerPlugin(new Slick.AutoTooltips({
		enableForHeaderCells: true
	}));
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'paymentSummaryColumnOrder', 'paymentSummaryColumnWidths', ["checkboxSelector", "flagColumn"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell)
		setupContextMenu();
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedRowStates = [];
		selectedRowWorkflows = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedRowStates.push(item.status);
				selectedRowWorkflows.push(item.workflow);
			}
		}
		if (selectedRowIds.length > 0) {
			$("#paymentSummaryGrid").addClass("has-bottom-controls");
			$("#paymentsGrid .bottom-controls").removeClass("hidden");
			$("#selectedCount").html(selectedRowIds.length);
			grid.resizeCanvas();
		} else {
			$("#paymentSummaryGrid").removeClass("has-bottom-controls");
			$("#paymentsGrid .bottom-controls").addClass("hidden");
			$("#selectedCount").html('');
			grid.resizeCanvas();
		}
	});
	grid.onClick.subscribe(function(e, args) {
		row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#paymentDetailScreen',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			record = dataView.getItem(row);
			viewPaymentDetails(record);
			grid.setSelectedRows([]);
			selectedRowIds = [];
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('paymentSummaryColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('paymentSummaryColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i < store.get('paymentSummaryColumnOrder').length + 2; i++) {
			if (columns[i].visible == true) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleAdHocColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	GRID RESIZER
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));



	/**********************************************************************
	PAYMENT VIEWS
	**********************************************************************/
	$("#paymentViewFilter").on("click.filter-view", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set")) {
			var status = $target.attr("data-status"),
				workflow = $target.attr("data-workflow"),
				user = $target.attr("data-user");
			if (!status) {
				statusString = ""
			}
			if (statusString != status) {
				statusString = status
			}
			if (!workflow) {
				workflowString = ""
			}
			if (workflowString != workflow) {
				workflowString = workflow
			}
			if (!user) {
				userString = ""
			}
			if (userString != user) {
				userString = user
			}
			paymentsViewFilter();
		}
	});

	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#reportMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#reportMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#reportMenu"
			});
		}
	});


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);




	/**********************************************************************
	GROUPING
	**********************************************************************/
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});

	/**********************************************************************
	ACTION MENU AND ACTIONS
	**********************************************************************/
	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});
	$("[data-action='delete']").on("click", deleteRecordFromList);
	$("[data-action='reject']").on("click", rejectRecordFromList);
	$("[data-action='recall']").on("click", recallRecordFromList);
	$("[data-action='approve']").on("click", approveRecordFromList);
	$("[data-action='rate']").on("click", getDynamicRate);
	$("[data-action='genereateAuditReport']").on("click", function(e) {
		e.preventDefault();
		triggerAuditReportDialog($(this));
	});
	$("a[data-action='pymdetail']").on("click", showPaymentDetailReportDialog);
	$("a[data-action='pymsummary']").on("click", showPaymentSummaryReportDialog);
	$("a[data-action='pymtrail']").on("click", showPaymentTrailReportDialog);
	$("a[data-action='pymtemplate']").on("click", showPaymentTemplateDialog);
	$("a[data-action='pymaudit']").on("click", showAuditHistoryDialog);
	$("a[data-action='gendebadvices").on("click", showBatchLevelDebitAdviceDialog);
	$("a[data-action='genbenadvices").on("click", showBatchLevelBeneAdviceDialog);


	/**********************************************************************
	SETTINGS
	**********************************************************************/	
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	JUMP TO PAYMENT DETAILS
	**********************************************************************/
	var b = document.location.href.split(".html")[1];

	if (b == "#detail") {
		$("#paymentSummaryGrid").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		document.location.hash = '';
	}


});