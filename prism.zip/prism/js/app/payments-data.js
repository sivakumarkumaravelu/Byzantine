var divisions = [
	"Customer Division 1",
	"Customer Division 2",
	"Customer Division 3"
];

var customerAccounts = [{
	id: "CustAcc1",
	name: "AUD Local Funding",
	shortname: "AUD Local Funding",
	number: "12345-8474722322",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	residentstatus: true,
	available: "16,000.00",
	availablefunds: "16,000.00"
}, {
	id: "CustAcc2",
	name: "Melbourne Operating",
	shortname: "Melbourne Opps",
	number: "12345-9839573082",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	residentstatus: true,
	available: "67,000.00",
	availablefunds: "67,000.00"
}, {
	id: "CustAcc3",
	name: "AUD Charity",
	number: "12345-7717777731",
	shortname: "Charity Account 5",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	residentstatus: true,
	available: "23,000.00",
	availablefunds: "23,000.00"
}, {
	id: "CustAcc4",
	name: "Wangfujing Office",
	shortname: "",
	number: "3539939711",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZBEI00001",
	city: "Beijing",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Beijing",
	country: "China",
	residentstatus: true,
	available: "140,000.00",
	availablefunds: "140,000.00"
}, {
	id: "CustAcc5",
	name: "Hepingmen Office",
	shortname: "",
	number: "3441295104",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZBEI00001",
	city: "Beijing",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Beijing",
	country: "China",
	residentstatus: true,
	available: "75,000.00",
	availablefunds: "75,000.00"
}, {
	id: "CustAcc6",
	name: "ANZ Shanghai Account",
	shortname: "",
	number: "6540364593",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	residentstatus: false,
	available: "1,000,000,000,000,000",
	availablefunds: "1,000,000,000,000,000"
}];
for (var j in customerAccounts) {
	customerAccounts[j].label = customerAccounts[j].name + " - " + customerAccounts[j].number + " (" + customerAccounts[j].ccy + ")";
}

var beneficiaryAccounts = [{
	id: randString(10),
	approved: true,
	name: "Sam Taylor",
	nickname: "Sammy",
	localname: "",
	accountnumber: "12345-6731299878",
	type: "Resident Individual",
	accountcurrency: "AUD",
	address1: "Level 8",
	address2: "530 Collins Street",
	address3: "3000",
	address4: "Melbourne",
	paymentaddress: "Sam.Taylor@company.com",
	payidtype: "Email",
	payidname: "Samuel John Taylor",
	country: "Australia",
	email: "samtaylor_blues@email.com",
	phone: "555-555-1111",
	fax: "777-888-9999",
	bank: "AUSTRALIA AND NEW ZEALAND BANK",
	branch: "ANZ Banking Group Limited",
	bankaddress1: "Level 12, 530 Collins Street",
	bankaddress2: "Floor 22",
	bankaddress3: "200001",
	bankaddress4: "Melbourne",
	bankpostal: "200001",
	bankcountry: "Australia",
	swift: "ANZBAU3M",
	clearing: [{
		type: "BSB",
		code: "063-032"
	}]
}, {
	id: randString(10),
	approved: true,
	name: "Gina Giocare",
	nickname: "GG",
	localname: "",
	accountnumber: "12345-9835497124",
	residentstatus: true,
	accountcurrency: "AUD",
	address1: "Level 8",
	address2: "530 Collins Street",
	address3: "3000",
	address4: "Melbourne",
	paymentaddress: "+61422040652",
	payidtype: "Phone",
	payidname: "Gina Giocare",
	country: "Australia",
	email: "gina_giocare@email.com",
	phone: "555-555-1111",
	fax: "777-888-9999",
	bank: "AUSTRALIA AND NEW ZEALAND BANK",
	branch: "ANZ Banking Group Limited",
	bankaddress1: "Level 12, 530 Collins Street",
	bankaddress2: "Floor 22",
	bankaddress3: "200001",
	bankaddress4: "Melbourne",
	bankpostal: "200001",
	bankcountry: "Australia",
	swift: "ANZBAU3M",
	clearing: [{
		type: "BSB",
		code: "063-032"
	}]
}, {
	id: randString(10),
	approved: true,
	name: "Christopher Hendricks",
	nickname: "Chris",
	localname: "",
	accountnumber: "12345-3528745982",
	residentstatus: true,
	accountcurrency: "AUD",
	address1: "Level 8",
	address2: "530 Collins Street",
	address3: "3000",
	address4: "Melbourne",
	paymentaddress: "013353 987654321",
	payidtype: "BSB/ACC",
	payidname: "",
	country: "Australia",
	email: "Chris.Hendricks@email.com",
	phone: "555-555-1111",
	fax: "777-888-9999",
	bank: "AUSTRALIA AND NEW ZEALAND BANK",
	branch: "ANZ Banking Group Limited",
	bankaddress1: "Level 12, 530 Collins Street",
	bankaddress2: "Floor 22",
	bankaddress3: "200001",
	bankaddress4: "Melbourne",
	bankpostal: "200001",
	bankcountry: "Australia",
	swift: "ANZBAU3M",
	clearing: [{
		type: "BSB",
		code: "063-032"
	}]
}, {
	id: randString(10),
	approved: true,
	name: "Xie Ping Lei",
	nickname: "Christina",
	localname: "莎莉·菲尔德",
	accountnumber: "2384492528252653",
	residentstatus: true,
	accountcurrency: "CNY",
	address1: "Unit 1077/1079/108",
	address2: "No. 1018, Chang Ning Road",
	address3: "3000",
	address4: "Shanghai",
	country: "China",
	email: "xiepinglei@email.com",
	phone: "555-555-5555",
	fax: "777-888-9999",
	bank: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	branch: "Shanghai Branch",
	bankaddress1: "Unit 1077/1079/108",
	bankaddress2: "No. 1018, Chang Ning Road",
	bankaddress3: "200042",
	bankaddress4: "Shanghai",
	bankpostal: "200042",
	bankcountry: "China",
	swift: "ANZBCNSH",
	clearing: [{
		type: "CNAPS",
		code: "761290013606"
	}]
}, {
	id: randString(10),
	approved: true,
	name: "Xavier Tan",
	nickname: "Xavier",
	localname: "万里·米勒",
	accountnumber: "8996838652772297",
	residentstatus: true,
	accountcurrency: "CNY",
	address1: "Unit 1077/1079/108",
	address2: "No. 1018, Chang Ning Road",
	address3: "3000",
	address4: "Shanghai",
	country: "China",
	email: "xaviar_tan@email.com",
	phone: "555-555-6666",
	fax: "777-888-9999",
	bank: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	branch: "Shanghai Branch",
	bankaddress1: "Unit 1077/1079/108",
	bankaddress2: "No. 1018, Chang Ning Road",
	bankaddress3: "200042",
	bankaddress4: "Shanghai",
	bankpostal: "200042",
	bankcountry: "China",
	swift: "SCBLCNSXSHA",
	clearing: [{
		type: "CNAPS",
		code: "671290000017"
	}]
}, {
	id: randString(10),
	approved: true,
	name: "James Fung",
	nickname: "James",
	localname: "",
	accountnumber: "1243256242499124",
	residentstatus: false,
	accountcurrency: "CNY",
	address1: "Unit 1077/1079/108",
	address2: "No. 1018, Chang Ning Road",
	address3: "3000",
	address4: "Shanghai",
	country: "China",
	email: "xaviar_tan@email.com",
	phone: "555-555-6666",
	fax: "777-888-9999",
	bank: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	branch: "Shanghai Branch",
	bankaddress1: "Unit 1077/1079/108",
	bankaddress2: "No. 1018, Chang Ning Road",
	bankaddress3: "200042",
	bankaddress4: "Shanghai",
	bankpostal: "200042",
	bankcountry: "China",
	swift: "SCBLCNSXSHA",
	clearing: [{
		type: "CNAPS",
		code: "671290000017"
	}]
}, {
	id: randString(10),
	approved: true,
	name: "Crissy Snow",
	nickname: "Crissy",
	localname: "",
	accountnumber: "2554398665771654",
	residentstatus: true,
	accountcurrency: "CNY",
	address1: "Unit 1077/1079/108",
	address2: "No. 1018, Chang Ning Road",
	address3: "3000",
	address4: "Hong Kong",
	country: "Hong Kong",
	email: "crissy.snow@email.com",
	phone: "555-555-6666",
	fax: "777-888-9999",
	bank: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	branch: "Hong Kong Branch",
	bankaddress1: "Unit 1077/1079/108",
	bankaddress2: "No. 1018, Chang Ning Road",
	bankaddress3: "200042",
	bankaddress4: "Hong Kong",
	bankpostal: "200042",
	bankcountry: "Hong Kong",
	swift: "SCBLHKHH",
	clearing: [{
		type: "Bank",
		code: "003-329"
	}]
}];
for (var j in beneficiaryAccounts) {
	beneficiaryAccounts[j].label = beneficiaryAccounts[j].name + "\n" + beneficiaryAccounts[j].accountnumber;
}

var fxRates = [{
	from: "AUD",
	to: "AUD",
	rate: 1.0000
},{
	from: "AUD",
	to: "CNY",
	rate: 4.8076
}, {
	from: "AUD",
	to: "SGD",
	rate: 1.0190
}, {
	from: "AUD",
	to: "HKD",
	rate: 5.8900
}, {
	from: "AUD",
	to: "NZD",
	rate: 1.0700
}, {
	from: "CNY",
	to: "CNY",
	rate: 1.0000
}, {
	from: "CNY",
	to: "AUD",
	rate: 0.2080
}, {
	from: "CNY",
	to: "SGD",
	rate: 0.2120
}, {
	from: "CNY",
	to: "HKD",
	rate: 1.1700
}, {
	from: "CNY",
	to: "NZD",
	rate: 0.2100
}, {
	from: "SGD",
	to: "SGD",
	rate: 1.0000
}, {
	from: "SGD",
	to: "AUD",
	rate: 0.9813
}, {
	from: "SGD",
	to: "CNY",
	rate: 4.7169
}, {
	from: "SGD",
	to: "HKD",
	rate: 5.7800
}, {
	from: "SGD",
	to: "NZD",
	rate: 1.0100
}, {
	from: "HKD",
	to: "HKD",
	rate: 1.0000
}, {
	from: "HKD",
	to: "AUD",
	rate: 0.1700
}, {
	from: "HKD",
	to: "CNY",
	rate: 0.8500
}, {
	from: "HKD",
	to: "SGD",
	rate: 0.1700
}, {
	from: "HKD",
	to: "NZD",
	rate: 0.1800
}, {
	from: "NZD",
	to: "NZD",
	rate: 1.0000
}, {
	from: "NZD",
	to: "AUD",
	rate: 0.9400
}, {
	from: "NZD",
	to: "CNY",
	rate: 4.8400
}, {
	from: "NZD",
	to: "SGD",
	rate: 0.9900
}, {
	from: "NZD",
	to: "HKD",
	rate: 5.5300
}];

var contractRates = [{
	from: "AUD",
	to: "CNY",
	high: 4.8110,
	low: 4.7710
}, {
	from: "AUD",
	to: "SGD",
	high: 1.0410,
	low: 1.0010
}, {
	from: "AUD",
	to: "HKD",
	high: 5.9100,
	low: 5.8800
}, {
	from: "AUD",
	to: "NZD",
	high: 1.0710,
	low: 1.0690
}, {
	from: "CNY",
	to: "AUD",
	high: 0.2310,
	low: 0.1910
}, {
	from: "CNY",
	to: "SGD",
	high: 0.2310,
	low: 0.1910
}, {
	from: "CNY",
	to: "HKD",
	high: 1.1850,
	low: 1.1670
}, {
	from: "CNY",
	to: "NZD",
	high: 0.2300,
	low: 0.2000
}, {
	from: "SGD",
	to: "AUD",
	high: 1.0010,
	low: 0.9610
}, {
	from: "SGD",
	to: "CNY",
	high: 4.7210,
	low: 4.6810
}, {
	from: "SGD",
	to: "HKD",
	high: 5.7900,
	low: 5.7100
}, {
	from: "SGD",
	to: "NZD",
	high: 1.0250,
	low: 1.0090
}, {
	from: "HKD",
	to: "AUD",
	high: 0.1710,
	low: 0.1690
}, {
	from: "HKD",
	to: "CNY",
	high: 0.8550,
	low: 0.8480
}, {
	from: "HKD",
	to: "SGD",
	high: 0.1710,
	low: 0.1690
}, {
	from: "HKD",
	to: "NZD",
	high: 0.1990,
	low: 0.1700
}, {
	from: "NZD",
	to: "AUD",
	high: 0.9600,
	low: 0.9200
}, {
	from: "NZD",
	to: "CNY",
	high: 4.8500,
	low: 4.8200
}, {
	from: "NZD",
	to: "SGD",
	high: 1.0000,
	low: 0.9700
}, {
	from: "NZD",
	to: "HKD",
	high: 5.5600,
	low: 5.5100
}];


var rateTypes = [
	"Carded",
	"Contract",
	"Dynamic"
];


var paymentTypes = [
	"Account Transfer",
	"Domestic",
	"Domestic Salary",
	"International",
	"International Salary"
];


var _payment_currencies = [
	"AUD",
	"CNY",
	"HKD",
	"NZD",
	"SGD"
];

var charges = [{
	code: "OUR",
	description: "Ours"
}, {
	code: "BEN",
	description: "Beneficiary"
}, {
	code: "SHA",
	description: "Shared"
}];

var auDomesticPaymentMethods = [
	"RTGS",
	"Direct Entry",
	"Osko"
];

var cnDomesticPaymentMethods = [
	"Book Transfer",
	"BEPS",
	"HVPS",
	"HVPS(XB)"
];

var workflow = [
	"Draft",
	"Pending Approval",
	"Needs Rate",
	"Needs Repair",
	"Warehoused",
	"Processing"
];