/**********************************************************************
						MICRO-TEMPLATE
**********************************************************************/
(function(){
  var cache = {};
  this.tmpl = function tmpl(str, data){
	var fn = !/\W/.test(str) ?
	  cache[str] = cache[str] ||
		tmpl(document.getElementById(str).innerHTML) :
	  new Function("obj",
		"var p=[],print=function(){p.push.apply(p,arguments);};" +
		"with(obj){p.push('" +
		str
		  .replace(/[\r\t\n]/g, " ")
		  .split("<%").join("\t")
		  .replace(/((^|%>)[^\t]*)'/g, "$1\r")
		  .replace(/\t=(.*?)%>/g, "',$1,'")
		  .split("\t").join("');")
		  .split("%>").join("p.push('")
		  .split("\r").join("\\'")
	  + "');}return p.join('');");
	return data ? fn( data ) : fn;
  };
})();


/**********************************************************************
ACCOUNT SUMMARY GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var loadRecordTimer;
var columns = [
	{id:"account", name:"Accounts", formatter:renderCell, field:"accountname", cssClass:"contact-card-cell", type: "preview"}
];
checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
options = {
	rowHeight: 70,	
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: true,
	multiColumnSort: false,
	multiSelect: true,
	showHeaderRow: false
};
var compiled_template = tmpl("cell_template");
function renderCell(row, cell, value, columnDef, dataContext) {
	return compiled_template(dataContext);
};
var groupedSetting = 0; 
var groupCollapseSetting = 0; 
var groupCCYSetting = "USD";
function sumTotalsFormatter(totals, columnDef) {
	return groupCCYSetting + " " + addCommas(Math.round((totals.sum[columnDef.field] * 100) / 100).toFixed(2));
}
function expandAllGroups() {
	dataView.expandAllGroups();
	$("#groupMenuControl").removeClass("on");
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
	$("#groupMenuControl").removeClass("on");
}
function clearGrouping() {
	$("#groupMenuControl").removeClass("on");
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: false
		}]);

	dataView.setAggregators([
		new Slick.Data.Aggregators.Sum("openingavailablebal"),
		new Slick.Data.Aggregators.Sum("openingledgerbal"),
		new Slick.Data.Aggregators.Sum("availablebal"),
		new Slick.Data.Aggregators.Sum("ledgerbal")
	], true);

	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
	$("#groupMenuControl").removeClass("on");
}
var labelString = "", findString = "", findDataPoint = "accountnumb";
function myFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}

	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	return true;
}
function calculateTotals() {
	var totalAvailable = 0,
		totalLedger = 0;
	for (var i = 0; i < dataView.getLength(); i++) {
		if (dataView.getItem(i).id) {
			totalAvailable = parseFloat(totalAvailable) + parseFloat(dataView.getItem(i).availablebal.replace(',', ''));
			totalLedger = parseFloat(totalLedger) + parseFloat(dataView.getItem(i).ledgerbal.replace(',', ''));
		}
	}
	totalAvailable = addCommas(totalAvailable.toFixed(2))
	$("[data-value='totalavailable']").html(totalAvailable)
	totalLedger = addCommas(totalLedger.toFixed(2))
	$("[data-value='totalledger']").html(totalLedger)
}
function filterAccounts() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	calculateTotals()
}
function timeFormatter() {
	var date = new Date();
	var time = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds() + " AEDT";
	return time;
}
for (var i = 0; i < 20; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	d["label"] = "None";
	d["labelid"] = "None";
	if (i % 3 == 0) {
		d["company"] = "Consulting Pte. Ltd.";
		d["country"] = "Singapore";
		d["bankname"] = "ANZ Singapore";
		d["branchcode"] = "ANZSG0311";
		if (i % 2 == 0) {
			d["accounttype"] = "Savings";
			d["accountname"] = "SGSavings" + Math.round(Math.random() * 1000);
			d["accountalias"] = "ABC Savings - " + Math.round(Math.random() * 1000);
		} else {
			d["accounttype"] = "Current";
			d["accountname"] = "SGCurrent" + Math.round(Math.random() * 1000);
			d["accountalias"] = "ABC Current - " + Math.round(Math.random() * 1000);
		};
		d["currency"] = "SGD";
		d["fxrate"] = parseFloat(1.2221).toFixed(4);
	} else {
		d["company"] = "Manufacturing Inc.";
		d["country"] = "Australia";
		d["bankname"] = "ANZ Australia";
		d["branchcode"] = "ANZMLB356";
		if (i % 2 == 0) {
			d["accounttype"] = "Current";
			d["accountname"] = "AUCurrent" + Math.round(Math.random() * 1000);
			d["accountalias"] = "123 Current - " + Math.round(Math.random() * 1000);
		} else {
			d["accounttype"] = "Savings";
			d["accountname"] = "AUSavings" + Math.round(Math.random() * 1000);
			d["accountalias"] = "123 Savings - " + Math.round(Math.random() * 1000);
		};
		d["currency"] = "AUD";
		d["fxrate"] = parseFloat(0.9100).toFixed(4);
	};
	d["accountnumb"] = Math.round(Math.random() * 1000000000).toString();
	d["baldate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["openingavailablebal"] = (Math.round(Math.random() * 10000000) / 100).toFixed(2);
	d["openingledgerbal"] = (Math.round(Math.random() * 10000000) / 100).toFixed(2);
	d["availablebal"] = (Math.round(Math.random() * 10000000) / 100).toFixed(2);
	d["ledgerbal"] = (Math.round(Math.random() * 10000000) / 100).toFixed(2);
	d["availablefunds"] = (Math.round(Math.random() * 10000000) / 100).toFixed(2);
	d["overdraft"] = (Math.round(Math.random() * 1000000) / 100).toFixed(2);
};


/**********************************************************************
ACCOUNT ACTIVITY GRID
**********************************************************************/
var activityDataView;
var activityGrid;
var activityData = [];
var activitySelectedRowIds = [];
var activityColumns = [{
	id: "postingdate",
	name: "Post Date",
	field: "postingdate",
	visible: true,
	sortable: true,
	sorter: "sorterDateIso",
	width: 160
}, {
	id: "valuedate",
	name: "Value Date",
	field: "valuedate",
	visible: true,
	sortable: true,
	sorter: "sorterDateIso",
	width: 160
}, {
	id: "damount",
	name: "Debits",
	field: "damount",
	visible: true,
	sortable: true,
	sorter: "sorterNumeric",
	width: 180,
	groupTotalsFormatter: sumTotalsFormatter,
	formatter: Slick.Formatters.AmountFormatter,
	cssClass: "num neg",
	headerCssClass: "righted",
}, {
	id: "camount",
	name: "Credits",
	field: "camount",
	visible: true,
	sortable: true,
	sorter: "sorterNumeric",
	width: 180,
	groupTotalsFormatter: sumTotalsFormatter,
	formatter: Slick.Formatters.AmountFormatter,
	cssClass: "num pos",
	headerCssClass: "righted",
}, {
	id: "runningbalance",
	name: "Running Balance",
	field: "runningbalance",
	visible: true,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	width: 180,
	cssClass: "num pos",
	headerCssClass: "righted",
}, {
	id: "transcode",
	name: "Transaction Type",
	field: "transcode",
	visible: true,
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare"
}, {
	id: "baicode",
	name: "BAI Code",
	field: "baicode",
	visible: true,
	sortable: true,
	sorter: "sorterStringCompare",
	width: 160
}, {
	id: "transnar",
	name: "Narrative",
	visible: true,
	field: "transnar",
	width: 200
}, {
	id: "transdesc",
	name: "Transaction Description",
	field: "transdesc",
	visible: true,
	width: 200
}, {
	id: "voucher",
	name: "Voucher Image",
	field: "voucher",
	visible: true,
	width: 160,
	cssClass: "centered",
	sortable: true,
	sorter: "sorterStringCompare"
}, {
	id: "swift",
	name: "SWIFT Message",
	field: "swift",
	visible: true,
	width: 160,
	cssClass: "centered",
	sortable: true,
	sorter: "sorterStringCompare"
}];
activityOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
var acolumnFilters = {};
if ( store.get('nostroActivityOrder') ) {
	activityColumns = store.get('nostroActivityOrder');
	for (i = 0; i < activityColumns.length; i++) {
		if (activityColumns[i].id == "damount" || activityColumns[i].id == "camount") {
			activityColumns[i].groupTotalsFormatter = sumTotalsFormatter;
			activityColumns[i].formatter = Slick.Formatters.AmountFormatter;
		}
		if ( activityColumns[i].id == "runningbalance" ) {
			activityColumns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('nostroActivityWidths') ) {
	var setActivityWidth = store.get('nostroActivityWidths');
	for (var i in setActivityWidth) {
		var s = setActivityWidth[i]
		for (c = 0; c < activityColumns.length; c++) {
			if (s.id == activityColumns[c].id) {
				activityColumns[c].width = s.width
			}
		}
	}
}
var activityCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
activityColumns.unshift(activityCheckboxSelector.getColumnDefinition());
function trxnexpandAllGroups() {
	activityDataView.expandAllGroups();
}
function trxncollapseAllGroups() {
	activityDataView.collapseAllGroups();
}
function trxnclearGrouping() {
	activityDataView.setGrouping([]);
}
function trxngroupBy(item, text) {
	activityDataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);

	activityDataView.setAggregators([
		new Slick.Data.Aggregators.Sum("damount"),
		new Slick.Data.Aggregators.Sum("camount")
	], true);

	if(groupCollapseSetting == 1) {
		trxncollapseAllGroups();
	}
}
var findActivityString = "", findActivityDataPoint = "transcode";
function myActivityFilter(item, args) {

	if (args.findActivityString != "" && item[findActivityDataPoint].toLowerCase().indexOf(args.findActivityString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in acolumnFilters) {
		if (columnId !== undefined && acolumnFilters[columnId] !== "") {
			var c = activityGrid.getColumns()[activityGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = acolumnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(acolumnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}	

	return true;
}
function toggleActivityFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in acolumnFilters) {
		acolumnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		activityGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		activityGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	activityDataView.refresh();
}
function filterActivity() {
	var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showActivity = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		activityDataView.refresh();
		if(groupCollapseSetting == 1) {
			trxncollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showActivity, 500);
}
for (var i = 0; i < 25; i++) {
	var d = (activityData[i] = {});
	d["id"] = "id_" + i;
	d["postingdate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["valuedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	if (i % 3 == 0) {
		d["damount"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
		d["camount"] = "";
		d["voucher"] = "y";
		d["swift"] = "";
	} else {
		d["damount"] = "";
		d["camount"] = (Math.round(Math.random() * 100000) / 100).toFixed(2);
		d["voucher"] = "";
		d["swift"] = "y";
	};
	d["runningbalance"] = addCommas((Math.round(Math.random() * 100000) / 100).toFixed(2));
	d["transcode"] = "TC" + (Math.round(Math.random() * 1000)).toString();
	d["baicode"] = "BAI" + (Math.round(Math.random() * 10000)).toString();
	d["transnar"] = "";
	d["transdesc"] = "Pellentesque laoreet convallis nisi in faucibus. Etiam dignissim laoreet dignissim. Donec mi orci, varius et eleifend non, rutrum quis lectus.";
}


/**********************************************************************
BALANCE HISTORY GRID
**********************************************************************/
var balanceDataView;
var balancehistorygrid;
var	bdata = [];
var bcolumns = [{
	id: "date",
	name: "Date",
	field: "date",
	width: 160,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "openingavailbal",
	name: "Opening Available Balance",
	field: "openingavailbal",
	width: 200,
	cssClass: "num pos",
	headerCssClass: "righted",
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true
}, {
	id: "closingavailbal",
	name: "Closing Available Balance",
	field: "closingavailbal",
	width: 200,
	cssClass: "num pos",
	headerCssClass: "righted",
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true
}, {
	id: "openingledgbal",
	name: "Opening Ledger Balance",
	field: "openingledgbal",
	width: 200,
	cssClass: "num pos",
	headerCssClass: "righted",
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true
}, {
	id: "closingledgbal",
	name: "Closing Ledger Balance",
	field: "closingledgbal",
	width: 200,
	cssClass: "num pos",
	headerCssClass: "righted",
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	visible: true
}];
boptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: false,
	showHeaderRow: false,
	headerRowHeight: 40
};
if ( store.get('nostroBalanceOrder') ) {
	bcolumns = store.get('nostroBalanceOrder');
	if (bcolumns[i].id == "openingavailbal" || bcolumns[i].id == "closingavailbal" || bcolumns[i].id == "openingledgbal" || bcolumns[i].id == "closingledgbal") {
		bcolumns[i].formatter = Slick.Formatters.AmountFormatter;
	}
}
if ( store.get('nostroBalanceWidths') ) {
	var setBalanceWidth = store.get('nostroBalanceWidths');
	for (var i in setBalanceWidth) {
		var s = setBalanceWidth[i]
		for (c = 0; c < bcolumns.length; c++) {
			if (s.id == bcolumns[c].id) {
				bcolumns[c].width = s.width
			}
		}
	}
}
for (var i=0; i<30; i++) {
	var d = (bdata[i] = {});
	d["id"] = "id_" + i;
	d["date"] = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - i)));
	d["openingavailbal"] = (Math.round(Math.random() * 10000000)/1000).toFixed(2);
	d["closingavailbal"] = (Math.round(Math.random() * 10000000)/1000).toFixed(2);
	d["openingledgbal"] = (Math.round(Math.random() * 10000000)/1000).toFixed(2);
	d["closingledgbal"] = (Math.round(Math.random() * 10000000)/1000).toFixed(2);
}


/**********************************************************************
LIQUIDITY GRID
**********************************************************************/
var liquidityDataView;
var liquidityGrid;
var	liqData = [];
var	liqColumns = [
	{ id:"detail", name:"Transaction Detail / Reference", field:"detail", width: 300, sortable: true, sorter: "sorterStringCompare", visible: true },
	{ id:"time", name:"Time Processed", field:"time", width: 200, sortable: true, sorter: "sorterDateIso", visible: true },
	{ id:"debit", name:"Debit Amount", field:"debit", width: 200, cssClass: "num neg", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric",formatter: Slick.Formatters.AmountFormatter, visible: true },
	{ id:"credit", name:"Credit Amount", field:"credit", width: 200, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric",formatter: Slick.Formatters.AmountFormatter, visible: true },
	{ id:"runningbal", name:"Running Balance", field:"runningbal", width: 200, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric",formatter: Slick.Formatters.AmountFormatter, visible: true }
],
liqOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: false,
	showHeaderRow: true,
	headerRowHeight: 40
};
var liqcolumnFilters = {};
if ( store.get('nostroLiquidityOrder') ) {
	liqColumns = store.get('nostroLiquidityOrder');
	if (liqColumns[i].id == "debit" || liqColumns[i].id == "credit" || liqColumns[i].id == "runningbal") {
		liqColumns[i].formatter = Slick.Formatters.AmountFormatter;
	}
}
if ( store.get('nostroLiquidityWidths') ) {
	var setLiquidityWidth = store.get('nostroLiquidityWidths');
	for (var i in setLiquidityWidth) {
		var s = setLiquidityWidth[i]
		for (c = 0; c < liqColumns.length; c++) {
			if (s.id == liqColumns[c].id) {
				liqColumns[c].width = s.width
			}
		}
	}
}
function myLiquidityFilter(item, args) {

	for (var columnId in liqcolumnFilters) {
		if (columnId !== undefined && liqcolumnFilters[columnId] !== "") {
			var c = liquidityGrid.getColumns()[liquidityGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = liqcolumnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(liqcolumnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}	

	return true;
}
function toggleLiquidityFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in liqcolumnFilters) {
		liqcolumnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		liquidityGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		liquidityGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	liquidityDataView.refresh();
}
for (var i=0; i<30; i++) {
	var d = (liqData[i] = {});
	d["id"] = "id_" + i;
	d["detail"] = randString()+Math.round(Math.random() * 1000000)/1000;
	d["time"] =  $.datepicker.formatDate('dd/mm/yy', new Date()) + " " + timeFormatter();
	d["debit"] = (Math.round(Math.random() * 10000000)/100).toFixed(2);
	d["credit"] = (Math.round(Math.random() * 10000000)/100).toFixed(2);
	d["runningbal"] = (Math.round(Math.random() * 10000000)/100).toFixed(2);
}


/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var user_nostro_folders = [], folders_updated = false, folders_deleted = false;
$folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Accounts</p><p style='font-size: 14px;'>Folders help you keep your accounts organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move accounts into a folder by selecting them in the accounts grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-th-list fa-fw'></i> View Menu.</p></div>"),
$folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if ( store.get('nostro_folders') ) { user_nostro_folders = store.get('nostro_folders') };
function folderFilter() {
	var rows = grid.getSelectedRows()
	if(rows.length > 0) {
		grid.setSelectedRows(0)
	}
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	})
	filterAccounts()
}
function folderChecker(val) {
	var _folder = val, error = false, $folderList = $(".folder-list").children("li"), existingFolders = [];
	for ( var i = 0; i < $folderList.length; i++ ) {
		existingFolders.push( $folderList.eq(i).attr("data-folder") );
	}
	if ($.inArray(_folder, existingFolders) != -1) { error = "existing" }
	return error;
}
function renameFolder(el) {
	var newFolderName = $.trim(el.val());
	if ( newFolderName == '' || newFolderName == "undefined" ) {
		el.val( el.attr("data-folder-name") );
	} else {
		el.val(newFolderName);
		el.closest("li").attr("data-folder", newFolderName );
		folders_updated = true;
	}
}
function addFolder() {
	var folderName = $.trim($("#newFolderInput").val()), $folderList = $("ul.folder-list"), $newFolderDiv = $("div.new-folder"), $li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
	if ( folderName == '' || folderName== "undefined" ) {
		$("#newFolderInput").val('');
		return false;
	} else {
		if ( folderCheck == "existing" ) {
			 $newFolderDiv.addClass("error");
			 $("#newFolderInput").focus().select().one("keyup.remove-error", function() { $newFolderDiv.removeClass("error"); });
		} else {
			if ( $newFolderDiv.hasClass("error") ) { $newFolderDiv.removeClass("error"); }
			if ( $(".folder-message").size() ) {
				$(".folder-message").remove();
				$folderListInstruction.insertBefore($folderList);
			}
			$li = $("<li data-folder='"+folderName+"' data-folder-id='"+randString()+"' class='row new' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' value='"+folderName+"' maxlength='25' data-folder-name='"+folderName+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
			$("#newFolderInput").val('');
			$folderList.sortable("refresh");
			folders_updated = true;
		}
	}
}
function addFolderInline() {
	var folderName = $.trim($("#_inlineFolderInput").val()), folderExists = false;
	if ( folderName == '' || folderName == "undefined" ) {
		$("#_inlineFolderInput").val('');
		return false;
	} else {
		for ( var i = 0; i < user_nostro_folders.length; i++ ) {
			if ( folderName == user_nostro_folders[i].name ) {
				folderExists = true;
				break;
			}
		}
		if ( folderExists ) {
			alert("A folder with that name already exists.");
		} else {
			var _id = randString();
			var _new = { name: folderName, id: _id };
			user_nostro_folders.push(_new);
			populateFolders();
			store.set('nostro_folders', user_nostro_folders);
			$("#_inlineFolderInput").val('');
			moveAccounts(_id);
		}
	}
}
function deleteFolder(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function(){
		if ( !$target.hasClass('new') ) { folders_deleted = true; }
		$target.remove();
		$(".folder-list").sortable("refresh");
		folders_updated = true;
		if ( !$(".folder-list").children("li").size() ) {
			$(".folder-list-instructions").remove();
			$folderMessage.appendTo(".folder-settings");
		}
		if ( $("div.new-folder").hasClass("error") ) {
			 $("div.new-folder").removeClass("error");
		}
	 });
}
function populateFolders() {
	var $assignFolders = $(".assign-folders"), folderCount = user_nostro_folders.length, activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
	$assignFolders.children().remove();
	if ( $("#removeFromFolder").size() > 0 ) { $("#removeFromFolder").remove(); }
	if ( folderCount > 0 ) {
		var $li, $a
		$assignFolders.each( function() {
			var _this = $(this);
			if (  _this.parents().attr("id") == "folderMenu" ) {
				$.each(user_nostro_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
					}).appendTo($li);
				});
				var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
				$spacer = $("<li class='menu-section' />").appendTo($ul),
				$li = $("<li />").appendTo($ul),
				$a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected accounts from folders' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
					e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
				}).appendTo($li),
				$spacer = $("<li class='menu-section' />").appendTo($ul);
			} else if ( _this.parents().attr("id") == "viewMenu" ) {
				$.each(user_nostro_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					if ( this.id == activeFolder ) { $li.addClass("active"); $("#viewMenuControl").children("a").children("span").html(this.name); }
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault();
						var _folderID = $(this).attr("data-folder-id"), _folderName = $(this).attr("data-folder");
						if ( labelString != _folderID ) {
							labelString = _folderID;
						}
						folderFilter();
						$("#selectedFolder").html(_folderName);
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
		$li = $("<li class='no-set' />").appendTo($viewMenu),
		$a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Folders</div>Folders help keep your data organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
	}
}
function populateFolderManager() {
	folders_updated = false; folders_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
	$folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
	$folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
	$folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e){if(e.keyCode == 13){addFolder()}}).appendTo($folderAddDiv),
	$folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
	$folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
	$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({ handle: '.reorder-folder', axis: 'y', tolerance: "pointer", update: function( event, ui ) { folders_updated = true } }),
	folderCount = user_nostro_folders.length, $li, $div, $span, $input, $a, $error;
	if ( folderCount > 0 ) {
		$folderListInstruction.insertBefore($folderList);
		$.each(user_nostro_folders, function() {
			$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='"+this.name+"' data-folder-name='"+this.name+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
		});
	} else {
		$folderMessage.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showFolderManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Nostro Account Folders",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function(){return populateFolderManager()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();updateFolders(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
function saveFolders(dialog) {
	var $dialog = $("#"+dialog.id), $active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
	$dialog.addClass("working");
	user_nostro_folders = folders_updated;

	var active_deleted = true;

	for ( f = 0; f < user_nostro_folders.length; f++ ) {
		if ( $active == user_nostro_folders[f].id ) {
			active_deleted = false;
			break;
		}
	}

	for ( var i = 0; i < data.length; i++ ) {
		var _resetFolder = true;
		for ( var n = 0; n < user_nostro_folders.length; n++ ) {
			if ( data[i].labelid == user_nostro_folders[n].id ) {
				data[i].label = user_nostro_folders[n].name;
				_resetFolder = false;
				break;
			}
		}
		if ( _resetFolder ) {
			data[i].label = "None";
			data[i].labelid = "None";
		}

	}
	folders_updated = false;
	folders_deleted = false;
	store.set('nostro_folders', user_nostro_folders);
	setTimeout( function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateFolders();
		if ( !user_nostro_folders.length || active_deleted ) { $("#_allAccounts").trigger("click"); }
		dialogHider(dialog);
	}, 300);
}
function updateFolders(dialog) {
	if ( folders_updated ) {
		folders_updated = [];
		var duplicate_names = false, $folderList = $(".folder-list");
		$folderList.find("li.error").removeClass("error");
		$folderList.children("li").each(function() {
			folders_updated.push( { "name":$(this).attr("data-folder"), "id":$(this).attr("data-folder-id") });
			var _name = $(this).attr("data-folder");
			$(this).siblings().each(function() {
				if ( $(this).attr("data-folder") == _name ) {
					$(this).addClass("error");
				}
			});
		});
		if ( $folderList.find("li.error").size() ) {
			duplicate_names = true;
		}
		if ( duplicate_names ) {
			return false;
		} else {
			var save_folders = false;
			if ( user_nostro_folders.length != folders_updated.length ) {
				save_folders = true;
			} else {
				for (var i = 0; i < user_nostro_folders.length; i++) {
					if ( user_nostro_folders[i].name != folders_updated[i].name || user_nostro_folders[i].id != folders_updated[i].id ) {
						save_folders = true;
						break;
					}
				}
			}
			if ( save_folders || folders_deleted ) {
				if ( folders_deleted ) {
					buildConfirmDialog( "You've removed some existing folders.", "Are you sure you want to continue?", function(){saveFolders(dialog)});
				} else {
					saveFolders(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}
function moveAccounts(_id) {
	var _folder, _message, _rowsForUpdate = [], _sel = selectedRowIds.length;
	for ( var i = 0; i < user_nostro_folders.length; i++ ) {
		if ( user_nostro_folders[i].id == _id ) {
			_folder = user_nostro_folders[i];
			_message = "Selected accounts were moved to &quot;"+_folder.name+"&quot;";
			break;
		}
	}
	if ( _id == "None" ) {
		_folder = [{ name:"None", id:"None"}];
		_message = "Selected accounts were removed from their folders";
	}
	for ( var i = 0, l = _sel; i < l; i++ ) {
		var _item = selectedRowIds[i];
		if ( _item ) {
			_rowsForUpdate.unshift(_item);
		}
	}
	for ( var i = 0; i < _rowsForUpdate.length; i++ ) {
		data[dataView.getIdxById(_rowsForUpdate[i])].label = _folder.name;
		data[dataView.getIdxById(_rowsForUpdate[i])].labelid = _folder.id;
	}
	grid.setSelectedRows(0);
	selectedRowIds = [];
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) { collapseAllGroups(); }
	groupedSetting = 1;
	buildNotification(_message, 300, 3000);
	store.set('nostroAccounts', dataView.getItems());
	$("#viewMenu .assign-folders").find("a[data-folder-id='"+_folder.id+"']").trigger("click");
}


/**********************************************************************
REQUEST REPORTS
**********************************************************************/
function showAccountStatementModal(e) {
	e.preventDefault();
	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.","It will be available for download in the &quot;Download Reports&quot; section shortly.","");
		}, 3000);
	};
	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).parent("div.data-column").find("div.data-text"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='statementSpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();
		} else if ( _date == "dr" ) {
			$("#statementSpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='statementFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='statementToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var statementeDatRange = $("#statementFromDate, #statementToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "statementFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					statementeDatRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#statementSpecificDate, #statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
		$row.add("focused");
	};
	var formElements = [
		{ name: "Report Format", id: "stmt-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "MT940", value: "MT940"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "stmt-name", type: "input", max: 30 },
		{ name: "Description", id: "stmt-desc", type: "input", max: 75 },
		{ name: "Data From", id: "stmt-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function(){ $(this).addClass("focused") }).on("focusout", function(){ $(this).removeClass("focused") }).appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $note;
		if ( formElements[i].type == "select" ) {
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
		} else if ( formElements[i].type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}
		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}
		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}
		$el.appendTo($data);
		if ( formElements[i].note ) {
			$note = $("<div class='data-text'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestStatement",
		title: "Account Statement Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
function showBalanceHistoryModal(e) {
	e.preventDefault();
	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report took more than 3 seconds to generate.","It will be available for download in the &quot;Downloads&quot; section shortly.","");
		}, 3000);
	};
	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).parent("div.data-column").find("div.data-text"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='summarySpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();
		} else if ( _date == "dr" ) {
			$("#summarySpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='summaryFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='summaryToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var summaryDateRange = $("#summaryFromDate, #summaryToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "summaryFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					summaryDateRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#summarySpecificDate, #summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
		$row.add("focused");
	};
	var formElements = [
		{ name: "Report Format", id: "bal-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "MT940", value: "MT940"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "bal-name", type: "input", max: 30 },
		{ name: "Description", id: "bal-desc", type: "input", max: 75 },
		{ name: "Data From", id: "bal-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function(){ $(this).addClass("focused") }).on("focusout", function(){ $(this).removeClass("focused") }).appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $note;
		if ( formElements[i].type == "select" ) {
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
		} else if ( formElements[i].type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}
		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}
		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}
		$el.appendTo($data);
		if ( formElements[i].note ) {
			$note = $("<div class='data-text'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestBalances",
		title: "Balance Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}


/**********************************************************************
SERVICE REQUEST WARNING
**********************************************************************/
function navigateToServiceRequests(e) {
	document.location.href = "service-requests-from-account.html#new";
}
function createServiceRequestWarning(e) {
	e.preventDefault();
	buildConfirmDialog("This will take you to the Service Requests Application to create a new account related service request.", "Do you want to proceed?", function() {
		navigateToServiceRequests(e)
	});
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE ACCOUNT SUMMARY GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#summaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var sortcolumns = [
		{id:"accountname", name:"Account Name", field:"accountname", toolTip:"Click to sort by Account Name", width: 160, sortable:true, visible: true},
		{id:"accountnumb", name:"Account Number", field:"accountnumb", toolTip:"Click to sort by Account Number", width: 160, sortable: true, visible: true},
		{id:"currency", name:"Currency", field:"currency", toolTip:"Click to sort by Account Currency", width: 75, sortable:true, visible: true},
		{id:"openingavailablebal", name:"Opening Available Balance", field:"openingavailablebal", toolTip:"Click to sort by Opening Available Balance", width: 130, sortable:true, cssClass: "num pos", headerCssClass: "righted", visible: true}
	];
	new Slick.Controls.SlickPreviewSortPicker(sortcolumns, grid, options);
	var $accountsGrid = $(grid.getCanvasNode()),
	$scrollArea = $("#summaryGrid").parent("div.scroll-area"),
	$bottomControls = $("#accountGrid .bottom-controls"),
	$selected = $("#selectedCount");
	grid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();	
		var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			if (rows.length > 1) {
				$cmenu = $("#multipleContextMenu")
			} else {
				$cmenu = $("#contextMenu")
			}
		};
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {		
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});	  
	grid.onSelectedRowsChanged.subscribe(function(e) {
		clearTimeout(loadRecordTimer);
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedReportOwners = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedReportOwners.push(item.ownedby)
			}
		}
		if ( !rows.length ) {
			grid.resetActiveCell();
			$(".selection-panel").show().find("div[data-value='multiple-selection']").hide();
			$(".selection-panel").find("div[data-value='no-selection']").show();
			$selected.html('');
		} else if ( rows.length === 1 ) {
			if ( !grid.getActiveCell() || grid.getActiveCell().row != rows[0] ) {
				 grid.setActiveCell( rows[0], 1);
			}
			$selected.html(selectedRowIds.length);
			$(".right-panel").scrollTop("0");
			$("#accountActivityTab").trigger("click");
			$(".selection-panel").hide();
		} else if ( rows.length > 1 ) {
			$(".right-panel").removeClass("loading");
			$(".selection-panel").show().find("div[data-value='no-selection']").hide()
			$(".selection-panel").find("div[data-value='multiple-selection']").show();
			$selected.html(selectedRowIds.length);
		}
	});
	grid.onSort.subscribe(function(e, args) {
		sortcol = args.sortCol.field;
		sortdir = args.sortAsc ? 1 : -1;
		dataView.fastSort(sortcol, args.sortAsc);
	});
	grid.onClick.subscribe(function(e, args) {
		var row = args.row;
		if ( grid.getActiveCell() && grid.getActiveCell().row == args.row ) {
			grid.resetActiveCell();
		}
		grid.setSelectedRows([row]);
		grid.setActiveCell(row, 1);
	});
	grid.onActiveCellChanged.subscribe(function(e, args) {
		var item = grid.getActiveCell(), $row = $(grid.getActiveCellNode()).closest(".slick-row");
		if ( $row.is(".slick-group, .slick-group-totals") ) {
			return false;
		} else {
			if ( item ) {
				if ( grid.getActiveCell().row != grid.getSelectedRows([0]) || !grid.getSelectedRows().length ) {
					 grid.setSelectedRows([item.row]);
				}
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	if (store.get('nostroAccounts')) {
		data = store.get('nostroAccounts')
	}
	dataView.setItems(data);
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	});
	dataView.setFilter(myFilter);
	grid.setColumns(columns);


	/**********************************************************************
	CALCULATE GRAND TOTALS
	**********************************************************************/	
	calculateTotals()



	/**********************************************************************
	INITIALIZE ACCOUNT ACTIVITY GRID
	**********************************************************************/
	var activityGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	activityDataView = new Slick.Data.DataView({
		activityGroupItemMetadataProvider: activityGroupItemMetadataProvider
	});
	activityGrid = new Slick.Grid("#activityGrid", activityDataView, activityColumns, activityOptions);
	activityGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	activityGrid.registerPlugin(activityGroupItemMetadataProvider);
	activityGrid.registerPlugin(activityCheckboxSelector);
	var activityColumnpicker = new Slick.Controls.ColumnPicker(activityColumns, activityGrid, activityOptions, 'nostroActivityOrder', 'nostroActivityWidths', ["activityCheckboxSelector"]);
	activityGrid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = activityGrid.getCellFromEvent(e),
			row = cell.row,
			rows = activityGrid.getSelectedRows(),
			$cmenu = $("#transactionContextMenu");
		if ($.inArray(row, rows) == -1) {
			activityGrid.setSelectedRows([row])
		}
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	activityGrid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		activitySelectedRowIds = [];
		var rows = activityGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = activityDataView.getItem(rows[i])
			if (item.id) activitySelectedRowIds.push(item.id)
		}
		if(activitySelectedRowIds.length > 0) {
			$("#activity .bottom-controls").removeClass("hidden");
			$("#activity .gutter-30").addClass("has-bottom-controls");
			$("#selectedActivityCount").html(activitySelectedRowIds.length);
		} else {
			$("#activity .bottom-controls").addClass("hidden");
			$("#activity .gutter-30").removeClass("has-bottom-controls");
			$("#selectedActivityCount").html('');
		}
		activityGrid.resizeCanvas();
	});
	activityGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		activityDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	activityGrid.onClick.subscribe(function(e, args) {
		var acell = activityGrid.getCellFromEvent(e), arow = acell.row, $arow = $(e.target).closest(".slick-row");
		if( !$arow.is(".slick-group, .slick-group-totals") ) {
			e.preventDefault();
			activityGrid.setSelectedRows(0);
			activitySelectedRowIds = [];
			function showTransactionDetails() {
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
				$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
				$controls = $("<div class='control-list right' />").appendTo($navigationBar),
				$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
				$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
				$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
				details = [
					{name: "Company", id: "td1", type: "text", data: "LLC Manufacturing Inc."},
					{name: "Account Name", id: "td2", type: "text", data: "AUD Operations"},
					{name: "Account Number", id: "td3", type: "text", data: "334-1233-212"},
					{name: "Transaction Code", id: "td4", type: "text", data: "TC3457"},
					{name: "BAI Code", id: "td5", type: "text", data: "BAI39433"},
					{name: "Posting Date", id: "td6", type: "text", data: smartDates("yesterday")},
					{name: "Value Date", id: "td7", type: "text", data: smartDates("yesterday")},
					{name: "Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "AUD 1,300.00"},
					{name: "Transaction Narrative", id: "td9", type: "text", data: "Praesent magna purus, posuere et porta ac, volutpat ut dui. Ut non mauris orci. In a porttitor felis. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt."},
					{name: "Transaction Description", id: "td10", type: "text", data: "Praesent magna purus, posuere et porta ac, volutpat ut dui. Ut non mauris orci. In a porttitor felis. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt."},
					{name: "Voucher Images", id: "td11", type: "text", data: "<a href='javascript:void(0)'><i class='fa fa-image fa-fw' style='margin-right: 8px;'></i>View Images</a>"},
					{name: "SWIFT MT", id: "td12", type: "text", data: "Swift Message Type" },
					{name: "Header", id: "td13", type: "text", data: "data.swiftMsgObj.header.line[d]", attributes: [{name:"style", value:"white-space: normal; word-wrap: break-word; white-space: pre-wrap; *white-space: pre; word-break: break-word;"}] },
					{name: "&nbsp;", id: "td13", type: "text", data: "data.swiftMsgObj.header.line[d]", attributes: [{name:"style", value:"white-space: normal; word-wrap: break-word; white-space: pre-wrap; *white-space: pre; word-break: break-word;"}]  },
					{name: "&nbsp;", id: "td13", type: "text", data: "data.swiftMsgObj.header.line[d]", attributes: [{name:"style", value:"white-space: normal; word-wrap: break-word; white-space: pre-wrap; *white-space: pre; word-break: break-word;"}]  }
				],
				$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
				$formSection = $("<div class='form-section' />").appendTo($detailsForm);
				for (var i = 0; i < details.length; i++) {
					var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>"+details[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details[i].id+"'>"+details[i].data+"</div>").appendTo($data);
					if ( details[i].attributes ) {
						for ( var a = 0; a < details[i].attributes.length; a++ ) {
							$el.attr( details[i].attributes[a].name ,details[i].attributes[a].value );
						}
					}
				};
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "transactionDetails",
				title: "Transaction Details",
				size: "medium",
				icon: "<i class='fa fa-file-text'></i>",
				content: function(){return showTransactionDetails()},
				buttons: [
					{ name: "Close", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
					{ name: "Transaction Detail Report", icon: "<i class='fa fa-file-text fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}], cssClass: "primary" }
				]
			}
			dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
		}
	});
	activityGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('nostroActivityWidths', activityGrid.getColumns());
	});
	$(activityGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			acolumnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			activityDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	activityGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(acolumnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	activityDataView.onRowCountChanged.subscribe(function(e,args) {
		activityGrid.updateRowCount();
		activityGrid.render();
	});
	activityDataView.onRowsChanged.subscribe(function(e,args) {
		activityGrid.invalidateRows(args.rows);
		activityGrid.render();
		if (activitySelectedRowIds.length > 0)
		{
			var activitySelRows = [];
			for (var i = 0; i < activitySelectedRowIds.length; i++)
			{
				var idx = activityDataView.getRowById(activitySelectedRowIds[i]);
				if (idx != undefined)
					activitySelRows.push(idx);
			}
			activityGrid.setSelectedRows(activitySelRows);
		}
	});
	activityDataView.setItems(activityData);
	activityDataView.setFilterArgs({
		findActivityString: findActivityString
	});
	activityDataView.syncGridSelection(activityGrid, true, false);
	activityDataView.syncGridCellCssStyles(activityGrid, "contextMenu");
	activityDataView.setFilter(myActivityFilter);
	activityGrid.setColumns(activityColumns);
	if ( store.get('nostroActivityOrder') ) {
		var visibleActivityColumns = [];
		for (var i = 0; i < store.get('nostroActivityOrder').length+1; i++) {
			if (activityColumns[i].visible) {
				visibleActivityColumns.push(activityColumns[i])
			}
		}
		activityGrid.setColumns(visibleActivityColumns);
	}
	activityGrid.setHeaderRowVisibility(false);


	/**********************************************************************
	INITIALIZE BALANCE HISTORY GRID
	**********************************************************************/
	var balanceHistoryItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	balanceDataView = new Slick.Data.DataView({
		balanceHistoryItemMetaProvider: balanceHistoryItemMetaProvider
	});
	balancehistorygrid = new Slick.Grid("#balanceGrid", balanceDataView, bcolumns, boptions);
	balancehistorygrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	balancehistorygrid.registerPlugin(balanceHistoryItemMetaProvider);
	var bcolumnpicker = new Slick.Controls.ColumnPicker(bcolumns, balancehistorygrid, boptions, 'nostroBalanceOrder', 'nostroBalanceWidths', []);
	balancehistorygrid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = balancehistorygrid.getCellFromEvent(e),
			row = cell.row,
			rows = balancehistorygrid.getSelectedRows(),
			$cmenu = $("#balanceContextMenu");
		if ($.inArray(row, rows) == -1) {
			balancehistorygrid.setSelectedRows([row])
		}
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	balancehistorygrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		balanceDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	balancehistorygrid.onClick.subscribe(function(e, args) {
		var bcell = balancehistorygrid.getCellFromEvent(e);
		var brow = balancehistorygrid.row;
		$('#accountActivityTab').trigger('click');
	});
	balancehistorygrid.onColumnsResized.subscribe(function(e, args) {
		store.set('nostroBalanceWidths', balancehistorygrid.getColumns());
	});
	balanceDataView.onRowCountChanged.subscribe(function(e, args) {
		balancehistorygrid.updateRowCount();
		balancehistorygrid.render();
	});
	balanceDataView.onRowsChanged.subscribe(function(e, args) {
		balancehistorygrid.invalidateRows(args.rows);
		balancehistorygrid.render();
	});
	balanceDataView.setItems(bdata);
	balanceDataView.syncGridSelection(balancehistorygrid, true, false);
	balanceDataView.syncGridCellCssStyles(balancehistorygrid, "contextMenu");
	balancehistorygrid.setColumns(bcolumns);
	if (store.get('nostroBalanceOrder')) {
		var visibleBalanceColumns = [];
		for (var i = 0; i < store.get('nostroBalanceOrder').length; i++) {
			if (bcolumns[i].visible) {
				visibleBalanceColumns.push(bcolumns[i])
			}
		}
		balancehistorygrid.setColumns(visibleBalanceColumns);
	}


	/**********************************************************************
	INITIALIZE LIQUIDITY GRID
	**********************************************************************/
	var liquidityItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	liquidityDataView = new Slick.Data.DataView({
		liquidityItemMetaProvider: liquidityItemMetaProvider
	});
	liquidityGrid = new Slick.Grid("#liquidityGrid", liquidityDataView, liqColumns, liqOptions);
	liquidityGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	liquidityGrid.registerPlugin(liquidityItemMetaProvider);
	var liqColumnpicker = new Slick.Controls.ColumnPicker(liqColumns, liquidityGrid, liqOptions, 'nostroLiquidityOrder', 'nostroLiquidityWidths', []);
	liquidityGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		liquidityDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	liquidityGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('nostroLiquidityWidths', liquidityGrid.getColumns());
	});
	$(liquidityGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			liqcolumnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			liquidityDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	liquidityGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(liqcolumnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	liquidityDataView.onRowCountChanged.subscribe(function(e,args) {
		liquidityGrid.updateRowCount();
		liquidityGrid.render();
	});
	liquidityDataView.onRowsChanged.subscribe(function(e,args) {
		liquidityGrid.invalidateRows(args.rows);
		liquidityGrid.render();
	});
	liquidityDataView.setItems(liqData);
	liquidityDataView.syncGridSelection(liquidityGrid, true, false);
	liquidityDataView.syncGridCellCssStyles(liquidityGrid, "contextMenu");
	liquidityDataView.setFilter(myLiquidityFilter);
	liquidityGrid.setColumns(liqColumns);
	if ( store.get('nostroLiquidityOrder') ) {
		var visibleLiquidityColumns = [];
		for (var i = 0; i < store.get('nostroLiquidityOrder').length; i++) {
			if (liqColumns[i].visible) {
				visibleLiquidityColumns.push(liqColumns[i])
			}
		}
		liquidityGrid.setColumns(visibleLiquidityColumns);
	}
	liquidityGrid.setHeaderRowVisibility(false);



	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).on("resize", function() {
		grid.resizeCanvas();
		balancehistorygrid.resizeCanvas();
		activityGrid.resizeCanvas();
		liquidityGrid.resizeCanvas();
	});


	/**********************************************************************
	FOLDER VIEW INTERACTIONS
	**********************************************************************/
	$("#_allAccounts").on("click", function(e) {
		e.preventDefault();
		var _folder = "";
		if ( labelString != _folder ) {
			labelString = _folder;
		}
		folderFilter();
		$("#selectedFolder").html("All Accounts")
	});
	$(".manage-folders").on("click", showFolderManagerDialog);
	$("#_inlineFolderButton").on("click", addFolderInline);
	$("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
		if (e.keyCode == 13) {
			addFolderInline();
		}
	});
	populateFolders();


	/**********************************************************************
	SETTINGS MENU
	**********************************************************************/
	function returnRate(a,b) {
		var rate;
			if (a == "AUD") {if (b == "AUD") {rate = 1.0000} else if (b == "SGD") {rate = 0.8222}
			} else if (a == "CNY") {if (b == "AUD") {rate = 5.9200} else if (b == "SGD") {rate = 4.8400}
			} else if (a == "EUR") {if (b == "AUD") {rate = 0.7502} else if (b == "SGD") {rate = 0.6100}
			} else if (a == "HKD") {if (b == "AUD") {rate = 7.4910} else if (b == "SGD") {rate = 6.1230}
			} else if (a == "IDR") {if (b == "AUD") {rate = 9426.0710} else if (b == "SGD") {rate = 7708.4500}
			} else if (a == "INR") {if (b == "AUD") {rate = 53.8600} else if (b == "SGD") {rate = 43.8700}
			} else if (a == "KRW") {if (b == "AUD") {rate = 1081.8300} else if (b == "SGD") {rate = 886.1722}
			} else if (a == "KHR") {if (b == "AUD") {rate = 3852.6700} else if (b == "SGD") {rate = 3164.1900}
			} else if (a == "MYR") {if (b == "AUD") {rate = 2.9201} else if (b == "SGD") {rate = 2.3902}
			} else if (a == "NZD") {if (b == "AUD") {rate = 1.2000} else if (b == "SGD") {rate = 0.9800}
			} else if (a == "SGD") {if (b == "AUD") {rate = 1.2222} else if (b == "SGD") {rate = 1.0000}
			} else if (a == "THB") {if (b == "AUD") {rate = 28.9100} else if (b == "SGD") {rate = 23.7100}
			} else if (a == "USD") {if (b == "AUD") {rate = 0.9600} else if (b == "SGD") {rate = 0.7900}
			} else if (a == "VND") {if (b == "AUD") {rate = 20208.5600} else if (b == "SGD") {rate = 16565.4300}
			};
		return(rate)
	}
	$("#ccyMenu").on("click.set-ccy", "a", function(e) {
		e.preventDefault();
		groupCCYSetting = $(this).attr("data-value");
		for (var i = 0; i < data.length; i++) {
			data[i].fxrate = returnRate(groupCCYSetting, data[i].currency).toFixed(4);
		}
		dataView.setItems(data)
		filterAccounts();
		$("span[data-object='reference-ccy']").empty().html(groupCCYSetting);
		$("#_totalsRow [data-value='totalccy']").html(groupCCYSetting);
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout( function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$("body").on("click.trxngroup-by", "#trxnGroupBy [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		trxngroupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});


	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		}
	});
	$("#activityReportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = activityGrid.getSelectedRows().length;
		var menuLink = $("#activityReportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestActivityReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestActivityReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestActivityReportsMenu"
			});
		}
	});


	/**********************************************************************
	ACTION MENU INTERACTION
	**********************************************************************/
	$("#actionMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength =  grid.getSelectedRows().length;
		var menuLink = $("#actionMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({"href":"#actionMenuNoSelected"});
		} else if (rowsLength == 1) {
			menuLink.attr({"href":"#actionMenu"});
		} else if (rowsLength > 1) {
			menuLink.attr({"href":"#actionMenuMultiSelected"});
		}
	});
	$("#viewActivityFromBalanceDate").on("click", function(e){
		e.preventDefault();
		balancehistorygrid.setSelectedRows([]);
		$('#accountActivityTab').trigger('click');
	});


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	function findFilter() {
		var rows = grid.getSelectedRows();
		if(rows.length > 0) {
			grid.setSelectedRows(0);
		}
		if(findString == "") {
			dataView.setFilterArgs({
				labelString: labelString,
				findString: findString
			});	
		} else {
			dataView.setFilterArgs({
				labelString: labelString,
				findString: findString
			});
		}
		dataView.refresh();
	}
	$("#acctSearchClear").on("click", function(e) {
		e.preventDefault(); e.stopPropagation();
		$("#_findAccounts").val('');
		$("#_findAccounts").focus();
		 $("#acctSearchClear").hide();
		findString = "";
		findFilter();
	});
	$("#_findAccounts").keyup(function (e) {
		if (e.which == 27) {
		  $("#acctSearchClear").hide();
		  this.value = '';
		}
		findString = this.value;
		findFilter();
		if ( this.value != "" ) {
			$("#acctSearchClear").show();
		} else {
			$("#acctSearchClear").hide();
		}
	});
	$("#findAccountOptions").on("click.set-find", "a", function(e) {
		e.preventDefault();
		var findPlaceholder = $(this).text(), filterString = $(this).attr("data-value");
		if (findDataPoint != filterString) {
			if ( document.createElement("input").placeholder != undefined ) {
				$("#_findAccounts").attr("placeholder", findPlaceholder);
			}
			findDataPoint = filterString;
			$("#_findAccounts").val('').focus();
			$("#acctSearchClear").hide();
			findString = '';
			findFilter();
		}
		$("#findAccountOptions").hide();
	});
	$("#toggleFilter").on("click", function(e) {
		e.preventDefault();
		if ( $(".search-menu").is(":visible") ) {
			$(this).removeClass("btn-on");
			$(".search-menu").hide();
			$("#summaryGrid").css({"top": 0});
			grid.resizeCanvas();
		} else {
			$(this).addClass("btn-on");
			$(".search-menu").show().find("input.search-input").focus();
			$("#summaryGrid").css({"top": 50});
			grid.resizeCanvas();
		}
	});
	$(".search-options").on("click", function(e) {
		e.preventDefault(); e.stopPropagation();
		function hideMenu() {
			$("#findAccountOptions").hide();
			$(document).off("keyup.hide-search");
			$(window).off("resize.hide-search");
			$("body").off("click.hide-search");
		}
		if ( $("#findAccountOptions").is(":visible") ) {
			hideMenu();
		} else {
			$(".control-menus .control-menu").hide();
			$("#findAccountOptions").show().css({"top":"218px"});
			$(window).on("resize.hide-search", function() {
				hideMenu()
			});
			$(document).on("keyup.hide-search", function(e) {
				e.preventDefault();
				if(e.keyCode == 27) {
					hideMenu()
				}
			});
			$("body").on("click.hide-search", function() {
				hideMenu()
			});
		}
	});

	$("#toggleActivityFilter").on("click", toggleActivityFilterRow);
	$("#toggleLiquidityFilter").on("click", toggleLiquidityFilterRow);


	/**********************************************************************
	ACCOUNT ACTIVITY / BALANCE HISTORY DATE FILTERS
	**********************************************************************/
	$("#balDateToday").on("click", function(e){
		e.preventDefault();
		$("span[data-object='balance-date']").empty().html("Today");
	});
	$("#balDateYesterday").on("click", function(e){
		e.preventDefault();
		$("span[data-object='balance-date']").empty().html("Yesterday");
	});
	$("#balDateLastBusinessDay").on("click", function(e){
		e.preventDefault();
		$("span[data-object='balance-date']").empty().html("Last Business Day");
	});
	$("#_specificBalDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#settingsMenuControl").removeClass("on");
			$("#balanceDate").find("li.active").removeClass("active");
			$("#speBalanceDate").closest("li").addClass("active");
			$("span[data-object='balance-date']").empty().html(dateText);
			$("div.control-list").find("a[href='#viewMenu']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({
				"data-panel": "#accountGrid",
				"data-switch": "switch-panels"
			}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		}
	}).click(function(e) {
		e.stopPropagation();
	});
	$("#_trxnspecificDate").datepicker({
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			onSelect: function(dateText) {
				$("#trxnDate").find("li.active").removeClass("active");
				$("#trxnSpecDateItem").closest("li").addClass("active");
				$("div.control-list").find("a[href='#trxnDate']").children("span.item-text").text(dateText);
				$("#activityDate").html(dateText);
				$("div.control-list").find("a[href='#trxnDate']").parent(".btn").removeClass("on");
				$("div.control-menus div.control-menu").hide();
				$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
				$('#accountActivityTab').trigger('click');
	
			}
		}).click(function(e) {e.stopPropagation();
	});
	var trxnDateRangeSelection = $("#_trxnrangeDateFrom, #_trxnrangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_trxnrangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				trxnDateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {
		e.stopPropagation();
	});
	$("#_trxnDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_trxnrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_trxnrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#trxnDate").find("li.active").removeClass("active");
		$("#trxnRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#accountActivityTab').trigger('click');
		$("div.control-list").find("a[href='#trxnDate']").children("span.item-text").text(fromDate+" - "+toDate);
		$("#activityDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#trxnDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});
	$("#_balspecificDate").datepicker({
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			onSelect: function(dateText) {
				$("#balDate").find("li.active").removeClass("active");
				$("#balSpecDateItem").closest("li").addClass("active");
				$("div.control-list").find("a[href='#balDate']").children("span.item-text").text(dateText);
				$("#balanceHistoryDate").html(dateText);
				$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
				$("div.control-menus div.control-menu").hide();
				$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
				$('#balanceHistoryTab').trigger('click');
	
			}
		}).click(function(e) {e.stopPropagation();
	});
	var balDateRangeSelection = $("#_balrangeDateFrom, #_balrangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_balrangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				balDateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {
		e.stopPropagation();
	});
	$("#_balDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_balrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_balrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#balDate").find("li.active").removeClass("active");
		$("#balRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#balanceHistoryTab').trigger('click');
		$("div.control-list").find("a[href='#balDate']").children("span.item-text").text(fromDate+" - "+toDate);
		$("#balanceHistoryDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});
	$("#_liqspecificDate").datepicker({
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			onSelect: function(dateText) {
				$("#liqDate").find("li.active").removeClass("active");
				$("#liqSpecDateItem").closest("li").addClass("active");
				$("div.control-list").find("a[href='#liqDate']").children("span.item-text").text(dateText);
				$("#balanceHistoryDate").html(dateText);
				$("div.control-list").find("a[href='#liqDate']").parent(".btn").removeClass("on");
				$("div.control-menus div.control-menu").hide();
				$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
				$('#liquidityTab').trigger('click');
	
			}
		}).click(function(e) {e.stopPropagation();
	});
	var liqDateRangeSelection = $("#_liqrangeDateFrom, #_liqrangeDateTo").datepicker({
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				var option = this.id == "_liqrangeDateFrom" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
					liqDateRangeSelection.not(this).datepicker("option", option, date);
			}
		}).click(function(e) {e.stopPropagation();});
	$("#_liqDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_liqrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_liqrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#liqDate").find("li.active").removeClass("active");
		$("#liqRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#liquidityTab').trigger('click');
		$("div.control-list").find("a[href='#liqDate']").children("span.item-text").text(fromDate+" - "+toDate);
		$("#liquidityDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#liqDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});
		
		
	/**********************************************************************
	REQUEST REPORT MODALS
	**********************************************************************/
	$(".request-statement").on("click", showAccountStatementModal);
	$(".request-balances").on("click", showBalanceHistoryModal);


	/**********************************************************************
	CREATE NEW SERVICE REQUEST
	**********************************************************************/
	$(".new-service-request").on("click", createServiceRequestWarning);


	/**********************************************************************
	CLOSE PREVIOUS NEXT
	**********************************************************************/
	$("[data-action='previousAccount']").on("click", function(e) {
		e.preventDefault();
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow-1;
		if ( $accountsGrid.find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
			activeRow = activeRow-1;
		}	
		$accountsGrid.find("div[row='"+activeRow+"'] div.slick-cell").eq(1).trigger("click")
	});
	$("[data-action='nextAccount']").on("click", function(e) {
		e.preventDefault();
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow+1;
		if ( $accountsGrid.find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
			activeRow = activeRow+1;
		}
		$accountsGrid.find("div[row='"+activeRow+"'] div.slick-cell").eq(1).trigger("click")
	});
	$("#closeDetailView").on("click", function(e) {
		e.preventDefault();
		grid.setSelectedRows({});
		grid.resetActiveCell();
	});



});



