/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Report Centre Onscreen Guide",
	action: "slider"
}, {
	title: "Can I create a new scheduled report to be produced daily?",
	faq: "<p>Click the New Report button &gt; Enter the required details, ensure Frequency is set to Daily &gt; Save.</p>"
}, {
	title: "How can I get reports emailed directly to me?",
	faq: "<p>Scheduled reports can be emailed to you by ticking the Deliver By Email option, however you must have set a Report Retrieval Code under User Preferences.</p><p>Emailed reports go directly to the email address registered to your User Profile.</p>"
}, {
	title: "How do I set a Report Retrieval Code?",
	faq: "<p>Set a report retrieval code to allow you to receive a scheduled report via email by:<br />Click on the Settings & Preferences menu (displayed as your User Name on the top right of the screen) &gt; Manage my preferences &gt; Enter a code in the Report Retrieval Code field.</p><p>When you receive a report via email you will be required to enter this code in order to access your report.</p>"
}, {
	title: "How do I edit a scheduled report?",
	faq: "<p>Right-click on the report you wish to change and select Edit Report Schedule &gt; Update details as required &gt; Click Save.</p>"
}];