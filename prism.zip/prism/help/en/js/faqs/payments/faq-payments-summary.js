/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Payments Onscreen Guide",
	action: "slider"
}, {
	title: "Which payments do I see in Current Payments?",
	faq: "<p>The Current Payment screen includes payments that have not been sent for processing as well as those that have been processed within the last seven calendar days.</p>"
}, {
	title: "Why can’t I approve a payment?",
	faq: "<p>Check the following:<br />&gt; Do you have the appropriate permissions to approve payments?<br /> &gt; Did you create the payment? Depending on your permissions, you may not be able to approve a payment you created.<br /> &gt; What is the payment status? Payments can only be approved if they have a status of Pending Approval.<br /> &gt; You may have already approved the payment. View the payment audit information for more details.</p>"
}, {
	title: "How do I know who needs to sign the transaction with a security device?",
	faq: "<p>Only the final approver will be asked for their security device credentials to send the payment to the Bank for processing.</p>"
}, {
	title: "Why hasn’t my payment been processed?",
	faq: "<p>The status of the payment will give you an indication as to why it may not have been processed yet. For example, if the status is:<br />&gt; Pending Approval. The payment has not yet received all necessary approvals. It must be approved before it can be processed.<br />&gt; Approver Rejected. The payment has been rejected by an approver within your organisation. View the payment details to identify the reason for rejection.<br />&gt; Bank Rejected. View the payment details to identify the reason for rejection.<br />&gt; Completed with Errors. While the payment was processed by ANZ, one or more instructions within the payment could not be processed. Review the payment and individual payment instruction details to view the error messages.</p>"
}, {
	title: "What are the payment cut-off times? ",
	faq: "<p>Payment processing and cut-off times vary depending on the payment types and currencies used.  The system determines the cut-off time based on the following attributes; the Debit Account Currency, the Debit Country, Payment Currency and the Payment Type.</p><p>You can view the cut-off time for a payment in the Cut-off Time column located in the Current Payments screen.</p>"
}, {
	title: "Can I produce reports for more than one payment at a time?",
	faq: "<p>Yes, select the payments you want to run the report for and then click on the Actions menu and select the report you want to run. Alternatively, right click on the selected payments to bring up the Actions menu.</p>"
}, {
	title: "Why can't I copy payments in the Current Payment screen?",
	faq: "<p>Check the following: <br />&gt; Are you selecting one payment at a time? Payments can only be copied one at a time.<br />&gt; What is the payment status? Payments can only be copied if they are in one of the following statuses: Bank Rejected, Completed, Completed with Errors, Future Dated or Processing<br />&gt; Do you have permissions to create a payment of the same type you are trying to copy?</p>"
}, {
	title: "How long do deleted payments stay in system?",
	faq: "<p>Deleted payments that have not been released to the bank will remain visible in the system for seven days. For audit purposes, you cannot delete a payment that has been processed by ANZ.</p>"
}, {
	title: "How do I edit a payment?",
	faq: "<p>A payment must be in a Draft, Needs Repair or Approver Rejected status to enable editing. If the payment is in a Pending Approval status, it needs to be Recalled or Rejected before it can be edited.</p><p>To edit the payment, select the payment, click on the Actions menu and select Edit. Alternatively you can right click on the payment to bring up the Actions menu.</p>"
}, {
	title: "Can I stop a future dated payment that has been submitted to ANZ for processing?",
	faq: "<p>Yes, if a payment is in a status of Future Dated, you can stop it by selecting Stop from the Actions menu.</p>"
}];