/**********************************************************************
ACCOUNTS
**********************************************************************/
var _accounts = [{
		name: "AU Savings",
		number: "7717777731",
		ccy: "AUD"
	}, {
		name: "Melbourne Operations",
		number: "2123115211",
		ccy: "AUD"
	}, {
		name: "Singapore Funding",
		number: "5153523541",
		ccy: "SGD"
	}, {
		name: "Bangalore Operations",
		number: "3539939711",
		ccy: "INR"
	}, {
		name: "SGD Funding",
		number: "3441295104",
		ccy: "SGD"
	}, {
		name: "INR Savings",
		number: "3564964147",
		ccy: "INR"
	}, {
		name: "Trade Funding",
		number: "9494937937",
		ccy: "SGD"
	}, {
		name: "Loan Repayment",
		number: "8474722322",
		ccy: "AUD"
	}, {
		name: "Nightly Sweep",
		number: "3843947473",
		ccy: "AUD"
	}, {
		name: "AUD Liquidity",
		number: "2333576832",
		ccy: "AUD"
	}],
	_accountTypeAhead = [];
for (var j in _accounts) {
	_accountTypeAhead.push(_accounts[j].name + " - " + _accounts[j].number + " (" + _accounts[j].ccy + ")")
}
function split(val) {
	return val.split(/,\s*/);
}
function extractLast(term) {
	return split(term).pop();
}
function rand(min, max) {
	var offset = min;
	var range = (max - min) + 1;
	var randomNumber = Math.floor(Math.random() * range) + offset;
	return randomNumber;
}


/**********************************************************************
DIALOGS
**********************************************************************/
function showAddAccounts(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearAccountsFilter").show()
			} else {
				$("#clearAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#AddAccountsFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
		$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each(_accounts, function() {
		$li = $("<li data-name='" + this.name + "' data-number='" + this.number + "'>").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.closest("li");
				}
				$("#accountInput").val($target.attr("data-name") + " - " + $target.attr("data-number"));
				$("#requestNameInput").focus();
				if (rand(0, 2) % 2 == 0) {
					$("#existingEnquiriesNote").show()
				} else {
					$("#existingEnquiriesNote").hide()
				}
				dialogHider(_dialog);
			}),
			$name = $("<div class='dialog-search-data-col' style='width: 240px;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='dialog-search-data-col' style='width: 240px;'>" + this.number + "</div>").appendTo($row),
			$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>" + this.ccy + "</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Select An Account",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if (!$(".dialog-search-list").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}
function showExistingEnquiriesDialog(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />");

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "existingEnquiriesDialog",
		title: "Existing Enquiries",
		size: "wide",
		icon: "<i class='fa fa-envelope'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function showCommentsDialog(_target) {
	/* set $wrapper to hold the add comment and attachments form */
	var $wrapper = $("<div class='wrapper' />");
	var $formSection = $("<div class='form-section top-label' />").appendTo($wrapper);
	var $row = $("<div class='row' />").appendTo($formSection);
	var $labelColumn = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Comment</label>").appendTo($labelColumn);
	var $dataColumn = $("<div class='data-column' />").appendTo($row);
	var $data = $("<textarea style='width: 95%; max-width: 95%; height: 200px;' id='_addComment'></textarea>").appendTo($dataColumn);
	var $row = $("<div class='row' />").appendTo($formSection);
	var $labelColumn = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Attachments</label>").appendTo($labelColumn);
	var $dataColumn = $("<div class='data-column' />").appendTo($row);
	var $ul = $("<ul />").appendTo($dataColumn);
	var $li = $("<li />").appendTo($ul);
	var $data = $("<input type='file' multiple='multiple' />").appendTo($li);
	var $labelDesc = $("<label class='desc'>Attachment 1</label>").appendTo($li);
	var $li = $("<li />").appendTo($ul);
	var $data = $("<input type='file' multiple='multiple' />").appendTo($li);
	var $labelDesc = $("<label class='desc'>Attachment 2</label>").appendTo($li);
	var $li = $("<li />").appendTo($ul);
	var $data = $("<input type='file' multiple='multiple' />").appendTo($li);
	var $labelDesc = $("<label class='desc'>Attachment 3</label>").appendTo($li);
	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "enquiryHistoryDialog",
		title: "Add Comment",
		size: "medium",
		icon: "<i class='fa fa-comment'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#_addComment").focus();
}


/**********************************************************************
SETUP REQUEST SCREEN
**********************************************************************/
function setupViewEnquiry(item) {
	$("#requestInformation").scrollTop(0);
	var _type = item.requesttype;
	$("#viewRequestType").html(_type);
	$("#viewRequestStatus").html(item.requeststatus);
	$("#viewRequestId").html(item.requestid);
	$("#viewAccountNameHeader").html(item.accountname);
	$("#viewAccountNumberHeader").html(item.accountnumber);
	$("#viewAccountCCYHeader").html(item.ccy);
	$("#viewAccount").html(item.accountname + " - " + item.accountnumber + " (" + item.ccy + ")");
	$("#viewRequestDetails > div").hide();
	$("#addNote, #addAttachment").hide();
	$("#addActions").show();
	$("[data-value='requestID']").html(item.requestid);
	$("[data-value='createdBy']").html(item.createdby);
	if (_type == "Other request") {
		$("#viewOtherRequestInfo").show();
	}
	if (_type == "Request a new agent deposit book") {
		$("#viewBookRequestName").show();
		$("#viewAgentBookInfo").show();
		$("#viewDeliveryInfo").show();
	}
	if (_type == "Request a new standard deposit book") {
		$("#viewBookRequestName").show();
		$("#viewStandardDepositBookInfo").show();
		$("#viewDeliveryInfo").show();
	}
	$("#viewRequestActivity, #viewRequestData").show();
	$("#requestActivityToggle").children("i").removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
	$("#requestDataToggle").children("i").removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
}


/**********************************************************************
REQUESTS SUMMARY GRID SETUP
**********************************************************************/
function styleRequestStatusFormatter(row, cell, value, columnDef, dataContext) {
	if (value == "Open") {
		return "<span style='color: #009900;'>" + value + "</span>";
	} else {
		return value;
	}
}

var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [{
	id: "accountnumber",
	name: "Account Number",
	field: "accountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "accountname",
	name: "Account Name",
	field: "accountname",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "requestid",
	name: "Request ID",
	field: "requestid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "requesttype",
	name: "Request Type",
	field: "requesttype",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "requeststatus",
	name: "Request Status",
	field: "requeststatus",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	formatter: styleRequestStatusFormatter,
	visible: true
}, {
	id: "createdby",
	name: "Created By",
	field: "createdby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "creationdate",
	name: "Creation Date",
	field: "creationdate",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "lastupdate",
	name: "Last Update",
	field: "lastupdate",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "closedate",
	name: "Closed Date",
	field: "closedate",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "channel",
	name: "Channel",
	field: "channel",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "raisedfor",
	name: "Raised on Behalf Of",
	field: "raisedfor",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('requestColumnOrder')) {
	columns = store.get('requestColumnOrder');
}
if (store.get('requestColumnWidths')) {
	var setWidth = store.get('requestColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());

var	groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var searchString = "", statusString = "", searchPoint = "accountnumber";
function myFilter(item, args) {
	if (args.statusString != "" && item["requeststatus"] != args.statusString) {
		return false;
	}
	if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1) {
		return false;
	}
	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}
	return true;
}
function filterRequests() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function findRequests() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	if (searchString == "") {
		dataView.setFilterArgs({
			searchString: searchString,
			statusString: statusString
		})
	} else {
		dataView.setFilterArgs({
			searchString: searchString,
			statusString: statusString
		})
	};
	dataView.refresh();
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
function viewFilter() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		statusString: statusString,
		searchString: searchString
	});
	filterRequests();
}


/**********************************************************************
REQUESTS DATA
**********************************************************************/
var requestTypes = ["Request a statement copy", "Request a new cheque book", "Request a new standard deposit book", "Request a new agent deposit book", "Request a new bank@post deposit book", "Other request", "Request further details about a transaction", "Beneficiary claims non-receipt of a payment", "Missing deposit / value from my account (partial missing)", "Missing deposit / value from my account (full missing)", "Other transaction request"];
var requestUsers = ["Kent Brokman", "Arnie Pye", "Jasper Beardly", "Patty Bouvier", "Roger Meyers Jr."]
for (var i = 0; i < 40; i++) {
	var d = (data[i] = {});
	var randy = _accounts[rand(0, _accounts.length - 1)];
	d["id"] = "id_" + i;
	d["requestid"] = "SR-" + randString(6);
	d["creationdate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date()) + " " + timeFormatter();
	d["accountnumber"] = randy.number;
	d["accountname"] = randy.name;
	d["ccy"] = randy.ccy;
	d["requestname"] = "RequestName" + randString();
	d["requesttype"] = requestTypes[rand(0, requestTypes.length - 1)];
	d["createdby"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["channel"] = "Self Service";
	d["raisedfor"] = "-";
	if (i % 3 == 0) {
		d["requeststatus"] = "Closed";
		d["closedate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	} else {
		d["requeststatus"] = "Open";
		d["closedate"] = "";
	}
};


/**********************************************************************
MANAGE ACTION AND CONTEXT CONTROLS
**********************************************************************/
function checkStatus(arr) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--] !== arr[L]) return false;
	}
	return arr[L];
}
var enableContextItem = function() {
	var text = $(this).children("div.disabled").text();
	$(this).children("div.disabled").replaceWith("<a href='javascript:void(0)'>" + text + "</a>");
};
var disableContextItem = function() {
	var text = $(this).children("a").text();
	$(this).children("a").replaceWith("<div class='disabled'>" + text + "</div>");
};
function setupContextMenu() {
	var sel = selectedRowIds.length,
		$contextItems = $("[data-type='context-item']"),
		_status;
	if (sel == 0 || sel > 1) {
		$contextItems.each(disableContextItem);
	} else {
		_status = dataView.getItemById(selectedRowIds[0]).requeststatus;
		if (_status == "Open") {
			$contextItems.each(enableContextItem);
		} else {
			$("[data-action='viewdetails'], [data-action='viewhistory']").each(enableContextItem);
			$("[data-action='addcomment'], [data-action='attachdocument']").each(disableContextItem);
		}
	}
}


/**********************************************************************
DETAIL ACTIONS
**********************************************************************/
function createAgain() {
	setTimeout(function() {
		$("body").removeClass("loading");
		$(".header, .shell").find(":focusable").removeAttr("tabindex");
		$("#requestForm").trigger("reset");
		$("#transactionRequestSteps").hide().children("li").removeClass("active complete");
		$("#defaultSteps").show().children("li[data-step='1']").addClass("active").siblings().removeClass("active complete");
		$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0).siblings(":not('.top-controls')").addClass("hidden");
		if ($(".ie8").size() > 0) {
			$("body").find(".fa").addClass("repaint");
			setTimeout(function() {
				$("body").find(".fa").removeClass("repaint");
			}, 1)
		}
	}, 500)
}
function finishCreating() {
	document.location.href='service-requests.html';
}


/**********************************************************************
UPDATE THE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='service-requests.html'>Nostro Accounts</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Service Request Details");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Nostro Accounts");
	} else if (update == "new") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("New Service Request");
	}
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALISE REQUESTS GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#servcieRequests", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'requestColumnOrder', 'requestColumnWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell)
		setupContextMenu();
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
			}
		}
		if (selectedRowIds.length > 0) {
			$("#servcieRequests").addClass("has-bottom-controls");
			$("#requestSummary .bottom-controls").removeClass("hidden");
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#servcieRequests").removeClass("has-bottom-controls");
			$("#requestSummary .bottom-controls").addClass("hidden");
			$("#selectedCount").html('');
		}
		grid.resizeCanvas();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e), row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#requestDetail',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			setupViewEnquiry(dataView.getItem(row));
			updateBreadcrumb("view");
			grid.setSelectedRows(0);
			selectedRowIds = [];
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('requestColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		statusString: statusString,
		searchString: searchString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('requestColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i < store.get('requestColumnOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleAdHocColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});


	/**********************************************************************
	SECTION TOGGLES
	**********************************************************************/
	$("#requestActivityToggle").on("click", function(e) {
		e.preventDefault();
		var $section = $("#viewRequestActivity"),
			$icon = $(this).children("i");
		if ($section.is(":visible")) {
			$section.hide();
			$icon.removeClass("fa-chevron-circle-up").addClass("fa-chevron-circle-down");
		} else {
			$section.show();
			$icon.removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
		}
	});
	$("#requestDataToggle").on("click", function(e) {
		e.preventDefault();
		var $section = $("#viewRequestData"),
			$icon = $(this).children("i");
		if ($section.is(":visible")) {
			$section.hide();
			$icon.removeClass("fa-chevron-circle-up").addClass("fa-chevron-circle-down");
		} else {
			$section.show();
			$icon.removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
		}
	});


	/**********************************************************************
	VIEW MENU FUNCTIONS
	**********************************************************************/
	$("#viewMenu").on("click.filter-view", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set")) {
			var value = $target.attr("data-value");
			if (statusString != value) {
				statusString = value;
			};
			viewFilter();
		}
	});


	/**********************************************************************
	ACTIONS
	**********************************************************************/
	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});
	$("#newRequestButton").on("click", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		$("#requestForm").trigger("reset");
		$("#transactionRequestSteps").hide().children("li").removeClass("active complete");
		$("#defaultSteps").children("li").removeClass("active complete");
		$("#defaultSteps").show().children("li[data-step='1']").addClass("active");
		$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0).siblings(":not('.top-controls')").addClass("hidden");
		$target.attr({
			'data-panel': '#newRequest',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		updateBreadcrumb("new");
	});
	$("[data-action='viewdetails']").on("click", "a", function(e) {
		e.preventDefault();
		var item = dataView.getItem(grid.getSelectedRows());
		setupViewEnquiry(item);
		grid.setSelectedRows(0);
		selectedRowIds = [];
		$(this).attr({
			'data-panel': '#requestDetail',
			'data-switch': 'switch-panels'
		}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		updateBreadcrumb("view");
	});


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


	/**********************************************************************
	SETTINGS
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	GROUPING MENU FUNCTIONS
	**********************************************************************/
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});


	/**********************************************************************
	RECORD ACTIONS
	**********************************************************************/
	$("[data-action='add-comment']").on("click", function(e) {
		e.preventDefault();
		showCommentsDialog($(this));
	});
	$("[data-action='refresh']").on("click", function(e) {
		e.preventDefault();
		$('#requestDetail').addClass("loading");
		setTimeout(function() {
			$('#requestDetail').removeClass("loading");
		}, 600);
	});
	$("[data-action='download']").on("click", function(e) {
		e.preventDefault();
	});
	$("[data-action='previous-request']").on("click", function(e) {
		e.preventDefault();
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow - 1;
		if ($("#servcieRequests").find("div[row='" + activeRow + "']").is(".slick-group, .slick-group-totals")) {
			activeRow = activeRow - 1;
		}
		if (activeRow < 0) {
			return false;
		} else {
			grid.setActiveCell(activeRow, 0)
			setupViewEnquiry(dataView.getItem(activeRow));		
		}
	});
	$("[data-action='next-request']").on("click", function(e) {
		e.preventDefault();
		var activeRow = grid.getActiveCell().row;
		activeRow = activeRow + 1;
		if ($("#servcieRequests").find("div[row='" + activeRow + "']").is(".slick-group, .slick-group-totals")) {
			activeRow = activeRow + 1;
		}
		if (activeRow >= grid.getDataLength()) {
			return false;
		} else {
			grid.setActiveCell(activeRow, 0);
			setupViewEnquiry(dataView.getItem(activeRow));
		}
	});


	/**********************************************************************
	NEW REQUEST INITIALIZATION
	**********************************************************************/
	$("[data-action='set-request-type']").on("click", function(e) {
		e.preventDefault();
		$("#newRequest").addClass("loading");
		$("#requestForm").trigger("reset");
		$("#existingEnquiriesNote").hide();
		var cat = $(this).closest("ul.step-list").attr("data-request-type"),
			type = $(this).attr("data-request-type"),
			steps;
		$("[data-request-header]").html($(this).text());
		if (cat == "account") {
			$("#newRequest").attr("data-category", "account");
			steps = $("#defaultSteps");
			steps.children("[data-step='1']").removeClass("active").addClass('complete');
			steps.children("[data-step='3']").addClass("active");

			if (type == "other") {
				$("#transactionSelection, #transactionSelectionView, #agentBookInfo, #transactionSelection, #depsoitBookInfo, #deliveryInfo, #agentBookInfoView, #depositBookInfoView, #deliveryInfoView").hide();
				$("#accountSelection, #accountSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			} else if (type == "agent-book") {
				$("#transactionSelection, #transactionSelectionView, #otherRequestInfo, #transactionSelection, #otherRequestInfoView, #depsoitBookInfo, #depositBookInfoView").hide();
				$("#accountSelection, #accountSelectionView, #agentBookInfo, #deliveryInfo, #agentBookInfoView, #deliveryInfoView").show();
			} else if (type == "deposit-book") {
				$("#transactionSelection, #transactionSelectionView, #otherRequestInfo, #transactionSelection, #otherRequestInfoView, #agentBookInfo, #agentBookInfoView").hide();
				$("#accountSelection, #accountSelectionView, #depsoitBookInfo, #deliveryInfo, #depositBookInfoView, #deliveryInfoView").show();
			} else {
				$("#transactionSelection, #transactionSelectionView, #agentBookInfo, #transactionSelection, #depsoitBookInfo, #deliveryInfo, #agentBookInfoView, #depositBookInfoView, #deliveryInfoView").hide();
				$("#accountSelection, #accountSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			}

			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='3']").removeClass("hidden").scrollTop(0);
				$("#newRequest").removeClass("loading");
				$("#accountInput").focus();
				if ($(".ie8").size() > 0) {
					$("body").find(".fa").addClass("repaint");
					setTimeout(function() {
						$("body").find(".fa").removeClass("repaint");
					}, 1)
				}
			}, 500);

		} else if (cat == "transaction") {
			$("#newRequest").attr("data-category", "transaction");
			steps = $("#transactionRequestSteps");
			steps.children("[data-step='1']").removeClass("active").addClass('complete');
			steps.children("[data-step='2']").addClass("active");

			if (type == "transaction-details") {
				$("#accountSelection, #accountSelectionView, #agentBookInfo, #depsoitBookInfo, #deliveryInfo, #agentBookInfoView, #depositBookInfoView, #deliveryInfoView").hide();
				$("#transactionSelection, #transactionSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			} else if (type == "non-receipt") {
				$("#accountSelection, #accountSelectionView, #depsoitBookInfo, #depositBookInfoView, #agentBookInfo, #deliveryInfo, #agentBookInfoView, #deliveryInfoView").hide();
				$("#transactionSelection, #transactionSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			} else if (type == "missing-partial") {
				$("#accountSelection, #accountSelectionView, #agentBookInfo, #agentBookInfoView, #depsoitBookInfo, #deliveryInfo, #depositBookInfoView, #deliveryInfoView").hide();
				$("#transactionSelection, #transactionSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			} else if (type == "missing-full") {
				$("#accountSelection, #accountSelectionView, #agentBookInfo, #agentBookInfoView, #depsoitBookInfo, #deliveryInfo, #depositBookInfoView, #deliveryInfoView").hide();
				$("#transactionSelection, #transactionSelectionView, #accountSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			} else if (type == "other-trans") {
				$("#accountSelection, #accountSelectionView, #agentBookInfo, #agentBookInfoView, #depsoitBookInfo, #deliveryInfo, #depositBookInfoView, #deliveryInfoView").hide();
				$("#transactionSelection, #otherRequestInfo, #otherRequestInfoView").show();
			} else if (type == "processed-incorrectly") {
				$("#accountSelection, #accountSelectionView, #agentBookInfo, #agentBookInfoView, #depsoitBookInfo, #deliveryInfo, #depositBookInfoView, #deliveryInfoView").hide();
				$("#transactionSelection, #transactionSelectionView, #otherRequestInfo, #otherRequestInfoView").show();
			}

			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='2']").removeClass("hidden").scrollTop(0);
				$("#defaultSteps").hide();
				$("#transactionRequestSteps").show();
				$("#newRequest").removeClass("loading");
				if ($(".ie8").size() > 0) {
					$("body").find(".fa").addClass("repaint");
					setTimeout(function() {
						$("body").find(".fa").removeClass("repaint");
					}, 1)
				}
			}, 500);
		}
	});
	$("[data-action='previousStep']").on("click", function(e) {
		e.preventDefault();
		$("#newRequest").addClass("loading");
		var _step = $(this).closest("div.scroll-area").attr("data-step"),
			_category = $("#newRequest").attr("data-category");
		if (_step == "2") {
			$("#transactionRequestSteps").hide().children("[data-step]").removeClass("active complete");
			$("#defaultSteps").show().children("[data-step='1']").addClass("active").siblings().removeClass("active complete");
			$("#newRequest").find("div.scroll-area[data-step='2'], div.scroll-area[data-step='3']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
		} else if (_step == "3") {
			if (_category == "account") {
				$("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
				$("#newRequest").find("div.scroll-area[data-step='3']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
			} else if (_category == "transaction") {
				$("#transactionRequestSteps").children("[data-step='2']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
				$("#transactionRequestSteps").children("[data-step='1']").addClass("complete");
				$("#newRequest").find("div.scroll-area[data-step='3']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='2']").removeClass("hidden").scrollTop(0);
			}
		} else if (_step == "4") {
			if (_category == "account") {
				$("#defaultSteps").children("[data-step='3']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
				$("#defaultSteps").children("[data-step='1']").addClass("complete");
			} else if (_category == "transaction") {
				$("#transactionRequestSteps").children("[data-step='3']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
				$("#transactionRequestSteps").children("[data-step='2']").addClass("complete");
			}
			$("#newRequest").find("div.scroll-area[data-step='4']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='3']").removeClass("hidden").scrollTop(0);

		}
		setTimeout(function() {
			$("#newRequest").removeClass("loading");
			if ($(".ie8").size() > 0) {
				$("body").find(".fa").addClass("repaint");
				setTimeout(function() {
					$("body").find(".fa").removeClass("repaint");
				}, 1)
			}
		}, 200);
	});
	$("[data-action='nextStep']").on("click", function(e) {
		e.preventDefault();
		$("#newRequest").addClass("loading");
		var _step = $(this).closest("div.scroll-area").attr("data-step"),
			_category = $("#newRequest").attr("data-category");
		if (_step == "2") {
			$("#transactionRequestSteps").children("[data-step='3']").addClass("active").siblings().removeClass("active complete");
			$("#transactionRequestSteps").children("[data-step='2']").addClass("complete");
			$("#newRequest").find("div.scroll-area[data-step='2']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='3']").removeClass("hidden").scrollTop(0);
		} else if (_step == "3") {
			if (_category == "account") {
				$("#defaultSteps").children("[data-step='4']").addClass("active").siblings().removeClass("active complete");
				$("#defaultSteps").children("[data-step='3']").addClass("complete");
				$("#newRequest").find("div.scroll-area[data-step='3']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='4']").removeClass("hidden").scrollTop(0);
			} else if (_category == "transaction") {
				$("#transactionRequestSteps").children("[data-step='4']").addClass("active").siblings().removeClass("active complete");
				$("#transactionRequestSteps").children("[data-step='3']").addClass("complete");
				$("#newRequest").find("div.scroll-area[data-step='3']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='4']").removeClass("hidden").scrollTop(0);
			}
		}
		setTimeout(function() {
			$("#newRequest").removeClass("loading");
			if ($(".ie8").size() > 0) {
				$("body").find(".fa").addClass("repaint");
				setTimeout(function() {
					$("body").find(".fa").removeClass("repaint");
				}, 1)
			}
		}, 200);
	});
	$("[data-action='submitRequest']").on("click", function(e) {
		e.preventDefault();
		$("body").addClass("loading");
		$(".header, .shell").find(":focusable").attr("tabindex", -1);
		setTimeout(function() {
			buildCustomConfirmDialog("<span style='font-size: 16px; color: #007dba; font-weight: 600;'>Request ID: 837342281</span>", "<span style='font-weight: 600;'>Your service request has been succefully submitted.</span>", "<span style='display: inline-block; max-width: 400px;'>Requests received prior to 4pm AEDT will be responded to same day. Requests received after 4pm AEDT will be responded to next business day.</span>", "View service requests", function() {
				finishCreating()
			}, "", "Raise another service request", function() {
				createAgain()
			}, "primary");
		}, 1500);
	});
	$("#accountInput").autocomplete({
		autoFocus: false,
		delay: 0,
		minLength: 1,
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_accountTypeAhead, extractLast(request.term));
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		focus: function() {
			return false;
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				$("#existingEnquiriesNote").hide();
				this.value = "";
				return false;
			} else {
				this.value = ui.item.value;
				$("#existingEnquiriesNote").show()
				return false;
			}
		}
	}).on("focus", function() {
		$(this).one("mouseup", function() {
			$(this).select();
		})
	}).on("keyup", function() {
		if ($(this).val() == "") {
			$("#existingEnquiriesNote").hide();
		}
	});
	$("#existingEnquiriesNote a").on("click", function(e) {
		e.preventDefault();
		showExistingEnquiriesDialog($(this))
	});
	$("#searchAccountsDialog").on("click", function(e) {
		e.preventDefault();
		showAddAccounts($(this))
	});


	/**********************************************************************
	CLOSE DETAIL VIEW
	**********************************************************************/
	$("#closeDetailView").on("click", function(e){
		updateBreadcrumb("close");
	});


	/**********************************************************************
	JUMP TO DETAIL
	**********************************************************************/
	var b = document.location.href.split(".html")[1];
	if (b == "#new") {
		$("#newRequestButton").trigger("click");
	}

});