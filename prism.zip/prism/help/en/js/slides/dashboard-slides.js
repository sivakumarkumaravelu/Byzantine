function renderSliderDialog(e) {
    e.preventDefault();
	function renderImage() {
		var $dialogContent = $("<div style='display: none;' class='center slider' />");
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>ANZ Transactive – Global gives you access to a <span class='c007dba'>range of products and services</span>, depending on your permissions, for managing your organisation’s financial needs.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Getting started is easy. This guide helps you get familiar with <span class='c007dba'>some important features and functionality</span> to optimise your experience.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/dashboard/slide01.png' style='border: 0;' />").appendTo($guideImage);

		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><span class='c007dba'>Customisable workspaces</span> allow you to easily arrange and resize content that is important to you.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Giving you <span class='c007dba'>immediate visibility of key information and tasks</span>, there are default workspace options based on your permissions.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Select <span class='c007dba'>Add to Workspace</span> to choose from a range of content. New content appears at the bottom of your workspace. Create, reorder and rename workspaces by selecting <span class='c007dba'>Manage Your Workspace</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/dashboard/slide02.gif' style='border: 0;' />").appendTo($guideImage);

		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>The <span class='c007dba'>Application Banner</span> provides features that are available from all screens.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Use it to access a range of <span class='c007dba'>online help tools</span>, check <span class='c007dba'>log in information</span> and select your <span class='c007dba'>preferred language</span>.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Under <span class='c007dba'>Settings & Preferences</span>, set your reference currency, date/time preferences and how numbers are displayed. You can also create email notifications and alerts, and the password for scheduled email reports.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/dashboard/slide03.gif' style='border: 0;' />").appendTo($guideImage);

		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>The <span class='c007dba'>Menu</span> is fixed to the left hand side and is a <span class='c007dba'>key tool for navigating</span> the application.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>It gives you access to the following options depending on your permissions and country availability.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/dashboard/slide04.png' style='border: 0;' />").appendTo($guideImage);

		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>The <span class='c007dba'>Control Bar</span> is used across the application, providing quick and easy access to <span class='c007dba'>key tasks relevant to the screen</span> you are on.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>It is grouped into three sections: <span class='c007dba'>View</span>, <span class='c007dba'>Actions</span> and <span class='c007dba'>Screen Controls</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/dashboard/slide05.png' style='border: 0;' />").appendTo($guideImage);

		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/dashboard/slide06.png' style='border: 0;' />").appendTo($guideImage);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><strong>Need more information?</strong></div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>View <span class='c007dba'>Online Help</span> within ANZ Transactive – Global or visit our <span class='c007dba'>Online Resources</span> site to access a range of detailed guidance.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>We also encourage you to be familiar with our <a href='about:blank' target='_blank' style='color: #007dba; text-decoration: underline;'>Privacy Statement</a></div>").appendTo($guideContent);
		
		
		setTimeout(function() { 
			$('.dialog-container').removeClass('working').on("click", function(e){
				e.stopPropagation();
			});
			$('.slider').show(); 
			$(".center").slick({
				dots: true,
				infinite: true,
				prevArrow: '<div><i class="fa fa-chevron-circle-left faprev" aria-hidden="true"></i></div>',
				nextArrow: '<div><i class="fa fa-chevron-circle-right fanext" aria-hidden="true"></i></div>',
				slidesToShow: 1,
			});
		},800);
		
		return $dialogContent;
	}
	var $target = $(e.target);
	var origin = $target.closest(".dialog-parent").length > 0 ? $target.closest(".dialog-parent") : $target;
	var dialog = {
		id: "guideDialog",
		title: "Getting Started Onscreen Guide",
		size: "guide working",
		icon: "<i class='fa fa-info-circle'></i>",
		content: function() {
			return renderImage();
		}
		
	}
	dialogViewer(origin, dialog, dialogBuilder(dialog));
}