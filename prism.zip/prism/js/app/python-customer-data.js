/* CUSTOMERS */
/* used by the customer account generator */
var _customers = [{
	id: "OPCUST01",
	name: "Prototype Consulting Incorporated",
	localname: "原型諮詢有限公司",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer1@tbos.prototype.com"
}, {
	id: "OPCUST02",
	name: "Midnight Express Delivery",
	localname: "午夜快遞",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer2@tbos.prototype.com"
}, {
	id: "OPCUST03",
	name: "Happy Delights Catering Services",
	localname: "快樂歡欣餐飲服務",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer3@tbos.prototype.com"
}, {
	id: "OPCUST04",
	name: "Fitness Experts Limited",
	localname: "健身專家有限公司",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer4@tbos.prototype.com"
}, {
	id: "OPCUST05",
	name: "Clear Sky Financial Services",
	localname: "晴空金融服務",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer5@tbos.prototype.com"
}, {
	id: "OPCUST06",
	name: "Dong Dong Manufacturing",
	localname: "董棟製造",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer6@tbos.prototype.com"
}, {
	id: "OPCUST07",
	name: "Chaoyang Fisheries",
	localname: "朝陽水產",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer7@tbos.prototype.com"
}, {
	id: "OPCUST08",
	name: "Beijing Tourist Board",
	localname: "北京市旅遊局",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer8@tbos.prototype.com"
}, {
	id: "OPCUST09",
	name: "KS Foods Incorporated",
	localname: "KS食品股份有限公司",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer9@tbos.prototype.com"
}, {
	id: "OPCUST10",
	name: "China Adventure Tours Inc.",
	localname: "中國探險旅遊公司",
	address1: "L234 China Central Place",
	address2: "No. 79 Jianguo Road",
	address3: "Cjaoyang District",
	address4: "Beijing",
	postal: "100025",
	country: "China",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST11",
	name: "Experts Financial Services Inc.",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST12",
	name: "Pinocchio Imports and Exports Inc.",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST13",
	name: "Melbourne Chemical",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST14",
	name: "Smith Family Clinic",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST15",
	name: "AMCORP Melbourne",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST16",
	name: "PK Investments",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST17",
	name: "JDP Holdings",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST18",
	name: "Dragon Financial",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST19",
	name: "Association of Landscaping Experts",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}, {
	id: "OPCUST20",
	name: "Felicia Wong Private Limited",
	localname: "",
	address1: "55 Queen Street",
	address2: "Melbourne",
	address3: "Victoria",
	address4: "Melbourne",
	postal: "3000",
	country: "Australia",
	email: "customer10@tbos.prototype.com"
}];

/* CUSTOMER ACCOUNTS TYPES */
/* used by the customer account generator */
var _customer_account_types = [
	"Savings",
	"Current"
];

/* CUSTOMER ACCOUNT CURRENCIES */
/* used by the customer account generator */
var _customer_account_currencies = [{
	country: "Australia",
	code: "AUD",
	currency: "Australian Dollar"
}, {
	country: "China",
	code: "CNY",
	currency: "Chinese Yuan"
}];

/* ANZ CUSTOMER BANKS */
/* used by the customer account generator */
var _customer_banks = [{
	id: "OPCBANK01",
	name: "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
	localname: "澳大利亚和新西兰银行集团上海分行",
	branch: "Shanghai Branch",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	postal: "200001",
	city: "Shanghai",
	country: "China",
	swift: "ANZBCNSH",
	clearing: {
		type: "CNAPS",
		code: "761290013606"
	}
}, {
	id: "OPCBANK02",
	name: "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
	localname: "澳大利亚和新西兰银行集团有限公司北京分行",
	branch: "Beijing Branch",
	address1: "Tower 2, Floor 17",
	address2: "Beijing Bright China Chang An Building",
	address3: "Dong Cheng District, Beijing",
	postal: "100005",
	city: "Beijing",
	country: "China",
	swift: "ANZBCNSHBJG",
	clearing: {
		type: "CNAPS",
		code: "761100000012"
	}
}, {
	id: "OPCBANK03",
	name: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	localname: "",
	branch: "ANZ Banking Group Limited",
	address1: "Level 12, 530 Collins Street",
	address2: "Melbourne",
	address3: "Victoria",
	postal: "3000",
	city: "Melbourne",
	country: "Australia",
	swift: "ANZBAU3M",
	clearing: {
		type: "BSB",
		code: "013-988"
	}
}, {
	id: "OPCBANK04",
	name: "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED",
	localname: "",
	branch: "Beijing Branch",
	address1: "115 Pitt St",
	address2: "Sydney",
	address3: "New South Wales",
	postal: "2000",
	city: "Sydney",
	country: "Australia",
	swift: "ANZBAU3M",
	clearing: {
		type: "BSB",
		code: "012-013"
	}
}];

/* CUSTOMER ACCOUNTS */
/* the array that holds customer accounts */
/* the customer account generator function */
/* generate customer accounts or use stored values */

var _tbos_customer_accounts = [];

function generateCustomerAccounts() {
	var a = {};
	var customer = _customers[rand(0, _customers.length - 1)];
	var bank = _customer_banks[rand(0, _customer_banks.length - 1)];
	var type = _customer_account_types[rand(0, _customer_account_types.length - 1)];
	var resident = (customer.country == bank.country) ? "Resident" : "Non-Resident";
	var currency;
	for ( var i = 0, l = _customer_account_currencies.length; i < l; i++ ) {
		if ( _customer_account_currencies[i].country == bank.country ) {
			currency = _customer_account_currencies[i];
			break;
		}
	}
	a["id"] = randString(10);
	a["owner"] = customer;
	a["bank"] = bank;
	a["swiftbank"] = bank;
	a["type"] = type;
	a["currency"] = currency;
	a["number"] = randNumber(10);
	a["name"] = customer.id + " " + type + " " + randString(5).toUpperCase();
	a["resident"] = resident;
	a["availablebalance"] = (parseFloat((Math.random() * 100000000) / 100)).toFixed(2);
	a["availablefunds"] = (parseFloat((Math.random() * 100000000) / 100)).toFixed(2);
	return a;
}

for (var i = 0; i < 50; i++) {
	_tbos_customer_accounts[i] = generateCustomerAccounts();
}