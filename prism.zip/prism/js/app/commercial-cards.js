/**********************************************************************
CARD DATA
**********************************************************************/
var _cardNumbers = [
	{ id: "card1", number: randNumber(18), status: "Active", name: "ACC TEST 11", open: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(100, 500)))), close: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(100, 300)))), lastupdated: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 30)))) + " " + timeFormatter(), currency: "AUD", monthly: (Math.round(Math.random() * 10000000)/100).toFixed(2), transaction: (Math.round(Math.random() * 10000000)/100).toFixed(2), atm: (Math.round(Math.random() * 10000000)/100).toFixed(2), otc: (Math.round(Math.random() * 10000000)/100).toFixed(2), current: (Math.round(Math.random() * 10000000)/100).toFixed(2), available: (Math.round(Math.random() * 10000000)/100).toFixed(2) },
	{ id: "card2", number: randNumber(18), status: "Active", name: "ACC TEST 22", open: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(100, 500)))), close: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(100, 300)))), lastupdated: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 30)))) + " " + timeFormatter(), currency: "AUD", monthly: (Math.round(Math.random() * 10000000)/100).toFixed(2), transaction: (Math.round(Math.random() * 10000000)/100).toFixed(2), atm: (Math.round(Math.random() * 10000000)/100).toFixed(2), otc: (Math.round(Math.random() * 10000000)/100).toFixed(2), current: (Math.round(Math.random() * 10000000)/100).toFixed(2), available: (Math.round(Math.random() * 10000000)/100).toFixed(2) },
	{ id: "card3", number: randNumber(18), status: "Active", name: "ACC TEST 33", open: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(100, 500)))), close: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(100, 300)))), lastupdated: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 30)))) + " " + timeFormatter(), currency: "AUD", monthly: "Unrestricted", transaction: "Unrestricted", atm: (Math.round(Math.random() * 10000000)/100).toFixed(2), otc: "Unrestricted", current: (Math.round(Math.random() * 10000000)/100).toFixed(2), available: (Math.round(Math.random() * 10000000)/100).toFixed(2) },
	{ id: "card4", number: randNumber(18), status: "Active", name: "ACC TEST 44", open: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(100, 500)))), close: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(100, 300)))), lastupdated: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 30)))) + " " + timeFormatter(), currency: "AUD", monthly: (Math.round(Math.random() * 10000000)/100).toFixed(2), transaction: (Math.round(Math.random() * 10000000)/100).toFixed(2), atm: (Math.round(Math.random() * 10000000)/100).toFixed(2), otc: (Math.round(Math.random() * 10000000)/100).toFixed(2), current: (Math.round(Math.random() * 10000000)/100).toFixed(2), available: (Math.round(Math.random() * 10000000)/100).toFixed(2) },
	{ id: "card5", number: randNumber(18), status: "Active", name: "ACC TEST 55", open: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(100, 500)))), close: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(100, 300)))), lastupdated: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 30)))) + " " + timeFormatter(), currency: "AUD", monthly: (Math.round(Math.random() * 10000000)/100).toFixed(2), transaction: (Math.round(Math.random() * 10000000)/100).toFixed(2), atm: (Math.round(Math.random() * 10000000)/100).toFixed(2), otc: (Math.round(Math.random() * 10000000)/100).toFixed(2), current: (Math.round(Math.random() * 10000000)/100).toFixed(2), available: (Math.round(Math.random() * 10000000)/100).toFixed(2) },
	{ id: "card6", number: randNumber(18), status: "Active", name: "ACC TEST 66", open: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(100, 500)))), close: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(100, 300)))), lastupdated: $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 30)))) + " " + timeFormatter(), currency: "AUD", monthly: (Math.round(Math.random() * 10000000)/100).toFixed(2), transaction: (Math.round(Math.random() * 10000000)/100).toFixed(2), atm: (Math.round(Math.random() * 10000000)/100).toFixed(2), otc: (Math.round(Math.random() * 10000000)/100).toFixed(2), current: (Math.round(Math.random() * 10000000)/100).toFixed(2), available: (Math.round(Math.random() * 10000000)/100).toFixed(2) }
];


/**********************************************************************
MAIN GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columns = [
	{id:"company", name:"Company Name", field:"company", toolTip:"Click to sort by Company Name. Right-Click to hide or show", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"billingaccountname", name:"Billing Entity Name", field:"billingaccountname", toolTip:"Click to sort by Billing Account Name. Right-Click to hide or show", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"billingaccountnumber", name:"Billing Entity Number", field:"billingaccountnumber", toolTip:"Click to sort by Billing Account Name. Right-Click to hide or show", width: 200, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"billingaccountstatus", name:"Billing Entity Status", field:"billingaccountstatus", toolTip:"Click to sort by Billing Account Status. Right-Click to hide or show", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{id:"producttype", name:"Product Type", field:"producttype", toolTip:"Click to sort by Product Type. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"currency", name:"Currency", field:"currency", toolTip:"Click to sort by Currency. Right-Click to hide or show", width: 100, sortable:true, sorter: "sorterStringCompare", visible: true},
	{id:"totallimit", name:"Total Limit", field:"totallimit", toolTip:"Click to sort by Total Limit. Right-Click to hide or show", width: 180, sortable: true, sorter: "sorterNumeric", cssClass: "num", headerCssClass: "righted", visible: true, formatter: Slick.Formatters.AmountFormatter, groupTotalsFormatter:sumTotalsFormatter},
	{id:"openingbalance", name:"Opening Balance", field:"openingbalance", toolTip:"Click to sort by Opening Balance. Right-Click to hide or show", width: 180, sortable:true, sorter: "sorterNumeric", cssClass: "num pos", headerCssClass: "righted", visible: true, formatter: Slick.Formatters.AmountFormatter, groupTotalsFormatter:sumTotalsFormatter},
	{id:"availablefunds", name:"Available Funds", field:"availablefunds", toolTip:"Click to sort by Available Funds. Right-Click to hide or show", width: 180, sortable:true, sorter: "sorterNumeric", cssClass: "num pos", headerCssClass: "righted",  visible: true, formatter: Slick.Formatters.AmountFormatter, groupTotalsFormatter:sumTotalsFormatter},
	{id:"lastupdated", name:"Last Updated", field:"lastupdated", toolTip:"Click to sort by Last Updated Date. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{id:"minimumdue", name:"Minimum Payment Due", field:"minimumdue", toolTip:"Click to sort by Minimum Payment Due. Right-Click to hide or show", width: 180, sortable: true, sorter: "sorterNumeric", cssClass: "num", headerCssClass: "righted", formatter: Slick.Formatters.AmountFormatter, visible: true},	
	{id:"paymentduedate", name:"Payment Due Date", field:"paymentduedate", toolTip:"Click to sort by Payment Due Date. Right-Click to hide or show", width: 160, sortable:true, sorter: "sorterDateIso", visible: true}
];
var columnFilters = {};
if ( store.get('commercialCardsColumnOrder') ) {
	columns = store.get('commercialCardsColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "totallimit" || columns[i].id == "openingbalance" || columns[i].id == "availablefunds") {
			columns[i].groupTotalsFormatter = sumTotalsFormatter;
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
		if (columns[i].id == "minimumdue") {
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('commercialCardsColumnWidths') ) {
	var setWidth = store.get('commercialCardsColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
var groupedSetting = 0, groupCollapseSetting = 0, groupCCYSetting = "AUD";
function sumTotalsFormatter(totals, columnDef) {
	return groupCCYSetting + " " + addCommas(Math.round((totals.sum[columnDef.field] * 100)/100).toFixed(2));
}
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
		getter: item,
		formatter: function (g) {
			return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		displayTotalsRow: true
	}]);
	
	dataView.setAggregators([
		new Slick.Data.Aggregators.Sum("totallimit"),
		new Slick.Data.Aggregators.Sum("openingbalance"),
		new Slick.Data.Aggregators.Sum("availablefunds")
	], true);

	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var labelString = "", findString = "", findDataPoint = "groupname";
function myFilter(item, args) {

	if (args.labelString != "" && item["labelid"] != args.labelString) {
		return false;
	}

	if (args.findString != "" && item[findDataPoint].toLowerCase().indexOf(args.findString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function calculateTotals() {
	var totalAvailable = 0, totalOpening = 0, totalLimits = 0;
	for (var i = 0; i < dataView.getLength(); i++) {
		if (dataView.getItem(i).id) {
			totalLimits = parseFloat(totalAvailable) + parseFloat(dataView.getItem(i).totallimit);
			totalOpening = parseFloat(totalOpening) + parseFloat(dataView.getItem(i).openingbalance);
			totalAvailable = parseFloat(totalAvailable) + parseFloat(dataView.getItem(i).availablefunds);
		}
	}
	totalLimits = addCommas(totalLimits.toFixed(2));
	$("[data-value='totallimits']").html(totalLimits);
	totalOpening = addCommas(totalOpening.toFixed(2));
	$("[data-value='totalopening']").html(totalOpening);
	totalAvailable = addCommas(totalAvailable.toFixed(2));
	$("[data-value='totalavailable']").html(totalAvailable);
}
function filterCards() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	calculateTotals()
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
for (var i=0; i<20; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	d["label"] = "None";
	d["labelid"] = "None";
	d["billingaccountstatus"] = "Active";
	d["billingaccountname"] = "Billing Account"+Math.round(Math.random() * 1000);
	d["billingaccountnumber"] = randNumber(16);
	d["minimumdue"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
	d["lastupdated"] = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 5))));
	d["paymentduedate"] = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(0, 5))));
	d["currency"] = "AUD";
	d["openingbalance"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["availablefunds"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	d["totallimit"] = (Math.round(Math.random() * 1000000)/100).toFixed(2);
	if(i < 10){
		d["producttype"] = "ANZ Travel Account";
		d["company"] = "Consulting Pte. Ltd.";
		d["country"] = "Australia";
		d["bankname"] = "ANZ Australia";
		d["branchcode"] = "ANZSG0311";
	} else {
		d["producttype"] = "ANZ Business One";
		d["company"] = "Manufacturing Inc.";
		d["country"] = "Australia";
		d["bankname"] = "ANZ Australia";
		d["branchcode"] = "ANZMLB356";
	};
};


/**********************************************************************
CARD SUMMARY GRID
**********************************************************************/
var cardSummaryDataView;
var cardSummaryGrid;
var cardSummaryData = [];
var cardSummarySelectedRowIds = [];
var cardSummaryCols = [
	{ id:"cardnumber", name:"Card Number", field:"cardnumber", sortable: true, sorter: "sorterStringCompare",width: 200, visible: true },
	{ id:"cardname", name:"Cardholder Name", field:"cardname", sortable: true, sorter: "sorterStringCompare",width: 200, visible: true },
	{ id:"cardstatus", name:"Card Status", field:"cardstatus", sortable: true, sorter: "sorterStringCompare",width: 160, visible: true },
	{ id:"currency", name:"Currency", field:"currency", width: 100, sortable:true, sorter: "sorterStringCompare",visible: true},
	{ id:"spendcap", name:"Spend Cap", field:"spendcap", width: 180, sortable:true, sorter: "sorterNumeric", visible: true, cssClass: "num", formatter: Slick.Formatters.AmountFormatter, headerCssClass: "righted"},
	{ id:"transactionlimit", name:"Transaction Limit", field:"transactionlimit", width: 180, sortable:true, sorter: "sorterNumeric", visible: true, cssClass: "num", formatter: Slick.Formatters.AmountFormatter, headerCssClass: "righted"},
	{ id:"atmlimit", name:"ATM Limit", field:"atmlimit", width: 180, sortable:true, sorter: "sorterNumeric", visible: true, cssClass: "num", formatter: Slick.Formatters.AmountFormatter, headerCssClass: "righted"},
	{ id:"otclimit", name:"Over The Counter Limit", field:"otclimit", width: 180, sortable:true, sorter: "sorterNumeric", visible: true, cssClass: "num", formatter: Slick.Formatters.AmountFormatter, headerCssClass: "righted"},
	{ id:"lastupdated", name:"Last Updated", field:"lastupdated", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{ id:"openingbalance", name:"Opening Balance", field:"openingbalance", width: 180, sortable:true, sorter: "sorterNumeric", visible: true, cssClass: "num pos", formatter: Slick.Formatters.AmountFormatter, headerCssClass: "righted"},
	{ id:"availablefunds", name:"Available Funds", field:"availablefunds", width: 180, sortable:true, sorter: "sorterNumeric", visible: true, cssClass: "num pos", formatter: Slick.Formatters.AmountFormatter, headerCssClass: "righted"},
	{ id:"opendate", name:"Open Date", field:"opendate", width: 160, sortable:true, sorter: "sorterDateIso", visible: true},
	{ id:"closedate", name:"Close Date", field:"closedate", width: 160, sortable:true, sorter: "sorterDateIso", visible: true}
];
var cardSummaryFilters = {};
var cardSummaryOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if ( store.get('cardSummaryColumnOrder') ) {
	cardSummaryCols = store.get('cardSummaryColumnOrder');
	for (i = 0; i < cardSummaryCols.length; i++) {
		if (cardSummaryCols[i].id == "spendcap" || cardSummaryCols[i].id == "transactionlimit" || cardSummaryCols[i].id == "atmlimit" || cardSummaryCols[i].id == "otclimit" || cardSummaryCols[i].id == "openingbalance" || cardSummaryCols[i].id == "availablefunds") {
			cardSummaryCols[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('cardSummaryColumnWidths') ) {
	var setCardSummaryColWidth = store.get('cardSummaryColumnWidths');
	for (var i in setCardSummaryColWidth) {
		var s = setCardSummaryColWidth[i]
		for (c = 0; c < cardSummaryCols.length; c++) {
			if (s.id == cardSummaryCols[c].id) {
				cardSummaryCols[c].width = s.width
			}
		}
	}
}
var cardSummaryCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
cardSummaryCols.unshift(cardSummaryCheckboxSelector.getColumnDefinition());
function cardSummaryExpandAllGroups() {
	cardSummaryDataView.expandAllGroups();
}
function cardSummaryCollapseAllGroups() {
	cardSummaryDataView.collapseAllGroups();
}
function cardSummaryClearGrouping() {
	cardSummaryDataView.setGrouping([]);
	groupedSetting = 0;
}
function cardSummaryGroupBy(item, text) {
	cardSummaryDataView.setGrouping([{
		getter: item,
		formatter: function (g) {
			return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		displayTotalsRow: true
	}]);
	
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var findCardSummaryString = "", findCardSummaryDataPoint = "cardnumber";
function myCardSummaryFilter(item, args) {
	if (args.findCardSummaryString != "" && item[findCardSummaryDataPoint].toLowerCase().indexOf(args.findCardSummaryString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in cardSummaryFilters) {
		if (columnId !== undefined && cardSummaryFilters[columnId] !== "") {
			var c = cardSummaryGrid.getColumns()[cardSummaryGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = cardSummaryFilters[columnId],
					_field = item[c.field],
					_greaterThen, _lessThen, _comparer, _between = false;
					if (_.isString(_field)) {
						if (item[c.field].toLowerCase().indexOf(cardSummaryFilters[columnId].toLowerCase()) == -1) {
							return false;
						}
					} else {
						_field = item[c.field].replace(/[^\d\.\-\ ]/g, '');
						if (_filter.charAt(0) === ">") {
							_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
							if (_filter.indexOf("<") != -1) {
								_between = true
							}
							if (_between) {
								_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
								if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
									return false;
								}
							} else {
								if (parseFloat(_field) < parseFloat(_greaterThen)) {
									return false;
								}
							}
						} else if (_filter.charAt(0) === "<") {
							_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
							if (_filter.indexOf(">") != -1) {
								_between = true
							}
							if (_between) {
								_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
								if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
									return false;
								}
							} else {
								if (parseFloat(_field) > parseFloat(_lessThen)) {
									return false;
								}
							}
						} else {
							if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
								return false;
							}
						}
					}
			} else {
				if (item[c.field].toLowerCase().indexOf(cardSummaryFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}


	return true;
}
function filterCardSummary() {
	var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showCardSummary = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		cardSummaryDataView.refresh();
		if(groupCollapseSetting == 1) {
			cardSummaryCollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showCardSummary, 500);
}
function toggleCardSummaryFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in cardSummaryFilters) {
		cardSummaryFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		cardSummaryGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		cardSummaryGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	cardSummaryDataView.refresh();
}
for (var i = 0; i < _cardNumbers.length; i++) {
	var card = _cardNumbers[i];
	var d = (cardSummaryData[i] = {});
	d["id"] = "id"+i;
	d["cardnumber"] = card.number;
	d["cardstatus"] = card.status;
	d["cardname"] = card.name;
	d["opendate"] = card.open;
	d["closedate"] = card.close;
	d["lastupdated"] = card.lastupdated;
	d["currency"] = card.currency;
	d["spendcap"] = card.monthly;
	d["transactionlimit"] = card.transaction;
	d["atmlimit"] = card.atm;
	d["otclimit"] = card.otc;
	d["openingbalance"] = card.current;
	d["availablefunds"] = card.available;
}


/**********************************************************************
BALANCE HISTORY GRID
**********************************************************************/
var balanceDataView;
var balancehistorygrid;
var	bdata = [];
var	bcolumns = [
	{ id:"statementcycle", name:"Statement Cycle", field:"statementcycle", width: 160, sortable: true, sorter: "sorterDateIso", visible: true },
	{ id:"currency", name:"Currency", field:"currency", width: 100, sortable: true, sorter: "sorterStringCompare", visible: true },
	{ id:"openingbalance", name:"Opening Balance", field:"openingbalance", width: 180, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter, visible: true },
	{ id:"totaldebits", name:"Total Debits", field:"totaldebits", width: 180, cssClass: "num neg", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter, visible: true },
	{ id:"totalcredits", name:"Total Credits", field:"totalcredits", width: 180, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter, visible: true },
	{ id:"closingbalance", name:"Closing Balance", field:"closingbalance", width: 180, cssClass: "num pos", headerCssClass: "righted", sortable: true, sorter: "sorterNumeric", formatter: Slick.Formatters.AmountFormatter, visible: true }
],
boptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: true,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: false,
	headerRowHeight: 40
};
if ( store.get('commericalCardsBalanceOrder') ) {
	bcolumns = store.get('commericalCardsBalanceOrder');
	for (i = 0; i < bcolumns.length; i++) {
		if (bcolumns[i].id == "openingbalance" || bcolumns[i].id == "totaldebits" || bcolumns[i].id == "totalcredits" || bcolumns[i].id == "closingbalance") {
			bcolumns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('commercialCardsBalanceWidths') ) {
	var setBalanceWidth = store.get('commercialCardsBalanceWidths');
	for (var i in setBalanceWidth) {
		var s = setBalanceWidth[i]
		for (c = 0; c < bcolumns.length; c++) {
			if (s.id == bcolumns[c].id) {
				bcolumns[c].width = s.width
			}
		}
	}
}
for (var i=0; i<30; i++) {
	var d = (bdata[i] = {});
	d["id"] = "id_" + i;
	d["statementcycle"] =  $.datepicker.formatDate('dd/mm/yy', new Date());
	d["currency"] = "AUD";
	d["openingbalance"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
	d["totaldebits"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
	d["totalcredits"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
	d["closingbalance"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
}


/**********************************************************************
CARD ACTIVITY GRID
**********************************************************************/
var cardActivityDataView;
var cardActivityGrid;
var cardActivityData = [];
var cardActivitySelectedRowIds = [];
var cardActivityFilters = {};
var cardActivityColumns = [
	{ id:"transactiondate", name:"Transaction Date", field:"transactiondate", sortable: true, sorter: "sorterDateIso", width: 160, visible: true },
	{ id:"transactiontime", name:"Transaction Time", field:"transactiontime", sortable: true, sorter: "sorterTime", width: 160 , visible: true},
	{ id:"cardnumber", name:"Card Number", field:"cardnumber", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true },
	{ id:"cardholder", name:"Cardholder Name", field:"cardholder", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true },
	{ id:"currency", name:"Currency", field:"currency", width: 100, sortable:true, sorter: "sorterStringCompare", visible: true},
	{ id:"debitamount", name:"Debit", field:"debitamount", sortable: true, sorter: "sorterNumeric", width: 160, groupTotalsFormatter:sumTotalsFormatter, formatter: Slick.Formatters.AmountFormatter, cssClass: "num neg", headerCssClass: "righted", visible: true },
	{ id:"authcode", name:"Authorisation Code", field:"authcode", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"transtatus", name:"Transaction Status", field:"transtatus", width: 160, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantgroup", name:"Merchant Group", field:"merchantgroup", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantname", name:"Merchant Name", field:"merchantname", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantlocation", name:"Merchant Location", field:"merchantlocation", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true}
],
cardActivityOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if ( store.get('cardActivityOrder') ) {
	cardActivityColumns = store.get('cardActivityOrder');
	for (i = 0; i < cardActivityColumns.length; i++) {
		if (cardActivityColumns[i].id == "debitamount") {
			cardActivityColumns[i].groupTotalsFormatter = sumTotalsFormatter;
			cardActivityColumns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('cardActivityWidths') ) {
	var setActivityWidth = store.get('cardActivityWidths');
	for (var i in setActivityWidth) {
		var s = setActivityWidth[i]
		for (c = 0; c < cardActivityColumns.length; c++) {
			if (s.id == cardActivityColumns[c].id) {
				cardActivityColumns[c].width = s.width
			}
		}
	}
}
var cardActivityCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
cardActivityColumns.unshift(cardActivityCheckboxSelector.getColumnDefinition());
function trxnexpandAllGroups() {
	cardActivityDataView.expandAllGroups();
}
function trxncollapseAllGroups() {
	cardActivityDataView.collapseAllGroups();
}
function trxnclearGrouping() {
	cardActivityDataView.setGrouping([]);
	groupedSetting = 0;
}
function trxngroupBy(item, text) {
	cardActivityDataView.setGrouping([{
		getter: item,
		formatter: function (g) {
			return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		displayTotalsRow: true
	}]);
	cardActivityDataView.setAggregators([
		new Slick.Data.Aggregators.Sum("debitamount")
	], true);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var findActivityString = "", findActivityDataPoint = "cardnumber";
function myActivityFilter(item, args) {

	if (args.findActivityString != "" && item[findActivityDataPoint].toLowerCase().indexOf(args.findActivityString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in cardActivityFilters) {
		if (columnId !== undefined && cardActivityFilters[columnId] !== "") {
			var c = cardActivityGrid.getColumns()[cardActivityGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = cardActivityFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(cardActivityFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterActivity() {
	var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showActivity = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		cardActivityDataView.refresh();
		if(groupCollapseSetting == 1) {
			trxncollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showActivity, 500);
}
function toggleCardActivityFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in cardActivityFilters) {
		cardActivityFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		cardActivityGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		cardActivityGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	cardActivityDataView.refresh();
}
for (var i=0; i<75; i++) {
	var _card = _cardNumbers[rand(0, _cardNumbers.length - 1)];
	var d = (cardActivityData[i] = {});
	d["id"] = "id_" + i;
	d["transactiondate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["postdate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["transactiontime"] = timeFormatter();
	d["cardnumber"] = _card.number;
	d["cardholder"] = _card.name;
	d["merchantgroup"] = "AUSTRALIA PL BRISBANE";
	d["merchantname"] = "PL BRISBANE";
	d["merchantlocation"] = "BRISBANE";
	d["currency"] = "AUD";
	d["debitamount"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
	d["authcode"] = randNumber(10);
	d["transtatus"] = "APPROVED";
}


/**********************************************************************
OUTSTANDING TRANSACTIONS GRID
**********************************************************************/
var outstandingDataView;
var outstandingGrid;
var outstandingData = [];
var outstandingSelectedRowIds = [];
var outstandingFilters = {};
var outstandingCols = [
	{ id:"transactiondate", name:"Transaction Date", field:"transactiondate", sortable: true, sorter: "sorterDateIso", width: 160, visible: true },
	{ id:"transactiontime", name:"Transaction Time", field:"transactiontime", sortable: true, sorter: "sorterTime", width: 160 , visible: true},
	{ id:"cardnumber", name:"Card Number", field:"cardnumber", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true },
	{ id:"cardholder", name:"Cardholder Name", field:"cardholder", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true },
	{ id:"currency", name:"Currency", field:"currency", width: 100, sortable:true, sorter: "sorterStringCompare", visible: true},
	{ id:"debitamount", name:"Debit", field:"debitamount", sortable: true, sorter: "sorterNumeric", width: 160, groupTotalsFormatter:sumTotalsFormatter, formatter: Slick.Formatters.AmountFormatter, cssClass: "num neg", headerCssClass: "righted", visible: true },
	{ id:"merchantgroup", name:"Merchant Group", field:"merchantgroup", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantname", name:"Merchant Name", field:"merchantname", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantlocation", name:"Merchant Location", field:"merchantlocation", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true}
];
var outstandingOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if ( store.get('outstandingColumnOrder') ) {
	outstandingCols = store.get('outstandingColumnOrder');
	for (i = 0; i < outstandingCols.length; i++) {
		if (outstandingCols[i].id == "debitamount") {
			outstandingCols[i].groupTotalsFormatter = sumTotalsFormatter;
			outstandingCols[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('outstandingColumnWidths') ) {
	var setOutstandingColumnWidth = store.get('outstandingColumnWidths');
	for (var i in setOutstandingColumnWidth) {
		var s = setOutstandingColumnWidth[i]
		for (c = 0; c < outstandingCols.length; c++) {
			if (s.id == outstandingCols[c].id) {
				outstandingCols[c].width = s.width
			}
		}
	}
}
var outstandingCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
outstandingCols.unshift(outstandingCheckboxSelector.getColumnDefinition());
function outstandingExpandAllGroups() {
	outstandingDataView.expandAllGroups();
}
function outstandingCollapseAllGroups() {
	outstandingDataView.collapseAllGroups();
}
function outstandingClearGrouping() {
	outstandingDataView.setGrouping([]);
	groupedSetting = 0;
}
function outstandingGroupBy(item, text) {
	outstandingDataView.setGrouping([{
		getter: item,
		formatter: function (g) {
			return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		displayTotalsRow: true
	}]);
	outstandingDataView.setAggregators([
		new Slick.Data.Aggregators.Sum("debitamount")
	], true);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var findOutstandingString = "", findOutstandingDataPoint = "cardnumber";
function myOutstandingFilter(item, args) {
	if (args.findOutstandingString != "" && item[findOutstandingDataPoint].toLowerCase().indexOf(args.findOutstandingString.toLowerCase()) == -1) {
		return false;
	}
	for (var columnId in outstandingFilters) {
		if (columnId !== undefined && outstandingFilters[columnId] !== "") {
			var c = outstandingGrid.getColumns()[outstandingGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = outstandingFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(outstandingFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterOutstanding() {
	var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showOutstanding = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		outstandingDataView.refresh();
		if(groupCollapseSetting == 1) {
			outstandingCollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showOutstanding, 500);
}
function toggleOustandingFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in outstandingFilters) {
		outstandingFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		outstandingGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		outstandingGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	outstandingDataView.refresh();
}
for (var i=0; i<20; i++) {
	var _card = _cardNumbers[rand(0, _cardNumbers.length - 1)];
	var d = (outstandingData[i] = {});
	d["id"] = "id_" + i;
	d["transactiondate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["transactiontime"] = timeFormatter();
	d["cardnumber"] = _card.number;
	d["cardholder"] = _card.name;
	d["merchantgroup"] = "AUSTRALIA PL BRISBANE";
	d["merchantname"] = "PL BRISBANE";
	d["merchantlocation"] = "BRISBANE";
	d["currency"] = "AUD";
	d["debitamount"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
}

/**********************************************************************
DECLINED TRANSACTIONS GRID
**********************************************************************/
var declinedDataView;
var declinedGrid;
var declinedData = [];
var declinedSelectedRowIds = [];
var declinedFilters = {};
var declinedCols = [
	{ id:"transactiondate", name:"Transaction Date", field:"transactiondate", sortable: true, sorter: "sorterDateIso", width: 160, visible: true },
	{ id:"transactiontime", name:"Transaction Time", field:"transactiontime", sortable: true, sorter: "sorterTime", width: 160 , visible: true},
	{ id:"cardnumber", name:"Card Number", field:"cardnumber", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true },
	{ id:"cardholder", name:"Cardholder Name", field:"cardholder", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true },
	{ id:"currency", name:"Currency", field:"currency", width: 100, sortable:true, sorter: "sorterStringCompare", visible: true},
	{ id:"debitamount", name:"Debit", field:"debitamount", sortable: true, sorter: "sorterNumeric", width: 160, groupTotalsFormatter:sumTotalsFormatter, formatter: Slick.Formatters.AmountFormatter, cssClass: "num neg", headerCssClass: "righted", visible: true },
	{ id:"declinedreason", name:"Declined Reason", field:"declinedreason", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantgroup", name:"Merchant Group", field:"merchantgroup", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantname", name:"Merchant Name", field:"merchantname", width: 200, sortable: true, sorter: "sorterStringCompare", visible: true},
	{ id:"merchantlocation", name:"Merchant Location", field:"merchantlocation", sortable: true, sorter: "sorterStringCompare", width: 200, visible: true}
];
var declinedOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if ( store.get('declinedColumnOrder') ) {
	declinedCols = store.get('declinedColumnOrder');
	for (i = 0; i < declinedCols.length; i++) {
		if (declinedCols[i].id == "debitamount") {
			declinedCols[i].groupTotalsFormatter = sumTotalsFormatter;
			declinedCols[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if ( store.get('declinedColumnWidths') ) {
	var setDeclinedColumnWidth = store.get('declinedColumnWidths');
	for (var i in setDeclinedColumnWidth) {
		var s = setDeclinedColumnWidth[i]
		for (c = 0; c < declinedCols.length; c++) {
			if (s.id == declinedCols[c].id) {
				declinedCols[c].width = s.width
			}
		}
	}
}
var declinedCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
declinedCols.unshift(declinedCheckboxSelector.getColumnDefinition());
function declinedExpandAllGroups() {
	declinedDataView.expandAllGroups();
}
function declinedCollapseAllGroups() {
	declinedDataView.collapseAllGroups();
}
function declinedClearGrouping() {
	declinedDataView.setGrouping([]);
	groupedSetting = 0;
}
function declinedGroupBy(item, text) {
	declinedDataView.setGrouping([{
		getter: item,
		formatter: function (g) {
			return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		displayTotalsRow: true
	}]);
	declinedDataView.setAggregators([
		new Slick.Data.Aggregators.Sum("debitamount")
	], true);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
var findDeclinedString = "", findDeclinedDataPoint = "cardnumber";
function myDeclinedFilter(item, args) {
	if (args.findDeclinedString != "" && item[findDeclinedDataPoint].toLowerCase().indexOf(args.findDeclinedString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in declinedFilters) {
		if (columnId !== undefined && declinedFilters[columnId] !== "") {
			var c = declinedGrid.getColumns()[declinedGrid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = declinedFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(declinedFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterDeclined() {
	var $loading = $(".loading-panel"), $primarytab = $(".primary-tabs ul").children("li.active").children("a")
	var showDeclined = function() {
		$primarytab.removeClass("load");
		$loading.addClass("hidden");
		declinedDataView.refresh();
		if(groupCollapseSetting == 1) {
			declinedCollapseAllGroups();
		}
	}
	$primarytab.addClass("load");
	$loading.removeClass("hidden");
	setTimeout(showDeclined, 500);
}
function toggleDeclinedFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in declinedFilters) {
		declinedFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		declinedGrid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		declinedGrid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	declinedDataView.refresh();
}
for (var i=0; i<20; i++) {
	var _card = _cardNumbers[rand(0, _cardNumbers.length - 1)];
	var d = (declinedData[i] = {});
	d["id"] = "id_" + i;
	d["transactiondate"] = $.datepicker.formatDate('dd/mm/yy', new Date());
	d["transactiontime"] = timeFormatter();
	d["cardnumber"] = _card.number;
	d["cardholder"] = _card.name;
	d["merchantgroup"] = "AUSTRALIA PL BRISBANE";
	d["merchantname"] = "PL BRISBANE";
	d["merchantlocation"] = "BRISBANE";
	d["currency"] = "AUD";
	d["debitamount"] = (Math.round(Math.random() * 100000)/100).toFixed(2);
	d["declinedreason"] = "DECLINED - REASON";
}


/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var commercial_cards_folders = [], folders_updated = false, folders_deleted = false;
$folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Accounts</p><p style='font-size: 14px;'>Folders help you keep your accounts organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move accounts into a folder by selecting them in the accounts grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-th-list fa-fw'></i> View Menu.</p></div>"),
$folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if ( store.get('account_folders') ) { commercial_cards_folders = store.get('account_folders') };
function folderFilter() {
	var rows = grid.getSelectedRows()
	if(rows.length > 0) {
		grid.setSelectedRows(0)
	}
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	})
	filterCards()
}
function folderChecker(val) {
	var _folder = val, error = false, $folderList = $(".folder-list").children("li"), existingFolders = [];
	for ( var i = 0; i < $folderList.length; i++ ) {
		existingFolders.push( $folderList.eq(i).attr("data-folder") );
	}
	if ($.inArray(_folder, existingFolders) != -1) { error = "existing" }
	return error;
}
function renameFolder(el) {
	var newFolderName = $.trim(el.val());
	if ( newFolderName == '' || newFolderName == "undefined" ) {
		el.val( el.attr("data-folder-name") );
	} else {
		el.val(newFolderName);
		el.closest("li").attr("data-folder", newFolderName );
		folders_updated = true;
	}
}
function addFolder() {
	var folderName = $.trim($("#newFolderInput").val()), $folderList = $("ul.folder-list"), $newFolderDiv = $("div.new-folder"), $li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
	if ( folderName == '' || folderName== "undefined" ) {
		$("#newFolderInput").val('');
		return false;
	} else {
		if ( folderCheck == "existing" ) {
			 $newFolderDiv.addClass("error");
			 $("#newFolderInput").focus().select().one("keyup.remove-error", function() { $newFolderDiv.removeClass("error"); });
		} else {
			if ( $newFolderDiv.hasClass("error") ) { $newFolderDiv.removeClass("error"); }
			if ( $(".folder-message").size() ) {
				$(".folder-message").remove();
				$folderListInstruction.insertBefore($folderList);
			}
			$li = $("<li data-folder='"+folderName+"' data-folder-id='"+randString()+"' class='row new' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' value='"+folderName+"' maxlength='25' data-folder-name='"+folderName+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
			$("#newFolderInput").val('');
			$folderList.sortable("refresh");
			folders_updated = true;
		}
	}
}
function addFolderInline() {
	var folderName = $.trim($("#_inlineFolderInput").val()), folderExists = false;
	if ( folderName == '' || folderName == "undefined" ) {
		$("#_inlineFolderInput").val('');
		return false;
	} else {
		for ( var i = 0; i < commercial_cards_folders.length; i++ ) {
			if ( folderName == commercial_cards_folders[i].name ) {
				folderExists = true;
				break;
			}
		}
		if ( folderExists ) {
			alert("A folder with that name already exists.");
		} else {
			var _id = randString();
			var _new = { name: folderName, id: _id };
			commercial_cards_folders.push(_new);
			populateFolders();
			store.set('account_folders', commercial_cards_folders);
			$("#_inlineFolderInput").val('');
			moveAccounts(_id);
		}
	}
}
function deleteFolder(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function(){
		if ( !$target.hasClass('new') ) { folders_deleted = true; }
		$target.remove();
		$(".folder-list").sortable("refresh");
		folders_updated = true;
		if ( !$(".folder-list").children("li").size() ) {
			$(".folder-list-instructions").remove();
			$folderMessage.appendTo(".folder-settings");
		}
		if ( $("div.new-folder").hasClass("error") ) {
			 $("div.new-folder").removeClass("error");
		}
	 });
}
function populateFolders() {
	var $assignFolders = $(".assign-folders"), folderCount = commercial_cards_folders.length, activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
	$assignFolders.children().remove();
	if ( $("#removeFromFolder").size() > 0 ) { $("#removeFromFolder").remove(); }
	if ( folderCount > 0 ) {
		var $li, $a
		$assignFolders.each( function() {
			var _this = $(this);
			if (  _this.parents().attr("id") == "folderMenu" ) {
				$.each(commercial_cards_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
					}).appendTo($li);
				});
				var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
				$spacer = $("<li class='menu-section' />").appendTo($ul),
				$li = $("<li />").appendTo($ul),
				$a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected accounts from folders' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
					e.preventDefault(); moveAccounts( $(this).attr("data-folder-id") );
				}).appendTo($li),
				$spacer = $("<li class='menu-section' />").appendTo($ul);
			} else if ( _this.parents().attr("id") == "viewMenu" ) {
				$.each(commercial_cards_folders, function() {
					$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' />").appendTo(_this);
					if ( this.id == activeFolder ) { $li.addClass("active"); $("#viewMenuControl").children("a").children("span").html(this.name); }
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-folder='"+this.name+"' data-folder-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						e.preventDefault();
						var _folderID = $(this).attr("data-folder-id"), _folderName = $(this).attr("data-folder");
						if ( labelString != _folderID ) {
							labelString = _folderID;
						}
						folderFilter();
						$("#selectedFolder").html(_folderName);
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
		$li = $("<li class='no-set' />").appendTo($viewMenu),
		$a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Folders</div>Folders help keep your data organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
	}
}
function populateFolderManager() {
	folders_updated = false; folders_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
	$folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
	$folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
	$folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e){if(e.keyCode == 13){addFolder()}}).appendTo($folderAddDiv),
	$folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
	$folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
	$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({ handle: '.reorder-folder', axis: 'y', tolerance: "pointer", update: function( event, ui ) { folders_updated = true } }),
	folderCount = commercial_cards_folders.length, $li, $div, $span, $input, $a, $error;
	if ( folderCount > 0 ) {
		$folderListInstruction.insertBefore($folderList);
		$.each(commercial_cards_folders, function() {
			$li = $("<li data-folder='"+this.name+"' data-folder-id='"+this.id+"' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='"+this.name+"' data-folder-name='"+this.name+"' />").on("change", function() { renameFolder( $(this) );}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
		});
	} else {
		$folderMessage.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showFolderManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Operating Account Folders",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function(){return populateFolderManager()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();updateFolders(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
function saveFolders(dialog) {
	var $dialog = $("#"+dialog.id), $active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
	$dialog.addClass("working");
	commercial_cards_folders = folders_updated;

	var active_deleted = true;

	for ( f = 0; f < commercial_cards_folders.length; f++ ) {
		if ( $active == commercial_cards_folders[f].id ) {
			active_deleted = false;
			break;
		}
	}

	for ( var i = 0; i < data.length; i++ ) {
		var _resetFolder = true;
		for ( var n = 0; n < commercial_cards_folders.length; n++ ) {
			if ( data[i].labelid == commercial_cards_folders[n].id ) {
				data[i].label = commercial_cards_folders[n].name;
				_resetFolder = false;
				break;
			}
		}
		if ( _resetFolder ) {
			data[i].label = "None";
			data[i].labelid = "None";
		}

	}
	folders_updated = false;
	folders_deleted = false;
	store.set('account_folders', commercial_cards_folders);
	setTimeout( function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateFolders();
		if ( !commercial_cards_folders.length || active_deleted ) { $("#_allAccounts").trigger("click"); }
		dialogHider(dialog);
	}, 300);
}
function updateFolders(dialog) {
	if ( folders_updated ) {
		folders_updated = [];
		var duplicate_names = false, $folderList = $(".folder-list");
		$folderList.find("li.error").removeClass("error");
		$folderList.children("li").each(function() {
			folders_updated.push( { "name":$(this).attr("data-folder"), "id":$(this).attr("data-folder-id") });
			var _name = $(this).attr("data-folder");
			$(this).siblings().each(function() {
				if ( $(this).attr("data-folder") == _name ) {
					$(this).addClass("error");
				}
			});
		});
		if ( $folderList.find("li.error").size() ) {
			duplicate_names = true;
		}
		if ( duplicate_names ) {
			return false;
		} else {
			var save_folders = false;
			if ( commercial_cards_folders.length != folders_updated.length ) {
				save_folders = true;
			} else {
				for (var i = 0; i < commercial_cards_folders.length; i++) {
					if ( commercial_cards_folders[i].name != folders_updated[i].name || commercial_cards_folders[i].id != folders_updated[i].id ) {
						save_folders = true;
						break;
					}
				}
			}
			if ( save_folders || folders_deleted ) {
				if ( folders_deleted ) {
					buildConfirmDialog( "You've removed some existing folders.", "Are you sure you want to continue?", function(){saveFolders(dialog)});
				} else {
					saveFolders(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}
function moveAccounts(_id) {
	var _folder, _message, _rowsForUpdate = [], _sel = selectedRowIds.length;
	for ( var i = 0; i < commercial_cards_folders.length; i++ ) {
		if ( commercial_cards_folders[i].id == _id ) {
			_folder = commercial_cards_folders[i];
			_message = "Selected accounts were moved to &quot;"+_folder.name+"&quot;";
			break;
		}
	}
	if ( _id == "None" ) {
		_folder = [{ name:"None", id:"None"}];
		_message = "Selected accounts were removed from their folders";
	}
	for ( var i = 0, l = _sel; i < l; i++ ) {
		var _item = selectedRowIds[i];
		if ( _item ) {
			_rowsForUpdate.unshift(_item);
		}
	}
	for ( var i = 0; i < _rowsForUpdate.length; i++ ) {
		data[dataView.getIdxById(_rowsForUpdate[i])].label = _folder.name;
		data[dataView.getIdxById(_rowsForUpdate[i])].labelid = _folder.id;
	}
	grid.setSelectedRows(0);
	selectedRowIds = [];
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) { collapseAllGroups(); }
	groupedSetting = 1;
	buildNotification(_message, 300, 3000);
	store.set('commercialCardsData', dataView.getItems());
	$("#viewMenu .assign-folders").find("a[data-folder-id='"+_folder.id+"']").trigger("click");
}


/**********************************************************************
REQUEST REPORTS
**********************************************************************/
function showAccountStatementModal(e) {
	e.preventDefault();

	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.","It will be available for download in the &quot;Download Reports&quot; section shortly.","");
		}, 3000);
	};

	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).closest("div.data-column").find("div.data-note"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='statementSpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();
		} else if ( _date == "dr" ) {
			$("#statementSpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='statementFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='statementToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var statementeDatRange = $("#statementFromDate, #statementToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "statementFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					statementeDatRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#statementSpecificDate, #statementFromDate, #statementToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
	};

	var formElements = [
		{ name: "Report Format", id: "stmt-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "MT940", value: "MT940"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "stmt-name", type: "input", max: 30 },
		{ name: "Description", id: "stmt-desc", type: "input", max: 75 },
		{ name: "Data From", id: "stmt-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);

	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $custom, $note, _type = formElements[i].type;

		if ( _type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}

		if ( _type == "select" ) {
			$custom = $("<div class='custom-select' />");
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
			$el.appendTo($custom)
		}

		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}

		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}

		if ( _type == "select" ) {
			$custom.appendTo($data);
		} else {
			$el.appendTo($data);
		}



		if ( formElements[i].note ) {
			$note = $("<div class='data-note' style='margin-top: 10px;'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestStatement",
		title: "Account Statement Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
function showBalanceHistoryModal(e) {
	e.preventDefault();
	function downloadReport(_dialog) {
		dialogHider(_dialog);
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			buildConfirmDialog("Your report took more than 3 seconds to generate.","It will be available for download in the &quot;Downloads&quot; section shortly.","");
		}, 3000);
	};
	function dateRefresh() {
		var _date = $(this).val(), $dateNote = $(this).parent("div.data-column").find("div.data-text"), $row = $(this).closest("div.row");
		if ( _date == "sd" ) {
			$("#summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $specificDate = $("<input type='text' id='summarySpecificDate' style='width: 120px !important;' placeholder='Date' />").datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true}).appendTo($dateNote).focus();
		} else if ( _date == "dr" ) {
			$("#summarySpecificDate").datepicker("destroy").remove();
			$dateNote.empty();
			var $dateRangeFrom = $("<input type='text' id='summaryFromDate' style='width: 120px !important;' placeholder='From' />").appendTo($dateNote);
			var $dateRangeTo = $("<input type='text' id='summaryToDate' style='width: 120px !important;' placeholder='To' />").appendTo($dateNote);
			var summaryDateRange = $("#summaryFromDate, #summaryToDate").datepicker({
				duration: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				numberOfMonths: 1,
				onSelect: function( selectedDate ) {
					var option = this.id == "summaryFromDate" ? "minDate" : "maxDate",
						instance = $( this ).data( "datepicker" ),
						date = $.datepicker.parseDate(
							instance.settings.dateFormat ||
							$.datepicker._defaults.dateFormat,
							selectedDate, instance.settings );
					summaryDateRange.not( this ).datepicker( "option", option, date );
				}
			});
			$dateRangeFrom.focus();
		} else {
			$("#summarySpecificDate, #summaryFromDate, #summaryToDate").datepicker("destroy").remove();
			$dateNote.empty().html( $(this).val() );
		}
		$row.add("focused");
	};
	var formElements = [
		{ name: "Report Format", id: "bal-format", type: "select", data: [{option: "CSV", value: "CSV"},{option: "MT940", value: "MT940"},{option: "PDF", value: "PDF"}] },
		{ name: "File Name", id: "bal-name", type: "input", max: 30 },
		{ name: "Description", id: "bal-desc", type: "input", max: 75 },
		{ name: "Data From", id: "bal-date", type: "select", data: [{option: "Today", value: smartDates("today")}, {option: "Yesterday", value: smartDates("yesterday")}, {option: "Week To Date", value: smartDates("weektodate")}, {option: "Last Week", value: smartDates("lastweek")}, {option: "Month To Date", value: smartDates("monthtodate")}, {option: "Last Month", value: smartDates("lastmonth")}, {option: "Specific Date", value: "sd"}, {option: "Date Range", value: "dr"} ], events: [{event: "change", action: dateRefresh}], note: true, notevalue: smartDates("today") }
	],
	$formWrapper =  $("<div class='data-form' />"),
	$formSection = $("<div class='form-section' />").appendTo($formWrapper);
	for (var i = 0; i < formElements.length; i++) {
		var $row = $("<div class='row' />").on("focusin", function(){ $(this).addClass("focused") }).on("focusout", function(){ $(this).removeClass("focused") }).appendTo($formSection),
		$label = $("<div class='label-column'><label>"+formElements[i].name+"</label></div>)").appendTo($row),
		$data = $("<div class='data-column' />").appendTo($row),
		$el, $note;
		if ( formElements[i].type == "select" ) {
			$el = $("<select id='"+formElements[i].id+"'></select>");
			if ( formElements[i].data ) {
				for (var d = 0; d < formElements[i].data.length; d++) {
					var $option = $("<option value="+formElements[i].data[d].value+">"+formElements[i].data[d].option+"</option>").appendTo($el)
				}
			}
		} else if ( formElements[i].type == "input" ) {
			$el = $("<input type='text' id='"+formElements[i].id+"' maxlength='"+formElements[i].max+"' />");
		}
		if ( formElements[i].attributes ) {
			for (var a = 0; a < formElements[i].attributes.length; a++) {
				$el.attr( formElements[i].attributes[a].name, formElements[i].attributes[a].value );
			}
		}
		if ( formElements[i].events ) {
			for (var e = 0; e < formElements[i].events.length; e++) {
				$el.on( formElements[i].events[e].event, formElements[i].events[e].action );
			}
		}
		$el.appendTo($data);
		if ( formElements[i].note ) {
			$note = $("<div class='data-text'>"+formElements[i].notevalue+"</div>").appendTo($data);
		}
	};
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "requestBalances",
		title: "Balance Summary Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: $formWrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();downloadReport(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}


/**********************************************************************
SERVICE REQUEST WARNING
**********************************************************************/
function navigateToServiceRequests(e) {
	document.location.href="service-requests-from-account.html#new";
}

function createServiceRequestWarning(e) {
	e.preventDefault();
	buildConfirmDialog( "This will take you to the Service Requests Application to create a new account related service request.", "Do you want to proceed?", function(){navigateToServiceRequests(e)});
}


/**********************************************************************
UPDATE THE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='commercial-cards.html'>Commercial Cards</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Billing Entity Details");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Commercial Cards");
	}
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	INITIALIZE MAIN GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#summaryGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, "commercialCardsColumnOrder", "commercialCardsColumnWidths", ["checkBoxSelector"]);
	grid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			if (rows.length > 1) {
				$cmenu = $("#multipleContextMenu")
			} else {
				$cmenu = $("#contextMenu")
			}
		};
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if(selectedRowIds.length > 0) {
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#selectedCount").html('');
		}
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var cell = grid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		if( !$row.is(".slick-group, .slick-group-totals") ) {
			$row.attr({'data-panel': '#accountDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels');
			$("#cardSummaryTab").trigger("click");
			updateBreadcrumb("view");
			$row.removeAttr("data-panel data-switch");
			grid.setSelectedRows(0);
			selectedRowIds = [];
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('commercialCardsColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e,args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e,args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0)
		{
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++)
			{
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	if (store.get('commercialCardsData')) {
		data = store.get('commercialCardsData')
	}
	dataView.setItems(data);
	dataView.setFilterArgs({
		labelString: labelString,
		findString: findString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if ( store.get('commercialCardsColumnOrder') ) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('commercialCardsColumnOrder').length+1; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	INITIALIZE CARD SUMMARY GRID
	**********************************************************************/
	var cardSummaryGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	cardSummaryDataView = new Slick.Data.DataView({
		cardSummaryGroupItemMetadataProvider: cardSummaryGroupItemMetadataProvider
	});
	cardSummaryGrid = new Slick.Grid("#cardSummaryGrid", cardSummaryDataView, cardSummaryCols, cardSummaryOptions);
	cardSummaryGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	cardSummaryGrid.registerPlugin(cardSummaryGroupItemMetadataProvider);
	cardSummaryGrid.registerPlugin(cardSummaryCheckboxSelector);
	var cardSummaryColumnpicker = new Slick.Controls.ColumnPicker(cardSummaryCols, cardSummaryGrid, cardSummaryOptions, 'cardSummaryColumnOrder', 'cardSummaryColumnWidths', ["cardSummaryCheckboxSelector"]);
	cardSummaryGrid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();
		var cell = cardSummaryGrid.getCellFromEvent(e), row = cell.row, rows = cardSummaryGrid.getSelectedRows(), $cmenu = $("#cardSummaryContextMenu");
		if ($.inArray(row, rows) == -1) {
			cardSummaryGrid.setSelectedRows([row])
		} else {
			if (rows.length > 1) {
				$cmenu = $("#cardSummaryContextMenuMultiSelected")
			} else {
				$cmenu = $("#cardSummaryContextMenu")
			}
		};
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	cardSummaryGrid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		cardSummarySelectedRowIds = [];
		var rows = cardSummaryGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = cardSummaryDataView.getItem(rows[i])
			if (item.id) cardSummarySelectedRowIds.push(item.id)
		}
		if(cardSummarySelectedRowIds.length > 0) {
			$("#cardSummarySelectedCount").html(cardSummarySelectedRowIds.length);
		} else {
			$("#cardSummarySelectedCount").html('');
		}
	});
	cardSummaryGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		cardSummaryDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	cardSummaryGrid.onClick.subscribe(function(e, args) {
		var acell = cardSummaryGrid.getCellFromEvent(e);
		var arow = acell.row;
		$('#accountActivityTab').trigger('click');
	});
	cardSummaryGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('cardSummaryColumnWidths', cardSummaryGrid.getColumns());
	});
	$(cardSummaryGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			cardSummaryFilters[columnId] = $.trim($(this).val());
			$icon.show();
			cardSummaryDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	cardSummaryGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(cardSummaryFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	cardSummaryDataView.onRowCountChanged.subscribe(function(e,args) {
		cardSummaryGrid.updateRowCount();
		cardSummaryGrid.render();
	});
	cardSummaryDataView.onRowsChanged.subscribe(function(e,args) {
		cardSummaryGrid.invalidateRows(args.rows);
		cardSummaryGrid.render();
		if (cardSummarySelectedRowIds.length > 0)
		{
			var cardSummarySelRows = [];
			for (var i = 0; i < cardSummarySelectedRowIds.length; i++)
			{
				var idx = cardSummaryDataView.getRowById(cardSummarySelectedRowIds[i]);
				if (idx != undefined)
					cardSummarySelRows.push(idx);
			}
			cardSummaryGrid.setSelectedRows(cardSummarySelRows);
		}
	});
	cardSummaryDataView.setItems(cardSummaryData);
	cardSummaryDataView.setFilterArgs({
		findCardSummaryString: findCardSummaryString
	});
	cardSummaryDataView.syncGridSelection(cardSummaryGrid, true, false);
	cardSummaryDataView.syncGridCellCssStyles(cardSummaryGrid, "contextMenu");
	cardSummaryDataView.setFilter(myCardSummaryFilter);
	cardSummaryGrid.setColumns(cardSummaryCols);
	if ( store.get('cardSummaryColumnOrder') ) {
		var visibleCardSummaryCols = [];
		for (var i = 0; i < store.get('cardSummaryColumnOrder').length + 1; i++) {
			if (cardSummaryCols[i].visible) {
				visibleCardSummaryCols.push(cardSummaryCols[i])
			}
		}
		cardSummaryGrid.setColumns(visibleCardSummaryCols);
	}
	cardSummaryGrid.setHeaderRowVisibility(false);



	/**********************************************************************
	INITIALIZE BALANCE HISTORY GRID
	**********************************************************************/
	var balanceHistoryItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	balanceDataView = new Slick.Data.DataView({
		balanceHistoryItemMetaProvider: balanceHistoryItemMetaProvider
	});
	balancehistorygrid = new Slick.Grid("#balanceGrid", balanceDataView, bcolumns, boptions);
	balancehistorygrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	balancehistorygrid.registerPlugin(balanceHistoryItemMetaProvider);
	var bcolumnpicker = new Slick.Controls.ColumnPicker(bcolumns, balancehistorygrid, boptions, 'commericalCardsBalanceOrder', 'commercialCardsBalanceWidths');
	balancehistorygrid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = balancehistorygrid.getCellFromEvent(e),
			row = cell.row,
			rows = balancehistorygrid.getSelectedRows(),
			$cmenu = $("#balanceContextMenu");
		if ($.inArray(row, rows) == -1) {
			balancehistorygrid.setSelectedRows([row])
		}
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	balancehistorygrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		balanceDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	balancehistorygrid.onClick.subscribe(function(e, args) {
		var bcell = balancehistorygrid.getCellFromEvent(e);
		var brow = balancehistorygrid.row;
		$('#accountActivityTab').trigger('click');
	});
	balancehistorygrid.onColumnsResized.subscribe(function(e, args) {
		store.set('commercialCardsBalanceWidths', balancehistorygrid.getColumns());
	});
	balanceDataView.onRowCountChanged.subscribe(function(e,args) {
		balancehistorygrid.updateRowCount();
		balancehistorygrid.render();
	});
	balanceDataView.onRowsChanged.subscribe(function(e,args) {
		balancehistorygrid.invalidateRows(args.rows);
		balancehistorygrid.render();
	});
	balanceDataView.syncGridSelection(balancehistorygrid, true, false);
	balanceDataView.syncGridCellCssStyles(balancehistorygrid, "contextMenu");
	balanceDataView.setItems(bdata);
	balancehistorygrid.setColumns(bcolumns);
	if ( store.get('commericalCardsBalanceOrder') ) {
		var visibleBalanceColumns = [];
		for (var i = 0; i < store.get('commericalCardsBalanceOrder').length; i++) {
			if (bcolumns[i].visible) {
				visibleBalanceColumns.push(bcolumns[i])
			}
		}
		balancehistorygrid.setColumns(visibleBalanceColumns);
	}


	/**********************************************************************
	INITIALIZE ACCOUNT ACTIVITY GRID
	**********************************************************************/
	var cardActivityGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	cardActivityDataView = new Slick.Data.DataView({
		cardActivityGroupItemMetadataProvider: cardActivityGroupItemMetadataProvider
	});
	cardActivityGrid = new Slick.Grid("#cardActivityGrid", cardActivityDataView, cardActivityColumns, cardActivityOptions);
	cardActivityGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	cardActivityGrid.registerPlugin(cardActivityGroupItemMetadataProvider);
	cardActivityGrid.registerPlugin(cardActivityCheckboxSelector);
	var activityColumnpicker = new Slick.Controls.ColumnPicker(cardActivityColumns, cardActivityGrid, cardActivityOptions, 'cardActivityOrder', 'cardActivityWidths', ["cardActivityCheckboxSelector"]);
	cardActivityGrid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();
		var cell = cardActivityGrid.getCellFromEvent(e), row = cell.row, rows = cardActivityGrid.getSelectedRows(), $cmenu = $("#transactionContextMenu");
		if ($.inArray(row, rows) == -1) {
			cardActivityGrid.setSelectedRows([row])
		}
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	cardActivityGrid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		cardActivitySelectedRowIds = [];
		var rows = cardActivityGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = cardActivityDataView.getItem(rows[i])
			if (item.id) cardActivitySelectedRowIds.push(item.id)
		}
	});
	cardActivityGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		cardActivityDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	cardActivityGrid.onClick.subscribe(function(e, args) {
		var acell = cardActivityGrid.getCellFromEvent(e), arow = acell.row, $arow = $(e.target).closest(".slick-row");
		if( !$arow.is(".slick-group, .slick-group-totals") ) {
			e.preventDefault();
			cardActivityGrid.setSelectedRows(0);
			cardActivitySelectedRowIds = [];
			function showTransactionDetails() {
				function navigateTransactions() {}
				function voucherImages() {}
				function transactionHelp() {}
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
				$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
				$controls = $("<div class='control-list right' />").appendTo($navigationBar),
				$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
				$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
				$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
				details = [
					{name: "Account Name", id: "td2", type: "text", data: "AUD Operations"},
					{name: "Account Number", id: "td3", type: "text", data: "3341233212123123 (AUD)"},
					{name: "Card Number", id: "td1", type: "text", data: "47777xxxxxxxxxxxxxxxx767"},
					{name: "Transaction Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "10,300.00"},
					{name: "Billed Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "10,300.00"},
					{name: "Estimated GST Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "25.00"},
					{name: "Billed Currency", id: "td5", type: "text", data: "AUD"},
					{name: "Posting Date", id: "td6", type: "text", data: smartDates("yesterday")},
					{name: "Value Date", id: "td7", type: "text", data: smartDates("yesterday")},
					{name: "Merchant Category Code &amp; Name", id: "td9", type: "text", data: "DEBAO AUSTRALIA"},
					{name: "Merchant Group", id: "td10", type: "text", data: "DEBAO AUSTRALIA"},
					{name: "Narrative", id: "td11", type: "text", data: "DEBAO AUSTRALIA PL BRISBANE"}
				],
				$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
				$formSection = $("<div class='form-section' />").appendTo($detailsForm);
				for (var i = 0; i < details.length; i++) {
					var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>"+details[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details[i].id+"'>"+details[i].data+"</div>").appendTo($data);
					if ( details[i].attributes ) {
						for ( var a = 0; a < details[i].attributes.length; a++ ) {
							$el.attr( details[i].attributes[a].name ,details[i].attributes[a].value );
						}
					}
				};
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "transactionDetails",
				title: "Transaction Details",
				size: "medium",
				icon: "<i class='fa fa-file-text'></i>",
				content: function(){return showTransactionDetails()},
				buttons: [
					{ name: "Close", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
					{ name: "Transaction Detail Report", icon: "<i class='fa fa-file-text fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}], cssClass: "primary" }
				]
			}
			dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
		}
	});
	cardActivityGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('cardActivityWidths', cardActivityGrid.getColumns());
	});
	$(cardActivityGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			cardActivityFilters[columnId] = $.trim($(this).val());
			$icon.show();
			cardActivityDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	cardActivityGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(cardActivityFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	cardActivityDataView.onRowCountChanged.subscribe(function(e,args) {
		cardActivityGrid.updateRowCount();
		cardActivityGrid.render();
	});
	cardActivityDataView.onRowsChanged.subscribe(function(e,args) {
		cardActivityGrid.invalidateRows(args.rows);
		cardActivityGrid.render();
		if (cardActivitySelectedRowIds.length > 0)
		{
			var activitySelRows = [];
			for (var i = 0; i < cardActivitySelectedRowIds.length; i++)
			{
				var idx = cardActivityDataView.getRowById(cardActivitySelectedRowIds[i]);
				if (idx != undefined)
					activitySelRows.push(idx);
			}
			cardActivityGrid.setSelectedRows(activitySelRows);
		}
	});
	cardActivityDataView.setItems(cardActivityData);
	cardActivityDataView.setFilterArgs({
		findActivityString: findActivityString
	});
	cardActivityDataView.syncGridSelection(cardActivityGrid, true, false);
	cardActivityDataView.syncGridCellCssStyles(cardActivityGrid, "contextMenu");
	cardActivityDataView.setFilter(myActivityFilter);
	cardActivityGrid.setColumns(cardActivityColumns);
	if ( store.get('cardActivityOrder') ) {
		var visiblecardActivityColumns = [];
		for (var i = 0; i < store.get('cardActivityOrder').length+1; i++) {
			if (cardActivityColumns[i].visible) {
				visiblecardActivityColumns.push(cardActivityColumns[i])
			}
		}
		cardActivityGrid.setColumns(visiblecardActivityColumns);
	}
	cardActivityGrid.setHeaderRowVisibility(false);


	/**********************************************************************
	INITIALIZE OUTSTANDING TRANSACTIONS GRID
	**********************************************************************/
	var outstandingGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	outstandingDataView = new Slick.Data.DataView({
		outstandingGroupItemMetadataProvider: outstandingGroupItemMetadataProvider
	});
	outstandingGrid = new Slick.Grid("#outstandingGrid", outstandingDataView, outstandingCols, outstandingOptions);
	outstandingGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	outstandingGrid.registerPlugin(outstandingGroupItemMetadataProvider);
	outstandingGrid.registerPlugin(outstandingCheckboxSelector);
	var outstandingColumnpicker = new Slick.Controls.ColumnPicker(outstandingCols, outstandingGrid, outstandingOptions, 'outstandingColumnOrder', 'outstandingColumnWidths', ["outstandingCheckboxSelector"]);
	outstandingGrid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();
		var cell = outstandingGrid.getCellFromEvent(e), row = cell.row, rows = outstandingGrid.getSelectedRows(), $cmenu = $("#outstandingContextMenu");
		if ($.inArray(row, rows) == -1) {
			outstandingGrid.setSelectedRows([row])
		}
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	outstandingGrid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		outstandingSelectedRowIds = [];
		var rows = outstandingGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = outstandingDataView.getItem(rows[i])
			if (item.id) outstandingSelectedRowIds.push(item.id)
		}
	});
	outstandingGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		outstandingDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	outstandingGrid.onClick.subscribe(function(e, args) {
		var acell = outstandingGrid.getCellFromEvent(e), arow = acell.row, $arow = $(e.target).closest(".slick-row");
		if( !$arow.is(".slick-group, .slick-group-totals") ) {
			e.preventDefault();
			outstandingGrid.setSelectedRows(0);
			outstandingSelectedRowIds = [];
			function showTransactionDetails() {
				function navigateTransactions() {}
				function voucherImages() {}
				function transactionHelp() {}
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
				$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
				$controls = $("<div class='control-list right' />").appendTo($navigationBar),
				$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
				$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
				$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
				details = [
					{name: "Account Name", id: "td2", type: "text", data: "AUD Operations"},
					{name: "Account Number", id: "td3", type: "text", data: "3341233212123123 (AUD)"},
					{name: "Card Number", id: "td1", type: "text", data: "47777xxxxxxxxxxxxxxxx767"},
					{name: "Transaction Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "10,300.00"},
					{name: "Billed Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "10,300.00"},
					{name: "Estimated GST Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "25.00"},
					{name: "Billed Currency", id: "td5", type: "text", data: "AUD"},
					{name: "Posting Date", id: "td6", type: "text", data: smartDates("yesterday")},
					{name: "Value Date", id: "td7", type: "text", data: smartDates("yesterday")},
					{name: "Merchant Category Code &amp; Name", id: "td9", type: "text", data: "DEBAO AUSTRALIA"},
					{name: "Merchant Group", id: "td10", type: "text", data: "DEBAO AUSTRALIA"},
					{name: "Narrative", id: "td11", type: "text", data: "DEBAO AUSTRALIA PL BRISBANE"}
				],
				$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
				$formSection = $("<div class='form-section' />").appendTo($detailsForm);
				for (var i = 0; i < details.length; i++) {
					var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>"+details[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details[i].id+"'>"+details[i].data+"</div>").appendTo($data);
					if ( details[i].attributes ) {
						for ( var a = 0; a < details[i].attributes.length; a++ ) {
							$el.attr( details[i].attributes[a].name ,details[i].attributes[a].value );
						}
					}
				};
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "transactionDetails",
				title: "Transaction Details",
				size: "medium",
				icon: "<i class='fa fa-file-text'></i>",
				content: function(){return showTransactionDetails()},
				buttons: [
					{ name: "Close", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
					{ name: "Transaction Detail Report", icon: "<i class='fa fa-file-text fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}], cssClass: "primary" }
				]
			}
			dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
		}
	});
	outstandingGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('outstandingColumnWidths', outstandingGrid.getColumns());
	});
	$(outstandingGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			outstandingFilters[columnId] = $.trim($(this).val());
			$icon.show();
			outstandingDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	outstandingGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(outstandingFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	outstandingDataView.onRowCountChanged.subscribe(function(e,args) {
		outstandingGrid.updateRowCount();
		outstandingGrid.render();
	});
	outstandingDataView.onRowsChanged.subscribe(function(e,args) {
		outstandingGrid.invalidateRows(args.rows);
		outstandingGrid.render();
		if (outstandingSelectedRowIds.length > 0)
		{
			var outstandingSelRows = [];
			for (var i = 0; i < outstandingSelectedRowIds.length; i++)
			{
				var idx = outstandingDataView.getRowById(outstandingSelectedRowIds[i]);
				if (idx != undefined)
					outstandingSelRows.push(idx);
			}
			outstandingGrid.setSelectedRows(outstandingSelRows);
		}
	});
	outstandingDataView.setItems(outstandingData);
	outstandingDataView.setFilterArgs({
		findOutstandingString: findOutstandingString
	});
	outstandingDataView.syncGridSelection(outstandingGrid, true, false);
	outstandingDataView.syncGridCellCssStyles(outstandingGrid, "contextMenu");
	outstandingDataView.setFilter(myOutstandingFilter);
	outstandingGrid.setColumns(outstandingCols);
	if ( store.get('outstandingColumnOrder') ) {
		var visibleOutstandingCols = [];
		for (var i = 0; i < store.get('outstandingColumnOrder').length+1; i++) {
			if (outstandingCols[i].visible) {
				visibleOutstandingCols.push(outstandingCols[i])
			}
		}
		outstandingGrid.setColumns(visibleOutstandingCols);
	}
	outstandingGrid.setHeaderRowVisibility(false);



	/**********************************************************************
	INITIALIZE DECLINED TRANSACTIONS GRID
	**********************************************************************/
	var declinedGroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	declinedDataView = new Slick.Data.DataView({
		declinedGroupItemMetadataProvider: declinedGroupItemMetadataProvider
	});
	declinedGrid = new Slick.Grid("#declinedGrid", declinedDataView, declinedCols, declinedOptions);
	declinedGrid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
	declinedGrid.registerPlugin(declinedGroupItemMetadataProvider);
	declinedGrid.registerPlugin(declinedCheckboxSelector);
	var declinedColumnpicker = new Slick.Controls.ColumnPicker(declinedCols, declinedGrid, declinedOptions, 'declinedColumnOrder', 'declinedColumnWidths', ["declinedCheckboxSelector"]);
	declinedGrid.onContextMenu.subscribe(function (e,args) {
		e.preventDefault();
		var cell = declinedGrid.getCellFromEvent(e), row = cell.row, rows = declinedGrid.getSelectedRows(), $cmenu = $("#declinedContextMenu");
		if ($.inArray(row, rows) == -1) {
			declinedGrid.setSelectedRows([row])
		}
		var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
		if(e.pageX + 210 > winwidth) {
			leftpos = e.pageX-205;
		}
		if(e.pageY + cheight > winheight) {
			toppos = e.pageY-cheight;
			if(toppos < 0) {
				toppos = e.pageY - (cheight-(winheight-e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if(e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	declinedGrid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		declinedSelectedRowIds = [];
		var rows = declinedGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = declinedDataView.getItem(rows[i])
			if (item.id) declinedSelectedRowIds.push(item.id)
		}
	});
	declinedGrid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		declinedDataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	declinedGrid.onClick.subscribe(function(e, args) {
		var acell = declinedGrid.getCellFromEvent(e), arow = acell.row, $arow = $(e.target).closest(".slick-row");
		if( !$arow.is(".slick-group, .slick-group-totals") ) {
			e.preventDefault();
			declinedGrid.setSelectedRows(0);
			declinedSelectedRowIds = [];
			function showTransactionDetails() {
				function navigateTransactions() {}
				function voucherImages() {}
				function transactionHelp() {}
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
				$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
				$controls = $("<div class='control-list right' />").appendTo($navigationBar),
				$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
				$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
				$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
				details = [
					{name: "Account Name", id: "td2", type: "text", data: "AUD Operations"},
					{name: "Account Number", id: "td3", type: "text", data: "3341233212123123 (AUD)"},
					{name: "Card Number", id: "td1", type: "text", data: "47777xxxxxxxxxxxxxxxx767"},
					{name: "Transaction Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "10,300.00"},
					{name: "Billed Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "10,300.00"},
					{name: "Estimated GST Amount", id: "td8", type: "text", attributes: [{name:"class", value:"data-text neg"}], data: "25.00"},
					{name: "Billed Currency", id: "td5", type: "text", data: "AUD"},
					{name: "Posting Date", id: "td6", type: "text", data: smartDates("yesterday")},
					{name: "Value Date", id: "td7", type: "text", data: smartDates("yesterday")},
					{name: "Merchant Category Code &amp; Name", id: "td9", type: "text", data: "DEBAO AUSTRALIA"},
					{name: "Merchant Group", id: "td10", type: "text", data: "DEBAO AUSTRALIA"},
					{name: "Narrative", id: "td11", type: "text", data: "DEBAO AUSTRALIA PL BRISBANE"}
				],
				$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
				$formSection = $("<div class='form-section' />").appendTo($detailsForm);
				for (var i = 0; i < details.length; i++) {
					var $row = $("<div class='row' />").appendTo($formSection),
					$label = $("<div class='label-column'><label>"+details[i].name+"</label></div>)").appendTo($row),
					$data = $("<div class='data-column' />").appendTo($row),
					$el = $("<div class='data-text' id='"+details[i].id+"'>"+details[i].data+"</div>").appendTo($data);
					if ( details[i].attributes ) {
						for ( var a = 0; a < details[i].attributes.length; a++ ) {
							$el.attr( details[i].attributes[a].name ,details[i].attributes[a].value );
						}
					}
				};
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "transactionDetails",
				title: "Transaction Details",
				size: "medium",
				icon: "<i class='fa fa-file-text'></i>",
				content: function(){return showTransactionDetails()},
				buttons: [
					{ name: "Close", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
					{ name: "Transaction Detail Report", icon: "<i class='fa fa-file-text fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}], cssClass: "primary" }
				]
			}
			dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
		}
	});
	declinedGrid.onColumnsResized.subscribe(function(e, args) {
		store.set('declinedColumnWidths', declinedGrid.getColumns());
	});
	$(declinedGrid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			declinedFilters[columnId] = $.trim($(this).val());
			$icon.show();
			declinedDataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	declinedGrid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(declinedFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	declinedDataView.onRowCountChanged.subscribe(function(e,args) {
		declinedGrid.updateRowCount();
		declinedGrid.render();
	});
	declinedDataView.onRowsChanged.subscribe(function(e,args) {
		declinedGrid.invalidateRows(args.rows);
		declinedGrid.render();
		if (declinedSelectedRowIds.length > 0)
		{
			var declinedSelRows = [];
			for (var i = 0; i < declinedSelectedRowIds.length; i++)
			{
				var idx = declinedDataView.getRowById(declinedSelectedRowIds[i]);
				if (idx != undefined)
					declinedSelRows.push(idx);
			}
			declinedGrid.setSelectedRows(declinedSelRows);
		}
	});
	declinedDataView.setItems(declinedData);
	declinedDataView.setFilterArgs({
		findDeclinedString: findDeclinedString
	});
	declinedDataView.syncGridSelection(declinedGrid, true, false);
	declinedDataView.syncGridCellCssStyles(declinedGrid, "contextMenu");
	declinedDataView.setFilter(myDeclinedFilter);
	declinedGrid.setColumns(declinedCols);
	if ( store.get('declinedColumnOrder') ) {
		var visibleDeclinedCols = [];
		for (var i = 0; i < store.get('declinedColumnOrder').length+1; i++) {
			if (declinedCols[i].visible) {
				visibleDeclinedCols.push(declinedCols[i])
			}
		}
		declinedGrid.setColumns(visibleDeclinedCols);
	}
	declinedGrid.setHeaderRowVisibility(false);


	/**********************************************************************
	CALCULATE GRAND TOTALS
	**********************************************************************/
	calculateTotals()


	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
		cardSummaryGrid.resizeCanvas();
		balancehistorygrid.resizeCanvas();
		cardActivityGrid.resizeCanvas();
		outstandingGrid.resizeCanvas();
		declinedGrid.resizeCanvas();
	});

	/**********************************************************************
	FOLDER VIEW INTERACTIONS
	**********************************************************************/
	$("#_allAccounts").on("click", function(e) {
		e.preventDefault();
		var _folder = "";
		if ( labelString != _folder ) {
			labelString = _folder;
		}
		folderFilter();
		$("#selectedFolder").html("All Cards")
	});
	$(".manage-folders").on("click", showFolderManagerDialog);
	$("#_inlineFolderButton").on("click", addFolderInline);
	$("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
		if (e.keyCode == 13) {
			addFolderInline();
		}
	});
	populateFolders();


	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		groupBy(item,text);
	});
	$("body").on("click.cardsummarygroup-by", "#groupCardSummaryMenu [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		cardSummaryGroupBy(item,text);
	});
	$("body").on("click.trxngroup-by", "#trxnGroupBy [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		trxngroupBy(item,text);
	});
	$("body").on("click.outstandinggroup-by", "#outstandingGroupBy [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		outstandingGroupBy(item,text);
	});
	$("body").on("click.declinedgroup-by", "#declinedGroupBy [data-action='group']", function(e) {
		e.preventDefault();
		var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
		declinedGroupBy(item,text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if( groupCollapseSetting == 0 ) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});


	/**********************************************************************
	CURRENCY INTERACTION
	**********************************************************************/
	function returnRate(a,b) {
		var rate;
			if (a == "AUD") {if (b == "AUD") {rate = 1.0000} else if (b == "SGD") {rate = 0.8222}
			} else if (a == "CNY") {if (b == "AUD") {rate = 5.9200} else if (b == "SGD") {rate = 4.8400}
			} else if (a == "EUR") {if (b == "AUD") {rate = 0.7502} else if (b == "SGD") {rate = 0.6100}
			} else if (a == "HKD") {if (b == "AUD") {rate = 7.4910} else if (b == "SGD") {rate = 6.1230}
			} else if (a == "IDR") {if (b == "AUD") {rate = 9426.0710} else if (b == "SGD") {rate = 7708.4500}
			} else if (a == "INR") {if (b == "AUD") {rate = 53.8600} else if (b == "SGD") {rate = 43.8700}
			} else if (a == "KRW") {if (b == "AUD") {rate = 1081.8300} else if (b == "SGD") {rate = 886.1722}
			} else if (a == "KHR") {if (b == "AUD") {rate = 3852.6700} else if (b == "SGD") {rate = 3164.1900}
			} else if (a == "MYR") {if (b == "AUD") {rate = 2.9201} else if (b == "SGD") {rate = 2.3902}
			} else if (a == "NZD") {if (b == "AUD") {rate = 1.2000} else if (b == "SGD") {rate = 0.9800}
			} else if (a == "SGD") {if (b == "AUD") {rate = 1.2222} else if (b == "SGD") {rate = 1.0000}
			} else if (a == "THB") {if (b == "AUD") {rate = 28.9100} else if (b == "SGD") {rate = 23.7100}
			} else if (a == "USD") {if (b == "AUD") {rate = 0.9600} else if (b == "SGD") {rate = 0.7900}
			} else if (a == "VND") {if (b == "AUD") {rate = 20208.5600} else if (b == "SGD") {rate = 16565.4300}
			};
		return(rate)
	}
	$("#ccyMenu").on("click.set-ccy", "a", function(e) {
		e.preventDefault();
		groupCCYSetting = $(this).attr("data-value");
		for (var i = 0; i < data.length; i++) {
			data[i].fxrate = returnRate(groupCCYSetting, data[i].currency).toFixed(4);
		}
		dataView.setItems(data)
		filterCards();
		$("span[data-object='reference-ccy']").empty().html(groupCCYSetting);
		$("#_totalsRow [data-value='totalccy']").html(groupCCYSetting);
	});

	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		}
	});
	$("#activityReportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = cardActivityGrid.getSelectedRows().length;
		var menuLink = $("#activityReportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestTransactionDetailsNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestTransactionDetails"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestTransactionDetails"
			});
		}
	});
	$("#outStandingReportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = outstandingGrid.getSelectedRows().length;
		var menuLink = $("#outStandingReportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestTransactionDetailsNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestTransactionDetails"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestTransactionDetails"
			});
		}
	});
	$("#declinedReportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = declinedGrid.getSelectedRows().length;
		var menuLink = $("#declinedReportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestTransactionDetailsNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestTransactionDetails"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestTransactionDetails"
			});
		}
	});

	/**********************************************************************
	ACTION MENU INTERACTION
	**********************************************************************/
	$("#actionMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength =  grid.getSelectedRows().length;
		var menuLink = $("#actionMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({"href":"#actionMenuNoSelected"});
		} else if (rowsLength == 1) {
			menuLink.attr({"href":"#actionMenu"});
		} else if (rowsLength > 1) {
			menuLink.attr({"href":"#actionMenuMultiSelected"});
		}
	});
	$("#cardSummaryActionMenuControl").on("click.show-actionMenu", function(e){
		var rowsLength =  cardSummaryGrid.getSelectedRows().length;
		var menuLink = $("#cardSummaryActionMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({"href":"#cardSummaryActionMenuNoSelected"});
		} else if (rowsLength == 1) {
			menuLink.attr({"href":"#cardSummaryActionMenu"});
		} else if (rowsLength > 1) {
			menuLink.attr({"href":"#cardSummaryActionMenuMultiSelected"});
		}
	});
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout( function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);
	$("#toggleCardSummaryFilter").on("click", toggleCardSummaryFilterRow);
	$("#toggleCardActivityFilter").on("click", toggleCardActivityFilterRow);
	$("#toggleOutstandingFilter").on("click", toggleOustandingFilterRow);
	$("#toggleDeclinedFilter").on("click", toggleDeclinedFilterRow);


	/**********************************************************************
	ENTITY TOGGLE
	**********************************************************************/
	$("a[data-toggle='entity'").on("click", function(e){
		e.preventDefault();
		var $this = $(this),
			$icon = $this.find("i");
			$parent = $this.parent("span.btn"),
			$sibling = ($parent.next().length > 0) ? $parent.next("span.btn") : $parent.prev("span.btn"),
			$siblingIcon = $sibling.find("i");
		if ( $sibling.hasClass("btn-on") ) {
			$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
			$parent.addClass("btn-on");
			$icon.removeClass("fa-square-o").addClass("fa-check-square-o");
			$sibling.removeClass("btn-on");
			$siblingIcon.removeClass("fa-check-square-o").addClass("fa-square-o");
		}
	});



	/**********************************************************************
	BALANCE HISTORY LINK TO ACCOUNT ACTIVITY
	**********************************************************************/
	$("#viewActivityFromBalanceDate").on("click", function(e){
		e.preventDefault();
		balancehistorygrid.setSelectedRows([]);
		$('#accountActivityTab').trigger('click');
	});

	/**********************************************************************
	ACCOUNT ACTIVITY / BALANCE HISTORY DATE FILTERS
	**********************************************************************/
	$("#_trxnspecificDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#trxnDate").find("li.active").removeClass("active");
			$("#trxnSpecDateItem").closest("li").addClass("active");
			$("div.control-list").find("a[href='#trxnDate']").children("span.item-text").text(dateText);
			$("#activityDate").html(dateText);
			$("div.control-list").find("a[href='#trxnDate']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
			$('#accountActivityTab').trigger('click');
			updateBreadcrumb("view");
	}}).click(function(e) {e.stopPropagation();});

	var trxnDateRangeSelection = $("#_trxnrangeDateFrom, #_trxnrangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_trxnrangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				trxnDateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {e.stopPropagation();});

	$("#_trxnDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_trxnrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_trxnrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#trxnDate").find("li.active").removeClass("active");
		$("#trxnRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#accountActivityTab').trigger('click');
		updateBreadcrumb("view");
		$("div.control-list").find("a[href='#trxnDate']").children("span.item-text").text(fromDate+" - "+toDate);
		$("#activityDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#trxnDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});

	$("#trxnDate ul li a").on("click", function(e){
		var $target = $(e.target), _selection = $target.html();
		var $scrollArea = $("#cardActivityGrid").parent("div.scroll-area"), $tabPanel = $scrollArea.parent("div.application-tab-panel");
		var $bottomMessage = $("<div class='bottom-controls'><div class='control-list'><div class='control-text'><div style='color: #fff; font-size: 14px; line-height: 60px; white-space: normal; padding: 0 20px;'>Today's transactions include all authorised but unposted transactions.</div></div></div></div>");
		if ( _selection == "Today" ) {
			$scrollArea.addClass("has-bottom-controls");
			$bottomMessage.appendTo($tabPanel);
		} else {
			$scrollArea.removeClass("has-bottom-controls");
			$scrollArea.next("div.bottom-controls").remove();
		}
		cardActivityGrid.resizeCanvas();
	});

	$("#_balspecificDate").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		onSelect: function(dateText) {
			$("#balDate").find("li.active").removeClass("active");
			$("#balSpecDateItem").closest("li").addClass("active");
			$("div.control-list").find("a[href='#balDate']").children("span.item-text").text(dateText);
			$("#balanceHistoryDate").html(dateText);
			$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
			$("div.control-menus div.control-menu").hide();
			$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
			$('#balanceHistoryTab').trigger('click');
			updateBreadcrumb("view");
	}}).click(function(e) {e.stopPropagation();});

	var balDateRangeSelection = $("#_balrangeDateFrom, #_balrangeDateTo").datepicker({
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function( selectedDate ) {
			var option = this.id == "_balrangeDateFrom" ? "minDate" : "maxDate",
				instance = $( this ).data( "datepicker" ),
				date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings );
				balDateRangeSelection.not(this).datepicker("option", option, date);
		}
	}).click(function(e) {e.stopPropagation();});

	$("#_balDateRangeBtn").on("click", function(e) {
		var fromDate = $('#_balrangeDateFrom').datepicker('getDate'); fromDate = $.datepicker.formatDate('dd/mm/yy', fromDate);
		var toDate = $('#_balrangeDateTo').datepicker('getDate'); toDate = $.datepicker.formatDate('dd/mm/yy', toDate);
		$("#balDate").find("li.active").removeClass("active");
		$("#balRangeDateItem").closest("li").addClass("active");
		$(this).attr({"data-panel": "#accountDetail", "data-switch" : "switch-panels"}).trigger("click.switch-panels").removeAttr("data-panel data-switch");
		$('#balanceHistoryTab').trigger('click');
		updateBreadcrumb("view");
		$("div.control-list").find("a[href='#balDate']").children("span.item-text").text(fromDate+" - "+toDate);
		$("#balanceHistoryDate").html(fromDate+" - "+toDate);
		$("div.control-list").find("a[href='#balDate']").parent(".btn").removeClass("on");
		$("div.control-menus div.control-menu").hide();
	});

	/**********************************************************************
	REQUEST REPORT MODALS
	**********************************************************************/
	$(".request-statement").on("click", showAccountStatementModal);
	$(".request-balances").on("click", showBalanceHistoryModal);

	/**********************************************************************
	CREATE NEW SERVICE REQUEST
	**********************************************************************/
	$(".new-service-request").on("click", createServiceRequestWarning);


	/**********************************************************************
	CLOSE DETAIL VIEW
	**********************************************************************/
	$("#closeDetailView").on("click", function(e){
		updateBreadcrumb("close");
	});
	

	/**********************************************************************
	JUMP TO ACCOUNT DETAILS
	**********************************************************************/
	var b=document.location.href.split(".html")[1];
	if (b == "#detail") {
		$("#summaryGrid").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		$('#cardSummaryTab').trigger('click');
		document.location.hash = '';
	}


});