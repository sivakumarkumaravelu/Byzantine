function clearErrors() {
	if ($(this).val() != '' && $(this).closest("div.row").hasClass("error")) {
		$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
	}
}
function checkFormat() {
	var _gcp = ($(this).val() == "GCP Delimited") ? true : false;
	if (_gcp) {
		$("#debitIndicatorRow, #purposeRow").show();
	} else {
		$("#debitIndicatorRow, #purposeRow").hide();
	}
}
function cancelUpload() {
	$("#fileSection").hide();
	$("#uploadFileInput").val('');
	$("#uploadButton, #startUpload").removeClass("disabled");
	$(".progress-meter").stop(true, true).css({
		width: 0
	});
	clearAllErrors();
}
function showFileUploadSection() {


	$("#uploadMessage").hide();
	$("#fileSection, #fileUploadActions").show();
	$(".progress-meter").stop(true, true).css({
		width: 0
	});

	var str = $('#uploadFileInput').val();
	var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);
	$("#filenamevalue").html(filename);

	var file = $("#uploadFileInput")[0].files[0];

	

	if (window.ActiveXObject) {
		var myFSO = new ActiveXObject("Scripting.FileSystemObject");
		var filepath = document.getElementById('uploadFileInput').value;
		var thefile = myFSO.getFile(filepath);
		var size = thefile.size;
	} else {
		var size = file.size;
	}

	var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
	fSize = size;
	i = 0;
	while (fSize > 900) {
		fSize /= 1024;
		i++;
	}
	$("#filesize").html("(" + (Math.round(fSize * 100) / 100) + ' ' + fSExt[i] + ")");
}
function checkUploadSettings() {
	var _passed = true,
		_division = $("#divisionField").val(),
		
		_encoding = $("#encodingField").val(),
		_indicator = $("#debitIndicatorField").val(),
		_purpose = $("#purposeField").val();

	if (!_division) {
		_passed = false;
		$("#divisionField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>Division is required</div>");
			}
		});
	}
	
	if (!_encoding) {
		_passed = false;
		$("#encodingField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>File Encoding is required</div>");
			}
		});
	}

	

	if (_passed) {
		$("#fileUploadSection").closest("div.row").removeClass("error").find("div.data-error").remove();
		$("#uploadButton, #startUpload").addClass("disabled");
		$(".progress-meter").animate({
			width: "100%"
		}, 3000, function() {
			$("#uploadButton, #startUpload").removeClass("disabled");
			$("#fileUploadActions").hide();
			$("#uploadMessage").show();
			$("#uploadFileInput").val('');
		});
	} else {
		$("#fileUploadSection").closest("div.row").addClass("error").find("div.data-column").append($("<div class='data-error'>File does not match selection criteria</div>"));
	}
}
function populateFileUploadDialog() {
	var $dialogContent = $("<div class='py-ui' style='padding: 10px;' id='fileUploadForm' />");
	var $div = $("<div class=' top-label' />").appendTo($dialogContent);

	var $gridrow = $("<div class='grid-row' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell'  />").appendTo($gridrow);

	var $row =  $("<div class='row'  />").appendTo($gridcell);

	 $(' <span id="one" class = "form-button  nohover" ><i class="fa fa-check-circle fa-lg"></i>&nbsp;&nbsp;<span>Duplicate Filename & File Properties Check Pending</span></span>').appendTo($row);



	 var $row =  $("<div class='row'  />").appendTo($gridcell);

	 $("<div class='verticalline' />").appendTo($row);

	 $(' <span id="two" class = "form-button  nohover" ><i class="fa fa-check-circle fa-lg"></i>&nbsp;&nbsp;<span>Virus Scan Check Pending</span></span>').appendTo($row);

	  var $row =  $("<div class='row'  />").appendTo($gridcell);
	 
	 $("<div class='verticalline' />").appendTo($row);
	 $(' <span id="three" class = "form-button  nohover"><i class="fa fa-check-circle fa-lg"></i>&nbsp;&nbsp;<span>File Format Check Pending</span></span>').appendTo($row);

	  var $row =  $("<div class='row'  />").appendTo($gridcell);
	 
	 $("<div class='verticalline' />").appendTo($row);
	 $(' <span id="four" class = "form-button  nohover" ><i class="fa fa-check-circle fa-lg"></i>&nbsp;&nbsp;<span>Data Validation Check Pending</span></span>').appendTo($row);

	
	return $dialogContent;
}
function continueSteps(_dialog){
	$("#one i").removeClass("fa-check-circle");
	$("#one i").addClass("fa-spinner fa-spin");
	$("#one span").html("Duplicate Filename & File Properties Check in Progress");
	setTimeout(function(){ continueSteps1(_dialog); }, 3000)
}
function continueSteps1(_dialog){
	$("#one i").removeClass("fa-spinner fa-spin");
	$("#one i").addClass("fa-check-circle");
	$("#one i").css("color","green");
	$("#one span").html("Duplicate Filename & File Properties Check Completed");
	$("#one").css("background", "#FFF");

	$("#two i").removeClass("fa-check-circle");
	$("#two i").addClass("fa-spinner fa-spin");
	$("#two span").html("Virus Scan Check in Progress");
	setTimeout(function(){ continueSteps2(_dialog); }, 3000)
}
function continueSteps2(_dialog){
	$("#two i").removeClass("fa-spinner fa-spin");
	$("#two i").addClass("fa-check-circle");
	$("#two i").css("color","green");
	$("#two span").html("Virus Scan Check Completed");
	$("#two").css("background", "#FFF");

	$("#three i").removeClass("fa-check-circle");
	$("#three i").addClass("fa-spinner fa-spin");
	$("#three span").html("File Format Check in Progress");
	setTimeout(function(){ continueSteps3(_dialog); }, 3000)
}
function continueSteps3(_dialog){
	$("#three i").removeClass("fa-spinner fa-spin");
	$("#three i").addClass("fa-check-circle");
	$("#three i").css("color","green");
	$("#three span").html("File Format Check Completed");
	$("#three").css("background", "#FFF");

	$("#four i").removeClass("fa-check-circle");
	$("#four i").addClass("fa-spinner fa-spin");
	$("#four span").html("Data Validation Check in Progress");
	setTimeout(function(){  $("#four i").removeClass("fa-spinner fa-spin");
	$("#four i").addClass("fa-check-circle");
	$("#four i").css("color","green");
	$("#four span").html("Data Validation Check Completed"); 
	$("#four").css("background", "#FFF");
	dialogHider(_dialog);

	$( ".py-initiation-steps >ul li:nth-child(1) i" ).removeClass("fa-circle");
	$( ".py-initiation-steps >ul li:nth-child(1) i" ).addClass("fa-check-circle");
	$( ".py-initiation-steps >ul li:nth-child(1) span" ).text("");

	$( ".py-initiation-steps >ul li:nth-child(2)").addClass("active");

	$( "#first").css("display","none");
	$( "#firstbottom").css("display","none");

	$( "#second").css("display","block");
	$( "#secondbottom").css("display","block");

	  }, 3000)
}
function triggerUploadDialog(e) { 
	e.preventDefault();
	if($("#myfile").val() ==""){
		$('#attachment').addClass("error");
		$('#showmsg').css("display","block");
		return;
	}
	else if($("#myfile").val().indexOf(".xls") <0){
		$('#attachment').addClass("error");
		$('#showmsg1').css("display","block");
		return;
	}
	
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "uploadFile",
		title: "Your Request is being processed",
		size: "small",
		icon: "<i class='fa fa-upload'></i>",
		content: function() {
			return populateFileUploadDialog()
		}/*,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]*/
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	setTimeout(function(){ continueSteps(_dialog); } , 1000);
}
function performClick(elemId) {
	elemId = 'myfile';
	 if($("#myfile").val() !=""){ 
   		$('.uploadfile').on("click", function(e){e.preventDefault();});

   		return;
   }
   var elem = document.getElementById(elemId); 
   if(elem && document.createEvent) { 
      var evt = document.createEvent("MouseEvents");
      evt.initEvent("click", true, false);
      elem.dispatchEvent(evt);
   }	
}
function removefile(){
	$("#myfile").val(""); 
	$("#filename").parent().css("display","none");
     $("#filename").html("");
     setTimeout( function(){ $('.uploadfile').css("cursor","pointer"); },100);
}

$(function() {

	$("#myfile").on("change", function(){ 
		if($("#myfile").val() !=""){ 
		 $("#filename").parent().css("display","block");
	     $("#filename").html($("#myfile").val()+'&nbsp;&nbsp;&nbsp;<a href="#" class="removefile" title="Remove">remove</a>');
	     $('.uploadfile').css("cursor","not-allowed"); 

	     $('#attachment').removeClass("error");
	     $('#showmsg').css("display","none");
	       $('#showmsg1').css("display","none");
	     $("a[class='removefile']").on("click", removefile);
	    }
	});

	/* file upload */
	$("a[class='uploadfile']").on("click", performClick);
	$("a[class='removefile']").on("click", removefile);
	$("a[id='uploadnow']").on("click", triggerUploadDialog);

	var b = document.location.href.split(".html")[1];
	var $breadcrumb = $(".application-breadcrumb");
	var $navLink = $("ul[data-map='payments']");
	if (b == "#files") {
		var $b2 = $("<span data-ref='b2'><a href='payments-files.html'>Payments</a></span>").appendTo($breadcrumb);
		var	$b3 = $("<span data-ref='b3'><a href='payments-files.html'>File Import List</a></span>").appendTo($breadcrumb);
		var	$b4 = $("<span data-ref='b4'>Upload Beneficiaries</span>").appendTo($breadcrumb);
		$navLink.find("a[href='payments-files.html']").parent("li").addClass("on");
		$("#backButton").on("click", function() {
			document.location.href = "payments-files.html";
		})
	} else if (b == "#benes") {
		var $b2 = $("<span data-ref='b2'><a href='payments-beneficiaries.html'>Payments</a></span>").appendTo($breadcrumb);
		var	$b3 = $("<span data-ref='b3'><a href='payments-beneficiaries.html'>Payee List</a></span>").appendTo($breadcrumb);
		var	$b4 = $("<span data-ref='b4'>Upload Beneficiaries</span>").appendTo($breadcrumb);
		$navLink.find("a[href='payments-beneficiaries.html']").parent("li").addClass("on");
		$("#backButton").on("click", function() {
			document.location.href = "payments-beneficiaries.html";
		})
	}

});



	