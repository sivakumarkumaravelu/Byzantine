/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Payments Onscreen Guide",
	action: "slider"
}, {
	title: "What is the maximum payment file size that I can imp",
	faq: "<p>A payment file of up to 5MB will be accepted.</p>"
}, {
	title: "What is the difference between ISO XML and Fixed Length file formats?",
	faq: "<p>An ISO XML file contains the data in a hierarchical structure with a tag surrounding each data element. The Fixed Length format is where each data element is oriented by a fixed position within the file.</p>"
}, {
	title: "How long do payment files stay in the Payment File Summary screen?",
	faq: "<p>Payment files will be purged from the system after 31 days.</p>"
}, {
	title: "What does the Control Amount column refer to?",
	faq: "<p>The total of all amounts in the file, across all payments, without decimal points.</p>"
}, {
	title: "What does it mean when my file says there are transactions needing repair?",
	faq: "<p>If your file has uploaded successfully but says there are transactions that need repair, click on the file and select View Current Payments. Click on the payment in a Needs Repair status to view the payment details and associated error messages.</p>"
}, {
	title: "Why does the system create multiple payments when I upload a single file?",
	faq: "<p>If your file contains a mix of currencies and international and domestic payments, the system will automatically split your file into the necessary payments to allow them to be submitted for approval.</p>"
}];