var helpNavigation = function(a) {
	return {
		init: function() {
			var b=document.location.href.split(".html")[1],
			d=(document.location.href.split(".html")[0]).split("/"),
			c=d[d.length-1]+".html"+b,
			a = $(".help-menu-sections").find("a[href='"+c+"']"),
			ul = a.closest("ul");
			$(".help-menu-sections").find("li.active").removeClass("active");
			a.parent("li").addClass("active");
			ul.parent("li").addClass("open");
			if (ul.hasClass("help-section-two")) {
				ul.parent("li").children("a.help-lvl1").children("i").addClass("fa-minus-square");
			}
			if (ul.hasClass("help-section-three")) {
				ul.siblings("span.help-expand-lvl").children("i").addClass("fa-angle-down");
				ul.parents("ul").closest("li").addClass("open").children("a.help-lvl1").children("i").addClass("fa-minus-square");
			}
			if (a.hasClass("help-lvl2")) {
				a.parent("li").addClass("open");
				a.siblings("span.help-expand-lvl").children("i").addClass("fa-angle-down");
			}
		},
		lvl1LinkClickHandler: function(b) {
			b.parent("li").toggleClass("open");
			b.children("i").toggleClass("fa-minus-square");
		},
		lvl2LinkClickHanlder: function(b) {
			if (!b.parent("li").hasClass("open")) {
				b.parent("li").addClass("open");
				b.prev("span.help-expand-lvl").children("i").addClass("fa-angle-down");
			}
		},
		toggleNavClickHandler: function(b) {
			b.parent("li").toggleClass("open");
			b.children("i").toggleClass("fa-angle-down");
		}
	}
}(jQuery);

$(function() {

	helpNavigation.init();

	$("a.help-lvl1").on("click", function(a) {
		helpNavigation.lvl1LinkClickHandler($(this));
	});

	$("a.help-lvl2").on("click", function(a) {
		helpNavigation.lvl2LinkClickHanlder($(this));
	});

	$(".help-expand-lvl").on("click", function(a) {
		helpNavigation.toggleNavClickHandler($(this));
	});

});

window.onhashchange = function() {
	helpNavigation.init();
};