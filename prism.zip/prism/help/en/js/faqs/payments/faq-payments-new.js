/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Payments Onscreen Guide",
	action: "slider"
}, {
	title: "How do I transfer funds between my accounts?",
	faq: "<p>To transfer funds between your registered ANZ accounts, click on <b>Payments</b> &gt; <b>Create Payment</b> and then select <b>Account Transfer</b>.</p>"
}, {
	title: "What is the difference between a Domestic/International Payment and a Domestic/International Salary Payment?",
	faq: "<p>The differences between a Domestic/International Payment and a Domestic/International Salary Payment are:<br />&gt; Access to salary payments is entitlements based which enables your organisation to ensure that confidential information is only visible to appropriate users<br /> &gt; A salary payment must use the bulk debit option, i.e. it cannot have individual debits for each payment instruction.</p>"
}, {
	title: "What is the difference between a template and a payment?",
	faq: "<p>Templates help to reduce the time you spend creating payments. A template holds pre-defined payment information that can be re-used so that you don’t need to enter the details each time you create a payment.</p><p>A payment is the actual instruction to pay one or more beneficiary accounts.</p>"
}, {
	title: "What happens if I choose Individual Debits for a payment?",
	faq: "<p>When you select individual debits, each instruction in the payment will appear as a line item on your statement.</p>"
}, {
	title: "Can I have individual debits if I use the Salary payment types?",
	faq: "<p>No. Payments created using the salary payment type cannot have individual debits.</p>"
}, {
	title: "Do beneficiaries need to be in the address book when creating a payment?",
	faq: "<p>No, but you need to have access to create ad-hoc beneficiaries. Users without this permission will be required to choose a beneficiary from the Address Book.</p>"
}, {
	title: "How does the Urgent flag work?",
	faq: "<p>The Urgent flag will send the payment via the fastest available clearing method available. The system will determine this based on; the value of the payment, the beneficiary bank information and any regulatory rules.</p>"
}, {
	title: "What is the maximum value that can be sent in a payment?",
	faq: "<p>&gt; In most cases, each payment instruction can be up to 99999999999.99 in the selected currency<br />&gt; For BEPS transfer payments, the maximum payment currency value is 50,000 CNY</p>"
}, {
	title: "What is the maximum number of days I can future date a payment?",
	faq: "<p>You can future date a payment up to 20 business days.</p>"
}, {
	title: "Why can’t I submit my payment?",
	faq: "<p>There are a number of reasons why you may not be able to submit your payment, these include:<br/>&gt; The payment contains an ad-hoc beneficiary (i.e. a beneficiary that does not exist in your address book) and you do not have permission to use ad-hoc beneficiaries<br />&gt; The payment is past the cut-off - you will need to change the value date<br />&gt; The payment contains errors - check the status of each instruction within the payment to find the error</p>"
}, {
	title: "How many Foreign Exchange (FX) contracts can I add to a cross currency payment?",
	faq: "<p>Up to 5 FX contracts can be added to a payment unless a carded rate is also required to fund part of the payment. In this case, only 4 FX contracts can be used.</p>"
}];