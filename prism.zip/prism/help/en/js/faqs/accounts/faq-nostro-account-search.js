/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Accounts Onscreen Guide",
	action: "slider"
}, {
	title: "How do I save a search?",
	faq: "<p>Enter your search criteria in the required fields &gt; Click the Save icon &gt; Enter a Name for the Search &gt; Click Save.</p><p>Saved searches will appear in your Saved Searches folder menu.</p>"
}, {
	title: "How do I request Transaction Details?",
	faq: "<p>Click on any transaction in the search result list to view the Transaction Details in a pop up window. To download the details in a report;<br />Click the Transaction Details Report button &gt; Complete the required fields &gt; Click Submit to generate the report.</p><p>The report will be available in the Download screen to view or save.</p>"
}];