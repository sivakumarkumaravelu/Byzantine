function renderSliderDialog(e) {
    e.preventDefault();
	function renderImage() {
		var $dialogContent = $("<div style='display: none;' class='center slider' />");
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>Report Centre gives you one place for creating and managing your reporting needs.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>Here you have the option to create <span class='c007dba'>Report Profiles</span> and <span class='c007dba'>Scheduled Reports</span>, as well as <span class='c007dba'>Download Reports</span>.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/reporting/slide01.png' style='border: 0;' />").appendTo($guideImage);
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><span class='c007dba'>Report Profiles</span> allows you to create and manage different report types based on <span class='c007dba'>your information needs</span>.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>These reports can be run on an <span class='c007dba'>ad-hoc basis, scheduled at a particular time</span> or <span class='c007dba'>saved for future use</span>. You can also <span class='c007dba'>share</span> them with other users in your organisation.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/reporting/slide02.png' style='border: 0;' />").appendTo($guideImage);
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'>Four default report profiles are available:</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph' style='padding: 0;'><ul><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Daily Account Statement</li><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Monthly Account Statement</li><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Daily Account Summary</li><li style='font-size: 14px; font-weight: 600; background: #eee; padding: 8px 10px; margin-bottom: 2px;'><i class='fa fa-check fa-fw' style='color: #009900;'></i> Monthly Balance Summary</li></ul></div>").appendTo($guideContent);		
		var $guideParagraph = $("<div class='guide-paragraph'>Daily reports show yesterday’s data and monthly reports show last month’s data.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/reporting/slide03.png' style='border: 0;' />").appendTo($guideImage);
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><span class='c007dba'>Scheduled Reports</span> allows you to create and manage reports that you would like to <span class='c007dba'>run at regular intervals</span>.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>It also offers you the convenience of setting up reports to <span class='c007dba'>be automatically emailed to you</span>. These reports are protected by a retrieval code.</div>").appendTo($guideContent);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/reporting/slide04.png' style='border: 0;' />").appendTo($guideImage);
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><span class='c007dba'>Download Reports</span> displays all of the reports you have generated on <span class='c007dba'>ad-hoc basis or from a report schedule</span>.</div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>A <span class='c007dba'>range of download formats</span> are available including CSV, PDF or XLSX, allowing you to use the data in your own systems. You can also easily delete any unrequired reports.</div>").appendTo($guideContent);		
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/reporting/slide05.png' style='border: 0;' />").appendTo($guideImage);
		var $slideDiv = $("<div />").appendTo($dialogContent);
		var $guideDiv = $("<div class='guide-container' />").appendTo($slideDiv);
		var $guideImage = $("<div class='guide-image' />").appendTo($guideDiv);
		var $image = $("<img src='help/en/img/slides/reporting/slide06.png' style='border: 0;' />").appendTo($guideImage);
		var $guideContent = $("<div class='guide-content' />").appendTo($guideDiv);
		var $guideParagraph = $("<div class='guide-paragraph'><strong>Need more information?</strong></div>").appendTo($guideContent);
		var $guideParagraph = $("<div class='guide-paragraph'>View <span class='c007dba'>Online Help</span> within ANZ Transactive – Global or visit our <span class='c007dba'>Online Resources</span> site to access a range of detailed guidance.</div>").appendTo($guideContent);
		setTimeout(function() { 
			$('.dialog-container').removeClass('working').on("click", function(e){
				e.stopPropagation();
			});
			$('.slider').show(); 
			$(".center").slick({
				dots: true,
				infinite: true,
				prevArrow: '<div><i class="fa fa-chevron-circle-left faprev" aria-hidden="true"></i></div>',
				nextArrow: '<div><i class="fa fa-chevron-circle-right fanext" aria-hidden="true"></i></div>',
				slidesToShow: 1,
			});
		},800);
		return $dialogContent;
	}
	var $target = $(e.target);
	var origin = $target.closest(".dialog-parent").length > 0 ? $target.closest(".dialog-parent") : $target;
	var dialog = {
		id: "guideDialog",
		title: "Report Centre Onscreen Guide",
		size: "guide working",
		icon: "<i class='fa fa-info-circle'></i>",
		content: function() {
			return renderImage();
		}
		
	}
	dialogViewer(origin, dialog, dialogBuilder(dialog));
}