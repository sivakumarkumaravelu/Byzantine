/**********************************************************************
TEMPLATES GRID
**********************************************************************/
var data = _tbos_payment_templates;
var dataView;
var	grid;
var	record = null;
var	selectedRowIds = [];
var	selectedRowStates = [];
var	selectedRowWorkflows = [];
var columnFilters = {};
var	columns = [{
	id: "templateid",
	name: "Template ID",
	field: "templateid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "templatename",
	name: "Template Name",
	field: "templatename",
	width: 250,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "status",
	name: "Status",
	field: "status",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "name",
	name: "Beneficiary / Payment Name",
	field: "name",
	width: 250,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "type",
	name: "Payment Type",
	field: "type",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "totaldebitamount",
	name: "Debit Amount",
	field: "totaldebitamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "debitcurrency",
	name: "Debit Currency",
	field: "debitcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitaccountnumber",
	name: "Debit Account Number",
	field: "debitaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "debitaccountname",
	name: "Debit Account Name",
	field: "debitaccountname",
	width: 220,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "totalpaymentamount",
	name: "Payment Amount",
	field: "totalpaymentamount",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true,
	cssClass: "num neg",
	headerCssClass: "righted"
}, {
	id: "paymentcurrency",
	name: "Payment Currency",
	field: "paymentcurrency",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "beneficiaryaccountnumber",
	name: "Beneficiary Account",
	field: "beneficiaryaccountnumber",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiaryid",
	name: "Beneficiary ID",
	field: "beneficiaryid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiarybankid",
	name: "Beneficiary Bank ID",
	field: "beneficiarybankid",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "beneficiarybankname",
	name: "Beneficiary Bank Name",
	field: "beneficiarybankname",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "createdby",
	name: "Created By",
	field: "createdby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false,
}, {
	id: "createdon",
	name: "Creation Date",
	field: "createdon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: false
}, {
	id: "lastmodifiedby",
	name: "Last Modified By",
	field: "lastmodifiedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "lastmodifiedon",
	name: "Last Modified Date",
	field: "lastmodifiedon",
	width: 200,
	sortable: true,
	sorter: "sorterDateIso",
	visible: false
}, {
	id: "lastapprovedby",
	name: "Last Approver",
	field: "lastapprovedby",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}, {
	id: "numberofpayments",
	name: "No. of Instructions",
	field: "numberofpayments",
	width: 200,
	sortable: true,
	sorter: "sorterNumeric",
	visible: true
}, {
	id: "division",
	name: "Division",
	field: "division",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: false
}];
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('paymentTemplatesColumnOrder')) {
	columns = store.get('paymentTemplatesColumnOrder');
	for (i = 0; i < columns.length; i++) {
		if ( columns[i].id == "totaldebitamount" || columns[i].id == "totalpaymentamount") {
			columns[i].formatter = Slick.Formatters.AmountFormatter
		}
	}
} else {
	store.set('paymentTemplatesColumnOrder', columns)
}
if (store.get('paymentTemplatesColumnWidths')) {
	var setWidth = store.get('paymentTemplatesColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());

var groupedSetting = 0, groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var searchString = "", statusString = "", workflowString = "", userString = "", searchPoint = "templatename";
function myFilter(item, args) {

	if (args.statusString != "" && args.statusString.toLowerCase().indexOf(item["status"].toLowerCase()) == -1) {
		return false;
	}

	if (args.workflowString != "" && item["workflow"].toLowerCase().indexOf(args.workflowString.toLowerCase()) == -1) {
		return false;
	}

	if (args.userString != "" && item["createdby"].toLowerCase().indexOf(args.userString.toLowerCase()) == -1) {
		return false;
	}

	if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1) {
		return false;
	}

	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function filterPaymentSummaryGrid() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}
function quickFindPayments() {
	var rows = grid.getSelectedRows();
	if (rows.length > 0) {
		grid.setSelectedRows(0)
	};
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.refresh();
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
function paymentsViewFilter() {
	var rows = grid.getSelectedRows();
	folderString = "";
	if (rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	filterPaymentSummaryGrid();
}


/**********************************************************************
CONTEXT MENU
**********************************************************************/
function checkStatus(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
function checkWorkflow(arr, text) {
	var L = arr.length - 1;
	while (L) {
		if (arr[L--].indexOf(text) != arr[L].indexOf(text)) {
			return false
		}
	}
	return arr[L]
}
var enableContextItem = function() {
	$(this).children("div.disabled").remove();
	$(this).children("a").show();
};
var disableContextItem = function() {
	if ($(this).children("div.disabled").size()) {
		$(this).children("div.disabled").remove();
	}
	var $a = $(this).children("a"),
		$div = $("<div class='disabled' />"),
		content = $a.html();
	$a.hide();
	$div.html(content).appendTo($(this));
};
function setupContextMenu(record) {
	var sel = selectedRowIds.length,
		$contextItems = $("[data-type='context-item']"),
		statusValue = "",
		workflowValue = "";
	if (record != null) {
		selectedRowStates.push(record.status);
		selectedRowWorkflows.push(record.workflow);
		sel = 1;
	}
	if (!sel) {
		$contextItems.each(disableContextItem);
	} else {
		statusValue = checkStatus(selectedRowStates, "");
		workflowValue = checkWorkflow(selectedRowWorkflows, "");
		if (sel == 1) {
			if (workflowValue == "New") {
				if (statusValue == "Draft" || statusValue == "Rejected") {
					$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='template']").each(enableContextItem);
					$("[data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				} else if (statusValue == "Pending Approval") {
					$("[data-action='view'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				}
			} else if (workflowValue == "Approved") {
				if (statusValue == "Future Dated") {
					$("[data-action='view'], [data-action='copy'], [data-action='delete'], [data-action='template'], [data-action='stop']").each(enableContextItem);
					$("[data-action='edit'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='recall']").each(disableContextItem);
				} else if (statusValue == "Processing") {
					$("[data-action='view'], [data-action='copy'], [data-action='template']").each(enableContextItem);
					$("[data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
				}
			} else if (workflowValue == "Needs Repair") {
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='delete'], [data-action='submit'], [data-action='template']").each(enableContextItem);
				$("[data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop']").each(disableContextItem);
			}
		} else {
			if (statusValue == "Draft" || statusValue == "Rejected" || statusValue == "Needs Repair") {
				$("[data-action='delete'], [data-action='submit']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else if (statusValue == "Pending Approval") {
				$("[data-action='recall'], [data-action='approve'], [data-action='reject']").each(enableContextItem);
				$("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else if (statusValue == "Future Dated") {
				$("[data-action='stop']").each(enableContextItem);
				$("[data-action='view'], [data-action='copy'], [data-action='edit'], [data-action='delete'], [data-action='submit'], [data-action='retry'], [data-action='approve'], [data-action='reject'], [data-action='recall'], [data-action='template']").each(disableContextItem);
			} else if (!statusValue && (selectedRowStates.indexOf("Draft") > -1 || selectedRowStates.indexOf("Rejected") > -1 || selectedRowStates.indexOf("Needs Repair") > -1) && selectedRowStates.indexOf("Pending Approvel") == -1 && selectedRowStates.indexOf("Processing") == -1 && selectedRowStates.indexOf("Future Dated") == -1) {
				$("[data-action='delete'], [data-action='submit']").each(enableContextItem);
				$("[data-action='view'], [data-action='edit'], [data-action='copy'], [data-action='recall'], [data-action='approve'], [data-action='reject'], [data-action='retry'], [data-action='stop'], [data-action='template']").each(disableContextItem);
			} else {
				$contextItems.each(disableContextItem);
			}
		}
	}
}



/**********************************************************************
FOLDER SETUP AND MANAGEMENT
**********************************************************************/
var user_template_folders = [], folders_updated = false, folders_deleted = false;
var $folderMessage = $("<div class='folder-message'><p>Use Folders To Organise Payment Templates</p><p style='font-size: 14px;'>Folders help you keep your templates organised. Enter a folder name in the field above to create a new folder.</p><p style='font-size: 14px;'>Move templates by selecting them in the grid and right-clicking or using the Action Menu to move them to the selected folder.</p><p style='font-size: 14px;'>To access your folders use the <i class='fa fa-th-list fa-fw'></i> View Menu.</p></div>");
var $folderListInstruction = $("<p class='folder-list-instructions'>Reorder, rename, or remove your folders.</p>");
if (store.get('template_folder_store')) {
	user_template_folders = store.get('template_folder_store')
};
function folderChecker(val) {
	var _folder = val,
		error = false,
		$folderList = $(".folder-list").children("li"),
		existingFolders = [];
	for (var i = 0; i < $folderList.length; i++) {
		existingFolders.push($folderList.eq(i).attr("data-folder"));
	}
	if ($.inArray(_folder, existingFolders) != -1) {
		error = "existing"
	}
	return error;
}
function renameFolder(el) {
	var newFolderName = $.trim(el.val());
	if (newFolderName == '' || newFolderName == "undefined") {
		el.val(el.attr("data-folder-name"));
	} else {
		el.val(newFolderName);
		el.closest("li").attr("data-folder", newFolderName);
		folders_updated = true;
	}
}
function addFolder() {
	var folderName = $.trim($("#newFolderInput").val()),
		$folderList = $("ul.folder-list"),
		$newFolderDiv = $("div.new-folder"),
		$li, $div, $span, $input, $a, $error, folderCheck = folderChecker(folderName);
	if (folderName == '' || folderName == "undefined") {
		$("#newFolderInput").val('');
		return false;
	} else {
		if (folderCheck == "existing") {
			$newFolderDiv.addClass("error");
			$("#newFolderInput").focus().select().one("keyup.remove-error", function() {
				$newFolderDiv.removeClass("error");
			});
		} else {
			if ($newFolderDiv.hasClass("error")) {
				$newFolderDiv.removeClass("error");
			}
			if ($(".folder-message").size()) {
				$(".folder-message").remove();
				$folderListInstruction.insertBefore($folderList);
			}
			$li = $("<li data-folder='" + folderName + "' data-folder-id='" + randString() + "' class='row new' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' value='" + folderName + "' maxlength='25' data-folder-name='" + folderName + "' />").on("change", function() {
				renameFolder($(this));
			}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with the same name already exists</div>").appendTo($div);
			$("#newFolderInput").val('');
			$folderList.sortable("refresh");
			folders_updated = true;
		}
	}
}
function addFolderInline() {
	var folderName = $.trim($("#_inlineFolderInput").val()),
		folderExists = false;
	if (folderName == '' || folderName == "undefined") {
		$("#_inlineFolderInput").val('');
		return false;
	} else {
		for (var i = 0; i < user_template_folders.length; i++) {
			if (folderName == user_template_folders[i].name) {
				folderExists = true;
				break;
			}
		}
		if (folderExists) {
			alert("A folder with that name already exists.");
		} else {
			var _id = randString();
			var _new = {
				name: folderName,
				id: _id
			};
			user_template_folders.push(_new);
			populateFolders();
			store.set('template_folder_store', user_template_folders);
			$("#_inlineFolderInput").val('');
			moveTemplates(_id);
		}
	}
}
function deleteFolder(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function() {
		if (!$target.hasClass('new')) {
			folders_deleted = true;
		}
		$target.remove();
		$(".folder-list").sortable("refresh");
		folders_updated = true;
		if (!$(".folder-list").children("li").size()) {
			$(".folder-list-instructions").remove();
			$folderMessage.appendTo(".folder-settings");
		}
		if ($("div.new-folder").hasClass("error")) {
			$("div.new-folder").removeClass("error");
		}
	});
}
function populateFolders() {
	var $assignFolders = $(".assign-folders"),
		folderCount = user_template_folders.length,
		activeFolder = $assignFolders.children("li.active") ? $assignFolders.children("li.active").attr("data-folder-id") : false;
	$assignFolders.children().remove();
	if ($("#removeFromFolder").size() > 0) {
		$("#removeFromFolder").remove();
	}
	if (folderCount > 0) {
		var $li, $a
		$assignFolders.each(function() {
			var _this = $(this);
			if (_this.parents().attr("id") == "folderMenu") {
				$.each(user_template_folders, function() {
					$li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' />").appendTo(_this);
					$a = $("<a href='javascript:void(0)' title='" + this.name + "' data-folder='" + this.name + "' data-folder-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
						e.preventDefault();
						moveTemplates($(this).attr("data-folder-id"));
					}).appendTo($li);
				});
				var $ul = $("<ul class='no-set' id='removeFromFolder' />").insertAfter(_this),
					$spacer = $("<li class='menu-section' />").appendTo($ul),
					$li = $("<li />").appendTo($ul),
					$a = $("<a href='javascript:void(0)' class='remove-from-folders' title='Remove selected beneficiaries from a folder' data-folder='None' data-folder-id='None'>None (Remove from folders)</a>").on("click", function(e) {
						e.preventDefault();
						moveTemplates($(this).attr("data-folder-id"));
					}).appendTo($li),
					$spacer = $("<li class='menu-section' />").appendTo($ul);
			} else if (_this.parents().attr("id") == "viewMenu") {
				$.each(user_template_folders, function() {
					$li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' />").appendTo(_this);
					if (this.id == activeFolder) {
						$li.addClass("active");
						$("#viewMenuControl").children("a").children("span").html(this.name);
					}
					$a = $("<a href='javascript:void(0)' title='" + this.name + "' data-folder='" + this.name + "' data-folder-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
						e.preventDefault();
						var _folderID = $(this).attr("data-folder-id"),
							_folderName = $(this).attr("data-folder");
						if (folderString != _folderID) {
							folderString = _folderID;
						}
						folderFilter();
						$("#selectedFolder").html(_folderName);
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.assign-folders"),
			$li = $("<li class='no-set' />").appendTo($viewMenu),
			$a = $("<a href='javascript:void(0)'><div style='font-weight: 600; margin-bottom: 4px;'>Create Folders</div>Folders help keep your data organized. Click here to start creating folders.</a>").appendTo($li).on("click", showFolderManagerDialog);
	}
}
function populateFolderManager() {
	folders_updated = false;
	folders_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
		$folderAddLine = $("<p>Create a new folder.</p>").appendTo($folderSettings),
		$folderAddDiv = $("<div class='new-folder' />").appendTo($folderSettings),
		$folderAddInput = $("<input type='text' placeholder='Enter a name for your new folder' value='' maxlength='25' id='newFolderInput'>").on("keyup", function(e) {
			if (e.keyCode == 13) {
				addFolder()
			}
		}).appendTo($folderAddDiv),
		$folderAddButton = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Add</a>").on("click", addFolder).appendTo($folderAddDiv),
		$folderError = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($folderAddDiv),
		$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({
			handle: '.reorder-folder',
			axis: 'y',
			tolerance: "pointer",
			update: function(event, ui) {
				folders_updated = true
			}
		}),
		folderCount = user_template_folders.length,
		$li, $div, $span, $input, $a, $error;
	if (folderCount > 0) {
		$folderListInstruction.insertBefore($folderList);
		$.each(user_template_folders, function() {
			$li = $("<li data-folder='" + this.name + "' data-folder-id='" + this.id + "' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='" + this.name + "' data-folder-name='" + this.name + "' />").on("change", function() {
				renameFolder($(this));
			}).appendTo($div);
			$a = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteFolder).appendTo($div);
			$error = $("<div class='data-error'>A folder with this name already exists</div>").appendTo($div);
		});
	} else {
		$folderMessage.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showFolderManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Template Folders",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function() {
			return populateFolderManager()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateFolders(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveFolders(dialog) {
	var $dialog = $("#" + dialog.id),
		$active = $("#viewMenu").children(".assign-folders").find("li.active").attr("data-folder-id");
	$dialog.addClass("working");
	user_template_folders = folders_updated;

	var active_deleted = true;

	for (f = 0; f < user_template_folders.length; f++) {
		if ($active == user_template_folders[f].id) {
			active_deleted = false;
			break;
		}
	}

	for (var i = 0; i < data.length; i++) {
		var _resetFolder = true;
		for (var n = 0; n < user_template_folders.length; n++) {
			if (data[i].folderid == user_template_folders[n].id) {
				data[i].folder = user_template_folders[n].name;
				_resetFolder = false;
				break;
			}
		}
		if (_resetFolder) {
			data[i].folder = "None";
			data[i].folderid = "None";
		}

	}
	folders_updated = false;
	folders_deleted = false;
	store.set('template_folder_store', user_template_folders);
	setTimeout(function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateFolders();
		if (!user_template_folders.length || active_deleted) {
			$("#allTemplates").trigger("click");
		}
		dialogHider(dialog);
	}, 300);
}
function updateFolders(dialog) {
	if (folders_updated) {
		folders_updated = [];
		var duplicate_names = false,
			$folderList = $(".folder-list");
		$folderList.find("li.error").removeClass("error");
		$folderList.children("li").each(function() {
			folders_updated.push({
				"name": $(this).attr("data-folder"),
				"id": $(this).attr("data-folder-id")
			});
			var _name = $(this).attr("data-folder");
			$(this).siblings().each(function() {
				if ($(this).attr("data-folder") == _name) {
					$(this).addClass("error");
				}
			});
		});
		if ($folderList.find("li.error").size()) {
			duplicate_names = true;
		}
		if (duplicate_names) {
			return false;
		} else {
			var save_folders = false;
			if (user_template_folders.length != folders_updated.length) {
				save_folders = true;
			} else {
				for (var i = 0; i < user_template_folders.length; i++) {
					if (user_template_folders[i].name != folders_updated[i].name || user_template_folders[i].id != folders_updated[i].id) {
						save_folders = true;
						break;
					}
				}
			}
			if (save_folders || folders_deleted) {
				if (folders_deleted) {
					buildConfirmDialog("You've removed some existing folders.", "Are you sure you want to continue?", function() {
						saveFolders(dialog)
					});
				} else {
					saveFolders(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}
function moveTemplates(_id) {
	var _folder, _message, _rowsForUpdate = [],
		_sel = selectedRowIds.length;
	for (var i = 0; i < user_template_folders.length; i++) {
		if (user_template_folders[i].id == _id) {
			_folder = user_template_folders[i];
			_message = "Selected templates were moved to &quot;" + _folder.name + "&quot;";
			break;
		}
	}
	if (_id == "None") {
		_folder = [{
			name: "None",
			id: "None"
		}];
		_message = "Selected templates were removed from their folders";
	}
	for (var i = 0, l = _sel; i < l; i++) {
		var _item = selectedRowIds[i];
		if (_item) {
			_rowsForUpdate.unshift(_item);
		}
	}
	for (var i = 0; i < _rowsForUpdate.length; i++) {
		data[dataView.getIdxById(_rowsForUpdate[i])].folder = _folder.name;
		data[dataView.getIdxById(_rowsForUpdate[i])].folderid = _folder.id;
	}
	grid.setSelectedRows(0);
	selectedRowIds = [];
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if (groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
	buildNotification(_message, 300, 3000);
	$("#viewMenu .assign-folders").find("a[data-folder-id='" + _folder.id + "']").trigger("click");
}


/**********************************************************************
REJECT TEMPLATE
**********************************************************************/
function rejectRecords(dialog) {
	$("#rejectReason").addClass("working");
	var sel = selectedRowIds.length;
	if (!sel || sel == 1) {
		var payment, msg;
		if (record != null) {
			payment = dataView.getItemById(record.id);
		} else {
			payment = data[dataView.getIdxById(selectedRowIds[0])];
		}
		var reloadPaymentGrid = function() {
			payment.rejectedby = "Prototype User 100";
			payment.rejectedon = smartDates("today") + " at " + timeFormatter();
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		payment.status = "Rejected";
		msg = "Approval for payment <strong>" + payment.customerreference + "</strong> has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	} else if (sel > 1) {
		var reloadPaymentGrid = function() {
			setTimeout(function() {
				$("#rejectReason").removeClass("working");
				dialogHider(dialog);
				dataView.refresh();
				grid.invalidate();
				grid.render();
				grid.setSelectedRows([]);
				buildNotification(msg, 500, 5000);
			}, 1500);
		}
		for (var i = 0; i < selectedRowIds.length; i++) {
			data[dataView.getIdxById(selectedRowIds[i])].status = "Rejected";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedby = "Prototype User 100";
			data[dataView.getIdxById(selectedRowIds[i])].rejectedon = smartDates("today") + " at " + timeFormatter();
		}
		msg = "Approval for selected payment records has been <strong>rejected</strong>.";
		reloadPaymentGrid();
	}
}
function rejectRecordReason(e) {
	e.preventDefault();
	var $target = $(e.target);
	var populateRejectReason = function() {
		var $form = $("<div class='form-section' />");
		var $row = $("<div class='row' />").appendTo($form);
		var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($row);
		var $textarea = $("<textarea style='width: 425px; height: 230px;' id='rejectionReasonTextarea'></textarea>").appendTo($dataCol);
		return $form;
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "rejectReason",
		title: "Enter A Reason For Rejection",
		size: "small",
		icon: "<i class='fa fa-ban'></i>",
		content: function() {
			return populateRejectReason()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					rejectRecords(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#rejectionReasonTextarea").focus();
}
function rejectRecordFromList(e) {
	e.preventDefault();
	var sel = selectedRowIds.length;
	if (sel > 1) {
		buildConfirmDialog("Approval for selected records will be rejected.", "Do you want to continue?", function() {
			rejectRecordReason(e);
		});
	} else {
		rejectRecordReason(e);
	}
}

/**********************************************************************
APPROVE TEMPLATE
**********************************************************************/
var approvalData = [],
	approvalDataView,
	approvalGrid,
	approvalColumns = [{
		id: "beneficiaryname",
		name: "Beneficiary / Batch Name",
		field: "beneficiaryname",
		width: 250,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "reference",
		name: "Payment ID",
		field: "reference",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "debitamount",
		name: "Debit Amount",
		field: "debitamount",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true,
		cssClass: "num neg",
		headerCssClass: "righted"
	}, {
		id: "debitaccountcurrency",
		name: "Debit Currency",
		field: "debitaccountcurrency",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "debitaccountnumber",
		name: "Debit Account Number",
		field: "debitaccountnumber",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "valuedate",
		name: "Value Date",
		field: "valuedate",
		width: 200,
		sortable: true,
		sorter: "sorterDateIso",
		visible: true
	}, {
		id: "paymenttype",
		name: "Payment Type",
		field: "paymenttype",
		width: 200,
		sortable: true,
		sorter: "sorterStringCompare",
		visible: true
	}, {
		id: "noinstructions",
		name: "No. of Instructions",
		field: "noinstructions",
		width: 200,
		sortable: true,
		sorter: "sorterNumeric",
		visible: true
	}];
var approvalOptions = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: false,
	syncColumnCellResize: false,
	forceFitColumns: true,
	multiSelect: false
};
function approveRecords(dialog) {
	$("#approvePayments").addClass("working");
	var sel = selectedRowIds.length;
	var reloadPaymentGrid = function() {
		setTimeout(function() {
			$("#approvePayments").removeClass("working");
			dialogHider(dialog);
			dataView.refresh();
			grid.invalidate();
			grid.render();
			grid.setSelectedRows([]);
			buildNotification(msg, 500, 5000);
		}, 1500);
	}
	for (var i = 0; i < selectedRowIds.length; i++) {
		data[dataView.getIdxById(selectedRowIds[i])].status = "Processing";
		data[dataView.getIdxById(selectedRowIds[i])].workflow = "Approved";
		data[dataView.getIdxById(selectedRowIds[i])].approvedby = "Prototype User 100";
		data[dataView.getIdxById(selectedRowIds[i])].approvedon = smartDates("today") + " at " + timeFormatter();
	}
	msg = "Selected payments have been approved and submitted for processing.";
	reloadPaymentGrid();
}
function approveRecordFromList(e) {
	e.preventDefault();
	var $target = $(e.target);
	var populateApprovalDialog = function() {
		var $dialogContent = $("<div style=' height: 100%; box-sizing: border-box; padding: 20px;' />");
		var $approveSummaryGrid = $("<div id='approvalGrid' style='width: 100%; height: 50%; margin-bottom: 20px; border: 1px solid #d9d9d9; border-radius: 4px;' />").appendTo($dialogContent);
		var $noteSection = $("<div id='approvalNote' style='margin-bottom: 20px; padding: 0 20px; white-space: nowrap;' />").appendTo($dialogContent);
		var $div = $("<div style='float: left;' />").appendTo($noteSection);
		var $img = $("<img src='img/smart_card_technology.png' />").appendTo($div);
		var $div = $("<div style='float: left; margin-top: -145px; margin-left: 180px; padding: 10px 60px 10px 20px;' />").appendTo($noteSection);
		var $heading = $("<div><strong>Smartcard Instructions</strong></div>").appendTo($div);
		var $instructions = $("<div style='white-space: normal; margin: 10px 0;'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis consectetur tellus. Proin dapibus augue a purus volutpat commodo. Mauris ac ante odio. Quisque efficitur ligula tincidunt est placerat varius. Sed nec blandit libero. Sed nec enim ac libero interdum viverra ac porta nibh. In pellentesque felis sit amet orci tristique, eget tristique lacus tincidunt. Etiam mattis vehicula ipsum, quis auctor augue pulvinar eu. Curabitur ligula lacus, ultricies eget feugiat sollicitudin, consequat a purus.</div>").appendTo($div);

		return $dialogContent;
	}
	var _origin = $target.closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $target;
	var _dialog = {
		id: "approvePayments",
		title: "Approve Selected Payments",
		size: "full-screen",
		icon: "<i class='fa fa-thumbs-up'></i>",
		content: function() {
			return populateApprovalDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Approve",
			icon: "<i class='fa fa-check fa-fw fa-lg'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					approveRecords(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	approvalData = [];
	for (var i = 0; i < selectedRowIds.length; i++) {
		approvalData.push(data[dataView.getIdxById(selectedRowIds[i])]);
	}


	setTimeout(function() {
		approvalDataView = new Slick.Data.DataView({});
		approvalGrid = new Slick.Grid("#approvalGrid", approvalDataView, approvalColumns, approvalOptions);
		approvalGrid.setSelectionModel(new Slick.RowSelectionModel({
			selectActiveRow: false
		}));
		approvalDataView.setItems(approvalData);
		approvalGrid.setColumns(approvalColumns);

		$(window).bind("resize", function() {
			approvalGrid.resizeCanvas();
		});

		$(window).on("resize", _.debounce(function(e) {
			approvalGrid.resizeCanvas();
		}, 100));
	}, 300);
}


/**********************************************************************
VIEW / EDIT TEMPLATE
**********************************************************************/
function viewPaymentDetails(record) {


	updateBreadcrumb("view");

	/* setup the review grid */
	var reviewDataView;
	var reviewGrid;
	var reviewData = [];
	var reviewColumns = [{
		id: "number",
		name: "#",
		field: "number",
		toolTip: "Item Number",
		width: 50,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: false
	}, {
		id: "validated",
		name: "<i class='fa fa-check-circle fa-fw' style='color: #fff;'></i>",
		field: "validated",
		toolTip: "Payment Validation",
		width: 60,
		headerCssClass: "centered",
		cssClass: "centered",
		sortable: false,
		visible: true,
		resizable: false,
		formatter: Slick.Formatters.ValidatedIconFormatter
	}, {
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryaccountnumber",
		name: "Account",
		field: "beneficiaryaccountnumber",
		toolTip: "Beneficiary Account",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "status",
		name: "Status",
		field: "status",
		toolTip: "Status",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}];

	if (record.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			visible: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			visible: true,
			formatter: Slick.Formatters.AmountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			visible: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			visible: true,
			formatter: Slick.Formatters.AmountFormatter
		}
	}
	reviewColumns.push(currencyColumn);
	reviewColumns.push(amountColumn);

	var reviewOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};

	var $paymentDetailSection = $("#templateDetail");

	/* view payment section */
	var $paymentDetailContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; bottom: 60px; background: #f5f5f5;' id='viewPaymentContent' />");

	/* page title */
	var $pageTitle = $("<div class='page-section' />").appendTo($paymentDetailContainer),
		$titleSpan = $("<span>" + record.type + " Payment Template</span>").appendTo($pageTitle);

	/* detail section */
	var $paymentDataSection = $("<div class='grid-layout' />").appendTo($paymentDetailContainer);

	/* system information */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Information</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Template ID</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.templateid + "</div>").appendTo($dataCol);

	if (record.notices) {
		var $data = $("<div class='data-text' />").appendTo($dataCol),
			$link = $("<a href='javascript:void(0)' title='Click To View Payment Alerts' style='color: #e98c3a;'><i class='fa fa-exclamation-triangle fa-fw'></i></a>").appendTo($data).on("click", function(e) {
				e.preventDefault();
				showPaymentNotificaitonsDialog($(this), record);
			});
	}

	var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Template Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.templatename + "</div>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Status</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.status + "</div>").appendTo($dataCol);

	if (record.status == "Needs Repair") {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box error' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$boxDiv = $("<div />").appendTo($boxContent),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>This payment has the following errors:</div>").appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($boxDiv),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 307px; overflow-y: auto;' id='errorsGrid' />").appendTo($dataCol),
			$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
		for (var e = 0, f = record.errors.length; e < f; e++) {
			var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + record.errors[e].description + "</span></li>").appendTo($errorList);
		}
	}

	/* batch details */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Debit Account</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
		$data = $("<div class='data-text' style='font-size: 16px;'>" + record.debitaccountnumber + " - " + record.debitaccountname + " (" + record.debitcurrency + ")</div>").appendTo($dataGroup),
		$data = $("<div class='data-text'> $" + addCommas(record.debitaccount.availablebalance) + " (Current Balance)</div>").appendTo($dataGroup),
		$data = $("<div class='data-text'> $" + addCommas(record.debitaccount.availablefunds) + " (Available Balance)</div>").appendTo($dataGroup),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Value Date</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' style='font-size: 16px;'>" + record.paymentdate + "</div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' style='font-size: 16px;'>" + record.paymentcurrency + " $" + record.totalpaymentamount + "</div>").appendTo($dataCol);
	if (record.paymentcurrency != record.debitcurrency) {
		var $dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text' style='font-size: 16px;'>" + record.debitcurrency + " $" + record.totaldebitamount + "</div>").appendTo($dataCol);
	}
	var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Division</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.division + "</div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Batch Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + record.name + "</div>").appendTo($dataCol),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Batch Description</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' style='max-width: 70%;'>" + record.batchdescription + "</div>").appendTo($dataCol);

	/* batch settings */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header-inline'>Payment Preferences</div>").appendTo($box),
		$boxContent = $("<div class='box-content-inline' />").appendTo($box),
		$dataRow = $("<div class='row' />").appendTo($boxContent),
		$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow);
	var $data = $("<input type='checkbox' id='viewIndividualDebitsFlag' disabled='disabled' class='disabled' />").appendTo($dataCol),
		$desc = $("<label class='desc' style='cursor: default;'>Individual Debits</label>").appendTo($dataCol);
	if (record.individualdebitsflag) {
		$data.prop("checked", true);
	}
	if (record.type.indexOf("International") != -1) {
		var $data = $("<input type='checkbox' id='viewUrgentFlag' disabled='disabled' />").appendTo($dataCol),
			$desc = $("<label class='desc' style='cursor: default;'>Urgent</label>").appendTo($dataCol);
		if (record.urgentflag) {
			$data.prop("checked", true);
		}
	}
	if (record.paymentcurrency != record.debitcurrency) {
		var $data = $("<input type='checkbox' id='viewDebitFlag' disabled='disabled' class='disabled' />").appendTo($dataCol),
			$desc = $("<label class='desc' style='cursor: default;'>Use Debit Currency</label>").appendTo($dataCol);
		if (record.debitequivalentflag) {
			$data.prop("checked", true);
		}
	}

	/* payment section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Instructions</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$boxDiv = $("<div />").appendTo($boxContent),
		$dataRow = $("<div class='row' />").appendTo($boxDiv),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
		$searchDiv = $("<div class='icon-input payment-grid-filter' />").appendTo($inlineSearch),
		$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
		$searchInput = $("<input type='text' placeholder='Search Payment Instructions' />").appendTo($searchDiv),
		$paymentInstructionGrid = $("<div class='payment-grid' id='viewPaymentsGrid' />").appendTo($dataCol),
		$totalsDiv = $("<div style='padding: 15px 20px 0 20px;' />").appendTo($boxContent),
		$totalsRow = $("<div class='grid-row' />").appendTo($totalsDiv),
		$totalsCell = $("<div class='grid-cell' style='width: 100%; color: #4a494a; font-size: 14px; text-align: right;' />").appendTo($totalsRow),
		$totalInstructions = $("<div style='display: inline-block; vertical-align: top; margin-right: 25px;'>Number Of Instructions: &nbsp;<strong>" + record.numberofpayments + "</strong></div>").appendTo($totalsCell),
		$totalAmountsDiv = $("<div style='display: inline-block; vertical-align: top;' />").appendTo($totalsCell);
	if (record.paymentcurrency != record.debitcurrency) {
		if (record.debitequivalentflag) {
			var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='margin-top: 8px;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
		} else {
			var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='margin-top: 8px;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + record.debitcurrency + " $" + addCommas(record.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv);
		}
	} else {
		var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + record.paymentcurrency + " $" + addCommas(record.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
	}

	/* fx section */
	if ((record.paymentcurrency != record.debitcurrency) && !record.individualdebitsflag) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Rate Type</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + record.ratetype + "</div>").appendTo($dataCol);
		if (record.ratetype == "Carded") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Rate</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + record.rate + " &nbsp;&nbsp; 1 " + record.fromccy + " &nbsp; = &nbsp; " + (1 * record.rate) + " " + record.toccy + "</div>").appendTo($dataCol);
		} else if (record.ratetype == "Contract") {
			var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
			var _remaining = 0;
			for (var x = 0, y = record.contracts.length; x < y; x++) {
				_remaining = (Number(_remaining) + Number(record.contracts[x].used));
				var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].reference + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell'>" + record.contracts[x].clientid + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + record.contracts[x].rate + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(record.contracts[x].used) + "</div>").appendTo($dataTableRow);
			}
			var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
			var _remaining = Number(_remaining).toFixed(2);
			if (record.debitequivalentflag) {
				if (_remaining == removeCommas(record.totaldebitamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totaldebitamount)) {
					var _amt = (Number(removeCommas(record.totaldebitamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totaldebitamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totaldebitamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			} else {
				if (_remaining == removeCommas(record.totalpaymentamount)) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(removeCommas(record.totalpaymentamount)) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > removeCommas(record.totalpaymentamount)) {
					var _amt = (Number(_remaining) - Number(removeCommas(record.totalpaymentamount))).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			}
		}
		var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
	}

	/* buttons */
	var $paymentButtonContainer = $("<div style='position: absolute; bottom: 0; right: 0; left: 0; border-top: 1px solid #d7d7d7; text-align: center; white-space: nowrap; padding: 10px 0; overflow: hidden; background: #fff;' />");

	var $closeButton = $("<span class='form-button' id='closeButton' />").appendTo($paymentButtonContainer),
		$closeLink = $("<a href='#templateList' title='Close Payment' data-panel='#templateList' data-switch='switch-panels'><i class='fa fa-times-circle fa-fw'></i><span>Close</span></a></span>").appendTo($closeButton).on("click", function(e) {
			record = null;
			reviewGrid.destroy()
			reviewGrid = null;
			reviewDataView = null;
			reviewData = [];
			reviewColumns = [];
			$(window).off("resize.reviewgrid");
			$("#viewPaymentContent").remove();
			updateBreadcrumb("close");
		});


	if (record.status == "Draft" || record.status == "Approver Rejected") {

		var $editButton = $("<span class='form-button' id='editButton' />").appendTo($paymentButtonContainer),
			$editLink = $("<a href='javascript:void(0)' title='Edit Payment'><i class='fa fa-edit fa-fw'></i>Edit</a>").appendTo($editButton).on("click", function(e) {
				e.preventDefault();
				$("#templateDetail").empty().addClass("loading");
				reviewGrid.destroy();
				reviewGrid = null;
				reviewDataView = null;
				reviewData = [];
				reviewColumns = [];
				$(window).off("resize.reviewgrid");
				editPaymentDetails(record);
				setTimeout(function() {
					$("#templateDetail").removeClass("loading").scrollTop(0);
					if ($(".ie8").size() > 0) {
						var $icons = $(target).find(".fa");
						$icons.addClass("repaint");
						setTimeout(function() {
							$icons.removeClass("repaint")
						}, 1)
					}
				}, 500);
			});


		var $deleteButton = $("<span class='form-button' id='deleteButton' />").appendTo($paymentButtonContainer),
			$deleteLink = $("<a href='javascript:void(0)' title='Delete Payment'><i class='fa fa-trash-o fa-fw'></i>Delete</a>").appendTo($deleteButton);

	} else if (record.status == "Approved") {

		var $editButton = $("<span class='form-button' id='editButton' />").appendTo($paymentButtonContainer),
			$editLink = $("<a href='javascript:void(0)' title='Edit Payment'><i class='fa fa-edit fa-fw'></i>Edit</a>").appendTo($editButton).on("click", function(e) {
				e.preventDefault();
				$("#templateDetail").empty().addClass("loading");
				reviewGrid.destroy();
				reviewGrid = null;
				reviewDataView = null;
				reviewData = [];
				reviewColumns = [];
				$(window).off("resize.reviewgrid");
				editPaymentDetails(record);
				setTimeout(function() {
					$("#templateDetail").removeClass("loading").scrollTop(0);
					if ($(".ie8").size() > 0) {
						var $icons = $(target).find(".fa");
						$icons.addClass("repaint");
						setTimeout(function() {
							$icons.removeClass("repaint")
						}, 1)
					}
				}, 500);
			});


		var $deleteButton = $("<span class='form-button' id='deleteButton' />").appendTo($paymentButtonContainer),
			$deleteLink = $("<a href='javascript:void(0)' title='Delete Payment'><i class='fa fa-trash-o fa-fw'></i>Delete</a>").appendTo($deleteButton);


	} else if (record.status == "Pending Approval") {

		var $approveButton = $("<span class='form-button primary' id='approveButton' />").appendTo($paymentButtonContainer),
			$approveLink = $("<a href='javascript:void(0)' title='Approve Payment'><i class='fa fa-check-circle fa-fw'></i>Approve</a>").appendTo($approveButton);

		var $rejectButton = $("<span class='form-button' id='rejectButton' />").appendTo($paymentButtonContainer),
			$rejectLink = $("<a href='javascript:void(0)' title='Reject Payment'><i class='fa fa-ban fa-fw'></i>Reject</a>").appendTo($rejectButton);

	}



	/* attach the content */
	$paymentDetailContainer.appendTo($paymentDetailSection);
	$paymentButtonContainer.appendTo($paymentDetailSection);


	/* instruction dialog */
	function triggerInstructionDialog(_target, item) {
		function renderPaymentInstructionDetails() {

			var instruction = item;

			function triggerBeneficiaryDialog() {

				function renderBeneficiaryData() {
					var bene = instruction.beneficiary;
					var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewBeneDialog' />");

					/* beneficiary section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Beneficiary Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benename + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Beneficiary Local Language Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benelocalname + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Number</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneaccount + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Account Type</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benetype + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.beneaddress3 + ", " + bene.benepostal + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + bene.benecity + "</div>").appendTo($break),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.benecountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>E-mail</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bene.beneemail + "</div>").appendTo($dataCol);


					/* bank section */
					var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
						$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
						$box = $("<div class='box' />").appendTo($sectionCell),
						$boxHeader = $("<div class='box-header'>Beneficiary Bank</div>").appendTo($box),
						$boxContent = $("<div class='box-content top-label' />").appendTo($box),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Country</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Clearing Code</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Bank Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Branch Name</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataCol),
						$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Address</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress1 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress2 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchaddress3 + "</div>").appendTo($break),
						$break = $("<div class='break' />").appendTo($dataCol),
						$data = $("<div class='data-text'>" + branchcity + "</div>").appendTo($break);

					return $dialogContent;
				}

				var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
				var _dialog = {
					id: "viewBeneDetails",
					title: "Beneficiary Details",
					size: "xl",
					icon: "<i class='fa fa-book'></i>",
					content: function() {
						return renderBeneficiaryData();
					},
					buttons: [{
						name: "Close",
						icon: "<i class='fa fa-times fa-fw'></i>",
						events: [{
							event: "click",
							action: function(e) {
								e.preventDefault();
								dialogHider(_dialog);
							}
						}]
					}]
				}
				dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			}

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>System Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.id + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.status + "</div>").appendTo($dataCol);


			if (instruction.status == "Needs Repair") {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box error' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$boxDiv = $("<div />").appendTo($boxContent),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>This payment instruction has the following errors:</div>").appendTo($dataCol),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 200px; overflow-y: scroll;' id='errorsGrid' />").appendTo($dataCol),
					$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
				for (var e = 0, f = instruction.errors.length; e < f; e++) {
					var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + instruction.errors[e].description + "</span></li>").appendTo($errorList);
				}
			}


			/* beneficiary section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>To</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Beneficiary</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' />").appendTo($dataCol),
				$link = $("<a href='javacript:void(0)' id='viewBeneDetailTrigger' style='color: #017dba;'>" + instruction.beneficiaryname + " <i class='fa fa-external-link fa-fw' style='vertical-align: middle;'></i></a>").appendTo($data).on("click", triggerBeneficiaryDialog),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.beneficiaryaccountnumber + "</div>").appendTo($dataCol);
			if (instruction.beneficiary.benelocalname != "") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Local Language Name</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.beneficiary.benelocalname + "</div>").appendTo($dataCol);
			}
			if (record.type.indexOf("International") != -1) {
				var bank = instruction.beneficiary.swiftbank,
					bankbranch = instruction.beneficiary.swiftbranch,
					bankcountry = instruction.beneficiary.swiftbankcountry,
					branchaddress1 = instruction.beneficiary.swiftbankaddress1,
					branchaddress2 = instruction.beneficiary.swiftbankaddress2,
					branchaddress3 = instruction.beneficiary.swiftbankaddress3,
					branchpostal = instruction.beneficiary.swiftbankpostal,
					branchcity = instruction.beneficiary.swiftbankcity,
					bankcode = instruction.beneficiary.swiftcode + " (SWIFT)";
			} else {
				var bank = instruction.beneficiary.benebank,
					bankbranch = instruction.beneficiary.benebankbranch,
					bankcountry = instruction.beneficiary.benebankcountry,
					branchaddress1 = instruction.beneficiary.benebankaddress1,
					branchaddress2 = instruction.beneficiary.benebankaddress2,
					branchaddress3 = instruction.beneficiary.benebankaddress3,
					branchpostal = instruction.beneficiary.benebankpostal,
					branchcity = instruction.beneficiary.benebankcity,
					bankcode = instruction.beneficiary.benebankclearingcode + " (" + instruction.beneficiary.benebankclearingtype + ")";
			}
			var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Bank Details</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataGroup),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Clearing</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol);


			/* payment details section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Method</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.paymentmethod + "</div>").appendTo($dataCol),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Date</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentdate + "</div>").appendTo($dataCol);

			if (record.individualdebitsflag) {
				if (record.paymentcurrency != record.debitcurrency) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			} else {
				if (record.debitequivalentflag) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			}


			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Reference</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.paymentreference + "</div>").appendTo($dataCol);

			if (instruction.paymentmethod == "BEPS" || instruction.paymentmethod == "DHVPS" || instruction.paymentmethod == "CBHVPS") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Purpose Code</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.purposecode + "</div>").appendTo($dataCol);
			}

			var $row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Remittance Information</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='max-width: 70%;'>" + instruction.remittanceinformation + "</div>").appendTo($dataCol);

			if ((record.paymentcurrency != record.debitcurrency) && record.individualdebitsflag) {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($dataRow),
					$label = $("<label>Rate Type</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>" + instruction.ratetype + "</div>").appendTo($dataCol);
				if (instruction.ratetype == "Carded") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>Rate</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-text'>" + instruction.rate + " &nbsp;&nbsp; 1 " + instruction.fromccy + " &nbsp; = &nbsp; " + (1 * instruction.rate) + " " + instruction.toccy + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
				} else if (instruction.ratetype == "Contract") {
					var $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
					var _remaining = 0;
					for (var x = 0, y = instruction.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(instruction.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].reference + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + instruction.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].used) + "</div>").appendTo($dataTableRow);
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					if (record.debitequivalentflag) {
						if (_remaining == instruction.debitequivalentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.debitequivalentamount) {
							var _amt = (Number(instruction.debitequivalentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.debitequivalentamount) {
							var _amt = (Number(_remaining) - Number(instruction.debitequivalentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						if (_remaining == instruction.paymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.paymentamount) {
							var _amt = (Number(instruction.paymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.paymentamount) {
							var _amt = (Number(_remaining) - Number(instruction.paymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}

				}
			}



			/* supporting documents section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow);

			if (instruction.supportingdocs.length) {
				var $dataTable = $("<div class='data-table' />").appendTo($dataCol),
					$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);

				for (var x = 0, y = instruction.supportingdocs.length; x < y; x++) {
					_doc = instruction.supportingdocs[x];
					var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
				}
			} else {
				var $data = $("<div class='data-text'>No documents attached</div>").appendTo($dataCol);
			}


			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "viewPaymentInstruction",
			title: "Payment Instruction",
			size: "xl",
			icon: "<i class='fa fa-money'></i>",
			content: function() {
				return renderPaymentInstructionDetails();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Request Beneficiary Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}],
				cssClass: "primary"
			}, {
				name: "Request Debit Advice",
				icon: "<i class='fa fa-file-text fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}

	/* initialise the view payments grid */
	reviewData = record.payments;
	var reviewItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	reviewDataView = new Slick.Data.DataView({
		reviewItemMetaProvider: reviewItemMetaProvider
	});
	reviewGrid = new Slick.Grid("#viewPaymentsGrid", reviewDataView, reviewColumns, reviewOptions);
	reviewGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: true
	}));
	reviewGrid.registerPlugin(reviewItemMetaProvider);
	reviewGrid.onSort.subscribe(function(e, args) {
		reviewDataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	reviewGrid.onClick.subscribe(function(e, args) {
		var cell = reviewGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = reviewDataView.getItem(row);
		triggerInstructionDialog($(e.target), item);
	});
	reviewDataView.beginUpdate();
	reviewDataView.setItems(reviewData);
	reviewDataView.endUpdate();
	reviewGrid.setColumns(reviewColumns);

	$(window).on("resize.reviewgrid", function() {
		reviewGrid.resizeCanvas();
	});

	$(window).on("resize.reviewgrid", _.debounce(function(e) {
		reviewGrid.resizeCanvas();
	}, 100));
}

function editPaymentDetails(record) {


	updateBreadcrumb("edit");

	var editingRecord = jQuery.extend(true, {}, record);

	/* setup the edit payment grid */
	var editDataView;
	var editGrid;
	var editData = [];
	var editSelectedRowIds = [];
	var editColumns = [{
		id: "number",
		name: "#",
		field: "number",
		toolTip: "Item Number",
		width: 50,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare",
		resizable: false
	}, {
		id: "validated",
		name: "<i class='fa fa-check-circle fa-fw' style='color: #fff;'></i>",
		field: "validated",
		toolTip: "Payment Validation",
		width: 60,
		headerCssClass: "centered",
		cssClass: "centered",
		sortable: false,
		visible: true,
		resizable: false,
		formatter: Slick.Formatters.ValidatedIconFormatter
	}, {
		id: "id",
		name: "Payment ID",
		field: "id",
		toolTip: "Payment ID",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryname",
		name: "Beneficiary",
		field: "beneficiaryname",
		toolTip: "Beneficiary Name",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "beneficiaryaccountnumber",
		name: "Account",
		field: "beneficiaryaccountnumber",
		toolTip: "Beneficiary Account",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}, {
		id: "status",
		name: "Status",
		field: "status",
		toolTip: "Status",
		width: 200,
		sortable: true,
		visible: true,
		sorter: "sorterStringCompare"
	}];

	if (editingRecord.debitequivalentflag) {
		var currencyColumn = {
			id: "debitaccountcurrency",
			name: "Currency",
			field: "debitaccountcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			visible: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "debitequivalentamount",
			name: "Amount",
			field: "debitequivalentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			visible: true,
			formatter: Slick.Formatters.AmountFormatter
		}
	} else {
		var currencyColumn = {
			id: "paymentcurrency",
			name: "Currency",
			field: "paymentcurrency",
			toolTip: "Currency",
			width: 100,
			sortable: true,
			visible: true,
			sorter: "sorterStringCompare"
		}
		var amountColumn = {
			id: "paymentamount",
			name: "Amount",
			field: "paymentamount",
			toolTip: "Amount",
			headerCssClass: "righted",
			cssClass: "righted",
			sorter: "sorterNumeric",
			width: 200,
			sortable: true,
			visible: true,
			formatter: Slick.Formatters.AmountFormatter
		}
	}
	editColumns.push(currencyColumn);
	editColumns.push(amountColumn);
	var editOptions = {
		editable: false,
		enableAddRow: false,
		enableCellNavigation: false,
		enableColumnReorder: false,
		autoHeight: false,
		forceFitColumns: true,
		multiSelect: true
	};
	var editCheckboxSelector = new Slick.CheckboxSelectColumn({
		cssClass: "slick-cell-checkboxsel"
	});
	editColumns.unshift(editCheckboxSelector.getColumnDefinition());

	var $paymentDetailSection = $("#templateDetail");

	/* clear payment section */
	$paymentDetailSection.empty();

	/* view payment section */
	var $paymentDetailContainer = $("<div class='scroll-area py-ui' style='overflow-y: scroll; padding: 10px 30px 0 30px; bottom: 60px; background: #f5f5f5;' id='editPaymentContent' />");

	/* page title */
	var $pageTitle = $("<div class='page-section' />").appendTo($paymentDetailContainer),
		$titleSpan = $("<span>" + editingRecord.type + " Payment</span>").appendTo($pageTitle);

	/* detail section */
	var $paymentDataSection = $("<div class='grid-layout' />").appendTo($paymentDetailContainer);

	/* system information */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>System Information</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Payment ID</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + editingRecord.batchid + "</div>").appendTo($dataCol);
	if (editingRecord.notices) {
		var $data = $("<div class='data-text' />").appendTo($dataCol),
			$link = $("<a href='javascript:void(0)' title='Click To View Payment Alerts' style='color: #e98c3a;'><i class='fa fa-exclamation-triangle fa-fw'></i></a>").appendTo($data).on("click", function(e) {
				e.preventDefault();
				showPaymentNotificaitonsDialog($(this), editingRecord);
			});
	}
	var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Status</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text'>" + editingRecord.status + "</div>").appendTo($dataCol);


	/* division section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header-inline'>Select a Division</div>").appendTo($box),
		$boxContent = $("<div class='box-content-inline' />").appendTo($box),
		$dataRow = $("<div class='row' />").appendTo($boxContent),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$customSelect = $("<div class='custom-select' style='min-width: 300px;' />").appendTo($dataCol),
		$select = $("<select id='divisionSelectInput'><option value='Division ABC'>Division ABC</option><option value='Division 123'>Division 123</option></select>").appendTo($customSelect);


	/* from account and batch detail section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell halves' />").appendTo($sectionRow),
		$box = $("<div class='box' style='height: 230px;' />").appendTo($sectionCell),
		boxHeader = $("<div class='box-header'>From</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Debit Account</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$comboBox = $("<div class='combobox-div' style='width: 85%;' />").appendTo($dataCol),
		$input = $("<input type='text' id='debitAccountInput' value='" + editingRecord.debitaccountnumber + " - " + editingRecord.debitaccountname + " (" + editingRecord.debitcurrency + ")' />").appendTo($comboBox),
		$iconDiv = $("<div class='combobox-icon' />").appendTo($comboBox),
		$icon = $("<i class='fa fa-chevron-down fa-fw'></i>").appendTo($iconDiv),
		$searchLink = $("<a href='javascript:void(0)' id='searchDebitAccountsDialog' title='Find A Debit Account' style='color: #007dba;' />").appendTo($dataCol),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchLink),
		$autoCompleteDiv = $("<div id='debitAccountInputAutoComplete' />").appendTo($dataCol),
		$accountDetailSection = $("<div id='debitAccountDetailSection' />").appendTo($boxContent),
		$detailRow = $("<div class='grid-row' />").appendTo($accountDetailSection),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Available Balance</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' id='debitAccountAvailableBalance'>$" + editingRecord.debitaccountavailablebalance + "</div>").appendTo($dataCol),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Available Funds</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<div class='data-text' id='debitAccountAvailableFunds'>$" + editingRecord.debitaccountavailablefunds + "</div>").appendTo($dataCol),
		$sectionCell = $("<div class='grid-cell halves' />").appendTo($sectionRow),
		$box = $("<div class='box' style='height: 230px;' />").appendTo($sectionCell),
		boxHeader = $("<div class='box-header'>Batch Details</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Name</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$data = $("<input type='text' id='batchNameInput' style='width: 85%;' value='" + editingRecord.name + "' />").appendTo($dataCol),
		$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Paymnet Date</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$dateDiv = $("<div class='date-input-div' />").appendTo($dataCol),
		$data = $("<input type='text' id='batchPaymentDateInput' class='date-input' value='" + editingRecord.paymentdate + "' />").appendTo($dateDiv).datepicker({
			dateFormat: 'dd/mm/yy',
			constrainInput: true,
			changeMonth: true,
			changeYear: true,
			duration: 0,
			minDate: 0,
			showOn: "button",
			buttonImage: "img/datepicker-icon.png",
			buttonImageOnly: true,
			buttonText: "Select date",
			beforeShow: function() {
				var widget = $("#paymentDateInput").datepicker("widget");
				widget.appendTo($("#paymentDateCalendar"));
				$("#paymentDateCalendar").show();
			},
			onClose: function() {
				var widget = $("#paymentDateInput").datepicker("widget");
				widget.appendTo($("body"));
			}
		}).mask("99/99/9999", {
			placeholder: "dd/mm/yyyy"
		}),
		$datePickerDiv = $("<div class='date-picker-div' id='batchPaymentDateCalendar' />").appendTo($dateDiv),
		$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
		$dataRow = $("<div class='row mandatory' />").appendTo($detailCell),
		$labelCol = $("<div class='label-column' />").appendTo($dataRow),
		$label = $("<label>Paymnet Currency</label>").appendTo($labelCol),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$customSelect = $("<div class='custom-select'  style='width: 100px;' />").appendTo($dataCol),
		$select = $("<select id='batchPaymentCurrencySelection'><option value=''></option><option value='AUD'>AUD</option><option value='CNY'>CNY</option><option value='HKD'>HKD</option><option value='SGD'>SGD</option></select>").appendTo($customSelect).val(editingRecord.paymentcurrency);


	/* settings section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header-inline'>Settings</div>").appendTo($box),
		$boxContent = $("<div class='box-content-inline' />").appendTo($box),
		$dataRow = $("<div class='row' />").appendTo($boxContent),
		$dataCol = $("<div class='data-column' style='padding-left: 10px;' />").appendTo($dataRow);
	var $data = $("<input type='checkbox' id='individualDebitsFlag' />").appendTo($dataCol),
		$desc = $("<label class='desc' for='individualDebitsFlag'>Individual Debits</label>").appendTo($dataCol);
	if (editingRecord.individualdebitsflag) {
		$data.prop("checked", true);
	}
	if (editingRecord.type.indexOf("International") != -1) {
		var $data = $("<input type='checkbox' id='urgentFlag' />").appendTo($dataCol),
			$desc = $("<label class='desc' for='urgentFlag'>Urgent</label>").appendTo($dataCol);
		if (editingRecord.urgentflag) {
			$data.prop("checked", true);
		}
	}
	if (editingRecord.paymentcurrency != editingRecord.debitcurrency) {
		var $data = $("<input type='checkbox' id='debitFlag' />").appendTo($dataCol),
			$desc = $("<label class='desc' for='debitFlag'>Use Debit Currency</label>").appendTo($dataCol);
		if (editingRecord.debitequivalentflag) {
			$data.prop("checked", true);
		}
	}


	/* payment section */
	var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
		$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
		$box = $("<div class='box' />").appendTo($sectionCell),
		$boxHeader = $("<div class='box-header'>Payment Instructions</div>").appendTo($box),
		$boxContent = $("<div class='box-content top-label' />").appendTo($box),
		$boxDiv = $("<div />").appendTo($boxContent),
		$dataRow = $("<div class='row' />").appendTo($boxDiv),
		$dataCol = $("<div class='data-column' />").appendTo($dataRow),
		$inlineSearch = $("<div class='search-inline-payments' />").appendTo($dataCol),
		$addBtn = $("<span class='form-button primary' />").appendTo($inlineSearch),
		$addLink = $("<a href='javascript:void(0)' id='addPaymentsToBatch'><i class='fa fa-plus-square fa-fw'></i>Add</a>").appendTo($addBtn),
		$removeBtn = $("<span class='form-button' />").appendTo($inlineSearch),
		$removeLink = $("<a href='javascript:void(0)' id='removePaymentsFromBatch'><i class='fa fa-trash fa-fw'></i>Remove</a>").appendTo($removeBtn),
		$searchDiv = $("<div class='icon-input payment-grid-filter' />").appendTo($inlineSearch),
		$searchIcon = $("<div class='icon-input-icon'><i class='fa fa-search fa-fw'></i></div>").appendTo($searchDiv),
		$searchInput = $("<input type='text' placeholder='Search Payment Instructions' />").appendTo($searchDiv),
		$paymentInstructionGrid = $("<div class='payment-grid' id='editPaymentsGrid' />").appendTo($dataCol),
		$totalsDiv = $("<div style='padding: 15px 20px 0 20px;' />").appendTo($boxContent),
		$totalsRow = $("<div class='grid-row' />").appendTo($totalsDiv),
		$totalsCell = $("<div class='grid-cell' style='width: 100%; color: #4a494a; font-size: 14px; text-align: right;' />").appendTo($totalsRow),
		$totalInstructions = $("<div style='display: inline-block; vertical-align: top; margin-right: 25px;'>Number Of Instructions: &nbsp;<strong>" + editingRecord.numberofpayments + "</strong></div>").appendTo($totalsCell),
		$totalAmountsDiv = $("<div style='display: inline-block; vertical-align: top;' />").appendTo($totalsCell);
	if (editingRecord.paymentcurrency != editingRecord.debitcurrency) {
		if (editingRecord.debitequivalentflag) {
			var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.debitcurrency + " $" + addCommas(editingRecord.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='margin-top: 8px;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.paymentcurrency + " $" + addCommas(editingRecord.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
		} else {
			var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.paymentcurrency + " $" + addCommas(editingRecord.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv),
				$totalAmount = $("<div style='margin-top: 8px;'>Total Debit Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.debitcurrency + " $" + addCommas(editingRecord.totaldebitamount) + "</strong></div>").appendTo($totalAmountsDiv);
		}
	} else {
		var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;<strong style='font-size: 16px;'>" + editingRecord.paymentcurrency + " $" + addCommas(editingRecord.totalpaymentamount) + "</strong></div>").appendTo($totalAmountsDiv);
	}


	/* fx section */
	if ((editingRecord.paymentcurrency != editingRecord.debitcurrency) && !editingRecord.individualdebitsflag) {
		var $sectionRow = $("<div class='grid-row' />").appendTo($paymentDataSection),
			$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
			$box = $("<div class='box' />").appendTo($sectionCell),
			$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Rate Type</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$customSelect = $("<div class='custom-select' />").appendTo($dataCol),
			$data = $("<select id='fxSelection'><option value='Carded'>Carded</option><option value='Contract'>Contract</option></select>").appendTo($customSelect).val(editingRecord.ratetype);
		if (editingRecord.ratetype == "Carded") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Rate</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + editingRecord.rate + " &nbsp;&nbsp; 1 " + editingRecord.fromccy + " &nbsp; = &nbsp; " + (1 * editingRecord.rate) + " " + editingRecord.toccy + "</div>").appendTo($dataCol),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
		} else if (editingRecord.ratetype == "Contract") {
			var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>&nbsp;</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$searchFXBtn = $("<span class='form-button primary' />").appendTo($dataCol),
				$searchFXLink = $("<a href='javascript:void(0)' id='fxContractSearch'><i class='fa fa-search fa-fw'></i>Find &amp; Add Contracts</a>").appendTo($searchFXBtn),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
			var _remaining = 0;
			for (var x = 0, y = editingRecord.contracts.length; x < y; x++) {
				_remaining = (Number(_remaining) + Number(editingRecord.contracts[x].used));
				var $dataTableRow = $("<div class='data-table-row' data-contract-row='true' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' />").appendTo($dataTableRow),
					$removeLink = $("<a href='javascript:void(0)' data-contract-id='" + editingRecord.contracts[x].id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($dataTableCell),
					$contractSpan = $("<span>" + editingRecord.contracts[x].reference + "</span>").appendTo($dataTableCell),
					$dataTableCell = $("<div class='data-table-cell'>" + editingRecord.contracts[x].clientid + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(editingRecord.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + editingRecord.contracts[x].rate + "</div>").appendTo($dataTableRow),
					$dataTableCell = $("<div class='data-table-cell' style='text-align: right;' />").appendTo($dataTableRow),
					$usedInput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + editingRecord.contracts[x].id + "' value='" + addCommas(editingRecord.contracts[x].used) + "' />").appendTo($dataTableCell);
			}
			var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
				$cardedRateCheckbox = $("<input type='checkbox' id='usedCardedRateFlag' class='disabled' disabled='disabled' />").appendTo($dataTableCell),
				$cardedRateLabel = $("<label class='desc disabled' id='useCardedRateFlagLabel' for='usedCardedRateFlag'>Use Carded Rate For Remaining Amount</label>").appendTo($dataTableCell),
				$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
			var _remaining = Number(_remaining).toFixed(2);
			if (editingRecord.debitequivalentflag) {
				if (_remaining == editingRecord.totaldebitamount) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < editingRecord.totaldebitamount) {
					var _amt = (Number(editingRecord.totaldebitamount) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > editingRecord.totaldebitamount) {
					var _amt = (Number(_remaining) - Number(editingRecord.totaldebitamount)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			} else {
				if (_remaining == editingRecord.totalpaymentamount) {
					var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
				} else if (_remaining < editingRecord.totalpaymentamount) {
					var _amt = (Number(editingRecord.totalpaymentamount) - Number(_remaining)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				} else if (_remaining > editingRecord.totalpaymentamount) {
					var _amt = (Number(_remaining) - Number(editingRecord.totalpaymentamount)).toFixed(2);
					var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
				}
			}
		}
	}



	/* buttons */
	var $paymentButtonContainer = $("<div style='position: absolute; bottom: 0; right: 0; left: 0; border-top: 1px solid #d7d7d7; text-align: center; white-space: nowrap; padding: 10px 0; overflow: hidden; background: #fff;' />");
	var $closeButton = $("<span class='form-button' id='closeButton' />").appendTo($paymentButtonContainer),
		$closeLink = $("<a href='#templateList' title='Close Payment' data-panel='#templateList' data-switch='switch-panels'><i class='fa fa-ban fa-fw'></i><span>Cancel</span></a></span>").appendTo($closeButton).on("click", function(e) {
			record = null;
			$(window).off("resize.reviewgrid");
			$("#viewPaymentContent").remove();
			updateBreadcrumb("close");
		});


	/* attach the content */
	$paymentDetailContainer.appendTo($paymentDetailSection);
	$paymentButtonContainer.appendTo($paymentDetailSection);


	/* instruction dialog */
	function triggerInstructionDialog(_target, item) {
		function renderPaymentInstructionDetails() {

			var instruction = item;

			var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewInstructionDialog' />");

			/* system information */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>System Information</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Payment ID</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.id + "</div>").appendTo($dataCol),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($dataRow),
				$label = $("<label>Status</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$data = $("<div class='data-text'>" + instruction.status + "</div>").appendTo($dataCol);


			if (instruction.status == "Needs Repair") {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box error' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>Errors</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$boxDiv = $("<div />").appendTo($boxContent),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$data = $("<div class='data-text'>This payment instruction has the following errors:</div>").appendTo($dataCol),
					$dataRow = $("<div class='row' />").appendTo($boxDiv),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$errorGrid = $("<div class='payment-grid' style='height: auto; max-height: 200px; overflow-y: scroll;' id='errorsGrid' />").appendTo($dataCol),
					$errorList = $("<ul class='error-list' />").appendTo($errorGrid);
				for (var e = 0, f = instruction.errors.length; e < f; e++) {
					var $errorLi = $("<li><span class='error-icon'><i class='fa fa-exclamation-triangle fa-fw'></i></span><span class='error-text'>" + instruction.errors[e].description + "</span></li>").appendTo($errorList);
				}
			}


			/* beneficiary section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>To</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row mandatory' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Beneficiary</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$comboBoxDiv = $("<div class='combobox-div' style='width: 65%;' />").appendTo($dataCol),
				$comboBoxInput = $("<input type='text' value='" + instruction.beneficiaryname + "' id='instBene' placeholder='Type in a beneficiary name or account number' />").appendTo($comboBoxDiv),
				$comboBoxIcon = $("<div class='combobox-icon' id='instBeneControl'><i class='fa fa-chevron-down fa-fw'></i></div>").appendTo($comboBoxDiv),
				$comboBoxSearch = $("<a href='javascript:void(0)' id='instBeneSearch' title='Find a beneficiary' class='form-icon'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Account Number</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + instruction.beneficiaryaccountnumber + "</div>").appendTo($dataCol);
			if (instruction.beneficiary.benelocalname != "") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Local Language Name</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$data = $("<div class='data-text'>" + instruction.beneficiary.benelocalname + "</div>").appendTo($dataCol);
			}
			if (record.type.indexOf("International") != -1) {
				var bank = instruction.beneficiary.swiftbank,
					bankbranch = instruction.beneficiary.swiftbranch,
					bankcountry = instruction.beneficiary.swiftbankcountry,
					bankcode = instruction.beneficiary.swiftcode + " (SWIFT)";
			} else {
				var bank = instruction.beneficiary.benebank,
					bankbranch = instruction.beneficiary.benebankbranch,
					bankcountry = instruction.beneficiary.benebankcountry,
					bankcode = instruction.beneficiary.benebankclearingcode + " (" + instruction.beneficiary.benebankclearingtype + ")";
			}
			var $detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Bank Details</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$dataGroup = $("<div class='input-group' />").appendTo($dataCol),
				$data = $("<div class='data-text'>" + bank + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankbranch + "</div>").appendTo($dataGroup),
				$data = $("<div class='data-text'>" + bankcountry + "</div>").appendTo($dataGroup),
				$detailCell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Clearing</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text'>" + bankcode + "</div>").appendTo($dataCol);


			/* payment details section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row mandatory' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Method</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol),
				$select = $("<select id='instPaymentMethod'><option value=''><option><option value='" + instruction.paymentmethod + "'>" + instruction.paymentmethod + "<option></select>").appendTo($customSelect).val(instruction.paymentmethod),
				$row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Date</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentdate + "</div>").appendTo($dataCol);

			if (record.individualdebitsflag) {
				if (record.paymentcurrency != record.debitcurrency) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol),
						$row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			} else {
				if (record.debitequivalentflag) {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.debitaccountcurrency + " $" + addCommas(instruction.debitequivalentamount) + "</div>").appendTo($dataCol);
				} else {
					var $row = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($row),
						$data = $("<div class='data-text' style='font-size: 16px;'>" + instruction.paymentcurrency + " $" + addCommas(instruction.paymentamount) + "</div>").appendTo($dataCol);
				}
			}


			var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
				$row = $("<div class='row mandatory' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Payment Reference</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<input type='text' style='width: 85%' value='" + instruction.paymentreference + "' id='instPaymentReference' />").appendTo($dataCol);

			if (instruction.paymentmethod == "BEPS" || instruction.paymentmethod == "DHVPS" || instruction.paymentmethod == "CBHVPS") {
				var $row = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($row),
					$label = $("<label>Purpose Code</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($row),
					$customSelect = $("<div class='custom-select' />").appendTo($dataCol);
				if (instruction.paymentmethod == "CBHVPS") {
					var $select = $("<select id='instPurposeCode'><option value=''></option><option value='02112 - 货物贸易结算 Goods trade settlement'>02112 - 货物贸易结算 Goods trade settlement</option><option value='02113 - 货物贸易结算退款 Goods trade settlement refund'>02113 - 货物贸易结算退款 Goods trade settlement refund</option><option value='02114 - 服务贸易结算 Service trade settlement'>02114 - 服务贸易结算 Service trade settlement</option><option value='02115 - 服务贸易结算退款 Service trade settlement refund'>02115 - 服务贸易结算退款 Service trade settlement refund</option><option value='02116 - 资本项下跨境支付 X-border pmt under capital acc'>02116 - 资本项下跨境支付 X-border pmt under capital acc</option><option value='02117 - 资本项下跨境支付退款 X-border pmt refund capital'>02117 - 资本项下跨境支付退款 X-border pmt refund capital</option><option value='02125 - 其他经常项目支出 Other current acc transactions'>02125 - 其他经常项目支出 Other current acc transactions</option></select>").appendTo($customSelect).val(instruction.purposecode);

				} else {
					var $select = $("<select id='instPurposeCode'><option value=''></option><option value='02102 - 普通汇兑 Common exchange'>02102 - 普通汇兑 Common exchange</option></select>").appendTo($customSelect).val(instruction.purposecode);
				}
			}
			var $row = $("<div class='row' />").appendTo($detailCell),
				$labelCol = $("<div class='label-column' />").appendTo($row),
				$label = $("<label>Remittance Information</label>").appendTo($labelCol),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$data = $("<textarea style='width: 85%; height: 100px;' id='instRemittance'>" + instruction.remittanceinformation + "</textarea>").appendTo($dataCol);

			if ((record.paymentcurrency != record.debitcurrency) && record.individualdebitsflag) {
				var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
					$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
					$box = $("<div class='box' />").appendTo($sectionCell),
					$boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box),
					$boxContent = $("<div class='box-content top-label' />").appendTo($box),
					$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
					$detailCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($detailRow),
					$dataRow = $("<div class='row' />").appendTo($detailCell),
					$labelCol = $("<div class='label-column' />").appendTo($dataRow),
					$label = $("<label>Rate Type</label>").appendTo($labelCol),
					$dataCol = $("<div class='data-column' />").appendTo($dataRow),
					$customSelect = $("<div class='custom-select' />").appendTo($dataCol),
					$selet = $("<select id='instRateType'><option value='Carded'>Carded</option><option value='Contract'>Contract</option></select>").appendTo($customSelect).val(instruction.ratetype);
				if (instruction.ratetype == "Carded") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>Rate</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-text'>" + instruction.rate + " &nbsp;&nbsp; 1 " + instruction.fromccy + " &nbsp; = &nbsp; " + (1 * instruction.rate) + " " + instruction.toccy + "</div>").appendTo($dataCol),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$data = $("<div class='data-note'>* Foreign Exchange Rate provided is indicative only and subject to change by the Bank at any time without notice.</div>").appendTo($dataCol);
				} else
				if (instruction.ratetype == "Contract") {
					var $detailCell = $("<div class='grid-cell' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$labelCol = $("<div class='label-column' />").appendTo($dataRow),
						$label = $("<label>&nbsp;</label>").appendTo($labelCol),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$searchFXBtn = $("<span class='form-button primary' />").appendTo($dataCol),
						$searchFXLink = $("<a href='javascript:void(0)' id='instContractSearch'><i class='fa fa-search fa-fw'></i>Find &amp; Add Contracts</a>").appendTo($searchFXBtn),
						$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
						$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
						$dataRow = $("<div class='row' />").appendTo($detailCell),
						$dataCol = $("<div class='data-column' />").appendTo($dataRow),
						$dataTable = $("<div class='data-table' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Contract ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Rate</div>").appendTo($dataTableRow),
						$dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
					var _remaining = 0;
					for (var x = 0, y = instruction.contracts.length; x < y; x++) {
						_remaining = (Number(_remaining) + Number(instruction.contracts[x].used));
						var $dataTableRow = $("<div class='data-table-row' data-contract-row='true' />").appendTo($dataTable),
							$dataTableCell = $("<div class='data-table-cell' />").appendTo($dataTableRow),
							$removeLink = $("<a href='javascript:void(0)' data-contract-id='" + instruction.contracts[x].id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($dataTableCell),
							$contractSpan = $("<span>" + instruction.contracts[x].reference + "</span>").appendTo($dataTableCell),
							$dataTableCell = $("<div class='data-table-cell'>" + instruction.contracts[x].clientid + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + addCommas(instruction.contracts[x].total.toFixed(2)) + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;'>" + instruction.contracts[x].rate + "</div>").appendTo($dataTableRow),
							$dataTableCell = $("<div class='data-table-cell' style='text-align: right;' />").appendTo($dataTableRow),
							$usedInput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + instruction.contracts[x].id + "' value='" + addCommas(instruction.contracts[x].used) + "' />").appendTo($dataTableCell);
					}
					var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol),
						$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow),
						$cardedRateCheckbox = $("<input type='checkbox' id='usedInstructionCardedRateFlag' class='disabled' disabled='disabled' />").appendTo($dataTableCell),
						$cardedRateLabel = $("<label class='desc disabled' id='usedInstructionCardedRateLabel' for='usedInstructionCardedRateFlag'>Use Carded Rate For Remaining Amount</label>").appendTo($dataTableCell),
						$dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
					var _remaining = Number(_remaining).toFixed(2);
					if (record.debitequivalentflag) {
						if (_remaining == instruction.debitequivalentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.debitequivalentamount) {
							var _amt = (Number(instruction.debitequivalentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.debitequivalentamount) {
							var _amt = (Number(_remaining) - Number(instruction.debitequivalentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					} else {
						if (_remaining == instruction.paymentamount) {
							var $remainingSpan = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i>  Remaining Amount: 0.00</span>").appendTo($dataTableCell);
						} else if (_remaining < instruction.paymentamount) {
							var _amt = (Number(instruction.paymentamount) - Number(_remaining)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						} else if (_remaining > instruction.paymentamount) {
							var _amt = (Number(_remaining) - Number(instruction.paymentamount)).toFixed(2);
							var $remainingSpan = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(_amt) + "</span>").appendTo($dataTableCell);
						}
					}

				}
			}

			var uploadSupportingDocumentInteraction = function() {
				$("#progressBar").show();
				$(".progress-meter").animate({
					width: "100%"
				}, 3000, function() {
					$("#progressBar").hide();
					$(".progress-meter").css("width", 0);
					$("#instAttachSupportingDoc").val('');
					var _doc = {
						id: randString(20),
						filename: "SupportingDocument1FileName.pdf",
						filesize: "827kb",
						status: "Performing Virus Scan"
					}
					var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />"),
						$fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
						$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell),
						$documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell),
						$statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "<i class='ellipsis-loader' /></div>").appendTo($dataTableRow);
					$dataTableRow.appendTo($("div[data-supporting-docs='" + instruction.id + "']"));
					var _rand = rand(0, 2);
					if (_rand == 0) {
						setTimeout(function() {
							$documentLink.css("color", "#c91b01");
							$removeLink.css("color", "#c91b01");
							$statusTableCell.empty().html("Virus Scan Failed");
							_doc.status == "Virus Scan Failed";
						}, 4000);
					} else {
						setTimeout(function() {
							$documentLink.remove();
							$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($fileInfoCell);
							$statusTableCell.empty().html("Attached");
							_doc.status == "Attached";
						}, 4000);
					}
				});
			}


			/* supporting documents section */
			var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
				$sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
				$box = $("<div class='box' />").appendTo($sectionCell),
				$boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box),
				$boxContent = $("<div class='box-content top-label' />").appendTo($box),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$row = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($row),
				$buttonSpan = $("<span class='form-button primary' id='uploadButton' />").appendTo($dataCol),
				$buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Attach File</a>").appendTo($buttonSpan),
				$fileInput = $("<input type='file' name='file' id='instAttachSupportingDoc' style='position: absolute; left: 30px; padding: 0; width: 155px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($buttonSpan).on('change', uploadSupportingDocumentInteraction),
				$progressDiv = $("<div id='progressBar' style='display: none;' />").appendTo($dataCol),
				$progressBar = $("<div class='progress-bar'></div>").appendTo($progressDiv),
				$progressMeter = $("<div class='progress-meter' />").appendTo($progressBar),
				$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
				$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
				$dataRow = $("<div class='row' />").appendTo($detailCell),
				$dataCol = $("<div class='data-column' />").appendTo($dataRow),
				$dataTable = $("<div class='data-table' data-supporting-docs='" + instruction.id + "' />").appendTo($dataCol),
				$dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable),
				$dataTableCell = $("<div class='data-table-cell' style='width: 70%;'>File Name</div>").appendTo($dataTableRow),
				$dataTableCell = $("<div class='data-table-cell' style='width: 30%;'>Status</div>").appendTo($dataTableRow);

			for (var x = 0, y = instruction.supportingdocs.length; x < y; x++) {
				_doc = instruction.supportingdocs[x];
				var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />").appendTo($dataTable),
					$dataTableCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
					$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($dataTableCell),
					$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($dataTableCell),
					$dataTableCell = $("<div class='data-table-cell'>" + _doc.status + "</div>").appendTo($dataTableRow);
			}

			return $dialogContent;
		}
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "editPaymentInstruction",
			title: "Payment Instruction",
			size: "xl",
			icon: "<i class='fa fa-money'></i>",
			content: function() {
				return renderPaymentInstructionDetails();
			},
			buttons: [{
				name: "Close",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	}


	/* initialise the view payments grid */
	editData = editingRecord.payments;
	var editItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	editDataView = new Slick.Data.DataView({
		editItemMetaProvider: editItemMetaProvider
	});
	editGrid = new Slick.Grid("#editPaymentsGrid", editDataView, editColumns, editOptions);
	editGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	editGrid.registerPlugin(editItemMetaProvider);
	editGrid.registerPlugin(editCheckboxSelector);
	editGrid.onSort.subscribe(function(e, args) {
		editDataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	editGrid.onClick.subscribe(function(e, args) {
		var cell = editGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = editDataView.getItem(row);
		triggerInstructionDialog($(e.target), item);
	});
	editDataView.beginUpdate();
	editDataView.setItems(editData);
	editDataView.endUpdate();
	editGrid.setColumns(editColumns);
	$(window).on("resize.editgrid", function() {
		editGrid.resizeCanvas();
	});
	$(window).on("resize.editgrid", _.debounce(function(e) {
		editGrid.resizeCanvas();
	}, 100));
}


/**********************************************************************
UPDATE THE BREADCRUMB
**********************************************************************/
function updateBreadcrumb(update) {
	var $breadcrumb = $("div.application-breadcrumb");
	var $b3 = $("span[data-ref='b3']");
	var $b3Link = $("<a href='payments-templates.html'>Templates</a>");
	var $b4 = $("<span data-ref='b4' />");
	$("span[data-ref='b4']").remove();
	if (update == "view") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Template Details");
	} else if (update == "edit") {
		$b3.empty();
		$b3Link.appendTo($b3);
		$b4.appendTo($breadcrumb).html("Edit Template");
	} else if (update == "close") {
		$("span[data-ref='b4']").remove();
		$b3.empty().html("Templates");
	}
}


/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


	/**********************************************************************
	POPULATE TEMPLATE FOLDERS
	**********************************************************************/
	populateFolders();


	/**********************************************************************
	INITIALIZE TEMPLATE GRID
	**********************************************************************/
	var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		groupItemMetadataProvider: groupItemMetadataProvider
	});
	grid = new Slick.Grid("#templateGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(groupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'paymentTemplatesColumnOrder', 'paymentTemplatesColumnWidths', ["checkboxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu = $("#contextMenu");
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row]);
		}
		grid.setActiveCell(row, cell.cell)
		setupContextMenu();
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");

		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").children(".on").removeClass("on");
		selectedRowIds = [];
		selectedRowStates = [];
		selectedRowWorkflows = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) {
				selectedRowIds.push(item.id);
				selectedRowStates.push(item.status);
				selectedRowWorkflows.push(item.workflow);
			}
		}
		if (selectedRowIds.length > 0) {
			$("#templateGrid").addClass("has-bottom-controls");
			$("#templateList .bottom-controls").removeClass("hidden");
			$("#selectedCount").html(selectedRowIds.length);
			grid.resizeCanvas();
		} else {
			$("#templateGrid").removeClass("has-bottom-controls");
			$("#templateList .bottom-controls").addClass("hidden");
			$("#selectedCount").html('');
			grid.resizeCanvas();
		}
	});
	grid.onClick.subscribe(function(e, args) {
		row = args.row, $row = $(e.target).closest(".slick-row");
		if (!$row.is(".slick-group, .slick-group-totals")) {
			$row.attr({
				'data-panel': '#templateDetail',
				'data-switch': 'switch-panels'
			}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
			record = dataView.getItem(row);
			viewPaymentDetails(record);
			grid.setSelectedRows([]);
			selectedRowIds = [];
		}
	});
	grid.onSort.subscribe(function(e, args) {
		dataView.sort(function(dataRow1, dataRow2) {
			sortdir = args.sortAsc ? 1 : -1;
			sortcol = args.sortCol.field;
			var _sorter = args.sortCol.sorter,
				result;
			if (_sorter == "sorterStringCompare") {
				result = sorterStringCompare(dataRow1, dataRow2);
			} else if (_sorter == "sorterNumeric") {
				result = sorterNumeric(dataRow1, dataRow2);
			} else if (_sorter == "sorterDateIso") {
				result = sorterDateIso(dataRow1, dataRow2);
			} else if (_sorter == "sorterTime") {
				result = sorterTime(dataRow1, dataRow2);
			}
			if (result != 0) {
				return result;
			}
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('paymentTemplatesColumnWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({
		statusString: statusString,
		workflowString: workflowString,
		userString: userString,
		searchString: searchString
	});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('paymentTemplatesColumnOrder')) {
		var visibleAdHocColumns = [];
		for (var i = 0; i < store.get('paymentTemplatesColumnOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleAdHocColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleAdHocColumns);
	}
	grid.setHeaderRowVisibility(false);


	/**********************************************************************
	GRID RESIZER
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));


	/**********************************************************************
	TEMPLATE VIEWS
	**********************************************************************/
	$("#viewWorkflowFilter").on("click.filter-view", function(e) {
		e.preventDefault();
		var $target = $(e.target);
		if ($target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set")) {
			var status = $target.attr("data-status"),
				workflow = $target.attr("data-workflow"),
				user = $target.attr("data-user");
			if (!status) {
				statusString = ""
			}
			if (statusString != status) {
				statusString = status
			}
			if (!workflow) {
				workflowString = ""
			}
			if (workflowString != workflow) {
				workflowString = workflow
			}
			if (!user) {
				userString = ""
			}
			if (userString != user) {
				userString = user
			}
			paymentsViewFilter();
		}
	});
	$(".manage-folders").on("click", showFolderManagerDialog);
	$("#_inlineFolderButton").on("click", addFolderInline);
	$("#_inlineFolderInput").bind("keyup.add-folder", function(e) {
		if (e.keyCode == 13) {
			addFolderInline();
		}
	});


	/**********************************************************************
	GROUPING
	**********************************************************************/
	$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
		e.preventDefault();
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text();
		groupBy(item, text);
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});


	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);


	/**********************************************************************
	ACTIONS
	**********************************************************************/
	$("#actionMenuControl").on("click", function(e) {
		e.preventDefault();
		setupContextMenu();
	});
	$("[data-action='reject']").on("click", rejectRecordFromList);
	$("[data-action='approve']").on("click", approveRecordFromList);


	/**********************************************************************
	SETTINGS
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});


	/**********************************************************************
	JUMP TO TEMPLATE DETAILS
	**********************************************************************/
	var b = document.location.href.split(".html")[1];

	if (b == "#detail") {
		$("#templateGrid").find("div[row='1'] div.slick-cell").eq(2).trigger("click")
		document.location.hash = '';
	}


});