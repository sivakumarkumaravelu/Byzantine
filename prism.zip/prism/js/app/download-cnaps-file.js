$(function() {

	$("#cnapsupdatedate").datepicker({
		dateFormat: 'dd/mm/yy',
		constrainInput: true,
		changeMonth: true,
		changeYear: true,
		duration: 0,
		maxDate: 0,
		showOn: "button",
		buttonImage: "img/datepicker-icon.png",
		buttonImageOnly: true,
		buttonText: "Select date",
		beforeShow: function() {
			var widget = $("#cnapsupdatedate").datepicker("widget");
			widget.appendTo($("#cnapsupdatecal"));
			$("#cnapsupdatecal").show();
		},
		onClose: function() {
			var widget = $("#cnapsupdatedate").datepicker("widget");
			widget.appendTo($("body"));
		}
	}).mask("99/99/9999", {
		placeholder: "dd/mm/yyyy"
	}).on("change", function() {
		var $row = $(this).closest("div.row"),
			$dataCol = $(this).closest("div.data-column");
		if ($(this).val()) {
			if ($row.hasClass('error')) {
				$row.removeClass("error").find("div.data-error").remove();
			}
			var stringval = $(this).val(),
				testdate;
			try {
				testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
				$("#dop2").prop("checked", true);
			} catch (e) {
				$row.addClass("error");
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Date is not valid");
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Date is not valid");
				}
			} finally {
				if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) > 0) {
					$row.addClass("error");
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Date cannot be in the future");
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Date cannot be in the future");
					}
				}
			}
		} else {
			if ($row.hasClass('error')) {
				$row.removeClass("error").find("div.data-error").remove();
			}
		}
	});

});