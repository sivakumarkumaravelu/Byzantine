/**********************************************************************
DATA
**********************************************************************/
var ACCOUNTS = [{name: "Primary Savings Account", number: "113-6677-322", currency: "AUD", funds: "12,000.00", available: "12,000.00", balance: "12,000.00"}, {name: "Funding Account Singapore", number: "456-8888-125", currency: "SGD", funds: "32,101.53", available: "32,101.53", balance: "32,101.53"}, {name: "Loan Repayment Account", number: "684-2345-111", currency: "SGD", funds: "6,130.00", available: "6,130.00", balance: "6,130.00"}, {name: "Operations Account", number: "334-3566-122", currency: "AUD", funds: "8,456.31", available: "8,456.31", balance: "8,456.31"}, {name: "Current Account", number: "888-3354-355", currency: "HKD", funds: "17,257.91", available: "17,257.91", balance: "17,257.91"}, {name: "Funding Account China", number: "356-5788-009", currency: "HKD", funds: "57,774.31", available: "57,774.31", balance: "57,774.31"}, {name: "India Operations", number: "433-3566-123", currency: "INR", funds: "76,730.00", available: "76,730.00", balance: "76,730.00"}, {name: "Legal Operations Account", number: "112-6578-244", currency: "AUD", funds: "108,456.31", available: "108,456.31", balance: "108,456.31"}, {name: "Trade Account", number: "333-3555-122", currency: "SGD", funds: "27,257.31", available: "27,257.31", balance: "27,257.31"}, {name: "Secondary Savings Account", number: "111-1222-245", currency: "AUD", funds: "207,774.31", available: "207,774.31", balance: "207,774.31"}, {name: "India Legal", number: "344-1678-999", currency: "INR", funds: "500,000.00", available: "500,000.00", balance: "500,000.00"}, {name: "India Financing", number: "311-3556-133", currency: "INR", funds: "700,000.00", available: "700,000.00", balance: "700,000.00"}, {name: "Thai Operations", number: "777-3123-663", currency: "THB", funds: "1,000,000.00", available: "1,000,000.00", balance: "1,000,000.00"}, {name: "THB Legal", number: "334-1456-123", currency: "THB", funds: "2,632,012.64", available: "2,632,012.64", balance: "2,632,012.64"}];
var SWIFT_CODES = [{name: 'Merchant Group - 1', number: 'BNK'}, {name: 'Merchant Group - 2', number: 'BOE'}, {name: 'Merchant Group - 3', number: 'BRF'}, {name: 'Merchant Group - 4', number: 'CAR'}, {name: 'Merchant Group - 5', number: 'CAS'}, {name: 'Merchant Group - 6', number: 'CHG'}, {name: 'Merchant Group - 7', number: 'CHK'}, {name: 'Merchant Group - 8', number: 'CLR'}];
var BAI_CODES = [{name: '101', number: 'Description...'}, {name: '102', number: 'Description...'}, {name: '103', number: 'Description...'}, {name: '104', number: 'Description...'}, {name: '105', number: 'Description...'}, {name: '106', number: 'Description...'}, {name: '107', number: 'Description...'}, {name: '108', number: 'Description...'}, {name: '109', number: 'Description...'}, {name: '110', number: 'Description...'}, {name: '111', number: 'Description...'}, {name: '112', number: 'Description...'}, {name: '113', number: 'Description...'}, {name: '114', number: 'Description...'}, {name: '115', number: 'Description...'}];
var TRANTYPE_CODES = [{name: 'Sweep Credit', number: 'CMI-S'}, {name: 'Intercompany Loan Transfer', number: 'CMI-S'}, {name: 'Intercompany Interest transfer', number: 'CMI-S'}, {name: 'Notional Pooling Interest', number: 'CMI-NP'}, {name: 'Domestic Clearing Transaction', number: 'PAY IN'}, {name: 'Bankers Cheque/ Demand Draft/ Cashiers Order', number: 'CHEQUE'}, {name: 'Book Transfer to ANZ account', number: 'PAY IN'}, {name: 'Cash Deposit', number: 'CASH'}, {name: 'Cheque Deposit', number: 'CHEQUE'}, {name: 'Same day funds transfer', number: 'PAY IN'}, {name: 'Cross Border Credit Transfer', number: 'INT PYMT'}, {name: 'Return - Domestic Clearing transaction', number: 'RETURNED'}, {name: 'Return - Same day funds transfer', number: 'RETURNED'}, {name: 'Return - Cross border transfer', number: 'RETURNED'}, {name: 'Return - Book transfer ', number: 'RETURNED'}, {name: 'Return - Direct Debit Collection', number: 'RETURNED'}, {name: 'Direct Debit Authorisation', number: 'DIR DEB'}, {name: 'Direct Debit', number: 'DIR DEB'}, {name: 'Direct Debit Collection', number: 'DIR DEB'}, {name: 'Return - Cheques', number: 'RETURNED'}, {name: 'Return - Direct Debit', number: 'RETURNED'}, {name: 'CREDIT', number: 'CREDIT'}, {name: 'Sweep debit', number: 'CMI-S'}, {name: 'Domestic transfer', number: 'CMI-S'}, {name: 'Domestic Clearing Transaction', number: 'DEBIT'}, {name: 'Book Transfer to ANZ account', number: 'DEBIT'}, {name: 'Cash Withdrawal', number: 'CASH'}, {name: 'Payroll', number: 'PAYROLL'}, {name: 'Payroll return', number: 'RETURNED'}, {name: 'CORR CHQ WDL', number: 'CHEQUE'}, {name: 'CORR-CHQ TFR DD/TT', number: 'CHEQUE'}, {name: 'MULTI DEPOSIT', number: 'CASH'}, {name: 'CREDIT', number: 'CASH'}, {name: 'DEPOSIT', number: 'CASH'}, {name: '3RD PARTY WITHDRAWAL', number: 'CASH'}, {name: 'NO CHEQUE WITHDRAWAL', number: 'CASH'}, {name: 'DRAFT ISSUE', number: 'CASH'}, {name: 'CASH/CHQ DEP', number: 'CASH'}, {name: 'SWIFT TXN - CR TO VOSTRO', number: 'CASH'}, {name: 'MULTI WITHDRAWAL', number: 'CASH'}, {name: 'CORR CASH DEPOSIT', number: 'CASH'}, {name: 'CORR DRAFT FROM ACCOUNT', number: 'CASH'}, {name: 'CORR DRAFT FROM CASH', number: 'CASH'}, {name: 'CORR CREDIT', number: 'CASH'}, {name: 'CORR CONSOLIDATED DEP', number: 'CASH'}, {name: 'COR FORCED GROUP CREDIT', number: 'CASH'}, {name: 'CORR CEMTEX TRANS', number: 'CASH'}, {name: 'CORR TRAV CHEQUE DEP', number: 'CASH'}, {name: 'CORR DEBIT', number: 'CASH'}, {name: 'CLOSE ACCOUNT BY CASH', number: 'CASH'}, {name: 'CLOSE ACCOUNT DEBIT', number: 'CASH'}, {name: 'ATM CASH DEPOSIT', number: 'CASH'}, {name: 'POS RFND', number: 'CASH'}, {name: 'MULTI DEPOSIT (ATM)', number: 'CASH'}, {name: 'CREDIT TRANSACTION (ATM)', number: 'CASH'}, {name: 'BILL PAY DEBIT (ATM/INTERNET BANKING/MPTU)', number: 'CASH'}, {name: 'ATM CSH WDL', number: 'CASH'}, {name: 'POS PURCH', number: 'CASH'}, {name: 'EFTPOS CSH ADV', number: 'CASH'}, {name: 'MULTI WITHDRAWAL (ATM)', number: 'CASH'}, {name: 'NO CHEQUE WDL (ATM)', number: 'CASH'}, {name: 'CORR ATM CASH DEPOSIT', number: 'CASH'}, {name: 'COR POS RFND', number: 'CASH'}, {name: 'CORR CREDIT TRANS (ATM)', number: 'CASH'}, {name: 'COR ATM CSH WDL', number: 'CASH'}, {name: 'COR POS PURCH', number: 'CASH'}, {name: 'COR E/POS CSH ADV', number: 'CASH'}, {name: 'ATM MINI STATEMENT PRINT', number: 'CASH'}, {name: 'O.S CASH DEPOSIT', number: 'CASH'}, {name: 'O.S CREDIT', number: 'CASH'}, {name: 'O.S. CASH WITHDRAWAL', number: 'CASH'}, {name: 'O.S 3RD PARTY WITHDRAWAL', number: 'CASH'}, {name: 'CORR O.S. CASH DEPOSIT', number: 'CASH'}, {name: 'CROSS CURRENCY TXN', number: 'MISC DEBIT'}, {name: 'REVOLVING CR CSH ADV', number: 'MISC DEBIT'}, {name: 'GENERATED CASH DEDUCTION', number: 'MISC DEBIT'}, {name: 'GENERATED DEDUCTION', number: 'MISC DEBIT'}, {name: 'CORR DRAFT DEP ACCOUNT', number: 'MISC DEBIT'}, {name: 'CORR INT BR CROSS CCY', number: 'MISC DEBIT'}, {name: 'CORR CROSS CURRENCY', number: 'MISC DEBIT'}, {name: 'CORR REVOLV CR CSH ADV', number: 'MISC DEBIT'}, {name: 'CORR GENR CASH DEDUCTION', number: 'MISC DEBIT'}, {name: 'CORR GENERATED DEDUCTION', number: 'MISC DEBIT'}, {name: 'CURRENCY TRANSACTION', number: 'MISC DEBIT'}, {name: 'CORR CCY TRANSACTION', number: 'MISC DEBIT'}, {name: 'CROSS CCY', number: 'MISC DEBIT'}, {name: 'CHANGE BACKDATED', number: 'MISC DEBIT'}, {name: 'ACCT CHQ PAYMENT', number: 'MISC DEBIT'}, {name: 'CORR REVOLV CASH ADV', number: 'MISC DEBIT'}, {name: 'REVOLV CR TRF ADV', number: 'MISC DEBIT'}, {name: 'GENR CASH DEDUCTION', number: 'MISC DEBIT'}, {name: 'GENR DEDUCTION', number: 'MISC DEBIT'}, {name: 'CORR GENR CASH POST', number: 'MISC DEBIT'}, {name: 'CORR GENR POSTING', number: 'MISC DEBIT'}, {name: 'CORRE CASH POSTING', number: 'MISC DEBIT'}, {name: 'CORR CROSS CCY', number: 'MISC DEBIT'}, {name: 'CORR GENR CSH DEDUC', number: 'MISC DEBIT'}, {name: 'CORR GENR DEDUCTION', number: 'MISC DEBIT'}, {name: 'ACCT TO TELEX', number: 'MISC DEBIT'}, {name: 'CORR ACC TO TLX', number: 'MISC DEBIT'}, {name: 'CREDIT TFR STAND/ORDER', number: 'TRANSFER'}, {name: 'DEBIT TFR STAND/ORDER', number: 'TRANSFER'}, {name: 'CREDIT TFR STAND/ORDER', number: 'A/C TRANS '}, {name: 'DEBIT TFR STAND/ORDER', number: 'A/C TRANS '}, {name: 'TRAVELLERS CHQ DEPOSIT', number: 'TVL CHEQUE'}, {name: 'CORR TRAV CHQ DEPOSIT', number: 'TVL CHEQUE'}, {name: 'T/CHEQUE SELL', number: 'TVL CHEQUE'}, {name: 'T/CHEQUE BUY', number: 'TVL CHEQUE'}, {name: 'CORR SALE OF TRAV CHQS', number: 'TVL CHEQUE'}, {name: 'CORR PURCHASE TRAV CHQS', number: 'TVL CHEQUE'}, {name: 'CORR ACCT TRAV CHQS', number: 'TVL CHEQUE'}, {name: 'CORR TRAV CHQS DEP', number: 'TVL CHEQUE'}];

/**********************************************************************
TRANSACTION SEARCH GRID
**********************************************************************/
var dataView;
var grid;
var data = [];
var selectedRowIds = [];
var columnFilters = {};
var columns = [{
	id: "company",
	name: "Company",
	field: "company",
	toolTip: "Click to sort by Company",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "accountnum",
	name: "Account Number",
	field: "accountnum",
	toolTip: "Click to sort by Account Number",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "accountnam",
	name: "Account Name",
	field: "accountnam",
	toolTip: "Click to sort by Account Name",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "postingdate",
	name: "Posting Date",
	field: "postingdate",
	toolTip: "Click to sort by Posting Date",
	width: 160,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "valuedate",
	name: "Value Date",
	field: "valuedate",
	toolTip: "Click to sort by Value Date",
	width: 160,
	sortable: true,
	sorter: "sorterDateIso",
	visible: true
}, {
	id: "ccy",
	name: "Currency",
	field: "ccy",
	toolTip: "Click to sort by Currency",
	width: 100,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "damount",
	name: "Debit Amount",
	field: "damount",
	toolTip: "Click to sort by Debit Amount",
	width: 160,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	cssClass: "num neg",
	headerCssClass: "righted",
	visible: true
}, {
	id: "camount",
	name: "Credit Amount",
	field: "camount",
	toolTip: "Click to sort by Credit Amount",
	width: 160,
	sortable: true,
	sorter: "sorterNumeric",
	formatter: Slick.Formatters.AmountFormatter,
	cssClass: "num pos",
	headerCssClass: "righted",
	visible: true
}, {
	id: "debcred",
	name: "Debit/Credit",
	field: "debcred",
	toolTip: "Click to sort by Type",
	width: 160,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "baicode",
	name: "BAI Code",
	field: "baicode",
	sortable: true,
	sorter: "sorterStringCompare",
	width: 160,
	visible: true
}, {
	id: "transcode",
	name: "Transaction Code",
	field: "transcode",
	sortable: true,
	sorter: "sorterStringCompare",
	width: 160,
	visible: true
}, {
	id: "transdesc",
	name: "Transaction Code Desc.",
	field: "transdesc",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "transnar",
	name: "Transaction Narrative",
	field: "transnar",
	width: 200,
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "voucher",
	name: "Voucher",
	field: "voucher",
	width: 160,
	cssClass: "centered",
	headerCssClass: "centered",
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}, {
	id: "swift",
	name: "SWIFT",
	field: "swift",
	width: 160,
	cssClass: "centered",
	headerCssClass: "centered",
	sortable: true,
	sorter: "sorterStringCompare",
	visible: true
}];
var	options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiColumnSort: true,
	multiSelect: true,
	showHeaderRow: true,
	headerRowHeight: 40
};
if (store.get('transactionSearchOrder')) {
	columns = store.get('transactionSearchOrder');
	for (i = 0; i < columns.length; i++) {
		if (columns[i].id == "damount" || columns[i].id == "camount") {
			columns[i].formatter = Slick.Formatters.AmountFormatter;
		}
	}
}
if (store.get('transactionSearchWidths')) {
	var setWidth = store.get('transactionSearchWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}
var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var groupCollapseSetting = 0;
function expandAllGroups() {
	dataView.expandAllGroups();
}
function collapseAllGroups() {
	dataView.collapseAllGroups();
}
function clearGrouping() {
	dataView.setGrouping([]);
	groupedSetting = 0;
}
function groupBy(item, text) {
	dataView.setGrouping([{
			getter: item,
			formatter: function (g) {
				return text + ": " + g.value + "  <span>(" + g.count + " items)</span>";
			},
			displayTotalsRow: true
		}]);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}
function myFilter(item, args) {
	for (var columnId in columnFilters) {
		if (columnId !== undefined && columnFilters[columnId] !== "") {
			var c = grid.getColumns()[grid.getColumnIndex(columnId)],
				_sorter = c.sorter;
			if (_sorter == "sorterNumeric") {
				var _filter = columnFilters[columnId],
					_field = item[c.field].replace(/[^\d\.\-\ ]/g, ''),
					_greaterThen, _lessThen, _comparer, _between = false;
				if (_filter.charAt(0) === ">") {
					_greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf("<") != -1) {
						_between = true
					}
					if (_between) {
						_lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) < parseFloat(_greaterThen)) {
							return false;
						}
					}
				} else if (_filter.charAt(0) === "<") {
					_lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
					if (_filter.indexOf(">") != -1) {
						_between = true
					}
					if (_between) {
						_greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
						if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
							return false;
						}
					} else {
						if (parseFloat(_field) > parseFloat(_lessThen)) {
							return false;
						}
					}
				} else {
					if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
						return false;
					}
				}
			} else {
				if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
					return false;
				}
			}
		}
	}

	return true;
}
function toggleFilterRow(e) {
	e.preventDefault();
	$('.slick-headerrow-column').children().val('').next("i").hide();
	for (var columnId in columnFilters) {
		columnFilters[columnId] = "";
	}
	if ($(this).hasClass("btn-on")) {
		grid.setHeaderRowVisibility(false);
		$(this).removeClass("btn-on");
	} else {
		grid.setHeaderRowVisibility(true);
		$(this).addClass("btn-on");
	}
	dataView.refresh();
}
for (var i = 0; i < 50; i++) {
	var d = (data[i] = {});
	d["id"] = "id_" + i;
	if (i % 3 == 0) {
		d["company"] = "Consulting Pte. Ltd.";
		d["damount"] = (Math.round(Math.random() * 1000000) / 100).toFixed(2);
		d["camount"] = "";
		d["debcred"] = "Debit";
		if (i < 65) {
			d["accountnam"] = "Currenct Account";
			d["accountnum"] = "834-6564-211";
			d["ccy"] = "SGD";
			d["postingdate"] = "Jan. 05, 2012";
			d["valuedate"] = "Jan. 05, 2012";
			d["voucher"] = "Y";
			d["swift"] = "Y";
		} else {
			d["accountnam"] = "Savings Account";
			d["accountnum"] = "432-1922-011";
			d["ccy"] = "AUD";
			d["postingdate"] = "Jan. 12, 2012";
			d["valuedate"] = "Jan. 12, 2012";
			d["voucher"] = "";
			d["swift"] = "Y";
		};
	} else {
		d["company"] = "Manufacturing Inc.";
		d["damount"] = "";
		d["camount"] = (Math.round(Math.random() * 1000000) / 100).toFixed(2);
		d["debcred"] = "Credit";
		if (i < 65) {
			d["accountnam"] = "Currenct Account";
			d["accountnum"] = "123-2223-212";
			d["ccy"] = "SGD";
			d["postingdate"] = "Jan. 12, 2012";
			d["valuedate"] = "Jan. 12, 2012";
			d["voucher"] = "Y";
			d["swift"] = "";
		} else {
			d["accountnam"] = "Savings Account";
			d["accountnum"] = "574-233444-23";
			d["ccy"] = "AUD";
			d["postingdate"] = "Jan. 05, 2012";
			d["valuedate"] = "Jan. 05, 2012";
			d["voucher"] = "";
			d["swift"] = "";
		};
	};
	d["baicode"] = "BAI" + (Math.round(Math.random() * 10000)).toString();
	d["transcode"] = "TC" + (Math.round(Math.random() * 1000)).toString();
	d["transnar"] = "";
	d["transdesc"] = "";
}

/**********************************************************************
SEARCH INDICATOR SETUP
**********************************************************************/
function indicatorSelection() {
	var alphaIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "~", "Contains"],
		numIndicators = ["=", "Equal To", "&ne;", "Not Equal To", "&gt;", "Greater Than", "&lt;", "Less Than", "&hArr;", "Between"],
		dateIndicatores = ["=", "Specific Date", "&hArr;", "Date Range", "Rd", "Rolling Dates"];
	var $indicatorMenu, whichArray, indicator, mainInput, fromInput, toInput, rollingInput, hiddenInput;
	var sibs;

	function init() {
		$indicatorMenu = $("<div class='indicator-menu' style='display:none;position:absolute;' />").appendTo(document.body);
		$indicatorMenu.bind("click", setIndicator);
		setupIndicators();
	}

	function setupIndicators() {

		var $indicatorItem;
		$(".transactionSearch .indicator").bind("click", function(e) {
			e.stopPropagation();
			if ($indicatorMenu.is(":visible") && $indicatorMenu.attr("id") == $(this).attr("id") + "m") {
				$indicatorMenu.empty().hide();
				return;
			}
			$indicatorMenu.empty();
			indicator = $(this);
			sibs = $(this).siblings("input").not("input[type='hidden']");
			mainInput = $(this).next("input");
			fromInput = mainInput.next("input");
			toInput = fromInput.next("input");
			rollingInput = toInput.next("input");
			hiddenInput = $(this).siblings("input[type='hidden']");
			$indicatorMenu.attr("id", indicator.attr("id") + "m");
			whichArray = alphaIndicators;
			if ($(this).hasClass("num")) whichArray = numIndicators;
			if ($(this).hasClass("date")) whichArray = dateIndicatores;
			for (var i = 0; i < whichArray.length; i++) {
				$indicatorItem = $("<div />").attr("id", i).html("<strong id=" + i + ">" + whichArray[i] + "</strong> " + whichArray[i + 1]).appendTo($indicatorMenu);
				i = i + 1;
			}
			var pleft = $(this).offset().left;
			var ptop = $(this).offset().top + $(this).height() + 2;
			$indicatorMenu.css("top", ptop).css("left", pleft).show();
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").children(".on").removeClass("on");
			$("body").one("click", function() {
				$indicatorMenu.empty().hide();
			});
			$(document).on("keyup.hideIndicator", function(e) {
				if (e.keyCode == 27) {
					$indicatorMenu.empty().hide();
					$(document).off("keyup.hideIndicator");
				}
			});
		});
	}

	function setIndicator(e) {
		var indset = whichArray[parseInt(e.target.id)];
		var hidset = whichArray[parseInt(e.target.id) + 1];
		indicator.html(indset).attr("title", hidset);
		hiddenInput.val(hidset);
		if (hidset == "Date Range" || hidset == "Between") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.removeClass("display-none").prop("disabled", "").focus();
			toInput.removeClass("display-none").prop("disabled", "");
		}
		if (hidset == "Rolling Dates") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.removeClass("display-none").prop("disabled", "").focus();
		}
		if (hidset != "Date Range" && hidset != "Rolling Dates" && hidset != "Between") {
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			mainInput.removeClass("display-none").prop("disabled", "").focus();
		}
	}
	init();
}

/**********************************************************************
SAVED SEARCHES
**********************************************************************/
var saved_searches = [{
		name: "Debits Above USD $10000",
		id: "asdf3"
	}, {
		name: "All Singapore Debits",
		id: "sdf23"
	}, {
		name: "Last Week Debit - Credit",
		id: "hgj56"
	}, {
		name: "Yesterday Debits Above $5k",
		id: "ncve4"
	}, {
		name: "Yesterday Credits",
		id: "47hj6"
	}],
	searches_updated = false,
	searches_deleted = false,
	$search_message = $("<p>Use the saved search feature to save frequent searches and quickly recall them.</p>");
if (store.get('saved_transaction_searches')) {
	saved_searches = store.get('saved_transaction_searches')
};
function searchChecker(val) {
	var _search = val,
		error = false,
		$searchList = $(".search-list").children("li"),
		existingSearches = [];
	for (var i = 0; i < $searchList.length; i++) {
		existingSearches.push($searchList.eq(i).attr("data-search"));
	}
	if ($.inArray(_search, existingSearches != -1)) {
		error = "existing"
	}
	return error;
}
function renameSearch(el) {
	var newSearchName = $.trim(el.val());
	if (newSearchName == '' || newSearchName == "undefined") {
		el.val(el.attr("data-search-name"));
	} else {
		el.val(newSearchName);
		el.closest("li").attr("data-search", newSearchName);
		searches_updated = true;
	}
}
function deleteSearch(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function() {
		if (!$target.hasClass('new')) {
			searches_deleted = true;
		}
		$target.remove();
		$(".folder-list").sortable("refresh");
		searches_updated = true;
		if (!$(".folder-list").children("li").size()) {
			$(".search-instructions").remove();
			$search_message.appendTo(".folder-settings");
		}
	});
}
function populateSearches() {
	var $savedSearches = $(".saved-searches"),
		searchCount = saved_searches.length,
		activeSearch = $savedSearches.children("li.active") ? $savedSearches.children("li.active").attr("data-search-id") : false;
	$savedSearches.children().remove();
	if (searchCount > 0) {
		var $li, $a
		$savedSearches.each(function() {
			var _this = $(this);
			if (_this.parents().attr("id") == "viewMenu") {
				$.each(saved_searches, function() {
					$li = $("<li data-search='" + this.name + "' data-search-id='" + this.id + "' />").appendTo(_this);
					if (this.id == activeSearch) {
						$li.addClass("active");
						$("#searchMenuControl").children("a").children("span").html(this.name);
					}
					$a = $("<a href='javascript:void(0)' title='" + this.name + "' data-search='" + this.name + "' data-search-id='" + this.id + "'>" + this.name + "</a>").on("click", function(e) {
						e.preventDefault();
					}).appendTo($li);
				});
			}
		});
	} else {
		var $viewMenu = $("#viewMenu").children("ul.saved-searches"),
			$li = $("<li class='no-set' />").appendTo($viewMenu),
			$a = $("<div >You have no saved searches</div>").appendTo($li);
	}
}
function populateSearchManager() {
	searches_updated = false;
	searches_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
		$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({
			handle: '.reorder-folder',
			axis: 'y',
			tolerance: "pointer",
			update: function(event, ui) {
				searches_updated = true
			}
		}),
		folderCount = saved_searches.length,
		$li, $div, $span, $input, $remove, $view, $error;
	if (folderCount > 0) {
		$folderAddLine = $("<p class='search-instructions'>Reorder, rename, run or remove your saved searches.</p>").insertBefore($folderList),
			$.each(saved_searches, function() {
				$li = $("<li data-search='" + this.name + "' data-search-id='" + this.id + "' class='row' />").appendTo($folderList);
				$div = $("<div class='folder-row data-column' />").appendTo($li);
				$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
				$input = $("<input type='text' maxlength='25' value='" + this.name + "' data-search-name='" + this.name + "' />").on("change", function() {
					renameSearch($(this));
				}).appendTo($div);
				$view = $("<a href='javascript:void(0)' class='view-folder'><i class='fa fa-search fa-fw'></i></a>").appendTo($div);
				$remove = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteSearch).appendTo($div);
				$error = $("<div class='data-error'>A saved search with this name already exists</div>").appendTo($div);
			});
	} else {
		$search_message.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showSearchManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Saved Searches",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function() {
			return populateSearchManager()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					updateSearches(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}
function saveSearches(dialog) {
	var $dialog = $("#" + dialog.id),
		$active = $("#viewMenu").children(".saved-searches").find("li.active").attr("data-search-id");
	$dialog.addClass("working");
	saved_searches = searches_updated;

	var active_deleted = true;

	for (f = 0; f < saved_searches.length; f++) {
		if ($active == saved_searches[f].id) {
			active_deleted = false;
			break;
		}
	}

	searches_updated = false;
	searches_deleted = false;
	store.set('saved_transaction_searches', saved_searches);
	setTimeout(function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateSearches();
		if (!saved_searches.length || active_deleted) {
			$("#_noSearch").trigger("click");
		}
		dialogHider(dialog);
	}, 300);
}
function updateSearches(dialog) {
	if (searches_updated) {
		searches_updated = [];
		var duplicate_names = false,
			$searchList = $(".folder-list");
		$searchList.find("li.error").removeClass("error");
		$searchList.children("li").each(function() {
			searches_updated.push({
				"name": $(this).attr("data-search"),
				"id": $(this).attr("data-search-id")
			});
			var _name = $(this).attr("data-search");
			$(this).siblings().each(function() {
				if ($(this).attr("data-search") == _name) {
					$(this).addClass("error");
				}
			});
		});
		if ($searchList.find("li.error").size()) {
			duplicate_names = true;
		}
		if (duplicate_names) {
			return false;
		} else {
			var save_searches = false;
			if (saved_searches.length != searches_updated.length) {
				save_searches = true;
			} else {
				for (var i = 0; i < saved_searches.length; i++) {
					if (saved_searches[i].name != searches_updated[i].name || saved_searches[i].id != searches_updated[i].id) {
						save_searches = true;
						break;
					}
				}
			}
			if (save_searches || searches_deleted) {
				if (searches_deleted) {
					buildConfirmDialog("You've deleted some saved searches.", "Are you sure you want to continue?", function() {
						saveSearches(dialog)
					});
				} else {
					saveSearches(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}

/**********************************************************************
SEARCH FIELD TOGGLE
**********************************************************************/
var search_height = 0;
var inMotion = false;
function showSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	$this.attr("show", "true").addClass("btn-on");
	$i.removeClass("fa-search-plus").addClass("fa-search-minus");
	$(".search-fields").removeClass("slide-up");
	$(".scroll-area").removeClass("full-height");
	$(".basic-search").css("overflow", "hidden");
	inMotion = setTimeout(function() {
		$(".basic-search").css("overflow", "visible");
		grid.resizeCanvas();
		inMotion = false;
	}, 300);
}
function hideSearchFields() {
	var $this = $("#show-hide-search"),
		$i = $this.find("i");
	if (inMotion) clearTimeout(inMotion);
	$i.removeClass("fa-search-minus").addClass("fa-search-plus");
	$this.attr("show", "false").removeClass("btn-on");
	$(".search-fields").css("overflow", "hidden").addClass("slide-up");
	$(".scroll-area").addClass("full-height");
	setTimeout(function() {
		grid.resizeCanvas();
	}, 300);
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {

	/**********************************************************************
	INITIALIZE TRANSACTION SEARCH GRID
	**********************************************************************/
	var GroupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		GroupItemMetadataProvider: GroupItemMetadataProvider
	});
	grid = new Slick.Grid("#searchGrid", dataView, columns, options);
	grid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	grid.registerPlugin(GroupItemMetadataProvider);
	grid.registerPlugin(checkboxSelector);
	var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'transactionSearchOrder', 'transactionSearchWidths', ["checkBoxSelector"]);
	grid.onContextMenu.subscribe(function(e, args) {
		e.preventDefault();
		var cell = grid.getCellFromEvent(e),
			row = cell.row,
			rows = grid.getSelectedRows(),
			$cmenu;
		if ($.inArray(row, rows) == -1) {
			grid.setSelectedRows([row])
			$cmenu = $("#contextMenu")
		} else {
			$cmenu = $("#contextMenu")
		};
		var cheight = $cmenu.height(),
			winwidth = $(window).width(),
			winheight = $(window).height(),
			leftpos = e.pageX,
			toppos = e.pageY;
		if (e.pageX + 210 > winwidth) {
			leftpos = e.pageX - 205;
		}
		if (e.pageY + cheight > winheight) {
			toppos = e.pageY - cheight;
			if (toppos < 0) {
				toppos = e.pageY - (cheight - (winheight - e.pageY));
			}
		};
		$(document).off("keyup.hide-context");
		$("body").off("click.hide-context");
		function hideContextMenu() {
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").find(".on").removeClass("on");
			$(".control-menus").find("a.sub-open").removeClass("sub-open");
		}
		hideContextMenu();
		$cmenu.css("top", toppos).css("left", leftpos).show();
		$(document).on("keyup.hide-context", function(e) {
			if (e.keyCode == 27) {
				hideContextMenu()
			}
		});
		$("body").one("click.hide-context", function() {
			hideContextMenu()
		});
	});
	grid.onSelectedRowsChanged.subscribe(function(e) {
		$(document).off("keyup.hide-menu");
		$(".shell").off("resize.hide-menu");
		$("body").off("click.hide-menu");
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		selectedRowIds = [];
		var rows = grid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) selectedRowIds.push(item.id)
		}
		if(selectedRowIds.length > 0) {
			$("#transactionSearchPanel .bottom-controls").removeClass("hidden");
			$("#transactionSearchPanel .gutter-30").addClass("has-bottom-controls");
			$("#selectedCount").html(selectedRowIds.length);
		} else {
			$("#transactionSearchPanel .bottom-controls").addClass("hidden");
			$("#transactionSearchPanel .gutter-30").removeClass("has-bottom-controls");
			$("#selectedCount").html('');
		}
		grid.resizeCanvas();
	});
	grid.onSort.subscribe(function(e, args) {
		var cols = args.sortCols;
		dataView.sort(function(dataRow1, dataRow2) {
			for (var i = 0, l = cols.length; i < l; i++) {
				sortdir = cols[i].sortAsc ? 1 : -1;
				sortcol = cols[i].sortCol.field;
				var _sorter = cols[i].sortCol.sorter,
					result;
				if (_sorter == "sorterStringCompare") {
					result = sorterStringCompare(dataRow1, dataRow2);
				} else if (_sorter == "sorterNumeric") {
					result = sorterNumeric(dataRow1, dataRow2);
				} else if (_sorter == "sorterDateIso") {
					result = sorterDateIso(dataRow1, dataRow2);
				} else if (_sorter == "sorterTime") {
					result = sorterTime(dataRow1, dataRow2);
				}
				if (result != 0) {
					return result;
				}
			}
			return 0;
		});
		args.grid.invalidateAllRows();
		args.grid.render();
	});
	grid.onClick.subscribe(function(e, args) {
		var acell = grid.getCellFromEvent(e),
			arow = acell.row,
			$arow = $(e.target).closest(".slick-row");
		if (!$arow.is(".slick-group, .slick-group-totals")) {
			e.preventDefault();

			function showTransactionDetails() {
				function navigateTransactions() {}

				function voucherImages() {}

				function transactionHelp() {}
				var $transactionDetails = $("<div style='position: absolute; top: 0; right: 0; bottom: 0; left: 0;' />"),
					$navigationBar = $("<div class='top-controls' />").appendTo($transactionDetails),
					$controls = $("<div class='control-list right' />").appendTo($navigationBar),
					$helpBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-question-circle fa-fw'></i></a></span>").appendTo($controls),
					$prevousBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-left fa-fw'></i></a></span>").appendTo($controls),
					$nextBtn = $("<span class='btn'><a href='javascript:void(0)'><i class='fa fa-chevron-right fa-fw'></i></a></span>").appendTo($controls),
					details = [{
						name: "Company",
						id: "td1",
						type: "text",
						data: "LLC Manufacturing Inc."
					}, {
						name: "Account Name",
						id: "td2",
						type: "text",
						data: "AUD Operations"
					}, {
						name: "Account Number",
						id: "td3",
						type: "text",
						data: "334-1233-212"
					}, {
						name: "Transaction Code",
						id: "td4",
						type: "text",
						data: "TC3457"
					}, {
						name: "BAI Code",
						id: "td5",
						type: "text",
						data: "BAI39433"
					}, {
						name: "Posting Date",
						id: "td6",
						type: "text",
						data: smartDates("yesterday")
					}, {
						name: "Value Date",
						id: "td7",
						type: "text",
						data: smartDates("yesterday")
					}, {
						name: "Amount",
						id: "td8",
						type: "text",
						attributes: [{
							name: "class",
							value: "data-text neg"
						}],
						data: "AUD 1,300.00"
					}, {
						name: "Transaction Narrative",
						id: "td9",
						type: "text",
						data: "Praesent magna purus, posuere et porta ac, volutpat ut dui. Ut non mauris orci. In a porttitor felis. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt."
					}, {
						name: "Transaction Description",
						id: "td10",
						type: "text",
						data: "Praesent magna purus, posuere et porta ac, volutpat ut dui. Ut non mauris orci. In a porttitor felis. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt. Quisque lobortis aliquam metus. Aenean varius fringilla tincidunt."
					}, {
						name: "Voucher Images",
						id: "td11",
						type: "text",
						data: "<a href='javascript:void(0)'><i class='fa fa-image fa-fw' style='margin-right: 8px;'></i>View Images</a>"
					}],
					$detailsForm = $("<div class='data-form' style='position: absolute; top: 50px; right: 0; bottom: 0; left: 0; overflow-x: hidden; overflow-y: auto;' />").appendTo($transactionDetails),
					$formSection = $("<div class='form-section' />").appendTo($detailsForm);
				for (var i = 0; i < details.length; i++) {
					var $row = $("<div class='row' />").appendTo($formSection),
						$label = $("<div class='label-column'><label>" + details[i].name + "</label></div>)").appendTo($row),
						$data = $("<div class='data-column' />").appendTo($row),
						$el = $("<div class='data-text' id='" + details[i].id + "'>" + details[i].data + "</div>").appendTo($data);
					if (details[i].attributes) {
						for (var a = 0; a < details[i].attributes.length; a++) {
							$el.attr(details[i].attributes[a].name, details[i].attributes[a].value);
						}
					}
				};
				return $transactionDetails;
			}
			var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
			var _dialog = {
				id: "transactionDetails",
				title: "Transaction Details",
				size: "medium",
				icon: "<i class='fa fa-file-text'></i>",
				content: function() {
					return showTransactionDetails()
				},
				buttons: [{
					name: "Close",
					icon: "<i class='fa fa-times fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}]
				}, {
					name: "Transaction Detail Report",
					icon: "<i class='fa fa-file-text fa-fw'></i>",
					events: [{
						event: "click",
						action: function(e) {
							e.preventDefault();
							dialogHider(_dialog)
						}
					}],
					cssClass: "primary"
				}]
			}
			dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
		}
	});
	grid.onColumnsResized.subscribe(function(e, args) {
		store.set('transactionSearchWidths', grid.getColumns());
	});
	$(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
		var columnId = $(this).data("columnId");
		var $icon = $(this).next("i");
		if (columnId != null) {
			columnFilters[columnId] = $.trim($(this).val());
			$icon.show();
			dataView.refresh();
			if (!$(this).val()) {
				$icon.hide();
			}
		}
	});
	grid.onHeaderRowCellRendered.subscribe(function(e, args) {
		if (args.column.id == "_checkbox_selector") {
			return false;
		} else {
			$(args.node).empty().addClass(args.column.headerCssClass);
			var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
			var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
				e.preventDefault();
				$(this).prev("input[type='text']").val("").trigger("change");
				$(this).hide();
			});
			if ($input.val()) {
				$icon.show();
			}
		}
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		grid.updateRowCount();
		grid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		grid.invalidateRows(args.rows);
		grid.render();
		if (selectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < selectedRowIds.length; i++) {
				var idx = dataView.getRowById(selectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			grid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(data);
	dataView.setFilterArgs({});
	dataView.syncGridSelection(grid, true, false);
	dataView.syncGridCellCssStyles(grid, "contextMenu");
	dataView.setFilter(myFilter);
	grid.setColumns(columns);
	if (store.get('transactionSearchOrder')) {
		var visibleColumns = [];
		for (var i = 0; i < store.get('transactionSearchOrder').length + 1; i++) {
			if (columns[i].visible) {
				visibleColumns.push(columns[i])
			}
		}
		grid.setColumns(visibleColumns);
	}
	grid.setHeaderRowVisibility(false);

	/**********************************************************************
	GRID RESIZE EVENT
	**********************************************************************/
	$(window).bind("resize", function() {
		grid.resizeCanvas();
	});
	$(window).on("resize", _.debounce(function(e) {
		grid.resizeCanvas();
	}, 100));

	/**********************************************************************
	SAVED SEARCH EVENTS
	**********************************************************************/
	$(".manage-searches").on("click", showSearchManagerDialog);
	populateSearches();

	/**********************************************************************
	REPORT MENU INTERACTION
	**********************************************************************/
	$("#reportsMenuControl").on("click.show-actionMenu", function(e) {
		var rowsLength = grid.getSelectedRows().length;
		var menuLink = $("#reportsMenuControl").children("a")
		if (rowsLength == 0) {
			menuLink.attr({
				"href": "#requestReportsMenuNoSelected"
			});
		} else if (rowsLength == 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		} else if (rowsLength > 1) {
			menuLink.attr({
				"href": "#requestReportsMenu"
			});
		}
	});

	/**********************************************************************
	SEARCH FIELDS
	**********************************************************************/
	$("#show-hide-search").on("click", function(e) {
		e.preventDefault();
		var $this = $(this);
		if ($this.attr("show") == "false") {
			showSearchFields();
		} else {
			hideSearchFields();
		}
	});

	/**********************************************************************
	FILTER INTERACTION
	**********************************************************************/
	$("#toggleFilter").on("click", toggleFilterRow);

	/**********************************************************************
	SETTINGS MENU
	**********************************************************************/
	$(".remember-settings").on("click", function() {
		$("body").addClass("loading");
		setTimeout(function() {
			$("body").removeClass("loading");
			buildNotification("Default settings for this screen have been updated", 500, 3000);
		}, 1000);
	});

	/**********************************************************************
	GROUPING INTERACTIONS
	**********************************************************************/
	$("body").on("click.group-by", "#groupMenu [data-action='group']", function(e) {
		e.preventDefault()
		var $target = $(e.target),
			item = $target.attr("data-item"),
			text = $target.text()
		groupBy(item, text)
	});
	$(".collapse-mark").bind("click.collapse-mark", function(e) {
		e.stopPropagation();
		var $item = $(".collapse-mark").parent("li");
		if (groupCollapseSetting == 0) {
			$item.addClass("on");
			groupCollapseSetting = 1;
		} else {
			$item.removeClass("on");
			groupCollapseSetting = 0;
		}
	});

	/**********************************************************************
	INITIALIZE SEARCH INDICATORS
	**********************************************************************/
	indicatorSelection();

	/**********************************************************************
	SETUP THE DATE FUNCTIONS
	**********************************************************************/
	var rollingDates = ["Today", "Yesterday", "Week to Date", "Previous Week", "Month to Date", "Previous Month"];
	$(".postingdaterolling, .valuedaterolling").autocomplete({
		source: rollingDates,
		autoFocus: true,
		delay: 0,
		minLength: 0,
		select: function(e, ui) {
			$(this).autocomplete("close");
		},
		change: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(rollingDates, function() {
				if (this.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this;
					return false;
				}
			});
			$(this).val(matchie);
			if (!valid) {
				$(this).val("");
				return false;
			}
		}
	});
	$(".postingdaterolling, .valuedaterolling").on("focus", function(e) {
		$(this).autocomplete("search", "");
	}).on("click", function(e) {
		$(this).autocomplete("search", "");
	}).on("keydown", function(e) {
		if (e.keyCode == "9") {
			e.stopImmediatePropagation();
		}
	});
	var postingdate = $(".postingdate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});
	var valuedate = $(".valuedate_").datepicker({
		duration: 0,
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true
	});
	var postingdates = $(".postingdatefrom, .postingdateto")
	$(".postingdatefrom").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".postingdateto").datepicker("option", "minDate", selectedDate)
			setTimeout(function() {
				$(".postingdateto").focus()
			}, 50)
		}
	});
	$(".postingdateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".postingdatefrom").datepicker("option", "maxDate", selectedDate)
		}
	});
	var valuedates = $(".valuedatefrom, .valuedateto")
	$(".valuedatefrom").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".valuedateto").datepicker("option", "minDate", selectedDate)
			setTimeout(function() {
				$(".valuedateto").focus()
			}, 50)
		}
	});
	$(".valuedateto").datepicker({
		dateFormat: 'dd/mm/yy',
		defaultDate: "-1m",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		onSelect: function(selectedDate) {
			$(".valuedatefrom").datepicker("option", "maxDate", selectedDate)
		}
	});

	/**********************************************************************
	SELECTIZE FIELDS
	**********************************************************************/
	var selectize_options = {
		plugins: ['remove_button'],
		maxItems: null,
		maxOptions: 50,
		valueField: 'number',
		labelField: 'name',
		searchField: ['number', 'name'],
		highlight: false,
		hideSelected: true,
		options: ACCOUNTS,
		render: {
			item: function(item, escape) {
				if (item.name == item.number) return '<div>' + '<span class="name" style="margin-right:0px;">' + escape(item.name) + '</span></div>'
				return '<div>' +
					(item.name ? '<span style="font-weight:bold; margin-right:5px;">' + escape(item.name) + '</span>' : '') +
					(item.number ? '<span>' + escape(item.number) + '</span>' : '') +
					'</div>';
			},
			option: function(item, escape) {
				var label = item.name || item.number;
				var caption = item.name ? item.number : null;
				return '<div>' +
					'<div class="label" >' + escape(label) + '</div>' +
					(caption ? '<div class="caption">' + escape(caption) + '</div>' : '') +
					'</div>';
			}
		},
		onItemAdd: function(value, $item) {
			this.$control_input.blur().focus();
			this.$control_input.focus();
		},
		onItemRemove: function(value) {},
		onDropdownOpen: function($dropdown, value) {
			if (!this.$control_input.val().length) this.close();
		},
		load: function(query, callback) {},
		persist: false,
		addPrecedence: true,
		openOnFocus: false,
		closeAfterSelect: true,
		create: "false"
	};
	$('.account-search').selectize(selectize_options);
	selectize_options.render.item = function(item, escape) {
		return '<div>' +
			'<span style="font-weight:bold; margin-right:5px;">' + escape(item.number) + '</span>' +
			'</div>';
	}

	selectize_options.options = SWIFT_CODES;
	$('.SWIFT-search').selectize(selectize_options);

	selectize_options.options = TRANTYPE_CODES;
	$('.TType-search').selectize(selectize_options);

	selectize_options.options = BAI_CODES;
	$('.BAI-search').selectize(selectize_options);

	/**********************************************************************
	SEARCH / RESET BUTTONS
	**********************************************************************/
	$(".start-search").click(function(e) {
		e.preventDefault();
		$(".shell").addClass("loading");
		setTimeout(function() {
			$(".shell").removeClass("loading");
			hideSearchFields();
			$("#noSearch").hide();
			$("#searchGrid").removeClass("hidden");
		}, 1000);
	});
	$(".resetSearch").click(function(e) {
		e.preventDefault();
		grid.setSelectedRows([]);
		$("#searchGrid").addClass("hidden");
		$("#noSearch").show();
	});

	/**********************************************************************
	ADD / REMOVE ITEM MODAL
	**********************************************************************/
	function showAddItems(_target, title, headers, items, SEL_INPUT) {


		/* function to save and add selected accounts to the widget */
		function saveSelectedAccounts(_dialog) {
			if ($("input[name=_addAccount]:checked").length > 0) {
				var ADD_ITEMS = [];
				var checked_items = $("input[name=_addAccount]:checked");

				for (var s = 0; s < checked_items.length; s++) {
					for (var i = s; i < items.length + s; i++) {
						if (i > items.length) i = i - items.length;
						if (items[i].number == checked_items.eq(s).val()) {
							ADD_ITEMS.push(items[i].number);
							break;
						}
					}
				}
				SEL_INPUT[0].selectize.addItems(ADD_ITEMS);
				dialogHider(_dialog);
			} else {
				dialogHider(_dialog);
			}
		}

		/* set $wrapper to hold the add accounts list */
		var $wrapper = $("<div class='widget-accounts wrapper' />"),

			/* build the account filter input */
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an item...' />").on("keyup", function() {
				if (this.value != '') {
					$("#clearAccountsFilter").show()
				} else {
					$("#clearAccountsFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#AddAccountsFilterInput").val("").trigger("change");
				$(this).hide();
			}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='fav-header' />").appendTo($wrapper),
			$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.find("input[name='_selectAll']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
				}
				var checkBoxes = $("input[name=_addAccount]:visible");
				var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
			}),
			$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv);
		for (var i = 0; i < headers.length; i++) {
			var width = 600 / headers.length;
			if (headers.length > 2) i <= 2 ? width += 20 : width -= 40;
			else i == 0 ? width += 40 : width -= 40;
			$("<div class='fav-header-col' style='width: " + width + "px;'>" + headers[i] + "</div>").appendTo($header);
		}

		/* build the accounts list */
		var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
			$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
			$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
		$.each(items, function() {

			$li = $("<li>").appendTo($ul),
				$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						if ($target.hasClass("fav-data-col")) {
							$target = $target.closest("div.fav-row");
						}
						$target = $target.find("input[name='_addAccount']");
						var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
					}
					if (!$(this).prop("checked")) {
						$("input[name='_selectAll']").prop("checked", false)
					}
					if ($("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length) {
						$("input[name='_selectAll']").prop("checked", true)
					}
				}),
				$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
			var $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addAccount'/>").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
			});
			for (var i = 0; i < headers.length; i++) {
				var width = 600 / headers.length;
				if (headers.length > 2) i <= 2 ? width += 20 : width -= 40;
				else i == 0 ? width += 40 : width -= 40;
				$("<div class='fav-data-col' style='width: " + width + "px;'>" + (i == 0 ? this.name : (i == 1 ? this.number : this.currency)) + "</div>").appendTo($row);
			}

			if ($.inArray(this.number, SEL_INPUT[0].selectize.items) > -1) {
				$li.remove();
			}
		});

		/* build and show the add accounts dialog */
		var _origin = _target;
		var _dialog = {
			id: "AddAccounts",
			title: title,
			size: "medium",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper,
			buttons: [{
				name: "Cancel",
				icon: "<i class='fa fa-times fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						dialogHider(_dialog)
					}
				}]
			}, {
				name: "Add",
				icon: "<i class='fa fa-plus fa-fw'></i>",
				events: [{
					event: "click",
					action: function(e) {
						e.preventDefault();
						saveSelectedAccounts(_dialog)
					}
				}],
				cssClass: "primary"
			}]
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

		if (!$("#AddAccountsFilterList").children("li").length) {
			var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
		}
	}
	$(".account-search-column label>i").click(function() {
		showAddItems($(this), "Add Accounts", ["Account Name", "Account Number", "Currency"], accounts, $('.account-search'))
	});
	$(".bai-search-column label>i").click(function() {
		showAddItems($(this), "Add Merchant Category Code", ["Marchant Category Code", "Description"], BAI_CODES, $('.BAI-search'))
	});
	$(".swift-code-column label>i").click(function() {
		showAddItems($(this), "Add Merchant Group", ["Merchant Group Name"], SWIFT_CODES, $('.SWIFT-search'))
	});
	$(".tran-type-column label>i").click(function() {
		showAddItems($(this), "Add Transaction Types", ["Description", "Tran Code"], TRANTYPE_CODES, $('.TType-search'))
	});
	
});