var entityNumbers = [];
var _cardNumbers = [
	{ id: "card1",number: randNumber(6),cardaccountnumber: randNumber(18),entitynumber:Math.round(45641234567890 * 10 + 2).toString(),status: "Active",name: "Mr. Scott", open: $.datepicker.formatDate('dd/mm/yy', new Date()), close: $.datepicker.formatDate('dd/mm/yy', new Date()), currency: "AUD",spendcap:"10,000.00", monthly: "10,000.00", transaction: "2,500.00", atm: "1,000.00", otc: "30,000.00", current: "4,500.00", available: "4,500.00",merchantname:"DEBAO AUSTRALIA PL",merchantlocation:"BRISBANE",merchantgroup:"RETAIL",debitamount:"1,000.00"},
	{ id: "card2",number: randNumber(6),cardaccountnumber: randNumber(18),entitynumber:Math.round(45641234567890 * 10 + 3).toString(),status: "Active",name: "Mrs. Scott", open: $.datepicker.formatDate('dd/mm/yy', new Date()),close: $.datepicker.formatDate('dd/mm/yy', new Date()),currency: "AUD",spendcap:"5,000.00", monthly: "10,000.00", transaction: "2,500.00", atm: "1,000.00", otc: "30,000.00", current: "4,500.00", available: "4,500.00",merchantname:"MYER",merchantlocation:"BRISBANE",merchantgroup:"RETAIL",debitamount:"2,500.00"},
	{ id: "card3",number: randNumber(6),cardaccountnumber: randNumber(18),entitynumber:Math.round(45641234567890 * 10 + 4).toString(),status: "Active",name: "Mr. Primrose", open: $.datepicker.formatDate('dd/mm/yy', new Date()),close: $.datepicker.formatDate('dd/mm/yy', new Date()), currency: "AUD",spendcap:"15,000.00", monthly: "10,000.00", transaction: "2,500.00", atm: "1,000.00", otc: "30,000.00", current: "4,500.00", available: "4,500.00",merchantname:"SPLOTLESS",merchantlocation:"MUSCOT",merchantgroup:"HOSPITABLITY",debitamount:"1,500.00"},
	{ id: "card4",number: randNumber(6),cardaccountnumber: randNumber(18),entitynumber:Math.round(45641234567890 * 10 + 5).toString(),status: "Active",name: "Mr. McGuillicuddy", open: $.datepicker.formatDate('dd/mm/yy', new Date()),close: $.datepicker.formatDate('dd/mm/yy', new Date()),currency: "AUD",spendcap:"50,000.00", monthly: "10,000.00", transaction: "2,500.00", atm: "1,000.00", otc: "30,000.00", current: "4,500.00", available: "4,500.00",merchantname:"QANTAS",merchantlocation:"MUSCOT",merchantgroup:"AIRLINES",debitamount:"500.00"}
];
var isCompatible = false;

for (var j in _cardNumbers) {
	entityNumbers.push(_cardNumbers[j].entitynumber)
}
function split( val ) {
	return val.split( /,\s*/ );
}
function extractLast( term ) {
	return split( term ).pop();
}

  function HandleBrowseClick()
{   
    var fileinput = $("#browse");
	fileinput.val('');
    fileinput.click();
	//$('#fakeBrowse').addClass('disabled');
}
function Handlechange(e)
{    
    var fileinput = document.getElementById("browse");
	 var cs=fileinput.value.split('.');
	if(cs[1]=="CSV" || cs[1]=="csv")
	{
	 isCompatible=true;
	}
	if(fileinput.value!='')
	 {
    $selectedItem=$("<li><i class='fa fa-paperclip' style='font-size:14px;padding-right:5px;'></i><span>"+fileinput.value+"</span><span style='margin-left: 14px;'><a href='javascript:void(0)' id='clearFile'>remove</a></span></li>");
	$("#browse").attr("disabled", "disabled");
	$('#fakeBrowse').addClass('disabled');
	$selectedItem.appendTo('#filename');
	}
	else{
		$("#browse").removeAttr("disabled");
		$('#fakeBrowse').removeClass('disabled');
		}
	
	
}
$('#filename').on('click','a#clearFile',function()
{
  $(this).closest('li').remove();
   var fileinput = $("#browse");
	fileinput.val('');
  $('#fakeBrowse').removeClass('disabled');
  $("#browse").removeAttr("disabled");
  
}); 

/**********************************************************************
SETUP REQUEST SCREEN
**********************************************************************/

function setupViewEnquiry(item) {
	$("#requestInformation").scrollTop(0);
	var _type = item.requesttype;
	$("#requestDetailsHeader").addClass('hidden');
	$("#viewDetailsHeader").removeClass('hidden');
	$("#viewRequestStatus").html(item.requestid);
	$("#viewBillingEntityNo").html(item.billingentitynumber);
	$("#viewBillingEntityName").html(item.billingentityname);	
	if ( _type == "Card Limit Change" ) {
		$("#requestDetail").show();
	}
	$("#requestDetail").show();
}


/**********************************************************************
ACCOUNTS
**********************************************************************/
var _accounts = [
	{ name: "AU Savings", number: "112345", ccy: "AUD"},
	{ name: "Melbourne Operations", number: "112342", ccy: "AUD"},
	{ name: "Singapore Funding", number: "112341", ccy: "SGD"},
	{ name: "Bangalore Operations", number: "112344", ccy: "INR"},
	{ name: "SGD Funding", number: "412348", ccy: "SGD"},
	{ name: "INR Savings", number: "712340", ccy: "INR"},
	{ name: "Trade Funding", number: "712349", ccy: "SGD"},
	{ name: "Loan Repayment", number: "212349", ccy: "AUD"},
	{ name: "Nightly Sweep", number: "312345", ccy: "AUD"},
	{ name: "AUD Liquidity", number: "212346", ccy: "AUD"}
], _accountTypeAhead = [];

for (var j in _accounts) {
	_accountTypeAhead.push( _accounts[j].name +" - "+ _accounts[j].number+" ("+_accounts[j].ccy+")" )
}

function split( val ) {
	return val.split( /,\s*/ );
}

function extractLast( term ) {
	return split( term ).pop();
}

function rand(min, max) {
  var offset = min;
  var range = (max - min) + 1;
  var randomNumber = Math.floor( Math.random() * range) + offset;
  return randomNumber;
}
//Add Comments Dialog
function showCommentsDialog(_target) {
	/* set $wrapper to hold the add comment and attachments form */
	var $wrapper = $("<div class='wrapper' />");
	var $formSection = $("<div class='form-section top-label' />").appendTo($wrapper);
	var $row = $("<div class='row' />").appendTo($formSection);
	var $labelColumn = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Comments</label>").appendTo($labelColumn);
	var $dataColumn = $("<div class='data-column' />").appendTo($row);
	var $data = $("<textarea style='width: 95%; max-width: 95%; height: 200px;' id='_addComment'></textarea>").appendTo($dataColumn);
	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "enquiryHistoryDialog",
		title: "Add Comment",
		size: "small",
		icon: "<i class='fa fa-pencil'></i>",
		content: $wrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}], cssClass:"primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
	$("#_addComment").focus();
}


/**********************************************************************
REQUESTS SUMMARY GRID SETUP
**********************************************************************/
function styleRequestStatusFormatter(row, cell, value, columnDef, dataContext) {
	if (value == "Open") {
		return "<span style='color: #009900;'>"+value+"</span>";
	} else {
		return value;
	}
}

var dataView, grid, data = [], selectedRowIds = [],
columns = [
    {id:"billingentitynumber", name:"Billing Entity Number", field:"billingentitynumber", width: 160, sortable:true, visible: true},
	{id:"billingentityname", name:"Billing Entity Name", field:"billingentityname", width: 160, sortable:true, visible: true},
	{id:"cardaccountnumber", name:"Card Account Number", field:"cardaccountnumber", width: 160, sortable:true, visible: true},
	{id:"cardnumber", name:"Card Number", field:"cardnumber", width: 160, sortable:true, visible: true},
	{id:"cardholdername", name:"Cardholder Name", field:"cardholdername", width: 140, sortable:true, visible: true},
	{id:"requestid", name:"Request ID", field:"requestid", width: 140, sortable: true, visible: true},
	{id:"crossreferenceid", name:"Cross Reference ID", field:"crossreferenceid", width: 160, sortable: true, visible: true},
	{id:"requesttype", name:"Request Type", field:"requesttype", width: 200, sortable: true, visible: true},
	{id:"requeststatus", name:"Request Status", field:"requeststatus", width: 100, sortable: true, formatter: styleRequestStatusFormatter, visible: true },
	{id:"requestor", name:"Requestor", field:"requestor", width: 100, sortable: true, visible: true},
	{id:"VerifyBy", name:"Verified By", field:"VerifyBy", width: 140, sortable:true, visible: true},
	{id:"Approveby", name:"Approved By", field:"Approveby", width: 140, sortable:true, visible: true},
	{id:"Secondapproval", name:"Second Approval", field:"Secondapproval", width: 140, sortable:true, visible: true},
	{id:"creationdate", name:"Creation Date", field:"creationdate", width: 100, sortable: true, visible: true},
	{id:"lastupdatedby", name:"Last Updated By", field:"lastupdatedby", width: 160, sortable: true, visible: true},
	{id:"lastupdate", name:"Last Updated Date", field:"lastupdate", width: 140, sortable: true, visible: true},
	{id:"closedate", name:"Completed Date", field:"closedate", width: 80, sortable: true, visible: true},
	{id:"Uploadedfilename", name:"Uploaded File Name", field:"Uploadedfilename", width: 140, sortable:true, visible: true}
	/**	{id:"accountnumber", name:"Account Number", field:"accountnumber", width: 200, sortable:true, visible: true},
	{id:"accountname", name:"Account Name", field:"accountname", width: 200, sortable:true, visible: true},
	{id:"createdby", name:"Created By", field:"createdby", width: 200, sortable: true, visible: true},
	{id:"channel", name:"Channel", field:"channel", width: 200, sortable: true, visible: true},
	{id:"raisedfor", name:"Raised on Behalf Of", field:"raisedfor", width: 200, sortable: true, visible: true}**/
];
if ( store.get('requestColumnOrder') ) {
	columns = store.get('requestColumnOrder');
}
if ( store.get('requestColumnWidths') ) {
	var setWidth = store.get('requestColumnWidths');
	for (var i in setWidth) {
		var s = setWidth[i]
		for (c = 0; c < columns.length; c++) {
			if (s.id == columns[c].id) {
				columns[c].width = s.width
			}
		}
	}
}

var checkboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
columns.unshift(checkboxSelector.getColumnDefinition());
var options = {
	editable: false,
	autoEdit: false,
	enableCellNavigation: true,
	enableColumnReorder: false,
	enableColumnReorderCheckbox: true,
	syncColumnCellResize: false,
	forceFitColumns: false,
	multiSelect: true
}, groupedSetting = 0, groupCollapseSetting = 0;
function collapseAllGroups() {
	dataView.beginUpdate();
	for (var i = 0; i < dataView.getGroups().length; i++) {
		if(!dataView.getGroups()[i].collapsed)
			dataView.collapseGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
	dataView.endUpdate();
}
function expandAllGroups() {
	for (var i = 0; i < dataView.getGroups().length; i++) {
		dataView.expandGroup(dataView.getGroups()[i].value, dataView.getGroups()[i].rows);
	}
}
function clearGrouping() {
	dataView.groupBy(null);
	groupedSetting = 0;
}
function groupBy(item,text) {
	dataView.groupBy(
		item,
		function (g) {
			return text+":  " + g.value + "  <span>(" + g.count + " items)</span>";
		},
		function (a, b) {
			return a.value - b.value;
		}
	);
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
	groupedSetting = 1;
}

var searchString = "", statusString = "", searchPoint = "requestid";

function myFilter(item, args) {
	if (args.statusString != "" && item["requeststatus"] != args.statusString)
		return false;
	if (args.searchString != "" && item[searchPoint].toLowerCase().indexOf(args.searchString.toLowerCase()) == -1)
		return false;
	return true;
}

function filterRequests() {
	dataView.refresh();
	grid.invalidate();
	grid.render();
	if(groupCollapseSetting == 1) {
		collapseAllGroups();
	}
}

function findRequests() {
	var rows = grid.getSelectedRows();
	if(rows.length > 0) {grid.setSelectedRows(0)};
	if(searchString == "") {
		dataView.setFilterArgs({searchString: searchString, statusString: statusString})
	} else {
		dataView.setFilterArgs({searchString: searchString, statusString: statusString})
	};
	dataView.refresh();
}

function viewFilter() {
	var rows = grid.getSelectedRows();
	if(rows.length > 0) {
		grid.setSelectedRows(0);
	}
	dataView.setFilterArgs({
		statusString: statusString,
		searchString: searchString
	});
	filterRequests();
}

/**********************************************************************
					SEARCH INDICATOR SETUP
**********************************************************************/
function indicatorSelection() {
	var alphaIndicators = ["=","Equal To","&ne;","Not Equal To","~","Contains"], numIndicators = ["=","Equal To","&ne;","Not Equal To","&gt;","Greater Than","&lt;","Less Than","&hArr;","Between"], dateIndicatores = ["=","Specific Date","&hArr;","Date Range","Rd","Rolling Dates"];
	var $indicatorMenu, whichArray, indicator, mainInput, fromInput, toInput, rollingInput, hiddenInput;
	var sibs;
	function init() {
		$indicatorMenu = $("<div class='indicator-menu' style='display:none;position:absolute;' />").appendTo(document.body);
		$indicatorMenu.bind("click", setIndicator);
		setupIndicators();
	}
	function setupIndicators() {
		var $indicatorItem;
		$("#commercialcardsSearch .indicator").bind("click", function(e){
			e.stopPropagation();
			if( $indicatorMenu.is(":visible") && $indicatorMenu.attr("id") == $(this).attr("id")+"m" ){
				$indicatorMenu.empty().hide();
				return;
			}
			$indicatorMenu.empty();
			indicator = $(this);
			sibs = $(this).siblings("input").not("input[type='hidden']");
			mainInput = $(this).next("input");
			fromInput = mainInput.next("input");
			toInput = fromInput.next("input");
			rollingInput = toInput.next("input");
			hiddenInput = $(this).siblings("input[type='hidden']");
			$indicatorMenu.attr("id", indicator.attr("id")+"m");
			whichArray = alphaIndicators;
			if($(this).hasClass("num")) whichArray = numIndicators;
			if($(this).hasClass("date")) whichArray = dateIndicatores;
			for(var i=0;i<whichArray.length;i++){
				$indicatorItem = $("<div />").attr("id", i).html("<strong id="+i+">"+whichArray[i]+"</strong> "+whichArray[i+1]).appendTo($indicatorMenu);
				i=i+1;
			}
			var pleft = $(this).offset().left;
			var ptop = $(this).offset().top+$(this).height();
			$indicatorMenu.css("top", ptop).css("left", pleft).show();
			$(".control-menus").children(".control-menu:visible").hide();
			$(".control-list").children(".on").removeClass("on");
			$("body").one("click", function() {
				$indicatorMenu.empty().hide();
			});
			$(document).on("keyup.hideIndicator", function(e) {
					if(e.keyCode == 27) {
						$indicatorMenu.empty().hide();
						$(document).off("keyup.hideIndicator");
					}
				}
			);
		});
	}
	function setIndicator(e) {
		var indset = whichArray[parseInt(e.target.id)];
		var hidset = whichArray[parseInt(e.target.id)+1];
		indicator.html(indset).attr("title", hidset);
		hiddenInput.val(hidset);
		if(hidset == "Date Range" || hidset == "Between") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.removeClass("display-none").prop("disabled", "").focus();
			toInput.removeClass("display-none").prop("disabled", "");
		}
		if(hidset == "Rolling Dates") {
			mainInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			rollingInput.removeClass("display-none").prop("disabled", "").focus();
		}
		if(hidset != "Date Range" && hidset != "Rolling Dates" && hidset != "Between") {
			rollingInput.addClass("display-none").prop("disabled", "disabled");
			fromInput.addClass("display-none").prop("disabled", "disabled");
			toInput.addClass("display-none").prop("disabled", "disabled");
			mainInput.removeClass("display-none").prop("disabled", "").focus();
		}
	}
	init();
}

/**********************************************************************
				INITIALIZE SEARCH INDICATORS
**********************************************************************/
indicatorSelection();
/**********************************************************************
REQUESTS DATA
**********************************************************************/

var requestTypes = ["Statement Preferences","Card Limit Change","Replace Card","Cancel Card"];
var requestUsers = ["Kent Brokman","Arnie Pye","Jasper Beardly","Patty Bouvier","Roger Meyers Jr."]
var requestbillingName=["Victoria Farms(AU)","North Island Farms(NZ)","NSW Farms(AU)","QLD Farms(AU)"]
var requestuploadfilename=["xxxxx.csv","yyy.csv","zzzz.csv"]


for (var i=0; i<17; i++) {
	var d = (data[i] = {});
	var randy = _accounts[rand(0, _accounts.length - 1)];
	var randy_billing = _accounts[rand(0, _accounts.length - 1)];
	d["id"] = "id_" + i;
	d["requestid"] = "SR-"+randString(6);
	d["crossreferenceid"] = "";
	d["creationdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,6,23))+ " " + timeFormatter();
	d["requestor"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,26)) + " " + timeFormatter();
	d["accountnumber"] = randy.number;
	d["lastupdatedby"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["cardholdername"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["accountname"] = randy.name;
	d["billingentitynumber"]="124856754"+randy_billing.number;
	d["cardnumber"]="************"+randy.number;
	d["cardaccountnumber"]="259123459654"+randy.number;
	d["billingentityname"]=requestbillingName[rand(0, requestbillingName.length - 1)];
	d["ccy"] = randy.ccy;
	d["requestname"] = "RequestName"+randString();
	d["requesttype"] = requestTypes[rand(0, requestTypes.length - 1)];
	d["Uploadedfilename"]= requestuploadfilename[rand(0, requestuploadfilename.length - 1)];
	//d["createdby"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["channel"] = "Self Service";
	d["raisedfor"] = "-";
	d["closedate"] = "";
	d["Approveby"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["Secondapproval"] = requestUsers[rand(0, requestUsers.length - 1)];
	d["VerifyBy"] = requestUsers[rand(0, requestUsers.length - 1)];
	if(d["requesttype"] == "New Cardholder Request"){
	d["crossreferenceid"]= "SA-"+randString(6);
	}
	if(d["billingentityname"] != "North Island Farms(NZ)"){  
	d["cardaccountnumber"]="";
	}
	
	if(i == 1) {
		d["requeststatus"] = "Pending Verification";
		d["requesttype"] = "New Cardholder Request";
		d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,7,23))+ " " + timeFormatter(11,12);
	} else if(i == 2 || i == 13){
		d["requeststatus"] = "Pending Approval";
		d["closedate"] = "";
		d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,7,22)) + " " + timeFormatter(10,12);
	} else if(i ==3 || i == 12) {
	   d["requeststatus"] = "Pending Second Approval";
	   d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,11)) + " " + timeFormatter(9,12);
		}
		else if(i == 4 || i == 11) {
	   d["requeststatus"] = "Unsuccessful. Please resubmit";
	   d["requesttype"] = "New Cardholder Request";
	   d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,23))+ " " + timeFormatter(11,12);
		}
		else if(i == 5 || i ==10) {
	   d["requeststatus"] = "Cancelled";
	   d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,23))+ " " + timeFormatter(11,12);
	   d["Uploadedfilename"]="";
		}
		else if(i == 0) {
	   d["requeststatus"] = "Unsuccessful. Please resubmit";
	     d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,7,11)) + " " + timeFormatter(9,12);
		 }
		else if(i == 7 ) {
	   d["requeststatus"] = "Pending Transmission";
	      d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,9,23))+ " " + timeFormatter(11,12);
		}
		else if(i ==9) {
	   d["requeststatus"] = "Failed Validation";
	      d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,9,23))+ " " + timeFormatter(11,12);
		}
		else if(i == 15){
		d["requeststatus"] = "Completed";
		 d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,9,23))+ " " + timeFormatter(11,12);
		 d["closedate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2015,1,11)) + " " + timeFormatter();
		}
		else if(i==6|| i == 14){
		d["requeststatus"] = "Deleted";
		   d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,23))+ " " + timeFormatter(11,12);
		}
		else if(i==16){
		d["requeststatus"] = "Rejected";
		d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,26)) + " " + timeFormatter();
		}
		else{
		d["requeststatus"] = "Unsuccessful. Please resubmit";
		d["lastupdate"] = $.datepicker.formatDate('dd/mm/yy', new Date(2014,8,26)) + " " + timeFormatter();
		}
};


/**********************************************************************
MANAGE ACTION AND CONTEXT CONTROLS
**********************************************************************/
function checkStatus(arr) {
	var L = arr.length-1;
	while(L) {
		if(arr[L--]!==arr[L]) return false;
	}
	return arr[L];
}

var enableContextItem = function() {
	var text = $(this).children("div.disabled").text();
	$(this).children("div.disabled").replaceWith( "<a href='javascript:void(0)'>" + text + "</a>" );
};

var disableContextItem = function() {
	var text = $(this).children("a").text();
	$(this).children("a").replaceWith( "<div class='disabled'>" + text + "</div>" );
};

function setupContextMenu() {
	var sel = selectedRowIds.length, $contextItems = $("[data-type='context-item']"), _status;
	if ( sel == 0 || sel > 1 ) {
		$contextItems.each(disableContextItem);
	} else {
		_status = dataView.getItemById(selectedRowIds[0]).requeststatus;
		if ( _status == "Open") {
			$contextItems.each(enableContextItem);
		} else {
			$("[data-action='viewdetails'], [data-action='viewhistory']").each(enableContextItem);
			$("[data-action='addcomment'], [data-action='attachdocument']").each(disableContextItem);
		}
	}
//$contextItems.each(enableContextItem);
	
}

/**********************************************************************
							SAVED SEARCHES
**********************************************************************/
var saved_searches_service = [{name:"Last Searches", id:"last"},{name:"Most Important", id:"important"},{name:"Recent Searches", id:"recent"}], searches_updated = false, searches_deleted = false, $search_message = $("<p>Use the saved search feature to save frequent searches and quickly recall them.</p>");
if ( store.get('saved_transaction_searches_list') ) { saved_searches_service = store.get('saved_transaction_searches_list') };
function searchChecker(val) {
	var _search = val, error = false, $searchList = $(".search-list").children("li"), existingSearches = [];
	for ( var i = 0; i < $searchList.length; i++ ) {
		existingSearches.push( $searchList.eq(i).attr("data-search") );
	}
	if ($.inArray(_search, existingSearches != -1)) {
		error = "existing"
	}
	return error;
}
function renameSearch(el) {
	var newSearchName = $.trim(el.val());
	if ( newSearchName == '' || newSearchName == "undefined" ) {
		el.val( el.attr("data-search-name") );
	} else {
		el.val(newSearchName);
		el.closest("li").attr("data-search", newSearchName );
		searches_updated = true;
	}
}
function deleteSearch(e) {
	e.preventDefault();
	var $target = $(this).closest("li");
	$target.hide('fast', function(){
		if ( !$target.hasClass('new') ) { searches_deleted = true; }
		$target.remove();
		$(".folder-list").sortable("refresh");
		searches_updated = true;
		if ( !$(".folder-list").children("li").size() ) {
			$(".search-instructions").remove();
			$search_message.appendTo(".folder-settings");
		}
	 });
}
function populateSearches() {
	var $savedSearches = $(".saved-searches"), searchCount = saved_searches_service.length, activeSearch = $savedSearches.children("li.active") ? $savedSearches.children("li.active").attr("data-search-id") : false;
	$savedSearches.children().remove();
	if ( searchCount > 0 ) {
		var $li, $a
		$savedSearches.each( function() {
			var _this = $(this);
			if ( _this.parents().attr("id") == "savesearches" ) {
				$.each(saved_searches_service, function() {
					$li = $("<li data-search='"+this.name+"' data-search-id='"+this.id+"' />").appendTo(_this);
					if ( this.id == activeSearch ) { $li.addClass("active"); $("#searchMenuControl").children("a").children("span").html(this.name); }
					$a = $("<a href='javascript:void(0)' title='"+this.name+"' data-value='"+this.name+"' data-search='"+this.name+"' data-search-id='"+this.id+"'>"+this.name+"</a>").on("click", function(e) {
						 var $target = $(e.target);
						 if ( $target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set") ) {
							 var value = $target.attr("data-value");
						
						 var activeId = $('#viewMenu li.active a').attr('data-value');
						 if(activeId != value ){
							$('#viewMenu li').removeClass('active');
							$target.parent('li').addClass('active');
							statusString = '';
							$('#viewMenuHeader span').html(value);
							$("body").addClass("loading");
							setTimeout( function() {
								$("body").removeClass("loading");
							}, 1000);
						 }
						 viewFilter();
							 
						}
					}).appendTo($li);
				});
			}
		});
	} else {
		var $saveViewMenu = $("#savesearches").children("ul.saved-searches"),
		$li = $("<li class='no-set' />").appendTo($saveViewMenu),
		$a = $("<div >You have no saved searches</div>").appendTo($li);
	}
}
function populateSearchManager() {
	searches_updated = false; searches_deleted = false;
	var $folderSettings = $("<div class='folder-settings' />"),
	$folderList = $("<ul class='folder-list' />").appendTo($folderSettings).sortable({ handle: '.reorder-folder', axis: 'y', tolerance: "pointer", update: function( event, ui ) { searches_updated = true } }),
	folderCount = saved_searches_service.length, $li, $div, $span, $input, $remove, $view, $error;
	if ( folderCount > 0 ) {
		$folderAddLine = $("<p class='search-instructions'>Reorder, rename, run or remove your saved searches.</p>").insertBefore($folderList),
		$.each(saved_searches_service, function() {
			$li = $("<li data-search='"+this.name+"' data-search-id='"+this.id+"' class='row' />").appendTo($folderList);
			$div = $("<div class='folder-row data-column' />").appendTo($li);
			$span = $("<span class='reorder-folder'><i class='fa fa-bars fa-fw'></i></span>").appendTo($div);
			$input = $("<input type='text' maxlength='25' value='"+this.name+"' data-search-name='"+this.name+"' />").on("change", function() { renameSearch( $(this) );}).appendTo($div);
			$view = $("<a href='javascript:void(0)' class='view-folder'><i class='fa fa-search fa-fw'></i></a>").appendTo($div);
			$remove = $("<a href='javascript:void(0)' class='delete-folder'><i class='fa fa-times fa-fw'></i></a>").on("click", deleteSearch).appendTo($div);
			$error = $("<div class='data-error'>A saved search with this name already exists</div>").appendTo($div);
		});
	} else {
		$search_message.appendTo($folderSettings);
	}
	return $folderSettings;
}
function showSearchManagerDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Manage Saved Searches",
		size: "medium",
		icon: "<i class='fa fa-folder-open'></i>",
		content: function(){return populateSearchManager()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();updateSearches(_dialog)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
function saveSearches(dialog) {
	var $dialog = $("#"+dialog.id), $active = $("#saveViewMenu").children(".saved-searches").find("li.active").attr("data-search-id");
	$dialog.addClass("working");
	saved_searches_service = searches_updated;

	var active_deleted = true;

	for ( f = 0; f < saved_searches_service.length; f++ ) {
		if ( $active == saved_searches_service[f].id ) {
			active_deleted = false;
			break;
		}
	}

	searches_updated = false;
	searches_deleted = false;
	store.set('saved_transaction_searches_list', saved_searches_service);
	setTimeout( function() {
		dataView.refresh();
		grid.invalidate();
		grid.render();
		populateSearches();
		if ( !saved_searches_service.length || active_deleted ) { $("#_noSearch").trigger("click"); }
		dialogHider(dialog);
	}, 300);
}
function updateSearches(dialog) {
	if ( searches_updated ) {
		searches_updated = [];
		var duplicate_names = false, $searchList = $(".folder-list");
		$searchList.find("li.error").removeClass("error");
		$searchList.children("li").each(function() {
			searches_updated.push( { "name":$(this).attr("data-search"), "id":$(this).attr("data-search-id") });
			var _name = $(this).attr("data-search");
			$(this).siblings().each(function() {
				if ( $(this).attr("data-search") == _name ) {
					$(this).addClass("error");
				}
			});
		});
		if ( $searchList.find("li.error").size() ) {
			duplicate_names = true;
		}
		if ( duplicate_names ) {
			return false;
		} else {
			var save_searches = false;
			if ( saved_searches_service.length != searches_updated.length ) {
				save_searches = true;
			} else {
				for (var i = 0; i < saved_searches_service.length; i++) {
					if ( saved_searches_service[i].name != searches_updated[i].name || saved_searches_service[i].id != searches_updated[i].id ) {
						save_searches = true;
						break;
					}
				}
			}
			if ( save_searches || searches_deleted ) {
				if ( searches_deleted ) {
					buildConfirmDialog( "You've deleted some saved searches.", "Are you sure you want to continue?", function(){saveSearches(dialog)});
				} else {
					saveSearches(dialog)
				}
			} else {
				dialogHider(dialog);
			}
		}
	} else {
		dialogHider(dialog)
	}
}





/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {


$(".manage-searches").on("click", showSearchManagerDialog);
populateSearches();


/**********************************************************************
INITIALISE REQUESTS GRID
**********************************************************************/
var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
dataView = new Slick.Data.DataView({
	groupItemMetadataProvider: groupItemMetadataProvider
});
for (var i=0; i<columns.length; i++)
{
	if(columns[i].name=="Request Status"){
		columns[i].formatter=highlight;
	}
}
function highlight(row, cell, value, columnDef, dataContext) {
    if (value == 'Unsuccessful. Please resubmit') {
      return "<span style='color:red'>" + value + "</span>";
    }
    else if (value == 'Failed Validation') {
      return "<span style='color:red'>" + value + "</span>";
    }else{return value}
  }
grid = new Slick.Grid("#servcieRequests", dataView, columns, options);
grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow:false}));
grid.registerPlugin(groupItemMetadataProvider);
grid.registerPlugin(checkboxSelector);
var columnpicker = new Slick.Controls.ColumnPicker(columns, grid, options, 'requestColumnOrder', 'requestColumnWidths');
grid.onContextMenu.subscribe(function (e,args) {
	e.preventDefault();
	var cell = grid.getCellFromEvent(e), row = cell.row, rows = grid.getSelectedRows(), $cmenu;
	var rowdata = dataView.getItem(row);
	if ($.inArray(row, rows) == -1) {
		grid.setSelectedRows([row])
		if(rowdata.requeststatus=="Unsuccessful. Please resubmit"){
	      $cmenu = $("#contextunsuceesfullMenu")
	      }
		  else
		  {
		$cmenu = $("#contextMenu")
		  }
	} else {
		if (rows.length > 1) {
		  if(rowdata.requeststatus=="Unsuccessful. Please resubmit"){
	       $cmenu = $("#multipleunsucessContextMenu")
	      }
		  else
		  {
			$cmenu = $("#multipleContextMenu")
		  }
		} else {
		if(rowdata.requeststatus=="Unsuccessful"){
	       $cmenu = $("#contextunsuceesfullMenu")
	      }
		  else
		  {
			$cmenu = $("#contextMenu")
		  }
		}
	};
	var cheight = $cmenu.height(), winwidth = $(window).width(), winheight = $(window).height(), leftpos = e.pageX, toppos = e.pageY;
	if(e.pageX + 210 > winwidth) {
		leftpos = e.pageX-205;
	}
	if(e.pageY + cheight > winheight) {
		toppos = e.pageY-cheight;
		if(toppos < 0) {
			toppos = e.pageY - (cheight-(winheight-e.pageY));
		}
	};
	$(document).off("keyup.hide-context");
	$("body").off("click.hide-context");
	function hideContextMenu() {
		$(".control-menus").children(".control-menu:visible").hide();
		$(".control-list").find(".on").removeClass("on");
		$(".control-menus").find("a.sub-open").removeClass("sub-open");
	}
	hideContextMenu();
	$cmenu.css("top", toppos).css("left", leftpos).show();
	$(document).on("keyup.hide-context", function(e) {
		if(e.keyCode == 27) {
			hideContextMenu()
		}
	});
	$("body").one("click.hide-context", function() {
		hideContextMenu()
	});
});


grid.onSelectedRowsChanged.subscribe(function(e) {
	$(document).off("keyup.hide-menu");
	$(".shell").off("resize.hide-menu");
	$("body").off("click.hide-menu");
	$(".control-menus").children(".control-menu:visible").hide();
	$(".control-list").children(".on").removeClass("on");
	selectedRowIds = [];
	var rows = grid.getSelectedRows();
	for (var i = 0, l = rows.length; i < l; i++) {
		var item = dataView.getItem(rows[i])
		if (item.id) {
			selectedRowIds.push(item.id);
		}

	}
});

grid.onClick.subscribe(function(e, args) {
	row = args.row, $row = $(e.target).closest(".slick-row");
	if( !$row.is(".slick-group, .slick-group-totals") ) {
		$row.attr({'data-panel': '#requestDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		setupViewEnquiry(dataView.getItem(row));
		grid.setSelectedRows(0);
		selectedRowIds = [];
	}

});

grid.onSort.subscribe(function(e, args) {
	sortcol = args.sortCol.field;
	sortdir = args.sortAsc ? 1 : -1;
	dataView.fastSort(sortcol, args.sortAsc);
});

grid.onColumnsReordered.subscribe(function(e, args) {
	store.set('requestColumnOrder', columns.slice(1));
});

grid.onColumnsResized.subscribe(function(e, args) {
	store.set('requestColumnWidths', grid.getColumns());
});

dataView.onRowCountChanged.subscribe(function(e,args) {
	grid.updateRowCount();
	grid.render();
});

dataView.onRowsChanged.subscribe(function(e,args) {
	grid.invalidateRows(args.rows);
	grid.render();
	if (selectedRowIds.length > 0)
	{
		var selRows = [];
		for (var i = 0; i < selectedRowIds.length; i++)
		{
			var idx = dataView.getRowById(selectedRowIds[i]);
			if (idx != undefined)
				selRows.push(idx);
		}
		grid.setSelectedRows(selRows);
	}
});

dataView.setItems(data);

dataView.setFilterArgs({
	statusString: statusString,
	searchString: searchString
});

dataView.setFilter(myFilter);

grid.setColumns(columns);

if ( store.get('requestColumnOrder') ) {
	var visibleAdHocColumns = [];
	for (var i = 0; i < store.get('requestColumnOrder').length+1; i++) {
		if (columns[i].visible) {
			visibleAdHocColumns.push(columns[i])
		}
	}
	visibleAdHocColumns.unshift(columns[0]);
	grid.setColumns(visibleAdHocColumns);
}






/**********************************************************************
GRID RESIZE EVENT
**********************************************************************/
$(window).bind("resize", function() {
	grid.resizeCanvas();
});

/**********************************************************************
SECTION TOGGLES
**********************************************************************/

$("#requestActivityToggle").on("click", function(e){
	e.preventDefault();
	var $section = $("#viewRequestActivity"), $icon = $(this).children("i");
	if ( $section.is(":visible") ) {
		$section.hide();
		$icon.removeClass("fa-chevron-circle-up").addClass("fa-chevron-circle-down");
	} else {
		$section.show();
		$icon.removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
	}
});

$("#requestDataToggle").on("click", function(e){
	e.preventDefault();
	var $section = $("#viewRequestData"), $icon = $(this).children("i");
	if ( $section.is(":visible") ) {
		$section.hide();
		$icon.removeClass("fa-chevron-circle-up").addClass("fa-chevron-circle-down");
	} else {
		$section.show();
		$icon.removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
	}
});


$("#resetSearch").on("click", function(e) {
	e.preventDefault();
	var activeSearch =  $(".saved-searches").find("li.active");
	if ( activeSearch ) {
	    e.preventDefault();
	e.stopPropagation();
     $('body').addClass('loading');
	$("#noSearch").hide();
	$("#noSearch").removeClass("loading panel");
		$("#commercialcardsSearch").find('.selectize-input').find('div[data-value]').hide();
	    $("#commercialcardsSearch").find('.selectize-input').find(':input').css('width','143px');
	    $("#commercialcardsSearch").find(':input').not(':button').val('');
	setTimeout(function(){ 
	    
	    $("#noSearch").show();
		$("#commercialsearchGrid").addClass("hidden");
           $('body').removeClass('loading');		
		
	}, 1000);
		

	} else {
		$("#_noSearch").trigger("click");
	}
});


/**********************************************************************
				SETUP THE DATE FUNCTIONS
**********************************************************************/
var rollingDates = ["Today","Yesterday","Week to Date","Previous Week","Month to Date","Previous Month"];

$("#postingdaterolling").autocomplete({
	source: rollingDates,
	autoFocus: false,
	delay: 0,
	minLength: 0,
	focus: function(e,ui) {
		return false;
	},
	select: function(e,ui) {
		$(this).autocomplete("close");
	},
	change: function(e,ui) {
		var matcher = $(this).val();
		var matchie = "";
		var valid = false;
		$.each(rollingDates, function() {
			if(this.toLowerCase() == matcher.toLowerCase()) {
				valid = true;
				matchie = this;
				return false;
			}
		});
		$(this).val(matchie);
		if(!valid) {
			$(this).val("");
			return false;
		}
	}
});
$("#postingdaterolling").on("focus", function(e) {
	e.preventDefault();
	$(this).autocomplete("search", "");
}).on("click", function(e) {
	$(this).autocomplete("search", "");
}).on("keydown", function(e) {
	if(e.keyCode == "9") {
		e.stopImmediatePropagation();
	}
});
var postingdate = $( "#lastUpdatedTime_" ).datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true});
var valuedate  =  $( "#creationdate_" ).datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true});
var postingdates = $( "#postingdatefrom, #postingdateto" )
$("#postingdatefrom").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#postingdateto").datepicker( "option", "minDate", selectedDate)
		setTimeout(function(){$("#postingdateto").focus()},50)
	}
});
$("#postingdateto").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#postingdatefrom").datepicker( "option", "maxDate", selectedDate)
	}
});
var valuedates = $( "#valuedatefrom, #valuedateto" )
$("#valuedatefrom").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#valuedateto").datepicker( "option", "minDate", selectedDate)
		setTimeout(function(){$("#valuedateto").focus()},50)
	}
});
$("#valuedateto").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#valuedatefrom").datepicker( "option", "maxDate", selectedDate)
	}
});
$("#billingEntityNumber").autocomplete({
	autoFocus: false,
	delay: 0,
	minLength: 1,
	source: function (request, response) {
		var results = $.ui.autocomplete.filter(entityNumbers, extractLast( request.term ));
		if (!results.length) {
			results = [
				{
					value: 'No Matches Found'
				}
			];
		}
		response(results);
	},
	focus: function() {
		return false;
	},
	select: function(event, ui) {
		if (ui.item.value == "No Matches Found") {
			this.value = "";
			return false;
		} else {
			this.value = ui.item.value;
			return false;
		}
	}
}).on("focus", function(){
	$(this).one("mouseup", function() {
		$(this).select();
	})
});

var search_height = 0; var inMotion = false;

//Show / Hide Search Panel
$("#show-hide-search").click(function(event){
	//$(".search-fields").animate({"max-height":"toggle"}, 1200);


	if($(this).attr("show") == "false"){ //show search panel
		$(this).attr("show", "true");
		$(this).find("a").attr("title", "Hide Search Criteria");
		$(this).find("i").removeClass("fa-search-plus").addClass("fa-search-minus");
		$(".search-fields").removeClass("slide-up");
		$(".scroll-area").removeClass("full-height");
		$(".basic-search").css("overflow", "hidden");
		inMotion = setTimeout(function(){ $(".basic-search").css("overflow", "initial"); $(window).resize(); inMotion = false; }, 600);
	}
	else{ //hide search panel
		
		if(inMotion) clearTimeout(inMotion);
		$(".search-fields").css("overflow", "hidden");
		$(".search-fields").addClass("slide-up");
		$(".scroll-area").addClass("full-height");
		$(this).find("a").attr("title", "Show Search Criteria");
		$(this).find("i").removeClass("fa-search-minus").addClass("fa-search-plus");
		$(this).attr("show", "false");
		$(window).resize();
		setTimeout(function(){ $(window).resize(); }, 600);
	}
});	

//Search Button
$(".start-search").click(function(e){
	e.preventDefault();
	e.stopPropagation();
	
	$("#show-hide-search").click();
	$("#servcieRequests").addClass("hidden");
	$("#noSearch").removeClass("hidden");
	$("#noSearch").addClass("loading panel");
	setTimeout(function(){ 
		$("#servcieRequests").removeClass("hidden"); 
		$("#noSearch").addClass("hidden");
	}, 1000);
});


/**********************************************************************
SEARCH PANEL BEHAVIOUR / BUTTONS
**********************************************************************/
var billingEntityNumbers = [];
var accounts = [
	{ number: Math.round(45641234567890 * 10 + 2).toString(), name: "Victoria Farms", currency: "Active", },
	{ number:Math.round(45641234567890 * 10 + 3).toString(), name: "North Island Farms", currency: "Active"},
	{ number: Math.round(45641234567890 * 10 + 4).toString(), name: "NSW Farms", currency: "Closed"},
	{number: Math.round(45641234567890 * 10 + 5).toString(), name: "QLD Farms", currency: "Dormant"},
	{number: Math.round(45641234567890 * 10 + 6).toString(), name: "Victoria Farms", currency: "Closed"},
	{number: Math.round(45641234567890 * 10 + 7).toString(), name: "North Island Farms", currency: "Active"},
	{number: Math.round(45641234567890 * 10 + 8).toString(), name: "NSW Farms", currency: "Active"},
	{number: Math.round(45641234567890 * 10 + 9).toString(), name: "QLD Farms", currency: "Active"},
	{number: Math.round(45641234567890 * 10 + 10).toString(), name: "Victoria Farms2", currency: "Dormant"},
	{number: Math.round(45641234567890 * 10 + 11).toString(), name: "North Island Farms", currency: "Closed"},
	{number: Math.round(45641234567890 * 10 + 12).toString(), name: "QLD Farms", currency: "Active"},
	{number: Math.round(45641234567890 * 10 + 13).toString(), name: "Victoria Farms", currency: "Closed"},
	{number: Math.round(45641234567890 * 10 + 14).toString(), name: "NSW Farms", currency: "Dormant"},
	{number: Math.round(45641234567890 * 10 + 15).toString(), name: "Victoria Farms", currency: "Active"}
];
for (var j in accounts) {
	billingEntityNumbers.push(accounts[j].number)
}
var selectize_options = {
    plugins: ['remove_button'],
    maxItems: null,
    valueField: 'number',
    labelField: 'name',
    searchField: ['number', 'name'],
    options: accounts,
	/* createFilter: function(query){
		return true;
	},*/
    render: {
        item: function(item, escape) {
			if(item.name == item.number) return '<div>' + '<span class="name" style="margin-right:0px;">' + escape(item.name) + '</span></div>'
            return '<div><span>' + escape(item.number) + '</span></div>';
        },
        option: function(item, escape) {
            var label =  item.number;
            var caption =  item.number;
            return '<div class="label" >' + escape(label) + '</div>';
        }
    },
	onItemAdd: function(value, $item){
		//$(".account-indicator").css("height", $(".selectize-control").height()-4).css("line-height",($(".selectize-control").height()-4)+"px");
		//$(window).resize(); $(window).resize();
		//var blah = this;
		//setTimeout(function(){ if(blah.$control_input.is(":focus")) blah.open(); }, 1000);
	},
	onItemRemove: function(value){
		//if($(this)[0].items.length) $(".account-indicator").css("height", $(".selectize-control").height()-4).css("line-height",($(".selectize-control").height()-4)+"px");
		//$(window).resize(); $(window).resize();
		//console.log(value);
	},
	onDropdownOpen: function($dropdown, value){
		if(!this.$control_input.val().length) this.close();
	},
	load: function(query, callback){
		//callback(accounts);
	},
	persist: false,
    addPrecedence: true,
	openOnFocus:false,
	closeAfterSelect:true
    // create: "true"
};


$('.account-search').selectize(selectize_options);

function showAddAccounts(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Name</div>").appendTo($header),
	$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Status</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( accounts, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#billingEntityNumberSelect").val($target.attr("data-number"));
			$("#billingEntityNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.name+"</div>").appendTo($row),
		$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Entities",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}
function showAddAccountReplace(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Name</div>").appendTo($header),
	$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Status</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( accounts, function() {
		$li = $("<li data-name='"+this.name+"' data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#billingEntityNumberSelect3").val($target.attr("data-number"));
			$("#repcard_billingEntityName").val($target.attr("data-name"));
			$("#billingEntityNumber").val($target.attr("data-number"));
			$("#addressLine1").val("833,Collins St");
			$("#addressLine22").val("833,St Marks");
			$("#suburb1").val("Docklands");
			$("#state1").val("VIC");
			$("#postCode1").val("3008");
			$("#country1").val("Australia");
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.name+"</div>").appendTo($row),
		$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Entities",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}
function showAddAccountCancel(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Name</div>").appendTo($header),
	$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Status</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( accounts, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#billingEntityNumberSelect2").val($target.attr("data-number"));
			$("#billingEntityNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.name+"</div>").appendTo($row),
		$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Entities",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}
function showAddAccounts2(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Name</div>").appendTo($header),
	$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( accounts, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#billingEntityNumberSelect2").val($target.attr("data-number"));
			$("#billingEntityNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.name+"</div>").appendTo($row),
		$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Entities",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

/**********************************************************************
ADD / REMOVE ITEM MODAL
**********************************************************************/
function showAddItems(_target, title, headers, items, SEL_INPUT) {


	/* function to save and add selected accounts to the widget */
	function saveSelectedAccounts(_dialog) {
		if ( $("input[name=_addAccount]:checked").length > 0 ) {
			var ADD_ITEMS = [];
			var checked_items = $("input[name=_addAccount]:checked");
			
			for (var s = 0; s < checked_items.length; s++) {
				for (var i = s; i < items.length + s; i++) {
					if(i > items.length) i = i - items.length;
					if ( items[i].number == checked_items.eq(s).val() ) {
						//_data.push( accounts[i] );
						ADD_ITEMS.push(items[i].number);
						break;
					}
				}
			}
			SEL_INPUT[0].selectize.addItems(ADD_ITEMS);
			dialogHider(_dialog);
			//buildFavouriteAccounts(_id,true);
			//store.set('saved_widget_data', widgetDataArray);
			//
		} else {
			dialogHider(_dialog);
		}
	}

	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='widget-accounts wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearEntitiesFilter").show() } else { $("#clearEntitiesFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearEntitiesFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='fav-header' />").appendTo($wrapper),
	$checkHeaderDiv = $("<div class='fav-header-col' style='text-align: center; padding: 0; width: 50px; cursor:default;' />").appendTo($header);
	
	
	for(var i = 0; i < headers.length; i++){
		var width = 600 / headers.length;
		if(headers.length > 2) i <= 2 ? width += 20 : width -= 40;
		else i == 0 ? width += 40 : width -= 40;
		$("<div class='fav-header-col' style='width: "+width+"px;'>"+headers[i]+"</div>").appendTo($header);
	}

	/* build the accounts list */
	var $dataContainer = $("<div class='fav-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul id='AddAccountsFilterList' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( items, function() {

		$li = $("<li>").appendTo($ul),
		$row = $("<div class='fav-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				if ( $target.hasClass("fav-data-col") ) {
					$target = $target.closest("div.fav-row");
				}
				$target = $target.find("input[name='_addAccount']");
				var checker = ( $target.is(":checked") ) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
			}
			if ( !$(this).prop("checked") ) {
				$("input[name='_selectAll']").prop("checked", false)
			}
			if (  $("input[name=_addAccount]:checked").length == $("input[name=_addAccount]").length ) {
				$("input[name='_selectAll']").prop("checked", true)
			}
		}),
		$checkDiv = $("<div class='fav-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row);
		var $checkInput = $("<input value='"+this.number+"' type='checkbox' name='_addAccount'/>").appendTo($checkDiv).on("change", function() {
				var selected = ( $(this).is(":checked") ) ? $(this).closest("div.fav-row").addClass("selected") : $(this).closest("div.fav-row").removeClass("selected");
		});
		for(var i = 0; i < headers.length; i++){
			var width = 600 / headers.length;
			if(headers.length > 2) i <= 2 ? width += 20 : width -= 40;
			else i == 0 ? width += 40 : width -= 40;
			$("<div class='fav-data-col' style='width: "+width+"px;'>"+(i == 0 ? this.number : (i == 1 ? this.name : this.currency))+"</div>").appendTo($row);
		}
		/*
		$name = $("<div class='fav-data-col' style='width: 220px;'>"+this.name+"</div>").appendTo($row),
		$number = $("<div class='fav-data-col' style='width: 220px;'>"+this.number+"</div>").appendTo($row),
		$currency = $("<div class='fav-data-col' style='width: 160px;'>"+this.currency+"</div>").appendTo($row) */
		
		if($.inArray(this.number, SEL_INPUT[0].selectize.items) > -1){ 
			//$checkInput.attr("checked", true); 
			//$row.addClass("selected"); 
			$li.remove();
		}
	});

	/* build and show the add accounts dialog */
	var _origin = _target;
	var _dialog = {
		id: "AddAccounts",
		title: title,
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Add", icon: "<i class='fa fa-plus fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();saveSelectedAccounts(_dialog)}}], cssClass:"primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('#AddAccountsFilterList');

	/* if no accounts are available display a message */
	if ( !$("#AddAccountsFilterList").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

$(".account-search-column label>i").click(function(){ showAddItems($(this), "Add Entities", ["Billing Entity Number", "Billing Entity Name","Status"], accounts, $('.account-search'))  });
$(".requesttype-search-column label>i").click(function(){ showAddItems($(this), "Add Request Types", [ "Request Type"], REQUEST_TYPES, $('.requesttype-search')) });
$(".requeststatus-search-column label>i").click(function(){ showAddItems($(this), "Add Request Statuses", [ "Request Status"], REQUEST_STATUS, $('.requeststatus-search')) });
$(".requestor-search-column label>i").click(function(){ showAddItems($(this), "Add Requestor", [ "First Name","Last Name","User Id"], REQUESTOR_NAMES, $('.requestor-search')) });
/**********************************************************************
CONTROL MENU FUNCTIONS
**********************************************************************/

/* view menu */
$("#viewMenu").on("click.filter-view", function(e) {
 e.preventDefault();
  var activeStatusFilter = $('#viewMenuHeader span').html(value);
  $( "#savesearches a:contains('"+activeStatusFilter+"')" ).parent('li').addClass('active');
 var $target = $(e.target);
 if ( $target.prop("nodeName") == "A" && !$target.parent().hasClass("no-set") ) {
	 var value = $target.attr("data-value");

  if (statusString != value) {
		 statusString = value;
	 };
	 viewFilter();	   
}
});

/* group by menu */
$("#groupMenu [data-action='group']").on("click.group-by", function(e) {
	e.preventDefault();
	var $target = $(e.target), item = $target.attr("data-item"), text = $target.text();
	groupBy(item,text);
});

/* collapse all groups  */
$(".collapse-mark").bind("click.collapse-mark", function(e) {
	e.stopPropagation();
	var $item = $(".collapse-mark").parent("li");
	if( groupCollapseSetting == 0 ) {
		$item.addClass("on");
		groupCollapseSetting = 1;
	} else {
		$item.removeClass("on");
		groupCollapseSetting = 0;
	}
});

/**********************************************************************
ACTION MENU INTERACTION
**********************************************************************/
$("#actionMenuControl").on("click.show-actionMenu", function(e) {
	var rowsLength =  grid.getSelectedRows().length;
	
	var menuLink = $("#actionMenuControl").children("a")
	if (rowsLength == 0) {
		menuLink.attr({"href":"#actionMenuNoSelected"});
	} else if (rowsLength == 1) {
		var rowId = grid.getSelectedRows()[0];
		var rowdata = dataView.getItem(rowId);
		if(rowdata.requeststatus=="Unsuccessful"){
	       menuLink.attr({"href":"#actionunsuceessMenu"});
	      }
		  else
		  {
		menuLink.attr({"href":"#actionMenu"});		
		  }
	} else if (rowsLength > 1) {
	    var rowId = grid.getSelectedRows()[1];
		var rowdata = dataView.getItem(rowId);
	    if(rowdata.requeststatus=="Unsuccessful"){
	       menuLink.attr({"href":"#actionunsuccessMenuMulti"});
	      }
		  else
		  {
		menuLink.attr({"href":"#actionMenuMulti"});
		  }
	}
});

/* remember grid settings */
$(".remember-settings").on("click", function() {
	$("body").addClass("loading");
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("Default settings for this screen have been updated", 500, 3000);
	}, 1000);
});

/* new request */
$("#newRequestButton").on("click", function(e) {
	e.preventDefault();
	var $target = $(e.target);
	$("#requestForm").trigger("reset");
	$("#transactionRequestSteps").hide().children("li").removeClass("active complete");
	$("#defaultSteps").children("li").removeClass("active complete");
	$("#defaultSteps").show().children("li[data-step='1']").addClass("active");
	$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0).siblings(":not('.top-controls')").addClass("hidden");
	$target.attr({'data-panel': '#newRequest', 'data-switch': 'switch-panels'}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
});

/*seach dialog */
$("#searchAccountsDialog").on("click", function(e) {
	e.preventDefault();
	showAddAccounts( $(this) )
});
$("#searchAccountsDialogreplace").on("click", function(e) {
	e.preventDefault();
	showAddAccountReplace( $(this) )
});
$("#searchAccountsDialogCancel").on("click", function(e) {
	e.preventDefault();
	showAddAccountCancel( $(this) )
});
$("#searchAccountsDialogLimit").on("click", function(e) {
	e.preventDefault();
	showAddAccounts1( $(this) )
});
$("#searchAccountsStat").on("click", function(e) {
	e.preventDefault();
	showAddAccounts10( $(this) )
});
/**********************************************************************
FIND REQUESTS SEARCH CONTROL
**********************************************************************/

$("#clearRequestCriteria").on("click", function() {
	$("#findRequests").val('');
	$("#findRequests").blur();
	$("#clearRequestCriteria").hide();
	searchString = "";
	findRequests();
});

$("#findRequests").keyup(function (e) {
	if (e.which == 27) {
		$("#clearRequestCriteria").hide();
		this.value = '';
		this.blur()
	}
	searchString = this.value;
	findRequests();
	if ( this.value != "" ) {
		$("#clearRequestCriteria").show()
	} else {
		$("#clearRequestCriteria").hide()
	}
});

$("#findMenu").on("click.set-find", "a", function(e) {
	e.preventDefault();
	var repPlaceholder = $(this).text(), searchString = $(this).attr("data-find");
	if (searchPoint != searchString) {
		$("#findRequests").attr("placeholder", repPlaceholder);
		searchPoint = searchString;
		$("#findRequests").val('').focus();
		$("#clearRequestCriteria").hide();
		searchString = '';
		findRequests();
	}
});


/**********************************************************************
NEW REQUEST INITIALIZATION
**********************************************************************/

$("[data-action='set-request-type']").on("click", function(e) {
	e.preventDefault();
	$("#newRequest").addClass("loading");
	$("#requestForm").trigger("reset");
	$("#existingEnquiriesNote").hide();
	var cat = $(this).closest("ul.step-list").attr("data-request-type");
	var type = $(this).attr("data-request-type");
	var	steps;
	$("[data-request-header]").html($(this).text());
	if (cat=="commercialcard") {
		$("#newRequest").attr("data-category","commercialcard");
		steps = $("#defaultSteps");
		steps.children("[data-step='1']").removeClass("active").addClass('complete');
		steps.children("[data-step='3']").addClass("active");
		if ( type == "new-card" ) {
		    $("[data-request-header]").html('Cardholder Online Application');
			$("#requestSummary").addClass('hidden');
			$("#newRequest").removeClass('hidden');
        	setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='6']").removeClass("hidden").scrollTop(0);
				$("#bottomControlNotes").removeClass("hidden");
				$("#limitChangeNote").hide();
				$("#newRequest").removeClass("loading");
				$("#accountInput").focus();
				if ( $(".ie8").size() > 0 ) {
					$("body").find(".fa").addClass("repaint");
					setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
				}
			}, 500);
        } else if ( type == "bulk-upload") {
		    steps = $("#defaultSteps");
			steps.hide();
		    stepsnew = $("#bulkUploaddefaultSteps");
			stepsnew.show();
			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='7']").removeClass("hidden").scrollTop(0);
				$("#bottomControlNotes").removeClass("hidden");
				$("#limitChangeNote").hide();
				$("#newRequest").removeClass("loading");
				$("#accountInput").focus();
				if ( $(".ie8").size() > 0 ) {
					$("body").find(".fa").addClass("repaint");
					setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
				}
			}, 500);
		} else if(type=="limit-change") {
			$("#newRequest").attr("data-category","commercial-card");
			$("[data-request-header]").html('Card Limit Change');
			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='21']").removeClass("hidden").scrollTop(0);
				$("#bottomControlNotes").removeClass("hidden");
				$("#limitChangeNote").show();
				$("#newRequest").removeClass("loading");
				if ( $(".ie8").size() > 0 ) {
					$("body").find(".fa").addClass("repaint");
					setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
				}
			}, 500);
		} else if(type=="replace-card") {
			$("#repcard_altDeliveryInfo").hide();
		    $("#newRequest").attr("data-category","commercial-card");
			steps = $("#defaultSteps");
			steps.children("[data-step='1']").removeClass("active").addClass('complete');
			steps.children("[data-step='3']").addClass("active");
			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='22']").removeClass("hidden").scrollTop(0);
				$("#bottomControlNotes").removeClass("hidden");
				$("#limitChangeNote").hide();
				$("#newRequest").removeClass("loading");
				if ( $(".ie8").size() > 0 ) {
					$("body").find(".fa").addClass("repaint");
					setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
				}
			}, 500);
		} else if(type=="cancel-card") { 
		    $("#newRequest").attr("data-category","commercial-card");
		    $("[data-request-header]").html('Cancel Card');
			steps = $("#defaultSteps");
			steps.hide();
			stepsnew = $("#cancelCarddefaultSteps");
			stepsnew.show();
			stepsnew.children("[data-step='1']").removeClass("active").addClass('complete');
			stepsnew.children("[data-step='3']").addClass("active");
			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='23']").removeClass("hidden").scrollTop(0);
				$("#bottomControlNotes").removeClass("hidden");
				$("#limitChangeNote").hide();
				$("#newRequest").removeClass("loading");
				if ( $(".ie8").size() > 0 ) {
					$("body").find(".fa").addClass("repaint");
					setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
				}
			}, 500);
		} else if(type=="statement-pref") {  
			$("#repcard_altDeliveryInfo").hide();
			$("[data-request-header]").html('Statement Preferences Change');
		    $("#newRequest").attr("data-category","commercial-card");
			steps = $("#defaultSteps");
			steps.children("[data-step='1']").removeClass("active").addClass('complete');
			steps.children("[data-step='3']").addClass("active");
			setTimeout(function() {
				$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
				$("#newRequest").find("div.scroll-area[data-step='20']").removeClass("hidden").scrollTop(0);
				$("#bottomControlNotes").removeClass("hidden");
				$("#limitChangeNote").hide();
				$("#newRequest").removeClass("loading");
				if ( $(".ie8").size() > 0 ) {
					$("body").find(".fa").addClass("repaint");
					setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
				}
			}, 500);
		}
	}
});

$("[data-action='previousStep']").on("click",function(e){
	e.preventDefault();
	$("#newRequest").addClass("loading");
	var _step = $(this).closest("div.scroll-area").attr("data-step"), _category = $("#newRequest").attr("data-category");
	if (_step == "11") {
		$("#cancelCarddefaultSteps").hide().children("[data-step]").removeClass("active complete");
		$("#defaultSteps").show().children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
		$("#newRequest").find("div.scroll-area[data-step='11'], div.scroll-area[data-step='12']").addClass("hidden");
		$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
		$("#newRequest").find("div#bottomcontrolsstep10").addClass("hidden");
	}
	else if(_step == "6")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='6']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
		else if(_step == "5")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='5']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "8")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='8']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "9")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='9']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "10")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='10']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "12")
    {
	   $("#cancelCarddefaultSteps").children("[data-step='3']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#cancelCarddefaultSteps").children("[data-step='1']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='12']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='11']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "14")
    {
	   $("#cancelCarddefaultSteps").children("[data-step='3']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#cancelCarddefaultSteps").children("[data-step='1']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='14']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='13']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "20")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='20']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	
	else if(_step == "21")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='21']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "22")
    {
	   $("#defaultSteps").children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#defaultSteps").children("[data-step='3']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='22']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
    }
	else if(_step == "23")
    {
	   $("#cancelCarddefaultSteps").hide().children("[data-step]").removeClass("active complete");
	   $("#defaultSteps").show().children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#newRequest").find("div.scroll-area[data-step='11'], div.scroll-area[data-step='23']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
	   $("#newRequest").find("div#bottomcontrolsstep10").addClass("hidden");
    }
	setTimeout(function() {
		$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 200);
});

$("[data-action='nextStep']").on("click",function(e){
	e.preventDefault();
	$("#newRequest").addClass("loading");
	var _step = $(this).closest("div.scroll-area").attr("data-step"), _category = $("#newRequest").attr("data-category");
	
	if(_step=='6')
	  {
	    $("#newRequest").find("div.scroll-area[data-step='6']").addClass("hidden");
        $("#newRequest").find("div.scroll-area[data-step='5']").removeClass("hidden").scrollTop(0);
	  }
	else if (_step == "11") {	       
			$("#cancelCarddefaultSteps").children("[data-step='4']").addClass("active").siblings().removeClass("active complete");
			$("#cancelCarddefaultSteps").children("[data-step='3']").addClass("complete");
			$("#newRequest").find("div.scroll-area[data-step='11']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='12']").removeClass("hidden").scrollTop(0);
	}else if(_step == "21"){
			$("#newRequest").find("div.scroll-area[data-step='21']").addClass("hidden");
            $("#newRequest").find("div.scroll-area[data-step='8']").removeClass("hidden").scrollTop(0);
	} else if(_step =="20"){
			$("#newRequest").find("div.scroll-area[data-step='20']").addClass("hidden");
            $("#newRequest").find("div.scroll-area[data-step='10']").removeClass("hidden").scrollTop(0);
	}else if(_step =="22"){
			$("#newRequest").find("div.scroll-area[data-step='22']").addClass("hidden");
            $("#newRequest").find("div.scroll-area[data-step='9']").removeClass("hidden").scrollTop(0);
	}else if(_step =="23"){
			$("#newRequest").find("div.scroll-area[data-step='23']").addClass("hidden");
            $("#newRequest").find("div.scroll-area[data-step='11']").removeClass("hidden").scrollTop(0);
	}else if(_step =="13"){
			$("#cancelCarddefaultSteps").children("[data-step='4']").addClass("active").siblings().removeClass("active complete");
			$("#cancelCarddefaultSteps").children("[data-step='3']").addClass("complete");
			$("#newRequest").find("div.scroll-area[data-step='13']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='14']").removeClass("hidden").scrollTop(0);
	}
	setTimeout(function() {
		$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 200);
});

function createAgain() {
	setTimeout(function(){
		$("body").removeClass("loading");
		$(".header, .shell").find(":focusable").removeAttr("tabindex");
		$("#otherRequestForm").trigger("reset");
		$("#cancelCarddefaultSteps").hide().children("li").removeClass("active complete");
		$("#defaultSteps").show().children("li[data-step='1']").addClass("active").removeClass("complete").siblings().removeClass("active complete");
		$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0).siblings(":not('.top-controls')").addClass("hidden");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 500)
}

function finishCreating() {
	setTimeout(function(){
		$("body").removeClass("loading");
		$(".header, .shell").find(":focusable").removeAttr("tabindex");
		$("#requestSummary").removeClass('hidden');
		$("#newRequest, #requestDetail").addClass('hidden');
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 500)
}

$("[data-action='submitRequest']").on("click", function(e){
	e.preventDefault();
	$("body").addClass("loading");
	$(".header, .shell").find(":focusable").attr("tabindex", -1);
	setTimeout(function(){
		buildCustomConfirmDialog( "<span style='font-size: 16px; color: #007dba; font-weight: 600;'>Request ID: 837342281</span>", "<span style='font-weight: 600;'>Your Service Request Has Been Succefully Submitted.</span>", "<span style='display: inline-block; max-width: 400px;'></span>", "View service requests", function(){finishCreating()}, "", "Raise another service request", function(){createAgain()}, "primary");
	},1500);
});

/* billing entities autocomplete */
$("#billingEntityNumberSelect").autocomplete({
	autoFocus: false,
	delay: 0,
	minLength: 1,
	source: function (request, response) {
		var results = $.ui.autocomplete.filter(billingEntityNumbers, extractLast( request.term ));
		if (!results.length) {
			results = [
				{
					value: 'No Matches Found'
				}
			];
		}
		response(results);
	},
	focus: function() {
		return false;
	},
	select: function(event, ui) {
		if (ui.item.value == "No Matches Found") {
			this.value = "";
			return false;
		} else {
			this.value = ui.item.value;
			return false;
		}
	}
}).on("focus", function(){
	$(this).one("mouseup", function() {
		$(this).select();
	})
});

var b=document.location.href.split(".html")[1];

if (b == "#new") {
	$("#newRequestButton").trigger("click");
}
$("#altAdress").change(function()
   {
       if(this.checked)
      {
	  $("#altDeliveryInfo").show();
	  }
	  else
	  {
	   $("#altDeliveryInfo").hide();
	  }
	   
   });
/**********************************************************************
APPROVE REQUEST
**********************************************************************/
function approveSuccessConfirmation(e)
{
	$("body").addClass("loading");
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully approved the selected card requests.", 500, 3000);
	}, 1000);
}

function populateApproveContent() {
	var $approveData = $("<div class='confirmation-message' style='padding:0px 20px 0px 20px'><p style='text-align:justify;'><input type='checkbox' name='alternativeadress' id='acknMessage' style='margin-right:10px;'>I declare that I am an Authorised Signatory for the above Billing Account, that the details contained in this completed form are true and correct and have been given to enable ANZ to issue an ANZ Commercial Card to the above individual as an agent of the Client. I hereby declare that I have read, understood and will comply with the obligations on me, which appear below.</p></div>");
	
	return $approveData;
}
function showApproveDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Approve",
		size: "small",
		icon: "",
		content: function(){return populateApproveContent()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Submit", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog);approveSuccessConfirmation(e)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
$(".approve-request").on("click", viewApproveDialog);

/**********************************************************************
REJECT REQUEST
**********************************************************************/
function rejectSuccessConfirmation(e){
	e.preventDefault();
	buildConfirmDialog( "Are you sure you want to reject Selected Card Requests?", '',function(){
	$("body").addClass("loading");
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully rejected the selected card requests.", 500, 3000);
	}, 1000);
	},'Yes', 'No');
}

$(".reject-request").on("click", viewRejectDialog);

/**********************************************************************
DELETE REQUEST
**********************************************************************/
function deleteSuccessConfirmation(e){
	e.preventDefault();
	buildConfirmDialog( "Are you sure you want to Cancel Selected Card Requests?", '',function(){
	$("body").addClass("loading");
	if($('#requestDetail').hasClass('hidden')){
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully cancelled the selected card requests.", 500, 3000);
	}, 1000);
	
	}
	else
	{
		$("body").addClass("loading");
		window.location.href='commercial-card-service-requests.html?cancelled=yes';
	}
	},'Yes', 'No');
}

$(".cancel-request").on("click", deleteSuccessConfirmation);

/**********************************************************************
RESUBMIT REQUEST
**********************************************************************/
function resubmitunSuccessConfirmation(e){
	e.preventDefault();
	buildConfirmDialog( "Are you sure you want to Resubmit the Selected Card Requests?", '',function(){
	$("body").addClass("loading");
	if($('#requestDetail').hasClass('hidden')){
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully Resubmitted the selected card requests.", 500, 3000);
	}, 1000);
	
	}
	else
	{
		$("body").addClass("loading");
		window.location.href='commercial-card-service-requests.html?resubmit=yes';
	}
	
	},'Yes', 'No');
}

$(".resubmit-request").on("click", resubmitunSuccessConfirmation);
/**********************************************************************
VERIFY REQUEST
**********************************************************************/
function verifySuccessConfirmation(e){
	$("body").addClass("loading");
	if($('#requestDetail').hasClass('hidden')){
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully verified the selected card requests.", 500, 3000);
	}, 1000);
	
	}
	else
	{
		$("body").addClass("loading");
		window.location.href='commercial-card-service-requests.html?verify=yes';
	}
	
}
function populateIdentificationContent() {
	var $identificationData = $("<div class='confirmation-message' style='padding:20px;'><p>It is a requirement all Cardholders are identified in accordance to the Anti- Money Laundering and Counter Terrorism Financing Act 2006 (Cth) (The \"AML Act\"). A cardholder can be identified by any of the following two identification methods set out in A & B below:</p></div>");
	$content1 = $("<div style='margin-top:15px;margin-bottom:10px;font-weight:bold;'>A. ANZ Customer Identification Process</div>").appendTo($identificationData);
	$content2 = $("<p>The identification required can be complied with by ensuring that a Cardholder(s)/Authorised User(s) has completed ANZ's Customer Identification Process carried out by an ANZ's staff member who is authorised to open bank accounts.</p>").appendTo($identificationData);
	$content3 = $("<div style='margin-top:15px;margin-bottom:10px;font-weight:bold;'>B. Corporate Customer Identification Process</div>").appendTo($identificationData);
	$content4 = $("<p>Company entities, trusts (where the trustee is a company), registered co-operatives, incorporated associations and government bodies may use the \"Corporate Customer\" method of cardholder identification under the AML Act. To fulfill this function, the \"Corporate Customer\" may nominate an Identification Officer in section 2 of this form overleaf. For the purpose of this clause, Identification Officer is defined on the attached sheet. The Identification Officer will be responsible for confirming the identity of the Cardholder(s)/Authorised User(s) and for declaring that the Cardholder(s)/Authorised User(s) is/are authorised to act as an agent on behalf of the Client.</p></li>").appendTo($identificationData);
	$content5 = $("<p>The Identification Officer must declare that the Cardholder/Authorised User has been identified by signing the front of this form.</p>").appendTo($identificationData);
	$content6 = $("<p>It is an offence under the AML Act to make a false or misleading statement.</p>").appendTo($identificationData);
	$content7 = $("<p>Note: If you have any enquiries regarding the above, please contact the ANZ Commercial Cards Service Centre on 1800 032 481.</p>").appendTo($identificationData);
	$content8= $("<div style='margin-top:15px;margin-bottom:10px;font-weight:bold;'>Responsibilities of an Identification Officer</div>").appendTo($identificationData);
	$content9 = $("<div class='list-container' style='margin:5px 0;'>The Identification Officer must collect:</div>").appendTo($identificationData);
	$contentlist=$('<ul />').appendTo($content9);
	$contentlistItem=$("<li>The Cardholder's/Authorised User's Full Name</li><li>Evidence of Cardholder's/Authorised User's authorisation to act on behalf of client</li><li>Title of the position or role held by Cardholder/Authorised User</li>").appendTo($contentlist);
	$content10= $("<div class='list-container' style='margin:5px 0;'>The Identification Officer must also verify:</div>").appendTo($identificationData);
	$contentlist1=$('<ul style="list-style-type:disc;list-style-position:inside;" />').appendTo($content10);
	$contentlistItem1=$("<li>Cardholder's/Authorised User's Full Name</li>").appendTo($contentlist1);
	$content11= $("<div class='list-container' style='margin:5px 0;'>The Identification Officer must provide to ANZ (by completing this form):</div>").appendTo($identificationData);
	$contentlist2=$('<ul style="list-style-type:disc;list-style-position:inside;"/>').appendTo($content11);
	$contentlistItem2=$("<li>Cardholder's/Authorised User's Full Name</li><li>Evidence of authority of identified Cardholder/Authorised User</li><li>Cardholder's/Authorised User's Date of Birth</li>").appendTo($contentlist2);;
	return $identificationData;
}
function showIdentificationDialog(e){
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog1 = {
		id: "folderManager",
		title: "Customer Identification Requirements",
		size: "large",
		icon: "",
		content: function(){return populateIdentificationContent()},
		buttons: [
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog1)}}] }
		]
	}
	dialogViewer( _origin, _dialog1, dialogBuilder(_dialog1) );
}

function populateVerifyContent() {
	var $wrapper = $("<div class='form-section top-label' />");
	var $approveSec = $("<div id='verify-section' class='confirmation-message'/>").appendTo($wrapper);
	var $ackmes = $("<p style='margin:15px 10px;text-align:justify;'>I hereby declare that I am an Identification Officer for this Billing Account. In accordance with the Anti-Money Laundering and Counter-Terrorism Financing Act 2006 (Cth) (the \"AML Act\"), I hereby declare that the individual(s) nominated as a Cardholder above is authorised to act as an agent of the Client holding the Billing Account. For requirements under the AML Act please refer to.</p>").appendTo($approveSec);
	var $acklink = $("<a href='#' title='Customer Identification Requirements' style='color:#004165;cursor:pointer; text-decoration:none;' id='verifyAcknowledge'>Customer Identification Requirements.</a>").appendTo($ackmes);
    var $Check=$("<input type='checkbox' name='alternativeadress' id='acknMessage' style='margin:0px 10px 0px 0px;'>").prependTo($ackmes);
	var $row = $("<div class='row fluid' style='margin-top:10px' />").appendTo($approveSec);
	var $labelColumn = $("<div class='label-column' style='vertical-align:top;'/>").appendTo($row);
	var $label = $("<label>Comments</label>").appendTo($labelColumn);
	var $dataColumn = $("<div class='data-column' style='vertical-align:top;'/>").appendTo($row);
	var $textareacontainer = $("<span/>").appendTo($dataColumn);
	var $data = $("<textarea style='width: 95%; max-width: 95%; height: 200px;' id='_addComment'></textarea>").appendTo($textareacontainer);
	$acklink.bind("click", showIdentificationDialog);
	 $Check.bind("change", showChecked);
	//$('#verifyAcknowledge').on("click", showIdentificationDialog);
	
	return $wrapper;
	/*var $approveData = $("<div class='confirmation-message' style='padding:0px 20px 0px 20px'><p style='text-align:justify;'><input type='checkbox' name='alternativeadress' style='margin-right:10px;'>I hereby declare that I am an Identification Officer for this Billing Account. In accordance with the Anti-Money Laundering and Counter-Terrorism Financing Act 2006 (Cth) (the \"AML Act\"), I hereby declare that the individual(s) nominated as a Cardholder above is authorised to act as an agent of the Client holding the Billing Account. For requirements under the AML Act please refer to \"<a href='#' title='Customer Identification Requirements' style='color:#004165;cursor:pointer; text-decoration:none;' id='verifyAcknowledge'>Customer Identification Requirements</a>\".</p></div>");
	$approveData.bind("click", showIdentificationDialog);
	return $approveData;*/
}
function showVerifyDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManagerNext",
		title: "Verify",
		size: "small",
		icon: "",
		content: function(){return populateVerifyContent()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Submit", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){
				e.preventDefault();
				if(!$(this).hasClass('disabled')){
					dialogHider(_dialog);
					verifySuccessConfirmation(e);
				}
			}}], cssClass: "disabled submit primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
$(".verify-request").on("click", showVerifyDialog);

/**********************************************************************
UPLOAD STATUS
**********************************************************************/  
//$("[data-action='submitBulkRequest']").on("click",function(e){ 
function uploadClick()
{
    //e.preventDefault();
	$("#newRequest").addClass("loading");
	var _step = $(this).closest("div.scroll-area").attr("data-step"), _category = $("#newRequest").attr("data-category");
    $('#bulkUploaddefaultSteps').children("[data-step='1']").removeClass("active").addClass('complete');
	$('#bulkUploaddefaultSteps').children("[data-step='3']").addClass("active"); 	
    if(isCompatible)
	{
	  $("[data-request-header]").html('Bulk Upload File Confirmation');
	  $("#newRequest").find("div.scroll-area[data-step='7']").addClass("hidden");
      $("#newRequest").find("div.scroll-area[data-step='15']").removeClass("hidden").scrollTop(0);
	  $("#newRequest").find("div#bottomcontrolsstep10").removeClass("hidden");
	  isCompatible=false;
	}
	else
	{
	  $("[data-request-header]").html('Bulk Upload File Exception');
	  $("#newRequest").find("div.scroll-area[data-step='7']").addClass("hidden");
      $("#newRequest").find("div.scroll-area[data-step='16']").removeClass("hidden").scrollTop(0);
	  $("#newRequest").find("div#bottomcontrolsstep10").removeClass("hidden");
	}
    	setTimeout(function() {
		$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 200);
}
function showProcessingDialog(e) {

	//e.preventDefault();
	var fileinput = $("#browse");
if(fileinput.val()!='')
	{
	
	/* define the steps */
 	var steps = [ "Uploading File", "Checking File", "Processing File" ];

 	/* build the content */
	var $content = $("<div class='processing-steps' />"),
	$connector = $("<div class='step-connector' />").appendTo($content),
	$ul = $("<ul />").appendTo($content), $li, $div, $text;
	for ( var i = 0; i < steps.length; i++ ) {
		$li = $("<li />").appendTo($ul),
		$div = $("<div class='processing-step' />").appendTo($li),
		$text = $("<span>"+steps[i]+" Pending</span>").appendTo($div);
	}

	/* build and open the dialog */
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "ProcessingDialog",
		title: "Your Request is Being Processed",
		size: "small",
		icon: "<i class='fa fa-male'></i>",
		content: $content,
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog);uploadClick()}}], cssClass:"primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* set the height of the connector line */
	$connector.css({ "height" : $ul.height() });

	/* run the sequence */
	var n = 0;
	function runSequence(n) {
		if ( n < steps.length ) {
			var $div = $ul.children("li").eq(n).children("div"), $span = $div.children("span");
			setTimeout(function(){
				$div.addClass("progress");
				$span.html(steps[n]+" In Progress");
				setTimeout(function(){
					$div.addClass("complete");
					$span.html(steps[n]+" Complete");
					n = n+1;
					runSequence(n);
				},2000);
			},300);
		} else {
			return false;
		}
	}
	runSequence(n);
	}
	
}
$("[data-action='submitBulkRequest']").on("click", showProcessingDialog);
/*$("[data-action='submitBulkRequest']").on("click", function(e){
	var fileinput = $("#browse");
	if(fileinput.val()!='')
	{
		showProcessingDialog(e);
	}
	
});*/

$("[data-action='bulkClose']").on("click",function(e){
    e.preventDefault();
    $('#filename li').remove();
	$('#fakeBrowse').removeClass('disabled');
	$("#browse").removeAttr("disabled");
    $('#newRequestButton').trigger('click');	
});

//limit change
   $("#permanentlimit").click(function(){ 
	$("#expiryd").hide();
	$("#revertlimit").hide();
	 $("#limitcontrolsection").css('display','');
   });
   
    $("#temporarylimit").click(function(){
   $("#expiryd").show();
   $("#revertlimit").show();
   $("#limitcontrolsection").css('display','block');
   });
    //limit change
   //replace_card  356844
 $("#repcard_altAdress").change(function()
   {
       if(this.checked)
      {
	  $("#repcard_altDeliveryInfo").show();
	  }
	  else
	  {
	   $("#repcard_altDeliveryInfo").hide();
	  }
	   
   });
   
   /*error show case new limit*/
    $("#newLimit").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
               return false;
    }
   });
$('#limitChangeSubmit').on('click', function() {
          var currentLimit = $('#Currentlimit'),
          newLimit = $('#newLimit');
          //display error message
		  var currLimit=currentLimit.val().replace(",", "");
          if(parseInt(newLimit.val()) > parseInt(currLimit))
          {
                   $('#newLimitError').css("display", "block");
                   $('#newLimit').parents('.row').addClass("error");
          }
          else
          {
                   $('#newLimitError').css("display", "none");
                   $('#newLimit').parents('.row').removeClass("error");
				   $("body").addClass("loading");
	               $(".header, .shell").find(":focusable").attr("tabindex", -1);
	              setTimeout(function(){
		                 buildCustomConfirmDialog( "<span style='font-size: 16px; color: #007dba; font-weight: 600;'>Request ID: 837342281</span>", "<span style='font-weight: 600;'>Your Service Request Has Been Succefully Submitted.</span>", "<span style='display: inline-block; max-width: 400px;'>Request will not be processed unless it has been approved (if applicable) and submitted in accordance with ANZ's requirements.</span>", "View service requests", function(){finishCreating()}, "", "Raise another service request", function(){createAgain()}, "primary");
	              },1500);
          }
});


   
/**********************************************************************
				SETUP THE DATE FUNCTIONS
**********************************************************************/
var rollingDates = ["Today","Yesterday","Week to Date","Previous Week","Month to Date","Previous Month"];

$("#postingdaterolling, #valuedaterolling").autocomplete({
	source: rollingDates,
	autoFocus: false,
	delay: 0,
	minLength: 0,
	focus: function(e,ui) {
		return false;
	},
	select: function(e,ui) {
		$(this).autocomplete("close");
	},
	change: function(e,ui) {
		var matcher = $(this).val();
		var matchie = "";
		var valid = false;
		$.each(rollingDates, function() {
			if(this.toLowerCase() == matcher.toLowerCase()) {
				valid = true;
				matchie = this;
				return false;
			}
		});
		$(this).val(matchie);
		if(!valid) {
			$(this).val("");
			return false;
		}
	}
});
$("#postingdaterolling, #valuedaterolling").on("focus", function(e) {
	e.preventDefault();
	$(this).autocomplete("search", "");
}).on("click", function(e) {
	$(this).autocomplete("search", "");
}).on("keydown", function(e) {
	if(e.keyCode == "9") {
		e.stopImmediatePropagation();
	}
});
var postingdate = $( "#effectivedate_" ).datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true});
var valuedate = $( "#expiredate_" ).datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true});
var postingdates = $( "#postingdatefrom, #postingdateto" )
$("#postingdatefrom").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#postingdateto").datepicker( "option", "minDate", selectedDate)
		setTimeout(function(){$("#postingdateto").focus()},50)
	}
});
$("#postingdateto").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#postingdatefrom").datepicker( "option", "maxDate", selectedDate)
	}
});
var valuedates = $( "#valuedatefrom, #valuedateto" )
$("#valuedatefrom").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#valuedateto").datepicker( "option", "minDate", selectedDate)
		setTimeout(function(){$("#valuedateto").focus()},50)
	}
});
$("#valuedateto").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#valuedatefrom").datepicker( "option", "maxDate", selectedDate)
	}
});



$("#billingEntityNumberSelect1").autocomplete({
	autoFocus: false,
	delay: 0,
	minLength: 1,
	source: function (request, response) {
		var results = $.ui.autocomplete.filter(billingEntityNumbers, extractLast( request.term ));
		if (!results.length) {
			results = [
				{
					value: 'No Matches Found'
				}
			];
		}
		response(results);
	},
	focus: function() {
		return false;
	},
	select: function(event, ui) {
		if (ui.item.value == "No Matches Found") {
			this.value = "";
			return false;
		} else {
			this.value = ui.item.value;
			return false;
		}
	}
}).on("focus", function(){
	$(this).one("mouseup", function() {
		$(this).select();
	})
});	

//replace card
$("#billingEntityNumberSelect2").autocomplete({
	autoFocus: false,
	delay: 0,
	minLength: 1,
	source: function (request, response) {
		var results = $.ui.autocomplete.filter(billingEntityNumbers, extractLast( request.term ));
		if (!results.length) {
			results = [
				{
					value: 'No Matches Found'
				}
			];
		}
		response(results);
	},
	focus: function() {
		return false;
	},
	select: function(event, ui) {
		if (ui.item.value == "No Matches Found") {
			this.value = "";
			return false;
		} else {
			this.value = ui.item.value;
			return false;
		}
	}
}).on("focus", function(){
	$(this).one("mouseup", function() {
		$(this).select();
	})
});	
//replace card

//statement preference
$("#billingEntityNumberSelect10").autocomplete({
	autoFocus: false,
	delay: 0,
	minLength: 1,
	source: function (request, response) {
		var results = $.ui.autocomplete.filter(billingEntityNumbers, extractLast( request.term ));
		if (!results.length) {
			results = [
				{
					value: 'No Matches Found'
				}
			];
		}
		response(results);
	},
	focus: function() {
		return false;
	},
	select: function(event, ui) {
		if (ui.item.value == "No Matches Found") {
			this.value = "";
			return false;
		} else {
			this.value = ui.item.value;
			return false;
		}
	}
}).on("focus", function(){
	$(this).one("mouseup", function() {
		$(this).select();
	})
});	
//statement preference
	function showAddAccounts1(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Name</div>").appendTo($header),
	$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Status</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( accounts, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#billingEntityNumberSelect1").val($target.attr("data-number"));
			$("#billingEntityNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.name+"</div>").appendTo($row),
		$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Entities",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}


//statement preference
function showAddAccounts10(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an entity...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 240px;'>Billing Entity Name</div>").appendTo($header),
	$currencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Status</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number, $currency;
	$.each( accounts, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#billingEntityNumberSelect10").val($target.attr("data-number"));
			$("#billingEntityNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 240px;'>"+this.name+"</div>").appendTo($row),
		$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddAccounts",
		title: "Add Entities",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}
//statement preference
$("#searchAccountsDialog1").on("click", function(e) {
	e.preventDefault();
	showAddAccounts2( $(this) )
});

$("#searchAccountsDialog3").on("click", function(e) {
	e.preventDefault();
	showAddCards3( $(this) )
});
$("#searchCardDialogCancel").on("click", function(e) {
	e.preventDefault();
	showAddCardsCancel( $(this) )
});
$("#searchCardnumberDialog").on("click", function(e) {
	e.preventDefault();
	showAddCards( $(this) )
});

	function showAddCards3(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a card number...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Card Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Cardholder Name</div>").appendTo($header);
	//$currencyHeadercurrencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number;
	$.each( cardno, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#cardNumber").val($target.attr("data-number"));
			$("#cardNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.name+"</div>").appendTo($row)
		//$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddCards",
		title: "Add Card Numbers",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}
function showAddCardsCancel(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a card number...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Card Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Cardholder Name</div>").appendTo($header);
	//$currencyHeadercurrencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number;
	$.each( cardno, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#cardNumberCancel").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.name+"</div>").appendTo($row)
		//$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddCards",
		title: "Add Card Numbers",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}



var cardNumbers = [];
var cardno = [
	{ number:"************134456", name: "Joe Smith" },
	{ number:"************213456", name: "Joe Smith"},
	{ number:"************453456", name: "Chris Smith"},
	{number:"************673456", name: "Kevin Mike"},
	{number:"************893456", name: "Chris Smith"},
	{number:"************563456", name: "Kevin Mike"},
	{number:"************343456", name: "Kevin Mike"},
	{number:"************673456", name: "Joe Smith"},
	{number:"************233456", name: "Shweta Sinha"},
	{number:"************093456", name: "Kevin Mike"},
	{number:"************643456", name: "Chris Smith"},
	{number:"************293456", name: "Joe Smith"},
	{number:"************193456", name: "Kevin Mike"},
	{number:"************393456", name: "Chris Smith"}
];
for (var j in cardno) {
	cardNumbers.push(cardno[j].number)
}

  //replace_card  356844
  
  function showAddCards(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a card number...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Card Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Cardholder Name</div>").appendTo($header);
	//$currencyHeadercurrencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number;
	$.each( cardno, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#CardNumberSelect").val($target.attr("data-number"));
			$("#cardNumber").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.name+"</div>").appendTo($row)
		//$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddCards",
		title: "Add Card Numbers",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}



var cardNumbers = [];
var cardno = [
	{ number:"************134456", name: "Joe Smith"},
	{ number:"************213456", name: "Joe Smith"},
	{ number:"************453456", name: "Chris Smith"},
	{number:"************673456", name: "Kevin Mike"},
	{number:"************893456", name: "Chris Smith"},
	{number:"************563456", name: "Kevin Mike"},
	{number:"************343456", name: "Kevin Mike"},
	{number:"************673456", name: "Joe Smith"},
	{number:"************233456", name: "Shweta Sinha"},
	{number:"************093456", name: "Kevin Mike"},
	{number:"************643456", name: "Chris Smith"},
	{number:"************293456", name: "Joe Smith"},
	{number:"************193456", name: "Kevin Mike"},
	{number:"************393456", name: "Chris Smith"}
];
for (var j in cardno) {
	cardNumbers.push(cardno[j].number)
}
/* Request Types */
var REQUEST_TYPES = 
	[
		{number:'New Cardholder Request'},
		{number:'Statement Preferences'},
		{number:'Card Limit Change'},
		{number:'Replace Card'},
		{number:'Cancel Card'}
	];

selectize_options.render.item = function(item, escape){
            return '<div>' +
                '<span style="font-weight:bold; margin-right:5px;">' + escape(item.number) + '</span>' +
            '</div>';
        }

selectize_options.options = REQUEST_TYPES;
$('.requesttype-search').selectize(selectize_options);

/* Request Statuses */

var REQUEST_STATUS = 
	[
		{number:'Pending Approval Request'},
		{number:'Pending Second Approval Request'},
		{number:'Pending Verification Request'},
		{number:'Cancelled Request'},
		{number:'Rejected Request'},
		{number:'Future Dated Request'},
		{number:'Pending Transmission Request'},
		{number:'Failed Validation Request'},
		{number:'Completed Request'},
		{number:'Deleted Request'},
		{number:'Failed Transmission Request'}
	];

selectize_options.render.item = function(item, escape){
            return '<div>' +
                '<span style="font-weight:bold; margin-right:5px;">' + escape(item.number) + '</span>' +
            '</div>';
        }

selectize_options.options = REQUEST_STATUS;
$('.requeststatus-search').selectize(selectize_options);

var REQUESTOR_NAMES = [
	{ number: "Arnie", name: "Pye", currency: "pyearni" },
	{ number: "roger", name: "Meyers", currency: "meyersr" },
	{ number: "Kent", name: "Brokman", currency: "brokman"},
	{ number: "Patty", name: "Bouvier", currency: "bouvier"},
	{ number: "Jasper", name: "Beardly", currency: "beardly"}
];
selectize_options.render.item = function(item, escape){
            return '<div>' +
                '<span style="font-weight:bold; margin-right:5px;">' + escape(item.currency) + '</span>' +
            '</div>';
        }

selectize_options.options = REQUESTOR_NAMES;
$('.requestor-search').selectize(selectize_options);

$("[data-action='refresh']").on("click",function(e){
	e.preventDefault();
	$('#requestDetail').addClass("loading");
	setTimeout(function(){
		$('#requestDetail').removeClass("loading");
	},600);
});


/**********************************************************************
APPROVE REQUEST
**********************************************************************/
function approveSuccessConfirmation1(e)
{
	$("body").addClass("loading");
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully approved the selected card requests.", 500, 3000);
	}, 1000);
}

function populateApproveContent1() {
	var $wrapper = $("<div class='form-section top-label' />");
	var $approveSec = $("<div id='appprove-section' class='confirmation-message'/>").appendTo($wrapper);
    var $ackmes = $("<p style='margin:15px 10px;text-align:justify;'>I declare that I am an Authorised Signatory for the above Billing Account, that the details contained in this completed form are true and correct and have been given to enable ANZ to issue an ANZ Commercial Card to the above individual as an agent of the Client. I hereby declare that I have read, understood and will comply with the obligations on me, which appear below.</p>").appendTo($approveSec);
	var $Check=$("<input type='checkbox' name='alternativeadress' id='acknMessage' style='margin:0px 10px 0px 0px;'>").prependTo($ackmes);
	var $row = $("<div class='row fluid' style='margin-top:10px' />").appendTo($approveSec);
	var $labelColumn = $("<div class='label-column' style='vertical-align:top;'/>").appendTo($row);
	var $label = $("<label>Comments</label>").appendTo($labelColumn);
	var $dataColumn = $("<div class='data-column' style='vertical-align:top;'/>").appendTo($row);
	var $textareacontainer = $("<span/>").appendTo($dataColumn);
	var $data = $("<textarea style='width: 95%; max-width: 95%; height: 200px;' id='_addComment'></textarea>").appendTo($textareacontainer);
	//$label.bind("click", showIcommentbox);
    $Check.bind("change", showChecked);
	return $wrapper;
}
function showChecked()
{
  if($(this).is(':checked'))
  {
    $(this).parents('.dialog-body').find('.dialog-buttons').children('a.submit').removeClass('disabled').addClass('primary');
  }
  else
  {
   $(this).parents('.dialog-body').find('.dialog-buttons').children('a.submit').removeClass('primary').addClass('disabled primary');
  }
}
function showIcommentbox(e)
{
 $(e.target).find('i').removeClass('fa-plus').addClass('fa-minus');
 $(e.target).parent('.label-column').closest('.data-column').children('span').find('textarea').removeClass('hidden');
}
function viewApproveDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager",
		title: "Approve",
		size: "small",
		icon: "",
		content: function(){return populateApproveContent1()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Submit", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){
				e.preventDefault();
				if(!$(this).hasClass("disabled")){
						dialogHider(_dialog);
						approveSuccessConfirmation1(e);
				}
			}}], cssClass: "disabled submit primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
$("[data-action='approve']").on("click",viewApproveDialog);

/**********************************************************************
REJECT REQUEST
**********************************************************************/

function rejectSuccessConfirmation1(e)
{
	$("body").addClass("loading");
	setTimeout( function() {
		$("body").removeClass("loading");
		buildNotification("You have successfully rejected the selected card requests.", 500, 3000);
	}, 1000);
}

function populateRejectComments() {
	var $wrapper = $("<div class='form-section top-label' />");
	var $approveSec = $("<div id='appprove-section' />").appendTo($wrapper);
	var $row = $("<div class='row fluid' style='margin-top:10px' />").appendTo($approveSec);
	var $labelColumn = $("<div class='label-column' style='vertical-align:top;'/>").appendTo($row);
	var $label = $("<label>Comments</label>").appendTo($labelColumn);
	var $dataColumn = $("<div class='data-column' style='vertical-align:top;'/>").appendTo($row);
	var $textareacontainer = $("<span/>").appendTo($dataColumn);
	var $data = $("<textarea style='width: 95%; max-width: 95%; height: 200px;' id='_addComment'></textarea>").appendTo($textareacontainer);
	return $wrapper;
}
function viewRejectCommentsDialog(e) {
	var _origin = $(e.target).closest(".dialog-parent").length > 0 ? $(e.target).closest(".dialog-parent") : $(e.target);
	var _dialog1 ={
		id:'folderManager2'
	}
	var _dialog = {
		id: "folderManager1",
		title: "Reject Comments",
		size: "small",
		icon: "",
		content: function(){return populateRejectComments()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Submit", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog);dialogHider(_dialog1);rejectSuccessConfirmation1(e)}}], cssClass: "primary" }
		]
	}
	
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}

function populateRejectContent1() {
	var $wrapper = $("<div class='confirmation-message' style='margin:25px;'><p>Are you sure you want to Reject Card Requests?</p></div>");	
	return $wrapper;
}
function viewRejectDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "folderManager2",
		title: "Reject",
		size: "xsmall",
		icon: "",
		content: function(){return populateRejectContent1()},
		buttons: [
			{ name: "Cancel", icon: "<i class='fa fa-times fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}] },
			{ name: "Reject", icon: "<i class='fa fa-thumbs-down fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();viewRejectCommentsDialog(e)}}], cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
}
$("[data-action='reject']").on("click",viewRejectDialog);

/**********************************************************************
MODIFY REQUEST
**********************************************************************/
function modifyRequest(){
		$("#requestDetailsHeader").removeClass('hidden');
		$("#viewDetailsHeader").addClass('hidden');
		var steps = $("#defaultSteps");
		steps.hide();
		stepsnew = $("#cancelCarddefaultSteps");
		stepsnew.show();
		stepsnew.children("[data-step='1']").removeClass("active").addClass('complete');
		stepsnew.children("[data-step='3']").addClass("active");
		$("[data-request-header]").html('Cardholder Online Application');
		$("#newRequest").removeClass('hidden').find("div.scroll-area[data-step='1']").addClass("hidden");
		$("#requestDetail").hide();			
        setTimeout(function() {
			$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='13']").removeClass("hidden").scrollTop(0);
			$("#newRequest").find("#bottomControlNotes").removeClass("hidden");
			$("#newRequest").removeClass("loading");
			$("#accountInput").focus();
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
		}, 10);
}

$("[data-action='modify']").on("click",modifyRequest);
/**********************************************************************
MODIFY REQUEST
**********************************************************************/
function viewRequest(){
    var b=document.location.href.split(".html")[1];
	if(b=="#modify")
	{
	$("#newRequest").addClass('hidden');
	$("#requestDetail").show();
	var $row = $(".slick-row");
	$row.attr({'data-panel': '#requestDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
	$("#requestDetailsHeader").addClass('hidden');
	$("#viewDetailsHeader").removeClass('hidden');
	}
	else
	{
	  $(this).attr('href',"commercial-card-service-requests.html");
	}
}
$("[data-action='redirectViewPage']").on("click",viewRequest);

$("[data-action='backTo']").on("click",function(){
	$("#requestDetailsHeader").removeClass('hidden');
	$("#viewDetailsHeader").addClass('hidden');
});

$("#alternateAdress").change(function()
   {
       if(this.checked)
      {
	  $("#alternateDeliveryInfo").show();
	  }
	  else
	  {
	   $("#alternateDeliveryInfo").hide();
	  }
	   
   });

   
 $('a.viewcardrequest').click(function(){
   var $row = $(".slick-row");
   $row.attr({'data-panel': '#requestDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels');
	$("#requestDetailsHeader").addClass('hidden');
	$("#viewDetailsHeader").removeClass('hidden');
	// below code is for demo purpose not actual data
	$(".slick-row .selected").trigger('click');
	console.log($(".slick-row .selected"));
	if( !$row.is(".slick-group, .slick-group-totals") ) {
		$row.attr({'data-panel': '#requestDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels').removeAttr("data-panel data-switch");
		setupViewEnquiry(dataView.getItem(2));
		grid.setSelectedRows(0);
		selectedRowIds = [];
	}
 });
$('.edit-request').click(function(e)
  {
   $('#requestDetail').find("[data-action='modify']").trigger('click');
  });
  
  $("[data-action='previous-request']").on("click", function(e) {
	var activeRow = 5 || grid.getActiveCell().row;
	activeRow = activeRow-1;
	if ( $("#servcieRequests").find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
		activeRow = activeRow-1;
	}
	grid.setActiveCell(activeRow,0)
	$("#servcieRequests").find("div[row='"+activeRow+"'] div.slick-cell").eq(2).trigger("click");
});

/* next request */
$("[data-action='next-request']").on("click", function(e) {
	var activeRow = 5 || grid.getActiveCell().row ;
	activeRow = activeRow+1;
	if ( $("#servcieRequests").find("div[row='"+activeRow+"']").is(".slick-group, .slick-group-totals") ) {
		activeRow = activeRow+1;
	}
	if(activeRow >= grid.getDataLength()) {
		return false;
	} else {
		grid.setActiveCell(activeRow,0)
		$("#servcieRequests").find("div[row='"+activeRow+"'] div.slick-cell").eq(2).trigger("click");
	}
});

/* Privacy statement*/
function populatePrivacyContent() {
	var $wrapper = $("<div class='form-section top-label' />");
	var $approveSec = $("<div id='verify-section' class='confirmation-message'/>").appendTo($wrapper);
	var $ackmes = $("<p style='margin:15px 10px;text-align:justify;'>Australia and New Zealand Banking group Limited ABN 11 005 357 522 (ANZ) is collecting the personal information of the individuals listed above in order to provide them with an ANZ Commercial Card under the Client's Billing Account. By clicking 'Next' I hereby declare, in respect of the personal information listed above, that the individual/s concerned is/are aware or I will immediately make them aware of the following:ANZ is collecting their information and about your business in order to issue an ANZ Commercial Card to them as an Agent of the Client holding the above Billing Account. Without this information ANZ may not be able to do this. ANZ may also use and disclose their information for ANZ's internal administration and operations (e.g. market or customer satisfaction research) ANZ may disclose their information to: any agent, contractor or service provider we engage to carry out or assist our functions and activities (including debt collection agencies); an organisation that assists ANZ to identify, prevent or investigate any fraud, unlawful activity or misconduct (or suspencted fraud, unlawful activity or misconduct); any third party providing me/us with a product or service in relation to the ANZ product; organisations that are in a product or marketing alliance with ANZ (alliance partners); participants in the payments system (including payment organisations and merchants); and any related entity of ANZANZ may disclose information to recipients (including service providers and related entities) which are (1) located outside Australia and/or (2) not established in or do not carry on business in Australia. Details about the location of these recipients are available in ANZ's Privacy Policy and at www.anz.com/privacy.Privacy PolicyANZ's Privacy Policy (www.anz.com/privacy) contains information about:- any laws that require or authorise ANZ to collect certain information;- the circumstances in which ANZ may collect information from other sources (including from a third party);- how to access personal information and seek correction of personal information; and- how a person can raise concerns that ANZ has breached the Privacy Act or an applicable Code and how ANZ deal with these matters.</p> ").appendTo($approveSec);
	return $wrapper;
}

$("#Privacy").on("click", showPrivacyDialog);
 function showPrivacyDialog(e)
 {
  e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "PrivacyNext",
		title: "ANZ Privacy Statement ",
		size: "large",
		icon: "",
		content: function(){return populatePrivacyContent()},
		buttons: [
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}],cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
 }
var b=document.location.href.split(".html")[1];
if (b == "#account") {
var $row = $(".slick-row");
$row.attr({'data-panel': '#requestDetail', 'data-switch': 'switch-panels'}).trigger('click.switch-panels');
$("#viewDetailsHeader").removeClass('hidden');
$("#requestDetailsHeader").addClass('hidden');
}
});