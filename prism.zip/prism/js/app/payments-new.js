/* PAYMENT CREATION VARIABLES */
var record = null;
var instruction = null;
var selectedDebitAccount = null;
var selectedCreditAccount = null;
var availableCreditAccounts;
var availableBeneficiaryAccounts;
var availableTraceAccounts;


/* PAGE ELEMENT VARIABLES */
var $shell = $(".shell");
var $applicationTitle = $(".application-title");
var $paymentScreen =  $("#paymentScreen");
var $paymentControlBarButtonGroup = $paymentScreen.children("div.top-controls").children("ul.control-list").children("div.btn-group");
var $paymentSelection = $("#paymentSelection");
var $paymentDataEntry = $("#paymentDataEntry");
var $paymentReviewScreen = $("#paymentDataReview");


/* BENEFICIARY GRID */
var grid = null;
var dataView;
var data;
var selectedRowIds;
var options;
var columns;
var columnFilters = {};

/* TIMER */
var loadTimer;
var attachTimer;

/* VALIDATION */
var validationFailed = true;






/* PAGE TITLE AND BUTTONS */

function updateApplicationTitle(type) {
    $applicationTitle.empty().html(type);
}

function updateCloseButton() {
    $("#cancelPaymentButton").children("a").prop("href", "payments-new.html");
}

function attachSaveButton() {
    var $saveButton = $("<span class='btn' id='savePaymentButton' />");
    var $saveButtonAnchor = $("<a href='#save' title='Save the record' />").appendTo($saveButton).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    }).on("click", savePaymentAsDraft);
    var $saveButtonIcon = $("<i class='fa fa-save fa-fw text-right'></i>").appendTo($saveButtonAnchor);
    var $saveButtonSpan = $("<span>Save</span>").appendTo($saveButtonAnchor);

    $saveButton.appendTo($paymentControlBarButtonGroup);
}

function attachReviewAndSubmitButton() {

    var $btnGridRow = $("<div class='grid-row' id='reviewButtonSection' />");
    var $btnGridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($btnGridRow);
    var $btnRow = $("<div class='row' style='padding: 15px 0;' />").appendTo($btnGridCell);
    var $btnDataCol = $("<div class='data-column' style='width: 100%; text-align: right; padding-right: 0;' />").appendTo($btnRow);
    var $reviewBtn = $("<span class='form-button primary' />").appendTo($btnDataCol);
    var $reviewBtnAnchor = $("<a href='javascript:void(0)' />").appendTo($reviewBtn).on("click", validatePayment);
    var $reviewIcon = $("<i class='fa fa-chevron-circle-right fa-fw'></i>").appendTo($reviewBtnAnchor);
    var $reviewText = $("<span>Review &amp; Submit</span>").appendTo($reviewBtnAnchor);

    return $btnGridRow;

    /*
    var $btnGroup = $("<div class='btn-group' id='submitGroup' />");
    var $reviewButton = $("<span class='btn primary' id='reviewPaymentButton' />").appendTo($btnGroup);
    var $reviewButtonAnchor = $("<a href='#review' title='Review and submit the record' />").appendTo($reviewButton).on("click", validatePayment).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });
    var $reviewButtonIcon = $("<i class='fa fa-chevron-circle-right fa-fw text-right'></i>").appendTo($reviewButtonAnchor);
    var $reviewButtonSpan = $("<span>Review &amp; Submit</span>").appendTo($reviewButtonAnchor);
    $btnGroup.insertAfter($paymentControlBarButtonGroup);
    */
}

function attachPreviousAndSubmitButtons() {

    var $btnGridRow = $("<div class='grid-row' id='submitButtonSection' />");
    var $btnGridCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($btnGridRow);
    var $btnRow = $("<div class='row' style='padding: 15px 0;' />").appendTo($btnGridCell);
    var $btnDataCol = $("<div class='data-column' style='width: 100%; text-align: right; padding-right: 0;' />").appendTo($btnRow);
    var $prevBtn = $("<span class='form-button' />").appendTo($btnDataCol);
    var $prevBtnAnchor = $("<a href='javascript:void(0)' />").appendTo($prevBtn).on("click", returnToPaymentEditing);
    var $prevIcon = $("<i class='fa fa-chevron-circle-left fa-fw'></i>").appendTo($prevBtnAnchor);
    var $prevText = $("<span>Previous</span>").appendTo($prevBtnAnchor);
    var $submitBtn = $("<span class='form-button action' />").appendTo($btnDataCol);
    var $submitBtnAnchor = $("<a href='javascript:void(0)' />").appendTo($submitBtn).on("click", submitPaymentForApproval);
    var $submitIcon = $("<i class='fa fa-share-square fa-fw'></i>").appendTo($submitBtnAnchor);
    var $submitText = $("<span>Submit</span>").appendTo($submitBtnAnchor);

    return $btnGridRow;

    /*

    $("#submitGroup").remove();

    var $btnGroup = $("<div class='btn-group' id='submitButtonGroup' />");
    var $submitButton = $("<span class='btn action' id='submitPaymentButton' />").appendTo($btnGroup);
    var $submitButtonAnchor = $("<a href='#submit' title='Submit this payment' />").appendTo($submitButton).on("click", submitPaymentForApproval).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });
    var $submitButtonIcon = $("<i class='fa fa-share-square fa-fw text-right'></i>").appendTo($submitButtonAnchor);
    var $submitButtonSpan = $("<span>Submit</span>").appendTo($submitButtonAnchor);
    $btnGroup.insertAfter($paymentControlBarButtonGroup);

    var $btnGroup = $("<div class='btn-group' id='previousButtonGroup' />");
    var $prevButton = $("<span class='btn' id='previousPaymentButton' />").appendTo($btnGroup);
    var $prevButtonAnchor = $("<a href='#previous' title='Return to editing this payment' />").appendTo($prevButton).on("click", returnToPaymentEditing).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });
    var $prevButtonIcon = $("<i class='fa fa-chevron-left fa-fw text-right'></i>").appendTo($prevButtonAnchor);
    var $prevButtonSpan = $("<span>Previous</span>").appendTo($prevButtonAnchor);
    $btnGroup.insertAfter($paymentControlBarButtonGroup);

    */
}

function updatePaymentCreationSteps(lvl) {
    var $steps = $(".py-initiation-steps ul");
    var stepCount = $steps.children("li").size();
    for ( var i = 0, l = stepCount; i < l; i++ ) {
        if ( i < lvl ) {
            $steps.children("li:eq("+i+")").removeClass("active").addClass("complete").children("i.fa").removeClass("fa-circle").addClass("fa-check-circle");
        } else if ( i == lvl ) {
            $steps.children("li:eq("+i+")").removeClass("complete").addClass("active").children("i.fa").removeClass("fa-check-circle").addClass("fa-circle");
        } else if ( i > lvl ) {
            $steps.children("li:eq("+i+")").removeClass("active complete").children("i.fa").removeClass("fa-check-circle").addClass("fa-circle");
        }
    }
}







/* FORM LOGIC */

function updateAvailableAccounts() {
    if (record.type == "Account Transfer") {
        availableCreditAccounts = [];
        var accid = selectedDebitAccount.id;
        _.each(customerAccounts, function(item){
            if ( item.id != accid) {
                availableCreditAccounts.push(item);
            }
        });
    } else if (record.type == "Domestic Payment") {
        availableBeneficiaryAccounts = [];
        var country = selectedDebitAccount.country;
        if ( country == "China" ) {
            _.each(beneficiaryAccounts, function(item){
                if ( item.bankcountry === country || item.bankcountry === "Hong Kong") {
                    availableBeneficiaryAccounts.push(item);
                }
            });  
        } else {
            _.each(beneficiaryAccounts, function(item){
                if ( item.bankcountry === country) {
                    availableBeneficiaryAccounts.push(item);
                }
            });            
        }
        if ( country == "Australia" ) {
            availableTraceAccounts = [];
            _.each(customerAccounts, function(item){
                if ( item.country === country ) {
                    availableTraceAccounts.push(item);
                }
            });
        }
    } else if (record.type == "International Payment") {
        availableBeneficiaryAccounts = [];
        var country = selectedDebitAccount.country;
        _.each(beneficiaryAccounts, function(item){
            if ( item.bankcountry != country) {
                availableBeneficiaryAccounts.push(item);
            }
        });
    }
}

function grabPaymentMethods(item) {
    if (record.type == "Domestic Payment") {
        var $options = $("<option value=''></option>");
        var debitAccountResidentStatus = selectedDebitAccount.residentstatus;
        var debitAccountCurrency = selectedDebitAccount.ccy;
        var beneficiaryAccount = null;
        if (item.beneficiaryaccountnumber) {
            var beneficiaryAccountNumber = item.beneficiaryaccountnumber;
            beneficiaryAccount = _.find(availableBeneficiaryAccounts, function(item) {
                if (item.accountnumber === beneficiaryAccountNumber) {
                    return item;
                }
            });
        } else if (item.accountnumber) {
            beneficiaryAccount = item;
        }
        if (beneficiaryAccount) {
            if ( beneficiaryAccount.bank === "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED" ) {
                if ( beneficiaryAccount.bankcountry == "China" ) {
                    $options = $("<option value='Book Transfer'>Book Transfer</option>");
                }
            } else {
                if (beneficiaryAccount.bankcountry == "Hong Kong" || beneficiaryAccount.bankcountry == "Macau") {
                    $options = $("<option value='HVPS(XB)'>HVPS(XB)</option>");
                } else if (beneficiaryAccount.bankcountry == "China") {
                    if (debitAccountResidentStatus == true) {
                        if (beneficiaryAccount.residentstatus == true) {
                            $options = $("<option value='BEPS'>BEPS</option><option value='HVPS'>HVPS</option>");
                        } else {
                            $options = $("<option value='HVPS(XB)'>HVPS(XB)</option>");
                        }
                    } else {
                        $options = $("<option value='HVPS(XB)'>HVPS(XB)</option>");
                    }
                }
            }
        }
        return $options;
    }
}

function runDebitAccountSelectionLogic() {

    if (record.type == "Account Transfer") {
        selectedCreditAccount = null;
        record.creditaccountnumber = "";
        record.creditaccountname = "";
        record.creditaccountcurrency = "";
        record.creditaccountcountry = "";
    } else {
        record.paymentmethod = "";
        record.debitcurrencyflag = false;
    }

    updateAvailableAccounts();
}

function showSelectedDebitAccount(account, dialog) {
    var updateDebitAccount = function() {
        selectedDebitAccount = account;
        record.debitaccountnumber = selectedDebitAccount.number;
        record.debitaccountname = selectedDebitAccount.name;
        record.debitaccountcurrency = selectedDebitAccount.ccy;
        record.debitaccountcountry = selectedDebitAccount.country;
        record.paymentcurrency = selectedDebitAccount.ccy;
        record.traceaccount = selectedDebitAccount.label;
        record.remitter = selectedDebitAccount.shortname;
        record.fxratetype = "Carded";
        record.instructions = [];
        runDebitAccountSelectionLogic();
        renderAdditionalPaymentSections();
        if ( dialog ) {
            dialogHider(dialog);
        }
    }
    if ( record.debitaccountnumber != "" && record.debitaccountnumber != account.number ) {
        var msg;
        if ( record.type == "Account Transfer" ) {
             msg = "Changing the debit account may impact entered payment details.";
        } else if (record.type == "Domestic Payment" || record.type == "International Payment") {
            if ( record.debitaccountcountry != account.country ) {
                msg = "Changing the debit account to an account based in a different country <strong>will remove</strong> any beneficiary payment instructions that have been added.";
            } else {
                msg = "Changing the debit account may impact some beneficiary payment instructions that have been added.";
            }
        }
        buildConfirmDialog(msg, "Do you want to proceed?", updateDebitAccount);
    } else {
        updateDebitAccount();
    }
}

function runCreditAccountSelectionLogic() {
    renderAccountTransferScreen();
}

function showSelectedCreditAccount(account, dialog) {
    var updateCreditAccount = function() {
        selectedCreditAccount = account;
        record.creditaccountnumber = selectedCreditAccount.number;
        record.creditaccountname = selectedCreditAccount.name;
        record.creditaccountcurrency = selectedCreditAccount.ccy;
        record.creditaccountcountry = selectedCreditAccount.country;
        record.paymentcurrency = selectedCreditAccount.ccy;
        runCreditAccountSelectionLogic();
        if ( dialog ) {
            dialogHider(dialog);
        }
    }
    if ( record.creditaccountnumber != "" && record.creditaccountnumber != account.number ) {
        var msg = "Changing the credit account may impact entered payment details.";
        buildConfirmDialog(msg, "Do you want to proceed?", updateCreditAccount);
    } else {
        updateCreditAccount();
    }
}

function renderSelectedAccountDetail(target, account) {

    var $target = $(target);
    var $row = $target.closest("div.row");

    var $currency = $target.find(".selected-account-currency");
    $currency.empty().html(account.ccy);

    var $name = $target.find(".selected-account-name");
    $name.empty().html(account.name);

    var $number = $target.find(".selected-account-number");
    $number.empty().html(account.number);

    var $branch = $("<span style='margin-left: 10px;'>" + account.branch + "</span>").appendTo($number);
   
    if ( record.type == "Account Transfer") {
        $("#debitAccountAmount1").empty().html("Available Balance");
        $("#debitAccountAmount2").empty().html("Current Balance");
    } else if (record.type == "Domestic Payment") {
        if (record.debitaccountcountry == "Australia") {
            $("#debitAccountAmount1").empty().html("Current Balance");
            $("#debitAccountAmount2").empty().html("Available Funds");
        } else {
            $("#debitAccountAmount1").empty().html("Available Balance");
            $("#debitAccountAmount2").empty().html("Available Funds");
        }
    } else if (record.type == "International Payment") {

    }

    var $balance = $target.find(".selected-account-balance").children("div").last();
    $balance.empty().html("$"+account.available);

    var $funds = $target.find(".selected-account-funds").children("div").last();
    $funds.empty().html("$"+account.availablefunds);

    $target.show();
    if ($row.hasClass("error")) {
        $row.removeClass("error");
        $row.find("div.data-error").remove();

    }
}

function returnBeneficiaryRecord(record) {
    var bene = _.find(availableBeneficiaryAccounts, function(item) {
        if (record.beneficiaryaccountnumber === item.accountnumber) {
            return item;
        }
    });
    return bene;
}

function getDealNumbers() {
    var fromCCY;
    var toCCY;
    if (record.debitcurrencyflag) {
        fromCCY = record.debitaccountcurrency;
        toCCY = record.paymentcurrency;
    } else {
        fromCCY = record.paymentcurrency;
        toCCY = record.debitaccountcurrency;
    }
    var rate = getCardedRate();
    var amount = Number(randNumber(3)).toFixed(2);
    var a = {};
    a["id"] = randString(10);
    a["fxid"] = "FXID-"+randString(5);
    a["number"] = randNumber(20);
    a["fromccy"] = fromCCY;
    a["toccy"] = toCCY;
    a["rate"] = rate;
    a["amount"] = amount;
    a["expiry"] = smartDates("randomfuture");
    return a;
}

function updateAccountTransferAmount() {
   try { var _payamount = ($("#paymentAmount").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#paymentAmount").val())).toFixed(2);
    var _debamount = ($("#debitAmount").val() == '') ? parseFloat(0).toFixed(2) : parseFloat(removeCommas($("#debitAmount").val())).toFixed(2);
    } catch(e) {}
    if (record.paymentcurrency != record.debitaccountcurrency) {
        if (record.debitcurrencyflag) {
            record.debitequivalentamount = _debamount;
            $("#debitAmount").val(addCommas(_debamount));
            if (record.fxratetype == "Carded") {
                record.paymentamount = parseFloat(record.fxrate * record.debitequivalentamount).toFixed(2);
                $("#paymentAmount").val(addCommas(record.paymentamount));
            } else {
                record.paymentamount = "--";
                $("#paymentAmount").val(record.paymentamount);
            }
        } else {
            record.paymentamount = _payamount;
            $("#paymentAmount").val(addCommas(_payamount));
            if (record.fxratetype == "Carded") {
                record.debitequivalentamount = parseFloat(record.fxrate * record.paymentamount).toFixed(2);
                $("#debitAmount").val(addCommas(record.debitequivalentamount));
            } else {
                record.debitequivalentamount = "--";
                $("#debitAmount").val(record.debitequivalentamount);
            }
        }
        if (record.fxratetype == "Contract") {
            renderContractAmountsUI();        
        }
    } else { 
        record.paymentamount = _payamount;
        record.debitequivalentamount = _payamount;
        $("#paymentAmount").val(addCommas(_payamount));
    }
}

function updateBatchTotals() {
    var totalPaymentAmount = 0;
    var totalDebitAmount = 0;
    if (record.paymentcurrency != record.debitaccountcurrency) {
        if ( record.individualdebitsflag ) {
            if (record.debitcurrencyflag) {
                for ( var i = 0, l = record.instructions.length; i < l; i++ ) {
                    if ( record.instructions[i].fxratetype == "Carded" ) {
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);
                        record.instructions[i].paymentamount = record.instructions[i].fxrate * record.instructions[i].debitequivalentamount;
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
                    } else {
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);
                        record.instructions[i].paymentamount = "--";
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);                    
                    }
                }
            } else {
                for ( var i = 0, l = record.instructions.length; i < l; i++ ) {
                    if ( record.instructions[i].fxratetype == "Carded" ) {
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
                        record.instructions[i].debitequivalentamount = record.instructions[i].fxrate * record.instructions[i].paymentamount;
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);
                    } else {
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
                        record.instructions[i].debitequivalentamount = "--";
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);                   
                    }
                }
            }
        } else {
            if (record.debitcurrencyflag) {
                if (record.fxratetype == "Carded") {
                    for (var i = 0, l = record.instructions.length; i < l; i++) {
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);
                        record.instructions[i].paymentamount = record.fxrate * record.instructions[i].debitequivalentamount;
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
                    }
                } else {
                    for (var i = 0, l = record.instructions.length; i < l; i++) {
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);
                        record.instructions[i].paymentamount = "--";
                    }
                    totalPaymentAmount = "--";
                }
            } else {
                if (record.fxratetype == "Carded") {
                    for (var i = 0, l = record.instructions.length; i < l; i++) {
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
                        record.instructions[i].debitequivalentamount = record.fxrate * record.instructions[i].paymentamount;
                        totalDebitAmount = parseFloat(totalDebitAmount) + parseFloat(record.instructions[i].debitequivalentamount);
                    }
                } else {
                    for (var i = 0, l = record.instructions.length; i < l; i++) {
                        totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
                        record.instructions[i].debitequivalentamount = "--";
                    }
                    totalDebitAmount = "--";
                }
            }
        }
        totalPaymentAmount = parseFloat(totalPaymentAmount).toFixed(2);
        totalDebitAmount =  parseFloat(totalDebitAmount).toFixed(2);
    } else {
        for (var i = 0, l = record.instructions.length; i < l; i++) {
            record.instructions[i].debitequivalentamount = record.instructions[i].paymentamount;
            totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(record.instructions[i].paymentamount);
        }
        totalPaymentAmount = parseFloat(totalPaymentAmount).toFixed(2);
        totalDebitAmount = totalPaymentAmount;
    }
    record.paymentamount = totalPaymentAmount;
    record.debitequivalentamount = totalDebitAmount;
    renderBatchTotalsUI();
    if ( record.fxratetype == "Contract" ) {
        renderContractAmountsUI();
    }
}

function calculateEquivalentWithContracts() {
    var clonedContracts = [];
    if (record.type == 'Account Transfer') {
        $.each(record.fxcontracts, function(i,obj) {
            clonedContracts.push($.extend(true, {}, obj)); 
        });
        var amount = (record.debitcurrencyflag) ? parseFloat(record.debitequivalentamount) : parseFloat(record.paymentamount);
        var equivalent = 0;
        var contractamount = 0;
        var paymentremaningamount = amount;
        var paymentdone = false;
        for ( var a = 0, b = clonedContracts.length; a < b; a++ ) {
            var contractamount = parseFloat(parseFloat(contractamount) + parseFloat(clonedContracts[a].used));
            if ( contractamount == amount ) {
                equivalent = parseFloat(parseFloat(equivalent) + parseFloat(clonedContracts[a].used * clonedContracts[a].rate)).toFixed(2);
                clonedContracts.splice(0, a+1);
                a = 0;
                paymentdone = true;
                break;
            } else if ( contractamount < amount ) {
                equivalent = parseFloat(parseFloat(equivalent) + parseFloat(clonedContracts[a].used * clonedContracts[a].rate)).toFixed(2);
                paymentremaningamount = parseFloat(amount) - parseFloat(contractamount);
            } else if ( contractamount > paymentremaningamount ) {
                var remaining;
                if ( paymentremaningamount < amount ) {
                    remaining = parseFloat(parseFloat(clonedContracts[a].used) - parseFloat(paymentremaningamount)).toFixed(2);
                    equivalent = parseFloat(parseFloat(equivalent) + parseFloat(paymentremaningamount * clonedContracts[a].rate)).toFixed(2);
                } else {
                    remaining = parseFloat(parseFloat(clonedContracts[a].used) - parseFloat(amount)).toFixed(2);
                    equivalent = parseFloat(parseFloat(equivalent) + parseFloat(amount * clonedContracts[a].rate)).toFixed(2);
                }
                clonedContracts[a].used = remaining;
                clonedContracts.splice(0, a);
                a = 0;
                paymentdone = true;
                break;
            }
        }
        if (paymentdone) {
            if (record.debitcurrencyflag) {
                record.paymentamount = parseFloat(equivalent).toFixed(2);
            } else {
                record.debitequivalentamount = parseFloat(equivalent).toFixed(2);
            }
        }
    } else {
        if (record.individualdebitsflag) {
            for ( var i = 0, l = record.instructions.length; i < l; i++ ) {
                var instruction = record.instructions[i];
                if (instruction.fxratetype == "Contract") {
                    var amount = (record.debitcurrencyflag) ? parseFloat(instruction.debitequivalentamount) : parseFloat(instruction.paymentamount);
                    var equivalent = 0;
                    var contractamount = 0;
                    var paymentremaningamount = amount;
                    var paymentdone = false;
                    $.each(instruction.fxcontracts, function(i,obj) {
                        clonedContracts.push($.extend(true, {}, obj)); 
                    });
                    for ( var a = 0, b = clonedContracts.length; a < b; a++ ) {
                        var contractamount = parseFloat(parseFloat(contractamount) + parseFloat(clonedContracts[a].used));
                        if ( contractamount == amount ) {
                            equivalent = parseFloat(parseFloat(equivalent) + parseFloat(clonedContracts[a].used * clonedContracts[a].rate)).toFixed(2);
                            clonedContracts.splice(0, a+1);
                            a = 0;
                            paymentdone = true;
                            break;
                        } else if ( contractamount < amount ) {
                            equivalent = parseFloat(parseFloat(equivalent) + parseFloat(clonedContracts[a].used * clonedContracts[a].rate)).toFixed(2);
                            paymentremaningamount = parseFloat(amount) - parseFloat(contractamount);
                        } else if ( contractamount > paymentremaningamount ) {
                            var remaining;
                            if ( paymentremaningamount < amount ) {
                                remaining = parseFloat(parseFloat(clonedContracts[a].used) - parseFloat(paymentremaningamount)).toFixed(2);
                                equivalent = parseFloat(parseFloat(equivalent) + parseFloat(paymentremaningamount * clonedContracts[a].rate)).toFixed(2);
                            } else {
                                remaining = parseFloat(parseFloat(clonedContracts[a].used) - parseFloat(amount)).toFixed(2);
                                equivalent = parseFloat(parseFloat(equivalent) + parseFloat(amount * clonedContracts[a].rate)).toFixed(2);
                            }
                            clonedContracts[a].used = remaining;
                            clonedContracts.splice(0, a);
                            a = 0;
                            paymentdone = true;
                            break;
                        }
                    }
                    if (paymentdone) {
                        if (record.debitcurrencyflag) {
                            instruction.paymentamount = parseFloat(equivalent).toFixed(2);
                        } else {
                            instruction.debitequivalentamount = parseFloat(equivalent).toFixed(2);
                        }
                    }
                }
            }
        } else {
            $.each(record.fxcontracts, function(i,obj) {
                clonedContracts.push($.extend(true, {}, obj)); 
            });
            for ( var i = 0, l = record.instructions.length; i < l; i++ ) {
                var instruction = record.instructions[i];
                var amount = (record.debitcurrencyflag) ? parseFloat(instruction.debitequivalentamount) : parseFloat(instruction.paymentamount);
                var equivalent = 0;
                var contractamount = 0;
                var paymentremaningamount = amount;
                var paymentdone = false;
                for ( var a = 0, b = clonedContracts.length; a < b; a++ ) {
                    var contractamount = parseFloat(parseFloat(contractamount) + parseFloat(clonedContracts[a].used));
                    if ( contractamount == amount ) {
                        equivalent = parseFloat(parseFloat(equivalent) + parseFloat(clonedContracts[a].used * clonedContracts[a].rate)).toFixed(2);
                        clonedContracts.splice(0, a+1);
                        a = 0;
                        paymentdone = true;
                        break;
                    } else if ( contractamount < amount ) {
                        equivalent = parseFloat(parseFloat(equivalent) + parseFloat(clonedContracts[a].used * clonedContracts[a].rate)).toFixed(2);
                        paymentremaningamount = parseFloat(amount) - parseFloat(contractamount);
                    } else if ( contractamount > paymentremaningamount ) {
                        var remaining;
                        if ( paymentremaningamount < amount ) {
                            remaining = parseFloat(parseFloat(clonedContracts[a].used) - parseFloat(paymentremaningamount)).toFixed(2);
                            equivalent = parseFloat(parseFloat(equivalent) + parseFloat(paymentremaningamount * clonedContracts[a].rate)).toFixed(2);
                        } else {
                            remaining = parseFloat(parseFloat(clonedContracts[a].used) - parseFloat(amount)).toFixed(2);
                            equivalent = parseFloat(parseFloat(equivalent) + parseFloat(amount * clonedContracts[a].rate)).toFixed(2);
                        }
                        clonedContracts[a].used = remaining;
                        clonedContracts.splice(0, a);
                        a = 0;
                        paymentdone = true;
                        break;
                    }
                }
                if (paymentdone) {
                    if (record.debitcurrencyflag) {
                        instruction.paymentamount = parseFloat(equivalent).toFixed(2);
                    } else {
                        instruction.debitequivalentamount = parseFloat(equivalent).toFixed(2);
                    }
                }
            }
        }
        var total = 0;
        if (record.debitcurrencyflag) {
            for (var i = 0, l = record.instructions.length; i < l; i++) {
                total += parseFloat(record.instructions[i].paymentamount);
            }
            record.paymentamount = parseFloat(total).toFixed(2);
        } else {
            for (var i = 0, l = record.instructions.length; i < l; i++) {
                total += parseFloat(record.instructions[i].debitequivalentamount);
            }
            record.debitequivalentamount = parseFloat(total).toFixed(2);        
        }
        renderBatchTotalsUI();
    }
}

function updateInstructionAmounts() {
    var $this = (record.debitcurrencyflag) ? $("#debitAmount") : $("#paymentAmount");
    var value = ($this.val() == '') ? "0.00" : parseFloat(removeCommas($this.val())).toFixed(2);
    $this.val(addCommas(value));
    if (record.individualdebitsflag) {
        if (record.debitaccountcurrency != record.paymentcurrency) {
            if (instruction.fxratetype == "Carded") {
                var fxrate = instruction.fxrate;
                var calculatedAmount = parseFloat(fxrate * value).toFixed(2);
                if (record.debitcurrencyflag) {
                    instruction.debitequivalentamount = value;               
                    $("#paymentAmount").val(addCommas(calculatedAmount));
                } else {
                    instruction.paymentamount = value;
                    $("#debitAmount").val(addCommas(calculatedAmount));
                }
            } else {
                if (record.debitcurrencyflag) {
                    instruction.debitequivalentamount = value;
                    $("#paymentAmount").val("--");
                } else {
                    instruction.paymentamount = value;
                    $("#debitAmount").val("--");
                }
                renderContractAmountsUI();
            }
        }
    } else {
        if (record.debitaccountcurrency != record.paymentcurrency) {
            if (record.fxratetype == "Carded") {
                var fxrate = record.fxrate;
                var calculatedAmount = parseFloat(fxrate * value).toFixed(2);
                if (record.debitcurrencyflag) {
                    $("#paymentAmount").val(addCommas(calculatedAmount));
                } else {
                    $("#debitAmount").val(addCommas(calculatedAmount));
                }
            } else {
                if (record.debitcurrencyflag) {
                    $("#paymentAmount").val("--");
                } else {
                    $("#debitAmount").val("--");
                }
                renderContractAmountsUI();
            }
        }
    }
}

function getCardedRate() {
    var cardedRate;
    var fetchedRateData;
    var fromCCY;
    var toCCY;

    if (record.debitcurrencyflag) {
        fromCCY = record.debitaccountcurrency;
        toCCY = record.paymentcurrency;
    } else {
        fromCCY = record.paymentcurrency;
        toCCY = record.debitaccountcurrency;
    }

    for (var i = 0, l = fxRates.length; i < l; i++) {
        var entry = fxRates[i];
        if (entry.from == fromCCY && entry.to == toCCY) {
            fetchedRateData = fxRates[i];
            cardedRate = parseFloat(fetchedRateData.rate).toFixed(4);
            break;
        }
    }

    return cardedRate;
}

function returnCardedRate() {
    var $rateText = $("#cardedRate");
    var $loader = $("<i class='data-loader' />");
    var fromCCY;
    var toCCY;
    if (record.debitcurrencyflag) {
        fromCCY = record.debitaccountcurrency;
        toCCY = record.paymentcurrency;
    } else {
        fromCCY = record.paymentcurrency;
        toCCY = record.debitaccountcurrency;
    }
    $rateText.empty();
    $loader.appendTo($rateText);
    clearTimeout(loadTimer);
    if (record.individualdebitsflag) {
        var rate = getCardedRate();
        for (var i = 0, l = record.instructions.length; i < l; i++) {
            record.instructions[i].fxrate = rate;
        }
    } else {
        record.fxrate = getCardedRate();
    }
    loadTimer = setTimeout(function() {
        $loader.remove();
        var singleEquivalent = 1 * record.fxrate;
        var $rate = $("<strong>" + record.fxrate + "</strong>").appendTo($rateText);
        var $info = $("<span style='margin-left: 10px;'> $1 " + fromCCY + " = $" + singleEquivalent + " " + toCCY + "</span>").appendTo($rateText);
    }, 300);
}

function renderBatchTotalsUI() {
    $("#batchTotal").empty();

    var _totalPaymentAmount;
    var _totalDebitAmount;

    if (record.paymentamount == "NaN")  {
        _totalPaymentAmount = " --";
    } else {
        _totalPaymentAmount = " $" + addCommas(parseFloat(record.paymentamount).toFixed(2));
    }
    if (record.debitequivalentamount == "NaN") {
        _totalDebitAmount = " --";
    } else {
        _totalDebitAmount = " $" + addCommas(parseFloat(record.debitequivalentamount).toFixed(2));
    }
    
    var $row= $("<div class='totals-row' />");
    var $totalItems = $("<div class='payment-amount-total' id='totalBatchItemsSection'>").appendTo($row);
    var $div = $("<div />").appendTo($totalItems);
    var $span = $("<span>Total Number of Items:</span>").appendTo($div);
    var $span = $("<span id='totalNumberOfPayments'>"+record.instructions.length+"</span>").appendTo($div);
    if ( record.debitaccountcurrency != record.paymentcurrency ) {
        if (record.debitcurrencyflag) {
            var $totalItems = $("<div class='payment-amount-total' id='totalPaymentAmountSection'>").appendTo($row);
            var $div = $("<div />").appendTo($totalItems);
            var $span = $("<span>Total Payment Amount:</span>").appendTo($div);
            var $span = $("<span id='totalPaymentAmount'>"+ record.paymentcurrency + _totalPaymentAmount +"</span>").appendTo($div);
            var $totalItems = $("<div class='payment-amount-total' id='totalDebitAmountSection'>").appendTo($row);
            var $div = $("<div />").appendTo($totalItems);
            var $span = $("<span>Total Debit Amount:</span>").appendTo($div);
            var $span = $("<span id='totalDebitAmount'>"+ record.debitaccountcurrency + _totalDebitAmount +"</span>").appendTo($div);
        } else {
            var $totalItems = $("<div class='payment-amount-total' id='totalDebitAmountSection'>").appendTo($row);
            var $div = $("<div />").appendTo($totalItems);
            var $span = $("<span>Total Debit Amount:</span>").appendTo($div);
            var $span = $("<span id='totalDebitAmount'>"+ record.debitaccountcurrency + _totalDebitAmount +"</span>").appendTo($div);
            var $totalItems = $("<div class='payment-amount-total' id='totalPaymentAmountSection'>").appendTo($row);
            var $div = $("<div />").appendTo($totalItems);
            var $span = $("<span>Total Payment Amount:</span>").appendTo($div);
            var $span = $("<span id='totalPaymentAmount'>"+ record.paymentcurrency + _totalPaymentAmount +"</span>").appendTo($div);
        }
    } else {
        var $totalItems = $("<div class='payment-amount-total' id='totalPaymentAmountSection'>").appendTo($row);
        var $div = $("<div />").appendTo($totalItems);
        var $span = $("<span>Total Payment Amount:</span>").appendTo($div);
        var $span = $("<span id='totalPaymentAmount'>"+ record.paymentcurrency + _totalPaymentAmount +"</span>").appendTo($div);
    }
    $row.appendTo($("#batchTotal"));
}

function handlePaymentNameChanges() {
    record.paymentname = $(this).val();
}

function handlePaymentReferenceChanges() {
    record.paymentreference = $(this).val();
}

function handleEndtoEndIDChanges() {
    record.endtoendid = $(this).val();
}

function handleDebitAdviceChanges() {
    if ( record.type == "Account Transfer" ) {
        record.debitadviceinformation = $(this).val();
    } else {
        if (record.individualdebitsflag) {
            instruction.debitadviceinformation = $(this).val();
        } else {
            record.debitadviceinformation = $(this).val();
        }
    }
}

function handleRemittanceInfoChanges() { 
    instruction.remittanceinformation = $(this).val();
}

function handleDebitInfoChanges() { 
    record.debitstatementnarrative = $(this).val();
}

function handleCreditInfoChanges() { 
    record.creditstatementnarrative = $(this).val();
}

function handlePaymentInfoChanges() { 
    record.paymentreference = $(this).val();
}

function handleDirectEntryIDChange() {
    record.directentryid = $(this).val();
}

function handleInstructionPaymentMethodChange() {
    var method = $("#paymentMethod").val();
    instruction.paymentmethod = method;
    handleInstructionMethodUpdates();
}

function handleInstructionMethodUpdates() {
    var method = instruction.paymentmethod;
    var codes;
    var $codeSelect = $("#purposeCode");
    $codeSelect.empty();
    if (method == "HVPS(XB)") {
        codes = _cbhvps_purspoe_codes;
        for (var i = 0, l = codes.length; i < l; i++) {
            var $purposeoptions = $("<option value='" + codes[i] + "'>" + codes[i] + "</option>").appendTo($codeSelect);
        }
        $("#chargesRow").show();
        $("#purposeCodeRow").show();
    } else {
        $("#chargesRow").hide();
        $("#purposeCodeRow").hide();
    }
    if (method == "Book Transfer") {
        $("#remittanceinformationRow").find("label").html("Remittance Information");
    } else {
        $("#remittanceinformationRow").find("label").html("Instruction Remarks");
    }
}

function handlePurposeCodeSelection() {
    var purposeCode = $("#purposeCode").val();
    instruction.purposecode = purposeCode;
}

function handleChargesSelection() {
    var chargeCode = $("#charges").val();
    instruction.charges = chargeCode;
}

function handlePurposeOfPaymentSelection() {
    var purposeOfPayment = $("#purposeOfPayment").val();
    instruction.purposeofpayment = purposeOfPayment;
}

function handleStatementNarrativeChange() {
    record.statementnarrative = $(this).val();
}

function handleInvoiceDetailChanges() {
   if (record.type == "Account Transfer") {
        record.invoiceinformation = $(this).val();
   } else {
        instruction.invoiceinformation = $(this).val();
   }
}

function handleDebitStatementReferenceChanges() {
    record.debitstatementreference = $(this).val();
    if ( $("#creditstatementref").val() == '' ) {
        $("#creditstatementref").val(record.debitstatementreference);
        record.creditstatementreference = record.debitstatementreference;
    }
}

function handleDebitStatementNarrativeChanges() {
    record.debitstatementnarrative = $(this).val();
    if ( $("#creditstatementnar").val() == '' ) {
        $("#creditstatementnar").val(record.debitstatementnarrative);
        record.creditstatementnarrative = record.debitstatementnarrative;
    }
}

function handleCreditStatementReferenceChanges() {
    record.creditstatementreference = $(this).val();
}

function handleCreditStatementNarrativeChanges() {
    record.creditstatementnarrative = $(this).val();
}

function returnRemainingAmount() {
    var item = (record.individualdebitsflag) ? instruction : record;
    var totalamount = (record.debitcurrencyflag) ? item.debitequivalentamount : item.paymentamount;
    var usedamount = 0;
    var remainingamount;
    if ($("input[data-contract-id]").size()) {
        $("input[data-contract-id]").each(function() {
            var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
            usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
        });
    }
    remainingamount = parseFloat(totalamount - usedamount).toFixed(2);
    if (item.cardedrateflag) {
        var cardedAmount = parseFloat($("#cardedRateEntry").val().replace(/[^0-9\.]+/g, ""));
        var updatedCardedAmount;
        if (remainingamount > 0) {
            updatedCardedAmount = (parseFloat(remainingamount) + parseFloat(cardedAmount)).toFixed(2);
            $("#cardedRateEntry").val(addCommas(updatedCardedAmount));
            for (var i = 0, l = item.fxcontracts.length; i < l; i++) {
                if (item.fxcontracts[i].id == "cardedRateEntry") {
                    item.fxcontracts[i].used = parseFloat(updatedCardedAmount).toFixed(2);
                    break;
                }
            }
            remainingamount = 0;
        } else if (remainingamount < 0) {
            updatedCardedAmount = (parseFloat(cardedAmount) + parseFloat(remainingamount)).toFixed(2);
            if (updatedCardedAmount >= 0) {
                $("#cardedRateEntry").val(addCommas(updatedCardedAmount));
                for (var i = 0, l = item.fxcontracts.length; i < l; i++) {
                    if (item.fxcontracts[i].id == "cardedRateEntry") {
                        item.fxcontracts[i].used = parseFloat(updatedCardedAmount).toFixed(2);
                        break;
                    }
                }               
                remainingamount = 0;
            } else if (updatedCardedAmount < 0) {
                $("#cardedRateEntry").val(parseFloat(0).toFixed(2));
                for (var i = 0, l = item.fxcontracts.length; i < l; i++) {
                    if (item.fxcontracts[i].id == "cardedRateEntry") {
                        item.fxcontracts[i].used = parseFloat(0).toFixed(2);
                        break;
                    }
                }
                remainingamount = updatedCardedAmount;
            }
        }
    }
    return remainingamount;
}

function renderContractAmountsUI() {
    var remainingamount = returnRemainingAmount();
    var $span = $("<span />");
    var $remainingDiv = $("#remainingPaymentAmount");
    $remainingDiv.empty();
    if (remainingamount < 0 || record.fxcontracts.length == 5) {
        $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
        $("#cardedRateFlagLabel").addClass("disabled");
    } else {
        if ($("#cardedRateFlag").attr("disabled")) {
            $("#cardedRateFlag").attr("disabled", false).removeClass("disabled");
            $("#cardedRateFlagLabel").removeClass("disabled");
        }
    }
    if (remainingamount < 0) {
        $span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(parseFloat(remainingamount * -1).toFixed(2)) + "</span>");
    } else if (remainingamount > 0) {
        $span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(parseFloat(remainingamount).toFixed(2)) + "</span>");
    } else if (remainingamount == 0) {
        $span = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i> Remaining Amount: " + addCommas(parseFloat(remainingamount).toFixed(2)) + "</span>");
    }
    $span.appendTo($remainingDiv);
}

function handleValueDateChanges() { 
    var value = $(this).attr("data-id");
    var $selection = $("#"+value);
    var $parent = $(this).closest("li");
    var $row = $parent.closest("div.row");
    $parent.addClass("selected").siblings("li.selected").removeClass("selected");
    $selection.show().siblings().hide();
    if ($row.hasClass("error")) {
        $row.removeClass("error").find("div.data-error").remove();
    } 
    if ( value == 'todayPayment' ) {
        $("#valueDate").val(smartDates("today"));
        $("#dailylimit").css("padding-top","5px");
        record.valuedate = smartDates("today");
    } else {
        $("#dailylimit").css("padding-top","10px");
        $("#valueDate").val('');
        record.valuedate = "";
    }
}

function handleCardedRateFlagChanges() {
    var item = (record.individualdebitsflag) ? instruction : record;
    item.cardedrateflag = $(this).prop("checked") ? true : false;
    if (item.cardedrateflag) {
        var fromCCY;
        var toCCY;
        if (record.debitcurrencyflag) {
            fromCCY = record.debitaccountcurrency;
            toCCY = record.paymentcurrency;
        } else {
            fromCCY = record.paymentcurrency;
            toCCY = record.debitaccountcurrency;
        }
        var rate = getCardedRate();
        var totalamount = (record.debitcurrencyflag) ? item.debitequivalentamount : item.paymentamount;
        var usedamount = 0;
        var remainingamount;

        if ($("input[data-contract-id]").size()) {
            $("input[data-contract-id]").each(function() {
                var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
                usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
            });
        }
        remainingamount = parseFloat(totalamount - usedamount).toFixed(2);

        var $row = $("<div class='data-table-row' data-contract-row='true' id='usedCardedRateInContractsRow' />"),
            $referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
            $removebutton = $("<a href='javascript:void(0)'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
                e.preventDefault();
                $(this).closest("div.data-table-row").remove();
                $("#cardedRateFlag").prop("checked", false);
                item.cardedrateflag = false;
                item.fxcontracts = _.without(item.fxcontracts, _.findWhere(item.fxcontracts, {
                    id: "cardedRateEntry"
                }));
                renderContractAmountsUI();
            }),
            $reference = $("<span>Carded Rate</span>").appendTo($referencecell),
            $amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
            $amountdata = $("<span>&nbsp;</span>").appendTo($amountcell),
            $cfidcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
            $cfiddata = $("<span>&nbsp;</span>").appendTo($cfidcell),            
            $ratecell = $("<div class='data-table-cell' style='width: 15%; text-align: right;' />").appendTo($row),
            $rate = $("<span>" + rate + "</span>").appendTo($ratecell),
            $usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
            $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0; border: 0;' disabled='disabled' data-contract-id='cardedRateEntry' id='cardedRateEntry' value='" + addCommas(remainingamount) + "' />").appendTo($usedamountcell);

        $row.appendTo($("#fxContractList"));
        var contract = {
            id: "cardedRateEntry",
            fxid: "",
            number: "Carded Rate",
            expiry: "",
            amount: "",
            fromccy: fromCCY,
            toccy: toCCY,
            rate: rate,
            used: remainingamount
        };
        item.fxcontracts.push(contract);
        renderContractAmountsUI();
    } else {
        $("#usedCardedRateInContractsRow").remove();
        item.fxcontracts = _.without(item.fxcontracts, _.findWhere(item.fxcontracts, {
            id: "cardedRateEntry"
        }));
        renderContractAmountsUI();
    }
}

function handlePaymentCurrencyChanges() {
    var revertPaymentCurrency = function() {
        $("#paymentCurrency").val(record.paymentcurrency);
    }
    var changePaymentCurrency = function() {
        record.paymentcurrency = $("#paymentCurrency").val();
        if ( record.type == "Domestic Payment" || record.type == "International Payment" ) {
            for (var i = 0, l = record.instructions.length; i < l; i++) {
                record.instructions[i].paymentcurrency = record.paymentcurrency;
            }
            if (record.debitaccountcurrency != record.paymentcurrency) {
                $("#useDebitCurrencyRow").show();
                $("#debitcurrencyflag").prop("checked", record.debitcurrencyflag);
                if (!record.individualdebitsflag) {
                    if (!$("#paymentFXSection").size()) {
                        renderFXSection().insertAfter($("#beneficiarySection"));
                    }
                    if (record.fxratetype == "Carded") {   
                        $("#fxContractButton, #fxContractSection").hide();
                        $("#cardedRateRow").show();               
                        returnCardedRate();
                    } else {
                        $("#cardedRateRow").hide();
                        $("#fxContractButton, #fxContractSection").show();
                        $("#fxContractList").find("div[data-contract-row='true']").remove();
                        record.fxcontracts = [];
                    }
                } else {
                    for (var i = 0, l = record.instructions.length; i < l; i++) {
                        if (record.instructions[i].fxratetype == "Carded") {
                            record.instructions[i].fxrate = getCardedRate();
                        } else {
                            record.instructions[i].fxcontracts = [];
                        }
                    }
                }
            } else {
                $("#paymentFXSection").remove();
                $("#useDebitCurrencyRow").hide();
                record.debitcurrencyflag = false;
            }
            dataView.refresh();
            grid.invalidate();
            grid.render();
            updateBatchTotals();
        }
        $("#paymentCurrency").focus();
    }
    buildConfirmDialog("Changing the payment currency may impact fx rates for this payment.", "Do you want to proceed?", changePaymentCurrency, revertPaymentCurrency);
}

function handleIndividualDebitsFlagChanges() {
    record.individualdebitsflag = $(this).prop("checked") ? true : false;
    if (record.debitaccountcurrency != record.paymentcurrency) {
        if (record.individualdebitsflag) {
             $("#paymentFXSection").remove();
        } else {
            renderFXSection().insertAfter($("#beneficiarySection"));
            returnCardedRate();
        }
        updateBatchTotals();
    }
    if (record.individualdebitsflag == true) {
        $("#paymentDebitAdviceRow").hide();
    } else {
        $("#paymentDebitAdviceRow").show();
    }
}

function handleUrgentFlagChanges() {
    record.urgentflag = $(this).prop("checked") ? true : false;
}

function handleDebitCurrencyFlagChanges() {
    record.debitcurrencyflag = $(this).prop("checked") ? true : false;
    returnCardedRate();
    if (record.fxratetype == "Contract") {
        /*
        $("#fxContractList").find("div[data-contract-row='true']").remove();
        record.fxcontracts = [];
        if (record.cardedrateflag) {
            record.cardedrateflag = false;
            $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
            $("#cardedRateFlagLabel").addClass("disabled");
        }
        renderContractAmountsUI();
        */
    }
    if ( record.type == "Domestic Payment" || record.type == "International Payment" ) {
        if (record.debitcurrencyflag) {
            for (var i = 0, l = record.instructions.length; i < l; i++) {
                record.instructions[i].debitequivalentamount = record.instructions[i].paymentamount;
            } 
        } else {
            for (var i = 0, l = record.instructions.length; i < l; i++) {
                record.instructions[i].paymentamount = record.instructions[i].debitequivalentamount;
            } 
        }
        dataView.refresh();
        grid.invalidate();
        grid.render();
        updateBatchTotals();
    } else {
        if (record.debitcurrencyflag) {
            $("#debitAmount").val($("#paymentAmount").val());
            $("#debitAmountRow").addClass("mandatory");
            $("#paymentAmountRow").removeClass("mandatory");
            $("#paymentAmount").attr("readonly", true).off().parent("div.ccy-amount-input").addClass("readonly");
            $("#debitAmount").attr("readonly", false).on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAccountTransferAmount).on("focus", function(){
                if ( $(this).val() == "0.00" ) {
                    $(this).val('');
                }
            }).parent("div.ccy-amount-input").removeClass("readonly");
        } else {
            $("#paymentAmount").val($("#debitAmount").val());
            $("#paymentAmountRow").addClass("mandatory");
            $("#debitAmountRow").removeClass("mandatory");
            $("#debitAmount").attr("readonly", true).off().parent("div.ccy-amount-input").addClass("readonly");
            $("#paymentAmount").attr("readonly", false).on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAccountTransferAmount).on("focus", function(){
                if ( $(this).val() == "0.00" ) {
                    $(this).val('');
                }
            }).parent("div.ccy-amount-input").removeClass("readonly");
        }
        updateAccountTransferAmount();
    }
}

function handleFXTypeChange() {
    if (record.individualdebitsflag) {
        instruction.fxratetype = $('#fxratetype').val();
        if (instruction.fxratetype == "Carded" || instruction.fxratetype == "Dynamic") {
            $("#fxContractButton, #fxContractSection").hide();
            $("#cardedRateRow").show();
            returnCardedRate();
        } else {
            $("#cardedRateRow").hide();
            $("#fxContractButton, #fxContractSection").show();           
        }
        updateInstructionAmounts();
    } else {
        record.fxratetype = $('#fxratetype').val();
        if (record.fxratetype == "Carded" || record.fxratetype == "Dynamic") {
            $("#fxContractButton, #fxContractSection").hide();
            $("#cardedRateRow").show();
            returnCardedRate();
        } else {
            $("#cardedRateRow").hide();
            $("#fxContractButton, #fxContractSection").show();
        }
        if ( record.type == "Account Transfer" ) {
            updateAccountTransferAmount();
        } else {
            updateBatchTotals();
        }
    }
}

function setSelectedBeneficiaryFromDialog(item, dialog) {
    if ( $("#editInstructionDialog").size() ) {
        var $select = $("#paymentMethod");
        $select.empty();
        var $options = grabPaymentMethods(item).appendTo($select);
        $("#beneName").val(item.name);
        $("#batchBeneAccountNumber").html(item.accountnumber);
        $("#batchBeneLocalLanguageNameField").html(item.localname);
        $("#batchBeneBankName").html(item.bank);
        $("#batchBeneBankBranch").html(item.branch);
        $("#batchBeneBankCountry").html(item.bankcountry);
        $("#batchBeneClearing").html(item.clearing[0].type + " " + item.clearing[0].code);
        $("#beneficiaryDetails").show();
    } else {
        var r = grid.getActiveCell();
        grid.gotoCell(r.row, r.cell, true);
        $("#beneName").val(item.name);
        $("#beneNumber").val(item.accountnumber);
        grid.getEditController().commitCurrentEdit();
        grid.gotoCell(r.row, 5, true);       
    }
    dialogHider(dialog);
}

function attachSupportingDocument() {
    $("#paymentProgressBar").show();
    $("#paymentProgressBar .progress-meter").animate({
        width: "100%"
    }, 1500, function() {
        $("#paymentProgressBar").hide();
        $("#paymentProgressBar .progress-meter").css("width", 0);

        var str = $("#paymentSupportingDoc").val();
        var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);

        if (window.ActiveXObject) {
            var myFSO = new ActiveXObject("Scripting.FileSystemObject");
            var filepath = document.getElementById('paymentSupportingDoc').value;
            var thefile = myFSO.getFile(filepath);
            var size = thefile.size;
        } else {
            var size = document.getElementById('paymentSupportingDoc').files[0].size;
        }

        var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
        fSize = size;
        i = 0;
        while (fSize > 900) {
            fSize /= 1024;
            i++;
        }

        var filesize = (Math.round(fSize * 100) / 100) + ' ' + fSExt[i];

        var _doc = {
            id: randString(20),
            filename: filename,
            filesize: filesize,
            status: "Performing Virus Scan"
        }
        var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />"),
            $fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
            $removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell).on("click", function(e) {
                e.preventDefault();
                $(this).closest("div.data-table-row").remove();
                if ( record.type == "Account Transfer" ) {
                   for (var i = 0, l = record.docs.length; i < l; i++) {
                        if (record.docs[i].id == _doc.id) {
                            record.docs.splice(i, 1);
                        }
                    }
                } else {
                    for (var i = 0, l = instruction.docs.length; i < l; i++) {
                        if (instruction.docs[i].id == _doc.id) {
                            instruction.docs.splice(i, 1);
                        }
                    }
                }
                clearTimeout(attachTimer);
                if (!$("div[data-doc-row]='true'").size()) {
                    $("#attachedDocuments").hide();
                }
            }),
            $documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell),
            $statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "<i class='ellipsis-loader' /></div>").appendTo($dataTableRow);
        $dataTableRow.appendTo($("div[data-supporting-docs='newInstruction']"));
        $("#attachedDocuments").show();
        attachTimer = setTimeout(function() {
            $documentLink.remove();
            $documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($fileInfoCell);
            $statusTableCell.empty().html("Attached");
            _doc.status = "Attached";
            if ( record.type == "Account Transfer" ) {
                record.docs.push(_doc);
            } else {
                instruction.docs.push(_doc);            
            }
        }, 500);
    });
}

function toggleGridFilterRow(e) {
    e.preventDefault();
    $('.slick-headerrow-column').children().val('').next("i").hide();
    for (var columnId in columnFilters) {
        columnFilters[columnId] = "";
    }
    if ($(this).hasClass("btn-on")) {
        grid.setHeaderRowVisibility(false);
        $(this).removeClass("btn-on");
    } else {
        grid.setHeaderRowVisibility(true);
        $(this).addClass("btn-on");
    }
    dataView.refresh();
}    


/* FORM VALIDATION */

function validateValueDate() {
    var $el = $("#valueDate");
    var $row = $el.closest("div.row");
    var $col = $el.closest("div.data-column");
    if ($row.hasClass('error')) {
        $row.removeClass("error").find("div.data-error").remove();
    }
    if ($el.val()) {
        var stringval = $el.val(),
            testdate;
        try {
            testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
        } catch (e) {
            validationFailed = true;
            $row.addClass("error");
            $("<div class='data-error' />").appendTo($col).html("Value Date is not valid");
        } finally {
            if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
                validationFailed = true;
                $row.addClass("error");
                $("<div class='data-error' />").appendTo($col).html("Value Date cannot be in the past");
            } else {
                record.valuedate = $el.val();
            }
        }
    } else {
        validationFailed = true;
        $row.addClass("error");
        $("<div class='data-error' />").appendTo($col).html("Value Date is a required field");
    }
}

function validateMandatoryPaymentFields(field, message) {
    var $el = $("#"+field);
    var $row = $el.closest("div.row");
    var $col = $el.closest("div.data-column");
    if ($col.children("div.data-error").size()) {
        $col.children("div.data-error").remove();
    }    
    if ($el.val() == '') {
        validationFailed = true;
        $row.addClass("error");     
        $("<div class='data-error' />").appendTo($col).html(message);
    } else {
         $row.removeClass("error");
    }
}

function validatePaymentData(value) {
    if (record.value == "") {
        validationFailed = true;
    }
}

function validatePaymentInstruction() {
    var instructionValidationFailed = false;
    if ( instruction.beneficiaryaccountnumber == '' ) {
        instructionValidationFailed = true;
    }
    if (record.debitaccountcountry == "China" && record.type == "Domestic Payment") {
        if ( instruction.paymentmethod == '' ) {
            instructionValidationFailed = true;
        }
    }
    if (record.paymentmethod == "Osko") {
        if ( instruction.endtoendid == '' ) {
            instructionValidationFailed = true;
        }
    } else {
        if ( instruction.paymentreference == '' ) {
            instructionValidationFailed = true;
        }
    }
 
    if ( instruction.valuedate == '' ) {
        instructionValidationFailed = true;
    }
    if (record.paymentcurrency != record.debitaccountcurrency) {
        if (record.debitcurrencyflag) {
            if ( instruction.debitequivalentamount == '' ) {
                instructionValidationFailed = true;
            }
        } else {
            if ( instruction.paymentamount == '' ) {
                instructionValidationFailed = true;
            }
        }
        if (record.individualdebitsflag && instruction.fxratetype == "Contract") {
            if (instruction.fxcontracts.length) {
                var totalamount = (record.debitcurrencyflag) ? instruction.debitequivalentamount : instruction.paymentamount;
                var fxcurrency = (record.debitcurrencyflag) ? record.debitaccountcurrency : record.paymentcurrency;
                var usedamount = 0;
                for (var i = 0, l = instruction.fxcontracts.length; i < l; i++) {
                    var contract = instruction.fxcontracts[i];
                    var thisamount = contract.used;
                    usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
                    if (contract.id != "cardedRateEntry") {
                        if ((parseFloat(contract.used)) > (parseFloat(contract.amount))) {
                            instructionValidationFailed = true;
                        }
                        if (contract.fromccy != fxcurrency) {
                            instructionValidationFailed = true;
                        }
                    }
                }
                var remainingamount = parseFloat(totalamount - usedamount).toFixed(2);
                if (remainingamount != 0) {
                    instructionValidationFailed = true;
                }
            }
        }

    } else {
        if ( instruction.paymentamount == '' ) {
            instructionValidationFailed = true;
        }
    }
    if (record.debitaccountcountry == "Australia" && (record.paymentmethod == "Direct Entry" || record.paymentmethod == "OKSO")) {
        if ( instruction.remitter == '' ) {
            instructionValidationFailed = true;
        }
        if (record.paymentmethod == "Direct Entry") {
            if ( instruction.traceaccount == '' ) {
                instructionValidationFailed = true;
            }
            if ( instruction.transactioncode == '' ) {
                instructionValidationFailed = true;
            }
        }
    }
    if ( instructionValidationFailed ) {
        validationFailed = true;
        instruction.validated = false;
    } else {
        instruction.validated = true;
    }  
}

function validatePaymentInstructions() {
    var instructionsAdded = (record.instructions.length) ? true : false;
    if (instructionsAdded) {
        for ( var i = 0, l = record.instructions.length; i < l; i++ ) {
            instruction = record.instructions[i];
            validatePaymentInstruction();
        }
    } else {
        validationFailed = true;
        $("#noInstructionsMessage").remove();
        var $noInstructionsMessageRow = $("<div class='row' id='noInstructionsMessage' style='margin: -10px 0 15px 0;' />");
        var $noInstructionMessageColumn = $("<div class='data-column' />").appendTo($noInstructionsMessageRow);
        var $noInstructionMessage = $("<div class='data-error'>At least one beneficiary payment must be added</div>").appendTo($noInstructionMessageColumn);
        var $insertPoint = $("#beneficiarySection").find("div.box-content div.row:first-child");
        $noInstructionsMessageRow.insertBefore($insertPoint);
    }
}

function validatePayment() {
    validationFailed = false;
    $shell.addClass("loading");
    if ($("div.error-notification").size()) {
        $("div.error-notification").remove();
    } 
    setTimeout(function() {
        $shell.removeClass("loading");
        if ( record.type == "Account Transfer" ) {
            validateMandatoryPaymentFields('debitAccountSelectionInput', 'Debit Account selection is required');
            validateMandatoryPaymentFields('creditAccountSelectionInput', 'Credit Account selection is required');
            validateMandatoryPaymentFields('paymentReference', 'Debit Reference is a required field');
            validateValueDate();
            if ((record.paymentcurrency != record.debitaccountcurrency) && record.fxratetype == "Contract") {
                var remainingamount = returnRemainingAmount();
                if ( remainingamount != 0 ) {
                    validationFailed = true;
                }
                if (record.fxcontracts.length) {
                    var fxcurrency = (record.debitcurrencyflag) ? record.debitaccountcurrency : record.paymentcurrency;
                    for (var i = 0, l = record.fxcontracts.length; i < l; i++) {
                        var contract = record.fxcontracts[i];
                        var $row = $("#"+contract.id);
                        if (contract.id != "cardedRateEntry") {
                            if ((parseFloat(contract.used)) > (parseFloat(contract.amount))) {
                                var $col = $row.find("div[data-type='used']");
                                var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-right: 5px; vertical-align: middle;' title='The utlized amount is greater than the available amount'></i>");
                                $col.addClass("error").children("i").remove();
                                $icon.prependTo($col);
                                validationFailed = true;
                            }
                        }
                        if (contract.fromccy != fxcurrency) {
                            var $col = $row.find("div[data-type='reference']");
                            var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-left: 5px; vertical-align: middle;' title='There is a currency pair mismatch with this contract'></i>");
                            $col.addClass("error").children("i").remove();
                            $icon.appendTo($col);
                            validationFailed = true;
                        }
                    }
                }
            }
        } else if ( record.type == "Domestic Payment" || record.type == "International Payment" ) {
            validateMandatoryPaymentFields('debitAccountSelectionInput', 'Debit Account selection is required');
            validateMandatoryPaymentFields('paymentName', 'Payment Name is a required field');
            validateMandatoryPaymentFields('endtoendid', 'End-to-End ID is a required field');
            validateMandatoryPaymentFields('statementNarrative', 'Statement Narrative is a required field');
            validateMandatoryPaymentFields('paymentReference', 'Payment Reference is a required field');
            if (record.debitaccountcountry == "Australia") {
                validateMandatoryPaymentFields('directEntryID', 'Direct Entry ID is a required field');
                validatePaymentData("traceaccount");
                validatePaymentData("transactioncode");
                validatePaymentData("remitter");
            }
            validateValueDate();
            validatePaymentInstructions();
            if((record.paymentcurrency != record.debitaccountcurrency) && record.fxratetype == "Contract") {
                var remainingamount = returnRemainingAmount();
                if ( remainingamount != 0 ) {
                    validationFailed = true;
                }
                if (record.fxcontracts.length) {
                    var fxcurrency = (record.debitcurrencyflag) ? record.debitaccountcurrency : record.paymentcurrency;
                    for (var i = 0, l = record.fxcontracts.length; i < l; i++) {
                        var contract = record.fxcontracts[i];
                        var $row = $("#"+contract.id);
                        if (contract.id != "cardedRateEntry") {
                            if ((parseFloat(contract.used)) > (parseFloat(contract.amount))) {
                                var $col = $row.find("div[data-type='used']");
                                var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-right: 5px; vertical-align: middle;' title='The utlized amount is greater than the available amount'></i>");
                                $col.addClass("error").children("i").remove();
                                $icon.prependTo($col);
                                validationFailed = true;
                            }
                        }
                        if (contract.fromccy != fxcurrency) {
                            var $col = $row.find("div[data-type='reference']");
                            var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-left: 5px; vertical-align: middle;' title='There is a currency pair mismatch with this contract'></i>");
                            $col.addClass("error").children("i").remove();
                            $icon.appendTo($col);
                            validationFailed = true;
                        }
                    }
                }
            }
        }
        if (validationFailed) {
            $("#paymentEntryForm").animate({
                scrollTop: 0
            }, 300).promise().done(function() {
                buildErrorNotification("Errors Were Detected", "Some errors were detected. Please review the form below and correct any items with error messages.", 100);
                if (record.instructions.length) {
                    dataView.refresh();
                    grid.invalidate();
                    grid.render();
                }
            });
        } else {
            if (record.fxratetype == "Contract" || record.individualdebitsflag) {
                calculateEquivalentWithContracts();
            }
            renderReviewPaymentScreen();
        }
    }, 500);
}





/* SAVE AS DRAFT */

function savePaymentAsDraft(e) {
    e.preventDefault();
    $("body").addClass("loading");
    $(".header, .shell").find(":focusable").attr("tabindex", -1);
    setTimeout(function() {
        $("body").removeClass("loading");
        $(".header, .shell").find(":focusable").removeAttr("tabindex");
        buildNotification("This payment has been saved in <strong>draft</strong> status with the following Payment ID: <strong>" + record.id + "</strong>", 300, 8000);
    }, 1000);
}





/* SUBMIT PAYMENT */

function submitPaymentForApproval(e) {
    e.preventDefault();
    $("body").addClass("loading");
    $(".header, .shell").find(":focusable").attr("tabindex", -1);
    var returnToCreatePage = function() {
        $("body").addClass("loading");
        $(".header, .shell").find(":focusable").attr("tabindex", -1);
        setTimeout(function() {
            document.location.href='payments-new.html';
        }, 1000);
    }
    setTimeout(function() {
        $("body").removeClass("loading");
        $(".header, .shell").find(":focusable").removeAttr("tabindex");
        buildConfirmOkDialog("<span class='pos' style='display: block; font-size: 24px; margin: 0 150px 20px 150px;'><i class='fa fa-check-circle fa-fw'></i> Success!</span>", "<span style='display: block;'><span style='display: block; font-weight: bold; margin-bottom: 5px;'>Payment ID: " + record.id + "</span><span style='display: block; margin-bottom: 20px;'>This payment has been submitted for approval.</span><span style='display: block; text-align: center;'><a href='javascript:void(0)' style='color: #007dba; text-decoration: none; display: inline-block; margin-bottom: 5px;'>View Payment Detail Report</a><br /><a href='javascript:void(0)'style='color: #007dba; text-decoration: none; display: inline-block;'>Save as Template</a></div>", returnToCreatePage);
    }, 1000);
}






/* CREATE PAYMENT */

function createNewPayment(type, salary) {

    /* CREATE THE RECORD */
    record = {
        id: randString(10) + smartDates("today"),
        type: type,
        salary: salary,
        division: "Customer Division 1",
        debitaccountnumber: "",
        debitaccountname: "",
        debitaccountcurrency: "",
        debitaccountcountry: "",
        debitstatementreference: "",
        debitstatementnarrative: "",
        creditaccountnumber: "",
        creditaccountname: "",
        creditaccountcurrency: "",
        creditaccountcountry: "",
        creditstatementreference: "",
        creditstatementnarrative: "",
        traceaccount: "",
        transactioncode: "50",
        remitter: "",
        paymentname: "",
        paymentreference: "",
        endtoendid: "",
        paymentmethod: "",
        valuedate: smartDates("today"),
        paymentcurrency: "",
        paymentamount: 0,
        debitequivalentamount: 0,
        debitreference: "",
        debitadviceinformation: "",
        remittanceinformation: "",
        statementnarrative: "",
        directentryid: "",
        individualdebitsflag: false,
        urgentflag: false,
        debitcurrencyflag: false,
        fxratetype: "Carded",
        fxrate: 0,
        fxcontracts: [],
        cardedrateflag: false,
        invoiceinformation: "",
        docs: [],
        instructions: [],
        errors: [],
        audit: []
    }

    /* RENDER THE INITIAL SCREEN */
    renderInitialPaymentScreen(type);
}



/* GRID FILTER */
function gridFilter(item, args) {
    for (var columnId in columnFilters) {
        if (columnId !== undefined && columnFilters[columnId] !== "") {
            var c = grid.getColumns()[grid.getColumnIndex(columnId)],
                _sorter = c.sorter;
            if (_sorter == "sorterNumeric") {
                var _filter = columnFilters[columnId];
                var _field;
                if ( c.id == "amount" ) {
                    if (record.debitcurrencyflag) {
                        _field = item.debitequivalentamount;
                    } else {
                        _field = item.paymentamount;
                    }
                } else {
                    _field = "" + item[c.field];
                }
                _field = _field.replace(/[^\d\.\-\ ]/g, '');
                var _greaterThen, _lessThen, _comparer, _between = false;
                if (_filter.charAt(0) === ">") {
                    _greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
                    if (_filter.indexOf("<") != -1) {
                        _between = true
                    }
                    if (_between) {
                        _lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
                        if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
                            return false;
                        }
                    } else {
                        if (parseFloat(_field) < parseFloat(_greaterThen)) {
                            return false;
                        }
                    }
                } else if (_filter.charAt(0) === "<") {
                    _lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
                    if (_filter.indexOf(">") != -1) {
                        _between = true
                    }
                    if (_between) {
                        _greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
                        if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
                            return false;
                        }
                    } else {
                        if (parseFloat(_field) > parseFloat(_lessThen)) {
                            return false;
                        }
                    }
                } else {
                    if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
                        return false;
                    }
                }
            } else {
                if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
                    return false;
                }
            }
        }
    }
    return true;
}


/* RENDER PAYMENT ENTRY SECTIONS */

function clearPaymentSections(sections) {
    if (sections !== undefined) {
        for (var i = 0, l = sections.length; i < l; i++) {
            var $section = $("#"+sections[i]);
            if ( $section.size() > 0 ) {
               $section.remove();
               if (sections[i] == "beneficiarySection") {
                    if (typeof(grid) != 'undefined' && grid != null) {
                        grid.destroy();
                        grid = null;
                        dataView = null;
                        data = [];
                        columns = [];
                        options = {};
                    }
               }
            }
        }
    } else {

        if ( $("#creditAccountSection").size() > 0 ) {
            $("#creditAccountSection").remove();
            selectedCreditAccount = null;
        }
        if ( $("#paymentMethodSection").size() > 0 ) {
            $("#paymentMethodSection").remove();
        }
        if ( $("#paymentDetailsSection").size() > 0 ) {
            $("#paymentDetailsSection").remove();
        }
        if ( $("#beneficiarySection").size() > 0 ) {
            $("#beneficiarySection").remove();
            if (typeof(grid) != 'undefined' && grid != null) {
                grid.destroy();
                grid = null;
                dataView = null;
                data = [];
                columns = [];
                options = {};
            }
        }
        if ( $("#paymentFXSection").size() > 0 ) {
            $("#paymentFXSection").remove();
        }
        if ( $("#paymentFXSection").size() > 0 ) {
            $("#paymentFXSection").remove();
        }
        if ( $("#supportingDocumentSection").size() > 0 ) {
            $("#supportingDocumentSection").remove();
        }
        if ( $("#remitSection").size() > 0 ) {
            $("#remitSection").remove();
        }
        if ( $("#instDialogBOPSection").size() > 0 ) {
            $("#instDialogBOPSection").remove();
        }
        if ( $("#reviewButtonSection").size() > 0 ) {
            $("#reviewButtonSection").remove();
        }
    }
}

function renderInitialPaymentScreen(type) {

    /* LOADING OVERLAY */
    $shell.addClass("loading");

    /* TIMEOUT TO HIDE THE PAYMENT SELECTION UI AND RENDER THE INITIAL STATE OF THE PAYMENT FORM */
    setTimeout(function(){
        updateApplicationTitle(type);
        updateCloseButton();
        attachSaveButton();
        updatePaymentCreationSteps(1);
        renderDebitAccountSection();
        $paymentSelection.hide();
        $paymentDataEntry.show();
        $shell.removeClass("loading");
        $("#debitAccountSelectionInput").focus();
    }, 500);
}

function renderAdditionalPaymentSections() {

    var type = record.type;
    var renderAdditionalFields;

    clearPaymentSections();

    if ( type == "Account Transfer" ) {
        renderAdditionalFields = function() {
            renderCreditAccountSection();
        }
    } else if ( type == "Domestic Payment" ) {
        renderAdditionalFields = function() {
            renderPaymentMethodSection();
            if ( selectedDebitAccount.country == "China" ) {
                renderPaymentDetailsSection();
                renderBeneficiarySection();
                attachReviewAndSubmitButton().appendTo($paymentDataEntry);

            }
        }
    } else if ( type == "International Payment" ) {
        renderAdditionalFields = function() {
            renderPaymentDetailsSection();
            renderBeneficiarySection();
            attachReviewAndSubmitButton().appendTo($paymentDataEntry);
        }
    }

    /* LOADING OVERLAY */
    $(".shell").addClass("loading");

    setTimeout(function(){
        renderSelectedAccountDetail('#debitAccountDetails', selectedDebitAccount);
        renderAdditionalFields();
        $(".shell").removeClass("loading");
    }, 500);
}

function renderAccountTransferScreen() {

    var type = record.type;
    var renderAdditionalFields;
    clearPaymentSections(["paymentDetailsSection", "paymentFXSection", "remitSection", "supportingDocumentSection", "reviewButtonSection"]);

    renderAdditionalFields = function() {
        renderAccountTransferDetailSection();
        renderRemitDetailSection(true).appendTo($paymentDataEntry);
        renderSupportingDocumentSection(true).appendTo($paymentDataEntry);
        if (record.debitaccountcurrency != record.creditaccountcurrency) {
            if (!$("#paymentFXSection").size()) {
                renderFXSection().insertAfter($("#paymentDetailsSection"));
            }
            if (record.fxratetype == "Carded") {   
                $("#fxContractButton, #fxContractSection").hide();
                $("#cardedRateRow").show();               
                returnCardedRate();
            } else {
                $("#cardedRateRow").hide();
                $("#fxContractButton, #fxContractSection").show();
                $("#fxContractList").find("div[data-contract-row='true']").remove();
                record.fxcontracts = [];
            }
        }
        if (record.debitaccountcountry == "China") {
            renderAdditionalInformationSection().appendTo($paymentDataEntry);          
        }
        attachReviewAndSubmitButton().appendTo($paymentDataEntry);
    }

    /* LOADING OVERLAY */
    $(".shell").addClass("loading");

    setTimeout(function(){
        renderSelectedAccountDetail('#creditAccountDetails', selectedCreditAccount);
        renderAdditionalFields();
        $(".shell").removeClass("loading");
    }, 500);
}

function renderDebitAccountSection() {
    var $sectionRow = $("<div class='grid-row' id='debitAccountSection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>From</div>").appendTo($box);
    var $boxContent = $("<div class='box-content' />").appendTo($box);
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Division</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $customSelect = $("<div class='custom-select' style='max-width: 100%;' />").appendTo($dataCol);
    var $divisionSelectionElement = $("<select id='divisionSelection' style='min-width: 250px;'></select>").appendTo($customSelect).on("change", function(){
        record.division = $(this).val();
    });
    for ( var i = 0, l = divisions.length; i < l; i++ ) {
        var $option = $("<option value='"+divisions[i]+"'>"+divisions[i]+"</option>").appendTo($divisionSelectionElement);
    }
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($dataRow);

    var $selectionComponentDiv = $("<div class='selection-component' id='debitAccountSelectionComponent' style='width: 95%; margin-right: 10px;' />").appendTo($dataCol);
    var $selectionComponentInput = $("<input type='text' readonly='readonly' class='selection-placeholder-input' id='debitAccountSelectionInput' placeholder='Select Debit Account' style='color: transparent;' />").appendTo($selectionComponentDiv);
    var $selectedDetailDiv = $("<div class='selection-detail' id='debitAccountDetails' />").appendTo($selectionComponentDiv);
    var $selectedContentDiv = $("<div class='selection-content' />").appendTo($selectedDetailDiv);
    var $selectedContentLeft = $("<div class='selection-content-left' />").appendTo($selectedContentDiv);
    var $selectedAccountCurrency = $("<div class='selected-account-currency' />").appendTo($selectedContentLeft);
    var $selectedAccountName = $("<div class='selected-account-name' />").appendTo($selectedContentLeft);
    var $selectedAccountNumber = $("<div class='selected-account-number' />").appendTo($selectedContentLeft);
    var $selectedContentRight = $("<div class='selection-content-right' />").appendTo($selectedContentDiv);
    var $selectedAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectedContentRight);
    var $accountBalanceLabel = $("<div id='debitAccountAmount1'>Available Balance</div>").appendTo($selectedAccountBalance);
    var $accountBalanceAmount = $("<div />").appendTo($selectedAccountBalance);
    var $selectedAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectedContentRight);
    var $accountFundsLabel = $("<div id='debitAccountAmount2'>Available Funds</div>").appendTo($selectedAccountFunds);
    var $accountFundsAmount = $("<div />").appendTo($selectedAccountFunds);
    var $selectedAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectedContentRight);
    var $selectedAccountDetailLink = $("<a href='#accountdetail' id='viewDebitAccountDetails' title='View Account Details'><i class='fa fa-file-text fa-fw'></a>").appendTo($selectedAccountDetail);
    var $suggestions = $("<div class='selection-suggestions' style='display: none;' id='debitAccountSuggestions' />").appendTo($selectionComponentDiv);
    var $suggestionsInput = $("<input type='text' value='' class='selection-suggestion-input' id='debitAccountSuggestionsInput' placeholder='Find an account...' />").appendTo($suggestions);
    var $suggestionsResults = $("<div class='selection-suggestion-list' id='debitAccountSuggestionResults' />").appendTo($suggestions);
    var $searchIcon = $("<a href='javascript:void(0)' title='Search Accounts' style='color: #007dba;' data-search='debit'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol).on("click", renderSearchAccountsDialog);


    /* ATTACH SECTION */
    $sectionRow.appendTo($paymentDataEntry);

    /* ATTACH EVENTS AND INTERACTIONS */
    $("#debitAccountSuggestionsInput").autocomplete({
        autoFocus: false,
        delay: 10,
        minLength: 0,
        appendTo: "#debitAccountSuggestionResults",
        position: {
            my: "left top",
            at: "left bottom"
        },
        source: function(request, response) {
            var results = $.ui.autocomplete.filter(customerAccounts, extractLast(request.term).trim());
            if (!results.length) {
                results = [{
                    value: 'No Matches Found'
                }];
            }
            response(results);
        },
        focus: function() {
            return false;
        },
        select: function(event, ui) {
            if (ui.item.value == "No Matches Found") {
                this.value = "";
                return false;
            } else {
                if ( $(this).value == "" ) {
                    return false;
                } else {
                    $("#debitAccountSuggestions").hide();
                    $("#debitAccountSelectionComponent").removeClass("open");
                    $("#debitAccountSelectionInput").val(ui.item.number).focus();
                    showSelectedDebitAccount(ui.item);
                    return false;                       
                }
            }
        },
        close: function(event, ui) {
            var matcher = $(this).val().trim();
            var matchie = "";
            var valid = false;
            $.each(customerAccounts, function() {
                if (this.label.toLowerCase() == matcher.toLowerCase()) {
                    valid = true;
                    matchie = this.label;
                    return false;
                }
            });
            if (valid) {
                $(this).val(matchie);
            }
            if (!valid) {
                $(this).val("");
                hideAccountSuggestions();
            }
            $(this).data().autocomplete.term = null;
        }
    }).focus(function(e) {
        $(this).autocomplete('search', '');
    }).on("click", function(e){
        e.stopImmediatePropagation();
    }).data("autocomplete")._renderItem = function(ul, item) {
        if (item.value == "No Matches Found") {
            return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
        } else {
            return $("<li></li>").data("item.autocomplete", item).append("<a><span style='display: inline-block; padding: 10px; border-radius: 2px; background: #0093d8; color: #fff; font-weight: bold; vertical-align: middle; margin-right: 10px;'>" + item.ccy + "</span><span style='display: inline-block; width: 92%; vertical-align: middle; white-space: normal; word-break: break-all;'><b>" + item.name + "</b><br />" + item.number + " <span style='margin-left: 10px;'>" + item.branch + "</span></span></a>").appendTo(ul);
        }
    };

    var hideAccountSuggestions = function() {
        $("#debitAccountSelectionComponent").removeClass("open");
        $("#debitAccountSuggestions").hide();
        $("#debitAccountSuggestionsInput").autocomplete("close");
        $(document).off("hideDebitSuggestions");
        $(document).off("keydown.hideDebitSuggestions");
        $(window).off("hideDebitSuggestions");
    }

    var showAccountSuggestions = function() {
        $("#debitAccountSelectionComponent").addClass("open");
        $("#debitAccountSuggestions").show();
        $("#debitAccountSuggestionsInput").val('').focus();
        $(document).one("click.hideDebitSuggestions contextmenu.hideDebitSuggestions", hideAccountSuggestions).on("keydown.hideDebitSuggestions", function(e){
            if(e.keyCode == 27) {
                hideAccountSuggestions();
                $("#debitAccountSelectionInput").focus();
            }
        });
        $(window).on("resize.hideDebitSuggestions", hideAccountSuggestions);
        var scrollToPoint = Math.abs($(".py-initiation-steps").position().top - $("#debitAccountSection").position().top);
        $("#paymentEntryForm").animate({
            scrollTop: scrollToPoint
        }, 300);
    }

    $("#viewDebitAccountDetails").on("click", renderAccountDetailDialog)

    $("#debitAccountSelectionInput, #debitAccountDetails").on("click", function(e) {
        e.stopPropagation();
        var isOpen = $("#debitAccountSuggestions").is(":visible");
        if (isOpen) {
            hideAccountSuggestions();
        } else {
            showAccountSuggestions();
        }
    }).on("keyup.show-debit-suggestions", function(e){
        if (e.keyCode == 38 || e.keyCode == 40) {
            showAccountSuggestions();
        }
    });

    if (record.debitaccountnumber) {
        renderSelectedAccountDetail('#debitAccountDetails', selectedDebitAccount);
        $("#debitAccountSelectionInput").val(selectedDebitAccount.number);
    }
}

function renderCreditAccountSection() {

    if ( $("#creditAccountSection").size() > 0 ) {
        $("#creditAccountSection").remove();
        selectedCreditAccount = null;
    }

    var $sectionRow = $("<div class='grid-row' id='creditAccountSection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>To</div>").appendTo($box);
    var $boxContent = $("<div class='box-content' />").appendTo($box);
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' style='width: 100%;' />").appendTo($dataRow);

    var $selectionComponentDiv = $("<div class='selection-component' id='creditAccountSelectionComponent' style='width: 95%; margin-right: 10px;' />").appendTo($dataCol);
    var $selectionComponentInput = $("<input type='text' readonly='readonly' class='selection-placeholder-input' id='creditAccountSelectionInput' placeholder='Select Credit Account' style='color: transparent;' />").appendTo($selectionComponentDiv);
    var $selectedDetailDiv = $("<div class='selection-detail' id='creditAccountDetails' />").appendTo($selectionComponentDiv);
    var $selectedContentDiv = $("<div class='selection-content' />").appendTo($selectedDetailDiv);
    var $selectedContentLeft = $("<div class='selection-content-left' />").appendTo($selectedContentDiv);
    var $selectedAccountCurrency = $("<div class='selected-account-currency' />").appendTo($selectedContentLeft);
    var $selectedAccountName = $("<div class='selected-account-name' />").appendTo($selectedContentLeft);
    var $selectedAccountNumber = $("<div class='selected-account-number' />").appendTo($selectedContentLeft);
    var $selectedContentRight = $("<div class='selection-content-right' />").appendTo($selectedContentDiv);
    var $selectedAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectedContentRight);
    var $accountBalanceLabel = $("<div>Available Balance</div>").appendTo($selectedAccountBalance);
    var $accountBalanceAmount = $("<div />").appendTo($selectedAccountBalance);
    var $selectedAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectedContentRight);
    var _amountFieldLabel = (record.type == "Account Transfer") ? "Current Balance" : "Available Funds";
    var $accountFundsLabel = $("<div>"+_amountFieldLabel+"</div>").appendTo($selectedAccountFunds);
    var $accountFundsAmount = $("<div />").appendTo($selectedAccountFunds);
    var $selectedAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectedContentRight);
    var $selectedAccountDetailLink = $("<a href='#accountdetail' id='viewCreditAccountDetails' title='View Account Details'><i class='fa fa-file-text fa-fw'></a>").appendTo($selectedAccountDetail);
    var $suggestions = $("<div class='selection-suggestions' style='display: none;' id='creditAccountSuggestions' />").appendTo($selectionComponentDiv);
    var $suggestionsInput = $("<input type='text' value='' class='selection-suggestion-input' id='creditAccountSuggestionsInput' placeholder='Find an account...' />").appendTo($suggestions);
    var $suggestionsResults = $("<div class='selection-suggestion-list' id='creditAccountSuggestionResults' />").appendTo($suggestions);
    var $searchIcon = $("<a href='javascript:void(0)' title='Search Accounts' style='color: #007dba;' data-search='credit'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol).on("click", renderSearchAccountsDialog);


    /* ATTACH SECTION */
    $sectionRow.appendTo($paymentDataEntry);


    /* ATTACH EVENTS AND INTERACTIONS */
    $("#creditAccountSuggestionsInput").autocomplete({
        autoFocus: false,
        delay: 10,
        minLength: 0,
        appendTo: "#creditAccountSuggestionResults",
        position: {
            my: "left top",
            at: "left bottom"
        },
        source: function(request, response) {
            var results = $.ui.autocomplete.filter(availableCreditAccounts, extractLast(request.term).trim());
            if (!results.length) {
                results = [{
                    value: 'No Matches Found'
                }];
            }
            response(results);
        },
        focus: function() {
            return false;
        },
        select: function(event, ui) {
            if (ui.item.value == "No Matches Found") {
                this.value = "";
                return false;
            } else {
                if ( $(this).value == "" ) {
                    return false;
                } else {
                    $("#creditAccountSuggestions").hide();
                    $("#creditAccountSelectionComponent").removeClass("open");
                    $("#creditAccountSelectionInput").val(ui.item.number).focus();
                    showSelectedCreditAccount(ui.item);
                    return false;                       
                }
            }
        },
        close: function(event, ui) {
            var matcher = $(this).val().trim();
            var matchie = "";
            var valid = false;
            $.each(availableCreditAccounts, function() {
                if (this.label.toLowerCase() == matcher.toLowerCase()) {
                    valid = true;
                    matchie = this.label;
                    return false;
                }
            });
            if (valid) {
                $(this).val(matchie);
            }
            if (!valid) {
                $(this).val("");
                hideCreditSuggestions();
            }
            $(this).data().autocomplete.term = null;
        }
    }).focus(function() {
        $(this).autocomplete('search', '');
    }).on("click", function(e){
        e.stopImmediatePropagation();
    }).data("autocomplete")._renderItem = function(ul, item) {
        if (item.value == "No Matches Found") {
            return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
        } else {
            return $("<li></li>").data("item.autocomplete", item).append("<a><span style='display: inline-block; padding: 10px; border-radius: 2px; background: #0093d8; color: #fff; font-weight: bold; vertical-align: middle; margin-right: 10px;'>" + item.ccy + "</span><span style='display: inline-block; width: 92%; vertical-align: middle; white-space: normal; word-break: break-all;'><b>" + item.name + "</b><br />" + item.number + " <span style='margin-left: 10px;'>" + item.branch + "</span></span></a>").appendTo(ul);
        }
    };

    var hideCreditSuggestions = function() {
        $("#creditAccountSelectionComponent").removeClass("open");
        $("#creditAccountSuggestions").hide();
        $("#creditAccountSuggestionsInput").autocomplete("close");
        $(document).off("hideCreditSuggestions");
        $(document).off("keydown.hideCreditSuggestions");
        $(window).off("hideCreditSuggestions");
    }

    var showCreditSuggestions = function() {
        $("#creditAccountSelectionComponent").addClass("open");
        $("#creditAccountSuggestions").show();
        $("#creditAccountSuggestionsInput").val('').focus();
        $(document).one("click.hideCreditSuggestions contextmenu.hideCreditSuggestions", hideCreditSuggestions).on("keydown.hideCreditSuggestions", function(e){
            if(e.keyCode == 27) {
                hideCreditSuggestions();
                $("#creditAccountSelectionInput").focus();
            }
        });
        $(window).on("resize.hideCreditSuggestions", hideCreditSuggestions);

        var scrollToPoint = Math.abs($(".py-initiation-steps").position().top - $("#creditAccountSection").position().top);

        $("#paymentEntryForm").animate({
            scrollTop: scrollToPoint
        }, 300);
    }

    $("#viewCreditAccountDetails").on("click", renderAccountDetailDialog)

    $("#creditAccountSelectionInput, #creditAccountDetails").on("click", function(e) {
        e.stopPropagation();
        var isOpen = $("#creditAccountSuggestions").is(":visible");
        if (isOpen) {
            hideCreditSuggestions();
        } else {
            showCreditSuggestions();
        }
    }).on("keyup.show-credit-suggestions", function(e){
        if (e.keyCode == 38 || e.keyCode == 40) {
            showCreditSuggestions();
        }
    });

    if (record.creditaccountnumber) {
        renderSelectedAccountDetail('#creditAccountDetails', selectedCreditAccount);
        $("#creditAccountSelectionInput").val(selectedCreditAccount.number);
    } else {
        $("#creditAccountSelectionInput").focus();
    }
}

function renderPaymentMethodSection() {
    var $sectionRow = $("<div class='grid-row' id='paymentMethodSection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Payment Method</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);

    if (selectedDebitAccount.country == "China") {
        var $data = $("<div class='data-text'>For domestic payments in China the payment method is selected along with the beneficiary account.</div>").appendTo($dataCol);
        $sectionRow.appendTo($paymentDataEntry);
    } else if ( selectedDebitAccount.country == "Australia") {
        var $data = $("<input type='radio' name='paymentMethodRadio' id='DirectEntry' value='Direct Entry' /><label class='desc' for='DirectEntry' title='A payment from a single funding account to one or more beneficiary domestic accounts.'>Direct Entry</label>").appendTo($dataCol);
        var $data = $("<input type='radio' name='paymentMethodRadio' id='RTGS' value='RTGS' /><label class='desc' for='RTGS' title='A high value domestic funds payment that will be settled the same day. Note that fees apply.'>RTGS</label>").appendTo($dataCol);
        var $data = $("<input type='radio' name='paymentMethodRadio' id='NPP' value='Osko' /><label class='desc' for='NPP' title='A real time payment that will be in the beneficiary&lsquo;s account alomst immediately providing the beneficiary&lsquo;s bank account supports Osko. Note that fees may apply.'>Osko</label>").appendTo($dataCol);
        $sectionRow.appendTo($paymentDataEntry);
        $('input[type=radio][name=paymentMethodRadio]').change(function() {
            $(".shell").addClass("loading");
            setTimeout(function(){
                if ( $("#paymentDetailsSection").size() > 0 ) {
                    $("#paymentDetailsSection").remove();
                }
                if ( $("#beneficiarySection").size() > 0 ) {
                    $("#beneficiarySection").remove();
                    if (typeof(grid) != 'undefined' && grid != null) {
                        grid.destroy();
                        grid = null;
                        dataView = null;
                        data = [];
                        columns = [];
                        options = {};
                    }
                }
                record.paymentmethod = $('input[name=paymentMethodRadio]').filter(':checked').val();
                clearPaymentSections(["paymentDetailsSection", "beneficiarySection", "paymentFXSection", "reviewButtonSection"]);
                renderPaymentDetailsSection();
                renderBeneficiarySection();
                attachReviewAndSubmitButton().appendTo($paymentDataEntry);
                $(".shell").removeClass("loading");
            }, 500);
        });
        if (record.paymentmethod) {
            $.each($('input[name=paymentMethodRadio]'), function(){
                if ( $(this).val() == record.paymentmethod ) {
                    $(this).prop("checked", true);
                }
            });
        } else {
            var scrollToPoint = Math.abs( $(".py-initiation-steps").position().top - $("#paymentMethodSection").position().top)
            setTimeout(function(){
                $("#paymentEntryForm").animate({
                    scrollTop: scrollToPoint
                }, 300);
            },1);
        }
    }
}

function renderPaymentDetailsSection(values) { 
    var $sectionRow = $("<div class='grid-row' id='paymentDetailsSection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);

    /* ROW */
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);

    /* LEFT CELL */
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);

    /* VALUE DATE */
    var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Value Date</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $valueDateDiv = $("<div style='display: inline-block; vertical-align: top;' />").appendTo($dataCol);
    var $valueDateList = $("<ul class='value-date-selection' />").appendTo($valueDateDiv);
    var $valueDateItem = $("<li class='selected highlighted' />").appendTo($valueDateList);
    var $valueDateAnchor = $("<a href='javascript:void(0)' id='highlighttoday' data-id='todayPayment'>Today</a>").appendTo($valueDateItem).on("click", handleValueDateChanges);
    var $valueDateItem = $("<li />").appendTo($valueDateList);
    var $valueDateAnchor = $("<a href='javascript:void(0)' data-id='laterPayment'>Later</a>").appendTo($valueDateItem).on("click", handleValueDateChanges);   
    var $valueDateContainer = $("<div class='value-date-container' />").appendTo($valueDateDiv);
    var $valueDateOptions = $("<div />").appendTo($valueDateContainer);
    var $today = $("<div id='todayPayment' />").appendTo($valueDateOptions);
    var $cutOffTime = $("<div class='data-text'>" + smartDates('today') + "</div>").appendTo($today);
    var $later = $("<div id='laterPayment' style='display: none;' />").appendTo($valueDateOptions);
    var $dateInputDiv = $("<div class='date-input-div' style='width: 178px;' />").appendTo($later);
    var $input = $("<input type='text' id='valueDate' placeholder='dd/mm/yyyy' value='"+smartDates('today')+"' />").appendTo($dateInputDiv).datepicker({
        dateFormat: 'dd/mm/yy',
        constrainInput: true,
        changeMonth: true,
        changeYear: true,
        duration: 0,
        minDate: "+1",
        beforeShow: function() {
            var widget = $("#valueDate").datepicker("widget");
            widget.appendTo($("#valueDateCalendar"));
            $("#valueDateCalendar").show();
        },
        onClose: function() {
            var widget = $("#valueDate").datepicker("widget");
            widget.appendTo($("body"));
        }
    }).mask("99/99/9999", {
        placeholder: "dd/mm/yyyy"
    }).on("change", function(){
        record.valuedate = $(this).val();
    });
    var $calendarDiv = $("<div id='valueDateCalendar' class='date-picker-div' />").appendTo($dateInputDiv);
    var $cutOffTime = $("<div class='data-text' style='margin: 10px; vertical-align: top;'>Cut-off Time: 16:00 AEST</div>").appendTo($dataCol);


    /* ROW */
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);

    /* LEFT CELL */
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);

    /* Payment Name */
    var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Payment Name</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<input type='text' id='paymentName' value='' style='width: 80%;' />").appendTo($dataCol).on('change', handlePaymentNameChanges);

    /* Payment Reference */
    if (record.debitaccountcountry == "China" || record.paymentmethod == "RTGS" || record.paymentmethod == "Direct Entry" || record.type == "International Payment") {
        var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' id='paymentReference' value='' style='width: 80%;' />").appendTo($dataCol).on('change', handlePaymentReferenceChanges);        
    }

    /* End to End ID */
    if (record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>End-to-End ID</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' id='endtoendid' value='' style='width: 80%;' />").appendTo($dataCol).on("change", handleEndtoEndIDChanges);
    }

    /* Payment Currency */
    if (record.debitaccountcountry == "China" || record.type == "International Payment") {
        var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Currency</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
        var $data = $("<select id='paymentCurrency'><option value='AUD'>AUD</option><option value='CNY'>CNY</option><option value='NZD'>NZD</option></select>").appendTo($customSelect).val(selectedDebitAccount.ccy).on("change", handlePaymentCurrencyChanges);        
    }

    /* Debit Currency Flag */
    if (record.debitaccountcountry == "China" || record.type == "International Payment") {
        var $dataRow = $("<div class='row' id='useDebitCurrencyRow' style='display: none;' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='checkbox' id='debitcurrencyflag' />").appendTo($dataCol).prop("checked", record.debitcurrencyflag).on('change', handleDebitCurrencyFlagChanges);
        var $labelDesc = $("<label class='desc' for='debitcurrencyflag'>Enter Amounts in Debit Currency</label>").appendTo($dataCol);
    }

    /* Individual Debits & Urgent Flags */
    if (record.debitaccountcountry == "China" || record.paymentmethod == "Osko" || record.type == "International Payment") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='checkbox' id='individualdebitsflag' />").appendTo($dataCol).on('change', handleIndividualDebitsFlagChanges);
        var $labelDesc = $("<label class='desc' for='individualdebitsflag'>Individual Debits</label>").appendTo($dataCol);
        if (record.debitaccountcountry == "China" && record.type != "International Payment") { 
            var $data = $("<input type='checkbox' id='urgentflag' />").appendTo($dataCol).on('change', handleUrgentFlagChanges);
            var $labelDesc = $("<label class='desc' for='urgentflag'>Urgent</label>").appendTo($dataCol);        
        }
    }

    /* Osko Limit */
    if (record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row' id='oksoLimitRow' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-note'>Daily Osko Limit: <strong>$5,000.00</strong></div>").appendTo($dataCol);
    }

    /* RIGHT CELL */
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);

    /* Statement Narrative */
    if (record.paymentmethod == "Direct Entry" || record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row mandatory' id='statementNarrativeRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Statement Narrative</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' id='statementNarrative' value='' style='width: 80%;' />").appendTo($dataCol).on("change", handleStatementNarrativeChange);        
    }

    /* Direct Entry ID */
    if (record.paymentmethod == "Direct Entry") {
        var $dataRow = $("<div class='row mandatory' id='directdirectEntryIDRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Direct Entry User ID</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol);
        var $data = $("<select id='directEntryID'><option value=''></option><option value='DIRECTDEBITID 1'>DIRECTDEBITID 1</option><option value='DIRECTDEBITID 2'>DIRECTDEBITID 2</option><option value='DIRECTDEBITID 3'>DIRECTDEBITID 3</option><option value='DIRECTDEBITID 4'>DIRECTDEBITID 4</option></select>").appendTo($customSelect).on("change", handleDirectEntryIDChange);        
    }

    /* Debit Advice Description */
    if (record.debitaccountcountry == "China" || record.paymentmethod == "Osko" || record.type == "International Payment") {
        var $dataRow = $("<div class='row' id='paymentDebitAdviceRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<textarea id='paymentDebitAdviceDescription' style='width: 80%; height: 80px;'></textarea>").appendTo($dataCol).on('change', handleDebitAdviceChanges);
    }

    /* ATTACH SECTION */
    $sectionRow.appendTo($paymentDataEntry);

    /* CHECK FOR VALUES */
    if (values != 'undefined' && values == true) {
        $("#paymentName").val(record.paymentname);
        $("#paymentReference").val(record.paymentreference);
        $("#paymentDebitAdviceDescription").val(record.debitadviceinformation);
        $("#directEntryID").val(record.directentryid);
        $("#endtoendid").val(record.endtoendid);
        $("#statementNarrative").val(record.statementnarrative);
        if ( record.valuedate != smartDates("today") ) {
            $("a[data-id='todayPayment']").parent("li").removeClass("selected");
            $("#todayPayment").hide();
            $("a[data-id='laterPayment']").parent("li").addClass("selected");
            $("#laterPayment").show();
            $("#valueDate").val(record.valuedate);
        }
        $("#paymentCurrency").val(record.paymentcurrency);
        $("#individualdebitsflag").prop("checked", record.individualdebitsflag);
        if (record.individualdebitsflag == true) {
            $("#paymentDebitAdviceRow").hide();
        } else {
            $("#paymentDebitAdviceRow").show();
        }
        if (record.debitaccountcurrency != record.paymentcurrency) {
            $("#useDebitCurrencyRow").show();
            if (record.debitcurrencyflag) {
                $("#debitcurrencyflag").prop("checked", record.debitcurrencyflag);
            }
        }
        if (record.urgentflag) {
            $("#urgentflag").prop("checked", record.urgentflag);
        }
    } else {
        var scrollToPoint = Math.abs( $(".py-initiation-steps").position().top - $("#paymentDetailsSection").position().top);
        setTimeout(function(){
            $("#paymentEntryForm").animate({
                scrollTop: scrollToPoint
            }, 300).promise().done(function() {
                $("#paymentName").focus();
            });
        },1);
    }
}

function renderAccountTransferDetailSection(values) {
    var $sectionRow = $("<div class='grid-row' id='paymentDetailsSection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);

    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);
    var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Value Date</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $valueDateDiv = $("<div style='display: inline-block; vertical-align: top;' />").appendTo($dataCol);
    var $valueDateList = $("<ul class='value-date-selection' />").appendTo($valueDateDiv);
    var $valueDateItem = $("<li class='selected highlighted' />").appendTo($valueDateList);
    var $valueDateAnchor = $("<a href='javascript:void(0)' id='highlighttoday' data-id='todayPayment'>Today</a>").appendTo($valueDateItem).on("click", handleValueDateChanges);
    var $valueDateItem = $("<li />").appendTo($valueDateList);
    var $valueDateAnchor = $("<a href='javascript:void(0)' data-id='laterPayment'>Later</a>").appendTo($valueDateItem).on("click", handleValueDateChanges);
    var $valueDateContainer = $("<div class='value-date-container' />").appendTo($valueDateDiv);
    var $valueDateOptions = $("<div />").appendTo($valueDateContainer);
    var $today = $("<div id='todayPayment' />").appendTo($valueDateOptions);
    var $cutOffTime = $("<div class='data-text'>" + smartDates('today') + "</div>").appendTo($today);
    var $later = $("<div id='laterPayment' style='display: none;' />").appendTo($valueDateOptions);
    var $dateInputDiv = $("<div class='date-input-div' style='width: 178px;' />").appendTo($later);
    var $input = $("<input type='text' id='valueDate' placeholder='dd/mm/yyyy' value='"+smartDates('today')+"' />").appendTo($dateInputDiv).datepicker({
        dateFormat: 'dd/mm/yy',
        constrainInput: true,
        changeMonth: true,
        changeYear: true,
        duration: 0,
        minDate: "+1",
        beforeShow: function() {
            var widget = $("#valueDate").datepicker("widget");
            widget.appendTo($("#valueDateCalendar"));
            $("#valueDateCalendar").show();
        },
        onClose: function() {
            var widget = $("#valueDate").datepicker("widget");
            widget.appendTo($("body"));
        }
    }).mask("99/99/9999", {
        placeholder: "dd/mm/yyyy"
    });
    var $calendarDiv = $("<div id='valueDateCalendar' class='date-picker-div' />").appendTo($dateInputDiv);
    var $cutOffTime = $("<div class='data-text' style='margin: 10px; vertical-align: top;'>Cut-off Time: 16:00 AEST</div>").appendTo($dataCol);

    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);
    if (record.debitaccountcurrency != record.creditaccountcurrency) {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $innerRow = $("<div class='grid-row' />").appendTo($dataCol);
        var $innerCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($innerRow);
        var $dataRow = $("<div class='row' id='paymentAmountRow' style='padding: 0; position: relative;' />").appendTo($innerCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $amountDiv = $("<div class='ccy-amount-input' />").appendTo($dataCol);
        var $data = $("<input type='text' style='width: 80%;' id='paymentAmount' value='0.00' />").appendTo($amountDiv);
        var $ccy = $("<div class='currency'>"+record.creditaccountcurrency+"</div>").appendTo($amountDiv);
        var $equal = $("<div style='position: absolute; top: 32px; right: 8%; font-size: 20px; color: #4a494a;'>=</div>").appendTo($dataCol);
        var $dataRow = $("<div class='row' id='useDebitCurrencyRow' style='padding-top: 5px; margin-bottom: -15px;' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='checkbox' id='debitcurrencyflag' />").appendTo($dataCol).on('change', handleDebitCurrencyFlagChanges);
        var $labelDesc = $("<label class='desc' for='debitcurrencyflag'>Enter Amount in Debit Currency</label>").appendTo($dataCol);
        var $innerCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($innerRow);
        var $dataRow = $("<div class='row' id='debitAmountRow' style='padding: 0;' />").appendTo($innerCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $amountDiv = $("<div class='ccy-amount-input' />").appendTo($dataCol);
        var $data = $("<input type='text' style='width: 80%;' id='debitAmount' value='0.00' />").appendTo($amountDiv);
        var $ccy = $("<div class='currency'>"+record.debitaccountcurrency+"</div>").appendTo($amountDiv);
    } else {
        var $dataRow = $("<div class='row' id='paymentAmountRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $amountDiv = $("<div class='ccy-amount-input' />").appendTo($dataCol);
        var $data = $("<input type='text' style='width: 80%;' id='paymentAmount' value='0.00' />").appendTo($amountDiv);
        var $ccy = $("<div class='currency'>"+record.creditaccountcurrency+"</div>").appendTo($amountDiv);
    }
    var $dataRow = $("<div class='row mandatory' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<input type='text' style='width: 80%;' value='"+record.paymentreference+"' id='paymentreference' />").appendTo($dataCol).on("change", handlePaymentInfoChanges);
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Debit Statement Narrative</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<input type='text' style='width: 80%;' id='debitstatementnar' />").appendTo($dataCol).on("change", handleDebitInfoChanges);
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Credit Statement Narrative</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<input type='text' style='width: 80%;' id='creditstatementnar' />").appendTo($dataCol).on("change", handleCreditInfoChanges);
       
 
    /* ATTACH SECTION */
    $sectionRow.appendTo($paymentDataEntry);

    /* SECTION LOGIC */
    if (record.debitaccountcurrency != record.creditaccountcurrency) {
        $("#debitcurrencyflag").prop("checked", record.debitcurrencyflag);
        if (record.debitcurrencyflag) {
            $("#paymentAmount").attr("readonly", true).off().parent("div.ccy-amount-input").addClass("readonly");;
            $("#debitAmountRow").addClass("mandatory");
            $("#debitAmount").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAccountTransferAmount).on("focus", function(){
                if ( $(this).val() == "0.00" ) {
                    $(this).val('');
                }
            });
        } else {
            $("#debitAmount").attr("readonly", true).off().parent("div.ccy-amount-input").addClass("readonly");;
            $("#paymentAmountRow").addClass("mandatory");
            $("#paymentAmount").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAccountTransferAmount).on("focus", function(){
                if ( $(this).val() == "0.00" ) {
                    $(this).val('');
                }
            });
        }
    } else {
        $("#paymentAmountRow").addClass("mandatory");
        $("#paymentAmount").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateAccountTransferAmount).on("focus", function(){
            if ( $(this).val() == "0.00" ) {
                $(this).val('');
            }
        });
    }
    $("#paymentReference").on('change', handlePaymentReferenceChanges);
    $("#paymentDebitAdviceDescription").on('change', handleDebitAdviceChanges);
    $("#remittanceInformation").on('change', handleRemittanceInfoChanges);
    if (record.debitaccountcountry == "Australia" && record.creditaccountcountry == "Australia") {
        $("#debitstatementnar").on('change', handleDebitStatementNarrativeChanges);
        $("#creditstatementnar").on('change', handleCreditStatementNarrativeChanges);
    }
    if (values != 'undefined' && values == true) {
        $("#paymentReference").val(record.paymentreference);
        $("#paymentDebitAdviceDescription").val(record.debitadviceinformation);
        $("#remittanceInformation").val(record.remittanceinformation);
        if ( record.valuedate != smartDates("today") ) {
            $("a[data-id='todayPayment']").parent("li").removeClass("selected");
            $("#todayPayment").hide();
            $("a[data-id='laterPayment']").parent("li").addClass("selected");
            $("#laterPayment").show();
            $("#valueDate").val(record.valuedate);
        }
        if (record.debitaccountcurrency != record.paymentcurrency) {
            if (record.fxratetype == "Contract") {
                if (record.debitcurrencyflag) {
                    $("#paymentAmount").val("--");
                    $("#debitAmount").val(addCommas(record.debitequivalentamount));
                } else {
                    $("#paymentAmount").val(addCommas(record.paymentamount));
                    $("#debitAmount").val("--");
                }
            } else {
                $("#paymentAmount").val(addCommas(record.paymentamount));
                $("#debitAmount").val(addCommas(record.debitequivalentamount));
            }
        } else {
            $("#paymentAmount").val(addCommas(record.paymentamount));
        }
        $("#debitstatementnar").val(record.debitstatementnarrative);
        $("#creditstatementnar").val(record.creditstatementnarrative);
    } else {
        var scrollToPoint = Math.abs( $(".py-initiation-steps").position().top - $("#paymentDetailsSection").position().top);
        setTimeout(function(){
            $("#paymentEntryForm").animate({
                scrollTop: scrollToPoint
            }, 300).promise().done(function() {
                $("#paymentReference").focus();
            });
        },1);
    }
}

function renderBeneficiarySection() {
    var $sectionRow = $("<div class='grid-row' id='beneficiarySection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Enter Beneficiary Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $paymentControlBarDiv = $("<div style='padding: 0 0 10px 0;' />").appendTo($dataCol);
    var $addButton = $("<span class='btn' />").appendTo($paymentControlBarDiv);
    var $addAnchor = $("<a href='javascript:void(0)' title='Add a beneficiary instruction'><i class='fa fa-plus-square fa-fw text-right blue'></i><span>Add</span></a>").appendTo($addButton).on("click", function(e){
        e.preventDefault();
        addBeneficiaryInstruction();
        grid.gotoCell(dataView.getLength() - 1,3,true);
    }).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });
    var $deleteButton = $("<span class='btn'>").appendTo($paymentControlBarDiv);
    var $deleteAnchor = $("<a href='javascript:void(0)' title='Remove selected instructions'><i class='fa fa-trash-o fa-fw text-right'></i><span>Remove</span></a>").appendTo($deleteButton).on("click", function(e){
        e.preventDefault();
        deleteBeneficiaryInstruction();
    }).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });

    var $filterButton = $("<span class='btn'>").appendTo($paymentControlBarDiv);
    var $filterAnchor = $("<a href='javascript:void(0)' title='Filter beneficiary instructions'><i class='fa fa-filter fa-fw text-right'></i><span>Filter</span></a>").appendTo($filterButton).on("click", toggleGridFilterRow).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });

    if (record.debitaccountcountry == "Australia" && record.type == "Domestic Payment") {
        if (record.paymentmethod != "RTGS") {
            var $defaultsButton = $("<span class='btn'>").appendTo($paymentControlBarDiv);
            var $defaultsAnchor = $("<a href='javascript:void(0)' title='Set batch default values'><i class='fa fa-cog fa-fw text-right'></i><span>Batch Defaults</span></a>").appendTo($defaultsButton).on("click", renderBatchDefaultsDialog).on("focus blur", function(e) {
                $(this).parent().toggleClass("focused", e.type === "focus")
            });
        }
    }

    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $beneficiaryGrid = $("<div class='payment-grid' id='beneficiaryGrid' />").appendTo($dataCol);
    var $totals = $("<div class='bottom-controls' />").appendTo($dataCol);
    var $table = $("<div class='bottom-control-table' />").appendTo($totals);
    var $list = $("<div class='control-list' style='width: 100%;' />").appendTo($table);
    var $list = $("<div class='control-list' />").appendTo($table);
    var $div = $("<div style='display: inline-block;' id='batchTotal' />").appendTo($list);

    /* ATTACH SECTION */
    $sectionRow.appendTo($paymentDataEntry);

    /* RENDER BATCH TOTALS */
    renderBatchTotalsUI();

    /* RENDER BENEFICIARY GRID */
    renderBeneficiaryGrid();
}

function renderBeneficiaryGrid() {

    data = record.instructions;
    selectedRowIds = [];
    options = {
        editable: true,
        autoEdit: true,
        enableAddRow: false,
        enableCellNavigation: true,
        enableColumnReorder: false,
        enableColumnResize: true,
        syncColumnCellResize: false,
        autoHeight: false,
        forceFitColumns: true,
        multiSelect: true,
        multiColumnSort: true,
        explicitInitialization: true,
        showHeaderRow: true,
        headerRowHeight: 40        
    };
    columns = [{
        id: "number",
        name: "#",
        field: "number",
        tooltip: "Item Number",
        width: 40,
        sortable: true,
        visible: true,
        sorter: "sorterNumeric",
        resizable: true,
        focusable: false,
        maxWidth: 75,
        minWidth: 40
    }, {
        id: "validated",
        name: "<i class='fa fa-check-circle fa-fw' style='color: #4d5d69;'></i>",
        field: "validated",
        toolTip: "Validation",
        width: 50,
        headerCssClass: "centered",
        cssClass: "centered",
        sortable: false,
        visible: true,
        resizable: false,
        focusable: false,
        formatter: Slick.Formatters.ValidatedIconFormatter
    }, {
        id: "beneficiaryname",
        name: "Beneficiary",
        field: "beneficiaryname",
        toolTip: "Beneficiary Name",
        width: 200,
        sortable: true,
        visible: true,
        resizable: true,
        sorter: "sorterStringCompare",
        editor: BeneficiaryFieldEditor,
        dataSource: beneficiaryAccounts 
    }, {
        id: "beneficiaryaccountnumber",
        name: "Account",
        field: "beneficiaryaccountnumber",
        toolTip: "Beneficiary Account",
        width: 175,
        sortable: true,
        visible: true,
        resizable: true,
        focusable: false,
        sorter: "sorterStringCompare"
    }, {
        id: "paymentreference",
        name: "Reference",
        field: "paymentreference",
        toolTip: "Reference",
        width: 150,
        sortable: true,
        visible: true,
        resizable: true,
        sorter: "sorterStringCompare",
        editor: Slick.Editors.Text
    }, {
        id: "amount",
        name: "Amount",
        field: "amount",
        toolTip: "Amount",
        headerCssClass: "righted",
        cssClass: "righted",
        sorter: "sorterNumeric",
        width: 125,
        sortable: true,
        visible: true,
        resizable: true,
        formatter: CurrencyAndAmountFormatter,
        editor: AmountFieldEditor
    }, {
        id: "id",
        name: "",
        field: "id",
        sortable: false,
        width: 60,
        maxWidth: 60,
        minWidth: 60,
        resizable: false,
        headerCssClass: "centered",
        cssClass: "centered",
        editor: instructionDialog,
        formatter: viewFormatter = function(row, cell, value, columnDef, dataContext) {
            return "<button data-action='edit-instruction' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba;' id='"+value+"'><i class='fa fa-pencil-square-o fa-fw'></i></button>";
        }
    }];

    var checkboxSelector = new Slick.CheckboxSelectColumn({
        cssClass: "slick-cell-checkboxsel"
    });
    columns.unshift(checkboxSelector.getColumnDefinition());

    if ( record.debitaccountcountry == "China" && record.type == "Domestic Payment") {
        var methodColumn = {
            id: "paymentmethod",
            name: "Method",
            field: "paymentmethod",
            toolTip: "Method",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare",
            editor: PaymentMethodEditor
        }
        columns.splice(5, 0, methodColumn)
    }

    if ( record.paymentmethod == "Osko" ) {

        columns.splice(5, 1)

        var endToEndColumn = {
            id: "endtoendid",
            name: "End-to-End ID",
            field: "endtoendid",
            toolTip: "End-to-End ID",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare",
            editor: Slick.Editors.Text
        }
        columns.splice(5, 0, endToEndColumn)

        var emailColumn = {
            id: "emailadviceflag",
            name: "<i class='fa fa-envelope fa-fw' style='color: #4d5d69;'></i>",
            field: "emailadviceflag",
            toolTip: "Email Address",
            width: 60,
            maxWidth: 60,
            minWidth: 60,
            headerCssClass: "centered",
            cssClass: "centered",
            sortable: false,
            visible: true,
            resizable: false,
            editor: Slick.Editors.Checkbox,
            formatter: Slick.Formatters.Checkmark
        }
        columns.splice(7, 0, emailColumn)
    }

    function CurrencyAndAmountFormatter(row, cell, value, columnDev, dataContext) {
        if (record.debitcurrencyflag) {
            return dataContext.debitcurrency + " $" + addCommas(parseFloat(dataContext.debitequivalentamount).toFixed(2));
        } else {
            return dataContext.paymentcurrency + " $" + addCommas(parseFloat(dataContext.paymentamount).toFixed(2));
        }
    }

    function BeneficiaryFieldEditor(args) {
        var $container = $("body");
        var $comboBox;
        var $beneficiaryName;
        var $beneficiaryNumber;
        var $beneficiaryID;
        var results;
        var defaultName;
        var defaultNumber;
        var defaultID;
        var scope = this;

        this.init = function() {
            $wrapper = $("<DIV id='inlineBeneficiarySuggestions' style='z-index:10000; position:absolute; min-width: 250px;'/>").appendTo($container);
            $comboBox = $("<div class='combobox-div' style='margin-right: 0; width: 100%; height: 35px; line-height: 35px; display: block;' />");
            $beneficiaryName = $("<input type='text' id='beneName' />");
            $beneficiaryNumber = $("<input type='hidden' id='beneNumber' />");
            $beneficiaryID = $("<input type='hidden' id='beneID' />");
            $beneficiaryName.appendTo($comboBox);
            $beneficiaryNumber.appendTo($comboBox);
            $beneficiaryID.appendTo($comboBox);
            $comboBox.appendTo(args.container);
            $beneficiaryName.autocomplete({
                autoFocus: false,
                delay: 10,
                minLength: 0,
                appendTo: "#inlineBeneficiarySuggestions",
                position: {
                    my: "left top",
                    at: "left bottom",
                    collision: "flip"
                },
                source: function(request, response) {
                    $("#beneName").autocomplete( "option", "autoFocus", false );
                    var results = $.ui.autocomplete.filter(availableBeneficiaryAccounts, extractLast(request.term).trim());
                    if (!results.length) {
                        results = [{
                            value: 'No Matches Found'
                        }];
                        results.unshift({value:"Search Beneficiaries"});
                        results.unshift({value:"Add New Beneficiary"});
                    } else if (results.length === 1) { 
                        $("#beneName").autocomplete( "option", "autoFocus", true );
                    } else {
                        if (request.term == "") {
                            results.unshift({value:"Search Beneficiaries"});
                            results.unshift({value:"Add New Beneficiary"});
                        }
                    }
                    response(results);
                },
                focus: function(event, ui) {
                    return false;
                },
                select: function(event, ui) {
                    if (ui.item.value == "No Matches Found") {
                        this.value = "";
                        $("#beneNumber").val("");
                        $("#beneID").val("");
                        return false;
                    } else if (ui.item.value == "Add New Beneficiary") {
                        renderAddBeneficiaryDialog();
                        return false;
                    } else if (ui.item.value == "Search Beneficiaries") {
                        renderSearchBeneficiaryDialog();
                        return false;
                    } else { 
                        this.value = ui.item.name;

                        $("#beneNumber").val(ui.item.accountnumber);
                        $("#beneID").val(ui.item.id);
                        var r = grid.getActiveCell(); 
                        var item = dataView.getItem(r.row);
                        
                        item.paymentaddress = ui.item.paymentaddress;
                        item.payidtype = ui.item.payidtype;
                        item.payidname = ui.item.payidname;
                       // grid.updateCell(r,5);
                        grid.getEditController().commitCurrentEdit();
                       
                        grid.gotoCell(r.row, 5, true);
                        return false;
                    }
                },
                close: function(event, ui) {
                    var matcher = $(this).val().trim();
                    var matchie = "";
                    var numb = "";
                    var bid = "";
                    var valid = false;
                    $.each(beneficiaryAccounts, function() {
                        if (this.name.toLowerCase() == matcher.toLowerCase()) {
                            valid = true;
                            matchie = this.name;
                            numb = this.accountnumber;
                            bid = this.id;
                            return false;
                        }
                    });
                    if (valid) {
                        $(this).val(matchie);
                        $("#beneNumber").val(numb);
                        $("#beneID").val(bid);
                    }
                    if (!valid) {
                        $(this).val(defaultName);
                        $("#beneNumber").val(defaultNumber);
                        $("#beneID").val(defaultID);
                    }
                    $(this).data().autocomplete.term = null;
                }
            }).data("autocomplete")._renderItem = function(ul, item) {
                if (item.value == "Add New Beneficiary") {
                     return $("<li id='addBeneficiaryDialog'></li>").data("item.autocomplete", item).append("<a style='color: #007dba;'><i class='fa fa-plus-square fa-fw'></i> " + item.value + "</a>").appendTo(ul);
                } else if (item.value == "Search Beneficiaries") {
                    return $("<li id='searchBeneficiaryDialog'></li>").data("item.autocomplete", item).append("<a style='color: #007dba;'><i class='fa fa-search fa-fw'></i> " + item.value + "</a>").appendTo(ul);
                } else if (item.value == "No Matches Found") {
                    return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
                } else {
                    return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br />" + item.accountnumber + "</a>").appendTo(ul);
                }
            };
            $beneficiaryName.on("click", function(){
                resultsAreVisible = $("#beneName").autocomplete("widget").is(":visible");
                if (resultsAreVisible) {
                    $("#beneName").autocomplete("close");
                } else {
                    $("#beneName").autocomplete("search", "");
                }           
            }).on("keydown", this.handleKeyDown);
            scope.position(args.position);
        }

        this.handleKeyDown = function (e) {
            e.stopPropagation();
            if (e.which == 27) {
                $beneficiaryName.val(defaultName);
                $beneficiaryNumber.val(defaultNumber);
                $beneficiaryID.val(defaultID);
                $beneficiaryName.autocomplete("close");
                args.cancelChanges();
            } else if (e.which == 9) {
                $beneficiaryName.autocomplete("close");
                var r = grid.getActiveCell(),
                    c;
                if (e.shiftKey) {
                    c = 0;
                } else {
                    c = 5;
                }
                grid.gotoCell(r.row, c, true);
                return false;
            }
        };

        this.destroy = function () {
          $beneficiaryName.autocomplete("destroy").remove();
          $comboBox.remove();
          $wrapper.remove();
        };

        this.focus = function () {
          $beneficiaryName.focus();
        };

        this.hide = function () {
          $wrapper.hide();
        };

        this.show = function () {
          $wrapper.show();
        };

        this.position = function (position) {
            $wrapper.css("top", position.top - 5).css("left", position.left - 5)
        };

        this.loadValue = function (item) {
            defaultName = item[args.column.field];
            $beneficiaryName.val(defaultName);
            $beneficiaryNumber.val(defaultNumber);
            $beneficiaryID.val(defaultID);
            $beneficiaryName.select();
        };

        this.serializeValue = function () {
            return { beneficiaryname: $beneficiaryName.val(), beneficiaryaccountnumber: $beneficiaryNumber.val(), beneficiaryid: $beneficiaryID.val() };
        };

        this.applyValue = function (item, state) {
            item.beneficiaryname = state.beneficiaryname;
            item.beneficiaryaccountnumber = state.beneficiaryaccountnumber;
            item.beneficiaryid = state.beneficiaryid;
            if (state.beneficiaryname == '') {
                item.paymentmethod = '';
            }
        };

        this.isValueChanged = function () {
           return (!($beneficiaryName.val() == "" && defaultName == null)) && ($beneficiaryName.val() != defaultName);
        };

        this.validate = function () {
          return {
            valid: true,
            msg: null
          };
        };

        this.init();
    }

    function PaymentMethodEditor(args) {
        var $customSelect;
        var $select;
        var $options;
        var defaultValue;
        var scope = this;

        this.init = function () {
            $customSelect = $("<div class='custom-select' style='max-width: 100% !important; width: 100%; margin-right: 0;' />");
            $select = $("<select id='paymentMethod'></select>").appendTo($customSelect);
            $options = grabPaymentMethods(args.item).appendTo($select);
            $customSelect.appendTo(args.container);
            $select.focus();
        };

        this.destroy = function () {
          $customSelect.remove();
        };

        this.focus = function () {
          $select.focus();
        };

        this.loadValue = function (item) {
            defaultValue = item[args.column.field];
            $select.val(defaultValue);
            $select.select();
        };

        this.serializeValue = function () {
            return { paymentmethod: $select.val() };
        };

        this.applyValue = function (item, state) {
          item[args.column.field] = state.paymentmethod;
        };

        this.isValueChanged = function () {
            return (!($select.val() == "" && defaultValue == null)) && ($select.val() != defaultValue);
        };

        this.validate = function () {
          return {
            valid: true,
            msg: null
          };
        };

        this.init();
    }

    function AmountFieldEditor(args) {
        var $input;
        var $currencyLabel;
        var defaultValue;
        var scope = this;

        this.init = function () {
            $input = $("<input type=text class='editor-text' style='text-align: right; padding-right: 7px; padding-left: 45px;' />")
                .appendTo(args.container)
                .bind("keydown.preventAlpha", preventAlphaKeys)
                .bind("keydown.nav", function (e) {
                if (e.keyCode === $.ui.keyCode.LEFT || e.keyCode === $.ui.keyCode.RIGHT) {
                    e.stopImmediatePropagation();
                }
            }).focus();
            $currencyLabel = $("<div style='position: absolute; top: 5px; left: 20px; line-height: 30px; background: #fff;' />").appendTo(args.container);
        };

        this.destroy = function () {
          $input.remove();
        };

        this.focus = function () { 
            $input.focus();
        };

        this.getValue = function () {
          return $input.val();
        };

        this.setValue = function (val) {
          $input.val(val);
        };

        this.loadValue = function (item) {
            if (record.debitcurrencyflag) {
                var val = (item.debitequivalentamount == 0) ? '' : addCommas(parseFloat(item.debitequivalentamount).toFixed(2))
                $input.val(val);
                $currencyLabel.html(item.debitcurrency);
            } else {
                var val = (item.paymentamount == 0) ? '' : addCommas(parseFloat(item.paymentamount).toFixed(2))
                $input.val(val);
                $currencyLabel.html(item.paymentcurrency);
            }
        };

        this.serializeValue = function () {
          return $input.val();
        };

        this.applyValue = function (item, state) {
            instruction = item;
            if (record.debitcurrencyflag) {
                if (state == "") {
                    state = 0;
                    item.debitequivalentamount = parseFloat(state).toFixed(2);
                } else {
                    item.debitequivalentamount = parseFloat(removeCommas(state)).toFixed(2);
                }
            } else {
                if (state == "") {
                    state = 0;
                    item.paymentamount = parseFloat(state).toFixed(2);
                } else {
                    item.paymentamount = parseFloat(removeCommas(state)).toFixed(2);
                }
            }
            updateBatchTotals();
        };

        this.isValueChanged = function () {
          return ($input.val() != defaultValue);
        };

        this.validate = function () {
          if (args.column.validator) {
            var validationResults = args.column.validator($input.val());
            if (!validationResults.valid) {
              return validationResults;
            }
          }

          return {
            valid: true,
            msg: null
          };
        };

        this.init();
    }

    function instructionDialog(args) {
        var $button;
        var $defaultValue;
        var scope = this;

        this.init = function () {
            $button = $("<button data-action='edit-instruction' style='padding: 0; margin: 0; border: 0; background: transparent; font-size: 14px; color: #007dba;' id='"+args.item.id+"'><i class='fa fa-pencil-square-o fa-fw'></i></button>")
                .appendTo(args.container)
                .bind("click", function(e){
                    renderEditInstructionDialog($(this), args.item);
                    return false;
                })
                .bind("keydown", function (e) {
                if (e.keyCode === 13) {
                    renderEditInstructionDialog($(this), args.item);
                    return false;
                }
            })
            .focus();
        };

        this.destroy = function () {
          $button.remove();
        };

        this.focus = function () {
          $button.focus();
        };

        this.getValue = function () {
        };

        this.setValue = function (val) {
        };

        this.loadValue = function (item) {
        };

        this.serializeValue = function () {
        };

        this.applyValue = function (item, state) {          
        };

        this.isValueChanged = function () {
        };

        this.validate = function () {
        };

        this.init();
    }

    function gridFilter(item, args) {
        for (var columnId in columnFilters) {
            if (columnId !== undefined && columnFilters[columnId] !== "") {
                var c = grid.getColumns()[grid.getColumnIndex(columnId)],
                    _sorter = c.sorter;
                if (_sorter == "sorterNumeric") {
                    var _filter = columnFilters[columnId];
                    var _field;
                    if ( c.id == "amount" ) {
                        if (record.debitcurrencyflag) {
                            _field = item.debitequivalentamount;
                        } else {
                            _field = item.paymentamount;
                        }
                    } else {
                        _field = "" + item[c.field];
                    }
                    _field = _field.replace(/[^\d\.\-\ ]/g, '');
                    var _greaterThen, _lessThen, _comparer, _between = false;
                    if (_filter.charAt(0) === ">") {
                        _greaterThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
                        if (_filter.indexOf("<") != -1) {
                            _between = true
                        }
                        if (_between) {
                            _lessThen = _filter.substr(_filter.lastIndexOf("<") + 1).replace(/[^\d\.\-\ ]/g, '');
                            if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
                                return false;
                            }
                        } else {
                            if (parseFloat(_field) < parseFloat(_greaterThen)) {
                                return false;
                            }
                        }
                    } else if (_filter.charAt(0) === "<") {
                        _lessThen = _filter.substr(1).replace(/[^\d\.\-\ ]/g, '');
                        if (_filter.indexOf(">") != -1) {
                            _between = true
                        }
                        if (_between) {
                            _greaterThen = _filter.substr(_filter.lastIndexOf(">") + 1).replace(/[^\d\.\-\ ]/g, '');
                            if ((parseFloat(_field) > parseFloat(_lessThen)) || (parseFloat(_field) < parseFloat(_greaterThen))) {
                                return false;
                            }
                        } else {
                            if (parseFloat(_field) > parseFloat(_lessThen)) {
                                return false;
                            }
                        }
                    } else {
                        if (_field.indexOf(_filter.replace(/[^\d\.\-\ ]/g, '')) == -1) {
                            return false;
                        }
                    }
                } else {
                    if (item[c.field].toLowerCase().indexOf(columnFilters[columnId].toLowerCase()) == -1) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    var itemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
    dataView = new Slick.Data.DataView({
        itemMetaProvider: itemMetaProvider
    });
    grid = new Slick.Grid("#beneficiaryGrid", dataView, columns, options);
    grid.setSelectionModel(new Slick.RowSelectionModel({
        selectActiveRow: false
    }));
    grid.registerPlugin(itemMetaProvider);
    grid.registerPlugin(checkboxSelector);
    grid.onSelectedRowsChanged.subscribe(function(e) {
        selectedRowIds = [];
        var rows = grid.getSelectedRows();
        for (var i = 0, l = rows.length; i < l; i++) {
            var item = dataView.getItem(rows[i])
            if (item.id) {
                selectedRowIds.push(item.id);
            }
        }
    });
    grid.onClick.subscribe(function (e, args) {
        if ($(e.target).is(':checkbox') && options['editable']) {
            var column = args.grid.getColumns()[args.cell];
            if (column['editable'] == false || column['autoEdit'] == false) {
                return;
            }
            dataView.getItem(args.row)[column.field] = !dataView.getItem(args.row)[column.field]
        }  
    });
    grid.onSort.subscribe(function(e, args) {
        var cols = args.sortCols;
        dataView.sort(function(dataRow1, dataRow2) {
            for (var i = 0, l = cols.length; i < l; i++) {
                sortdir = cols[i].sortAsc ? 1 : -1;
                sortcol = cols[i].sortCol.field;
                var _sorter = cols[i].sortCol.sorter,
                    result;
                if (_sorter == "sorterStringCompare") {
                    result = sorterStringCompare(dataRow1, dataRow2);
                } else if (_sorter == "sorterNumeric") {
                    result = sorterNumeric(dataRow1, dataRow2);
                } else if (_sorter == "sorterDateIso") {
                    result = sorterDateIso(dataRow1, dataRow2);
                } else if (_sorter == "sorterTime") {
                    result = sorterTime(dataRow1, dataRow2);
                }
                if (result != 0) {
                    return result;
                }
            }
            return 0;
        });
        args.grid.invalidateAllRows();
        args.grid.render();
    });
    grid.onKeyDown.subscribe(function(e, args) {
        if (e.keyCode === 9) {
            e.stopPropagation();
            if ( grid.getActiveCell() ) {
                var cell = grid.getActiveCell();
                var row = cell.row;
                var columnCount = grid.getColumns().length - 1;
                var rowCount = grid.getDataLength() - 1; 
                if (e.shiftKey === false) {
                    if ( cell.cell == columnCount && row == rowCount ) {
                        addBeneficiaryInstruction();
                        grid.gotoCell(dataView.getLength() - 1,0,true);
                    }
                } 
            }
        }
    });
    $(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
        var columnId = $(this).data("columnId");
        var $icon = $(this).next("i");
        if (columnId != null) {
            columnFilters[columnId] = $.trim($(this).val());
            $icon.show();
            dataView.refresh();
            if (!$(this).val()) {
                $icon.hide();
            }
        }
    });
    grid.onHeaderRowCellRendered.subscribe(function(e, args) {
        if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column" || args.column.id == "email" || args.column.id == "validated" || args.column.id == "id") {
            return false;
        } else {
            $(args.node).empty().addClass(args.column.headerCssClass);
            var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
            var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
                e.preventDefault();
                $(this).prev("input[type='text']").val("").trigger("change");
                $(this).hide();
            });
            if ($input.val()) {
                $icon.show();
            }
        }
    });
    dataView.onRowCountChanged.subscribe(function(e, args) {
        grid.updateRowCount();
        grid.render();
    });
    dataView.onRowsChanged.subscribe(function(e, args) {
        grid.invalidateRows(args.rows);
        grid.render();
        if (selectedRowIds.length > 0) {
            var selRows = [];
            for (var i = 0; i < selectedRowIds.length; i++) {
                var idx = dataView.getRowById(selectedRowIds[i]);
                if (idx != undefined)
                    selRows.push(idx);
            }
            grid.setSelectedRows(selRows);
        }
    });
    dataView.beginUpdate();
    dataView.setItems(data);
    dataView.setFilter(gridFilter);
    dataView.syncGridSelection(grid, true, false);
    dataView.syncGridCellCssStyles(grid, "contextMenu");
    dataView.endUpdate();
    grid.setColumns(columns);

    $(window).on("resize.grid", function() {
        grid.resizeCanvas();
    });
    $(window).on("resize.grid", _.debounce(function(e) {
        grid.resizeCanvas();
    }, 100));

    $('#beneficiaryGrid').on('blur.editorFocusLost', 'input, select, textarea, button', function() {
        window.setTimeout(function() {
            var focusedEditor = $("#beneficiaryGrid :focus");
            if (focusedEditor.length == 0 && Slick.GlobalEditorLock.isActive()) {
                Slick.GlobalEditorLock.commitCurrentEdit();
            }
        }, 150);
    });

    $('#beneficiaryGrid').on("click", "button[data-action='edit-instruction']", function(e){
        var $target = $("#"+$(this).attr("id"));
        var itemID = $target.attr("id");
        renderEditInstructionDialog($target, dataView.getItemById(itemID));
        return false;
    });

    setTimeout(function(){
        grid.init();
        grid.setHeaderRowVisibility(false);
    }, 1);
}

function renderFXSection() {
    var $sectionRow = $("<div class='grid-row' id='paymentFXSection' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' />").appendTo($boxRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Rate Type</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 150px; max-width: 100%;' />").appendTo($dataCol);

    if (record.debitaccountcountry == "Australia") {
        var $select = $("<select id='fxratetype'><option value='Dynamic'>Dynamic</option><option value='Contract'>Contract</option></select>").appendTo($customSelect).on('change', handleFXTypeChange);
    } else {
        var $select = $("<select id='fxratetype'><option value='Carded'>Carded</option><option value='Contract'>Contract</option></select>").appendTo($customSelect).on('change', handleFXTypeChange);
    }

    var $btnSpan = $("<span class='form-button primary' id='fxContractButton' style='display: none; margin-left: 30px;' />").appendTo($dataCol);
    var $btnLink = $("<a href='javascript:void(0)' id='fxContractSearch'><i class='fa fa-search fa-fw'></i><span>Find &amp; Add Contracts</span></a>").appendTo($btnSpan).on('click', renderFXContractDialog);
    var $boxCell = $("<div class='grid-cell' />").appendTo($boxRow);
    var $row = $("<div class='row' id='cardedRateRow' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Rate</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<div class='data-text' id='cardedRate' />").appendTo($dataCol);
    var $boxRow = $("<div class='grid-row' id='fxContractSection' style='display: none;' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $dataCol = $("<div class='data-column full' />").appendTo($row);
    var $dataTable = $("<div class='data-table' id='fxContractList' />").appendTo($dataCol);
    var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
    var $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Contract ID</div>").appendTo($dataTableRow);
    var $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow);
    var $dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow);
    var $dataTableCell = $("<div class='data-table-cell' style='width: 15%; text-align: right;'>FX Rate</div>").appendTo($dataTableRow);
    var $dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
    var $dataTable = $("<div class='data-table' style='border: 0;' />").appendTo($dataCol);
    var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
    var $dataTableCell = $("<div class='data-table-cell' style='width: 50%; background: transparent; border-bottom: 0 !important;' />").appendTo($dataTableRow);
    var $checkbox = $("<input type='checkbox' id='cardedRateFlag' />").appendTo($dataTableCell).on("change", handleCardedRateFlagChanges);

    if (record.debitaccountcountry == "Australia") {
        var $label = $("<label class='desc' id='cardedRateFlagLabel' for='cardedRateFlag'>Use Dynamic Rate For Remaining Amount</label>").appendTo($dataTableCell);
    } else {
        var $label = $("<label class='desc' id='cardedRateFlagLabel' for='cardedRateFlag'>Use Carded Rate For Remaining Amount</label>").appendTo($dataTableCell);
    }

    var $dataTableCell = $("<div class='data-table-cell' style='width: 50%; text-align: right; background: transparent; border-bottom: 0 !important;' id='remainingPaymentAmount' />").appendTo($dataTableRow);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $dataCol = $("<div class='data-column full' />").appendTo($row);
    var $data = $("<div class='data-note'>* FX rate is indicative only and subject to change at any time without notice.</div>").appendTo($dataCol);
    return $sectionRow;
}

function renderSupportingDocumentSection(values) {
    var $sectionRow = $("<div class='grid-row' id='supportingDocumentSection' />");
    var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
    var $box = $("<div class='box' />").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $btnSpan = $("<span class='form-button' id='uploadSupportingDoc' />").appendTo($dataCol);
    var $btnLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Attach Document</a>").appendTo($btnSpan);
    var $fileInput = $("<input type='file' name='file' id='paymentSupportingDoc' style='position: absolute; left: 20px; padding: 0; margin-top: 2px; width: 192px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($btnSpan).on("change", function(){
            attachSupportingDocument()
        });
    var $progBarDiv = $("<div id='paymentProgressBar' style='display: none;' />").appendTo($dataCol);
    var $progBar = $("<div class='progress-bar' />").appendTo($progBarDiv);
    var $progMeter = $("<div class='progress-meter' />").appendTo($progBar);
    var $documentsListRow = $("<div class='grid-row' style='display: none;' id='attachedDocuments' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%' />").appendTo($documentsListRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $dataTable = $("<div class='data-table' data-supporting-docs='newInstruction' />").appendTo($dataCol);
    var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
    var $fileNameCell = $("<div class='data-table-cell' style='width: 70%;'>File Name</div>").appendTo($dataTableRow);
    var $statusCell = $("<div class='data-table-cell' style='width: 30%;'>Status</div>").appendTo($dataTableRow);
    if (values != 'undefined' && values == true) {
        var item = (record.type == 'Account Transfer') ? record : instruction;
        if (item.docs.length) {
            $documentsListRow.css({"display":"block"});
            for (var i = 0, l = item.docs.length; i < l; i++) {
                var _doc = item.docs[i];
                var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />");
                var $fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow);
                var $removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell).on("click", function(e) {
                    e.preventDefault();
                    $(this).closest("div.data-table-row").remove();
                    if ( record.type == "Account Transfer" ) {
                       for (var i = 0, l = record.docs.length; i < l; i++) {
                            if (record.docs[i].id == _doc.id) {
                                record.docs.splice(i, 1);
                            }
                        }
                    } else {
                        for (var i = 0, l = instruction.docs.length; i < l; i++) {
                            if (instruction.docs[i].id == _doc.id) {
                                instruction.docs.splice(i, 1);
                            }
                        }
                    }
                    clearTimeout(attachTimer);
                    if (!$("div[data-doc-row]").size()) {
                        $("#attachedDocuments").hide();
                    }
                });
                var $documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell);
                var $statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "</div>").appendTo($dataTableRow);
                $dataTableRow.appendTo($dataTable);
            }
        }
    }
    return $sectionRow;
}

function renderRemitDetailSection(values) {
    var $sectionRow = $("<div class='grid-row' id='remitSection' />");
    var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
    var $box = $("<div class='box' />").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Remittance Information</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    if (record.type == "Account Transfer") {
        var $dataRow = $("<div class='row' id='debitadvicedescriptionRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $debitAdviceDescription = $("<textarea id='paymentDebitAdviceDescription' style='width: 80%; height: 80px;'></textarea>").appendTo($dataCol).on("change", handleDebitAdviceChanges);
    } else {
        var $row = $("<div class='row' id='remittanceinformationRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($row);
        var $label = $("<label>Remittance Information</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $remittanceInformation = $("<textarea id='remittanceInformation' style='width: 80%; height: 80px;'></textarea>").appendTo($dataCol).on("change", handleRemittanceInfoChanges);
    }
    var $row = $("<div class='row' id='invoicedetailsRow' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' style='text-align:left' />").appendTo($row);
    var $label = $("<label>Invoice Details</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $invoiceDetails = $("<textarea id='invoiceDetails' style='width: 80%; height: 175px;'></textarea>").appendTo($dataCol).on("change", handleInvoiceDetailChanges);

    if (record.type != "Account Transfer") {
        var $row = $("<div class='row' id='emailadvicerow' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $emailFlag = $("<input type='checkbox' id='emailBeneficiaryFlag' name='emailFlag' />").appendTo($dataCol).on("change", function(){
            if ( $(this).prop("checked") ) {
                $("#beneEmailField").attr("disabled", false).attr("readonly", false).removeClass("disabled").focus();
                instruction.emailadviceflag = true;
            } else {
                $("#beneEmailField").attr("disabled", true).attr("readonly", true).addClass("disabled");
                instruction.emailadviceflag = false;
            }
        });
        var $labelDesc = $("<label class='desc' for='emailBeneficiaryFlag'>Email Beneficiary Advice</label>").appendTo($dataCol);
        var $email = $("<input type='text' style='width: 250px;' id='beneEmailField' disabled='disabled' readonly='readonly' class='disabled' />").appendTo($dataCol);
    }

    if ( values != 'undefined' && values == true ) {
        var item = (record.type == "Account Transfer") ? record : instruction;
        if (record.type == "Account Transfer") {
            $debitAdviceDescription.val(item.debitadviceinformation);           
        } else {
            $remittanceInformation.val(item.remittanceinformation);
        }
        $invoiceDetails.val(item.invoiceinformation);
        if (record.type != "Account Transfer") {
            if (item.emailadviceflag) {
                $emailFlag.prop("checked", true);
                $email.attr("disabled", false).attr("readonly", false).removeClass("disabled");
            } else {
                $emailFlag.prop("checked", false);
                $email.attr("disabled", true).attr("readonly", true).addClass("disabled");
            }
        }
    }

    return $sectionRow;
}

function renderAdditionalInformationSection() {
    var $sectionRow = $("<div class='grid-row' id='instDialogBOPSection' />");
    var $cell = $("<div class='grid-cell' />").appendTo($sectionRow);
    var $box = $("<div class='box' />").appendTo($cell);
    var $boxHeader = $("<div class='box-header'>Additional Information</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxrow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxcell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxrow);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $dataCol = $("<div class='data-column full' />").appendTo($row);
    var $data = $("<input type='checkbox' id='manualBOP' checked='checked' />").appendTo($dataCol).on("change", function(){
        if ( $(this).prop("checked") ) {
            $("#BOPFields").hide();
        } else {
            $("#BOPFields").show();
        }
    });
    var $desc = $("<label for='manualBOP' class='desc'>Provided BOP form manually to bank</label>").appendTo($dataCol);
    var $boxrow = $("<div class='grid-row' id='BOPFields' style='display: none;' />").appendTo($boxContent);
    var $boxcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxrow);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Amount in Words</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField1' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Transaction Code 1</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField2'><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Transaction Description 1</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField3' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Ccy 1</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField4><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Amount 1</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField5' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Transaction Code 2</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField6'><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Description 2</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField7' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Ccy 2</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField8'><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Amount 2</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField9' />").appendTo($dataCol);
    var $boxcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxrow);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Unit Code</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField10' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Beneficiary Resident Country / Region Name</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<div class='data-text' id='bopField11'></div>").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Beneficiary Resident Country / Region Code</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<div class='data-text' id='bopField12'></div>").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Payment Nature</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField13'><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Tax Free Goods</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField14'><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Type of Payment</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField15'><option value=''></option></select>").appendTo($customSelect);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Contract Number</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField16' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Invoice Number</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField17' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Safe Batch / Registration Number</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<input type='text' value='' style='width: 85%;' id='bopField18' />").appendTo($dataCol);
    var $row = $("<div class='row' />").appendTo($boxcell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>BOP Reporting Type</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
    var $data = $("<select id='bopField19'><option value=''></option></select>").appendTo($customSelect);
    return $sectionRow;
}





/* RENDER REVIEW SCREEN SECTIONS */

function returnToPaymentEditing() {

    /* LOADING OVERLAY */
    $shell.addClass("loading");

    setTimeout(function() {
        $("#paymentEntryForm").scrollTop(0);
        updatePaymentCreationSteps(1);
        $("#submitButtonGroup, #previousButtonGroup").remove();
        $paymentReviewScreen.hide().empty();
        renderDebitAccountSection();
        if (record.type == "Account Transfer") {
            renderCreditAccountSection();
            renderAccountTransferDetailSection(true);
            renderRemitDetailSection(true).appendTo($paymentDataEntry);
            renderSupportingDocumentSection(true).appendTo($paymentDataEntry); 
            if (record.debitaccountcurrency != record.paymentcurrency) {
                renderFXSection().insertAfter($("#paymentDetailsSection"));
                $("#fxratetype").val(record.fxratetype);
                if (record.fxratetype == "Carded") {
                    returnCardedRate();
                } else {
                    $("#cardedRateRow").hide();
                    $("#fxContractButton, #fxContractSection").show();  
                    for (var i = 0, l = record.fxcontracts.length; i < l; i++) {
                        var contract = record.fxcontracts[i];
                        if (contract.id == "cardedRateEntry") {
                            var $row = $("<div class='data-table-row' data-contract-row='true' id='usedCardedRateInContractsRow' />");  
                        } else {
                            var $row = $("<div class='data-table-row' data-contract-row='true' id='" + contract.id + "' />");                           
                        }
                        var $referencecell = $("<div class='data-table-cell' style='width: 25%;' data-type='reference' />").appendTo($row);
                        var $removebutton = $("<a href='javascript:void(0)' data-contract-id='" + contract.id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
                            e.preventDefault();
                            $(this).closest("div.data-table-row").remove();
                            var _cid = $(this).attr("data-contract-id");
                            if (_cid == "cardedRateEntry") {
                                $("#cardedRateFlag").prop("checked", false);
                                record.cardedrateflag = false;
                            }
                            record.fxcontracts = _.without(record.fxcontracts, _.findWhere(record.fxcontracts, {
                                id: _cid
                            }));
                            renderContractAmountsUI();
                        });
                        var $reference = $("<span>" + contract.number + "</span>").appendTo($referencecell);
                        var $fxidcell = $("<div class='data-table-cell' style='width: 20%;' data-type='fxid' />").appendTo($row);
                        var $fxiddata = $("<span>" + contract.fxid + "</span>").appendTo($fxidcell);
                        var $amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='amount'  />").appendTo($row);
                        if (contract.id == "cardedRateEntry") {
                            var $amountdata = $("<span>" + addCommas(contract.amount) + "</span>").appendTo($amountcell);
                        } else {
                            var $amountdata = $("<span>$" + addCommas(contract.amount) + "</span>").appendTo($amountcell);                           
                        }
                        var $ratecell = $("<div class='data-table-cell' style='width: 15%; text-align: right;' />").appendTo($row);
                        var $rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell);
                        var $usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='used' >").appendTo($row);
                        if (contract.id == "cardedRateEntry") {
                            var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0; border: 0;' disabled='disabled' data-contract-id='cardedRateEntry' id='cardedRateEntry' value='" + addCommas(contract.used) + "' />").appendTo($usedamountcell);
                        } else {
                            var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + contract.id + "' value='" + addCommas(contract.used) + "' />").appendTo($usedamountcell).on("keydown", preventAlphaKeys).on("change", function() {
                                    var val = $(this).val();
                                    var cid = $(this).attr("data-contract-id");
                                    var used = parseFloat(0).toFixed(2);
                                    var camount;
                                    if (val != '') {
                                        used = val.replace(/[^0-9\.]+/g, "");
                                        used = parseFloat(used).toFixed(2);
                                    }
                                    $(this).val(addCommas(used));
                                    for (var a = 0, b = record.fxcontracts.length; a < b; a++) {
                                        if (record.fxcontracts[a].id == cid) {
                                            record.fxcontracts[a].used = used;
                                            camount = parseFloat(record.fxcontracts[a].amount);
                                            break;
                                        }
                                    }
                                    if ( used <= camount ) {
                                        if ( $(this).closest("div.data-table-cell").hasClass("error") ) {
                                             $(this).closest("div.data-table-cell").removeClass("error");
                                             $(this).prev("i").remove();
                                        }
                                    }
                                    renderContractAmountsUI();
                                }).on('focus', function(){
                                    if ( $(this).val() == "0.00" ) {
                                        $(this).val('');
                                    }
                                }).on('blur', function(){
                                    if ( $(this).val() == "" ) {
                                        $(this).val('0.00');
                                    }
                            });
                        }
                        $row.appendTo($("#fxContractList"));
                    }
                    if (record.fxcontracts.length == 5 && !record.cardedrateflag) {
                        $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
                        $("#cardedRateFlagLabel").addClass("disabled");
                    }
                    if (record.cardedrateflag) {
                        $("#cardedRateFlag").attr("disabled", false).prop("checked", true);
                    }
                    renderContractAmountsUI();
                }
            }
            if (record.debitaccountcountry == "China") {
                renderAdditionalInformationSection().appendTo($paymentDataEntry);
            }
            attachReviewAndSubmitButton().appendTo($paymentDataEntry);
        } else {
            if (record.type == "Domestic Payment") {
                renderPaymentMethodSection();
            }
            renderPaymentDetailsSection(true);
            renderBeneficiarySection();
            if (record.debitaccountcurrency != record.paymentcurrency && !record.individualdebitsflag) {
                renderFXSection().insertAfter($("#beneficiarySection"));
                $("#fxratetype").val(record.fxratetype);
                if (record.fxratetype == "Carded") {
                    returnCardedRate();
                } else {
                    $("#cardedRateRow").hide();
                    $("#fxContractButton, #fxContractSection").show();  
                    for (var i = 0, l = record.fxcontracts.length; i < l; i++) {
                        var contract = record.fxcontracts[i];
                        if (contract.id == "cardedRateEntry") {
                            var $row = $("<div class='data-table-row' data-contract-row='true' id='usedCardedRateInContractsRow' />");  
                        } else {
                            var $row = $("<div class='data-table-row' data-contract-row='true' id='" + contract.id + "' />");                           
                        }
                        var $referencecell = $("<div class='data-table-cell' style='width: 25%;' data-type='reference' />").appendTo($row);
                        var $removebutton = $("<a href='javascript:void(0)' data-contract-id='" + contract.id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
                            e.preventDefault();
                            $(this).closest("div.data-table-row").remove();
                            var _cid = $(this).attr("data-contract-id");
                            if (_cid == "cardedRateEntry") {
                                $("#cardedRateFlag").prop("checked", false);
                                record.cardedrateflag = false;
                            }
                            record.fxcontracts = _.without(record.fxcontracts, _.findWhere(record.fxcontracts, {
                                id: _cid
                            }));
                            renderContractAmountsUI();
                        });
                        var $reference = $("<span>" + contract.number + "</span>").appendTo($referencecell);
                        var $fxidcell = $("<div class='data-table-cell' style='width: 20%;' data-type='fxid' />").appendTo($row);
                        var $fxiddata = $("<span>" + contract.fxid + "</span>").appendTo($fxidcell);
                        var $amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='amount'  />").appendTo($row);
                        if (contract.id == "cardedRateEntry") {
                            var $amountdata = $("<span>" + addCommas(contract.amount) + "</span>").appendTo($amountcell);
                        } else {
                            var $amountdata = $("<span>$" + addCommas(contract.amount) + "</span>").appendTo($amountcell);                           
                        }
                        var $ratecell = $("<div class='data-table-cell' style='width: 15%; text-align: right;' />").appendTo($row);
                        var $rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell);
                        var $usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='used' >").appendTo($row);
                        if (contract.id == "cardedRateEntry") {
                            var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0; border: 0;' disabled='disabled' data-contract-id='cardedRateEntry' id='cardedRateEntry' value='" + addCommas(contract.used) + "' />").appendTo($usedamountcell);
                        } else {
                            var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + contract.id + "' value='" + addCommas(contract.used) + "' />").appendTo($usedamountcell).on("keydown", preventAlphaKeys).on("change", function() {
                                    var val = $(this).val();
                                    var cid = $(this).attr("data-contract-id");
                                    var used = parseFloat(0).toFixed(2);
                                    var camount;
                                    if (val != '') {
                                        used = val.replace(/[^0-9\.]+/g, "");
                                        used = parseFloat(used).toFixed(2);
                                    }
                                    $(this).val(addCommas(used));
                                    for (var a = 0, b = record.fxcontracts.length; a < b; a++) {
                                        if (record.fxcontracts[a].id == cid) {
                                            record.fxcontracts[a].used = used;
                                            camount = parseFloat(record.fxcontracts[a].amount);
                                            break;
                                        }
                                    }
                                    if ( used <= camount ) {
                                        if ( $(this).closest("div.data-table-cell").hasClass("error") ) {
                                             $(this).closest("div.data-table-cell").removeClass("error");
                                             $(this).prev("i").remove();
                                        }
                                    }
                                    renderContractAmountsUI();
                                }).on('focus', function(){
                                    if ( $(this).val() == "0.00" ) {
                                        $(this).val('');
                                    }
                                }).on('blur', function(){
                                    if ( $(this).val() == "" ) {
                                        $(this).val('0.00');
                                    }
                            });
                        }
                        $row.appendTo($("#fxContractList"));
                    }
                    if (record.fxcontracts.length == 5 && !record.cardedrateflag) {
                        $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
                        $("#cardedRateFlagLabel").addClass("disabled");
                    }
                    if (record.cardedrateflag) {
                        $("#cardedRateFlag").attr("disabled", false).prop("checked", true);
                    }
                    updateBatchTotals();
                }
            }
            attachReviewAndSubmitButton().appendTo($paymentDataEntry);
        }
        $paymentDataEntry.show();
        $shell.removeClass("loading");     
    }, 500);
}

function renderReviewPaymentScreen() {
    $("#paymentEntryForm").scrollTop(0);
    updatePaymentCreationSteps(2);
    /* attachPreviousAndSubmitButtons(); */
    $paymentDataEntry.hide().empty();
    $paymentReviewScreen.show();
    renderReviewPaymentHeader().appendTo($paymentReviewScreen);
    renderReviewPaymentDebitAccount().appendTo($paymentReviewScreen);
    if (record.type == "Domestic Payment" || record.type == "International Payment") {
        renderReviewPaymentBeneficiaries();
        if (record.type == "Domestic Payment") {
            renderReviewPaymentMethod().appendTo($paymentReviewScreen);
        }
        renderReviewPaymentDetails().appendTo($paymentReviewScreen);
        if (record.debitaccountcurrency != record.paymentcurrency && !record.individualdebitsflag) {
            renderReviewFXDetails().appendTo($paymentReviewScreen);
            if (record.fxratetype == "Carded") {
                returnCardedRate();
            }
        }
    } else if (record.type == "Account Transfer") {
        renderReviewTransferCreditAccount().appendTo($paymentReviewScreen);
        renderReviewAccountTransferDetails().appendTo($paymentReviewScreen);
        if (record.debitaccountcurrency != record.paymentcurrency) {
            renderReviewFXDetails().appendTo($paymentReviewScreen);
            if (record.fxratetype == "Carded") {
                returnCardedRate();
            }
        }
        renderReviewRemitDetailSection().appendTo($paymentReviewScreen);
        renderReviewSupportingDocumentSection().appendTo($paymentReviewScreen);
        if (record.debitaccountcountry == "China") {
            renderReviewAdditionalFields().appendTo($paymentReviewScreen);
        }
    }
    attachPreviousAndSubmitButtons().appendTo($paymentReviewScreen);
}

function renderReviewPaymentHeader() {
    var $sectionRow = $("<div class='grid-row' style='margin-bottom: 0;' />");
    var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
    var $box = $("<div class='box' />").appendTo($sectionCell);
    var $boxContent = $("<div class='box-content top-label transparent' />").appendTo($box);
    var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'><span style='font-size: 24px; display: inline-block; margin: 10px 0; color: #484848;'>Review Payment</span></div>").appendTo($dataCol);
    var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
    var $data = $("<div class='data-text'><span><strong>Payment ID:</strong> " + record.id + "</span></div>").appendTo($dataGroup);
    var $data = $("<div class='data-text'><strong>Value Date:</strong> " + record.valuedate + " - <strong>Cut off Time: </strong>16:00 AEST</div>").appendTo($dataGroup);
    var $detailCell = $("<div class='grid-cell' style='width: 50%; text-align: right;' />").appendTo($detailRow);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'><span><strong>Payment Amount</strong> <span style='display: block; font-size: 24px; color: #007dba; margin: 5px 0 -5px 0;'>"+ record.paymentcurrency +" $" + addCommas(parseFloat(record.paymentamount).toFixed(2)) + "</span></span></div>").appendTo($dataCol);
    return $sectionRow;
}

function renderReviewPaymentDebitAccount() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>From</div>").appendTo($box);
    var $boxContent = $("<div class='box-content' />").appendTo($box);
    var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'><strong>"+record.division+"</strong></div>").appendTo($dataCol);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column full' />").appendTo($dataRow);
    var $selectionComponentDiv = $("<div class='selection-display' />").appendTo($dataCol);
    var $selectionDetail = $("<div class='selection-display-detail' />").appendTo($selectionComponentDiv);
    var $selectionContent = $("<div class='selection-content' />").appendTo($selectionDetail);
    var $selectionContentLeft = $("<div class='selection-content-left' />").appendTo($selectionContent);
    var $selectionAccountCurrency = $("<div class='selected-account-currency'>"+record.debitaccountcurrency+"</div>").appendTo($selectionContentLeft);
    var $selectionAccountName = $("<div class='selected-account-name'>"+record.debitaccountname+"</div>").appendTo($selectionContentLeft);
    var $selectionAccountNumber = $("<div class='selected-account-number'>"+record.debitaccountnumber+"</div>").appendTo($selectionContentLeft);
    var $selectionContentRight = $("<div class='selection-content-right' />").appendTo($selectionContent);
    var $selectionAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectionContentRight);
    var $selectionAccountBalanceLabel = $("<div>Available Balance</div>").appendTo($selectionAccountBalance);
    var $selectionAccountBalanceValue = $("<div>"+addCommas(selectedDebitAccount.available)+"</div>").appendTo($selectionAccountBalance);
    var $selectionAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectionContentRight);
    var _amountFieldLabel = (record.type == "Account Transfer") ? "Current Balance" : "Available Funds";
    var $selectionAccountFundsLabel = $("<div>"+_amountFieldLabel+"</div>").appendTo($selectionAccountFunds);
    var $selectionAccountFundsValue = $("<div>"+addCommas(selectedDebitAccount.availablefunds)+"</div>").appendTo($selectionAccountFunds);
    var $selectionAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectionContentRight);
    var $selectionAccountDetailAnchor = $("<a href='#accountdetail' title='View Account Details' id='viewDebitAccountDetails'><i class='fa fa-file-text fa-fw'></i></a>").appendTo($selectionAccountDetail).on("click", renderAccountDetailDialog);
    var $arrowDiv = $("<div style='padding-top: 15px; margin-bottom: -25px; text-align: center; font-size: 40px; color: #007dba;' />").appendTo($sectionCell);
    var $arrowIcon = $("<i class='fa fa-angle-double-down fa-fw'></i>").appendTo($arrowDiv);
    return $sectionRow;
}

function renderReviewPaymentBeneficiaries() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Beneficiary Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label transparent no-row-padding' />").appendTo($box);
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $paymentControlBarDiv = $("<div style='padding: 0 0 10px 0;' />").appendTo($dataCol);

    var $filterButton = $("<span class='btn'>").appendTo($paymentControlBarDiv);
    var $filterAnchor = $("<a href='javascript:void(0)' title='Filter beneficiary instructions'><i class='fa fa-filter fa-fw text-right'></i><span>Filter</span></a>").appendTo($filterButton).on("click", toggleGridFilterRow).on("focus blur", function(e) {
        $(this).parent().toggleClass("focused", e.type === "focus")
    });

    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $beneficiaryGrid = $("<div class='payment-grid' id='beneficiaryGrid' />").appendTo($dataCol);
    var $totals = $("<div class='bottom-controls' />").appendTo($dataCol);
    var $table = $("<div class='bottom-control-table' />").appendTo($totals);
    var $list = $("<div class='control-list' style='width: 100%;' />").appendTo($table);
    var $list = $("<div class='control-list' />").appendTo($table);
    var $div = $("<div style='display: inline-block;' id='batchTotal' />").appendTo($list);

    /* ATTACH SECTION */
    $sectionRow.appendTo($paymentReviewScreen);

    /* RENDER BATCH TOTALS */
    renderBatchTotalsUI();

    /* RENDER BENEFICIARY GRID */
    renderReviewBeneficiaryGrid();
}

function renderReviewBeneficiaryGrid() {

    data = record.instructions;
    selectedRowIds = [];
    options = {
        editable: true,
        enableAddRow: false,
        enableCellNavigation: true,
        enableColumnReorder: false,
        enableColumnResize: true,
        syncColumnCellResize: false,
        autoHeight: false,
        forceFitColumns: true,
        multiSelect: false,
        multiColumnSort: true,
        explicitInitialization: true,
        showHeaderRow: true,
        headerRowHeight: 40
    };
    columns = [{
        id: "number",
        name: "#",
        field: "number",
        tooltip: "Item Number",
        width: 40,
        sortable: true,
        visible: true,
        sorter: "sorterStringCompare",
        resizable: true,
        focusable: false,
        maxWidth: 75,
        minWidth: 40
    }, {
        id: "validated",
        name: "<i class='fa fa-check-circle fa-fw' style='color: #4d5d69;'></i>",
        field: "validated",
        toolTip: "Validation",
        width: 50,
        headerCssClass: "centered",
        cssClass: "centered",
        sortable: false,
        visible: true,
        resizable: false,
        focusable: true,
        formatter: Slick.Formatters.ValidatedIconFormatter
    }, {
        id: "beneficiaryname",
        name: "Beneficiary",
        field: "beneficiaryname",
        toolTip: "Beneficiary Name",
        width: 200,
        sortable: true,
        visible: true,
        resizable: true,
        sorter: "sorterStringCompare"
    }, {
        id: "beneficiaryaccountnumber",
        name: "Account",
        field: "beneficiaryaccountnumber",
        toolTip: "Beneficiary Account",
        width: 175,
        sortable: true,
        visible: true,
        resizable: true,
        focusable: false,
        sorter: "sorterStringCompare"
    }, {
        id: "paymentreference",
        name: "Reference",
        field: "paymentreference",
        toolTip: "Reference",
        width: 150,
        sortable: true,
        visible: true,
        resizable: true,
        sorter: "sorterStringCompare"
    }, {
        id: "amount",
        name: "Amount",
        field: "amount",
        toolTip: "Amount",
        headerCssClass: "righted",
        cssClass: "righted",
        sorter: "sorterNumeric",
        width: 125,
        sortable: true,
        visible: true,
        resizable: true,
        formatter: CurrencyAndAmountFormatter
    }];

    if (record.debitaccountcountry == "China" && record.type == "Domestic Payment") {
        var methodColumn = {
            id: "paymentmethod",
            name: "Method",
            field: "paymentmethod",
            toolTip: "Method",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare"
        }
        columns.splice(5, 0, methodColumn)
    }

    if (record.paymentmethod == "Osko") {

        columns.splice(4, 1)

        var endToEndColumn = {
            id: "endtoendid",
            name: "End-to-End ID",
            field: "endtoendid",
            toolTip: "End-to-End ID",
            width: 150,
            sortable: true,
            visible: true,
            resizable: true,
            sorter: "sorterStringCompare"
        }
        columns.splice(4, 0, endToEndColumn)

        var emailColumn = {
            id: "emailadviceflag",
            name: "<i class='fa fa-envelope fa-fw' style='color: #4d5d69;'></i>",
            field: "emailadviceflag",
            toolTip: "Email Address",
            width: 60,
            maxWidth: 60,
            minWidth: 60,
            headerCssClass: "centered",
            cssClass: "centered",
            sortable: false,
            visible: true,
            resizable: false,
            formatter: disabledCheckboxFormatter
        }
        columns.splice(6, 0, emailColumn)
    }

    function CurrencyAndAmountFormatter(row, cell, value, columnDev, dataContext) {
        if (record.debitcurrencyflag) {
            return dataContext.debitcurrency + " $" + addCommas(parseFloat(dataContext.debitequivalentamount).toFixed(2));
        } else {
            return dataContext.paymentcurrency + " $" + addCommas(parseFloat(dataContext.paymentamount).toFixed(2));
        }
    }

    function disabledCheckboxFormatter(row, cell, value, columnDev, dataContext) {
        return value ? "<input type=checkbox value='"+value+"' class='editor-checkbox' checked='checked' disabled='disabled' />" : "<input type=checkbox value='"+value+"' class='editor-checkbox' disabled='disabled' />";
    }

    var itemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
    dataView = new Slick.Data.DataView({
        itemMetaProvider: itemMetaProvider
    });
    grid = new Slick.Grid("#beneficiaryGrid", dataView, columns, options);
    grid.setSelectionModel(new Slick.RowSelectionModel({
        selectActiveRow: false
    }));
    grid.registerPlugin(itemMetaProvider);
    grid.onSelectedRowsChanged.subscribe(function(e) {
        selectedRowIds = [];
        var rows = grid.getSelectedRows();
        for (var i = 0, l = rows.length; i < l; i++) {
            var item = dataView.getItem(rows[i])
            if (item.id) {
                selectedRowIds.push(item.id);
            }
        }
    });
    grid.onClick.subscribe(function(e, args) {
        var cell = grid.getCellFromEvent(e);
        var row = cell.row;
        var $row = $(e.target).closest(".slick-row");
        instruction = dataView.getItem(row);
        renderReviewInstructionDialog($(e.target), instruction);
    });
    grid.onSort.subscribe(function(e, args) {
        var cols = args.sortCols;
        dataView.sort(function(dataRow1, dataRow2) {
            for (var i = 0, l = cols.length; i < l; i++) {
                sortdir = cols[i].sortAsc ? 1 : -1;
                sortcol = cols[i].sortCol.field;
                var _sorter = cols[i].sortCol.sorter,
                    result;
                if (_sorter == "sorterStringCompare") {
                    result = sorterStringCompare(dataRow1, dataRow2);
                } else if (_sorter == "sorterNumeric") {
                    result = sorterNumeric(dataRow1, dataRow2);
                } else if (_sorter == "sorterDateIso") {
                    result = sorterDateIso(dataRow1, dataRow2);
                } else if (_sorter == "sorterTime") {
                    result = sorterTime(dataRow1, dataRow2);
                }
                if (result != 0) {
                    return result;
                }
            }
            return 0;
        });
        args.grid.invalidateAllRows();
        args.grid.render();
    });
    $(grid.getHeaderRow()).delegate(":input", "change keyup", function(e) {
        var columnId = $(this).data("columnId");
        var $icon = $(this).next("i");
        if (columnId != null) {
            columnFilters[columnId] = $.trim($(this).val());
            $icon.show();
            dataView.refresh();
            if (!$(this).val()) {
                $icon.hide();
            }
        }
    });
    grid.onHeaderRowCellRendered.subscribe(function(e, args) {
        if (args.column.id == "_checkbox_selector" || args.column.id == "_flag_column" || args.column.id == "email" || args.column.id == "validated" || args.column.id == "id") {
            return false;
        } else {
            $(args.node).empty().addClass(args.column.headerCssClass);
            var $input = $("<input type='text'>").data("columnId", args.column.id).val(columnFilters[args.column.id]).appendTo(args.node);
            var $icon = $("<i class='slick-clear-filter fa fa-times-circle fa-fw ' title='Clear Filter' style='display: none;'></i>").appendTo(args.node).on("click", function(e) {
                e.preventDefault();
                $(this).prev("input[type='text']").val("").trigger("change");
                $(this).hide();
            });
            if ($input.val()) {
                $icon.show();
            }
        }
    });
    dataView.onRowCountChanged.subscribe(function(e, args) {
        grid.updateRowCount();
        grid.render();
    });
    dataView.onRowsChanged.subscribe(function(e, args) {
        grid.invalidateRows(args.rows);
        grid.render();
        if (selectedRowIds.length > 0) {
            var selRows = [];
            for (var i = 0; i < selectedRowIds.length; i++) {
                var idx = dataView.getRowById(selectedRowIds[i]);
                if (idx != undefined)
                    selRows.push(idx);
            }
            grid.setSelectedRows(selRows);
        }
    });
    dataView.beginUpdate();
    dataView.setItems(data);
    dataView.setFilter(gridFilter);
    dataView.syncGridSelection(grid, true, false);
    dataView.syncGridCellCssStyles(grid, "contextMenu");
    dataView.endUpdate();
    grid.setColumns(columns);

    $(window).on("resize.grid", function() {
        grid.resizeCanvas();
    });
    $(window).on("resize.grid", _.debounce(function(e) {
        grid.resizeCanvas();
    }, 100));
    setTimeout(function(){
        grid.init();
        grid.setHeaderRowVisibility(false);
    }, 1);
}

function renderReviewPaymentMethod() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Payment Method</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $dataRow = $("<div class='row' />").appendTo($boxContent);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    if (selectedDebitAccount.country == "China") {
        var $data = $("<div class='data-text'>For domestic payments in China the payment method is selected along with the beneficiary account.</div>").appendTo($dataCol);
    } else if ( selectedDebitAccount.country == "Australia") {
        var $data = $("<div class='data-text'>"+record.paymentmethod+"</div>").appendTo($dataCol);
       // var $icon = $("<i class='fa fa-info-circle fa-fw' style='color: #484848; margin-left: 5px;'></i>").appendTo($data);
        if (record.paymentmethod == "RTGS") {
        //  $icon.attr("title", "A high value domestic funds payment that will be settled the same day. Note that fees apply.");
        } else if (record.paymentmethod == "Direct Entry") {
        // $icon.attr("title", "A payment from a single funding account to one or more beneficiary domestic accounts.");
        } else if (record.paymentmethod == "Osko") {
        // $icon.attr("title", "A real time payment that will be in the beneficiary&lsquo;s account alomst immediately providing the beneficiary&lsquo;s bank account supports Osko. Note that fees may apply.");
        }
    }
    return $sectionRow;
}

function renderReviewPaymentDetails() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);


    /* ROW */
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);

    /* LEFT CELL */
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);

    /* Value Date */
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Value Date</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'>"+record.valuedate+"</div>").appendTo($dataCol);
    if ( record.valuedate == smartDates("today") ) {
        var $cutOffTime = $("<div class='data-text'>Cut-off Time: 23:59 AEST</div>").appendTo($dataCol);
    }


     /* ROW */
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);

    /* LEFT CELL */
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);

    /* Payment Name */
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Payment Name</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'>"+record.paymentname+"</div>").appendTo($dataCol);

    /* Payment Reference */
    if ( record.type == "International Payment" || record.paymentmethod == "RTGS" || record.paymentmethod == "Direct Entry" || record.debitaccountcountry == "China") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.paymentreference+"</div>").appendTo($dataCol);
    }    

    /* End to End ID */
    if (record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>End-to-End ID</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.endtoendid+"</div>").appendTo($dataCol);
    }

    /* PAYMENT CURRENCY */
    if (record.debitaccountcountry == "China" || record.type == "International Payment") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Currency</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.paymentcurrency+"</div>").appendTo($dataCol);
    }

    /* DEBIT CURRENCY FLAG */
    if ((record.debitaccountcountry == "China" || record.type == "International Payment") && (record.debitaccountcurrency != record.paymentcurrency)) {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='checkbox' id='debitcurrencyflag' disabled='disabled' />").appendTo($dataCol).prop("checked", record.debitcurrencyflag);
        var $labelDesc = $("<label class='desc'>Enter Amounts in Debit Currency</label>").appendTo($dataCol);
    }


    /* INDIVIDUAL DEBITS & URGENT */
    if (record.debitaccountcountry == "China" || record.type == "International Payment" || record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='checkbox' id='individualdebitsflag' disabled='disabled' />").appendTo($dataCol).prop("checked", record.individualdebitsflag);
        var $labelDesc = $("<label class='desc'>Individual Debits</label>").appendTo($dataCol);
        if (record.debitaccountcountry == "China" && record.type == "Domestic Payment") {
            var $data = $("<input type='checkbox' id='urgentflag' disabled='disabled' />").appendTo($dataCol).prop("checked", record.urgentflag);
            var $labelDesc = $("<label class='desc'>Urgent</label>").appendTo($dataCol);
        }
    }

    /* Osko DAILY LIMIT */
    if (record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-note'>Daily Osko Limit: <strong>$5,000.00</strong></div>").appendTo($dataCol);
    }

    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);


    if (record.paymentmethod == "Direct Entry" || record.paymentmethod == "Osko") {
        var $dataRow = $("<div class='row ' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Statement Narrative</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.statementnarrative+"</div>").appendTo($dataCol);
    }

    if (record.paymentmethod == "Direct Entry") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Direct Entry User ID</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.directentryid+"</div>").appendTo($dataCol);
    }

    if (record.debitaccountcountry == "China" || record.type == "International Payment" || record.paymentmethod == "Osko") {
        if (!record.individualdebitsflag) {
            var $dataRow = $("<div class='row' />").appendTo($boxCell);
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $data = $("<textarea style='width: 80%; height: 80px;' readonly='readonly' disabled='disabled' class='disabled'>"+record.debitadviceinformation+"</textarea>").appendTo($dataCol);
        }
    }

    return $sectionRow;
}

function renderReviewFXDetails() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' />").appendTo($boxRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Rate Type</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<div class='data-text'>"+record.fxratetype+"</div>").appendTo($dataCol);
    if (record.fxratetype == "Carded") {
        var $boxCell = $("<div class='grid-cell' />").appendTo($boxRow);
        var $row = $("<div class='row' id='cardedRateRow' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($row);
        var $label = $("<label>Rate</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $data = $("<div class='data-text' id='cardedRate' />").appendTo($dataCol);
    } else {
        var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
        var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
        var $row = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column full' />").appendTo($row);
        var $dataTable = $("<div class='data-table' id='fxContractList' />").appendTo($dataCol);
        var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
        var $dataTableCell = $("<div class='data-table-cell' style='width: 25%;'>Contract ID</div>").appendTo($dataTableRow);
        var $dataTableCell = $("<div class='data-table-cell' style='width: 20%;'>Client FX ID</div>").appendTo($dataTableRow);
        var $dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Available Amount</div>").appendTo($dataTableRow);
        var $dataTableCell = $("<div class='data-table-cell' style='width: 15%; text-align: right;'>FX Rate</div>").appendTo($dataTableRow);
        var $dataTableCell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>Utilized Amount</div>").appendTo($dataTableRow);
    }
    for (var i = 0, l = record.fxcontracts.length; i < l; i++) {
        var contract = record.fxcontracts[i];
        var $row = $("<div class='data-table-row' data-contract-row='true' />");  
        var $referencecell = $("<div class='data-table-cell' style='width: 25%;' data-type='reference' />").appendTo($row);
        var $reference = $("<span>" + contract.number + "</span>").appendTo($referencecell);
        var $fxidcell = $("<div class='data-table-cell' style='width: 20%;' data-type='fxid' />").appendTo($row);
        var $fxiddata = $("<span>" + contract.fxid + "</span>").appendTo($fxidcell);
        var $amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='amount'  />").appendTo($row);
        if (contract.id == "cardedRateEntry") {
            var $amountdata = $("<span>" + addCommas(contract.amount) + "</span>").appendTo($amountcell);
        } else {
            var $amountdata = $("<span>$" + addCommas(contract.amount) + "</span>").appendTo($amountcell);                           
        }
        var $ratecell = $("<div class='data-table-cell' style='width: 15%; text-align: right;' />").appendTo($row);
        var $rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell);
        var $usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='used' >").appendTo($row);
        var $used = $("<span>" + contract.used +"</span>").appendTo($usedamountcell);
        $row.appendTo($dataTable);
    }
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $dataCol = $("<div class='data-column full' />").appendTo($row);
    var $data = $("<div class='data-note'>* FX carded rate is indicative only and subject to change at any time without notice.</div>").appendTo($dataCol);
    return $sectionRow;
}

function renderReviewTransferCreditAccount() {
    var $sectionRow = $("<div class='grid-row' style='margin-top: -20px;' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>To</div>").appendTo($box);
    var $boxContent = $("<div class='box-content' />").appendTo($box);
    var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'><strong>"+record.division+"</strong></div>").appendTo($dataCol);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column full' />").appendTo($dataRow);
    var $selectionComponentDiv = $("<div class='selection-display' />").appendTo($dataCol);
    var $selectionDetail = $("<div class='selection-display-detail' />").appendTo($selectionComponentDiv);
    var $selectionContent = $("<div class='selection-content' />").appendTo($selectionDetail);
    var $selectionContentLeft = $("<div class='selection-content-left' />").appendTo($selectionContent);
    var $selectionAccountCurrency = $("<div class='selected-account-currency'>"+record.creditaccountcurrency+"</div>").appendTo($selectionContentLeft);
    var $selectionAccountName = $("<div class='selected-account-name'>"+record.creditaccountname+"</div>").appendTo($selectionContentLeft);
    var $selectionAccountNumber = $("<div class='selected-account-number'>"+record.creditaccountnumber+"</div>").appendTo($selectionContentLeft);
    var $selectionContentRight = $("<div class='selection-content-right' />").appendTo($selectionContent);
    var $selectionAccountBalance = $("<div class='selected-account-balance' />").appendTo($selectionContentRight);
    var $selectionAccountBalanceLabel = $("<div>Available Balance</div>").appendTo($selectionAccountBalance);
    var $selectionAccountBalanceValue = $("<div>"+addCommas(selectedCreditAccount.available)+"</div>").appendTo($selectionAccountBalance);
    var $selectionAccountFunds = $("<div class='selected-account-funds' />").appendTo($selectionContentRight);
    var _amountFieldLabel = (record.type == "Account Transfer") ? "Current Balance" : "Available Funds";
    var $selectionAccountFundsLabel = $("<div>"+_amountFieldLabel+"</div>").appendTo($selectionAccountFunds);
    var $selectionAccountFundsValue = $("<div>"+addCommas(selectedCreditAccount.availablefunds)+"</div>").appendTo($selectionAccountFunds);
    var $selectionAccountDetail = $("<div class='selected-account-detail' />").appendTo($selectionContentRight);
    var $selectionAccountDetailAnchor = $("<a href='#accountdetail' title='View Account Details' id='viewCreditAccountDetails'><i class='fa fa-file-text fa-fw'></i></a>").appendTo($selectionAccountDetail).on("click", renderAccountDetailDialog);
    return $sectionRow;
}

function renderReviewAccountTransferDetails() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($sectionRow);
    var $box = $("<div class='box'/>").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Payment Details&nbsp;</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Value Date</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'>"+record.valuedate+"</div>").appendTo($dataCol);
    var $cutoffTime = $("<div class='data-text'>Cut-off Time: 16:00 AEST</div>").appendTo($dataCol);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);
    if (record.debitaccountcurrency != record.creditaccountcurrency) {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $innerRow = $("<div class='grid-row' />").appendTo($dataCol);
        var $innerCell = $("<div class='grid-cell' style='width: auto; margin-right: 50px;' />").appendTo($innerRow);
        var $dataRow = $("<div class='row' style='padding: 0;' />").appendTo($innerCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.paymentcurrency+" $"+addCommas(record.paymentamount)+"</div>").appendTo($dataCol);
        var $innerCell = $("<div class='grid-cell' style='width: auto;' />").appendTo($innerRow);
        var $dataRow = $("<div class='row' style='padding: 0;' />").appendTo($innerCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.debitaccountcurrency+" $"+addCommas(record.debitequivalentamount)+"</div>").appendTo($dataCol);
        var $dataRow = $("<div class='row' style='padding-top: 5px; margin-bottom: -15px;' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='checkbox' id='debitcurrencyflag' disabled='disabled' />").appendTo($dataCol);
        if ( record.debitcurrencyflag ) {
            $data.prop("checked", true);
        }
        var $labelDesc = $("<label class='desc'>Enter Amount in Debit Currency</label>").appendTo($dataCol);
    } else {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<div class='data-text'>"+record.paymentcurrency+" $"+addCommas(record.paymentamount)+"</div>").appendTo($dataCol);
    }
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'>"+record.paymentreference+"</div>").appendTo($dataCol);
    var $boxCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Debit Statement Narrative</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'>"+record.debitstatementnarrative+"</div>").appendTo($dataCol);
    var $dataRow = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
    var $label = $("<label>Credit Statement Narrative</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    var $data = $("<div class='data-text'>"+record.creditstatementnarrative+"</div>").appendTo($dataCol);

    return $sectionRow;
}

function renderReviewSupportingDocumentSection() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
    var $box = $("<div class='box' />").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label transparent' />").appendTo($box);
    var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
    var $dataRow = $("<div class='row' />").appendTo($detailCell);
    var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
    if (record.type == "Account Transfer") {
        if ( record.docs.length ) {
            var $dataTable = $("<div class='data-table' />").appendTo($dataCol);
            var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
            var $dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);
            for (var i = 0, l = record.docs.length; i < l; i++) {
                _doc = record.docs[i];
                var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
                var $dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
            }
        } else {
            $boxContent.removeClass("transparent");
            var $data = $("<div class='data-text'>No Spporting Documents Attached</div>").appendTo($dataCol);
        }
    } else {
        if ( instruction.docs.length ) {
            var $dataTable = $("<div class='data-table' />").appendTo($dataCol);
            var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
            var $dataTableCell = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($dataTableRow);
            for (var i = 0, l = instruction.docs.length; i < l; i++) {
                _doc = instruction.docs[i];
                var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
                var $dataTableCell = $("<div class='data-table-cell'><a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a></div>").appendTo($dataTableRow);
            }
        } else {
            $boxContent.removeClass("transparent");
            var $data = $("<div class='data-text'>No Spporting Documents Attached</div>").appendTo($dataCol);
        }
    }
    return $sectionRow;
}

function renderReviewRemitDetailSection() {
    var $sectionRow = $("<div class='grid-row' />");
    var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
    var $box = $("<div class='box' />").appendTo($sectionCell);
    var $boxHeader = $("<div class='box-header'>Remittance Information</div>").appendTo($box);
    var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
    var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
    var $boxCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxRow);
    var item = ( record.type == "Account Transfer" ) ? record : instruction;
    if (record.type == "Account Transfer") {
        var $dataRow = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<textarea style='width: 80%; height: 80px;' readonly='readonly' disabled='disabled'>"+item.debitadviceinformation+"</textarea>").appendTo($dataCol);
    } else {
        var $row = $("<div class='row' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' style='text-align:left' />").appendTo($row);
        var $label = $("<label>Remittance Information</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $remittanceInformation = $("<textarea style='width: 80%; height: 80px;' readonly='readonly' disabled='disabled'>"+item.remittanceinformation+"</textarea>").appendTo($dataCol);
    }
    var $row = $("<div class='row' />").appendTo($boxCell);
    var $labelCol = $("<div class='label-column' />").appendTo($row);
    var $label = $("<label>Invoice Details</label>").appendTo($labelCol);
    var $dataCol = $("<div class='data-column' />").appendTo($row);
    var $data = $("<textarea id='invoiceDetails' style='width: 80%; height: 175px;' readonly='readonly' disabled='disabled'>"+item.invoiceinformation+"</textarea>").appendTo($row);

    if (record.type != "Account Transfer") {
        var $row = $("<div class='row' />").appendTo($boxCell);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $emailFlag = $("<input type='checkbox' id='emailBeneficiaryFlag' name='emailFlag' readonly='readonly' disabled='disabled' class='disabled' />").appendTo($dataCol);
        if (item.emailadviceflag) {
            $emailFlag.prop("checked", true);
        }
        var $labelDesc = $("<label class='desc' for='emailBeneficiaryFlag'>Email Beneficiary Advice</label>").appendTo($dataCol);
        var $email = $("<input type='text' style='width: 250px;' id='beneEmailField' disabled='disabled' readonly='readonly' class='disabled' value='"+item.beneficiaryemail+"' />").appendTo($dataCol);
    }


    return $sectionRow;
}

function renderReviewAdditionalFields() {
}





/* DIALOGS */

function renderAccountDetailDialog(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    if ( $("#accountInformationDialog").size() > 0 ) {
        return false;
    } else {
        var $target = $(this);
        var title;
        var account;
        if ($target.attr("id") == "viewDebitAccountDetails") {
            title = "Debit";
            account = selectedDebitAccount;
        } else if ($target.attr("id") == "viewCreditAccountDetails") {
            title = "Credit";
            account = selectedCreditAccount
        }
        function renderAccountDetails() {
            var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />");
            var $box = $("<div class='box' />").appendTo($dialogContent);
            var $boxHeader = $("<div class='box-header'>Account Information</div>").appendTo($box);
            var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
            var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
            var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
            var $dataRow = $("<div class='row' />").appendTo($detailCell);
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Account Name</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $data = $("<div class='data-text'>" + account.name + "</div>").appendTo($dataCol);
            var $dataRow = $("<div class='row' />").appendTo($detailCell);
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Debit Account</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $data = $("<div class='data-text'>" + account.number + " (" + account.ccy + ")</div>").appendTo($dataCol);
            var $dataRow = $("<div class='row' />").appendTo($detailCell);
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Branch Name</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $data = $("<div class='data-text'>" + account.bank + " " + account.branch + "</div>").appendTo($dataCol);
            var $dataRow = $("<div class='row' />").appendTo($detailCell);
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Address</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $inputGroup = $("<div class='input-group' />").appendTo($dataCol);
            var $data = $("<div class='data-text'>" + account.address1 + "</div>").appendTo($inputGroup);
            var $data = $("<div class='data-text'>" + account.address2 + "</div>").appendTo($inputGroup);
            var $data = $("<div class='data-text'>" + account.address3 + "</div>").appendTo($inputGroup);
            var $dataRow = $("<div class='row' />").appendTo($detailCell);
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Country</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $data = $("<div class='data-text'>" + account.country + "</div>").appendTo($dataCol);
            return $dialogContent;
        }
        var origin = $target.closest(".dialog-parent").length > 0 ? $target.closest(".dialog-parent") : $target;
        var dialog = {
            id: "accountInformationDialog",
            title: title + " Account Information",
            size: "large",
            icon: "<i class='fa fa-info-circle'></i>",
            content: function() {
                return renderAccountDetails();
            },
            buttons: [{
                name: "Close",
                icon: "<i class='fa fa-times fa-fw'></i>",
                events: [{
                    event: "click",
                    action: function(e) {
                        e.preventDefault();
                        dialogHider(dialog)
                    }
                }]
            }]
        }
        dialogViewer(origin, dialog, dialogBuilder(dialog));
    }
}

function renderAddBeneficiaryDialog() {

    function saveBeneficiary(_dialog) {
        dialogHider(_dialog);
    }

    function renderAustraliaAdhocBeneficiary(){
        var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewBeneDialog' />");
        var $sectionRow = $("<div class='grid-row' style='margin-bottom: -10px;' />").appendTo($dialogContent),
            $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
            $box = $("<div class='box' />").appendTo($sectionCell),
            $boxContent = $("<div class='box-content transparent no-row-padding' />").appendTo($box);
        var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
            $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
            $box = $("<div class='box' />").appendTo($sectionCell),
            $boxHeader = $("<div class='box-header'>Beneficiary Information</div>").appendTo($box),
            $boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
            $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Beneficiary Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneName' value=''>").appendTo($dataCol),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>BSB</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newbenebsb' value=''>").appendTo($dataCol),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Beneficiary Email</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneEmail' value=''>").appendTo($dataCol),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Account Number</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneAccountNumber' value=''>").appendTo($dataCol);
            return $dialogContent;
    }

    function renderBeneficiaryData() { 

        var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='viewBeneDialog' />");

        var $sectionRow = $("<div class='grid-row' style='margin-bottom: -10px;' />").appendTo($dialogContent),
            $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
            $box = $("<div class='box' />").appendTo($sectionCell),
            $boxContent = $("<div class='box-content transparent no-row-padding' />").appendTo($box),
            $row = $("<div class='row' />").appendTo($boxContent),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='checkbox' id='updateAddressBook' />").appendTo($dataCol),
            $labeldesc = $("<label class='desc' for='updateAddressBook'>Add this beneficiary to the Address Book when the payment is submitted.</label>").appendTo($dataCol);

        var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
            $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
            $box = $("<div class='box' />").appendTo($sectionCell),
            $boxHeader = $("<div class='box-header'>Beneficiary Information</div>").appendTo($box),
            $boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
            $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Beneficiary Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneName' value=''>").appendTo($dataCol),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Beneficiary Local Language Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneLocalLanguageName' value=''>").appendTo($dataCol),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Beneficiary Short Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneNickName' value=''>").appendTo($dataCol),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Account Number</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneAccountNumber' value=''>").appendTo($dataCol),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Account Type</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $customSelect = $("<div class='custom-select' style='width: 80%; max-width: 400px;' />").appendTo($dataCol),
            $data = $("<select style='width: 100%;' id='newBeneAccountType'><option value='Select Account Type'>Select Account Type</option><option value='Resident Corporate'>Resident Corporate</option><option value='Non-Resident Corporate'>Non-Resident Corporate</option><option value='Resident Individual'>Resident Individual</option><option value='Non-Resident Individual'>Non-Resident Individual</option></select>").appendTo($customSelect),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Address</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneAddress1' placeholder='Line 1'value=''>").appendTo($break),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneAddress2' placeholder='Line 2'value=''>").appendTo($break),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneAddress3' placeholder='Line 3'value=''>").appendTo($break),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>City</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneCity' value=''>").appendTo($dataCol),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Country</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $customSelect = $("<div class='custom-select' style='width: 80%; max-width: 400px;' />").appendTo($dataCol),
            $data = $("<select style='width: 100%;' id='newBeneCountry'><option value='Select Country'>Select Country</option><option value='Australia'>Australia</option><option value='China'>China</option><option value='Hong Kong'>Hong Kong</option><option value='New Zealand'>New Zealand</option><option value='Singapore'>Singapore</option></select>").appendTo($customSelect),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>E-mail</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneEmail' value=''>").appendTo($dataCol);

        var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent),
            $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow),
            $box = $("<div class='box' />").appendTo($sectionCell),
            $boxHeader = $("<div class='box-header'>Beneficiary Bank Information</div>").appendTo($box),
            $boxContent = $("<div class='box-content top-label transparent' />").appendTo($box),
            $detailRow = $("<div class='grid-row' />").appendTo($boxContent),
            $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
            $row = $("<div class='row mandatory' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Country</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $customSelect = $("<div class='custom-select' style='width: 80%; max-width: 400px;' />").appendTo($dataCol),
            $data = $("<select style='width: 100%;' id='newBeneBankCountry'><option value='Select Country'>Select Country</option><option value='Australia'>Australia</option><option value='China'>China</option><option value='Hong Kong'>Hong Kong</option><option value='New Zealand'>New Zealand</option><option value='Singapore'>Singapore</option></select>").appendTo($customSelect).on("change", function() {
                if ($(this).val() != "") {
                    if ($(this).closest("div.row").hasClass("error")) {
                        $(this).closest("div.row").removeClass("error").find("div.data-error").remove();
                    }
                    var _country = $(this).val();
                    if (_country == "Australia") {
                        $("#newBeneBankLocalClearingSection").hide();
                        clearFormElements("newBeneBankLocalClearingSection");
                        $("#newBeneSwiftBankNCCCode").empty();
                        var $option = $("<option value='Australia Bank Branch Code'>Australia Bank Branch Code</option>").appendTo($("#newBeneSwiftBankNCCCode"));
                        $("#newBeneBankSwiftClearingSection, #swiftNCCSection").show();
                    } else if (_country == "Singapore") {
                        $("#newBeneBankLocalClearingSection, #swiftNCCSection").hide();
                        clearFormElements("newBeneBankLocalClearingSection");
                        $("#newBeneSwiftBankNCCCode").empty();
                        $("#newBeneBankSwiftClearingSection").show();
                    } else if (_country == "China") {
                        $("#newBeneLocalBankNCCCode").empty().parent().hide();
                        $("#newBeneSwiftBankNCCCode").empty();
                        var $option = $("<option value='China National Clearing Code'>China National Clearing Code</option>").appendTo($("#newBeneSwiftBankNCCCode"));
                        $("#newBeneBankLocalClearingSection, #newBeneBankSwiftClearingSection, #swiftNCCSection").show();
                    } else if (_country == "Hong Kong") {
                        $("#swiftNCCSection").hide();
                        $("#newBeneSwiftBankNCCCode").empty();
                        var $option = $("<option value='China National Clearing Code'>China National Clearing Code</option>").appendTo($("#newBeneLocalBankNCCCode"));
                        $("#newBeneLocalBankNCCCode").parent().show();
                        $("#newBeneBankLocalClearingSection, #newBeneBankSwiftClearingSection").show();
                    } else if (_country == "New Zealand") {
                        $("#newBeneBankLocalClearingSection").hide();
                        clearFormElements("newBeneBankLocalClearingSection");
                        $("#newBeneSwiftBankNCCCode").empty();
                        var $option = $("<option value='New Zealand Bank Branch Code'>New Zealand Bank Branch Code</option>").appendTo($("#newBeneSwiftBankNCCCode"));
                        $("#newBeneBankSwiftClearingSection, #swiftNCCSection").show();
                    }
                } else {
                    $("#newBeneBankLocalClearingSection, #newBeneBankSwiftClearingSection").hide();
                    clearFormElements("newBeneBankLocalClearingSection");
                    clearFormElements("newBeneBankSwiftClearingSection");
                }
            });

        var $sectionDiv = $("<div id='newBeneBankLocalClearingSection' style='display: none;'>").appendTo($boxContent),
            $detailRow = $("<div class='grid-row' />").appendTo($sectionDiv),
            $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $dataCol = $("<div class='data-column full' />").appendTo($row),
            $subheading = $("<div class='row-subheading'>Local Clearing Information</div>").appendTo($dataCol),
            $detailRow = $("<div class='grid-row' />").appendTo($sectionDiv),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Clearing Code</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $break = $("<div class='break' />").appendTo($dataCol),
            $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($break),
            $select = $("<select style='width: 100%;' id='newBeneLocalBankNCCCode'></select>").appendTo($customSelect),
            $break = $("<div class='break' />").appendTo($dataCol),
            $input = $("<input type='text' style='width: 80%;' id='newBeneLocalBankClearingCode' value='' />").appendTo($break),
            $anchor = $("<a href='javascript:void(0)' id='searchSwiftCodeDialog' title='Find a Local Clearing Code' style='color: #017dba;'><i class='fa fa-search fa-fw'></i></a>").appendTo($break),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Bank Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneLocalBankName' value='' />").appendTo($dataCol),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Branch Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneLocalBankBranchName' value='' />").appendTo($dataCol),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Address</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneLocalBankBranchAddress1' value='' />").appendTo($break),
            $labeldesc = $("<label class='desc'>Line 1</label>").appendTo($break),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneLocalBankBranchAddress2' value='' />").appendTo($break),
            $labeldesc = $("<label class='desc'>Line 2</label>").appendTo($break),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneLocalBankBranchAddress3' value='' />").appendTo($break),
            $labeldesc = $("<label class='desc'>Line 3</label>").appendTo($break);
        var $sectionDiv = $("<div id='newBeneBankSwiftClearingSection' style='display: none;'>").appendTo($boxContent),
            $detailRow = $("<div class='grid-row' />").appendTo($sectionDiv),
            $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $dataCol = $("<div class='data-column full' />").appendTo($row),
            $subheading = $("<div class='row-subheading'>SWIFT Clearing Information</div>").appendTo($dataCol),
            $detailRow = $("<div class='grid-row' />").appendTo($sectionDiv),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>SWIFT Code</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%;' id='newBeneSwiftBankClearingCode' value='' />").appendTo($dataCol),
            $anchor = $("<a href='javascript:void(0)' id='searchSwiftCodeDialog' title='Find a SWIFT Code' style='color: #017dba;'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol),
            $row = $("<div class='row' id='swiftNCCSection' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>NCC Code</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $break = $("<div class='break' />").appendTo($dataCol),
            $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($break),
            $select = $("<select style='width: 100%;' id='newBeneSwiftBankNCCCode'></select>").appendTo($customSelect),
            $break = $("<div class='break' />").appendTo($dataCol),
            $input = $("<input type='text' style='width: 80%;' id='newBeneSwiftBankNCCClearingCode' value='' />").appendTo($break),
            $anchor = $("<a href='javascript:void(0)' id='searchSwiftNCCDialog' title='Find an NCC Code' style='color: #017dba;'><i class='fa fa-search fa-fw'></i></a>").appendTo($break),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Bank Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneSwiftBankName' value='' />").appendTo($dataCol),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Branch Name</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneSwiftBankBranchName' value='' />").appendTo($dataCol),
            $detailCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($detailRow),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>Address</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneSwiftBankBranchAddress1' value='' />").appendTo($break),
            $labeldesc = $("<label class='desc'>Line 1</label>").appendTo($break),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneSwiftBankBranchAddress2' value='' />").appendTo($break),
            $labeldesc = $("<label class='desc'>Line 2</label>").appendTo($break),
            $break = $("<div class='break' />").appendTo($dataCol),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneSwiftBankBranchAddress3' value='' />").appendTo($break),
            $labeldesc = $("<label class='desc'>Line 3</label>").appendTo($break),
            $row = $("<div class='row' />").appendTo($detailCell),
            $labelCol = $("<div class='label-column' />").appendTo($row),
            $label = $("<label>City</label>").appendTo($labelCol),
            $dataCol = $("<div class='data-column' />").appendTo($row),
            $data = $("<input type='text' style='width: 80%; max-width: 400px;' id='newBeneSwiftBankBranchCity' value='' />").appendTo($dataCol);
      

        return $dialogContent;
    }

    var _target = $("#addBeneficiaryDialog");
    var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
    var _dialog = {
        id: "editBeneDetails",
        title: "Add New Beneficiary",
        size: "large",
        icon: "<i class='fa fa-book'></i>",
        content: function() {
            return renderBeneficiaryData();
        },
        close: function() {
            console.log("HERE");
            var c = grid.getActiveCell();
            grid.gotoCell(c.row, c.cell, true);
        },
        buttons: [{
            name: "Cancel",
            icon: "<i class='fa fa-times fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    dialogHider(_dialog);
                }
            }]
        }, {
            name: "Ok",
            icon: "<i class='fa fa-check-circle fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    saveBeneficiary(_dialog);
                }
            }],
            cssClass: "primary"
        }]
    }

    if ( record.debitaccountcountry == "Australia" ) {
        _dialog.size = "small";
        _dialog.content = function() {
            return renderAustraliaAdhocBeneficiary();
        }
    }



    dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function renderSearchBeneficiaryDialog() {

    var renderBeneficiarySearch = function() {
        var $dialogContent = $("<div class='py-ui' id='searchBeneficiaryDialogContent' />");

        var $wrapper = $("<div class='wrapper' />").appendTo($dialogContent),
            $searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
            $searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
            $searchInput = $("<input id='SearchBeneficiaryFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Find an beneficiary...' />").on("keyup", function() {
                if (this.value != '') {
                    $("#clearBeneficiaryFilter").show()
                } else {
                    $("#clearBeneficiaryFilter").hide()
                }
            }).appendTo($searchDiv),
            $searchClear = $("<span class='btn search-clear' id='clearBeneficiaryFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
                $("#SearchBeneficiaryFilterInput").val("").trigger("change");
                $(this).hide();
            }).appendTo($searchDiv);

        var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
            $nameHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Beneficiary Name</div>").appendTo($header),
            $numberHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Number</div>").appendTo($header),
            $currencyHeader = $("<div class='dialog-search-header-col' style='width: 160px; border-right: 0;'>Country</div>").appendTo($header);

        var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
            $ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
            $li, $row, $name, $number, $country;
        $.each(availableBeneficiaryAccounts, function() {
            var _bene = this;
            $li = $("<li data-name='" + this.name + "' data-number='" + this.accountnumber + "' data-country='" + this.bankcountry + "' >").appendTo($ul),
                $row = $("<a href='javascript:void(0)' class='dialog-search-row' />").appendTo($li).on("click", function(e) {
                    var $target = $(e.target);
                    if ($target.prop("nodeName") == "DIV") {
                        $target = $target.closest("li");
                    }
                    setSelectedBeneficiaryFromDialog(_bene, _dialog);
                }),
                $name = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.name + "</div>").appendTo($row),
                $number = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.accountnumber + "</div>").appendTo($row),
                $country = $("<div class='dialog-search-data-col' style='width: 160px;'>" + this.bankcountry + "</div>").appendTo($row)
        });
        return $dialogContent;
    }

    var _target = $("#searchBeneficiaryDialog");
    var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
    var _dialog = {
        id: "searchBeneDialog",
        title: "Search Beneficiaries",
        size: "xxl",
        icon: "<i class='fa fa-search'></i>",
        content: function() {
            return renderBeneficiarySearch();
        },
        close: function() {
            if ( $("#editInstructionDialog").size() )  {
                $("#searchBeneficiaryDialog").focus();
            } else {
                var c = grid.getActiveCell();
                grid.gotoCell(c.row, c.cell, true);
            }
        },
    }
    dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

    $("#SearchBeneficiaryFilterInput").fastLiveFilter('.dialog-search-list').focus();

    if (!$(".dialog-search-list").children("li").length) {
        var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #484848; font-size: 14px;'>No records found</div>").appendTo($dataContainer);
    }
}

function renderSearchAccountsDialog() {
    var renderAccountsSearch = function() {
        var $dialogContent = $("<div class='py-ui' id='searchAccountsDialogContent' />");
        var $wrapper = $("<div class='wrapper' />").appendTo($dialogContent),
            $searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
            $searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
            $searchInput = $("<input id='accountFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Find an account...' />").on("keyup", function() {
                if (this.value != '') {
                    $("#clearAccountsFilter").show()
                } else {
                    $("#clearAccountsFilter").hide()
                }
            }).appendTo($searchDiv),
            $searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
                $("#accountFilterInput").val("").trigger("change");
                $(this).hide();
            }).appendTo($searchDiv);
        var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
            $nameHeader = $("<div class='dialog-search-header-col' style='width: 300px;'>Account Name</div>").appendTo($header),
            $numberHeader = $("<div class='dialog-search-header-col' style='width: 300px;'>Account Number</div>").appendTo($header),
            $currencyHeader = $("<div class='dialog-search-header-col' style='width: 150px; border-right: 0;'>Currency</div>").appendTo($header),
            $branchHeader = $("<div class='dialog-search-header-col' style='width: 250px; border-right: 0;'>Branch Name</div>").appendTo($header);
        var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
            $ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
            $li, $row, $name, $number, $currency;
        $.each(_searchArray, function() {
            var _acc = this;
            $li = $("<li data-name='" + this.name + "' data-number='" + this.number + "' data-currency='" + this.ccy + "' >").appendTo($ul);
            $row = $("<a href='javascript:void(0)' class='dialog-search-row' />").appendTo($li);
            if ( _accountType == "debit" ) {
                $row.on("click", function(e) {
                    var $target = $(e.target);
                    if ($target.prop("nodeName") == "DIV") {
                        $target = $target.closest("li");
                    }
                    showSelectedDebitAccount(_acc, _dialog);
                });
            } else if ( _accountType == "trace" ) {
                $row.on("click", function(e) {
                    var $target = $(e.target);
                    if ($target.prop("nodeName") == "DIV") {
                        $target = $target.closest("li");
                    }
                    $("#traceAccount").val(_acc.label)
                    dialogHider(_dialog);
                });
            } else {
                $row.on("click", function(e) {
                    var $target = $(e.target);
                    if ($target.prop("nodeName") == "DIV") {
                        $target = $target.closest("li");
                    }
                    showSelectedCreditAccount(_acc, _dialog);
                });
            }
            $name = $("<div class='dialog-search-data-col' style='width: 300px;'>" + this.name + "</div>").appendTo($row);
            $number = $("<div class='dialog-search-data-col' style='width: 300px;'>" + this.number + "</div>").appendTo($row);
            $currency = $("<div class='dialog-search-data-col' style='width: 150px;'>" + this.ccy + "</div>").appendTo($row);
            $branch = $("<div class='dialog-search-data-col' style='width: 250px;'>" + this.branch + "</div>").appendTo($row);
        });
        return $dialogContent;
    }
    var _target = $(this);
    var _accountType = _target.attr("data-search");
    var _searchArray;
    if ( _accountType == "debit" ) {
        _searchArray = customerAccounts;
    } else if ( _accountType == "trace" ) {
        _searchArray = availableTraceAccounts;
    } else {
        _searchArray = availableCreditAccounts;
    }
    var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
    var _dialog = {
        id: "searchAccountsDialog",
        title: "Search Accounts",
        size: "xxl",
        icon: "<i class='fa fa-search'></i>",
        content: function() {
            return renderAccountsSearch();
        },
        buttons: [{
            name: "Cancel",
            icon: "<i class='fa fa-times fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    dialogHider(_dialog)
                }
            }]
        }]
    }
    dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

    $("#accountFilterInput").fastLiveFilter('.dialog-search-list').focus();

    if (!$(".dialog-search-list").children("li").length) {
        var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #484848; font-size: 14px;'>No records found</div>").appendTo($dataContainer);
    }
}

function renderBatchDefaultsDialog() {
    var $target = $(this);

    function saveBatchDefaults(_dialog) {
        record.traceaccount = $("#traceAccount").val();
        record.remitter = $("#remitterName").val();
        record.transactioncode = $("#transCode").val();
        if ( $("#updateAllInstructions").prop("checked") == true ) {
            for ( var i = 0, l = record.instructions.length; i < l; i++ ) {
                record.instructions[i].traceaccount = record.traceaccount;
                record.instructions[i].transactioncode = record.transactioncode;
                record.instructions[i].remitter = record.remitter;
            }
        }
        dialogHider(_dialog);
    }

    function renderBatchDefaults() {
        var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />");
        var $sectionRow = $("<div class='grid-row' />").appendTo($dialogContent);
        var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
        var $box = $("<div class='box' />").appendTo($sectionCell);
        var $boxContent = $("<div class='box-content top-label transparent' />").appendTo($box);

        var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
        var $boxCell = $("<div class='grid-cell' style='width: 50%' />").appendTo($boxRow);
        var $row = $("<div class='row mandatory' />").appendTo($boxCell);
        var $labelCol = $("<div class='label-column' />").appendTo($row);
        var $label = $("<label>Remitter Name</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $data = $("<input type='text' style='width: 80%;' id='remitterName' value=''>").appendTo($dataCol);

        if (record.paymentmethod == "Direct Entry") {
            var $boxCell = $("<div class='grid-cell' style='width: 50%' />").appendTo($boxRow);
            var $row = $("<div class='row mandatory' id='batchtransactioncode' />").appendTo($boxCell);
            var $labelCol = $("<div class='label-column' />").appendTo($row);
            var $label = $("<label>Transaction Code</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($row);
            var $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol);
            var $data = $("<select id='transCode'><option value=''></option><option value='25'>25 - Half Credit</option><option value='50'>50 - Credit</option><option value='100'>100 - Double Credit</option></select>").appendTo($customSelect);
            var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
            var $boxCell = $("<div class='grid-cell' style='width: 100%' />").appendTo($boxRow);
            var $row = $("<div class='row mandatory' />").appendTo($boxCell);
            var $labelCol = $("<div class='label-column' />").appendTo($row);
            var $label = $("<label>Trace Account</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($row);
            var $comboBox = $("<div class='combobox-div' style='width: 90%;' />").appendTo($dataCol);
            var $comboboxInput = $("<input type='text' value='' id='traceAccount' placeholder='Select An Account' />").appendTo($comboBox);
            var $searchIcon = $("<a href='javascript:void(0)' title='Search Accounts' style='color: #007dba;' data-search='trace'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol).on("click", renderSearchAccountsDialog);
            var $suggestionsDiv = $("<div id='traceAccountSuggestions' />").appendTo($dataCol);          
        }

        var $updateAllInstructionsDiv = $("<div style='position: absolute; bottom: 20px; left: 20px; right: 20px; padding: 20px; background: #f5f5f5; -moz-border-radius: 2px; -webkit-border-radius: 2px; border-radius: 2px;' />").appendTo($dialogContent);
        var $updateAllInstructionsInput = $("<input type='checkbox' id='updateAllInstructions' />").appendTo($updateAllInstructionsDiv);
        var $updateAllInstructionsLabel = $("<label class='desc' for='updateAllInstructions'>Update existing beneficiary payment instructions with these values</label>").appendTo($updateAllInstructionsDiv);

        return $dialogContent;
    }
    var origin = $target.closest(".dialog-parent").length > 0 ? $target.closest(".dialog-parent") : $target;
    var dialog = {
        id: "batchDefaultDialog",
        title: "Batch Defaults",
        size: "wide",
        icon: "<i class='fa fa-cog'></i>",
        content: function() {
            return renderBatchDefaults();
        },
        buttons: [{
            name: "Close",
            icon: "<i class='fa fa-times fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    dialogHider(dialog)
                }
            }]
        }, {
            name: "Ok",
            icon: "<i class='fa fa-check-circle fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    saveBatchDefaults(dialog)
                }
            }],
            cssClass: "primary"
        }]
    }
    dialogViewer(origin, dialog, dialogBuilder(dialog));

    if (record.paymentmethod == "Direct Entry") {
        $("#traceAccount").autocomplete({
            autoFocus: false,
            delay: 10,
            minLength: 0,
            appendTo: "#traceAccountSuggestions",
            position: {
                my: "left top",
                at: "left bottom",
                collision: "flip"
            },
            source: function(request, response) {
                var results = $.ui.autocomplete.filter(availableTraceAccounts, extractLast(request.term).trim());
                if (!results.length) {
                    results = [{
                        value: 'No Matches Found'
                    }];
                }
                response(results);
            },
            focus: function() {
                return false;
            },
            select: function(event, ui) {
                if (ui.item.value == "No Matches Found") {
                    this.value = "";
                    return false;
                } else {
                    this.value = ui.item.label;
                    record.traceaccount = ui.item.label;
                    return false;
                }
            },
            close: function(event, ui) {
                var matcher = $(this).val().trim();
                var matchie = "";
                var valid = false;
                $.each(availableTraceAccounts, function() {
                    if (this.label.toLowerCase() == matcher.toLowerCase()) {
                        valid = true;
                        matchie = this.label;
                        return false;
                    }
                });
                if (matcher == "") {
                    $(this).val('');
                    record.traceaccount = '';
                } else {
                    if (valid) {
                        $(this).val(matchie);
                    }
                    if (!valid) {
                        if (record.traceaccount != '') {
                            $(this).val(record.traceaccount);
                        } else {
                            $(this).val("");
                        }
                    }
                }
                $(this).data().autocomplete.term = null;
            }
        }).on("click", function() {
            var isOpen = $(this).autocomplete("widget").is(":visible")
            if (isOpen) {
                $(this).autocomplete("close");
            } else {
                $(this).autocomplete("search", "").focus();
            }
        }).data("autocomplete")._renderItem = function(ul, item) {
            if (item.value == "No Matches Found") {
                return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
            } else {
                return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br />" + item.number + " &nbsp;&nbsp; " + item.ccy + "</a>").appendTo(ul);
            }
        };
        $("#traceAccount").val(record.traceaccount);
        $("#transCode").val(record.transactioncode); 
    }

    $("#remitterName").val(record.remitter);
}

function renderFXContractDialog() {

    function addContracts(dialog) {
        var rows = $("input[name=_addContract]:checked");
        var allowedNumber = 5 - record.fxcontracts.length;
        if (allowedNumber == 0) {
            var message1 = "The maximum number of contracts have already been added.";
            buildConfirmDialog(message1, "");
        } else if ( allowedNumber > 0 ) {
            if (rows.length > allowedNumber) {
                var message1 = "The maximum number of contracts will be exceeded.";
                var message2 = "You can add up to <strong>" + allowedNumber + "</strong> more contracts to this payment.";
                buildConfirmDialog(message1, message2);
            } else {
                for (var i = 0, l = $("input[name=_addContract]:checked").length; i < l; i++) {
                    var $contract = $("input[name=_addContract]:checked").eq(i).closest("li");
                    var contract = {
                        id: $contract.attr("data-id"),
                        fxid: $contract.attr("data-fxid"),
                        number: $contract.attr("data-number"),
                        expiry: $contract.attr("data-expiry"),
                        amount: $contract.attr("data-amount"),
                        fromccy: $contract.attr("data-from"),
                        toccy: $contract.attr("data-to"),
                        rate: $contract.attr("data-rate"),
                        used: ""
                    };
                    var $row = $("<div class='data-table-row' data-contract-row='true' id='" + contract.id + "' />");
                    var $referencecell = $("<div class='data-table-cell' style='width: 25%;' data-type='reference' />").appendTo($row);
                    var $removebutton = $("<a href='javascript:void(0)' data-contract-id='" + contract.id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
                        e.preventDefault();
                        $(this).closest("div.data-table-row").remove();
                        var _cid = $(this).attr("data-contract-id");
                        if(record.individualdebitsflag) {
                            instruction.fxcontracts = _.without(instruction.fxcontracts, _.findWhere(instruction.fxcontracts, {
                                id: _cid
                            }));
                        } else {
                            record.fxcontracts = _.without(record.fxcontracts, _.findWhere(record.fxcontracts, {
                                id: _cid
                            }));
                        }
                        renderContractAmountsUI();
                    });
                    var $reference = $("<span>" + contract.number + "</span>").appendTo($referencecell);
                    var $fxidcell = $("<div class='data-table-cell' style='width: 20%;' data-type='fxid' />").appendTo($row);
                    var $fxiddata = $("<span>" + contract.fxid + "</span>").appendTo($fxidcell);
                    var $amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='amount'  />").appendTo($row);
                    var $amountdata = $("<span>$" + addCommas(contract.amount) + "</span>").appendTo($amountcell);
                    var $ratecell = $("<div class='data-table-cell' style='width: 15%; text-align: right;' />").appendTo($row);
                    var $rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell);
                    var $usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='used' >").appendTo($row);
                    var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + contract.id + "' value='0.00' />").appendTo($usedamountcell).on("keydown", preventAlphaKeys).on("change", function() {
                            var val = $(this).val();
                            var cid = $(this).attr("data-contract-id");
                            var used = parseFloat(0).toFixed(2);
                            var camount;
                            if (val != '') {
                                used = val.replace(/[^0-9\.]+/g, "");
                                used = parseFloat(used).toFixed(2);
                            }
                            $(this).val(addCommas(used));
                            if(record.individualdebitsflag) {
                                for (var a = 0, b = instruction.fxcontracts.length; a < b; a++) {
                                    if (instruction.fxcontracts[a].id == cid) {
                                        instruction.fxcontracts[a].used = used;
                                        camount = parseFloat(instruction.fxcontracts[a].amount);
                                        break;
                                    }
                                }
                            } else {
                                for (var a = 0, b = record.fxcontracts.length; a < b; a++) {
                                    if (record.fxcontracts[a].id == cid) {
                                        record.fxcontracts[a].used = used;
                                        camount = parseFloat(record.fxcontracts[a].amount);
                                        break;
                                    }
                                }
                            }
                            if ( used <= camount ) {
                                if ( $(this).closest("div.data-table-cell").hasClass("error") ) {
                                     $(this).closest("div.data-table-cell").removeClass("error");
                                     $(this).prev("i").remove();
                                }
                            }
                            renderContractAmountsUI();
                        }).on('focus', function(){
                            if ( $(this).val() == "0.00" ) {
                                $(this).val('');
                            }
                        }).on('blur', function(){
                            if ( $(this).val() == "" ) {
                                $(this).val('0.00');
                            }
                    });
                    $row.appendTo($("#fxContractList"));
                    if(record.individualdebitsflag) {
                        instruction.fxcontracts.push(contract);
                    } else {
                        record.fxcontracts.push(contract);
                    }
                }
                if(record.individualdebitsflag) {
                    if (instruction.fxcontracts.length == 5 && !instruction.cardedrateflag) {
                        $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
                        $("#cardedRateFlagLabel").addClass("disabled");
                    }
                } else {
                    if (record.fxcontracts.length == 5 && !record.cardedrateflag) {
                        $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
                        $("#cardedRateFlagLabel").addClass("disabled");
                    }
                }
                dialogHider(dialog);
            }
        }
    }

    var $wrapper = $("<div class='wrapper' />"),

        /* build the account filter input */
        $searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
        $searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
        $searchInput = $("<input id='DealNumberFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a contract...' />").on("keyup", function() {
            if (this.value != '') {
                $("#clearDealNumberFilter").show()
            } else {
                $("#clearDealNumberFilter").hide()
            }
        }).appendTo($searchDiv),
        $searchClear = $("<span class='btn search-clear' id='clearDealNumberFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
            $("#DealNumberFilterInput").val("").trigger("change");
            $(this).hide();
        }).appendTo($searchDiv);

    var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
        $checkHeaderDiv = $("<div class='dialog-search-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
            var $target = $(e.target);
            if ($target.prop("nodeName") == "DIV") {
                $target = $target.find("input[name='_selectAll']");
                var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
            }
            var checkBoxes = $("input[name=_addContract]:visible");
            var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
        }),
        $checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
        $numberHeader = $("<div class='dialog-search-header-col' style='width: 220px;'>Contract</div>").appendTo($header),
        $pairHeader = $("<div class='dialog-search-header-col' style='width: 140px;'>From - To</div>").appendTo($header),
        $rateHeader = $("<div class='dialog-search-header-col' style='width: 110px; border-right: 0;'>Rate</div>").appendTo($header),
        $expiryHeader = $("<div class='dialog-search-header-col' style='width: 130px; border-right: 0;'>Expires</div>").appendTo($header),
        $amountHeader = $("<div class='dialog-search-header-col' style='width: 150px; border-right: 0; text-align: right;'>Remaining</div>").appendTo($header);

    _dealNumbers = [];
    for (var i = 0; i < 15; i++) {
        _dealNumbers[i] = getDealNumbers();
    }

    var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
        $ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
        $li, $row, $checkDiv, $checkInput, $number, $paircol, $ratecol, $expiry, $amount;
    $.each(_dealNumbers, function() {
        $li = $("<li data-id='" + this.id + "' data-fxid='" + this.fxid + "' data-number='" + this.number + "' data-from='" + this.fromccy + "' data-to='" + this.toccy + "' data-rate='" + this.rate + "'data-expiry='" + this.expiry + "' data-amount='" + this.amount + "' />").appendTo($ul),
            $row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
                var $target = $(e.target);
                if ($target.prop("nodeName") == "DIV") {
                    if ($target.hasClass("dialog-search-data-col")) {
                        $target = $target.closest("div.dialog-search-row");
                    }
                    $target = $target.find("input[name='_addContract']");
                    var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
                }
                if (!$(this).prop("checked")) {
                    $("input[name='_selectAll']").prop("checked", false)
                }
                if ($("input[name=_addContract]:checked").length == $("input[name=_addContract]").length) {
                    $("input[name='_selectAll']").prop("checked", true)
                }
            }),
            $checkDiv = $("<div class='dialog-search-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row),
            $checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addContract' />").appendTo($checkDiv).on("change", function() {
                var selected = ($(this).is(":checked")) ? $(this).closest("div.dialog-search-row").addClass("selected") : $(this).closest("div.dialog-search-row").removeClass("selected");
            }),
            $number = $("<div class='dialog-search-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
            $paircol = $("<div class='dialog-search-data-col' style='width: 140px;'>" + this.fromccy + " - " + this.toccy + "</div>").appendTo($row),
            $ratecol = $("<div class='dialog-search-data-col' style='width: 110px;'>" + this.rate + "</div>").appendTo($row),
            $expiry = $("<div class='dialog-search-data-col' style='width: 130px;'>" + this.expiry + "</div>").appendTo($row),
            $amount = $("<div class='dialog-search-data-col' style='width: 150px; text-align: right;'>" + addCommas(this.amount) + "</div>").appendTo($row)
    });

    var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
    var _dialog = {
        id: "AddDealNumber",
        title: "Find and Add Contracts",
        size: "xxl",
        icon: "<i class='fa fa-plus-square'></i>",
        content: $wrapper,
        buttons: [{
            name: "Cancel",
            icon: "<i class='fa fa-times fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    dialogHider(_dialog)
                }
            }]
        }, {
            name: "Ok",
            icon: "<i class='fa fa-check fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    addContracts(_dialog);
                }
            }],
            cssClass: "primary"
        }]
    }
    dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

    $("#DealNumberFilterInput").fastLiveFilter('.dialog-search-list');

    if (!$(".dialog-search-list").children("li").length) {
        var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
    }
}

function renderBeneficiaryDetailsDialog() {  
}





/* BENEFICIARY INSTRUCTIONS */

function addBeneficiaryInstruction() {
    if (Slick.GlobalEditorLock.isActive()) {
        Slick.GlobalEditorLock.commitCurrentEdit();
    }
    if ( $("#noInstructionsMessage").size() ) {
        $("#noInstructionsMessage").remove();
    }
    var item = {
        id: randString(20),
        number: dataView.getLength() + 1,
        paymentreference: record.paymentreference,
        endtoendid: record.endtoendid,
        beneficiaryname: "",
        beneficiaryaccountnumber: "",
        beneficiaryid: "",
        beneficiaryemail: "",
        beneficiarycountry: "",
        beneficiarycountrycode: "",
        paymentmethod: "",
        valuedate: record.valuedate,
        paymentcurrency: record.paymentcurrency,
        paymentamount: 0,
        debitcurrency: record.debitaccountcurrency,
        debitequivalentamount: 0,
        debitadviceinformation: "",
        remittanceinformation: "",
        instructionremarks: "",
        invoiceinformation: "",
        emailadviceflag: false,
        traceaccount: record.traceaccount,
        transactioncode: record.transactioncode,
        remitter: record.remitter,        
        validated: "new",
        fxratetype: "Carded",
        fxrate: getCardedRate(),
        fxcontracts: [],
        cardedrateflag: false,
        charges: "",
        purposecode: "",
        purposeofpayment: "",
        errors: [],
        audit: [],
        docs: []
    }
    dataView.addItem(item);
    grid.invalidate();
    grid.updateRowCount();
    grid.render();
    updateBatchTotals();
}

function deleteBeneficiaryInstruction() {
    if ( grid.getDataLength() === selectedRowIds.length ) {
        record.instructions = [];
        data = record.instructions;
        dataView.setItems(data);
    } else {
        var rowsForDelete = [];
        for (var i = 0, l = selectedRowIds.length; i < l; i++) {
            var item = selectedRowIds[i];
            if (item) rowsForDelete.unshift(item)
        }
        for (var i = 0, l = rowsForDelete.length; i < l; i++) {
            dataView.deleteItem(rowsForDelete[i])
        }
        for (var i = 0, l = dataView.getItems().length; i < l; i++) {
            var item = dataView.getItem(i);
            item.number = i + 1;
        }
    }
    grid.setSelectedRows(0);
    selectedRowIds = [];
    dataView.refresh();
    grid.invalidate();
    grid.render();
    updateBatchTotals();
}

function loadInstructionDetails() {
    if (instruction != null) {
        if (instruction.beneficiaryname != "") {
            var bene = returnBeneficiaryRecord(instruction);
            $("#beneName").val(instruction.beneficiaryname);
            $("#batchBeneAccountNumber").html(instruction.beneficiaryaccountnumber);
            $("#batchBeneBankName").html(bene.bank);
            $("#batchBeneBankBranch").html(bene.branch);
            $("#batchBeneBankCountry").html(bene.bankcountry);
            if (record.type == "International Payment") {
                $("#batchBeneClearing").html("SWIFT" + " " + bene.swift);
            } else {
                $("#batchBeneClearing").html(bene.clearing[0].type + " " + bene.clearing[0].code);
            }
            $("#beneEmailField").val(bene.email);
            $("#bopField11").html(bene.country);
            $("#bopField12").html(bene.country);
            if (record.paymentmethod == "Direct Entry" || record.paymentmethod == "RTGS" || record.paymentmethod == "Osko") {
                $("#batchBeneBankBranch").hide();
                $("#batchBeneBankCountry").hide();
            }
            $("#beneficiaryDetails").show();
            $("#beneficiaryDetailDialogTrigger").show();
            if ( record.debitaccountcountry == "China" && record.type == "Domestic Payment" ) {
                $("#paymentMethod").empty();
                var $options = grabPaymentMethods(instruction).appendTo($("#paymentMethod"));
                $("#paymentMethod").val(instruction.paymentmethod);
                handleInstructionPaymentMethodChange();
            }
            var _paymentamount = (instruction.paymentamount == "--") ? "--" : addCommas(parseFloat(instruction.paymentamount).toFixed(2));
            $("#paymentAmount").val(_paymentamount);
            if (record.paymentcurrency != record.debitaccountcurrency) {
                if (record.individualdebitsflag) {
                    renderFXSection().insertAfter($("#instDialogPymtSection"));
                    $("#fxratetype").val(instruction.fxratetype);
                    if (instruction.fxratetype == "Carded") {
                        $("#fxContractButton, #fxContractSection").hide();
                        $("#cardedRateRow").show();
                        returnCardedRate();
                    } else {
                        $("#cardedRateRow").hide();
                        $("#fxContractButton, #fxContractSection").show();  
                        for (var i = 0, l = instruction.fxcontracts.length; i < l; i++) {
                            var contract = instruction.fxcontracts[i];
                            if (contract.id == "cardedRateEntry") {
                                var $row = $("<div class='data-table-row' data-contract-row='true' id='usedCardedRateInContractsRow' />");  
                            } else {
                                var $row = $("<div class='data-table-row' data-contract-row='true' id='" + contract.id + "' />");                           
                            }
                            var $referencecell = $("<div class='data-table-cell' style='width: 25%;' data-type='reference' />").appendTo($row);
                            var $removebutton = $("<a href='javascript:void(0)' data-contract-id='" + contract.id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
                                e.preventDefault();
                                $(this).closest("div.data-table-row").remove();
                                var _cid = $(this).attr("data-contract-id");
                                if (_cid == "cardedRateEntry") {
                                    $("#cardedRateFlag").prop("checked", false);
                                    instruction.cardedrateflag = false;
                                }
                                instruction.fxcontracts = _.without(instruction.fxcontracts, _.findWhere(instruction.fxcontracts, {
                                    id: _cid
                                }));
                                renderContractAmountsUI();
                            });
                            var $reference = $("<span>" + contract.number + "</span>").appendTo($referencecell);
                            var $fxidcell = $("<div class='data-table-cell' style='width: 20%;' data-type='fxid' />").appendTo($row);
                            var $fxiddata = $("<span>" + contract.fxid + "</span>").appendTo($fxidcell);
                            var $amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='amount'  />").appendTo($row);
                            if (contract.id == "cardedRateEntry") {
                                var $amountdata = $("<span>" + addCommas(contract.amount) + "</span>").appendTo($amountcell);
                            } else {
                                var $amountdata = $("<span>$" + addCommas(contract.amount) + "</span>").appendTo($amountcell);                           
                            }
                            var $ratecell = $("<div class='data-table-cell' style='width: 15%; text-align: right;' />").appendTo($row);
                            var $rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell);
                            var $usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' data-type='used' >").appendTo($row);
                            if (contract.id == "cardedRateEntry") {
                                var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0; border: 0;' disabled='disabled' data-contract-id='cardedRateEntry' id='cardedRateEntry' value='" + addCommas(contract.used) + "' />").appendTo($usedamountcell);
                            } else {
                                var $useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + contract.id + "' value='" + addCommas(contract.used) + "' />").appendTo($usedamountcell).on("keydown", preventAlphaKeys).on("change", function() {
                                        var val = $(this).val();
                                        var cid = $(this).attr("data-contract-id");
                                        var used = parseFloat(0).toFixed(2);
                                        var camount;
                                        if (val != '') {
                                            used = val.replace(/[^0-9\.]+/g, "");
                                            used = parseFloat(used).toFixed(2);
                                        }
                                        $(this).val(addCommas(used));
                                        for (var a = 0, b = instruction.fxcontracts.length; a < b; a++) {
                                            if (instruction.fxcontracts[a].id == cid) {
                                                instruction.fxcontracts[a].used = used;
                                                camount = parseFloat(instruction.fxcontracts[a].amount);
                                                break;
                                            }
                                        }
                                        if ( used <= camount ) {
                                            if ( $(this).closest("div.data-table-cell").hasClass("error") ) {
                                                 $(this).closest("div.data-table-cell").removeClass("error");
                                                 $(this).prev("i").remove();
                                            }
                                        }
                                        renderContractAmountsUI();
                                    }).on('focus', function(){
                                        if ( $(this).val() == "0.00" ) {
                                            $(this).val('');
                                        }
                                    }).on('blur', function(){
                                        if ( $(this).val() == "" ) {
                                            $(this).val('0.00');
                                        }
                                });
                            }
                            $row.appendTo($("#fxContractList"));
                        }
                        if (instruction.fxcontracts.length == 5 && !instruction.cardedrateflag) {
                            $("#cardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
                            $("#cardedRateFlagLabel").addClass("disabled");
                        }
                        if (instruction.cardedrateflag) {
                            $("#cardedRateFlag").attr("disabled", false).prop("checked", true);
                        }
                        renderContractAmountsUI();
                    }
                }
                $("#debitAmountRow").show();
                var _debitamount = (instruction.debitequivalentamount == "--") ? "--" : addCommas(parseFloat(instruction.debitequivalentamount).toFixed(2));
                $("#debitAmount").val(_debitamount);
                if (record.debitcurrencyflag) {
                    $("#paymentAmount").attr("readonly", true).parent("div.ccy-amount-input").addClass("readonly");
                    $("#debitAmountRow").addClass("mandatory");
                    $("#debitAmount").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateInstructionAmounts).on("focus", function(){
                        if ( $(this).val() == "0.00" ) {
                            $(this).val('');
                        }
                    });
                } else {
                    $("#debitAmount").attr("readonly", true).parent("div.ccy-amount-input").addClass("readonly");
                    $("#paymentAmountRow").addClass("mandatory");
                    $("#paymentAmount").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateInstructionAmounts).on("focus", function(){
                        if ( $(this).val() == "0.00" ) {
                            $(this).val('');
                        }
                    });
                }
            } else {
                $("#paymentAmountRow").addClass("mandatory");
                $("#paymentAmount").on("keydown.preventAlpha", preventAlphaKeys).on("blur", updateInstructionAmounts).on("focus", function(){
                    if ( $(this).val() == "0.00" ) {
                        $(this).val('');
                    }
                });
            }
            if (record.paymentmethod == "Osko") {
                $("#itemReference").val(instruction.endtoendid);    
            } else {
                $("#itemReference").val(instruction.paymentreference);
            }
            if (record.debitaccountcountry == "Australia" && record.type == "Domestic Payment") {
                $("#remitterName").val(instruction.remitter);
                $("#transCode").val(instruction.transactioncode);
                if (record.paymentmethod == "Direct Entry") {
                     $("#traceAccount").val(instruction.traceaccount);
                }
            }
            $("#remittanceInformation").val(instruction.remittanceinformation);
            if (instruction.emailadviceflag) {
                $("#emailBeneficiaryFlag").prop("checked", true).trigger("change");
            }
            $("#instructionDetailContainer").show();
        } else {
            $("#beneName").val('');
            $("#batchBeneAccountNumber").html('');
            $("#batchBeneLocalLanguageNameField").html('');
            $("#batchBeneBankName").html('');
            $("#batchBeneBankBranch").html('');
            $("#batchBeneBankCountry").html('');
            $("#batchBeneClearing").html('');
            $("#bopField11").html('');
            $("#bopField12").html('');
            $("#beneficiaryDetails").hide();
            $("#beneficiaryDetailDialogTrigger").hide();            
            $("#instructionDetailContainer").hide();
        }
    }
}

function checkInstructionValidation() {
    if (instruction != null) {
        if (instruction.validated == false) {
            if ($("#beneName").val() == '') {
                $("#beneName").closest("div.row").addClass("error").find("div.data-error").remove();
                var $error = $("<div class='data-error'>Beneficiary Account selection is required</div>").appendTo($("#beneName").closest("div.data-column"));
            }
            if ($("#itemReference").val() == '') {
                $("#itemReference").closest("div.row").addClass("error").find("div.data-error").remove();
                var $error = $("<div class='data-error'>Payment Reference is required</div>").appendTo($("#itemReference").closest("div.data-column"));
            }
            if ( record.debitaccountcountry == "China") {
                if ($("#paymentMethod").val() == '') {
                    $("#paymentMethod").closest("div.row").addClass("error").find("div.data-error").remove();
                    var $error = $("<div class='data-error'>Payment Method is required</div>").appendTo($("#paymentMethod").closest("div.data-column"));
                }
            }
            if (record.debitaccountcountry == "Australia") {
                if ($("#traceAccount").val() == '') {
                    $("#traceAccount").closest("div.row").addClass("error").find("div.data-error").remove();
                    var $error = $("<div class='data-error'>Trace Account selection is required</div>").appendTo($("#traceAccount").closest("div.data-column"));
                }
                if ($("#remitterName").val() == '') {
                    $("#remitterName").closest("div.row").addClass("error").find("div.data-error").remove();
                    var $error = $("<div class='data-error'>Remitter Name is required</div>").appendTo($("#remitterName").closest("div.data-column"));
                }
                if ($("#transCode").val() == '') {
                    $("#transCode").closest("div.row").addClass("error").find("div.data-error").remove();
                    var $error = $("<div class='data-error'>Transaction Code is required</div>").appendTo($("#transCode").closest("div.data-column"));
                }
            }
            if (record.individualdebitsflag && instruction.fxratetype == "Contract") {
                if (instruction.fxcontracts.length) {
                    var fxcurrency = (record.debitcurrencyflag) ? record.debitaccountcurrency : record.paymentcurrency;
                    for (var i = 0, l = instruction.fxcontracts.length; i < l; i++) {
                        var contract = instruction.fxcontracts[i];
                        var $row = $("#"+contract.id);
                        if (contract.id != "cardedRateEntry") {
                            if ((parseFloat(contract.used)) > (parseFloat(contract.amount))) {
                                var $col = $row.find("div[data-type='used']");
                                var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-right: 5px; vertical-align: middle;' title='The utlized amount is greater than the available amount'></i>");
                                $col.addClass("error").children("i").remove();
                                $icon.prependTo($col);
                            }
                            if (contract.fromccy != fxcurrency) {
                                var $col = $row.find("div[data-type='reference']");
                                var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-left: 5px; vertical-align: middle;' title='There is a currency pair mismatch with this contract'></i>");
                                $col.addClass("error").children("i").remove();
                                $icon.appendTo($col);
                            }
                        }
                    }
                }
            }
        }
    }
}

function saveInstructionDetails() {

    instruction.paymentreference = $("#itemReference").val();
    instruction.beneficiaryname = $("#beneName").val();
    instruction.beneficiaryaccountnumber = $("#batchBeneAccountNumber").html();
    instruction.remittanceinformation = $("#remittanceInformation").val();
    if ( record.debitaccountcountry == "Australia" ) {
        instruction.traceaccount = $("#traceAccount").val();
        instruction.remitter = $("#remitterName").val();
        instruction.transactioncode = $("#transCode").val();
    }
    if ( record.debitaccountcountry == "China" ) {
        instruction.paymentmethod = $("#paymentMethod").val();
    }
    if (record.individualdebitsflag) {
        if (record.paymentcurrency != record.debitaccountcurrency) {
            instruction.fxratetype = $("#fxratetype").val();
        }
    }

    if ( $("#debitAmount").size() ) {
        if ( $("#debitAmount").val() == "--" ) {
            instruction.debitequivalentamount = "--";
        } else {
            instruction.debitequivalentamount = parseFloat(removeCommas($("#debitAmount").val())).toFixed(2);
        } 
    }

    if ( $("#paymentAmount").size() ) {
        if ( $("#paymentAmount").val() == "--") {
            instruction.paymentamount = "--";
        } else {
            instruction.paymentamount = parseFloat(removeCommas($("#paymentAmount").val())).toFixed(2);
        }
    }

    $.extend( dataView.getItemById(instruction.id), instruction );

    validatePaymentInstruction();
    var row = dataView.getRowById(instruction.id);
    grid.invalidateRow(row);
    grid.render();
    updateBatchTotals();
}

function renderEditInstructionDialog(el, item) {

    instruction = jQuery.extend(true, {}, item);

    var _target = $(el);
    var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

    var renderInstructionBeneficiary = function() {
        var $sectionRow = $("<div class='grid-row' id='instDialogBeneSection' />");
        var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
        var $box = $("<div class='box' />").appendTo($sectionCell);
        var $boxHeader = $("<div class='box-header'>To</div>").appendTo($box);
        var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
        var $detailRow = $("<div class='grid-row' />").appendTo($boxContent);
        var $detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow);
        var $row = $("<div class='row mandatory' />").appendTo($detailCell);
        var $labelCol = $("<div class='label-column' />").appendTo($row);
        var $label = $("<label>Beneficiary</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $comboBox = $("<div class='combobox-div' style='width: 90%;' />").appendTo($dataCol);
        var $beneficiaryName = $("<input type='text' id='beneName' />").appendTo($comboBox);
        var $beneficiaryDetails = $("<a href='javascript:void(0)' id='beneficiaryDetailDialogTrigger' title='View Beneficiafy Details' class='form-icon' style='display: none;'><i class='fa fa-file-text fa-fw'></i></a>").appendTo($dataCol).on("click", function(e) {
            e.preventDefault();
            renderBeneficiaryDetailsDialog();
        });
        var $beneficiarySearch = $("<a href='javascript:void(0)' id='searchBeneficiaryDialog' title='Find a beneficiary' class='form-icon'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol).on("click", function(e) {
            e.preventDefault();
            renderSearchBeneficiaryDialog();
        });
        var $comboBoxAutoCompleteDiv = $("<div id='beneficiaryResults' />").appendTo($dataCol);
        var $detailDiv = $("<div id='beneficiaryDetails' style='display: none;' />").appendTo($boxContent);
        var $boxrow = $("<div class='grid-row' />").appendTo($detailDiv);
        var $boxcell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxrow);
        var $row = $("<div class='row' />").appendTo($boxcell);
        var $labelCol = $("<div class='label-column' />").appendTo($row);
        var $label = $("<label>Account</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $data = $("<div class='data-text' id='batchBeneAccountNumber'></div>").appendTo($dataCol);
        var $boxcell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxrow);
        var $row = $("<div class='row' />").appendTo($boxcell);
        var $labelCol = $("<div class='label-column' />").appendTo($row);
        var $label = $("<label>Bank Details</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($row);
        var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
        var $data = $("<div class='data-text' id='batchBeneBankName'></div>").appendTo($dataGroup);
        var $data = $("<div class='data-text' id='batchBeneBankBranch'></div>").appendTo($dataGroup);
        var $data = $("<div class='data-text' id='batchBeneBankCountry'></div>").appendTo($dataGroup);
        if (record.debitaccountcountry == "China" || record.type == "International Payment") {
            var $boxcell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxrow);
            var $row = $("<div class='row' />").appendTo($boxcell);
            var $labelCol = $("<div class='label-column' />").appendTo($row);
            var $label = $("<label>Clearing Code</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($row);
            var $data = $("<div class='data-text' id='batchBeneClearing'></div>").appendTo($dataCol);
        }

        return $sectionRow;
    }

    var renderInstructionPaymentDetails = function() {
        var $sectionRow = $("<div class='grid-row' id='instDialogPymtSection' />");
        var $sectionCell = $("<div class='grid-cell' />").appendTo($sectionRow);
        var $box = $("<div class='box' />").appendTo($sectionCell);
        var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
        var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
        var $boxRow = $("<div class='grid-row' />").appendTo($boxContent);
        var $leftCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);
        var $rightCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxRow);

        if (record.type == "Domestic Payment") {
            if (record.debitaccountcountry == "Australia") {
                if (record.paymentmethod == "Direct Entry") {
                    renderInstructionAmount().appendTo($leftCell);
                    renderLodgementReference().appendTo($leftCell);
                    renderWithholdingTax().appendTo($rightCell);
                    var $defaultsRow = $("<div class='grid-row' />").appendTo($boxContent);
                    var $defaultLeft = $("<div class='grid-cell' style='width: 50%;' />").appendTo($defaultsRow);
                    var $defaultRight = $("<div class='grid-cell' style='width: 50%;' />").appendTo($defaultsRow);
                    renderRemitterName().appendTo($defaultLeft);
                    renderTransactionCode().appendTo($defaultRight);
                    var $traceAccountRow = $("<div class='grid-row' />").appendTo($boxContent);
                    var $traceAccountCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($traceAccountRow);
                    renderTraceAccount().appendTo($traceAccountCell);
                } else if (record.paymentmethod == "RTGS") {
                    renderInstructionAmount().appendTo($leftCell);
                    renderInstructionReference().appendTo($leftCell);
                    renderInstructionCharges().appendTo($rightCell);
                } else if (record.paymentmethod == "Osko") {
                    renderInstructionAmount().appendTo($leftCell);
                    renderEndToEndID().appendTo($leftCell);
                    var $defaultsRow = $("<div class='grid-row' />").appendTo($boxContent);
                    var $defaultLeft = $("<div class='grid-cell' style='width: 50%;' />").appendTo($defaultsRow);
                    renderRemitterName().appendTo($defaultLeft);
                }
            } else if (record.debitaccountcountry == "China") {
                renderInstructionPaymentMethod().appendTo($leftCell);
                renderInstructionAmount().appendTo($leftCell);
                renderInstructionReference().appendTo($leftCell);
                renderInstructionCharges().appendTo($rightCell);
                renderPurposeCodes().appendTo($rightCell);
                if (record.individualdebitsflag) {
                    renderDebitAdviceDescription().appendTo($rightCell);
                }
            }
        } else if (record.type == "International Payment") {
            if (record.debitaccountcountry == "Australia") {
                renderInstructionAmount().appendTo($leftCell);
                renderInstructionReference().appendTo($leftCell);
                renderInstructionCharges().appendTo($rightCell);
                renderInstructionPurposeOfPayment().appendTo($rightCell);
            } else if (record.debitaccountcountry == "China") {
                renderInstructionAmount().appendTo($leftCell);
                renderInstructionReference().appendTo($leftCell);
                renderInstructionCharges().appendTo($rightCell);
            }
        }

        return $sectionRow;
    }

    var renderInstructionPaymentMethod = function() {
        var $dataRow = $("<div class='row mandatory' id='methodRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Payment Method</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol);
        var $data = $("<select id='paymentMethod'></select>").appendTo($customSelect).on("change", handleInstructionPaymentMethodChange);

        return $dataRow;
    }

    var renderInstructionAmount = function() {
        if (instruction.debitcurrency != instruction.paymentcurrency) {
            var $dataRow = $("<div class='row' />");
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $innerRow = $("<div class='grid-row' />").appendTo($dataCol);
            var $innerCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($innerRow);
            var $amountRow = $("<div class='row' id='paymentAmountRow' style='padding: 0; position: relative;' />").appendTo($innerCell);
            var $labelCol = $("<div class='label-column' />").appendTo($amountRow);
            var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($amountRow);
            var $amountDiv = $("<div class='ccy-amount-input' />").appendTo($dataCol);
            var $data = $("<input type='text' style='width: 80%;' id='paymentAmount' value='0.00' />").appendTo($amountDiv);
            var $ccy = $("<div class='currency'>"+record.paymentcurrency+"</div>").appendTo($amountDiv);
            var $equal = $("<div style='position: absolute; top: 44px; right: 8%; font-size: 20px; color: #4a494a;'>=</div>").appendTo($dataCol);
            var $innerCell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($innerRow);
            var $amountRow = $("<div class='row' id='debitAmountRow' style='padding: 0;' />").appendTo($innerCell);
            var $labelCol = $("<div class='label-column' />").appendTo($amountRow);
            var $label = $("<label>Debit Currency &amp; Amount</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($amountRow);
            var $amountDiv = $("<div class='ccy-amount-input' />").appendTo($dataCol);
            var $data = $("<input type='text' style='width: 80%;' id='debitAmount' value='0.00' />").appendTo($amountDiv);
            var $ccy = $("<div class='currency'>"+record.debitaccountcurrency+"</div>").appendTo($amountDiv);
        } else {
            var $dataRow = $("<div class='row' id='paymentAmountRow' />");
            var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
            var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
            var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
            var $amountDiv = $("<div class='ccy-amount-input' />").appendTo($dataCol);
            var $data = $("<input type='text' style='width: 80%;' id='paymentAmount' value='0.00' />").appendTo($amountDiv);
            var $ccy = $("<div class='currency'>"+record.paymentcurrency+"</div>").appendTo($amountDiv);
        }

        return $dataRow;
    }

    var renderInstructionReference = function() {
        var $dataRow = $("<div class='row mandatory' id='referenceRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Client Reference</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' id='itemReference' style='width: 80%;' />").appendTo($dataCol);

        return $dataRow;
    }

    var renderLodgementReference = function() {
        var $dataRow = $("<div class='row mandatory' id='lodgementRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Lodgment Reference</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' id='itemReference' style='width: 80%;' />").appendTo($dataCol);

        return $dataRow;
    }

    var renderEndToEndID = function() {
        var $dataRow = $("<div class='row mandatory' id='endtoendRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>End-to-End ID</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' id='itemReference' style='width: 80%;' />").appendTo($dataCol);

        return $dataRow;
    }

    var renderInstructionCharges = function() {
        var $dataRow = $("<div class='row mandatory' id='chargesRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Charges</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select disabled' style='width: 80%;' />").appendTo($dataCol);
        var $data = $("<select id='charges' disabled='disabled'><option value='SHA'>SHA</option></select>").appendTo($customSelect).on("change", handleChargesSelection);

        return $dataRow;
    }

    var renderInstructionPurposeOfPayment = function() {
        var $dataRow = $("<div class='row mandatory' id='purposeOfPaymentRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Purpose Of Payment</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol);
        var $data = $("<select id='purposeOfPayment'><option value='Capital Payment'>Capital Payment</option><option value='Payments For Goods'>Payments For Goods</option><<option value='Payments For Services'>Payments For Services</option>/select>").appendTo($customSelect).on("change", handlePurposeOfPaymentSelection);

        return $dataRow;
    }

    var renderPurposeCodes = function() {
        var $dataRow = $("<div class='row mandatory' id='purposeCodeRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Purpose Code</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol);
        var $data = $("<select id='purposeCode'></select>").appendTo($customSelect).on("change", handlePurposeCodeSelection);

        return $dataRow;
    }

    var renderWithholdingTax = function() {
        var $dataRow = $("<div class='row' id='withholdingTaxRow' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Withholding Tax Indicator &amp; Amount</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' />").appendTo($dataCol);
        var $data = $("<select id='taxindicator'><option value=''></option><option value='W'>W</option><option value='X'>X</option><option value='Y'>Y</option></select>").appendTo($customSelect);
        var $data = $("<input type='text' style='width: 60%;' id='withholdingtaxamount'>").appendTo($dataCol);

        return $dataRow;
    }

    var renderDebitAdviceDescription = function() {
        var $dataRow = $("<div class='row' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Debit Advice Description</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $debitAdviceDescription = $("<textarea id='paymentDebitAdviceDescription' style='width: 80%; height: 80px;'></textarea>").appendTo($dataCol).on("change", handleDebitAdviceChanges);

        return $dataRow;
    }

    var renderRemitterName = function() {
        var $dataRow = $("<div class='row mandatory' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Remitter Name</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $data = $("<input type='text' style='width: 80%;' id='remitterName'>").appendTo($dataCol);

        return $dataRow;
    }

    var renderTransactionCode = function() {
        var $dataRow = $("<div class='row mandatory' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Transaction Code</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $customSelect = $("<div class='custom-select' style='width: 80%;' />").appendTo($dataCol);
        var $data = $("<select id='transCode'><option value=''></option><option value='25'>25 - Half Credit</option><option value='50'>50 - Credit</option><option value='100'>100 - Double Credit</option></select>").appendTo($customSelect);

        return $dataRow;
    }

    var renderTraceAccount = function() {
        var $dataRow = $("<div class='row mandatory' />");
        var $labelCol = $("<div class='label-column' />").appendTo($dataRow);
        var $label = $("<label>Trace Account</label>").appendTo($labelCol);
        var $dataCol = $("<div class='data-column' />").appendTo($dataRow);
        var $comboBox = $("<div class='combobox-div' style='width: 90%;' />").appendTo($dataCol);
        var $comboboxInput = $("<input type='text' value='' id='traceAccount' placeholder='Select An Account' />").appendTo($comboBox);
        var $searchIcon = $("<a href='javascript:void(0)' title='Search Accounts' style='color: #007dba;' data-search='trace'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol).on("click", renderSearchAccountsDialog);
        var $suggestionsDiv = $("<div id='traceAccountSuggestions' />").appendTo($dataCol);

        return $dataRow;
    }

    var renderInstructionDialogContent = function() { 
        var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='instructionDialogContent' />");

        /* beneficiarty section */
        renderInstructionBeneficiary().appendTo($dialogContent);

        var $instructionDetailContainer = $("<div id='instructionDetailContainer' style='display: none;' />").appendTo($dialogContent);

        /* instruction details */
        renderInstructionPaymentDetails().appendTo($instructionDetailContainer);

        /* remittance information */
        renderRemitDetailSection().appendTo($instructionDetailContainer);

         /* supporting docs */
        renderSupportingDocumentSection().appendTo($instructionDetailContainer);

        /* additional information */
        if (record.debitaccountcountry == "China") {
            renderAdditionalInformationSection().appendTo($instructionDetailContainer);
        }
        
        return $dialogContent;
    }

    var _dialog = {
        id: "editInstructionDialog",
        title: "Beneficiary Payment Details",
        size: "xxl",
        icon: "<i class='fa fa-pencil-square-o'></i>",
        content: function() {
            return renderInstructionDialogContent();
        },
        close: function() {
            var c = grid.getActiveCell();
            grid.gotoCell(c.row, c.cell, true);
        },
            buttons: [{
                name: "Cancel",
                icon: "<i class='fa fa-times fa-fw'></i>",
                events: [{
                    event: "click",
                    action: function(e) {
                        e.preventDefault();
                        instruction = null;
                        dialogHider(_dialog);
                    }
                }]
            }, {
                name: "Save &amp; Close",
                icon: "<i class='fa fa-check fa-fw'></i>",
                events: [{
                    event: "click",
                    action: function(e) {
                        e.preventDefault();
                        saveInstructionDetails();
                        instruction = null;
                        dialogHider(_dialog);
                    }
                }],
                cssClass: "primary"
            }]
    }

    dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

    /* SECTION LOGIC */
    $("#beneName").on("click", function(){
        var resultsAreVisible = $("#beneName").autocomplete("widget").is(":visible");
        if (resultsAreVisible) {
            $("#beneName").autocomplete("close");
        } else {
            $("#beneName").autocomplete("search", "");
        }           
    }).autocomplete({
        autoFocus: false,
        delay: 10,
        minLength: 0,
        appendTo: "#beneficiaryResults",
        position: {
            my: "left top",
            at: "left bottom",
            collision: "flip"
        },
        source: function(request, response) {
            $("#beneName").autocomplete( "option", "autoFocus", false );
            var results = $.ui.autocomplete.filter(availableBeneficiaryAccounts, extractLast(request.term).trim());
            if (!results.length) {
                results = [{
                    value: 'No Matches Found'
                }];
                results.unshift({value:"Add New Beneficiary"});
            } else if (results.length === 1) {
                $("#beneName").autocomplete( "option", "autoFocus", true );
            } else {
                if (request.term == "") {
                    results.unshift({value:"Add New Beneficiary"});
                }
            }
            response(results);
        },
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            if (ui.item.value == "No Matches Found") {
                this.value = "";
                return false;
            } else if (ui.item.value == "Add New Beneficiary") {
                renderAddBeneficiaryDialog();
                return false;
            } else {
                this.value = ui.item.name;
                if (record.debitaccountcountry == "China" && record.type == "Domestic Payment") {
                    var $select = $("#paymentMethod");
                    $select.empty();
                    var $options = grabPaymentMethods(ui.item).appendTo($select);
                }
                instruction.beneficiaryname = ui.item.name;
                instruction.beneficiaryaccountnumber = ui.item.accountnumber;
                loadInstructionDetails();
                return false;
            }
        },
        close: function(event, ui) {
            var matcher = $(this).val().trim();
            var matchie = "";
            var valid = false;
            $.each(beneficiaryAccounts, function() {
                if (this.name.toLowerCase() == matcher.toLowerCase()) {
                    valid = true;
                    matchie = this.name;
                    return false;
                }
            });
            if (matcher == "") {
                instruction.beneficiaryname = "";
                instruction.beneficiaryaccountnumber = "";
                loadInstructionDetails();
            } else {
                if (valid) {
                    $(this).val(matchie);
                }
                if (!valid) {
                    if (instruction.beneficiaryname != '') {
                        $(this).val(instruction.beneficiaryname);
                    } else {
                        $(this).val('');
                    }
                }
            }
            $(this).data().autocomplete.term = null;
        }
    }).data("autocomplete")._renderItem = function(ul, item) {
        if (item.value == "Add New Beneficiary") {
             return $("<li id='addBeneficiaryDialog'></li>").data("item.autocomplete", item).append("<a style='color: #007dba;'><i class='fa fa-plus-square fa-fw'></i> " + item.value + "</a>").appendTo(ul);
        } else if (item.value == "No Matches Found") {
            return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
        } else {
            return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br />" + item.accountnumber + "</a>").appendTo(ul);
        }
    };


    if ( record.debitaccountcountry == "Australia" && record.paymentmethod == "Direct Entry") {
        $("#traceAccount").autocomplete({
            autoFocus: false,
            delay: 10,
            minLength: 0,
            appendTo: "#traceAccountSuggestions",
            position: {
                my: "left top",
                at: "left bottom",
                collision: "flip"
            },
            source: function(request, response) {
                var results = $.ui.autocomplete.filter(availableTraceAccounts, extractLast(request.term).trim());
                if (!results.length) {
                    results = [{
                        value: 'No Matches Found'
                    }];
                }
                response(results);
            },
            focus: function() {
                return false;
            },
            select: function(event, ui) {
                if (ui.item.value == "No Matches Found") {
                    this.value = "";
                    return false;
                } else {
                    this.value = ui.item.label;
                    record.traceaccount = ui.item.number;
                    return false;
                }
            },
            close: function(event, ui) {
                var matcher = $(this).val().trim();
                var matchie = "";
                var valid = false;
                $.each(availableTraceAccounts, function() {
                    if (this.label.toLowerCase() == matcher.toLowerCase()) {
                        valid = true;
                        matchie = this.label;
                        return false;
                    }
                });
                if (matcher == "") {
                   $(this).val("");     
                } else {
                    if (valid) {
                        $(this).val(matchie);
                    }
                    if (!valid) {
                        if (record.traceaccount != '') {
                             $(this).val(record.traceaccount);
                        } else {
                            $(this).val("");
                        }
                    }
                }
                $(this).data().autocomplete.term = null;
            }
        }).on("click", function() {
            var isOpen = $(this).autocomplete("widget").is(":visible")
            if (isOpen) {
                $(this).autocomplete("close");
            } else {
                $(this).autocomplete("search", "").focus();
            }
        }).data("autocomplete")._renderItem = function(ul, item) {
            if (item.value == "No Matches Found") {
                return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
            } else {
                return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br />" + item.number + " &nbsp;&nbsp; " + item.ccy + "</a>").appendTo(ul);
            }
        };
    }

    loadInstructionDetails();

    checkInstructionValidation();
}

function renderReviewInstructionDialog(el, item) {

    var _target = $(el);
    var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

    var renderReviewInstructionDialogContent = function() {
        var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='instructionDialogContent' />");
        return $dialogContent;
    }

    var _dialog = {
        id: "reviewInstructionDialog",
        title: "Beneficiary Payment Details",
        size: "xxl",
        icon: "<i class='fa fa-pencil-square-o'></i>",
        content: function() {
            return renderReviewInstructionDialogContent();
        },
        buttons: [{
            name: "Close",
            icon: "<i class='fa fa-times fa-fw'></i>",
            events: [{
                event: "click",
                action: function(e) {
                    e.preventDefault();
                    instruction = null;
                    dialogHider(_dialog);
                }
            }]
        }]
    }
    dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}




$(function() {
    $("a[data-type='transfer']").on("click", function(e){e.preventDefault(); createNewPayment("Account Transfer", false)});
    $("a[data-type='domestic']").on("click", function(e){e.preventDefault(); createNewPayment("Domestic Payment", false)});
    $("a[data-type='international']").on("click", function(e){e.preventDefault(); createNewPayment("International Payment", false)});
});