function split( val ) {
	return val.split( /,\s*/ );
}

function extractLast( term ) {
	return split( term ).pop();
}

function rand(min, max) {
  var offset = min;
  var range = (max - min) + 1;
  var randomNumber = Math.floor( Math.random() * range) + offset;
  return randomNumber;
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {



/**********************************************************************
FIND REQUESTS SEARCH CONTROL
**********************************************************************/


/**********************************************************************
NEW REQUEST INITIALIZATION
**********************************************************************/

$("[data-action='set-request-type']").on("click", function(e) {
	e.preventDefault();
	$("#newRequest").addClass("loading");
	$("#otherRequestForm").trigger("reset");
	var cat = $(this).closest("ul.step-list").attr("data-request-type"),
	type = $(this).attr("data-request-type"),
	steps;
	$("[data-request-header]").html($(this).text());
	if(type=="new-card")
	{
	 $("[data-request-header]").html("Card Holder Online Application");
	 $("#billingEntityNumber").val(Math.round(45641234567890 * 10 + 2).toString());
	 $("#billingEntityName").val("Victoria Farms (AU)");
	 $("#cardNumber").val("xxxxxxxxxxx123456");
	 $("#cardHolderName").val("Mr Joe Bloggs");
	 $("#addressLine1").val("833,Collins St");
	 $("#addressLine2").val("");
	 $("#suburb").val("Docklands");
	 $("#state").val("VIC");
	 $("#postCode").val("3008");
	 $("#country").val("Australia");
	 $("#altDeliveryInfo").hide();
	 $("[data-request-header]").html('Cardholder Online Application');
	}
	// replace_card logic - 356844 
	else if(type=="replace-card"){  
	 $("#repcard_billingEntityNumber").val(Math.round(45641234567890 * 10 + 2).toString());
	 $("#repcard_billingEntityName1").html("Victoria Farms (AU)");
	 $("#repcard_altDeliveryInfo").hide();	 
	 $("#cardHolderName").html("Joe Smith");
	 $("#addressLine1").html("833,Collins St");
	 $("#addressLine22").html("833,St Marks");
	 $("#suburb1").html("Docklands");
	 $("#state1").html("VIC");
	 $("#postCode1").html("3008");
	 $("#country1").html("Australia");
	}
	else
	{
	$("[data-request-header]").html($(this).text());
	}
	if (cat=="commercial-card") {
	if(type=="new-card")
	{
		$("#newRequest").attr("data-category","commercial-card");
		steps = $("#defaultSteps");
		steps.children("[data-step='1']").removeClass("active").addClass('complete');
		steps.children("[data-step='3']").addClass("active");
		setTimeout(function() {
			$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='5']").removeClass("hidden").scrollTop(0);
			$("#newRequest").find("div#bottomcontrolsstep5").removeClass("hidden");
			$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1);
			}
		}, 500);
	}
	else if(type=="limit-change")
	{
	$("[data-request-header]").html('Card Limit Change');
		steps = $("#defaultSteps");
		steps.children("[data-step='1']").removeClass("active").addClass('complete');
		steps.children("[data-step='3']").addClass("active");
		setTimeout(function() {
			$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='8']").removeClass("hidden").scrollTop(0);
			$("#newRequest").find("div#bottomcontrolsstep5").removeClass("hidden");
			$("#newRequest").find("div#bottomcontrolsstep8").removeClass("hidden");
			$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
		}, 500);
	}
	else if(type=="replace-card"){  // replace_card logic - 356844
	$("#newRequest").attr("data-category","commercial-card");
		steps = $("#defaultSteps");
		steps.children("[data-step='1']").removeClass("active").addClass('complete');
		steps.children("[data-step='3']").addClass("active");
				setTimeout(function() {
			$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='9']").removeClass("hidden").scrollTop(0);
			$("#newRequest").find("div#bottomcontrolsstep9").removeClass("hidden");
			$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
		}, 500);
	}else if(type=="cancel-card"){ 
	         $("#newRequest").attr("data-category","commercial-card");
	        $("[data-request-header]").html('Cancel Card');
			steps = $("#defaultSteps");
			steps.hide();
		stepsnew = $("#cancelCarddefaultSteps");
		stepsnew.show();
		stepsnew.children("[data-step='1']").removeClass("active").addClass('complete');
		stepsnew.children("[data-step='3']").addClass("active");
				setTimeout(function() {
			$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='11']").removeClass("hidden").scrollTop(0);
			$("#newRequest").find("div#bottomcontrolsstep10").removeClass("hidden");
			$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
		}, 500);
	}
	//statement preference logic - 479143
	else if(type=="statement-pref"){  
	$("#newRequest").attr("data-category","commercial-card");
	 $("[data-request-header]").html('Statement Preferences Change');
		steps = $("#defaultSteps");
		steps.children("[data-step='1']").removeClass("active").addClass('complete');
		steps.children("[data-step='3']").addClass("active");
				setTimeout(function() {
			$("#newRequest").find("div.scroll-area[data-step='1']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='10']").removeClass("hidden").scrollTop(0);
			$("#newRequest").find("div#bottomcontrolsstep10").removeClass("hidden");
			$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
		}, 500);
	}
	}
});

$("[data-action='previousStep']").on("click",function(e){
	e.preventDefault();
	$("#newRequest").addClass("loading");
	var _step = $(this).closest("div.scroll-area").attr("data-step"), _category = $("#newRequest").attr("data-category");
	if (_step == "11") {
		$("#cancelCarddefaultSteps").hide().children("[data-step]").removeClass("active complete");
		$("#defaultSteps").show().children("[data-step='1']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
		$("#newRequest").find("div.scroll-area[data-step='11'], div.scroll-area[data-step='12']").addClass("hidden");
		$("#newRequest").find("div.scroll-area[data-step='1']").removeClass("hidden").scrollTop(0);
		$("#newRequest").find("div#bottomcontrolsstep10").addClass("hidden");
	}else if(_step == "12")
    {
	   $("#cancelCarddefaultSteps").children("[data-step='3']").removeClass("complete").addClass("active").siblings().removeClass("active complete");
	   $("#cancelCarddefaultSteps").children("[data-step='1']").addClass("complete");
	   $("#newRequest").find("div.scroll-area[data-step='12']").addClass("hidden");
	   $("#newRequest").find("div.scroll-area[data-step='11']").removeClass("hidden").scrollTop(0);
    }
	setTimeout(function() {
		$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 200);
});

$("[data-action='nextStep']").on("click",function(e){
	e.preventDefault();
	$("#newRequest").addClass("loading");
	var _step = $(this).closest("div.scroll-area").attr("data-step"), _category = $("#newRequest").attr("data-category");
	if (_step == "11") {
	       
			$("#cancelCarddefaultSteps").children("[data-step='4']").addClass("active").siblings().removeClass("active complete");
			$("#cancelCarddefaultSteps").children("[data-step='3']").addClass("complete");
			$("#newRequest").find("div.scroll-area[data-step='11']").addClass("hidden");
			$("#newRequest").find("div.scroll-area[data-step='12']").removeClass("hidden").scrollTop(0);
	} 
	setTimeout(function() {
		$("#newRequest").removeClass("loading");
			if ( $(".ie8").size() > 0 ) {
				$("body").find(".fa").addClass("repaint");
				setTimeout( function() { $("body").find(".fa").removeClass("repaint"); }, 1)
			}
	}, 200);
});

function createAgain() {
	setTimeout(function() {
		document.location.href="commercial-cards-service-requests-account.html"
	}, 500);
}

function finishCreating() {
	setTimeout(function() {
		document.location.href="commercial-card-service-requests.html"
	}, 500);
}

function returnToOperatingAccounts() {
	setTimeout(function() {
		document.location.href="operating-accounts.html"
	}, 500);
}



$("[data-action='submitRequest']").on("click", function(e){
	e.preventDefault();
	$("body").addClass("loading");
	$(".header, .shell").find(":focusable").attr("tabindex", -1);
	setTimeout(function(){
		buildCustomConfirmDialog( "<span style='font-size: 16px; color: #007dba; font-weight: 600;'>Request ID: 837342281</span>", "<span style='font-weight: 600;'>Your Service Request Has Been Succefully Submitted.</span>", "<span style='display: inline-block; max-width: 400px;'>Request will not be processed unless it has been approved (if applicable) and submitted in accordance with ANZ's requirements.</span>", "View service requests", function(){finishCreating()}, "", "Raise another service request", function(){createAgain()}, "primary");
	},1500);
});


var b=document.location.href.split(".html")[1];

if (b == "#new") {
	$("#newRequestButton").trigger("click");
}


$("[data-action='add-comment']").on("click",function(e){
	e.preventDefault();

});

$("[data-action='refresh']").on("click",function(e){
	e.preventDefault();
	$('#requestDetail').addClass("loading");
	setTimeout(function(){
		$('#requestDetail').removeClass("loading");
	},600);
});

$("[data-action='download']").on("click",function(e){
	e.preventDefault();

});

$("#altAdress").change(function()
   {
       if(this.checked)
      {
	  $("#altDeliveryInfo").show();
	  }
	  else
	  {
	   $("#altDeliveryInfo").hide();
	  }
	   
   });
   //limit change
   $("#permanentlimit").click(function(){ 
	$("#expiryd").hide();
	$("#revertlimit").hide();
	 $("#limitcontrolsection").css('display','');
   });
   
    $("#temporarylimit").click(function(){
   $("#expiryd").show();
   $("#revertlimit").show();
   $("#limitcontrolsection").css('display','block');
   });
   
   $("#searchAccountsDialog3").on("click", function(e) {
	e.preventDefault();
	showAddCards3( $(this) )
   });
   
    $("#newLimit").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
               return false;
    }
   });
$('#limitChangeSubmit').on('click', function() {
          var currentLimit = $('#Currentlimit'),
          newLimit = $('#newLimit');
          //display error message
		  var currLimit=currentLimit.val().replace(",", "");
          if(parseInt(newLimit.val()) > parseInt(currLimit))
          {
                   $('#newLimitError').css("display", "block");
                   $('#newLimit').parents('.row').addClass("error");
          }
          else
          {
                   $('#newLimitError').css("display", "none");
                   $('#newLimit').parents('.row').removeClass("error");
				   $("body").addClass("loading");
	               $(".header, .shell").find(":focusable").attr("tabindex", -1);
	               setTimeout(function(){
		               buildCustomConfirmDialog( "<span style='font-size: 16px; color: #007dba; font-weight: 600;'>Request ID: 837342281</span>", "<span style='font-weight: 600;'>Your Service Request Has Been Succefully Submitted.</span>", "<span style='display: inline-block; max-width: 400px;'>Request will not be processed unless it has been approved (if applicable) and submitted in accordance with ANZ's requirements.</span>", "View service requests", function(){finishCreating()}, "", "Raise another service request", function(){createAgain()}, "primary");
	               },1500);
          }
});
  /**********************************************************************
				SETUP THE DATE FUNCTIONS
**********************************************************************/
var rollingDates = ["Today","Yesterday","Week to Date","Previous Week","Month to Date","Previous Month"];
   
    //replace_card show/hide logic - 356844
 $("#repcard_altAdress").change(function()
   {
       if(this.checked)
      {
	  $("#repcard_altDeliveryInfo").show();
	  }
	  else
	  {
	   $("#repcard_altDeliveryInfo").hide();
	  }
	   
   });

$("#postingdaterolling, #valuedaterolling").autocomplete({
	source: rollingDates,
	autoFocus: false,
	delay: 0,
	minLength: 0,
	focus: function(e,ui) {
		return false;
	},
	select: function(e,ui) {
		$(this).autocomplete("close");
	},
	change: function(e,ui) {
		var matcher = $(this).val();
		var matchie = "";
		var valid = false;
		$.each(rollingDates, function() {
			if(this.toLowerCase() == matcher.toLowerCase()) {
				valid = true;
				matchie = this;
				return false;
			}
		});
		$(this).val(matchie);
		if(!valid) {
			$(this).val("");
			return false;
		}
	}
});
$("#postingdaterolling, #valuedaterolling").on("focus", function(e) {
	e.preventDefault();
	$(this).autocomplete("search", "");
}).on("click", function(e) {
	$(this).autocomplete("search", "");
}).on("keydown", function(e) {
	if(e.keyCode == "9") {
		e.stopImmediatePropagation();
	}
});
var postingdate = $( "#effectivedate_" ).datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true});
var valuedate = $( "#expiredate_" ).datepicker({duration: 0,dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true});
var postingdates = $( "#postingdatefrom, #postingdateto" )
$("#postingdatefrom").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#postingdateto").datepicker( "option", "minDate", selectedDate)
		setTimeout(function(){$("#postingdateto").focus()},50)
	}
});
$("#postingdateto").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#postingdatefrom").datepicker( "option", "maxDate", selectedDate)
	}
});
var valuedates = $( "#valuedatefrom, #valuedateto" )
$("#valuedatefrom").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#valuedateto").datepicker( "option", "minDate", selectedDate)
		setTimeout(function(){$("#valuedateto").focus()},50)
	}
});
$("#valuedateto").datepicker({
	dateFormat: 'dd/mm/yy',
	defaultDate: "-1m",
	changeMonth: true,
	changeYear: true,
	numberOfMonths: 1,
	onSelect: function(selectedDate) {
		$("#valuedatefrom").datepicker( "option", "maxDate", selectedDate)
	}
});
/* Privacy statement*/
function populatePrivacyContent() {
	var $wrapper = $("<div class='form-section top-label' />");
	var $approveSec = $("<div id='verify-section' class='confirmation-message'/>").appendTo($wrapper);
	var $ackmes = $("<p style='margin:15px 10px;text-align:justify;'>Australia and New Zealand Banking group Limited ABN 11 005 357 522 (ANZ) is collecting the personal information of the individuals listed above in order to provide them with an ANZ Commercial Card under the Client's Billing Account. By clicking 'Next' I hereby declare, in respect of the personal information listed above, that the individual/s concerned is/are aware or I will immediately make them aware of the following:ANZ is collecting their information and about your business in order to issue an ANZ Commercial Card to them as an Agent of the Client holding the above Billing Account. Without this information ANZ may not be able to do this. ANZ may also use and disclose their information for ANZ's internal administration and operations (e.g. market or customer satisfaction research) ANZ may disclose their information to: any agent, contractor or service provider we engage to carry out or assist our functions and activities (including debt collection agencies); an organisation that assists ANZ to identify, prevent or investigate any fraud, unlawful activity or misconduct (or suspencted fraud, unlawful activity or misconduct); any third party providing me/us with a product or service in relation to the ANZ product; organisations that are in a product or marketing alliance with ANZ (alliance partners); participants in the payments system (including payment organisations and merchants); and any related entity of ANZANZ may disclose information to recipients (including service providers and related entities) which are (1) located outside Australia and/or (2) not established in or do not carry on business in Australia. Details about the location of these recipients are available in ANZ's Privacy Policy and at www.anz.com/privacy.Privacy PolicyANZ's Privacy Policy (www.anz.com/privacy) contains information about:- any laws that require or authorise ANZ to collect certain information;- the circumstances in which ANZ may collect information from other sources (including from a third party);- how to access personal information and seek correction of personal information; and- how a person can raise concerns that ANZ has breached the Privacy Act or an applicable Code and how ANZ deal with these matters.</p> ").appendTo($approveSec);
	return $wrapper;
}

$("#Privacy").on("click", showPrivacyDialog);
 function showPrivacyDialog(e)
 {
  e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "PrivacyNext",
		title: "ANZ Privacy Statement ",
		size: "large",
		icon: "",
		content: function(){return populatePrivacyContent()},
		buttons: [
			{ name: "Ok", icon: "<i class='fa fa-check fa-fw'></i>", events: [{event: "click", action: function(e){e.preventDefault();dialogHider(_dialog)}}],cssClass: "primary" }
		]
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );
 }
 
 $("#searchCardDialogCancel").on("click", function(e) {
	e.preventDefault();
	showAddCardsCancel( $(this) )
});
function showAddCardsCancel(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

	/* build the account filter input */
	$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
	$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
	$searchInput = $("<input id='AddAccountsFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a card number...' />").on("keyup", function(){
		if ( this.value != '' ) { $("#clearAccountsFilter").show() } else { $("#clearAccountsFilter").hide() }
	}).appendTo($searchDiv),
	$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click",function(){
		$("#AddAccountsFilterInput").val("").trigger("change"); $(this).hide();
	}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
	$nameHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Card Number</div>").appendTo($header),
	$numberHeader = $("<div class='dialog-search-header-col' style='width: 350px;'>Cardholder Name</div>").appendTo($header);
	//$currencyHeadercurrencyHeader = $("<div class='dialog-search-header-col' style='width: 170px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
	$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
	$li, $row, $checkDiv, $checkInput, $name, $number;
	$.each( cardno, function() {
		$li = $("<li data-name='"+this.name+"' data-number='"+this.number+"'>").appendTo($ul),
		$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e){
			var $target = $(e.target);
			if ( $target.prop("nodeName") == "DIV" ) {
				$target = $target.closest("li");
			}
			$("#cardNumberCancel").val($target.attr("data-number"));
			
			dialogHider(_dialog);
		}),
		$name = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.number+"</div>").appendTo($row),
		$number = $("<div class='dialog-search-data-col' style='width: 350px;'>"+this.name+"</div>").appendTo($row)
		//$currency = $("<div class='dialog-search-data-col' style='width: 170px;'>"+this.currency+"</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddCards",
		title: "Add Card Numbers",
		size: "medium",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer( _origin, _dialog, dialogBuilder(_dialog) );

	/* enable the fast filter on the search accounts input */
	$("#AddAccountsFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if ( !$(".dialog-search-list").children("li").length ) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}



var cardNumbers = [];
var cardno = [
	{ number:"************134456", name: "Joe Smith" },
	{ number:"************213456", name: "Joe Smith"},
	{ number:"************453456", name: "Chris Smith"},
	{number:"************673456", name: "Kevin Mike"},
	{number:"************893456", name: "Chris Smith"},
	{number:"************563456", name: "Kevin Mike"},
	{number:"************343456", name: "Kevin Mike"},
	{number:"************673456", name: "Joe Smith"},
	{number:"************233456", name: "Shweta Sinha"},
	{number:"************093456", name: "Kevin Mike"},
	{number:"************643456", name: "Chris Smith"},
	{number:"************293456", name: "Joe Smith"},
	{number:"************193456", name: "Kevin Mike"},
	{number:"************393456", name: "Chris Smith"}
];
for (var j in cardno) {
	cardNumbers.push(cardno[j].number)
}
});



