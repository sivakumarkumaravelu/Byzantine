/* faqs array */
faqs = [{
	title: "Online Help Guide",
	link: "about:blank",
	target: "ANZ Online Help Guide"
}, {
	title: "Payments Onscreen Guide",
	action: "slider"
}, {
	title: "Which payments can I find in Past Payments?",
	faq: "<p>Past Payments shows payments processed in the last 24 months in the following statuses; Completed, Completed with Errors or Bank Rejected.</p>"
}, {
	title: "Why can't I copy multiple payments in the Past Payment screen?",
	faq: "<p>Check the following:<br />&gt; Are you selecting one payment at a time? Payments can only be copied one at a time.<br /> &gt; Do you have permission to create a payment of the same type you are trying to copy?</p>"
}, {
	title: "Why can’t I find a payment in Past Payments?",
	faq: "<p>Check the following:<br />&gt; The payment may not have been processed by ANZ yet - check if the payment is in the Current Payments screen and check the payment status. <br /> &gt; The search criteria entered is not correct - review the search criteria used for the search.</p>"
}];