/* DEBIT ACCOUNTS */
var _debitAccounts = [{
	name: "AUD Local Funding Account",
	number: "8474722322",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	available: "16,000.00",
	availablefunds: "16,000.00"
}, {
	name: "Melbourne AUD Account",
	number: "9839573082",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	available: "67,000.00",
	availablefunds: "67,000.00"
}, {
	name: "AUD Savings",
	number: "7717777731",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	available: "23,000.00",
	availablefunds: "23,000.00"
}, {
	name: "Wangfujing Office",
	number: "3539939711",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZBEI00001",
	city: "Beijing",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Beijing",
	country: "China",
	available: "140,000.00",
	availablefunds: "140,000.00"
}, {
	name: "Hepingmen Office",
	number: "3441295104",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZBEI00001",
	city: "Beijing",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Beijing",
	country: "China",
	available: "75,000.00",
	availablefunds: "75,000.00"
}, {
	name: "Auckland Office",
	number: "3564964147",
	ccy: "NZD",
	bank: "ANZ Bank",
	branch: "Alliance Branch",
	city: "Auckland",
	address1: "King Street Building, Floor 22",
	address2: "1 King Street",
	address3: "Auckland",
	country: "New Zealand",
	available: "92,000.00",
	availablefunds: "92,000.00"
}, {
	name: "NZD Operations Office",
	number: "9494937937",
	ccy: "NZD",
	bank: "ANZ Bank",
	branch: "Alliance Branch",
	city: "Auckland",
	address1: "King Street Building, Floor 22",
	address2: "1 King Street",
	address3: "Auckland",
	available: "4,500.00",
	availablefunds: "4,500.00"
}, {
	name: "SGD Local Funding Account",
	number: "3843947473",
	ccy: "SGD",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	available: "10,000.00",
	availablefunds: "10,000.00"
}, {
	name: "SGD Alternate Funding Account",
	number: "3523463452",
	ccy: "SGD",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	available: "56,000.00",
	availablefunds: "56,000.00"
}];

for (var j in _debitAccounts) {
	_debitAccounts[j].label = _debitAccounts[j].number + " - " + _debitAccounts[j].name + " (" + _debitAccounts[j].ccy + ")";
}

/* CREDIT ACCOUNTS */
var _creditAccounts = [{
	name: "AUD Local Funding Account",
	number: "8474722322",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	available: "16,000.00",
	availablefunds: "16,000.00"
}, {
	name: "Melbourne AUD Account",
	number: "9839573082",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	available: "67,000.00",
	availablefunds: "67,000.00"
}, {
	name: "AUD Savings",
	number: "7717777731",
	ccy: "AUD",
	bank: "ANZ Bank",
	branch: "Melbourne Branch",
	city: "Melbourne",
	address1: "100 Queen Street",
	address2: "Level 20",
	address3: "Melbourne",
	country: "Australia",
	available: "23,000.00",
	availablefunds: "23,000.00"
}, {
	name: "Wangfujing Office",
	number: "3539939711",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZBEI00001",
	city: "Beijing",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Beijing",
	country: "China",
	available: "140,000.00",
	availablefunds: "140,000.00"
}, {
	name: "Hepingmen Office",
	number: "3441295104",
	ccy: "CNY",
	bank: "ANZ Bank",
	branch: "ANZBEI00001",
	city: "Beijing",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Beijing",
	country: "China",
	available: "75,000.00",
	availablefunds: "75,000.00"
}, {
	name: "Auckland Office",
	number: "3564964147",
	ccy: "NZD",
	bank: "ANZ Bank",
	branch: "Alliance Branch",
	city: "Auckland",
	address1: "King Street Building, Floor 22",
	address2: "1 King Street",
	address3: "Auckland",
	country: "New Zealand",
	available: "92,000.00",
	availablefunds: "92,000.00"
}, {
	name: "NZD Operations Office",
	number: "9494937937",
	ccy: "NZD",
	bank: "ANZ Bank",
	branch: "Alliance Branch",
	city: "Auckland",
	address1: "King Street Building, Floor 22",
	address2: "1 King Street",
	address3: "Auckland",
	available: "4,500.00",
	availablefunds: "4,500.00"
}, {
	name: "SGD Local Funding Account",
	number: "3843947473",
	ccy: "SGD",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	available: "10,000.00",
	availablefunds: "10,000.00"
}, {
	name: "SGD Alternate Funding Account",
	number: "3523463452",
	ccy: "SGD",
	bank: "ANZ Bank",
	branch: "ANZSGH00001",
	city: "Shanghai",
	address1: "Raffles City, Floor 22",
	address2: "268 Xizang Middle Road",
	address3: "Shanghai",
	country: "China",
	available: "56,000.00",
	availablefunds: "56,000.00"
}];

for (var j in _creditAccounts) {
	_creditAccounts[j].label = _creditAccounts[j].number + " - " + _creditAccounts[j].name + " (" + _creditAccounts[j].ccy + ")";
}

/* DOMESTIC BENEFICIARY ACCOUNTS */
var _beneAccounts = [{
	id: randString(10),
	name: "Sam Taylor",
	localname: "萨姆·泰勒",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "samtaylor_blues@email.com",
	phone: "555-555-1111",
	fax: "777-888-9999",
	bank: "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
	branch: "Shanghai Branch",
	bankaddress1: "Raffles City",
	bankaddress2: "Floor 22",
	bankaddress3: "268 Xizang Middle Road",
	bankaddress4: "Shanghai",
	bankpostal: "200001",
	bankcountry: "China",
	swift: "ANZBCNSH",
	clearing: [{
		type: "CNAPS",
		code: "761290013606"
	}]
}, {
	id: randString(10),
	name: "Gina Giocare",
	localname: "",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "gina@giocare.com",
	phone: "555-555-2222",
	fax: "777-888-9999",
	bank: "AUSTRALIA AND NEW ZEALAND BANK (CHINA)",
	branch: "Beijing Branch",
	bankaddress1: "Tower 2, Floor 17",
	bankaddress2: "Beijing Bright China Chang An Building",
	bankaddress3: "Dong ChenG District",
	bankaddress4: "Beijing",
	bankpostal: "100005",
	bankcountry: "China",
	swift: "ANZBCNSHBJG",
	clearing: [{
		type: "CNAPS",
		code: "761100000012"
	}]
}, {
	id: randString(10),
	name: "Chris Hendricks",
	localname: "克里斯·亨德里克斯",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "Chris.Hendricks@email.com",
	phone: "555-555-3333",
	fax: "777-888-9999",
	bank: "DBS BANK (CHINA) LIMITED",
	branch: "Beijing Branch",
	bankaddress1: "Winland Int'l Finance Centre, Floor 5",
	bankaddress2: "No.7 Financial Street",
	bankaddress3: "Xicheng District",
	bankaddress4: "Beijing",
	bankpostal: "100140",
	bankcountry: "China",
	swift: "DBSSCNSHBJG",
	clearing: [{
		type: "CNAPS",
		code: "623100000017"
	}]
}, {
	id: randString(10),
	name: "Paul G. Washington",
	localname: "",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "paul.g.washington@email.com",
	phone: "555-555-4444",
	fax: "777-888-9999",
	bank: "DBS BANK (CHINA) LIMITED",
	branch: "Beijing Branch",
	bankaddress1: "Winland Int'l Finance Centre, Floor 5",
	bankaddress2: "No.7 Financial Street",
	bankaddress3: "Xicheng District",
	bankaddress4: "Beijing",
	bankpostal: "100140",
	bankcountry: "China",
	swift: "DBSSCNSHBJG",
	clearing: [{
		type: "CNAPS",
		code: "623100000017"
	}]
}, {
	id: randString(10),
	name: "Sally Fieldser",
	localname: "莎莉·菲尔德",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "sally@email.com",
	phone: "555-555-5555",
	fax: "777-888-9999",
	bank: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	branch: "Shanghai Branch",
	bankaddress1: "Unit 1077/1079/108",
	bankaddress2: "No. 1018",
	bankaddress3: "Chang Ning Road",
	bankaddress4: "Shanghai",
	bankpostal: "200042",
	bankcountry: "China",
	swift: "SCBLCNSXSHA",
	clearing: [{
		type: "CNAPS",
		code: "671290000017"
	}]
}, {
	id: randString(10),
	name: "Miles Miller",
	localname: "万里·米勒",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "MilesMiller@email.com",
	phone: "555-555-6666",
	fax: "777-888-9999",
	bank: "STANDARD CHARTERED BANK CORPORATION LIMITED",
	branch: "Shanghai Branch",
	bankaddress1: "Unit 1077/1079/108",
	bankaddress2: "No. 1018",
	bankaddress3: "Chang Ning Road",
	bankaddress4: "Shanghai",
	bankpostal: "200042",
	bankcountry: "China",
	swift: "SCBLCNSXSHA",
	clearing: [{
		type: "CNAPS",
		code: "671290000017"
	}]
}, {
	id: randString(10),
	name: "William P. Aye",
	localname: "威廉·P·埃",
	accountnumber: randNumber(10),
	accountcurrency: "CNY",
	address1: "",
	address2: "",
	address3: "",
	address4: "",
	country: "China",
	email: "will.p.aye@email.com",
	phone: "555-555-7777",
	fax: "777-888-9999",
	bank: "DEUTSCHE BANK (CHINA) CO. LTD.",
	branch: "Shanghai Branch",
	bankaddress1: "Two IFC, 30 Floor",
	bankaddress2: "8 Century Avenue",
	bankaddress3: "Shanghai",
	bankaddress4: "",
	bankpostal: "200120",
	bankcountry: "China",
	swift: "DEUTCNSH",
	clearing: [{
		type: "CNAPS",
		code: "712290000012"
	}]
}];

for (var j in _beneAccounts) {
	_beneAccounts[j].label = _beneAccounts[j].name + "\n" + _beneAccounts[j].accountnumber;
}


/* FX RATES */
var _rates = [{
	from: "AUD",
	to: "CNY",
	rate: 4.8076
}, {
	from: "AUD",
	to: "SGD",
	rate: 1.0190
}, {
	from: "AUD",
	to: "HKD",
	rate: 5.8900
}, {
	from: "AUD",
	to: "NZD",
	rate: 1.0700
}, {
	from: "CNY",
	to: "AUD",
	rate: 0.2080
}, {
	from: "CNY",
	to: "SGD",
	rate: 0.2120
}, {
	from: "CNY",
	to: "HKD",
	rate: 1.1700
}, {
	from: "CNY",
	to: "NZD",
	rate: 0.2100
}, {
	from: "SGD",
	to: "AUD",
	rate: 0.9813
}, {
	from: "SGD",
	to: "CNY",
	rate: 4.7169
}, {
	from: "SGD",
	to: "HKD",
	rate: 5.7800
}, {
	from: "SGD",
	to: "NZD",
	rate: 1.0100
}, {
	from: "HKD",
	to: "AUD",
	rate: 0.1700
}, {
	from: "HKD",
	to: "CNY",
	rate: 0.8500
}, {
	from: "HKD",
	to: "SGD",
	rate: 0.1700
}, {
	from: "HKD",
	to: "NZD",
	rate: 0.1800
}, {
	from: "NZD",
	to: "AUD",
	rate: 0.9400
}, {
	from: "NZD",
	to: "CNY",
	rate: 4.8400
}, {
	from: "NZD",
	to: "SGD",
	rate: 0.9900
}, {
	from: "NZD",
	to: "HKD",
	rate: 5.5300
}];


/* DEAL REFERENCE NUMBERS */
var _dealNumbers = [];

function generateDealNumber() {

	var fromccy, toccy;

	if (type != "payotherdomesticbatch" && type != "payotherinternationalbatch") {
		if (newSinglePayment.usedebitequivalentflag) {
			fromccy = $("#paymentCurrencySelect").val();
			toccy = selectedDebitAccount.ccy;
		} else {
			fromccy = selectedDebitAccount.ccy;
			toccy = $("#paymentCurrencySelect").val();
		}
	} else {
		fromccy = newBatchPayment.debitaccountcurrency;
		toccy = newBatchPayment.paymentcurrency;
	}

	var amount = addCommas(Number(randNumber(5).replace(/[^0-9\.]+/g, "")).toFixed(2));
	var rate;
	for (var i = 0, l = _rates.length; i < l; i++) {
		if (_rates[i].from == fromccy && _rates[i].to == toccy) {
			rate = _rates[i].rate.toFixed(4);
			break;
		}
	}
	var a = {};
	a["id"] = randString(10);
	a["number"] = randNumber(20);
	a["fromccy"] = fromccy;
	a["toccy"] = toccy;
	a["rate"] = rate;
	a["amount"] = amount;
	a["expiry"] = smartDates("randomfuture");
	return a;
}

/* PAGE VARIABLES */
var type = null,
	selectedDebitAccount = null,
	selectedCreditAccount = null,
	selectedBeneAccount = null,
	batchPaymentItem = null,
	debitEquivalentFlag = false,
	rateType = false,
	cardedRate,
	paymentRemainingAmount = null,
	batchRemainingAmount = null,
	paymentAmount,
	debitEquivalentAmount,
	loadTimer,
	step = 1;


var newSinglePayment = {
	id: "",
	cateogry: "payment",
	type: "",
	division: "",
	debitaccountnumber: "",
	debitaccountname: "",
	debitaccountcurrency: "",
	creditaccountnumber: "",
	creditaccountname: "",
	creditaccountcurrency: "",
	beneficiaryid: "",
	beneficiaryname: "",
	beneficiarylocalname: "",
	beneficiaryaccountnumber: "",
	beneficiarybankname: "",
	beneficiarybankcountry: "",
	beneficiarybranchname: "",
	beneficiaryaccountclearingcode: "",
	beneficiaryaccountswiftcode: "",
	paymentmethod: "",
	paymentdate: "",
	paymentcurrency: "",
	paymentamount: "",
	debitcurrency: "",
	debitequivalentamount: "",
	ratetype: "",
	rate: "",
	contracts: [],
	usecardedratewithcontrats: false,
	usedebitequivalentflag: false,
	paymentreference: "",
	debitadvicedescription: "",
	remittanceinformation: "",
	supportingdocs: [],
	purposecode: "",
	charges: "",
	bopPriority: "",
	bopAmountInWords: "",
	bopUnitCode: "",
	bopResidentRegionName: "",
	bopResidentRegionCode: "",
	bopField1: "",
	bopField2: "",
	bopField3: "",
	bopField4: "",
	bopField5: "",
	bop1TransCode: "",
	bop1TransDesc: "",
	bop1CCY: "",
	bop1Amount: "",
	bop2TransCode: "",
	bop2TransDesc: "",
	bop2CCY: "",
	bop2Amount: "",
	bopContractNumber: "",
	bopInvoiceNumber: ""
};

var newBatchPayment = {
	id: "",
	batchid: "",
	cateogry: "batch",
	type: "",
	division: "",
	debitaccountnumber: "",
	debitaccountname: "",
	debitaccountcurrency: "",
	debitadvicedescription: "",
	name: "",
	paymentdate: "",
	paymentcurrency: "",
	paymentreference: "",
	individualdebitsflag: false,
	urgentflag: false,
	usedebitequivalentflag: false,
	ratetype: "",
	rate: "",
	contracts: [],
	usecardedratewithcontrats: false,
	debitequivalentamount: 0.00,
	paymentamount: 0.00,
	payments: []
};

function resetPaymentData() {
	type = null;
	selectedDebitAccount = null;
	selectedCreditAccount = null;
	selectedBeneAccount = null;
	debitEquivalentFlag = false;
	rateType = false;
	cardedRate;
	paymentAmount;
	debitEquivalentAmount;
	loadTimer;
	step = 1;
	newSinglePayment = {
		id: "",
		cateogry: "payment",
		type: "",
		division: "",
		debitaccountnumber: "",
		debitaccountname: "",
		debitaccountcurrency: "",
		creditaccountnumber: "",
		creditaccountname: "",
		creditaccountcurrency: "",
		beneficiaryid: "",
		beneficiaryname: "",
		beneficiaryaccountnumber: "",
		beneficiarybankname: "",
		beneficiarybankcountry: "",
		beneficiarybranchname: "",
		beneficiaryaccountclearingcode: "",
		beneficiaryaccountswiftcode: "",
		paymentmethod: "",
		paymentdate: "",
		paymentcurrency: "",
		paymentamount: "",
		debitcurrency: "",
		debitequivalentamount: "",
		ratetype: "",
		rate: "",
		contracts: [],
		usedebitequivalentflag: false,
		paymentreference: "",
		debitadvicedescription: "",
		remittanceinformation: "",
		supportingdocs: [],
		purposecode: "",
		charges: "",
		bopPriority: "",
		bopAmountInWords: "",
		bopUnitCode: "",
		bopResidentRegionName: "",
		bopResidentRegionCode: "",
		bopField1: "",
		bopField2: "",
		bopField3: "",
		bopField4: "",
		bopField5: "",
		bop1TransCode: "",
		bop1TransDesc: "",
		bop1CCY: "",
		bop1Amount: "",
		bop2TransCode: "",
		bop2TransDesc: "",
		bop2CCY: "",
		bop2Amount: "",
		bopContractNumber: "",
		bopInvoiceNumber: ""
	};
	newBatchPayment = {
		id: "",
		batchid: "",
		cateogry: "batch",
		type: "",
		division: "",
		debitaccountnumber: "",
		debitaccountname: "",
		debitaccountcurrency: "",
		debitadvicedescription: "",
		name: "",
		paymentdate: "",
		paymentcurrency: "",
		individualdebitsflag: false,
		urgentflag: false,
		ratetype: "",
		rate: "",
		contracts: [],
		usecardedratewithcontrats: false,
		debitequivalentamount: 0.00,
		paymentamount: 0.00,
		payments: []
	};
	clearFormElements("paymentEntryForm");
	$("#showDebAccountDeatilsDialog, #showCredAccountDeatilsDialog").hide();
}

function setupNewPayment(e) {
	e.preventDefault();
	$("#paymentScreen").addClass("loading");
	type = $(this).attr("data-type");
	if (type != "payotherdomesticbatch" && type != "payotherinternationalbatch") {
		newSinglePayment.id = randString(10);
		newSinglePayment.type = type;
		newSinglePayment.division = $("#divisionSelectInput").val();
	} else {
		newBatchPayment.id = randString(10);
		newBatchPayment.type = type;
		newBatchPayment.division = $("#divisionSelectInput").val();
	}
	$("[data-payment-header]").html($(this).attr("data-title"));
	clearFormElements("paymentEntryForm");
	$("#paymentEntryForm").scrollTop(0);
	$("#viewPaymentRecordDetails, #selectDivision, #debitAccountSection, #batchDetailsSection, #creditAccountSection, #beneAccountSection, #singlePaymentDetailSection, #regulatoryReportingSection, #batchPaymentSection, #batchPaymentPreferences, #batchDebitEquivalentFlag, #batchDebitEquivalenLabel, #fxSection, #documentSection, #cancelButton, #closeButton, #continueButton, #reviewButton, #savebutton").css({
		"display": "none"
	});
	step = 2;
	if (type == "payownaccount") {
		$("#selectDivision, #debitAccountSection, #creditAccountSection, #cancelButton, #reviewButton, #savebutton").show();
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		$("#selectDivision, #debitAccountSection, #beneAccountSection, #cancelButton, #reviewButton, #savebutton").show();
	} else if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		$("#selectDivision, #debitAccountSection, #batchDetailsSection, #batchPaymentCurrencySection, #batchPaymentPreferences, #cancelButton, #continueButton, #savebutton").show();
		if (type == "payotherinternationalbatch") {
			$("#urgentFlag, #urgentFlagLabel").hide();
		} else {
			$("#urgentFlag, #urgentFlagLabel").show();
		}
		$("#batchPaymentDateInput").datepicker("setDate", new Date());
		newBatchPayment.paymentdate = $("#batchPaymentDateInput").val();
	}
	setTimeout(function() {
		$("#paymentScreen").find("div[data-step='select']").addClass("hidden");
		$("#paymentScreen").find("div[data-step='enter']").removeClass("hidden").scrollTop(0);
		$("#paymentScreen").removeClass("loading");
		$("#debitAccountInput").focus();
		if ($(".ie8").size() > 0) {
			$("body").find(".fa").addClass("repaint");
			setTimeout(function() {
				$("body").find(".fa").removeClass("repaint");
			}, 1)
		}
	}, 500);
}

function showAddDebitAccount(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddDebitAccountFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearAccountsFilter").show()
			} else {
				$("#clearAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#AddDebitAccountFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
		$nameHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='dialog-search-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
		$li, $row, $name, $number, $currency;
	$.each(_debitAccounts, function() {
		var _debit = this;
		$li = $("<li data-name='" + this.name + "' data-number='" + this.number + "' data-currency='" + this.ccy + "' >").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.closest("li");
				}
				if (selectedDebitAccount != null && step == 3) {
					if (selectedDebitAccount.number != _debit.number) {
						var changeDebitAccount = function() {
							$("#debitAccountInput").val(_debit.number + " - " + _debit.name + " (" + _debit.ccy + ")");
							dialogHider(_dialog);
							selectedDebitAccount = _debit;
							showSelectedDebitAccountDetails(_debit);
							resetSinglePaymentDataEntryFiels();
							if ($("#debitAccountInput").closest("div.row").hasClass("error")) {
								$("#debitAccountInput").closest("div.row").removeClass("error").find("div.data-error").remove();
							}
						}
						buildConfirmDialog("Changing the Debit Account will reset any payment details you have entered.", "Do you want to proceed?", changeDebitAccount);
					} else {
						$("#debitAccountInput").val(_debit.number + " - " + _debit.name + " (" + _debit.ccy + ")");
						dialogHider(_dialog);
					}
				} else {
					$("#debitAccountInput").val(_debit.number + " - " + _debit.name + " (" + _debit.ccy + ")");
					dialogHider(_dialog);
					selectedDebitAccount = _debit;
					showSelectedDebitAccountDetails(_debit);
					if ($("#debitAccountInput").closest("div.row").hasClass("error")) {
						$("#debitAccountInput").closest("div.row").removeClass("error").find("div.data-error").remove();
					}
				}
			}),
			$name = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.number + "</div>").appendTo($row),
			$currency = $("<div class='dialog-search-data-col' style='width: 160px;'>" + this.ccy + "</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddDebitAccount",
		title: "Select a Debit Account",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddDebitAccountFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if (!$(".dialog-search-list").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

function showAddCreditAccount(_target) {
	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddCreditAccountFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find an account...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearCreditAccountsFilter").show()
			} else {
				$("#clearCreditAccountsFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearCreditAccountsFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#AddCreditAccountFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
		$nameHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Name</div>").appendTo($header),
		$numberHeader = $("<div class='dialog-search-header-col' style='width: 320px;'>Account Number</div>").appendTo($header),
		$currencyHeader = $("<div class='dialog-search-header-col' style='width: 160px; border-right: 0;'>Currency</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
		$li, $row, $name, $number, $currency;
	$.each(_creditAccounts, function() {
		var _credit = this;
		$li = $("<li data-name='" + this.name + "' data-number='" + this.number + "' data-currency='" + this.ccy + "' >").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.closest("li");
				}
				if (selectedCreditAccount != null && step == 3) {
					if (selectedCreditAccount.number != _credit.number) {
						var changeCreditAccount = function() {
							$("#creditAccountInput").val(_credit.number + " - " + _credit.name + " (" + _credit.ccy + ")");
							dialogHider(_dialog);
							selectedCreditAccount = _credit;
							showSelectedCreditAccountDetails(_credit);
							resetSinglePaymentDataEntryFiels();
							if ($("#creditAccountInput").closest("div.row").hasClass("error")) {
								$("#creditAccountInput").closest("div.row").removeClass("error").find("div.data-error").remove();
							}
						}
						buildConfirmDialog("Changing the Credit Account will reset any payment details you have entered.", "Do you want to proceed?", changeCreditAccount);
					} else {
						$("#creditAccountInput").val(_credit.number + " - " + _credit.name + " (" + _credit.ccy + ")");
						dialogHider(_dialog);
					}
				} else {
					$("#creditAccountInput").val(_credit.number + " - " + _credit.name + " (" + _credit.ccy + ")");
					dialogHider(_dialog);
					selectedCreditAccount = _credit;
					showSelectedCreditAccountDetails(_credit);
					if ($("#creditAccountInput").closest("div.row").hasClass("error")) {
						$("#creditAccountInput").closest("div.row").removeClass("error").find("div.data-error").remove();
					}
				}
			}),
			$name = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='dialog-search-data-col' style='width: 320px;'>" + this.number + "</div>").appendTo($row),
			$currency = $("<div class='dialog-search-data-col' style='width: 160px;'>" + this.ccy + "</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddCreditAccount",
		title: "Select a Credit Account",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddCreditAccountFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if (!$(".dialog-search-list").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

function showAddBeneAccount(_target) {

	/* set $wrapper to hold the add beneficiary list */
	var $wrapper = $("<div class='wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='AddBeneficiaryFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a beneficiary...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearBeneFilter").show()
			} else {
				$("#clearBeneFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearBeneFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#AddBeneficiaryFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
		$nameHeader = $("<div class='dialog-search-header-col' style='width: 360px;'>Beneficiary Name</div>").appendTo($header),
		$numberHeader = $("<div class='dialog-search-header-col' style='width: 220px;'>Account</div>").appendTo($header),
		$countryHeader = $("<div class='dialog-search-header-col' style='width: 220px; border-right: 0;'>Country</div>").appendTo($header);

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
		$li, $row, $name, $number, $currency;

	$.each(_beneAccounts, function() {
		var _bene = this;
		$li = $("<li data-name='" + this.name + "' data-number='" + this.accountnumber + "' data-bank='" + this.bank + "' data-country='" + this.bankcountry + "' >").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					$target = $target.closest("li");
				}
				if (selectedBeneAccount != null && step == 3) {
					if (selectedBeneAccount.accountnumber != _bene.accountnumber) {
						var changeBeneAccount = function() {
							$("#beneInput").val(_bene.name);
							dialogHider(_dialog);
							selectedBeneAccount = _bene;
							showSelectedBeneficiaryDetails(_bene);
							resetSinglePaymentDataEntryFiels();
							if ($("#beneInput").closest("div.row").hasClass("error")) {
								$("#beneInput").closest("div.row").removeClass("error").find("div.data-error").remove();
							}
						}
						buildConfirmDialog("Changing the Beneficiary will reset any payment details you have entered.", "Do you want to proceed?", changeBeneAccount);
					} else {
						return false;
					}
				} else {
					$("#beneInput").val(_bene.name);
					dialogHider(_dialog);
					selectedBeneAccount = _bene;
					showSelectedBeneficiaryDetails(_bene);
					if ($("#beneInput").closest("div.row").hasClass("error")) {
						$("#beneInput").closest("div.row").removeClass("error").find("div.data-error").remove();
					}
				}
			}),
			$name = $("<div class='dialog-search-data-col' style='width: 360px;'>" + this.name + "</div>").appendTo($row),
			$number = $("<div class='dialog-search-data-col' style='width: 220px;'>" + this.accountnumber + "</div>").appendTo($row),
			$country = $("<div class='dialog-search-data-col' style='width: 220px;'>" + this.bankcountry + "</div>").appendTo($row)
	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddBeneficiaryAccount",
		title: "Select a Beneficiary",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#AddBeneficiaryFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if (!$(".dialog-search-list").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no beneficiaries to add</div>").appendTo($dataContainer);
	}
}

function showDealNumberSearch(_target) {


	function addContracts(dialog) {

		var rows = $("input[name=_addContract]:checked");
		var allowedNumber = 5 - newSinglePayment.contracts.length;


		if (rows.length > allowedNumber) {
			var message1 = "The maximum number of contracts will be exceeded.";
			var message2 = "You can add up to <strong>" + allowedNumber + "</strong> more contracts to this payment.";
			buildConfirmDialog(message1, message2);
		} else {
			for (var i = 0, l = $("input[name=_addContract]:checked").length; i < l; i++) {
				var $contract = $("input[name=_addContract]:checked").eq(i).closest("li"),
					contract = {
						id: $contract.attr("data-id"),
						number: $contract.attr("data-number"),
						expiry: $contract.attr("data-expiry"),
						amount: $contract.attr("data-amount"),
						fromccy: $contract.attr("data-fromccy"),
						toccy: $contract.attr("data-toccy"),
						rate: $contract.attr("data-rate"),
						used: ""
					},
					$row = $("<div class='data-table-row' data-contract-row='true' />"),
					$referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
					$removebutton = $("<a href='javascript:void(0)' data-contract-id='" + contract.id + "'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
						e.preventDefault();
						$(this).closest("div.data-table-row").remove();
						var _fxid = $(this).attr("data-contract-id");
						newSinglePayment.contracts = _.without(newSinglePayment.contracts, _.findWhere(newSinglePayment.contracts, {
							id: _fxid
						}));
						handleContractUsedAmount();
					}),
					$reference = $("<span>" + contract.number + "</span>").appendTo($referencecell),
					$amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
					$amountdata = $("<span>$" + contract.amount + "</span>").appendTo($amountcell),
					$ratecell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
					$rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell),
					$usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
					$useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0;' data-contract-id='" + contract.id + "' value='0.00' />").appendTo($usedamountcell).on("keydown", preventAlphaKeys).on("change", function() {
						var val = $(this).val(),
							cid = $(this).attr("data-contract-id"),
							_amount;
						if (val != '') {
							_amount = val.replace(/[^0-9\.]+/g, "");
							_amount = parseFloat(_amount).toFixed(2);
							$(this).val(addCommas(_amount));
						} else {
							$(this).val("0.00");
						}
						for (var a = 0, b = newSinglePayment.contracts.length; a < b; a++) {
							if (newSinglePayment.contracts[a].id == cid) {
								newSinglePayment.contracts[a].used = $(this).val();
							}
						}
						handleContractUsedAmount();
					});
				$row.appendTo($("#fxContractList"));
				newSinglePayment.contracts.push(contract);
			}
			dialogHider(dialog);
		}
	}


	/* set $wrapper to hold the add accounts list */
	var $wrapper = $("<div class='wrapper' />"),

		/* build the account filter input */
		$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
		$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
		$searchInput = $("<input id='DealNumberFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a contract...' />").on("keyup", function() {
			if (this.value != '') {
				$("#clearDealNumberFilter").show()
			} else {
				$("#clearDealNumberFilter").hide()
			}
		}).appendTo($searchDiv),
		$searchClear = $("<span class='btn search-clear' id='clearDealNumberFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
			$("#DealNumberFilterInput").val("").trigger("change");
			$(this).hide();
		}).appendTo($searchDiv);

	/* build the header row */
	var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
		$checkHeaderDiv = $("<div class='dialog-search-header-col' style='text-align: center; padding: 0; width: 50px; cursor: pointer;' />").appendTo($header).on("click", function(e) {
			var $target = $(e.target);
			if ($target.prop("nodeName") == "DIV") {
				$target = $target.find("input[name='_selectAll']");
				var checker = ($target.is(":checked")) ? $target.prop("checked", false) : $target.prop("checked", true);
			}
			var checkBoxes = $("input[name=_addContract]:visible");
			var selectAll = ($target.is(":checked")) ? checkBoxes.prop("checked", true).trigger('change') : checkBoxes.prop("checked", false).trigger('change');
		}),
		$checkHeaderInput = $("<input type='checkbox' name='_selectAll' />").appendTo($checkHeaderDiv),
		$numberHeader = $("<div class='dialog-search-header-col' style='width: 220px;'>Contract</div>").appendTo($header),
		$pairHeader = $("<div class='dialog-search-header-col' style='width: 140px;'>From - To</div>").appendTo($header),
		$rateHeader = $("<div class='dialog-search-header-col' style='width: 110px; border-right: 0;'>Rate</div>").appendTo($header),
		$expiryHeader = $("<div class='dialog-search-header-col' style='width: 130px; border-right: 0;'>Expires</div>").appendTo($header),
		$amountHeader = $("<div class='dialog-search-header-col' style='width: 150px; border-right: 0; text-align: right;'>Remaining</div>").appendTo($header);


	/* generate deal numbers */
	_dealNumbers = [];
	for (var i = 0; i < 15; i++) {
		_dealNumbers[i] = generateDealNumber();
	}

	/* build the accounts list */
	var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
		$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
		$li, $row, $checkDiv, $checkInput, $number, $paircol, $ratecol, $expiry, $amount;
	$.each(_dealNumbers, function() {
		$li = $("<li data-id='" + this.id + "' data-number='" + this.number + "' data-from='" + this.fromccy + "' data-to='" + this.toccy + "' data-rate='" + this.rate + "'data-expiry='" + this.expiry + "' data-amount='" + this.amount + "' />").appendTo($ul),
			$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
				var $target = $(e.target);
				if ($target.prop("nodeName") == "DIV") {
					if ($target.hasClass("dialog-search-data-col")) {
						$target = $target.closest("div.dialog-search-row");
					}
					$target = $target.find("input[name='_addContract']");
					var checker = ($target.is(":checked")) ? $target.prop("checked", false).trigger('change') : $target.prop("checked", true).trigger('change');
				}
				if (!$(this).prop("checked")) {
					$("input[name='_selectAll']").prop("checked", false)
				}
				if ($("input[name=_addContract]:checked").length == $("input[name=_addContract]").length) {
					$("input[name='_selectAll']").prop("checked", true)
				}
			}),
			$checkDiv = $("<div class='dialog-search-data-col text-center' style='padding: 0; width: 50px; cursor: pointer;' />").appendTo($row),
			$checkInput = $("<input value='" + this.number + "' type='checkbox' name='_addContract' />").appendTo($checkDiv).on("change", function() {
				var selected = ($(this).is(":checked")) ? $(this).closest("div.dialog-search-row").addClass("selected") : $(this).closest("div.dialog-search-row").removeClass("selected");
			}),
			$number = $("<div class='dialog-search-data-col' style='width: 220px;'>" + this.number + "</div>").appendTo($row),
			$paircol = $("<div class='dialog-search-data-col' style='width: 140px;'>" + this.fromccy + " - " + this.toccy + "</div>").appendTo($row),
			$ratecol = $("<div class='dialog-search-data-col' style='width: 110px;'>" + this.rate + "</div>").appendTo($row),
			$expiry = $("<div class='dialog-search-data-col' style='width: 130px;'>" + this.expiry + "</div>").appendTo($row),
			$amount = $("<div class='dialog-search-data-col' style='width: 150px; text-align: right;'>" + this.amount + "</div>").appendTo($row)

	});

	/* build and show the add accounts dialog */
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "AddDealNumber",
		title: "Find and Add Contracts",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: $wrapper,
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					addContracts(_dialog);
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	/* enable the fast filter on the search accounts input */
	$("#DealNumberFilterInput").fastLiveFilter('.dialog-search-list');

	/* if no accounts are available display a message */
	if (!$(".dialog-search-list").children("li").length) {
		var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no accounts to add</div>").appendTo($dataContainer);
	}
}

function showSelectedDebitAccountDetails(debit) {
	step = 2;
	var $detailSection = $("#debitAccountDetailSection"),
		$balanceLoader = $("<i class='data-loader' />"),
		$fundsLoader = $("<i class='data-loader' />");
	if (debit) {
		if (type != "payotherdomesticbatch" && type != "payotherinternationalbatch") {
			newSinglePayment.debitaccountnumber = debit.number;
			newSinglePayment.debitaccountname = debit.name;
			newSinglePayment.debitaccountcurrency = debit.ccy;
			newSinglePayment.debitcurrency = debit.ccy;
		} else {
			newBatchPayment.debitaccountnumber = debit.number;
			newBatchPayment.debitaccountname = debit.name;
			newBatchPayment.debitaccountcurrency = debit.ccy;
		}
		$detailSection.show();
		$("#debitAccountInput").attr("disabled", true).addClass("disabled");
		$("#debitAccountAvailableBalance, #debitAccountAvailableFunds").html("");
		$balanceLoader.appendTo($("#debitAccountAvailableBalance"));
		$fundsLoader.appendTo($("#debitAccountAvailableFunds"));
		clearTimeout(loadTimer);
		loadTimer = setTimeout(function() {
			$("#debitAccountInput").attr("disabled", false).removeClass("disabled");
			$balanceLoader.remove();
			$fundsLoader.remove();
			$("#showDebAccountDeatilsDialog").show();
			$("#debitAccountAvailableBalance").html("$" + debit.available);
			$("#debitAccountAvailableFunds").html("$" + debit.availablefunds);
			if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
				$("#batchPaymentCurrencySelection").val(debit.ccy);
				newBatchPayment.paymentcurrency = debit.ccy
			}
		}, 500);
		checkAccountsAndContinue();
	} else {
		if (type != "payotherdomesticbatch" && type != "payotherinternationalbatch") {
			newSinglePayment.debitaccountnumber = "";
			newSinglePayment.debitaccountname = "";
			newSinglePayment.debitaccountcurrency = "";
			newSinglePayment.debitcurrency = "";
		} else {
			newBatchPayment.debitaccountnumber = "";
			newBatchPayment.debitaccountname = "";
			newBatchPayment.debitaccountcurrency = "";
		}
		$("#debitAccountAvailableBalance, #debitAccountAvailableFunds, #debitEquivalentCurrency").html("");
		$("#showDebAccountDeatilsDialog").hide();
		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			$("#batchPaymentCurrencySelection").val("");
			newBatchPayment.paymentcurrency = "";
		}
		$detailSection.hide();
		resetSinglePaymentDataEntryFiels();
	}
}

function showSelectedCreditAccountDetails(credit) {
	step = 2;
	var $detailSection = $("#creditAccountDetailSection"),
		$balanceLoader = $("<i class='data-loader' />"),
		$fundsLoader = $("<i class='data-loader' />");
	if (credit) {
		newSinglePayment.creditaccountnumber = credit.number;
		newSinglePayment.creditaccountname = credit.name;
		newSinglePayment.creditaccountcurrency = credit.ccy;
		$detailSection.show();
		$("#creditAccountInput").attr("disabled", false).removeClass("disabled");
		$("#creditAccountAvailableBalance, #creditAccountAvailableFunds").html("");
		$balanceLoader.appendTo($("#creditAccountAvailableBalance"));
		$fundsLoader.appendTo($("#creditAccountAvailableFunds"));
		clearTimeout(loadTimer);
		loadTimer = setTimeout(function() {
			$("#creditAccountInput").attr("disabled", false).removeClass("disabled");
			$balanceLoader.remove();
			$fundsLoader.remove();
			$("#showCredAccountDeatilsDialog").show();
			$("#creditAccountAvailableBalance").html("$" + credit.available);
			$("#creditAccountAvailableFunds").html("$" + credit.availablefunds);
		}, 500);
		checkAccountsAndContinue();
	} else {
		newSinglePayment.creditaccountnumber = "";
		newSinglePayment.debitaccountname = "";
		newSinglePayment.debitaccountcurrency = "";
		$("#creditAccountAvailableBalance, #creditAccountAvailableFunds").html("");
		$("#showCredAccountDeatilsDialog").hide();
		$detailSection.hide();
		resetSinglePaymentDataEntryFiels();
	}
}

function showSelectedBeneficiaryDetails(bene) {
	step = 2;
	if (bene) {
		newSinglePayment.beneficiaryname = bene.name;
		newSinglePayment.beneficiarylocalname = bene.localname;
		newSinglePayment.beneficiaryaccountnumber = bene.accountnumber;
		newSinglePayment.beneficiarybankname = bene.bank;
		newSinglePayment.beneficiarybankcountry = bene.bankcountry;
		newSinglePayment.beneficiarybranchname = bene.branch;
		newSinglePayment.beneficiaryaccountclearingcode = bene.clearing[0].code;
		newSinglePayment.beneficiaryaccountswiftcode = bene.swift;
		$("#enterNewBeneficiary").hide();
		$("#beneficiaryDetailsSection").show();
		$("#beneAccountNumber").html(bene.accountnumber);
		$("#beneBankName").html(bene.bank);
		$("#beneBankCountry").html(bene.bankcountry);
		if (bene.localname) {
			$("#beneLocalLanguageField").show();
			$("#beneLocalLanguageName").html(bene.localname);
		} else {
			$("#beneLocalLanguageField").hide();
			$("#beneLocalLanguageName").html("");
		}
		if (bene.branch) {
			$("#beneBankBranchName").show().html(bene.branch);
		} else {
			$("#beneBankBranchName").hide().html("");
		}
		if (type == "payotherdomestic") {
			if (bene.clearing.length) {
				$("#beneClearing").show().html(bene.clearing[0].code);
			} else {
				$("#beneClearing").hide().html("");
			}
		} else if (type == "payotherinternational") {
			$("#beneClearing").show().html(bene.swift);
		}
		checkAccountsAndContinue();
	} else {
		$("#beneAccountNumber, #beneBankName, #beneBankCountry, #beneLocalLanguageName, #beneBankBranchName, #beneClearing").html("");
		$("#beneLocalLanguageField,#beneBankBranchName, #beneClearing").hide();
		$("#enterNewBeneficiary").show();
		$("#beneficiaryDetailsSection").hide();
		newSinglePayment.beneficiaryname = "";
		newSinglePayment.beneficiarylocalname = "";
		newSinglePayment.beneficiaryaccountnumber = "";
		newSinglePayment.beneficiarybankname = "";
		newSinglePayment.beneficiarybankcountry = "";
		newSinglePayment.beneficiarybranchname = "";
		newSinglePayment.beneficiaryaccountclearingcode = "";
		newSinglePayment.beneficiaryaccountswiftcode = "";
		resetSinglePaymentDataEntryFiels();
	}
}

function viewDebitAdviceDescriptionDialog(e) {
	e.preventDefault();
	var _target = $(e.target);

	function renderBatchDescriptionDialog() {
		var $dialogContent = $("<div class='py-ui' id='editBatchDescription' />"),
			$row = $("<div class='row' />").appendTo($dialogContent),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$data = $("<textarea style='width: 95%; height: 150px;' disabled='disabled' class='disabled' id='viewBatchDescriptionField'>" + newBatchPayment.debitadvicedescription + "</textarea>").appendTo($dataCol);
		return $dialogContent;
	}
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "editBatchDescription",
		title: "Debit Advice Description",
		size: "xsmall",
		icon: "<i class='fa fa-edit'></i>",
		content: function() {
			return renderBatchDescriptionDialog();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showEditBatchDescriptionDialog(e) {
	e.preventDefault();
	var _target = $(e.target);

	function renderBatchDescriptionDialog() {
		var $dialogContent = $("<div class='py-ui' id='editBatchDescription' />"),
			$row = $("<div class='row' />").appendTo($dialogContent),
			$dataCol = $("<div class='data-column full' />").appendTo($row),
			$data = $("<textarea style='width: 95%; height: 150px;' id='batchDescriptionField'>" + newBatchPayment.debitadvicedescription + "</textarea>").appendTo($dataCol);
		return $dialogContent;
	}
	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "editBatchDescription",
		title: "Debit Advice Description",
		size: "xsmall",
		icon: "<i class='fa fa-edit'></i>",
		content: function() {
			return renderBatchDescriptionDialog();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					newBatchPayment.debitadvicedescription = $("#batchDescriptionField").val();
					dialogHider(_dialog);
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	$("#batchDescriptionField").focus();
}

function showAccountDetailsDialog(e) {
	e.preventDefault();
	var _target = $(this);

	var _title, _account
	if (_target.attr("id") == "showDebAccountDeatilsDialog" || _target.attr("id") == "selectedDebitAccountNumber") {
		_title = "Debit";
		_account = selectedDebitAccount;
	} else {
		_title = "Credit";
		_account = selectedCreditAccount
	}

	function renderAccountDetails() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' />"),
			$box = $("<div class='box' />").appendTo($dialogContent),
			$boxHeader = $("<div class='box-header'>Account Information</div>").appendTo($box),
			$boxContent = $("<div class='box-content top-label' />").appendTo($box),
			$detailRow = $("<div class='grid-row' />").appendTo($boxContent),
			$detailCell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($detailRow),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Account Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + _account.name + "</div>").appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Debit Account</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + _account.number + " (" + _account.ccy + ")</div>").appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Branch Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + _account.bank + " " + _account.branch + "</div>").appendTo($dataCol),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Address</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$inputGroup = $("<div class='input-group' />").appendTo($dataCol),
			$data = $("<div class='data-text'>" + _account.address1 + "</div>").appendTo($inputGroup),
			$data = $("<div class='data-text'>" + _account.address2 + "</div>").appendTo($inputGroup),
			$data = $("<div class='data-text'>" + _account.address3 + "</div>").appendTo($inputGroup),
			$dataRow = $("<div class='row' />").appendTo($detailCell),
			$labelCol = $("<div class='label-column' />").appendTo($dataRow),
			$label = $("<label>Country</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($dataRow),
			$data = $("<div class='data-text'>" + _account.country + "</div>").appendTo($dataCol);

		return $dialogContent;
	}

	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;

	var _dialog = {
		id: "accountInformationDialog",
		title: _title + " Account Information",
		size: "large",
		icon: "<i class='fa fa-external-link'></i>",
		content: function() {
			return renderAccountDetails();
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function checkAccountsAndContinue() {
	if (type == "payownaccount") {
		if (selectedDebitAccount && selectedCreditAccount) {
			paymentNextStep();
		} else if (selectedDebitAccount && !selectedCreditAccount) {
			$("#creditAccountInput").focus();
		} else if (selectedCreditAccount && !selectedDebitAccount) {
			$("#debitAccountInput").focus();
		}
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		if (selectedDebitAccount && selectedBeneAccount) {
			paymentNextStep();
		} else if (selectedDebitAccount && !selectedBeneAccount) {
			$("#beneInput").focus();
		} else if (selectedBeneAccount && !selectedDebitAccount) {
			$("#debitAccountInput").focus();
		}
	}
}

function fetchCardedRates() {
	var $rateData = $("#fxCardedRateInfo"),
		$loader = $("<i class='data-loader' />"),
		fetchedRateData,
		fromCCY,
		toCCY;

	$rateData.empty();
	$loader.appendTo($rateData);
	clearTimeout(loadTimer);

	if (type != "payotherdomesticbatch" && type != "payotherinternationalbatch") {

		if (debitEquivalentFlag) {
			fromCCY = selectedDebitAccount.ccy;
			toCCY = $("#paymentCurrencySelect").val();
		} else {
			fromCCY = $("#paymentCurrencySelect").val();
			toCCY = selectedDebitAccount.ccy;
		}

		for (var i = 0, l = _rates.length; i < l; i++) {
			var entry = _rates[i];
			if (entry.from == fromCCY && entry.to == toCCY) {
				fetchedRateData = _rates[i];
				cardedRate = fetchedRateData.rate.toFixed(4);
				newSinglePayment.rate = cardedRate;
				break;
			}
		}

		loadTimer = setTimeout(function() {
			$loader.remove();
			var singleEquivalent = 1 * cardedRate;
			var $rate = $("<strong>" + cardedRate + "</strong>").appendTo($rateData);
			var $info = $("<span style='margin-left: 10px;'> $1 " + fromCCY + " = $" + singleEquivalent + " " + toCCY + "</span>").appendTo($rateData);
			if (debitEquivalentFlag) {
				$("#debitEquivalentAmountField").trigger("change");
			} else {
				$("#paymentAmountInputField").trigger("change");
			}

		}, 1000);

	} else {

		if (newBatchPayment.usedebitequivalentflag) {
			fromCCY = newBatchPayment.debitaccountcurrency;
			toCCY = newBatchPayment.paymentcurrency;
		} else {
			fromCCY = newBatchPayment.paymentcurrency;
			toCCY = newBatchPayment.debitaccountcurrency;
		}

		for (var i = 0, l = _rates.length; i < l; i++) {
			var entry = _rates[i];
			if (entry.from == fromCCY && entry.to == toCCY) {
				fetchedRateData = _rates[i];
				cardedRate = fetchedRateData.rate.toFixed(4);
				newBatchPayment.rate = cardedRate;
				break;
			}
		}

		loadTimer = setTimeout(function() {
			$loader.remove();
			var singleEquivalent = 1 * cardedRate;
			var $rate = $("<strong>" + cardedRate + "</strong>").appendTo($rateData);
			var $info = $("<span style='margin-left: 10px;'> $1 " + fromCCY + " = $" + singleEquivalent + " " + toCCY + "</span>").appendTo($rateData);
		}, 1000);

	}
}

function fetchPaymentMethods() {
	var $paymentMethodSelection
	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		$paymentMethodSelection = $("#batchPaymentMethodSelection");
	} else {
		$paymentMethodSelection = $("#paymentMethodSelection");
	}
	var _debitCountry = selectedDebitAccount.country;
	$paymentMethodSelection.empty();
	if (type == "payownaccount") {
		var _creditCountry = selectedCreditAccount.country;
		if (_debitCountry == _creditCountry) {
			var $option = $("<option value='Book Transfer'>Book Transfer</option>").appendTo($paymentMethodSelection);
		} else {
			var $option = $("<option value='Telegraphic Transfer'>Telegraphic Transfer</option>").appendTo($paymentMethodSelection);
		}
		$paymentMethodSelection.trigger("change");
	} else if (type == "payotherdomestic" || type == "payotherdomesticbatch") {
		var $option = $("<option value=''></option>").appendTo($paymentMethodSelection);
		var $option = $("<option value='Book Transfer'>Book Transfer</option>").appendTo($paymentMethodSelection);
		var $beps = $("<option value='BEPS'>BEPS</option>").appendTo($paymentMethodSelection);
		var $hvps = $("<option value='DHVPS'>DHVPS</option>").appendTo($paymentMethodSelection);
		var $hvps = $("<option value='CBHVPS'>CBHVPS</option>").appendTo($paymentMethodSelection);
	} else if (type == "payotherinternational" || type == "payotherinternationalbatch") {
		var $option = $("<option value='Telegraphic Transfer'>Telegraphic Transfer</option>").appendTo($paymentMethodSelection);
		$paymentMethodSelection.trigger("change");
	}
}

function fetchPaymentCurrencies() {
	var _currencies = ["AUD", "CNY", "SGD"],
		$paymentCurrencySelect = $("#paymentCurrencySelect"),
		$option;

	$paymentCurrencySelect.empty();

	if (type == "payownaccount") {
		$option = $("<option value='" + selectedCreditAccount.ccy + "'>" + selectedCreditAccount.ccy + "</option>").appendTo($paymentCurrencySelect);
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		$option = $("<option value=''></option>").appendTo($paymentCurrencySelect);
		for (var i = 0, l = _currencies.length; i < l; i++) {
			var $currencyoptions = $("<option value='" + _currencies[i] + "'>" + _currencies[i] + "</option>").appendTo($paymentCurrencySelect);
		}
		$paymentCurrencySelect.val(selectedDebitAccount.ccy);
	}
	$paymentCurrencySelect.trigger("change");
}

function fetchPurposeCodes() {

	var _bepsPurposeCodes = ["02102 - 普通汇兑 Common exchange"],
		_dhvpsPurposeCodes = ['02102 - 普通汇兑 Common exchange'],
		_cbhvpsPurposeCodes = ['02112 - 货物贸易结算 Goods trade settlement', '02113 - 货物贸易结算退款 Goods trade settlement refund', '02114 - 服务贸易结算 Service trade settlement', '02115 - 服务贸易结算退款 Service trade settlement refund', '02116 - 资本项下跨境支付 X-border pmt under capital acc', '02117 - 资本项下跨境支付退款 X-border pmt refund capital', '02125 - 其他经常项目支出 Other current acc transactions'];

	var $purposeCodeSection = $("#purposeCodeSection"),
		$purposeCodeSelect = $("#purposeCodeSelection"),
		$item = newSinglePayment,
		$option;

	if (type == "payotherdomesticbatch") {
		$purposeCodeSection = $("#batchPaymentPurposeCodeSection");
		$purposeCodeSelect = $("#batchPaymentPurposeCodeField");
		$item = batchPaymentItem;
	}

	$purposeCodeSelect.empty();
	if (type == "payotherdomestic" || type == "payotherdomesticbatch") {
		$option = $("<option value=''></option>").appendTo($purposeCodeSelect);
		if ($item.paymentmethod == "BEPS") {
			for (var i = 0, l = _bepsPurposeCodes.length; i < l; i++) {
				var $purposeoptions = $("<option value='" + _bepsPurposeCodes[i] + "'>" + _bepsPurposeCodes[i] + "</option>").appendTo($purposeCodeSelect);
			}
			$purposeCodeSection.show();
		} else if ($item.paymentmethod == "DHVPS") {
			for (var i = 0, l = _dhvpsPurposeCodes.length; i < l; i++) {
				var $purposeoptions = $("<option value='" + _dhvpsPurposeCodes[i] + "'>" + _dhvpsPurposeCodes[i] + "</option>").appendTo($purposeCodeSelect);
			}
			$purposeCodeSection.show();
		} else if ($item.paymentmethod == "CBHVPS") {
			for (var i = 0, l = _cbhvpsPurposeCodes.length; i < l; i++) {
				var $purposeoptions = $("<option value='" + _cbhvpsPurposeCodes[i] + "'>" + _cbhvpsPurposeCodes[i] + "</option>").appendTo($purposeCodeSelect);
			}
			$purposeCodeSection.show();
		} else if ($item.paymentmethod == "Book Transfer" || $item.paymentmethod == "") {
			$purposeCodeSelect.empty();
			$purposeCodeSection.hide();
		}
	} else {
		$purposeCodeSection.hide();
		if (type == "payotherdomesticbatch") {
			batchPaymentItem.purposecode = "";
		} else {
			newSinglePayment.purposecode = "";
		}
	}
	/*
	$purposeCodeSelect.trigger("change");
	*/
}

function handleBatchNameChanges() {
	newBatchPayment.name = $(this).val();
}

function handleBatchReferenceChanges() {
	newBatchPayment.paymentreference = $(this).val();
}

function handleIndividualDebitsFlag() {
	if (step == 2) {
		newBatchPayment.individualdebitsflag = ($(this).prop("checked")) ? true : false;
	} else if (step == 3) {
		var changeIndividualDebitsFlag = function() {
			newBatchPayment.individualdebitsflag = $("#individualDebitsFlag").prop("checked");
			$("#totalBatchPaymentAmount").html("$" + addCommas(newBatchPayment.paymentamount.toFixed(2)));
			if (newBatchPayment.individualdebitsflag) {
				$("#fxSection").hide();
			} else {
				if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
					$("#fxSection").show();
				}
			}
			$("#paymentScreen").addClass("working");
			clearTimeout(loadTimer);
			loadTimer = setTimeout(function() {
				$("#paymentScreen").removeClass("working");
			}, 500);
		}
		var revertIndividualDebitsFlag = function() {
			$("#individualDebitsFlag").prop("checked", newBatchPayment.individualdebitsflag);
		}
		buildConfirmDialog("Changing this value will effect the FX details applied to this payment.", "Do you want to proceed?", changeIndividualDebitsFlag, revertIndividualDebitsFlag);
	}
}

function handleUrgentFlag() {
	newBatchPayment.urgentflag = ($(this).prop("checked")) ? true : false;
}

function handleBatchCurrencyChanges() {
	if (step == 2) {
		newBatchPayment.paymentcurrency = $(this).val();
		if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
			$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").show();
		} else {
			$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").hide();
			$("#batchDebitEquivalentFlag").prop("checked", false);
		}
	} else if (step > 2) {
		if (newBatchPayment.payments.length) {
			var changeBatchPaymentCurrency = function() {
				newBatchPayment.paymentcurrency = $("#batchPaymentCurrencySelection").val();
				$("#paymentScreen").addClass("working");
				clearTimeout(loadTimer);
				loadTimer = setTimeout(function() {
					for (var i = 0, l = newBatchPayment.payments.length; i < l; i++) {
						newBatchPayment.payments[i].paymentcurrency = newBatchPayment.paymentcurrency;
						newBatchPayment.payments[i].paymentamount = 0.00;
						newBatchPayment.payments[i].debitequivalentamount = 0.00;
						newBatchPayment.payments[i].validated = false;
					}
					editBatchData = newBatchPayment.payments;
					dataView.setItems(editBatchData);
					editBatchGrid.invalidateAllRows();
					editBatchGrid.render();
					newBatchPayment.paymentamount = 0.00;
					newBatchPayment.debitequivalentamount = 0.00;
					$("#totalBatchPaymentAmount, #totalBatchDebitAmount").html("$" + addCommas(newBatchPayment.paymentamount.toFixed(2)));
					continuePaymentDataEntry(type);
					if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
						$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").show();
					} else {
						$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").hide();
						$("#batchDebitEquivalentFlag").prop("checked", false);
					}
					$("#paymentScreen").removeClass("working");
				}, 500);
			}
			var revertBatchPaymentCurrency = function() {
				$("#batchPaymentCurrencySelection").val(newBatchPayment.paymentcurrency);
				if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
					$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").show();
				} else {
					$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").hide();
					$("#batchDebitEquivalentFlag").prop("checked", false);
				}
			}
			buildConfirmDialog("Changing the Payment Currency clear the amounts in added payments and reset batch level FX rates.", "Do you want to proceed?", changeBatchPaymentCurrency, revertBatchPaymentCurrency);
		} else {
			newBatchPayment.paymentcurrency = $("#batchPaymentCurrencySelection").val();
			if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
				$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").show();
			} else {
				$("#batchDebitEquivalentFlag, #batchDebitEquivalenLabel").hide();
				$("#batchDebitEquivalentFlag").prop("checked", false);
			}
			continuePaymentDataEntry(type);
		}
	}
	if ($(this).val()) {
		if ($(this).closest("div.row").hasClass('error')) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
		if ($(this).hasClass("error")) {
			$(this).removeClass("error").closest("div.row").find("div.label-column").removeClass("error");
			$(this).closest("div.row").find("div.data-error").remove();
		}
	}
}

function handleBatchPaymentDebitEquivalentFlag() {
	if (step == 2) {
		newBatchPayment.usedebitequivalentflag = ($("#batchDebitEquivalentFlag").prop("checked")) ? true : false;
	} else if (step > 2) {
		var changeBatchUseDebitCurrencyFlag = function() {
			newBatchPayment.usedebitequivalentflag = ($("#batchDebitEquivalentFlag").prop("checked")) ? true : false;
			$("#paymentScreen").addClass("working");
			var _changeCCY;
			if (newBatchPayment.usedebitequivalentflag) {
				_changeCCY = newBatchPayment.debitaccountcurrency;
			} else {
				_changeCCY = newBatchPayment.paymentcurrency;
			}
			clearTimeout(loadTimer);
			loadTimer = setTimeout(function() {
				var totalAmount = 0.00;
				for (var i = 0, l = newBatchPayment.payments.length; i < l; i++) {
					newBatchPayment.payments[i].paymentcurrency = _changeCCY;
					totalAmount = parseFloat(totalAmount) + parseFloat(newBatchPayment.payments[i].paymentamount.replace(/[^0-9\.]+/g, ""));
				}
				editBatchData = newBatchPayment.payments;
				dataView.setItems(editBatchData);
				editBatchGrid.invalidateAllRows();
				editBatchGrid.render();
				fetchCardedRates();
				$("#totalAmount1").empty();
				$("#totalAmount2").empty();
				if (newBatchPayment.usedebitequivalentflag) {
					if (newBatchPayment.ratetype == "Carded") {
						newBatchPayment.debitequivalentamount = addCommas(totalAmount.toFixed(2));
						newBatchPayment.paymentamount = addCommas((parseFloat(totalAmount * newBatchPayment.rate)).toFixed(2));
					}
					var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + newBatchPayment.paymentamount + "</strong></div>").appendTo($("#totalAmount1"));
					$("#totalAmount1").show();
					var $totalDebiAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + newBatchPayment.debitequivalentamount + "</strong></div>").appendTo($("#totalAmount2"));
					$("#totalAmount2").show();
				} else {
					if (newBatchPayment.ratetype == "Carded") {
						newBatchPayment.paymentamount = addCommas(totalAmount.toFixed(2));
						newBatchPayment.debitequivalentamount = addCommas((parseFloat(totalAmount * newBatchPayment.rate)).toFixed(2));
					}
					var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + newBatchPayment.debitequivalentamount + "</strong></div>").appendTo($("#totalAmount1"));
					$("#totalAmount1").show();
					var $totalDebiAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + newBatchPayment.paymentamount + "</strong></div>").appendTo($("#totalAmount2"));
					$("#totalAmount2").show();
				}
				$("#paymentScreen").removeClass("working");
			}, 500);
		}
		var revertBatchUseDebitCurrencyFlag = function() {
			$("#batchDebitEquivalentFlag").prop("checked", newBatchPayment.usedebitequivalentflag);
		}
		buildConfirmDialog("Changing this setting will impact the currency of entered payments.", "Do you want to proceed?", changeBatchUseDebitCurrencyFlag, revertBatchUseDebitCurrencyFlag);
	}
}

function handleDivisionChanges() {
	newSinglePayment.division = $(this).val();
}

function handlePaymentReferenceChanges() {

	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		batchPaymentItem.paymentreference = $(this).val();
	} else {
		if ($(this).val()) {
			if ($(this).closest("div.row").hasClass('error')) {
				$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
			}
			if ($(this).hasClass("error")) {
				$(this).removeClass("error").closest("div.row").find("div.label-column").removeClass("error");
				$(this).closest("div.row").find("div.data-error").remove();
			}
		}
		newSinglePayment.paymentreference = $(this).val();
	}
}

function handleRemittanceChanges() {
	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		batchPaymentItem.remittanceinformation = $(this).val();
	} else {
		newSinglePayment.remittanceinformation = $(this).val();
	}
}

function handleDebitAdviceChanges() {
	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		batchPaymentItem.debitadvicedescription = $(this).val();
	} else {
		newSinglePayment.debitadvicedescription = $(this).val();
	}
}

function handleBOPFieldChanges() {
	var _field = $(this).attr("id");
	for (var i in newSinglePayment) {
		if (i == _field) {
			newSinglePayment[i] = $(this).val();
		}
	}
}

function handlePurposeCodeChanges() {
	if ($(this).val()) {
		if ($(this).closest("div.row").hasClass('error')) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
		if ($(this).hasClass("error")) {
			$(this).removeClass("error").closest("div.row").find("div.label-column").removeClass("error");
			$(this).closest("div.row").find("div.data-error").remove();
		}
	}
	if (type == "payotherdomesticbatch") {
		batchPaymentItem.purposecode = $(this).val();
	} else {
		newSinglePayment.purposecode = $(this).val();
	}
}

function handlePaymentMethodChanges() {

	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		batchPaymentItem.paymentmethod = $(this).val();
	} else {
		newSinglePayment.paymentmethod = $(this).val();
	}

	fetchPurposeCodes();

	if ($(this).val()) {
		if ($(this).closest("div.row").hasClass('error')) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
		if ($(this).hasClass("error")) {
			$(this).removeClass("error").closest("div.row").find("div.label-column").removeClass("error");
			$(this).closest("div.row").find("div.data-error").remove();
		}
	}
}

function handleRateTypeChanges() {
	var type = $(this).val();
	if (type == "Carded") {
		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			newBatchPayment.ratetype = "Carded";
		} else {
			newSinglePayment.ratetype = "Carded";
		}
		rateType = "Carded";
		$("#fxContractRow").hide();
		$("#fxContractSection").hide();
		$("#fxCardedRateRow").show();
		fetchCardedRates();
	} else {
		rateType = "Contract";
		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			newBatchPayment.ratetype = "Contract";
		} else {
			newSinglePayment.ratetype = "Contract";
		}
		$("#fxCardedRateRow").hide();
		$("#fxContractRow").show();
		$("#fxContractSection").show();
		$("#fxContractSearch").focus();

		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			if (newBatchPayment.usedebitequivalentflag) {

			} else {

			}
		} else {
			if (debitEquivalentFlag) {
				$("#paymentAmountInputField").val("");
				$("#paymentAmountTextValue").html("");
				paymentAmount = 0.00;
				newSinglePayment.paymentamount = paymentAmount;
			} else {
				$("#debitEquivalentAmountField").val("");
				$("#debitEquivalentAmountTextValue").html("");
				debitEquivalentAmount = 0.00;
				newSinglePayment.debitequivalentamount = debitEquivalentAmount;
			}
		}
		handleContractUsedAmount();
	}
}

function handlePaymentCurrencyChanges() {
	var _paymentccy = $(this).val(),
		_debitccy = selectedDebitAccount.ccy;

	/* set newSinglePayment.paymentcurrency */
	newSinglePayment.paymentcurrency = _paymentccy;

	/* reset the payment amount */
	$("#paymentAmountInputField").val("");
	$("#paymentAmountTextValue").html("");
	paymentAmount = 0;
	newSinglePayment.paymentamount = paymentAmount;

	/* reset the debit equivalent amounts */
	$("#debitEquivalentAmountField").val("");
	$("#debitEquivalentAmountTextValue").html("");
	debitEquivalentAmount = 0;
	newSinglePayment.debitequivalentamount = debitEquivalentAmount;

	if (_paymentccy == "" || (_paymentccy == _debitccy)) {
		$("#debitEquivalentSection, #debitEquivalentEntryFlag, #fxSection").hide();
		$("#remainingPaymentAmount").empty();
		debitEquivalentFlag = false;
		rateType = false;
		cardedRate = null;
		paymentAmount = null;
		debitEquivalentAmount = null;
		newSinglePayment.ratetype = false;
		newSinglePayment.rate = null;
		newSinglePayment.contracts = [];
		if (newSinglePayment.usedebitequivalentflag) {
			$("#useDebitAmount").prop("checked", false).trigger("change");
		}
		$("#paymentAmountInputField").trigger("change");
	} else if (_paymentccy != _debitccy) {
		$("#debitEquivalentSection, #debitEquivalentEntryFlag, #fxSection").show();
		if (!newSinglePayment.ratetype || newSinglePayment.ratetype == "Carded") {
			$("#fxSelection").val("Carded").trigger("change");
		} else if (newSinglePayment.ratetype == "Contract") {
			$("#fxSelection").val("Contract").trigger("change");
			$("#fxContractList").find("div[data-contract-row='true']").remove();
			newSinglePayment.contracts = [];
		}
	}
}

function handleDebitEquivalentFlag() {
	debitEquivalentFlag = ($(this).prop('checked')) ? true : false;
	newSinglePayment.usedebitequivalentflag = debitEquivalentFlag;
	if (debitEquivalentFlag) {
		paymentAmount = 0;
		newSinglePayment.paymentamount = paymentAmount;
		$("#paymentAmountTextValue").html("");
		$("#debitEquivalentAmountTextValue, #paymentAmountInputField").hide();
		$("#debitEquivalentAmountField, #paymentAmountTextValue").show();
	} else {
		debitEquivalentAmount = 0;
		newSinglePayment.debitequivalentamount = debitEquivalentAmount;
		$("#debitEquivalentAmountTextValue").html("");
		$("#debitEquivalentAmountField, #paymentAmountTextValue").hide();
		$("#debitEquivalentAmountTextValue, #paymentAmountInputField").show();
	}
	if (rateType == "Carded") {
		fetchCardedRates()
	} else if (rateType == "Contract") {
		$("#fxContractList").find("div[data-contract-row='true']").remove();
		newSinglePayment.contracts = [];
		handleContractUsedAmount();
	}
	$("#paymentAmountSection, #debitEquivalentSection").removeClass("error").find(".error").removeClass("error");
	$("#paymentAmountSection, #debitEquivalentSection").find("div.data-error").remove();
}

function handleAmountChanges(el) {
	var $this = el,
		id = $this.attr("id"),
		amount;
	if ($this.val() && $this.val() != '') {
		amount = $this.val().replace(/[^0-9\.]+/g, "");
		if (rateType == "Carded") {
			$this.val(addCommas(parseFloat(amount).toFixed(2)));
			var equivalentAmount = (parseFloat(amount * cardedRate)).toFixed(2);
			if (id == "paymentAmountInputField") {
				$("#paymentAmountTextValue").html(addCommas(parseFloat(amount).toFixed(2)));
				$("#debitEquivalentAmountField").val(addCommas(equivalentAmount));
				$("#debitEquivalentAmountTextValue").html(addCommas(equivalentAmount));
				paymentAmount = parseFloat(amount).toFixed(2);
				debitEquivalentAmount = equivalentAmount;
			} else if (id == "debitEquivalentAmountField") {
				$("#debitEquivalentAmountTextValue").html(addCommas(parseFloat(amount).toFixed(2)));
				$("#paymentAmountInputField").val(addCommas(equivalentAmount));
				$("#paymentAmountTextValue").html(addCommas(equivalentAmount));
				paymentAmount = equivalentAmount;
				debitEquivalentAmount = parseFloat(amount).toFixed(2);
			} else if (id == "batchPaymentAmountField") {
				$("#batchPaymentAmountTextValue").html(addCommas(parseFloat(amount).toFixed(2)));
				$("#batchPaymentDebitEquivalentAmountField").val(addCommas(equivalentAmount));
				$("#batchPaymentDebitEquivalentAmountTextValue").html(addCommas(equivalentAmount));
				paymentAmount = parseFloat(amount).toFixed(2);
				debitEquivalentAmount = equivalentAmount;
			} else if (id == "batchPaymentDebitEquivalentAmountField") {
				$("#batchPaymentDebitEquivalentAmountTextValue").html(addCommas(parseFloat(amount).toFixed(2)));
				$("#batchPaymentAmountField").val(addCommas(equivalentAmount));
				$("#batchPaymentAmountTextValue").html(addCommas(equivalentAmount));
				paymentAmount = equivalentAmount;
				debitEquivalentAmount = parseFloat(amount).toFixed(2);
			}
		} else if (rateType == "Contract") {
			if (id == "paymentAmountInputField") {
				paymentAmount = parseFloat(amount).toFixed(2);
			} else if (id == "debitEquivalentAmountField") {
				debitEquivalentAmount = parseFloat(amount).toFixed(2);
			} else if (id == "batchPaymentAmountField") {
				paymentAmount = parseFloat(amount).toFixed(2);
			} else if (id == "batchPaymentDebitEquivalentAmountField") {
				debitEquivalentAmount = parseFloat(amount).toFixed(2);
			}
			$this.val(addCommas(parseFloat(amount).toFixed(2)));
			handleContractUsedAmount();
		} else if (!rateType) {
			paymentAmount = parseFloat(amount).toFixed(2);
			debitEquivalentAmount = paymentAmount;
			if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
				$("#batchPaymentAmountField").val(addCommas(paymentAmount));
				$("#batchPaymentAmountTextValue").html(addCommas(paymentAmount));
				$("#batchPaymentDebitEquivalentAmountField").val(addCommas(paymentAmount));
				$("#batchPaymentDebitEquivalentAmountTextValue").html(addCommas(paymentAmount));
			} else {
				$("#paymentAmountInputField").val(addCommas(paymentAmount));
				$("#paymentAmountTextValue").html(addCommas(paymentAmount));
				$("#debitEquivalentAmountField").val(addCommas(paymentAmount));
				$("#debitEquivalentAmountTextValue").html(addCommas(paymentAmount));
			}
		}
	} else {
		paymentAmount = 0;
		debitEquivalentAmount = 0;
		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			$("#batchPaymentAmountField").val("");
			$("#batchPaymentAmountTextValue").html("");
			$("#batchPaymentDebitEquivalentAmountField").val("");
			$("#batchPaymentDebitEquivalentAmountTextValue").html("");
		} else {
			$("#paymentAmountInputField").val("");
			$("#paymentAmountTextValue").html("");
			$("#debitEquivalentAmountField").val("");
			$("#debitEquivalentAmountTextValue").html("");
		}
		if (rateType == "Contract") {
			handleContractUsedAmount();
		}
	}
	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		batchPaymentItem.paymentamount = addCommas(parseFloat(paymentAmount).toFixed(2));
		batchPaymentItem.debitequivalentamount = addCommas(parseFloat(debitEquivalentAmount).toFixed(2));
	} else {
		newSinglePayment.paymentamount = paymentAmount;
		newSinglePayment.debitequivalentamount = debitEquivalentAmount;
	}
}

function handleCardedRateInContracts() {
	if ($(this).prop("checked")) {
		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			newBatchPayment.usecardedratewithcontrats = true;

			var fromCCY, toCCY;

			/* get the rate */
			if (newBatchPayment.usedebitequivalentflag) {
				fromCCY = newBatchPayment.paymentcurrency;
				toCCY = selectedDebitAccount.ccy;
			} else {
				fromCCY = selectedDebitAccount.ccy;
				toCCY = newBatchPayment.paymentcurrency;
			}
			for (var i = 0, l = _rates.length; i < l; i++) {
				var entry = _rates[i];
				if (entry.from == fromCCY && entry.to == toCCY) {
					fetchedRateData = _rates[i];
					cardedRate = fetchedRateData.rate.toFixed(4);
					newBatchPayment.rate = cardedRate;
					break;
				}
			}

			/* get the remaining amount needed */
			var totalamount = (newBatchPayment.usedebitequivalentflag) ? newBatchPayment.debitequivalentamount : newBatchPayment.paymentamount,
				usedamount = 0,
				remainingamount;

			if ($("input[data-contract-id]").size()) {
				$("input[data-contract-id]").each(function() {
					var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
					usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
				});
			}
			remainingamount = (totalamount - usedamount).toFixed(2);

			/* attach the line item to the fx contracts grid */
			var $row = $("<div class='data-table-row' data-contract-row='true' id='usedCardedRateInContractsRow' />"),
				$referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
				$removebutton = $("<a href='javascript:void(0)'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
					e.preventDefault();
					$(this).closest("div.data-table-row").remove();
					$("#useCardedRateFlag").prop("checked", false);
					newBatchPayment.usecardedratewithcontrats = false;
					handleContractUsedAmount();
				}),
				$reference = $("<span>Carded Rate</span>").appendTo($referencecell),
				$amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
				$amountdata = $("<span>&nbsp;</span>").appendTo($amountcell),
				$ratecell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
				$rate = $("<span>" + cardedRate + "</span>").appendTo($ratecell),
				$usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
				$useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0; border: 0;' disabled='disabled' data-contract-id='cardedRateRow' id='cardedRateRow' value='" + addCommas(remainingamount) + "' />").appendTo($usedamountcell);
			$row.appendTo($("#fxContractList"));
			handleContractUsedAmount();
			var contract = {
				id: "CardedRateEntry",
				number: "Carded Rate",
				expiry: "",
				amount: "",
				fromccy: fromCCY,
				toccy: toCCY,
				rate: cardedRate,
				used: addCommas(remainingamount)
			};
			newBatchPayment.contracts.push(contract);
		} else {
			newSinglePayment.usecardedratewithcontrats = true;

			var fromCCY, toCCY;

			/* get the rate */
			if (newSinglePayment.usedebitequivalentflag) {
				fromCCY = $("#paymentCurrencySelect").val();
				toCCY = selectedDebitAccount.ccy;
			} else {
				fromCCY = selectedDebitAccount.ccy;
				toCCY = $("#paymentCurrencySelect").val();
			}
			for (var i = 0, l = _rates.length; i < l; i++) {
				var entry = _rates[i];
				if (entry.from == fromCCY && entry.to == toCCY) {
					fetchedRateData = _rates[i];
					cardedRate = fetchedRateData.rate.toFixed(4);
					newSinglePayment.rate = cardedRate;
					break;
				}
			}

			/* get the remaining amount needed */
			var totalamount = ($("#useDebitAmount").is(":checked")) ? debitEquivalentAmount : paymentAmount,
				usedamount = 0,
				remainingamount;

			if ($("input[data-contract-id]").size()) {
				$("input[data-contract-id]").each(function() {
					var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
					usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
				});
			}
			remainingamount = (totalamount - usedamount).toFixed(2);

			/* attach the line item to the fx contracts grid */
			var $row = $("<div class='data-table-row' data-contract-row='true' id='usedCardedRateInContractsRow' />"),
				$referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
				$removebutton = $("<a href='javascript:void(0)'><i class='fa fa-times fa-lg fa-fw'></i></a>").appendTo($referencecell).on('click', function(e) {
					e.preventDefault();
					$(this).closest("div.data-table-row").remove();
					$("#useCardedRateFlag").prop("checked", false);
					newSinglePayment.usecardedratewithcontrats = false;
					handleContractUsedAmount();
				}),
				$reference = $("<span>Carded Rate</span>").appendTo($referencecell),
				$amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
				$amountdata = $("<span>&nbsp;</span>").appendTo($amountcell),
				$ratecell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
				$rate = $("<span>" + cardedRate + "</span>").appendTo($ratecell),
				$usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
				$useramountinput = $("<input type='text' style='width: 85%; font-size: 100%; text-align: right; margin: 0; border: 0;' disabled='disabled' data-contract-id='cardedRateRow' id='cardedRateRow' value='" + addCommas(remainingamount) + "' />").appendTo($usedamountcell);
			$row.appendTo($("#fxContractList"));
			handleContractUsedAmount();
			var contract = {
				id: "CardedRateEntry",
				number: "Carded Rate",
				expiry: "",
				amount: "",
				fromccy: fromCCY,
				toccy: toCCY,
				rate: cardedRate,
				used: addCommas(remainingamount)
			};
			newSinglePayment.contracts.push(contract);
		}
	} else {
		if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
			newBatchPayment.usecardedratewithcontrats = false;
			$("#usedCardedRateInContractsRow").remove();
			newBatchPayment.contracts = _.without(newBatchPayment.contracts, _.findWhere(newBatchPayment.contracts, {
				id: "CardedRateEntry"
			}));
			handleContractUsedAmount();
		} else {
			newSinglePayment.usecardedratewithcontrats = false;
			$("#usedCardedRateInContractsRow").remove();
			newSinglePayment.contracts = _.without(newSinglePayment.contracts, _.findWhere(newSinglePayment.contracts, {
				id: "CardedRateEntry"
			}));
			handleContractUsedAmount();
		}
	}
}

function handleContractUsedAmount() {
	if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		var totalamount = (newBatchPayment.usedebitequivalentflag) ? newBatchPayment.debitequivalentamount : newBatchPayment.paymentamount,
			usedamount = 0,
			remainingamount,
			$span = $("<span />"),
			$remainingDiv = $("#remainingPaymentAmount");
		$remainingDiv.empty();
		if (totalamount != 0) {
			if ($("#useCardedRateFlag").attr("disabled")) {
				$("#useCardedRateFlag").attr("disabled", false).removeClass("disabled");
				$("#useCardedRateFlagLabel").removeClass("disabled");
			}
			if ($("input[data-contract-id]").size()) {
				$("input[data-contract-id]").each(function() {
					var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
					usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
				});
			}
			remainingamount = (totalamount - usedamount).toFixed(2);
			if (remainingamount < 0 && !newBatchPayment.usecardedratewithcontrats) {
				$("#useCardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
				$("#useCardedRateFlagLabel").addClass("disabled");
			}
			/* if carded rate flag is set */
			if (newBatchPayment.usecardedratewithcontrats) {
				var cardedAmount = parseFloat($("#cardedRateRow").val().replace(/[^0-9\.]+/g, "")),
					updatedCardedAmount;
				if (remainingamount > 0) {
					updatedCardedAmount = (parseFloat(remainingamount) + parseFloat(cardedAmount)).toFixed(2);
					$("#cardedRateRow").val(addCommas(updatedCardedAmount));
					remainingamount = 0;
				} else if (remainingamount < 0) {
					updatedCardedAmount = (parseFloat(cardedAmount) + parseFloat(remainingamount)).toFixed(2);
					if (updatedCardedAmount >= 0) {
						$("#cardedRateRow").val(addCommas(updatedCardedAmount));
						remainingamount = 0;
					}
				}
			}
			batchRemainingAmount = remainingamount;

			/* populate the remaining amount div */
			if (remainingamount < 0) {
				$span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(remainingamount * -1) + "</span>");
			} else if (remainingamount > 0) {
				$span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(remainingamount) + "</span>");
			} else if (remainingamount == 0) {
				$span = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i> Remaining Amount: " + addCommas(remainingamount) + "</span>");
			}
			$span.appendTo($remainingDiv);


		} else {
			newBatchPayment.usecardedratewithcontrats = false;
			$("#useCardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
			$("#useCardedRateFlagLabel").addClass("disabled");
		}
	} else {
		var totalamount = ($("#useDebitAmount").is(":checked")) ? debitEquivalentAmount : paymentAmount,
			usedamount = 0,
			remainingamount,
			$span = $("<span />"),
			$remainingDiv = $("#remainingPaymentAmount");

		$remainingDiv.empty();

		if (totalamount != 0) {

			if ($("#useCardedRateFlag").attr("disabled")) {
				$("#useCardedRateFlag").attr("disabled", false).removeClass("disabled");
				$("#useCardedRateFlagLabel").removeClass("disabled");
			}

			if ($("input[data-contract-id]").size()) {
				$("input[data-contract-id]").each(function() {
					var thisamount = parseFloat($(this).val().replace(/[^0-9\.]+/g, ""));
					usedamount = (parseFloat(usedamount) + parseFloat(thisamount));
				});
			}
			remainingamount = (totalamount - usedamount).toFixed(2);


			if (remainingamount < 0 && !newSinglePayment.usecardedratewithcontrats) {
				$("#useCardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
				$("#useCardedRateFlagLabel").addClass("disabled");
			}

			/* if carded rate flag is set */
			if (newSinglePayment.usecardedratewithcontrats) {
				var cardedAmount = parseFloat($("#cardedRateRow").val().replace(/[^0-9\.]+/g, "")),
					updatedCardedAmount;
				if (remainingamount > 0) {
					updatedCardedAmount = (parseFloat(remainingamount) + parseFloat(cardedAmount)).toFixed(2);
					$("#cardedRateRow").val(addCommas(updatedCardedAmount));
					remainingamount = 0;
				} else if (remainingamount < 0) {
					updatedCardedAmount = (parseFloat(cardedAmount) + parseFloat(remainingamount)).toFixed(2);
					if (updatedCardedAmount >= 0) {
						$("#cardedRateRow").val(addCommas(updatedCardedAmount));
						remainingamount = 0;
					}
				}
			}
			paymentRemainingAmount = remainingamount;

			/* populate the remaining amount div */
			if (remainingamount < 0) {
				$span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Over By: " + addCommas(remainingamount * -1) + "</span>");
			} else if (remainingamount > 0) {
				$span = $("<span style='color: #c91b01;'><i class='fa fa-exclamation-triangle fa-fw'></i> Remaining Amount: " + addCommas(remainingamount) + "</span>");
			} else if (remainingamount == 0) {
				$span = $("<span style='color: #009900;'><i class='fa fa-check-circle fa-fw'></i> Remaining Amount: " + addCommas(remainingamount) + "</span>");
			}
			$span.appendTo($remainingDiv);
		} else {
			newSinglePayment.usecardedratewithcontrats = false;
			$("#useCardedRateFlag").attr("disabled", true).prop("checked", false).addClass("disabled");
			$("#useCardedRateFlagLabel").addClass("disabled");
		}
	}
}

function handleChargesChanges() {
	if ($(this).val()) {
		if ($(this).closest("div.row").hasClass('error')) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
		if ($(this).hasClass("error")) {
			$(this).removeClass("error").closest("div.row").find("div.label-column").removeClass("error");
			$(this).closest("div.row").find("div.data-error").remove();
		}
	}
	newSinglePayment.charges = $(this).val();
}

function resetSinglePaymentDataEntryFiels() {
	$("#singlePaymentDetailSection, #fxSection").find(".error").removeClass("error");
	$("#singlePaymentDetailSection, #fxSection").find("div.data-error").remove();
	$("#singlePaymentDetailSection, #fxSection, #documentSection").hide();
	clearFormElements("singlePaymentDetailSection");
	$("#debitEquivalentAmountField, #paymentAmountTextValue").hide();
	$("#debitEquivalentAmountTextValue, #paymentAmountInputField").show();
	if (type == "payownaccount") {
		if (newSinglePayment.debitaccountcurrency != newSinglePayment.creditaccountcurrency) {
			$("#fxSelection").val("Carded");
			newSinglePayment.ratetype = "Carded";
		}
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		if (newSinglePayment.debitaccountcurrency != newSinglePayment.paymentcurrency) {
			$("#fxSelection").val("Carded");
			newSinglePayment.ratetype = "Carded";
		}
	}
	$("#fxContractSection").hide();
	$("#fxContractList").find("div[data-contract-row='true']").remove();
	newSinglePayment.contracts = [];
	$("#remainingPaymentAmount").empty();
	debitEquivalentFlag = false;
	rateType = false;
	cardedRate = null;
	paymentAmount = null;
	debitEquivalentAmount = null;
}

function hanldeAttachDocument() {
	$("#progressBar").show();
	$(".progress-meter").animate({
		width: "100%"
	}, 3000, function() {
		$("#progressBar").hide();
		$(".progress-meter").css("width", 0);

		var str = $("#instAttachSupportingDoc").val();
		var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);

		if (window.ActiveXObject) {
			var myFSO = new ActiveXObject("Scripting.FileSystemObject");
			var filepath = document.getElementById('instAttachSupportingDoc').value;
			var thefile = myFSO.getFile(filepath);
			var size = thefile.size;
		} else {
			var size = document.getElementById('instAttachSupportingDoc').files[0].size;
		}

		var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
		fSize = size;
		i = 0;
		while (fSize > 900) {
			fSize /= 1024;
			i++;
		}

		var filesize = (Math.round(fSize * 100) / 100) + ' ' + fSExt[i];
		var attachTimer;

		var _doc = {
			id: randString(20),
			filename: filename,
			filesize: filesize,
			status: "Performing Virus Scan"
		}
		var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />"),
			$fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
			$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell).on("click", function(e) {
				e.preventDefault();
				$(this).closest("div.data-table-row").remove();
				for (var i = 0, l = newSinglePayment.supportingdocs.length; i < l; i++) {
					if (newSinglePayment.supportingdocs[i].id == _doc.id) {
						newSinglePayment.supportingdocs.splice(i, 1);
					}
				}
				clearTimeout(attachTimer);
				if (!$("div[data-doc-row]='true'").size()) {
					$("div[data-supporting-docs='newTransfer']").hide();
				}
			}),
			$documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell),
			$statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "<i class='ellipsis-loader' /></div>").appendTo($dataTableRow);
		$dataTableRow.appendTo($("div[data-supporting-docs='newTransfer']"));
		$("div[data-supporting-docs='newTransfer']").show();
		attachTimer = setTimeout(function() {
			$documentLink.remove();
			$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($fileInfoCell);
			$statusTableCell.empty().html("Attached");
			_doc.status = "Attached";
			newSinglePayment.supportingdocs.push(_doc);
		}, 2500);
	});
}

function continuePaymentDataEntry(type) {
	step = 3;
	if (type == "payownaccount") {
		clearFormElements("singlePaymentDetailSection");
		$("#viewPaymentRecordDetails, #debitEquivalentAmountField, #paymentAmountTextValue, #purposeCodeSection, #chargesSection").hide();
		$("#debitEquivalentAmountTextValue, #paymentAmountInputField").show();
		if (newSinglePayment.debitaccountcurrency != newSinglePayment.creditaccountcurrency) {
			$("#debitEquivalentCurrency").html(selectedDebitAccount.ccy)
			$("#fxSelection").val("Carded").trigger("change");
		}
		$("#remainingPaymentAmount").empty();
		debitEquivalentFlag = false;
		rateType = false;
		cardedRate = null;
		paymentAmount = null;
		debitEquivalentAmount = null;

		/* show the single payment details section */
		$("#singlePaymentDetailSection, #documentSection").show();

		/* populate the valid payment methods */
		fetchPaymentMethods();
		$("#paymentMethodSection").hide();

		/* populate the valid payment currencies */
		fetchPaymentCurrencies();

		/* set the payment date and newSinglePayment.paymentdate to today */
		$("#paymentDateInput").datepicker("setDate", new Date());
		newSinglePayment.paymentdate = $("#paymentDateInput").val();

		$("#paymentEntryForm").animate({
			scrollTop: $("#singlePaymentDetailSection").position().top - 20
		}, 300).promise().done(function() {
			if ($("#paymentMethodSelection").val() == "") {
				$("#paymentMethodSelection").focus();
			} else {
				$("#paymentDateInput").focus();
				if (rateType == "Carded") {
					fetchCardedRates();
				}
			}
		});
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		clearFormElements("singlePaymentDetailSection");
		$("#viewPaymentRecordDetails, #debitEquivalentAmountField, #paymentAmountTextValue").hide();
		$("#debitEquivalentAmountTextValue, #paymentAmountInputField").show();
		$("#remainingPaymentAmount").empty();
		debitEquivalentFlag = false;
		rateType = false;
		cardedRate = null;
		paymentAmount = null;
		debitEquivalentAmount = null;

		/* show the single payment details section */
		$("#singlePaymentDetailSection, #documentSection").show();

		if (type == "payotherinternational") {
			$("#regulatoryReportingSection").show();
		} else {
			$("#regulatoryReportingSection").hide();
		}

		if (type == "payotherinternational") {
			$("#chargesSection").show();
		} else {
			$("#chargesSection").hide();
		}

		/* populate the valid payment methods */
		fetchPaymentMethods();
		$("#paymentMethodSection").show();

		/* populate the valid payment currencies */
		fetchPaymentCurrencies();

		/* set the payment date and newSinglePayment.paymentdate to today */
		$("#paymentDateInput").datepicker("setDate", new Date());
		newSinglePayment.paymentdate = $("#paymentDateInput").val();

		$("#paymentEntryForm").animate({
			scrollTop: $("#singlePaymentDetailSection").position().top - 20
		}, 300).promise().done(function() {
			if ($("#paymentMethodSelection").val() == "") {
				$("#paymentMethodSelection").focus();
			} else {
				$("#paymentDateInput").focus();
				if (rateType == "Carded") {
					fetchCardedRates();
				}
			}
		});
	} else if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		$("#batchPaymentSection, #closeButton, #reviewButton, #viewDivisionSelection, #viewPaymentRecordDetails").show();
		$("#cancelButton, #continueButton, #savebutton, #customDivisionSelection, #documentSection").hide();
		$("#viewDivisionSelection").html(newBatchPayment.division);
		newBatchPayment.batchid = "P" + randString(10);
		$("#viewPaymentID").html("").html(newBatchPayment.batchid);
		if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
			if (newBatchPayment.individualdebitsflag) {
				$("#fxSection").hide();
			} else {
				$("#fxSection").show();
				$("#fxSelection").val("Carded Rate");
				rateType = "Carded";
				newBatchPayment.ratetype = "Carded";
				fetchCardedRates();
				$("#fxContractRow").hide();
				$("#viewFXContractList").find("div[data-contract-row='true']").remove();
				newBatchPayment.contracts = [];
				$("#fxCardedRateRow").show();
			}
			$("#totalAmount1").empty();
			$("#totalAmount2").empty();
			if (newBatchPayment.usedebitequivalentflag) {
				var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + addCommas(newBatchPayment.paymentamount.toFixed(2)) + "</strong></div>").appendTo($("#totalAmount1"));
				$("#totalAmount1").show();
				var $totalDebiAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + addCommas(newBatchPayment.debitequivalentamount.toFixed(2)) + "</strong></div>").appendTo($("#totalAmount2"));
				$("#totalAmount2").show();
			} else {
				var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + addCommas(newBatchPayment.debitequivalentamount.toFixed(2)) + "</strong></div>").appendTo($("#totalAmount1"));
				$("#totalAmount1").show();
				var $totalDebiAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + addCommas(newBatchPayment.paymentamount.toFixed(2)) + "</strong></div>").appendTo($("#totalAmount2"));
				$("#totalAmount2").show();
			}
		} else {
			$("#fxSection").hide();
			$("#fxSection, #fxContractRow, #fxCardedRateRow").hide();
			$("#viewFXContractList").find("div[data-contract-row='true']").remove();
			rateType = "";
			newBatchPayment.ratetype = "";
			newBatchPayment.contracts = [];
			$("#totalAmount2").empty().hide();
			$("#totalAmount1").empty();
			var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + addCommas(newBatchPayment.paymentamount.toFixed(2)) + "</strong></div>").appendTo($("#totalAmount1"));
			$("#totalAmount1").show();
		}
	}
	$("#paymentEntryForm").animate({
		scrollTop: $("#batchPaymentSection").position().top - 20
	}, 300).promise().done(function() {
		$("#addPaymentsToBatch").focus();
	});
}

function reviewPaymentDetails(type) {
	step = 4;
	if (type == "payownaccount") {
		$("#reviewPaymentRecordDetails, #viewPaymentRecordDetails, #viewSelectedBeneAccount, #viewBatchDetailsSection, #viewBatchPaymentPreferences, #viewRegulatoryReportingSection, #viewBatchPaymentSection, #viewdocumentSection").hide();
		$("#viewSelectedDebitAccount, #viewSelectedCreditAccount, #viewSinglePaymentDetailSection, #viewDocumentSection, #finalSaveButton, #finalCloseButton, #previousButton, #submitButton").show();
		$("#selectedDivision").html(newSinglePayment.division);
		$("#selectedDebitAccountNumber").html(newSinglePayment.debitaccountnumber + " - " + newSinglePayment.debitaccountname + "(" + newSinglePayment.debitaccountcurrency + ")");
		var $debicon = $("<i class='fa fa-external-link fa-fw' style='margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountNumber"));
		$("#selectedDebitAccountAmount").html("$" + selectedDebitAccount.available);
		$("#selectedDebitAccountFunds").html("$" + selectedDebitAccount.availablefunds);
		if (parseFloat(selectedDebitAccount.availablefunds.replace(/[^0-9\.]+/g, "")) < parseFloat(newSinglePayment.debitequivalentamount)) {
			var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountFunds"));
		} else {
			var $icon = $("<i class='fa fa-check-circle fa-fw' style='color: #009900; margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountFunds"));
		}
		$("#selectedCreditAccountNumber").html(newSinglePayment.creditaccountnumber + " - " + newSinglePayment.creditaccountname + "(" + newSinglePayment.creditaccountcurrency + ")");
		var $credicon = $("<i class='fa fa-external-link fa-fw' style='margin-left: 5px;'></i>").appendTo($("#selectedCreditAccountNumber"));
		$("#selectedCreditAccountAmount").html("$" + selectedCreditAccount.available);
		$("#selectedCreditAccountFunds").html("$" + selectedCreditAccount.availablefunds);
		$("#selectedPaymentMethod").html(newSinglePayment.paymentmethod);
		$("#selectedPaymentMethodSection").hide();
		$("#selectedPaymentDate").html(newSinglePayment.paymentdate);
		$("#selectedPaymentCurrency").html(newSinglePayment.paymentcurrency);
		$("#selectedPaymentAmount").html(addCommas("$" + newSinglePayment.paymentamount));
		$("#selectedDebitCurrency").html(newSinglePayment.debitcurrency);
		$("#selectedDebitEquivalentAmount").html(addCommas("$" + newSinglePayment.debitequivalentamount));
		$("#selectedRateType").html(newSinglePayment.ratetype);
		$("#selectedFXRate").html(newSinglePayment.rate);
		var singleEquivalent = 1 * newSinglePayment.rate;
		var toCCY, fromCCY;
		if (newSinglePayment.usedebitequivalentflag) {
			$("#selectedUseDebitAmount").prop("checked", true);
			fromCCY = newSinglePayment.paymentcurrency;
			toCCY = newSinglePayment.debitcurrency;
		} else {
			$("#selectedUseDebitAmount").prop("checked", false);
			fromCCY = newSinglePayment.debitcurrency;
			toCCY = newSinglePayment.paymentcurrency;
		}
		var $info = $("<span style='margin-left: 10px;'> $1 " + fromCCY + " = $" + singleEquivalent + " " + toCCY + "</span>").appendTo($("#selectedFXRate"));
		if (newSinglePayment.paymentcurrency != newSinglePayment.debitcurrency) {
			$("#viewDebitEquivalentSection, #viewFXSection, #viewDebitEquivalentFlagSection").show();
		} else {
			$("#viewDebitEquivalentSection, #viewFXSection, #viewDebitEquivalentFlagSection").hide();
		}
		if (newSinglePayment.ratetype == "Carded") {
			$("#viewContractRates").hide();
			$("#viewCardedRates").show();
		} else {
			$("#viewCardedRates").hide();
			$("#viewContractRates").show();
			$("#viewFXContractList").find("div[data-contract-row='true']").remove();
			for (var i = 0, l = newSinglePayment.contracts.length; i < l; i++) {
				var contract = newSinglePayment.contracts[i],
					$row = $("<div class='data-table-row' data-contract-row='true' />"),
					$referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
					$reference = $("<span>" + contract.number + "</span>").appendTo($referencecell),
					$amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row);
				if (contract.amount != "") {
					var $amountdata = $("<span>$" + contract.amount + "</span>").appendTo($amountcell);
				} else {
					var $amountdata = $("<span>" + contract.amount + "</span>").appendTo($amountcell);
				};
				var $ratecell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
					$rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell),
					$usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
					$useramountinput = $("<span>$" + contract.used + "</span>").appendTo($usedamountcell);
				$row.appendTo($("#viewFXContractList"));
			}
		}
		$("#selectedPaymentReference").html(newSinglePayment.paymentreference);
		$("#selectedDebitAdviceDesc").val(newSinglePayment.debitadvicedescription);
		$("#selectedRemittanceInformation").val(newSinglePayment.remittanceinformation);

		$("#showSupportingDocuments").empty();

		if (newSinglePayment.supportingdocs.length) {
			var $docTable = $("<div class='data-table' data-supporting-docs='" + newSinglePayment.id + "' />"),
				$docTableRow = $("<div class='data-table-row' />").appendTo($docTable),
				$docTableCellFileName = $("<div class='data-table-cell' style='width: 100%;'>File Name</div>").appendTo($docTableRow);

			for (var i = 0, l = newSinglePayment.supportingdocs.length; i < l; i++) {
				_doc = newSinglePayment.supportingdocs[i];
				var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />").appendTo($docTable),
					$dataTableCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
					$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($dataTableCell);
			}

			$docTable.appendTo($("#showSupportingDocuments"));

		} else {
			var $noDocs = $("<div class='data-text' style='padding-top: 9px;'>No supporting documents have been uploaded.</div>").appendTo($("#showSupportingDocuments"));
		}
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		$("#reviewPaymentRecordDetails, #viewPaymentRecordDetails, #viewSelectedCreditAccount, #viewBatchDetailsSection, #viewBatchPaymentPreferences, #viewBatchPaymentSection, #viewdocumentSection").hide();
		$("#viewSelectedDebitAccount, #viewSelectedBeneAccount, #viewSinglePaymentDetailSection, #viewDocumentSection").show();
		$("#selectedDivision").html(newSinglePayment.division);
		$("#selectedDebitAccountNumber").html(newSinglePayment.debitaccountnumber);
		$("#selectedDebitAccountName").html(newSinglePayment.debitaccountname);
		$("#selectedDebitAccountCurrency").html("(" + newSinglePayment.debitaccountcurrency + ")");
		$("#selectedDebitAccountAmount").html("$" + selectedDebitAccount.available);
		if (parseFloat(selectedDebitAccount.available.replace(/[^0-9\.]+/g, "")) < parseFloat(newSinglePayment.debitequivalentamount)) {
			var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountAmount"));
		} else {
			var $icon = $("<i class='fa fa-check-circle fa-fw' style='color: #009900; margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountAmount"));
		}
		$("#selectedBeneficiaryName").html(newSinglePayment.beneficiaryname);
		$("#selectedBeneAccountNumber").html(newSinglePayment.beneficiaryaccountnumber);
		if (newSinglePayment.beneficiarylocalname) {
			$("#selectedBeneLocalLanguageField").show();
		} else {
			$("#selectedBeneLocalLanguageField").hide();
		}
		$("#selectedBeneLocalLanguageName").html(newSinglePayment.beneficiarylocalname);
		$("#selectedBeneBankName").html(newSinglePayment.beneficiarybankname);
		$("#selectedBeneBankBranchName").html(newSinglePayment.beneficiarybranchname);
		$("#selectedBeneBankCountry").html(newSinglePayment.beneficiarybankcountry);
		$("#selectedBeneClearing").html(newSinglePayment.beneficiaryaccountclearingcode);
		$("#selectedPaymentMethod").html(newSinglePayment.paymentmethod);
		$("#selectedPaymentMethodSection").show();
		$("#selectedPaymentDate").html(newSinglePayment.paymentdate);
		$("#selectedPaymentCurrency").html(newSinglePayment.paymentcurrency);
		$("#selectedPaymentAmount").html(addCommas("$" + newSinglePayment.paymentamount));
		$("#selectedDebitCurrency").html(newSinglePayment.debitcurrency);
		$("#selectedDebitEquivalentAmount").html(addCommas("$" + newSinglePayment.debitequivalentamount));
		$("#selectedRateType").html(newSinglePayment.ratetype);
		$("#selectedFXRate").html(newSinglePayment.rate);
		var singleEquivalent = 1 * newSinglePayment.rate;
		var toCCY, fromCCY;
		if (newSinglePayment.usedebitequivalentflag) {
			$("#selectedUseDebitAmount").prop("checked", true);
			fromCCY = newSinglePayment.paymentcurrency;
			toCCY = newSinglePayment.debitcurrency;
		} else {
			$("#selectedUseDebitAmount").prop("checked", false);
			fromCCY = newSinglePayment.debitcurrency;
			toCCY = newSinglePayment.paymentcurrency;
		}
		var $info = $("<span style='margin-left: 10px;'> $1 " + toCCY + " = $" + singleEquivalent + " " + fromCCY + "</span>").appendTo($("#selectedFXRate"));
		if (newSinglePayment.paymentcurrency != newSinglePayment.debitcurrency) {
			$("#viewDebitEquivalentSection, #viewFXSection, #viewDebitEquivalentFlagSection").show();
		} else {
			$("#viewDebitEquivalentSection, #viewFXSection, #viewDebitEquivalentFlagSection").hide();
		}
		if (newSinglePayment.ratetype == "Carded") {
			$("#viewContractRates").hide();
			$("#viewCardedRates").show();
		} else {
			$("#viewCardedRates").hide();
			$("#viewContractRates").show();
			$("#viewFXContractList").find("div[data-contract-row='true']").remove();
			for (var i = 0, l = newSinglePayment.contracts.length; i < l; i++) {
				var contract = newSinglePayment.contracts[i],
					$row = $("<div class='data-table-row' data-contract-row='true' />"),
					$referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
					$reference = $("<span>" + contract.number + "</span>").appendTo($referencecell),
					$amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row);
				if (contract.amount != "") {
					var $amountdata = $("<span>$" + contract.amount + "</span>").appendTo($amountcell);
				} else {
					var $amountdata = $("<span>" + contract.amount + "</span>").appendTo($amountcell);
				};
				var $ratecell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
					$rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell),
					$usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
					$useramountinput = $("<span>$" + contract.used + "</span>").appendTo($usedamountcell);
				$row.appendTo($("#viewFXContractList"));
			}
		}
		$("#selectedPaymentReference").html(newSinglePayment.paymentreference);
		$("#selectedDebitAdviceDesc").val(newSinglePayment.debitadvicedescription);
		$("#selectedRemittanceInformation").val(newSinglePayment.remittanceinformation);
		if (newSinglePayment.purposecode) {
			$("#selectedPurposeCode").html(newSinglePayment.purposecode)
			$("#viewPurposeCodeSection").show();
		} else {
			$("#selectedPurposeCode").html("");
			$("#viewPurposeCodeSection").hide();
		}
		if (newSinglePayment.charges) {
			$("#selectedCharges").html(newSinglePayment.charges)
			$("#viewChargesSection").show();
		} else {
			$("#selectedCharges").html("");
			$("#viewChargesSection").hide();
		}

		if (type == "payotherinternational") {
			$("#viewRegulatoryReportingSection").show();
			$("#viewBopPriority").html(newSinglePayment.bopPriority);
			$("#viewBopAmountInWords").html(newSinglePayment.bopAmountInWords);
			$("#viewBopUnitCode").html(newSinglePayment.bopUnitCode);
			$("#viewBopResidentRegionName").html(newSinglePayment.bopResidentRegionName);
			$("#viewBopResidentRegionCode").html(newSinglePayment.bopResidentRegionCode);
			$("#viewBopField1").html(newSinglePayment.bopField1);
			$("#viewBopField2").html(newSinglePayment.bopField2);
			$("#viewBopField3").html(newSinglePayment.bopField3);
			$("#viewBopField4").html(newSinglePayment.bopField4);
			$("#viewBopField5").html(newSinglePayment.bopField5);
			$("#viewBop1TransCode").html(newSinglePayment.bop1TransCode);
			$("#viewBop1TransDesc").html(newSinglePayment.bop1TransDesc);
			$("#viewBop1CCY").html(newSinglePayment.bop1CCY);
			$("#viewBop1Amount").html(newSinglePayment.bop1Amount);
			$("#viewBop2TransCode").html(newSinglePayment.bop2TransCode);
			$("#viewBop2TransDesc").html(newSinglePayment.bop2TransDesc);
			$("#viewBop2CCY").html(newSinglePayment.bop2CCY);
			$("#viewBop2Amount").html(newSinglePayment.bop2Amount);
			$("#viewBopContractNumber").html(newSinglePayment.bopContractNumber);
			$("#viewBopInvoiceNumber").html(newSinglePayment.bopInvoiceNumber);
		} else {
			$("#viewRegulatoryReportingSection").hide();
		}
	} else if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		$("#viewSelectedDebitAccount, #viewSelectedBeneAccount, #viewSelectedCreditAccount, #viewSinglePaymentDetailSection, #viewFXSection, #viewRegulatoryReportingSection, #viewDocumentSection, #finalSaveButton").hide();
		$("#viewSelectedDebitAccount, #viewBatchDetailsSection, #viewBatchPaymentPreferences, #viewBatchPaymentSection, #reviewPaymentRecordDetails, #finalCloseButton, #previousButton, #submitButton").show();
		$("#reviewPaymentID").html("").html(newBatchPayment.batchid);
		reviewData = newBatchPayment.payments;
		reviewDataView.setItems(editBatchData);
		reviewGrid.invalidateAllRows();
		reviewGrid.render();
		$("#selectedDivision").html(newBatchPayment.division);
		$("#selectedDebitAccountNumber").html(newBatchPayment.debitaccountnumber + " - " + newBatchPayment.debitaccountname + " (" + newBatchPayment.debitaccountcurrency + ")");
		var $debicon = $("<i class='fa fa-external-link fa-fw' style='margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountNumber"));
		$("#selectedDebitAccountAmount").html("").html("$" + selectedDebitAccount.available);
		$("#selectedDebitAccountFunds").html("").html("$" + selectedDebitAccount.availablefunds);
		if (parseFloat(selectedDebitAccount.available.replace(/[^0-9\.]+/g, "")) < parseFloat(newBatchPayment.debitequivalentamount)) {
			var $icon = $("<i class='fa fa-exclamation-triangle fa-fw' style='color: #c91b01; margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountFunds"));
		} else {
			var $icon = $("<i class='fa fa-check-circle fa-fw' style='color: #009900; margin-left: 5px;'></i>").appendTo($("#selectedDebitAccountFunds"));
		}
		$("#viewBatchNameField").html(newBatchPayment.name);
		$("#viewBatchReferenceField").html(newBatchPayment.paymentreference);
		$("#viewBatchPaymentDateField").html(newBatchPayment.paymentdate);
		$("#viewBatchPaymentCurrencyField").html(newBatchPayment.paymentcurrency);
		if (newBatchPayment.individualdebitsflag) {
			$("#viewIndividualDebitsFlag").prop("checked", true);
		} else {
			$("#viewIndividualDebitsFlag").prop("checked", false);
		}
		if (newBatchPayment.urgentflag) {
			$("#viewUrgentFlag").prop("checked", true);
		} else {
			$("#viewUrgentFlag").prop("checked", false);
		}
		if (newBatchPayment.usedebitequivalentflag) {
			$("#viewBatchDebitEquivalentFlag").prop("checked", true);
		} else {
			$("#viewBatchDebitEquivalentFlag").prop("checked", false);
		}
		if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
			$("#viewBatchDebitEquivalentFlag, #viewBatchDebitEquivalenLabel").show();
			if (newBatchPayment.individualdebitsflag) {
				$("#viewFXSection").hide();
			} else {
				$("#viewFXSection").show();
				$("#selectedRateType").html(newBatchPayment.ratetype);
				if (newBatchPayment.ratetype == "Carded") {
					$("#viewCardedRates").show();
					$("#viewContractRates").hide();
					$("#selectedFXRate").html(newBatchPayment.rate);
					var singleEquivalent = 1 * newBatchPayment.rate;
					var toCCY, fromCCY;
					if (newBatchPayment.usedebitequivalentflag) {
						fromCCY = newBatchPayment.debitaccountcurrency;
						toCCY = newBatchPayment.paymentcurrency;
					} else {
						fromCCY = newBatchPayment.paymentcurrency;
						toCCY = newBatchPayment.debitaccountcurrency;
					}
					var $info = $("<span style='margin-left: 10px;'> $1 " + fromCCY + " = $" + singleEquivalent + " " + toCCY + "</span>").appendTo($("#selectedFXRate"));
				} else if (newBatchPayment.ratetype == "Contract") {
					$("#viewCardedRates").hide();
					$("#viewContractRates").show();
					$("#viewFXContractList").find("div[data-contract-row='true']").remove();
					for (var i = 0, l = newBatchPayment.contracts.length; i < l; i++) {
						var contract = newBatchPayment.contracts[i],
							$row = $("<div class='data-table-row' data-contract-row='true' />"),
							$referencecell = $("<div class='data-table-cell' style='width: 25%;' />").appendTo($row),
							$reference = $("<span>" + contract.number + "</span>").appendTo($referencecell),
							$amountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row);
						if (contract.amount != "") {
							var $amountdata = $("<span>$" + contract.amount + "</span>").appendTo($amountcell);
						} else {
							var $amountdata = $("<span>" + contract.amount + "</span>").appendTo($amountcell);
						};
						var $ratecell = $("<div class='data-table-cell' style='width: 20%; text-align: right;' />").appendTo($row),
							$rate = $("<span>" + contract.rate + "</span>").appendTo($ratecell),
							$usedamountcell = $("<div class='data-table-cell' style='width: 20%; text-align: right;'>").appendTo($row),
							$useramountinput = $("<span>$" + contract.used + "</span>").appendTo($usedamountcell);
						$row.appendTo($("#viewFXContractList"));
					}
				}
			}
			$("#reviewTotalAmount1").empty();
			$("#reviewTotalAmount2").empty();
			if (newBatchPayment.usedebitequivalentflag) {
				var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + newBatchPayment.paymentamount.toFixed(2) + "</strong></div>").appendTo($("#reviewTotalAmount1"));
				$("#reviewTotalAmount1").show();
				var $totalDebiAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + newBatchPayment.debitequivalentamount.toFixed(2) + "</strong></div>").appendTo($("#reviewTotalAmount2"));
				$("#reviewTotalAmount2").show();
			} else {
				var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + newBatchPayment.debitequivalentamount.toFixed(2) + "</strong></div>").appendTo($("#reviewTotalAmount1"));
				$("#reviewTotalAmount1").show();
				var $totalDebiAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + newBatchPayment.paymentamount.toFixed(2) + "</strong></div>").appendTo($("#reviewTotalAmount2"));
				$("#reviewTotalAmount2").show();
			}
		} else {
			$("#reviewTotalAmount1").empty();
			var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + newBatchPayment.paymentamount.toFixed(2) + "</strong></div>").appendTo($("#reviewTotalAmount1"));
			$("#reviewTotalAmount1").show();
			$("#reviewTotalAmount2").empty().hide();
		}

	}
	$("#paymentScreen").find("div[data-step='select'], div[data-step='enter']").addClass("hidden");
	$("#paymentScreen").find("div[data-step='review']").removeClass("hidden").find("#reviewPaymentDetails").scrollTop(0);
	if ($(".ie8").size() > 0) {
		$("body").find(".fa").addClass("repaint");
		setTimeout(function() {
			$("body").find(".fa").removeClass("repaint");
		}, 1)
	}
}

function paymentNextStep() {
	var validationFailed = false,
		continueFunction;

	if (type == "payownaccount") {
		if (step == 2) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#creditAccountInput").val()) {
				validationFailed = true;
				var $row = $("#creditAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#creditAccountInput").closest("div.data-column")).html("Credit Account is a required field");
				}
			}
			continueFunction = function() {
				continuePaymentDataEntry(type)
			}
		} else if (step == 3) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#creditAccountInput").val()) {
				validationFailed = true;
				var $row = $("#creditAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#creditAccountInput").closest("div.data-column")).html("Credit Account is a required field");
				}
			}
			if (!$("#paymentCurrencySelect").val() && (!$("#paymentAmountInputField").val() || $("#paymentAmountInputField").val() == 0.00)) {
				validationFailed = true;
				var $row = $("#paymentCurrencySelect").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Currency and Payment Amount are required fields");
				}
			}
			if ($("#paymentCurrencySelect").val() && (!$("#paymentAmountInputField").val() || $("#paymentAmountInputField").val() == 0.00)) {
				if ($("#useDebitAmount").prop("checked")) {
					if (!$("#debitEquivalentAmountField").val()) {
						validationFailed = true;
						var $row = $("#debitEquivalentAmountField").closest("div.row");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
							$("<div class='data-error' />").appendTo($row.children("div.data-column")).html("Debit Equivalent Amount is required");
						}
					} else if ($("#debitEquivalentAmountField").val() == 0.00) {
						validationFailed = true;
						var $row = $("#debitEquivalentAmountField").closest("div.row");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
							$("<div class='data-error' />").appendTo($row.children("div.data-column")).html("Debit Equivalent Amount must be more than 0.00");
						}
					}
				} else {
					if (!$("#paymentAmountInputField").val()) {
						validationFailed = true;
						if (!$("#paymentAmountInputField").hasClass("error")) {
							$("#paymentAmountInputField").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
							$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Amount is a required field");
						}
					} else if ($("#paymentAmountInputField").val() == 0.00) {
						validationFailed = true;
						if (!$("#paymentAmountInputField").hasClass("error")) {
							$("#paymentAmountInputField").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
							$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Amount must be more than 0.00");
						}
					}
				}
			}
			if (!$("#paymentCurrencySelect").val() && $("#paymentAmountInputField").val()) {
				validationFailed = true;
				if (!$("#paymentCurrencySelect").closest("div.custom-select").hasClass("error")) {
					$("#paymentCurrencySelect").closest("div.custom-select").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Currency is a required field");
				}
			}
			if ($("#fxSelection").val() == "Contract") {
				if (paymentRemainingAmount != 0) {
					validationFailed = true;
				}
			}
			if (!$("#paymentDateInput").val()) {
				validationFailed = true;
				var $row = $("#paymentDateInput").closest("div.row"),
					$dataCol = $("#paymentDateInput").closest("div.data-column");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
				}
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Payment Date is a required field")
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is a required field");
				}
			} else {
				var stringval = $("#paymentDateInput").val(),
					testdate;
				try {
					testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
				} catch (e) {
					validationFailed = true;
					var $row = $("#paymentDateInput").closest("div.row"),
						$dataCol = $("#paymentDateInput").closest("div.data-column");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
					}
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Payment Date is not valid")
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is not valid");
					}
				} finally {
					if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
						validationFailed = true;
						var $row = $("#paymentDateInput").closest("div.row"),
							$dataCol = $("#paymentDateInput").closest("div.data-column");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
						}
						if ($row.find("div.data-error").size()) {
							$row.find("div.data-error").html("Payment Date cannot be in the past")
						} else {
							$("<div class='data-error' />").appendTo($dataCol).html("Payment Date cannot be in the past");
						}
					}
				}
			}
			if (!$("#paymentReference").val()) {
				validationFailed = true;
				var $row = $("#paymentReference").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentReference").closest("div.data-column")).html("Payment Reference is a required field");
				}
			}
			continueFunction = function() {
				reviewPaymentDetails(type)
			}
		}
	} else if (type == "payotherdomestic" || type == "payotherinternational") {
		if (step == 2) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#beneInput").val()) {
				validationFailed = true;
				var $row = $("#beneInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#beneInput").closest("div.data-column")).html("Beneficiary selection is a required");
				}
			}
			continueFunction = function() {
				continuePaymentDataEntry(type)
			}
		} else if (step == 3) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#beneInput").val()) {
				validationFailed = true;
				var $row = $("#beneInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#beneInput").closest("div.data-column")).html("Beneficiary selection is a required");
				}
			}
			if (!$("#paymentMethodSelection").val()) {
				validationFailed = true;
				var $row = $("#paymentMethodSelection").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentMethodSelection").closest("div.data-column")).html("Payment Method is a required field");
				}
			}
			if (!$("#paymentCurrencySelect").val() && (!$("#paymentAmountInputField").val() || $("#paymentAmountInputField").val() == 0.00)) {
				validationFailed = true;
				var $row = $("#paymentCurrencySelect").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Currency and Payment Amount are required fields");
				}
			}
			if ($("#paymentCurrencySelect").val() && (!$("#paymentAmountInputField").val() || $("#paymentAmountInputField").val() == 0.00)) {
				if ($("#useDebitAmount").prop("checked")) {
					if (!$("#debitEquivalentAmountField").val()) {
						validationFailed = true;
						var $row = $("#debitEquivalentAmountField").closest("div.row");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
							$("<div class='data-error' />").appendTo($row.children("div.data-column")).html("Debit Equivalent Amount is required");
						}
					} else if ($("#debitEquivalentAmountField").val() == 0.00) {
						validationFailed = true;
						var $row = $("#debitEquivalentAmountField").closest("div.row");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
							$("<div class='data-error' />").appendTo($row.children("div.data-column")).html("Debit Equivalent Amount must be more than 0.00");
						}
					}
				} else {
					if (!$("#paymentAmountInputField").val()) {
						validationFailed = true;
						if (!$("#paymentAmountInputField").hasClass("error")) {
							$("#paymentAmountInputField").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
							$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Amount is a required field");
						}
					} else if ($("#paymentAmountInputField").val() == 0.00) {
						validationFailed = true;
						if (!$("#paymentAmountInputField").hasClass("error")) {
							$("#paymentAmountInputField").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
							$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Amount must be more than 0.00");
						}
					}
				}
			}
			if (!$("#paymentCurrencySelect").val() && $("#paymentAmountInputField").val()) {
				validationFailed = true;
				if (!$("#paymentCurrencySelect").closest("div.custom-select").hasClass("error")) {
					$("#paymentCurrencySelect").closest("div.custom-select").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Currency is a required field");
				}
			}
			if ($("#fxSelection").val() == "Contract") {
				if (paymentRemainingAmount != 0) {
					validationFailed = true;
				}
			}
			if (!$("#paymentDateInput").val()) {
				validationFailed = true;
				var $row = $("#paymentDateInput").closest("div.row"),
					$dataCol = $("#paymentDateInput").closest("div.data-column");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
				}
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Payment Date is a required field")
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is a required field");
				}
			} else {
				var stringval = $("#paymentDateInput").val(),
					testdate;
				try {
					testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
				} catch (e) {
					validationFailed = true;
					var $row = $("#paymentDateInput").closest("div.row"),
						$dataCol = $("#paymentDateInput").closest("div.data-column");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
					}
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Payment Date is not valid")
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is not valid");
					}
				} finally {
					if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
						validationFailed = true;
						var $row = $("#paymentDateInput").closest("div.row"),
							$dataCol = $("#paymentDateInput").closest("div.data-column");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
						}
						if ($row.find("div.data-error").size()) {
							$row.find("div.data-error").html("Payment Date cannot be in the past")
						} else {
							$("<div class='data-error' />").appendTo($dataCol).html("Payment Date cannot be in the past");
						}
					}
				}
			}
			if (!$("#paymentReference").val()) {
				validationFailed = true;
				var $row = $("#paymentReference").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentReference").closest("div.data-column")).html("Payment Reference is a required field");
				}
			}
			if (type == "payotherdomestic" && (newSinglePayment.paymentmethod == "BEPS" || newSinglePayment.paymentmethod == "DHVPS" || newSinglePayment.paymentmethod == "CBHVPS")) {
				if (!$("#purposeCodeSelection").val()) {
					validationFailed = true;
					var $row = $("#purposeCodeSelection").closest("div.row");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
						$("<div class='data-error' />").appendTo($("#purposeCodeSelection").closest("div.data-column")).html("Purpose Code is a required field");
					}
				}
			}
			if (type == "payotherinternational") {
				if (!$("#chargesSelection").val()) {
					validationFailed = true;
					var $row = $("#chargesSelection").closest("div.row");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
						$("<div class='data-error' />").appendTo($("#chargesSelection").closest("div.data-column")).html("Charges is a required field");
					}
				}
			}
			continueFunction = function() {
				reviewPaymentDetails(type)
			}
		}
	} else if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
		if (step == 2) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#batchNameInput").val()) {
				validationFailed = true;
				var $row = $("#batchNameInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#batchNameInput").closest("div.data-column")).html("Payment Name is a required field");
				}
			}
			if (!$("#batchReferenceInput").val()) {
				validationFailed = true;
				var $row = $("#batchReferenceInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#batchReferenceInput").closest("div.data-column")).html("Payment Reference is a required field");
				}
			}
			if (!$("#batchPaymentDateInput").val()) {
				validationFailed = true;
				var $row = $("#batchPaymentDateInput").closest("div.row"),
					$dataCol = $("#batchPaymentDateInput").closest("div.data-column");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
				}
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Value Date is a required field")
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Value Date is a required field");
				}
			} else {
				var stringval = $("#batchPaymentDateInput").val(),
					testdate;
				try {
					testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
				} catch (e) {
					validationFailed = true;
					var $row = $("#batchPaymentDateInput").closest("div.row"),
						$dataCol = $("#batchPaymentDateInput").closest("div.data-column");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
					}
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Value Date is not valid")
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Value Date is not valid");
					}
				} finally {
					if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
						validationFailed = true;
						var $row = $("#batchPaymentDateInput").closest("div.row"),
							$dataCol = $("#batchPaymentDateInput").closest("div.data-column");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
						}
						if ($row.find("div.data-error").size()) {
							$row.find("div.data-error").html("Value Date cannot be in the past")
						} else {
							$("<div class='data-error' />").appendTo($dataCol).html("Value Date cannot be in the past");
						}
					}
				}
			}
			if (!$("#individualDebitsFlag").prop("checked")) {
				if (!$("#batchPaymentCurrencySelection").val()) {
					validationFailed = true;
					var $row = $("#batchPaymentCurrencySelection").closest("div.row");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
						$("<div class='data-error' />").appendTo($("#batchPaymentCurrencySelection").closest("div.data-column")).html("Payment Currency is a required field");
					}
				}
			}
			continueFunction = function() {
				continuePaymentDataEntry(type)
			}
		} else if (step == 3) {
			if (!$("#batchNameInput").val()) {
				validationFailed = true;
				var $row = $("#batchNameInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#batchNameInput").closest("div.data-column")).html("Payment Name is a required field");
				}
			}
			if (!$("#batchReferenceInput").val()) {
				validationFailed = true;
				var $row = $("#batchReferenceInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#batchReferenceInput").closest("div.data-column")).html("Payment Reference is a required field");
				}
			}
			if ($("#fxSelection").val() == "Contract") {
				if (batchRemainingAmount != 0) {
					validationFailed = true;
				}
			}
			if (!$("#batchPaymentDateInput").val()) {
				validationFailed = true;
				var $row = $("#batchPaymentDateInput").closest("div.row"),
					$dataCol = $("#batchPaymentDateInput").closest("div.data-column");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
				}
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Value Date is a required field")
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Value Date is a required field");
				}
			} else {
				var stringval = $("#batchPaymentDateInput").val(),
					testdate;
				try {
					testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
				} catch (e) {
					validationFailed = true;
					var $row = $("#batchPaymentDateInput").closest("div.row"),
						$dataCol = $("#batchPaymentDateInput").closest("div.data-column");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
					}
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Value Date is not valid")
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Value Date is not valid");
					}
				} finally {
					if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
						validationFailed = true;
						var $row = $("#batchPaymentDateInput").closest("div.row"),
							$dataCol = $("#batchPaymentDateInput").closest("div.data-column");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
						}
						if ($row.find("div.data-error").size()) {
							$row.find("div.data-error").html("Value Date cannot be in the past")
						} else {
							$("<div class='data-error' />").appendTo($dataCol).html("Value Date cannot be in the past");
						}
					}
				}
			}
			for (var x = 0, y = newBatchPayment.payments.length; x < y; x++) {
				if (newBatchPayment.payments[x].validated == false) {
					validationFailed = true;
					break;
				}
			}
			continueFunction = function() {
				reviewPaymentDetails(type)
			}
		}
	}

	if (!validationFailed) {
		var validationSuccess = function() {
			$(document.activeElement).blur();
			$("#paymentScreen").addClass("working");
			if ($("div.error-notification").size()) {
				$("div.error-notification").remove();
			}
			setTimeout(function() {
				$("#paymentScreen").removeClass("working");
				if ($(".ie8").size() > 0) {
					$("body").find(".fa").addClass("repaint");
					setTimeout(function() {
						$("body").find(".fa").removeClass("repaint");
					}, 1);
				}
				continueFunction();
			}, 1000);
		}
		if (step == 3) {
			if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
				if (parseFloat(selectedDebitAccount.available.replace(/[^0-9\.]+/g, "")) < parseFloat(newBatchPayment.debitequivalentamount)) {
					buildConfirmDialog("The available balance of the seleced debit account is insufficient.", "Do you still want to proceed?", validationSuccess, "primary");
				} else {
					validationSuccess();
				}
			} else {
				if (parseFloat(selectedDebitAccount.available.replace(/[^0-9\.]+/g, "")) < parseFloat(newSinglePayment.debitequivalentamount)) {
					buildConfirmDialog("The available balance of the seleced debit account is insufficient.", "Do you still want to proceed?", validationSuccess, "primary");
				} else {
					validationSuccess();
				}
			}
		} else {
			validationSuccess();
		}
	} else {
		if (!$("div.error-notification").size()) {
			buildErrorNotification("Errors Were Detected", "Some errors were detected. Please review the form below and correct any items with error messages.", 100);
		}
	}
}

function previousStepFunction(e) {
	e.preventDefault();
	if (step == 2 || step == 3) {
		$("#paymentScreen").addClass("loading");
		$("#paymentEntryForm").find(".error").removeClass("error");
		$("#paymentEntryForm").find("div.data-error").remove();
		if ($("div.error-notification").size()) {
			$("div.error-notification").remove();
		}
		setTimeout(function() {
			step = 1;
			$("#paymentScreen").removeClass("loading");
			$("#paymentScreen").find("div[data-step='enter']").addClass("hidden");
			$("#paymentScreen").find("div[data-step='select']").removeClass("hidden").scrollTop(0);
			$("#singlePaymentDetailSection, #fxSection").hide();
			$("#debitAccountDetailSection, #creditAccountDetailSection, #beneficiaryDetailsSection").hide();
			resetPaymentData();
			if ($(".ie8").size() > 0) {
				$("body").find(".fa").addClass("repaint");
				setTimeout(function() {
					$("body").find(".fa").removeClass("repaint");
				}, 1)
			}
		}, 500);
	} else if (step == 4) {
		$("#paymentScreen").addClass("working");
		setTimeout(function() {
			step = 3;
			$("#paymentScreen").removeClass("working");
			$("#paymentScreen").find("div[data-step='select'], div[data-step='review']").addClass("hidden");
			$("#paymentScreen").find("div[data-step='enter']").removeClass("hidden").find("#paymentEntryForm").scrollTop(0);
			if ($(".ie8").size() > 0) {
				$("body").find(".fa").addClass("repaint");
				setTimeout(function() {
					$("body").find(".fa").removeClass("repaint");
				}, 1)
			}
		}, 500);
	}
}

function cancelPaymentFunction(e) {
	e.preventDefault();
	buildConfirmDialog("You will lose all details provided for this payment. Do you want to proceed?", "", function() {
		$("#paymentScreen").addClass("loading");
		$("#paymentEntryForm").find(".error").removeClass("error");
		$("#paymentEntryForm").find("div.data-error").remove();
		if ($("div.error-notification").size()) {
			$("div.error-notification").remove();
		}
		setTimeout(function() {
			step = 1;
			$("#paymentScreen").find("div[data-step='enter']").addClass("hidden");
			$("#paymentScreen").find("div[data-step='select']").removeClass("hidden").scrollTop(0);
			$("#singlePaymentDetailSection, #fxSection, #documentSection, #regulatoryReportingSection, #debitAccountDetailSection, #creditAccountDetailSection, #beneficiaryDetailsSection").hide();
			$("#debitAccountAvailableBalance, #debitAccountAvailableFunds, #creditAccountAvailableBalance, #creditAccountAvailableFunds").html("");
			$("#paymentScreen").removeClass("loading");
			resetPaymentData();
			if ($(".ie8").size() > 0) {
				$("body").find(".fa").addClass("repaint");
				setTimeout(function() {
					$("body").find(".fa").removeClass("repaint");
				}, 1)
			}
		}, 500);
	}, "primary");
}

function closePayment(e) {
	e.preventDefault();
	$("#paymentScreen").addClass("working");
	setTimeout(function() {
		document.location.href = "payments-summary.html";
	}, 500);
}

function closeBatchPayment(e) {
	e.preventDefault();
	buildConfirmDialog("Continue without saving the changes to this payment?", "", function() {
		$("#paymentScreen").addClass("loading");
		setTimeout(function() {
			document.location.href = "payments-summary.html";
		}, 500);
	}, "primary");
}

function showPaymentTemplateDialog(e) {

	e.preventDefault();

	function confirmTemplateCreation(_dialog) {
		$("#createTemplateDialog").addClass("working");
		setTimeout(function() {
			buildCustomDialog([{
				text: "Template Name: " + $("#templateName").val(),
				style: "color: #007dba; font-weight: bold;"
			}, {
				text: "Payment template has been successfully created.",
				style: ""
			}], [{
				title: "Ok",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
				}
			}, {
				title: "View This Template",
				class: "",
				action: function(e) {
					e.preventDefault();
					closeCustomDialog(e);
					setTimeout(function() {
						document.location.href = "payments-templates.html#detail";
					}, 500);
				}
			}]);
			dialogHider(_dialog);
		}, 1000);
	}

	var populateTemplateCreationDialog = function() {
		var $dialogContent = $("<div class='data-form top-label' id='templateDialogContent' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row mandatory' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateName' style='width: 90%;' value='My Payment Template' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Template Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='templateDesc' style='width: 90%;' />").appendTo($dataCol);
		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "createTemplateDialog",
		title: "Create A Template From This Payment",
		size: "xsmall",
		icon: "<i class='fa fa-clipboard'></i>",
		content: function() {
			return populateTemplateCreationDialog()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					confirmTemplateCreation(_dialog);
				}
			}],
			attributes: [{
				name: "id",
				value: "createTemplateButton"
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#templateName").focus();
}

function showPaymentDetailReportDialog(e) {

	e.preventDefault();

	function downloadReport(_dialog) {
		$("#detailReportDialog").addClass("working");
		setTimeout(function() {
			dialogHider(_dialog);
			buildConfirmDialog("Your report has taken longer than 3 seconds to generate.", "It will be available for download in the &quot;Download Reports&quot; section shortly.", "");
		}, 3000);
	};

	var populateRequestDetailReport = function() {
		var $dialogContent = $("<div class='data-form' />"),
			$formSection = $("<div class='form-section' />").appendTo($dialogContent),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Format</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 90%;' />").appendTo($dataCol),
			$data = $("<select id='repFormat'><option value='CSV'>CSV</option><option value='PDF'>PDF</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Encoding</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 90%;' />").appendTo($dataCol),
			$data = $("<select id='repEncoding'><option value='ASCII'>ASCII</option><option value='Unicode'>Unicode</option><option value='UTF-8'>UTF-8</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Language</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$customSelect = $("<div class='custom-select' style='width: 90%;' />").appendTo($dataCol),
			$data = $("<select id='repLanguage'><option value='English'>English</option><option value='Chinese (Simplified)'>Chinese (Simplified)</option><option value='Chinese (Traditional)'>Chinese (Traditional)</option></select>").appendTo($customSelect),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Name</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<input type='text' id='repName' value='' style='width: 90%;' />").appendTo($dataCol),
			$row = $("<div class='row' />").appendTo($formSection),
			$labelCol = $("<div class='label-column' />").appendTo($row),
			$label = $("<label>Report Description</label>").appendTo($labelCol),
			$dataCol = $("<div class='data-column' />").appendTo($row),
			$data = $("<textarea id='repDescription' style='width: 90%;'></textarea>").appendTo($dataCol);

		return $dialogContent;
	}

	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "detailReportDialog",
		title: "Payment Detail Report",
		size: "small",
		icon: "<i class='fa fa-file-text'></i>",
		content: function() {
			return populateRequestDetailReport()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog);
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					downloadReport(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function showSubmitPaymentDialog() {

	var submitPaymentDialogContent = function(_dialog) {
		var $dialogContent = $("<div class='dialog-content' />"),
			$customDialog = $("<div style='padding: 20px; text-align: center;' />").appendTo($dialogContent),
			$customMessageDiv = $("<div class='custom-message' />").appendTo($customDialog);
		if (newSinglePayment.id != "") {
			var $heading = $("<p style='color: #007dba; font-weight: bold;'>Payment Reference: " + newSinglePayment.id + "</p>").appendTo($customMessageDiv);
		} else {
			var $heading = $("<p style='color: #007dba; font-weight: bold;'>Payment Reference: " + newBatchPayment.id + "</p>").appendTo($customMessageDiv);
		}
		var $message = $("<p>This payment has successfully been submitted for approval.</p>").appendTo($customMessageDiv),
			$customButtonDiv = $("<div class='custom-buttons' />").appendTo($customDialog),
			$okSpan = $("<span class='form-button' />").appendTo($customButtonDiv),
			$okButton = $("<a href='javascript:void(0)'>Ok</a>").on("click", function(e) {
				e.preventDefault();
				dialogHider(_dialog);
				setTimeout(function() {
					document.location.href = 'payments-summary.html';
				}, 500);
			}).appendTo($okSpan),
			$viewSpan = $("<span class='form-button' />").appendTo($customButtonDiv),
			$viewButton = $("<a href='javascript:void(0)'>View This Payment</a>").on("click", function(e) {
				e.preventDefault();
				dialogHider(_dialog);
				setTimeout(function() {
					document.location.href = 'payments-summary.html#detail';
				}, 500);
			}).appendTo($viewSpan),
			$createSpan = $("<span class='form-button primary' />").appendTo($customButtonDiv),
			$createButton = $("<a href='javascript:void(0)'>Create A Template From This Payment</a>").on("click", showPaymentTemplateDialog).appendTo($createSpan),
			$requestSpan = $("<span class='form-button primary' />").appendTo($customButtonDiv),
			$requestButton = $("<a href='javascript:void(0)'>Request A Payment Detail Report</a>").on("click", showPaymentDetailReportDialog).appendTo($requestSpan);

		return $dialogContent;
	}

	var _origin = $("a[data-action='submitPayment']");
	var _dialog = {
		id: "submitPaymentDialog",
		title: "Payment Successfully Submitted",
		size: "small",
		icon: "<i class='fa fa-check'></i>",
		closeAction: function() {
			setTimeout(function() {
				document.location.href = 'payments-summary.html';
			}, 500);
		},
		content: function() {
			return submitPaymentDialogContent(_dialog)
		}
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

function confirmSubmitPayment(e) {
	e.preventDefault();
	buildConfirmDialog("Do you want to submit this payment for approval?", "", function() {
		$("#paymentScreen").addClass("working");
		$("#paymentEntryForm").find(".error").removeClass("error");
		$("#paymentEntryForm").find("div.data-error").remove();
		if ($("div.error-notification").size()) {
			$("div.error-notification").remove();
		}
		setTimeout(function() {
			showSubmitPaymentDialog();
		}, 1000);
	}, "primary");
}

function confirmSaveAsDraft(e) {
	e.preventDefault();

	var validationFailed = false;
	if (type == "payownaccount") {
		if (step == 2) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#creditAccountInput").val()) {
				validationFailed = true;
				var $row = $("#creditAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#creditAccountInput").closest("div.data-column")).html("Credit Account is a required field");
				}
			}
			continueFunction = function() {
				continuePaymentDataEntry(type)
			}
		} else if (step == 3) {
			if (!$("#debitAccountInput").val()) {
				validationFailed = true;
				var $row = $("#debitAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#debitAccountInput").closest("div.data-column")).html("Debit Account is a required field");
				}
			}
			if (!$("#creditAccountInput").val()) {
				validationFailed = true;
				var $row = $("#creditAccountInput").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#creditAccountInput").closest("div.data-column")).html("Credit Account is a required field");
				}
			}
			if (!$("#paymentCurrencySelect").val() && (!$("#paymentAmountInputField").val() || $("#paymentAmountInputField").val() == 0.00)) {
				validationFailed = true;
				var $row = $("#paymentCurrencySelect").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Currency and Payment Amount are required fields");
				}
			}
			if ($("#paymentCurrencySelect").val() && (!$("#paymentAmountInputField").val() || $("#paymentAmountInputField").val() == 0.00)) {
				if ($("#useDebitAmount").prop("checked")) {
					if (!$("#debitEquivalentAmountField").val()) {
						validationFailed = true;
						var $row = $("#debitEquivalentAmountField").closest("div.row");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
							$("<div class='data-error' />").appendTo($row.children("div.data-column")).html("Debit Equivalent Amount is required");
						}
					} else if ($("#debitEquivalentAmountField").val() == 0.00) {
						validationFailed = true;
						var $row = $("#debitEquivalentAmountField").closest("div.row");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
							$("<div class='data-error' />").appendTo($row.children("div.data-column")).html("Debit Equivalent Amount must be more than 0.00");
						}
					}
				} else {
					if (!$("#paymentAmountInputField").val()) {
						validationFailed = true;
						if (!$("#paymentAmountInputField").hasClass("error")) {
							$("#paymentAmountInputField").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
							$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Amount is a required field");
						}
					} else if ($("#paymentAmountInputField").val() == 0.00) {
						validationFailed = true;
						if (!$("#paymentAmountInputField").hasClass("error")) {
							$("#paymentAmountInputField").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
							$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Amount must be more than 0.00");
						}
					}
				}
			}
			if (!$("#paymentCurrencySelect").val() && $("#paymentAmountInputField").val()) {
				validationFailed = true;
				if (!$("#paymentCurrencySelect").closest("div.custom-select").hasClass("error")) {
					$("#paymentCurrencySelect").closest("div.custom-select").addClass("error").closest("div.data-column").prev("div.label-column").addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentCurrencySelect").closest("div.data-column")).html("Payment Currency is a required field");
				}
			}
			if ($("#fxSelection").val() == "Contract") {
				if (paymentRemainingAmount != 0) {
					validationFailed = true;
				}
			}
			if (!$("#paymentDateInput").val()) {
				validationFailed = true;
				var $row = $("#paymentDateInput").closest("div.row"),
					$dataCol = $("#paymentDateInput").closest("div.data-column");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
				}
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Payment Date is a required field")
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is a required field");
				}
			} else {
				var stringval = $("#paymentDateInput").val(),
					testdate;
				try {
					testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
				} catch (e) {
					validationFailed = true;
					var $row = $("#paymentDateInput").closest("div.row"),
						$dataCol = $("#paymentDateInput").closest("div.data-column");
					if (!$row.hasClass("error")) {
						$row.addClass("error");
					}
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Payment Date is not valid")
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is not valid");
					}
				} finally {
					if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
						validationFailed = true;
						var $row = $("#paymentDateInput").closest("div.row"),
							$dataCol = $("#paymentDateInput").closest("div.data-column");
						if (!$row.hasClass("error")) {
							$row.addClass("error");
						}
						if ($row.find("div.data-error").size()) {
							$row.find("div.data-error").html("Payment Date cannot be in the past")
						} else {
							$("<div class='data-error' />").appendTo($dataCol).html("Payment Date cannot be in the past");
						}
					}
				}
			}
			if (!$("#paymentReference").val()) {
				validationFailed = true;
				var $row = $("#paymentReference").closest("div.row");
				if (!$row.hasClass("error")) {
					$row.addClass("error");
					$("<div class='data-error' />").appendTo($("#paymentReference").closest("div.data-column")).html("Payment Reference is a required field");
				}
			}
			continueFunction = function() {
				reviewPaymentDetails(type)
			}
		}
	}

	if (!validationFailed) {
		buildConfirmDialog("Confirm that you would like to save the payment as a draft", "", function() {
			$("#paymentScreen").addClass("working");
			$("#paymentEntryForm").find(".error").removeClass("error");
			$("#paymentEntryForm").find("div.data-error").remove();
			if ($("div.error-notification").size()) {
				$("div.error-notification").remove();
			}
			setTimeout(function() {
				buildCustomConfirmDialog("<span style='font-size: 16px; color: #007dba; font-weight: bold;'>Payment Reference: " + newSinglePayment.id + "</span>", "<span>This payment has been saved as a draft.</span>", "", "Ok", function() {
					$("#paymentScreen").removeClass("working");
				}, "primary");
			}, 1000);
		}, "primary");
	} else {
		if (!$("div.error-notification").size()) {
			buildErrorNotification("Errors Were Detected", "Some errors were detected. Please review the form below and correct any items with error messages.", 100);
		}
	}
}


/* FILE UPLOAD FUNCTIONS */
function checkFormat() {
	var _gcp = ($(this).val() == "GCP Delimited") ? true : false;
	if (_gcp) {
		$("#debitIndicatorRow, #purposeRow").show();
	} else {
		$("#debitIndicatorRow, #purposeRow").hide();
	}
}

function clearErrors() {
	if ($(this).val() != '' && $(this).closest("div.row").hasClass("error")) {
		$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
	}
}

function clearAllErrors() {
	$("#fileUploadForm").find('div.error').removeClass("error").find("div.data-error").remove();
}

function cancelUpload() {
	$("#fileSection").hide();
	$("#uploadFileInput").val('');
	$("#uploadButton, #startUpload").removeClass("disabled");
	$(".progress-meter").stop(true, true).css({
		width: 0
	});
	clearAllErrors();
}

function showFileUploadSection() {
	$("#uploadMessage").hide();
	$("#fileSection, #fileUploadActions").show();
	$(".progress-meter").stop(true, true).css({
		width: 0
	});

	var str = $(this).val();
	var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);
	$("#filenamevalue").html(filename);

	if (window.ActiveXObject) {
		var myFSO = new ActiveXObject("Scripting.FileSystemObject");
		var filepath = document.getElementById('uploadFileInput').value;
		var thefile = myFSO.getFile(filepath);
		var size = thefile.size;
	} else {
		var size = this.files[0].size;
	}

	var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
	fSize = size;
	i = 0;
	while (fSize > 900) {
		fSize /= 1024;
		i++;
	}
	$("#filesize").html("(" + (Math.round(fSize * 100) / 100) + ' ' + fSExt[i] + ")");
}

function checkUploadSettings() {
	var _passed = true,
		_division = $("#divisionField").val(),
		_format = $("#formatField").val(),
		_encoding = $("#encodingField").val(),
		_indicator = $("#debitIndicatorField").val(),
		_purpose = $("#purposeField").val();

	if (!_division) {
		_passed = false;
		$("#divisionField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>Division is required</div>");
			}
		});
	}
	if (!_format) {
		_passed = false;
		$("#formatField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>File Format is required</div>");
			}
		});
	}
	if (!_encoding) {
		_passed = false;
		$("#encodingField").closest("div.row").addClass("error").find("div.data-column").append(function() {
			if ($(this).children("div.data-error").size() == 0) {
				$(this).append("<div class='data-error'>File Encoding is required</div>");
			}
		});
	}

	if (_format == "GCP Delimited") {
		if (!_indicator) {
			_passed = false;
			$("#debitIndicatorField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>Debit Indicator is required</div>");
				}
			});
		}
		if (!_purpose) {
			_passed = false;
			$("#purposeField").closest("div.row").addClass("error").find("div.data-column").append(function() {
				if ($(this).children("div.data-error").size() == 0) {
					$(this).append("<div class='data-error'>Payment Purpose is required</div>");
				}
			});
		}
	}

	if (_passed) {
		$("#fileUploadSection").closest("div.row").removeClass("error").find("div.data-error").remove();
		$("#uploadButton, #startUpload").addClass("disabled");
		$(".progress-meter").animate({
			width: "100%"
		}, 3000, function() {
			$("#uploadButton, #startUpload").removeClass("disabled");
			$("#fileUploadActions").hide();
			$("#uploadMessage").show();
			$("#uploadFileInput").val('');
		});
	} else {
		$("#fileUploadSection").closest("div.row").addClass("error").find("div.data-column").append($("<div class='data-error'>File does not match selection criteria</div>"));
	}
}

function populateFileUploadDialog() {
	var $dialogContent = $("<div class='py-ui' style='padding: 10px;' id='fileUploadForm' />");
	var $div = $("<div class=' top-label' />").appendTo($dialogContent);

	var $gridrow = $("<div class='grid-row' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridrow);

	var $row = $("<div class='row mandatory' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Division</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='divisionField'><option value=''></option><option value='Division ABC'>Division ABC</option><option value='Division 123'>Division 123</option><option value='Division XYZ'>Division XYZ</option></select>").appendTo($customSelect).on("change", clearErrors);

	var $row = $("<div class='row mandatory' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>File Format</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='formatField'><option value=''></option><option value='PAC File Format'>PAC File Format</option><option value='OTL Fixed Length'>OTL Fixed Length</option><option value='OTL Delimited'>OTL Delimited</option><option value='GCP Delimited'>GCP Delimited</option></select>").appendTo($customSelect).on("change", checkFormat).on("change", clearErrors);

	var $row = $("<div class='row mandatory' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>File Encoding</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='encodingField'><option value=''></option><option value='UTF-8'>UTF-8</option><option value='ASCII'>ASCII</option><option value='Unicode'>Unicode</option><option value='GB2312'>GB2312</option><option value='GB2312-80'>GB2312-80</option><option value='BIG5'>BIG5</option><option value='BIG5-HKSCS'>BIG5-HKSCS</option><option value='Shift-JIS'>Shift-JIS</option></select>").appendTo($customSelect).on("change", clearErrors);

	var $gridcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($gridrow);

	var $row = $("<div class='row mandatory' id='debitIndicatorRow' style='display: none;' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Debit Indicator</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='debitIndicatorField'><option value=''></option><option value='Bulk Debit'>Bulk Debit</option><option value='Itemised Debit'>Itemised Debit</option></select>").appendTo($customSelect).on("change", clearErrors);

	var $row = $("<div class='row mandatory' id='purposeRow' style='display: none;' />").appendTo($gridcell);
	var $labelCol = $("<div class='label-column' />").appendTo($row);
	var $label = $("<label>Payment Purpose</label>").appendTo($labelCol);
	var $dataCol = $("<div class='data-column' />").appendTo($row);
	var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
	var $select = $("<select id='purposeField'><option value=''></option><option value='Non-Salary Payment'>Non-Salary Payment</option><option value='Salary Payment'>Salary Payment</option></select>").appendTo($customSelect).on("change", clearErrors);


	var $gridrow = $("<div class='grid-row' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);

	var $row = $("<div class='row' />").appendTo($gridcell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);
	var $buttonSpan = $("<span class='form-button primary' id='uploadButton' />").appendTo($dataCol);
	var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Browse Files</a>").appendTo($buttonSpan);
	var $fileInput = $("<input type='file' name='file' id='uploadFileInput' style='position: absolute; left: 30px; padding: 0; width: 155px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($buttonSpan).on('change', showFileUploadSection);


	var $gridrow = $("<div class='grid-row' style='display: none;' id='fileSection' />").appendTo($div);
	var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);
	var $row = $("<div class='row' />").appendTo($gridcell);
	var $dataCol = $("<div class='data-column full' />").appendTo($row);

	var $uploadDiv = $("<div class='file-upload-section' id='fileUploadSection' />").appendTo($dataCol);
	var $fileDiv = $("<div id='fileNameDiv' />").appendTo($uploadDiv);
	var $data = $("<div class='file-name'><i class='fa fa-paperclip fa-fw'></i> <strong id='filenamevalue'></strong></div>").appendTo($fileDiv);
	var $data = $("<div class='file-size'><span id='filesize'></span></div>").appendTo($fileDiv);
	var $uploadActions = $("<div id='fileUploadActions' />").appendTo($uploadDiv);
	var $btndiv = $("<div class='file-upload-buttons' />").appendTo($uploadActions);
	var $buttonSpan = $("<span class='form-button primary' id='startUpload' />").appendTo($btndiv);
	var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-upload fa-fw'></i>Start</a>").appendTo($buttonSpan).on("click", checkUploadSettings);
	var $buttonSpan = $("<span class='form-button' id='cancelUpload' />").appendTo($btndiv);
	var $buttonLink = $("<a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i>Cancel</a>").appendTo($buttonSpan).on("click", cancelUpload);
	var $data = $("<div class='progress-bar'></div>").appendTo($uploadActions);
	var $meter = $("<div class='progress-meter' />").appendTo($data);
	var $messageDiv = $("<div class='file-upload-message' id='uploadMessage' style='display: none;' />").appendTo($uploadDiv);
	var $fileMessage = $("<div>This file has been <span style='color: #009900; font-weight: bold;'>successfully uploaded</span>. It will now be scanned and processed. You can find this file in the Payments File page with <strong>File ID: 34234234</strong>.</div>").appendTo($messageDiv);

	return $dialogContent;
}

function triggerUploadDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "uploadFile",
		title: "Upload Payment File",
		size: "xwide",
		icon: "<i class='fa fa-upload'></i>",
		content: function() {
			return populateFileUploadDialog()
		},
		buttons: [{
			name: "Close",
			icon: "<i class='fa fa-times-circle fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}



/* PAYMENT TEMPLATE FUNCTIONS */

/* destroy dialog search grid */
function destroyDialogSearchGrid() {
	if (typeof(searchGrid) != 'undefined' && searchGrid != null) {
		searchGrid.destroy();
		$(window).off('resize.searchgrid');
	}
}

function searchTemplates() {
	var _results = [];
	var _tempName = $("#searchTemplateName").val() ? $("#searchTemplateName").val() : "",
		_tempType = $("#searchPaymentTypes").val() ? $("#searchPaymentTypes").val() : "",
		_tempDebitCCy = $("#searchDebitCurrency").val() ? $("#searchDebitCurrency").val() : "",
		_tempDebitAcc = $("#searchDebitAccountNumber").val() ? $("#searchDebitAccountNumber").val() : "";
	for (var i = 0, l = _tbos_payment_templates.length; i < l; i++) {
		var _tmp = _tbos_payment_templates[i];
		if (_tmp.templatename.toLowerCase().indexOf(_tempName.toLowerCase()) != -1 && _tmp.type.toLowerCase().indexOf(_tempType.toLowerCase()) != -1 && _tmp.debitcurrency.toLowerCase().indexOf(_tempDebitCCy.toLowerCase()) != -1 && _tmp.debitaccountnumber.toLowerCase().indexOf(_tempDebitAcc.toLowerCase()) != -1) {
			_results.push(_tmp);
		}
	}
	return _results;
}

function loadTemplateResults(resultSet) {
	if (!resultSet) {
		$("#templateSearchResults").addClass("loading");
	}

	$("#templateSearchResults").find("div.loading-text").hide();

	var _results = (resultSet) ? resultSet : searchTemplates();

	setTimeout(function() {
		if (_results.length) {
			searchData = _results;
			if ($("div#searchGrid").size()) {
				searchGrid.setSelectedRows([]);
				searchDataView.beginUpdate();
				searchDataView.setItems(searchData);
				searchDataView.endUpdate();
				searchGrid.invalidateAllRows();
				searchGrid.render();
			} else {
				var $searchGrid = $("<div class='panel' id='searchGrid' />");
				$searchGrid.appendTo($("#templateSearchResults"));
				searchColumnFilters = {};
				searchGrouping = [];
				searchColumns = [{
					id: "templatename",
					name: "Template Name",
					field: "templatename",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,
				}, {
					id: "type",
					name: "Template Type",
					field: "type",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,
				}, {
					id: "debitaccountnumber",
					name: "Debit Account Number",
					field: "debitaccountnumber",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,
				}, {
					id: "debitcurrency",
					name: "Debit Currency",
					field: "debitcurrency",
					width: 200,
					sortable: true,
					sorter: "sorterStringCompare",
					visible: true,
				}];
				searchOptions = {
					enableCellNavigation: true,
					enableColumnReorder: true,
					syncColumnCellResize: false,
					forceFitColumns: true,
					multiSelect: false,
					multiColumnSort: true,
					explicitInitialization: true,
					showHeaderRow: false,
					dataItemColumnValueExtractor: getDataItemValue
				};

				function searchGridFilter(item, args) {
					for (var columnId in searchColumnFilters) {
						if (columnId !== undefined && searchColumnFilters[columnId] !== "") {
							var c = searchGrid.getColumns()[searchGrid.getColumnIndex(columnId)];
							if (item[c.field].toLowerCase().indexOf(searchColumnFilters[columnId].toLowerCase()) == -1) {
								return false;
							}
						}
					}
					return true;
				}
				var groupItemMetadataProvider = new Slick.Data.GroupItemMetadataProvider();
				searchDataView = new Slick.Data.DataView({
					groupItemMetadataProvider: groupItemMetadataProvider
				});
				searchGrid = new Slick.Grid($searchGrid, searchDataView, searchColumns, searchOptions);
				searchGrid.registerPlugin(groupItemMetadataProvider);
				searchGrid.setSelectionModel(new Slick.RowSelectionModel({
					selectActiveRow: true
				}));
				searchGrid.onSelectedRowsChanged.subscribe(function(e, args) {
					selectedDivisions = [];
					var rows = searchGrid.getSelectedRows();
					for (var i = 0, l = rows.length; i < l; i++) {
						var item = searchDataView.getItem(rows[i])
						if (item) selectedDivisions.push(item)
					}
				});
				searchGrid.onClick.subscribe(function(e, args) {
					var cell = searchGrid.getCellFromEvent(e);
					var row = cell.row;
				});
				searchGrid.onDblClick.subscribe(function(e, args) {
					var cell = searchGrid.getCellFromEvent(e);
					var row = cell.row;
				});
				searchGrid.onKeyDown.subscribe(function(e, args) {
					if (e.which == 13) {
						if (searchGrid.getActiveCell()) {
							var row = searchGrid.getActiveCell().row;
						}
					}
				});
				searchGrid.onSort.subscribe(function(e, args) {
					var cols = args.sortCols;
					searchDataView.sort(function(dataRow1, dataRow2) {
						for (var i = 0, l = cols.length; i < l; i++) {
							sortdir = cols[i].sortAsc ? 1 : -1;
							sortcol = cols[i].sortCol.field;
							var _sorter = cols[i].sortCol.sorter,
								idx = cols[i].sortCol.fieldIdx,
								result;
							if (_sorter == "sorterStringCompare") {
								result = sorterStringCompare(dataRow1, dataRow2);
							} else if (_sorter == "sorterNumeric") {
								result = sorterNumeric(dataRow1, dataRow2);
							} else if (_sorter == "sorterDateIso") {
								result = sorterDateIso(dataRow1, dataRow2);
							} else if (_sorter == "sorterStringCompareWithFieldIDX") {
								result = sorterStringCompareWithFieldIDX(dataRow1, dataRow2, idx);
							}
							if (result != 0) {
								return result;
							}
						}
						return 0;
					});
					args.grid.invalidateAllRows();
					args.grid.render();
				});
				searchDataView.onRowCountChanged.subscribe(function(e, args) {
					searchGrid.updateRowCount();
					searchGrid.render();
				});
				searchDataView.onRowsChanged.subscribe(function(e, args) {
					searchGrid.invalidateRows(args.rows);
					searchGrid.render();
				});
				searchDataView.beginUpdate();
				searchDataView.setItems(searchData);
				searchDataView.setFilter(searchGridFilter);
				searchDataView.endUpdate();
				$(window).on('resize.searchgrid', function() {
					searchGrid.resizeAndRender();
				});
			}
		} else {
			if ($("div#searchGrid").size()) {
				destroyDialogSearchGrid();
				$("div#searchGrid").remove();
			}
			$("#templateSearchResults").find("div.loading-text").html("No Results Found").show();
		}
		$("#templateSearchResults").removeClass("loading");
		searchGrid.resizeAndRender();
	}, 1000);
}

function populateTemplateSearchDialog() {
	var $dialogContent = $("<div class='py-ui' id='templateSearch' />"),
		$searchBar = $("<div class='search-bar' />").appendTo($dialogContent),
		$dialogGrid = $("<div class='panel' id='templateSearchResults' />").appendTo($dialogContent),
		$searchInstructions = $("<div class='loading-text'>Use the search fields above to find a payment template</div>").appendTo($dialogGrid);

	var $searchDiv = $("<div class='search-bar-container' />").appendTo($searchBar),
		$searchFields = $("<div class='search-bar-fields' />").appendTo($searchDiv),
		$searchFieldRow = $("<div class='search-bar-field-row' />").appendTo($searchFields),
		$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
		$searchFieldLabel = $("<label>Template Name</label>").appendTo($searchField),
		$searchInput = $("<input type='text' style='width: 95%;' value='' id='searchTemplateName' />").appendTo($searchField),
		$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
		$searchFieldLabel = $("<label>Payment Type</label>").appendTo($searchField),
		$customSelect = $("<div class='custom-select' style='width: 95%;' />").appendTo($searchField),
		$searchSelect = $("<select id='searchPaymentTypes'><option value=''></option><option value='Domestic'>Domestic</option><option value='International'>International</option><option value='Transfers'>Transfers</option><option value='Domestic Salary'>Domestic Salary</option><option value='International Salary'>International Salary</option></select>").appendTo($customSelect),
		$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
		$searchFieldLabel = $("<label>Debit Currency</label>").appendTo($searchField),
		$customSelect = $("<div class='custom-select' style='width: 95%;' />").appendTo($searchField),
		$searchSelect = $("<select id='searchDebitCurrency'><option value=''></option><option value='AUD'>AUD</option><option value='CNY'>CNY</option><option value='HKD'>HKD</option><option value='SGD'>SGD</option><option value='USD'>USD</option></select>").appendTo($customSelect),
		$searchFieldRow = $("<div class='search-bar-field-row' />").appendTo($searchFields),
		$searchField = $("<div class='search-bar-field' />").appendTo($searchFieldRow),
		$searchFieldLabel = $("<label>Debit Account Number</label>").appendTo($searchField),
		$searchInput = $("<input type='text' style='width: 95%;' value='' id='searchDebitAccountNumber' />").appendTo($searchField),
		$searchButtonDiv = $("<div class='search-bar-button' />").appendTo($searchDiv),
		$resetButton = $("<span class='form-button'><a href='javascrit:void(0)'><i class='fa fa-refresh fa-fw'></i>Reset</a></span>").appendTo($searchButtonDiv),
		$searchButton = $("<span class='form-button primary'><a href='javascrit:void(0)'><i class='fa fa-search fa-fw'></i>Search</a></span>").appendTo($searchButtonDiv).on("click", function(e) {
			e.preventDefault();
			loadTemplateResults();
		});

	return $dialogContent;
}

function triggerTemplateDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "searchTemplates",
		title: "Use Payment Template",
		size: "xwide",
		icon: "<i class='fa fa-clipboard'></i>",
		content: function() {
			return populateTemplateSearchDialog()
		},
		hasgrid: function() {
			return destroyDialogSearchGrid()
		}
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
	loadTemplateResults();
}



/* ADD BATCH PAYMENTS GRID */
var dataView;
var editBatchGrid;
var editBatchData = newBatchPayment.payments;
var editBatchSelectedRowIds = [];
var editBatchColumns = [{
	id: "number",
	name: "#",
	field: "number",
	toolTip: "Item Number",
	width: 30,
	sortable: true,
	resizable: false
}, {
	id: "validated",
	name: "<i class='fa fa-check-circle fa-fw' style='color: #009900;'></i>",
	field: "validated",
	toolTip: "Payment Validation",
	width: 50,
	headerCssClass: "centered",
	cssClass: "centered",
	sortable: true,
	resizable: false,
	formatter: Slick.Formatters.ValidatedIconFormatter
}, {
	id: "paymentreference",
	name: "Reference",
	field: "paymentreference",
	toolTip: "Payment Reference",
	width: 300,
	sortable: true
}, {
	id: "beneficiaryname",
	name: "Beneficiary",
	field: "beneficiaryname",
	toolTip: "Beneficiary Name",
	width: 200,
	sortable: true
}, {
	id: "beneficiaryaccountnumber",
	name: "Account",
	field: "beneficiaryaccountnumber",
	toolTip: "Beneficiary Account",
	width: 200,
	sortable: true
}, {
	id: "paymentcurrency",
	name: "Currency",
	field: "paymentcurrency",
	toolTip: "Payment Currency",
	width: 100,
	sortable: true
}, {
	id: "paymentamount",
	name: "Amount",
	field: "paymentamount",
	toolTip: "Payment Amount",
	headerCssClass: "righted",
	cssClass: "righted",
	width: 200,
	sortable: true
}];
var editBatchOptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	autoHeight: false,
	forceFitColumns: true,
	multiSelect: true
};

var editBatchCheckboxSelector = new Slick.CheckboxSelectColumn({
	cssClass: "slick-cell-checkboxsel"
});
editBatchColumns.unshift(editBatchCheckboxSelector.getColumnDefinition());


/* REVIEW BATCH PAYMENTS GRID */
var reviewDataView;
var reviewGrid;
var reviewData = newBatchPayment.payments;
var reviewColumns = [{
	id: "number",
	name: "#",
	field: "number",
	toolTip: "Item Number",
	width: 30,
	sortable: true,
	resizable: false
}, {
	id: "validated",
	name: "<i class='fa fa-check-circle fa-fw' style='color: #009900;'></i>",
	field: "validated",
	toolTip: "Payment Validation",
	width: 50,
	headerCssClass: "centered",
	cssClass: "centered",
	sortable: true,
	resizable: false,
	formatter: Slick.Formatters.ValidatedIconFormatter
}, {
	id: "paymentreference",
	name: "Reference",
	field: "paymentreference",
	toolTip: "Payment Reference",
	width: 300,
	sortable: true
}, {
	id: "beneficiaryname",
	name: "Beneficiary",
	field: "beneficiaryname",
	toolTip: "Beneficiary Name",
	width: 200,
	sortable: true
}, {
	id: "beneficiaryaccountnumber",
	name: "Account",
	field: "beneficiaryaccountnumber",
	toolTip: "Beneficiary Account",
	width: 200,
	sortable: true
}, {
	id: "paymentcurrency",
	name: "Currency",
	field: "paymentcurrency",
	toolTip: "Payment Currency",
	width: 100,
	sortable: true
}, {
	id: "paymentamount",
	name: "Amount",
	field: "paymentamount",
	toolTip: "Payment Amount",
	headerCssClass: "righted",
	cssClass: "righted",
	width: 200,
	sortable: true
}];
var reviewOptions = {
	editable: false,
	enableAddRow: false,
	enableCellNavigation: false,
	enableColumnReorder: false,
	autoHeight: false,
	forceFitColumns: true,
	multiSelect: false
};


function checkBatchFXRate() {
	var rtype = $("#batchFXSelection").val();
	if (rtype == "Carded") {
		$("#batchAddFXContracts, #batchFXContracts").hide();
		$("#batchFXCardedRate").show();
	} else {
		$("#batchFXCardedRate").hide();
		$("#batchAddFXContracts, #batchFXContracts").show();
	}
}

function addPaymentsToBatch(_target, item) {

	var batchItemDebitEquivalentFlag = false;

	if (item) {
		batchPaymentItem = item;
		var selectedBatchPaymentBeneficiary;
		for (var i = 0, l = _beneAccounts.length; i < l; i++) {
			if (batchPaymentItem.beneficiaryid == _beneAccounts[i].id) {
				selectedBatchPaymentBeneficiary = _beneAccounts[i];
				break;
			}
		}
	} else {
		batchPaymentItem = jQuery.extend({}, newSinglePayment);
		batchPaymentItem.validated = false;
		batchPaymentItem.id = randString(20);
		batchPaymentItem.division = newBatchPayment.division;
		batchPaymentItem.debitaccountnumber = newBatchPayment.debitaccountnumber;
		batchPaymentItem.debitaccountname = newBatchPayment.debitaccountname;
		batchPaymentItem.debitaccountcurrency = newBatchPayment.debitaccountcurrency;
		batchPaymentItem.debitcurrency = newBatchPayment.debitaccountcurrency;
		batchPaymentItem.paymentdate = newBatchPayment.paymentdate;
		batchPaymentItem.number = newBatchPayment.payments.length + 1;
		batchPaymentItem.paymentamount = "0.00";
		if (!newBatchPayment.individualdebitsflag) {
			batchPaymentItem.paymentcurrency = newBatchPayment.paymentcurrency;
		}
		var selectedBatchPaymentBeneficiary = null;
	}

	var saveBatchPaymentItem = function(_dialog, item) {

		var savePaymentToBatch = function() {
			if (item) {
				for (var y = 0, z = newBatchPayment.payments.length; y < z; y++) {
					if (item.id == newBatchPayment.payments[y].id) {
						newBatchPayment.payments[y] = batchPaymentItem;
						break;
					}
				}
			} else {
				newBatchPayment.payments.push(batchPaymentItem);
			}
			var totalPaymentAmount = 0.00,
				totalDebitAmount = 0.00;
			for (var a = 0, b = newBatchPayment.payments.length; a < b; a++) {
				totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(newBatchPayment.payments[a].paymentamount.replace(/[^0-9\.]+/g, ""));
			}
			newBatchPayment.paymentamount = totalPaymentAmount;
			if (newBatchPayment.paymentcurrency != newBatchPayment.debitaccountcurrency) {
				if (newBatchPayment.ratetype == "Carded") {
					totalDebitAmount = addCommas((parseFloat(totalPaymentAmount * newBatchPayment.rate)).toFixed(2));
					totalPaymentAmount = totalPaymentAmount.toFixed(2);
					newBatchPayment.paymentamount = totalPaymentAmount;
					newBatchPayment.debitequivalentamount = totalDebitAmount;
				} else if (newBatchPayment.ratetype == "Contract") {

				}
				$("#totalAmount1").empty();
				$("#totalAmount2").empty();
				if (newBatchPayment.usedebitequivalentflag) {
					var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + totalPaymentAmount + "</strong></div>").appendTo($("#totalAmount1"));
					$("#totalAmount1").show();
					var $totalDebiAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + totalDebitAmount + "</strong></div>").appendTo($("#totalAmount2"));
					$("#totalAmount2").show();
				} else {
					var $totalAmount = $("<div style='display: inline-block;'>Total Debit Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.debitaccountcurrency + " $" + totalDebitAmount + "</strong></div>").appendTo($("#totalAmount1"));
					$("#totalAmount1").show();
					var $totalDebiAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + totalPaymentAmount + "</strong></div>").appendTo($("#totalAmount2"));
					$("#totalAmount2").show();
				}
			} else {
				totalPaymentAmount = addCommas(totalPaymentAmount.toFixed(2));
				newBatchPayment.debitequivalentamount = totalPaymentAmount;
				$("#totalAmount2").empty().hide();
				$("#totalAmount1").empty();
				var $totalAmount = $("<div style='display: inline-block;'>Total Payment Amount: &nbsp;&nbsp; <strong style='font-size: 16px;'>" + newBatchPayment.paymentcurrency + " $" + totalPaymentAmount + "</strong></div>").appendTo($("#totalAmount1"));
				$("#totalAmount1").show();
			}
			editBatchData = newBatchPayment.payments;
			dataView.setItems(editBatchData);
			editBatchGrid.invalidateAllRows();
			editBatchGrid.render();
			dialogHider(_dialog);
			batchPaymentItem = null;
		}
		var validationFailed = false;
		if (!$("#batchBeneInput").val()) {
			validationFailed = true;
		}
		if (!$("#batchPaymentMethodSelection").val()) {
			validationFailed = true;
		}
		if (!$("#batchPaymentAmountField").val()) {
			validationFailed = true;
		}
		if (!$("#batchPaymentReference").val()) {
			validationFailed = true;
		}
		if (validationFailed) {
			batchPaymentItem.validated = false;
			buildConfirmDialog("Some mandatory fields have not been filled in.", "Do you want to save the payment and fix these issues later?", savePaymentToBatch, "primary");
		} else {
			batchPaymentItem.validated = true;
			savePaymentToBatch();
		}
	}

	var resetBatchPaymentItem = function() {
		batchPaymentItem.paymentmethod = "";
		batchPaymentItem.paymentamount = 0.00;
		batchPaymentItem.debitequivalentamount = 0.00;
		batchPaymentItem.paymentreference = "";
		batchPaymentItem.purposecode = "";
		batchPaymentItem.remittanceinformation = "";
		$("#batchPaymentMethodSelection").val("").trigger("change");
		$("#batchPaymentAmountField").val("");
		$("#batchPaymentAmountTextValue").html("");
		$("#batchPaymentDebitEquivalentAmountField").val("");
		$("#batchPaymentDebitEquivalentountTextValue").html("");
		$("#batchPaymentReference").val("");
		$("#batchPaymentPurposeCodeField").val("");
		$("#batchPaymentRemittanceInformation").val("");
	}

	var showBeneficiarySearchDialog = function(_target) {
		/* set $wrapper to hold the add beneficiary list */
		var $wrapper = $("<div class='wrapper' />"),

			/* build the account filter input */
			$searchDiv = $("<div style='height: 50px; background: #fff; border-bottom: 1px solid #ebebeb; color: #999; line-height: 50px; padding: 0 15px;'>").appendTo($wrapper),
			$searchIcon = $("<i class='fa fa-search fa-fw'></i>").appendTo($searchDiv),
			$searchInput = $("<input id='AddPaymentBeneficiaryFilterInput' type='text' style='width: 90%; height: 45px; border: 0; font-size: 16px;' placeholder='Type here to find a beneficiary...' />").on("keyup", function() {
				if (this.value != '') {
					$("#clearBeneFilter").show()
				} else {
					$("#clearBeneFilter").hide()
				}
			}).appendTo($searchDiv),
			$searchClear = $("<span class='btn search-clear' id='clearBeneFilter'><a href='javascript:void(0);''><i class='fa fa-times fa-fw'></i></a></span>").on("click", function() {
				$("#AddPaymentBeneficiaryFilterInput").val("").trigger("change");
				$(this).hide();
			}).appendTo($searchDiv);

		/* build the header row */
		var $header = $("<div class='dialog-search-header' />").appendTo($wrapper),
			$nameHeader = $("<div class='dialog-search-header-col' style='width: 360px;'>Beneficiary Name</div>").appendTo($header),
			$numberHeader = $("<div class='dialog-search-header-col' style='width: 220px;'>Account</div>").appendTo($header),
			$countryHeader = $("<div class='dialog-search-header-col' style='width: 220px; border-right: 0;'>Country</div>").appendTo($header);

		/* build the accounts list */
		var $dataContainer = $("<div class='dialog-search-data' style='top: 91px;' />").appendTo($wrapper),
			$ul = $("<ul class='dialog-search-list' />").appendTo($dataContainer),
			$li, $row, $name, $number, $currency;

		$.each(_beneAccounts, function() {
			var _bene = this;
			$li = $("<li data-name='" + this.name + "' data-number='" + this.accountnumber + "' data-bank='" + this.bank + "' data-country='" + this.bankcountry + "' >").appendTo($ul),
				$row = $("<div class='dialog-search-row' />").appendTo($li).on("click", function(e) {
					var $target = $(e.target);
					if ($target.prop("nodeName") == "DIV") {
						$target = $target.closest("li");
					}
					$("#batchBeneInput").val(_bene.name);
					dialogHider(_dialog);
					showSelectedBatchPaymentBeneficiaryDetails(_bene);
				}),
				$name = $("<div class='dialog-search-data-col' style='width: 360px;'>" + this.name + "</div>").appendTo($row),
				$number = $("<div class='dialog-search-data-col' style='width: 220px;'>" + this.accountnumber + "</div>").appendTo($row),
				$country = $("<div class='dialog-search-data-col' style='width: 220px;'>" + this.bankcountry + "</div>").appendTo($row)
		});
		/* build and show the add accounts dialog */
		var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
		var _dialog = {
			id: "AddBeneficiaryAccount",
			title: "Select a Beneficiary",
			size: "xxl",
			icon: "<i class='fa fa-plus-square'></i>",
			content: $wrapper
		}
		dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

		/* enable the fast filter on the search accounts input */
		$("#AddPaymentBeneficiaryFilterInput").fastLiveFilter('.dialog-search-list');

		/* if no accounts are available display a message */
		if (!$(".dialog-search-list").children("li").length) {
			var $noAccounts = $("<div style='text-align: center; margin: 50px auto; color: #999; font-size: 14px;'>There are no beneficiaries to add</div>").appendTo($dataContainer);
		}
	}

	var showSelectedBatchPaymentBeneficiaryDetails = function(bene) {
		if (bene) {
			batchPaymentItem.beneficiaryid = bene.id;
			batchPaymentItem.beneficiaryname = bene.name;
			batchPaymentItem.beneficiarylocalname = bene.localname;
			batchPaymentItem.beneficiaryaccountnumber = bene.accountnumber;
			batchPaymentItem.beneficiarybankname = bene.bank;
			batchPaymentItem.beneficiarybankcountry = bene.bankcountry;
			batchPaymentItem.beneficiarybranchname = bene.branch;
			batchPaymentItem.beneficiaryaccountclearingcode = bene.clearing[0].code;
			batchPaymentItem.beneficiaryaccountswiftcode = bene.swift;
			$("#enterNewBatchBeneficiary").hide();
			$("#batchBeneDetails").show();
			$("#batchBeneAccountNumber").html(bene.accountnumber);
			$("#batchBeneBankName").html(bene.bank);
			$("#batchBeneBankCountry").html(bene.bankcountry);
			if (bene.localname) {
				$("#batchBeneLocalLanguageNameSection").show();
				$("#batchBeneLocalLanguageNameField").html(bene.localname);
			} else {
				$("#batchBeneLocalLanguageNameSection").hide();
				$("#batchBeneLocalLanguageNameField").html("");
			}
			if (bene.branch) {
				$("#batchBeneBankBranch").show().html(bene.branch);
			} else {
				$("#batchBeneBankBranch").hide().html("");
			}
			if (type == "payotherdomesticbatch") {
				$("#batchBeneClearing").html(bene.clearing[0].code);
			} else if (type == "payotherinternationalbatch") {
				$("#batchBeneClearing").html(bene.swift);
			}

			$("#paymentInstructionPaymentSection, #batchPaymentSupportingDocumentsSection").show();

		} else {
			$("#batchBeneAccountNumber, #batchBeneBankName, #batchBeneBankCountry, #batchBeneLocalLanguageNameField, #batchBeneBankBranch, #batchBeneClearing").html("");
			$("#batchBeneLocalLanguageNameSection,#batchBeneBankBranch,#paymentInstructionPaymentSection, #batchPaymentSupportingDocumentsSection").hide();
			$("#batchBeneDetails").hide();
			batchPaymentItem.beneficiaryid = "";
			batchPaymentItem.beneficiaryname = "";
			batchPaymentItem.beneficiarylocalname = "";
			batchPaymentItem.beneficiaryaccountnumber = "";
			batchPaymentItem.beneficiarybankname = "";
			batchPaymentItem.beneficiarybankcountry = "";
			batchPaymentItem.beneficiarybranchname = "";
			batchPaymentItem.beneficiaryaccountclearingcode = "";
			batchPaymentItem.beneficiaryaccountswiftcode = "";
			resetBatchPaymentItem();
		}
	}

	var handlePaymentDebitEquivalentFlag = function() {
		batchItemDebitEquivalentFlag = ($(this).prop('checked')) ? true : false;
		batchPaymentItem.usedebitequivalentflag = batchItemDebitEquivalentFlag;
		if (batchItemDebitEquivalentFlag) {
			var batchItemPaymentAmount = 0;
			batchPaymentItem.paymentamount = batchItemPaymentAmount;
			$("#batchPaymentAmountTextValue").html("");
			$("#batchPaymentDebitEquivalentAmountTextValue, #batchPaymentAmountField").hide();
			$("#batchPaymentDebitEquivalentAmountField, #batchPaymentAmountTextValue").show();
		} else {
			var batchItemDebitEquivalentAmount = 0;
			batchPaymentItem.debitequivalentamount = batchItemDebitEquivalentAmount;
			$("#batchPaymentDebitEquivalentAmountTextValue").html("");
			$("#batchPaymentDebitEquivalentAmountField, #batchPaymentAmountTextValue").hide();
			$("#batchPaymentDebitEquivalentAmountTextValue, #batchPaymentAmountField").show();
		}
		if (batchPaymentItem.ratetype == "Carded") {
			fetchCardedRates()
		} else if (batchPaymentItem.ratetype == "Contract") {
			$("#batchFXContractList").find("div[data-contract-row='true']").remove();
			batchPaymentItem.contracts = [];
			handleContractUsedAmount();
		}
	}

	var handleBatchPaymentCurrencyChanges = function() {
		var _paymentccy = $(this).val(),
			_debitccy = selectedDebitAccount.ccy;

		/* set batchPaymentItem.paymentcurrency */
		batchPaymentItem.paymentcurrency = _paymentccy;

		/* reset the payment amount */
		$("#batchPaymentAmountField").val("");
		$("#batchPaymentAmountTextValue").html("");
		var batchItemPaymentAmount = 0;
		batchPaymentItem.paymentamount = batchItemPaymentAmount;

		/* reset the debit equivalent amounts */
		$("#batchPaymentDebitEquivalentAmountField").val("");
		$("#batchPaymentDebitEquivalentAmountTextValue").html("");
		var batchItemDebitEquivalentAmount = 0;
		batchPaymentItem.debitequivalentamount = batchItemDebitEquivalentAmount;

		if (_paymentccy == "" || (_paymentccy == _debitccy)) {
			$("#batchPaymentdebitEquivalentSection, #batchPaymentFXSection").hide();
			$("#batchPaymentRemainingAmount").empty();
			batchPaymentItem.ratetype = false;
			batchPaymentItem.rate = null;
			batchPaymentItem.contracts = [];
			if (batchPaymentItem.usedebitequivalentflag) {
				$("#batchPaymentUseDebitAmount").prop("checked", false).trigger("change");
			}
			$("#batchPaymentAmountField").trigger("change");
		} else if (_paymentccy != _debitccy) {
			$("#batchPaymentdebitEquivalentSection, #batchPaymentFXSection").show();
			if (!batchPaymentItem.ratetype || batchPaymentItem.ratetype == "Carded") {
				$("#batchFXSelection").val("Carded").trigger("change");
			} else if (batchPaymentItem.ratetype == "Contract") {
				$("#batchFXSelection").val("Contract").trigger("change");
				$("#batchFXContractList").find("div[data-contract-row='true']").remove();
				batchPaymentItem.contracts = [];
			}
		}
	}

	var handleAttachDocumentToPayment = function() {
		$("#paymentProgressBar").show();
		$("#paymentProgressBar .progress-meter").animate({
			width: "100%"
		}, 3000, function() {
			$("#paymentProgressBar").hide();
			$("#paymentProgressBar .progress-meter").css("width", 0);

			var str = $("#paymentSupportingDoc").val();
			var filename = str.substring(str.lastIndexOf("\\") + 1, str.length);

			if (window.ActiveXObject) {
				var myFSO = new ActiveXObject("Scripting.FileSystemObject");
				var filepath = document.getElementById('paymentSupportingDoc').value;
				var thefile = myFSO.getFile(filepath);
				var size = thefile.size;
			} else {
				var size = document.getElementById('paymentSupportingDoc').files[0].size;
			}

			var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
			fSize = size;
			i = 0;
			while (fSize > 900) {
				fSize /= 1024;
				i++;
			}

			var filesize = (Math.round(fSize * 100) / 100) + ' ' + fSExt[i];
			var attachTimer;

			var _doc = {
				id: randString(20),
				filename: filename,
				filesize: filesize,
				status: "Performing Virus Scan"
			}
			var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />"),
				$fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
				$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell).on("click", function(e) {
					e.preventDefault();
					$(this).closest("div.data-table-row").remove();
					for (var i = 0, l = batchPaymentItem.supportingdocs.length; i < l; i++) {
						if (batchPaymentItem.supportingdocs[i].id == _doc.id) {
							batchPaymentItem.supportingdocs.splice(i, 1);
						}
					}
					clearTimeout(attachTimer);
					if (!$("div[data-doc-row]='true'").size()) {
						$("div[data-supporting-docs='newInstruction']").hide();
					}
				}),
				$documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell),
				$statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "<i class='ellipsis-loader' /></div>").appendTo($dataTableRow);
			$dataTableRow.appendTo($("div[data-supporting-docs='newInstruction']"));
			$("div[data-supporting-docs='newInstruction']").show();
			attachTimer = setTimeout(function() {
				$documentLink.remove();
				$documentLink = $("<a href='javascript:void(0)' style='text-decoration: none;'>" + _doc.filename + " (" + _doc.filesize + ")</a>").appendTo($fileInfoCell);
				$statusTableCell.empty().html("Attached");
				_doc.status = "Attached";
				batchPaymentItem.supportingdocs.push(_doc);
			}, 2500);
		});
	}

	var populateAddPaymentDialog = function() {
		var $dialogContent = $("<div class='py-ui' style='padding: 20px;' id='addPaymentDialog' />");


		/* error section */
		var $gridrow = $("<div class='grid-row' id='paymentErrors' style='display: none;' />").appendTo($dialogContent);
		var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);
		var $box = $("<div class='box' />").appendTo($gridcell);
		var $boxHeader = $("<div class='box-header error'>Errors</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $boxrow = $("<div class='grid-row' />").appendTo($boxContent);
		var $boxcell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxrow);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $dataCol = $("<div class='data-column full' />").appendTo($row);
		var $errorGrid = $("<div class='payment-grid' />").appendTo($dataCol);


		/* beneficiary section */
		var $gridrow = $("<div class='grid-row' />").appendTo($dialogContent);
		var $gridcell = $("<div class='grid-cell' />").appendTo($gridrow);
		var $box = $("<div class='box' />").appendTo($gridcell);
		var $boxHeader = $("<div class='box-header'>To</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $boxrow = $("<div class='grid-row' />").appendTo($boxContent);
		var $boxcell = $("<div class='grid-cell' style='width: 100%;' />").appendTo($boxrow);
		var $row = $("<div class='row mandatory' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Beneficiary</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $comboBoxDiv = $("<div class='combobox-div' style='width: 65%;' />").appendTo($dataCol);
		var $comboBoxInput = $("<input type='text' value='' id='batchBeneInput' placeholder='Type in a beneficiary name or account number' />").appendTo($comboBoxDiv);
		var $comboBoxIcon = $("<div class='combobox-icon' id='batchBeneInputControl'><i class='fa fa-chevron-down fa-fw'></i></div>").appendTo($comboBoxDiv);
		var $comboBoxSearch = $("<a href='javascript:void(0)' id='searchBatchBeneDialog' title='Find a beneficiary' class='form-icon'><i class='fa fa-search fa-fw'></i></a>").appendTo($dataCol).on("click", function(e) {
			e.preventDefault();
			showBeneficiarySearchDialog($(this));
		});
		var $enterNewBeneLink = $("<a href='javscript:void(0)' style='color: #007dba; text-decoration: none; margin-left: 5px;'><i class='fa fa-pencil-square fa-fw text-right'></i><span style='margin-left: 5px;'>Enter / Edit Beneficiary</span></a>").appendTo($dataCol);
		var $comboBoxAutoCompleteDiv = $("<div id='batchBeneInputAutoComplete'></div>").appendTo($dataCol);
		var $detailDiv = $("<div id='batchBeneDetails' style='display: none;' />").appendTo($boxContent);
		var $boxrow = $("<div class='grid-row' />").appendTo($detailDiv);
		var $boxcell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxrow);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Account Number</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text' id='batchBeneAccountNumber'></div>").appendTo($dataCol);
		var $row = $("<div class='row' id='batchBeneLocalLanguageNameSection' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Local Language Name</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text' id='batchBeneLocalLanguageNameField'></div>").appendTo($dataCol);
		var $boxcell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxrow);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Bank Details</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $dataGroup = $("<div class='input-group' />").appendTo($dataCol);
		var $data = $("<div class='data-text' id='batchBeneBankName'></div>").appendTo($dataGroup);
		var $data = $("<div class='data-text' id='batchBeneBankBranch' style='display: none;'></div>").appendTo($dataGroup);
		var $data = $("<div class='data-text' id='batchBeneBankCountry'></div>").appendTo($dataGroup);
		var $boxcell = $("<div class='grid-cell' style='width: 33%;' />").appendTo($boxrow);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Clearing</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text' id='batchBeneClearing'></div>").appendTo($dataCol);

		/* payment section */
		var $row = $("<div class='grid-row' id='paymentInstructionPaymentSection' style='display: none;' />").appendTo($dialogContent);
		var $cell = $("<div class='grid-cell' />").appendTo($row);
		var $box = $("<div class='box' />").appendTo($cell);
		var $boxHeader = $("<div class='box-header'>Payment Details</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $boxrow = $("<div class='grid-row' />").appendTo($boxContent);
		var $boxcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxrow);
		var $row = $("<div class='row mandatory' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment Method</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='batchPaymentMethodSelection'></select>").appendTo($customSelect).on("change", handlePaymentMethodChanges);
		var $row = $("<div class='row mandatory' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment Date</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text' id='batchPaymentDate'>" + newBatchPayment.paymentdate + "</div>").appendTo($dataCol);
		var $row = $("<div class='row mandatory' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment Currency &amp; Amount</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 100px;' id='batchPaymentCustomCurrencySelect' />").appendTo($dataCol);
		var $select = $("<select id='batchPaymentCurrencySelect'><option value=''></option><option value='AUD'>AUD</option><option value='CNY'>CNY</option><option value='SGD'>SGD</option></select>").appendTo($customSelect).on("change", handleBatchPaymentCurrencyChanges);
		var $data = $("<div class='data-text' id='batchPaymentCurrency'>" + newBatchPayment.paymentcurrency + "</div>").appendTo($dataCol);
		var $data = $("<input type='text' id='batchPaymentAmountField' value='' style='width: 50%;' />").appendTo($dataCol).on({
			keydown: function(e) {
				preventAlphaKeys(e)
			},
			change: function(e) {
				handleAmountChanges($(this))
			}
		});
		var $data = $("<div class='data-text' id='batchPaymentAmountTextValue' style='display: none;'></div>").appendTo($dataCol);

		var $row = $("<div class='row' id='batchPaymentdebitEquivalentSection' style='display: none;' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Debit Equivalent Amount</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<div class='data-text' id='batchPaymentDebitCurrency'>" + newBatchPayment.debitaccountcurrency + "</div>").appendTo($dataCol);
		var $data = $("<input type='text' id='batchPaymentDebitEquivalentAmountField' value='' style='width: 50%; display: none;' />").appendTo($dataCol).on({
			keydown: function(e) {
				preventAlphaKeys(e)
			},
			change: function(e) {
				handleAmountChanges($(this))
			}
		});
		var $data = $("<div class='data-text' id='batchPaymentDebitEquivalentAmountTextValue'></div>").appendTo($dataCol);
		var $break = $("<br />").appendTo($dataCol);
		var $data = $("<input type='checkbox' id='batchPaymentUseDebitAmount' />").appendTo($dataCol).on('change', handlePaymentDebitEquivalentFlag);
		var $labeldesc = $("<label class='desc' for='batchPaymentUseDebitAmount'>Enter Amount in Debit Currency</label>").appendTo($dataCol);

		var $boxcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxrow);
		var $row = $("<div class='row mandatory' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Payment Reference</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' style='width: 85%' value='' id='batchPaymentReference' />").appendTo($dataCol).on("change", handlePaymentReferenceChanges);
		var $row = $("<div class='row mandatory' id='batchPaymentPurposeCodeSection' style='display: none;' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Purpose Code</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $select = $("<select id='batchPaymentPurposeCodeField'></select>").appendTo($customSelect).on("change", handlePurposeCodeChanges);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>Remittance Information</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<textarea style='width: 85%; height: 80px;' id='batchPaymentRemittanceInformation'></textarea>").appendTo($dataCol).on("change", handleRemittanceChanges);

		/* fx section */
		var $row = $("<div class='grid-row' id='batchPaymentFXSection' style='display: none;' />").appendTo($dialogContent);
		var $cell = $("<div class='grid-cell' />").appendTo($row);
		var $box = $("<div class='box' />").appendTo($cell);
		var $boxHeader = $("<div class='box-header'>FX Details</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $boxrow = $("<div class='grid-row' />").appendTo($boxContent);
		var $boxcell = $("<div class='grid-cell' style='width: auto;' />").appendTo($boxrow);


		/* reporting section */
		var $row = $("<div class='grid-row' id='batchPaymentRegulatoryReportingSection' style='display: none;' />").appendTo($dialogContent);
		var $cell = $("<div class='grid-cell' />").appendTo($row);
		var $box = $("<div class='box' />").appendTo($cell);
		var $boxHeader = $("<div class='box-header'>Regulatory Reporting</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $boxrow = $("<div class='grid-row' />").appendTo($boxContent);
		var $boxcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxrow);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>发电等级</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $data = $("<select id='bopPriority'><option value=''></option></select>").appendTo($customSelect);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>金额大写</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bopAmountInWords' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>对公组织机构代码</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bopUnitCode' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>收款人常驻国家（地区）名称</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bopResidentRegionName' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>收款人常驻国家（地区）代码</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bopResidentRegionCode' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>本笔款项是否为保税货物项下付款</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $data = $("<select id='bopField1'><option value=''></option></select>").appendTo($customSelect);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>本笔款项请选择</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $data = $("<select id='bopField2'><option value=''></option></select>").appendTo($customSelect);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>付汇性质</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $data = $("<select id='bopField3'><option value=''></option></select>").appendTo($customSelect);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>外汇局批件号/备案表号/业务编号</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $data = $("<select id='bopField4'><option value=''></option></select>").appendTo($customSelect);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>其他信息</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $customSelect = $("<div class='custom-select' style='width: 85%;' />").appendTo($dataCol);
		var $data = $("<select id='bopField5'><option value=''></option></select>").appendTo($customSelect);
		var $boxcell = $("<div class='grid-cell' style='width: 50%;' />").appendTo($boxrow);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>交易编码1</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop1TransCode' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>交易附言1</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop1TransDesc' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>相应币种1</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop1CCY' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>金额1</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop1Amount' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>交易编码2</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop2TransCode' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>交易附言2</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop2TransDesc' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>相应币种2</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop2CCY' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>金额2</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bop2Amount' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>合同号</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bopContractNumber' />").appendTo($dataCol);
		var $row = $("<div class='row' />").appendTo($boxcell);
		var $labelCol = $("<div class='label-column' />").appendTo($row);
		var $label = $("<label>发票号</label>").appendTo($labelCol);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $data = $("<input type='text' value='' style='width: 85%;' id='bopInvoiceNumber' />").appendTo($dataCol);

		/* supporting documents section */
		var $row = $("<div class='grid-row' id='batchPaymentSupportingDocumentsSection' style='display: none;' />").appendTo($dialogContent);
		var $cell = $("<div class='grid-cell' />").appendTo($row);
		var $box = $("<div class='box' />").appendTo($cell);
		var $boxHeader = $("<div class='box-header'>Supporting Documents</div>").appendTo($box);
		var $boxContent = $("<div class='box-content top-label' />").appendTo($box);
		var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $gridCell = $("<div class='grid-cell' style='width: 100%' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $btnSpan = $("<span class='form-button primary' id='uploadSupportingDoc' />").appendTo($dataCol);
		var $btnLink = $("<a href='javascript:void(0)'><i class='fa fa-plus fa-fw'></i>Attach Document</a>").appendTo($btnSpan);
		var $fileInput = $("<input type='file' name='file' id='paymentSupportingDoc' style='position: absolute; left: 30px; padding: 0; width: 155px; opacity: 0; filter: alpha(opacity=0); cursor: pointer;' />").appendTo($btnSpan).on("change", handleAttachDocumentToPayment);
		var $progBarDiv = $("<div id='paymentProgressBar' style='display: none;' />").appendTo($dataCol);
		var $progBar = $("<div class='progress-bar' />").appendTo($progBarDiv);
		var $progMeter = $("<div class='progress-meter' />").appendTo($progBar);
		var $gridRow = $("<div class='grid-row' />").appendTo($boxContent);
		var $gridCell = $("<div class='grid-cell' style='width: 100%' />").appendTo($gridRow);
		var $row = $("<div class='row' />").appendTo($gridCell);
		var $dataCol = $("<div class='data-column' />").appendTo($row);
		var $dataTable = $("<div class='data-table' data-supporting-docs='newInstruction' style='display: none;' />").appendTo($dataCol);
		var $dataTableRow = $("<div class='data-table-row' />").appendTo($dataTable);
		var $fileNameCell = $("<div class='data-table-cell' style='width: 70%;'>File Name</div>").appendTo($dataTableRow);
		var $statusCell = $("<div class='data-table-cell' style='width: 30%;'>Status</div>").appendTo($dataTableRow);



		return $dialogContent;
	}

	var _origin = _target.closest(".dialog-parent").length > 0 ? _target.closest(".dialog-parent") : _target;
	var _dialog = {
		id: "addPaymentsToBatchDialog",
		title: "Add A Payment Instruction",
		size: "xxl",
		icon: "<i class='fa fa-plus-square'></i>",
		content: function() {
			return populateAddPaymentDialog();
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Save",
			icon: "<i class='fa fa-save fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveBatchPaymentItem(_dialog, item)
				}
			}],
			cssClass: "primary"
		}, {
			name: "Save and Add Another",
			icon: "<i class='fa fa-save fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveBatchPaymentItem(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	if (item) {
		_dialog.title = "Edit Payment Instruction";
		_dialog.icon = "<i class='fa fa-edit'></i>";
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));

	$("#batchBeneInput").autocomplete({
		autoFocus: true,
		delay: 0,
		minLength: 0,
		appendTo: "#batchBeneInputAutoComplete",
		position: {
			collision: "flip"
		},
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_beneAccounts, extractLast(request.term));
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		focus: function() {
			return false;
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				this.value = "";
				return false;
			} else {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
				if (selectedBatchPaymentBeneficiary != null) {
					if (selectedBatchPaymentBeneficiary.accountnumber != ui.item.accountnumber) {
						var changeBeneAccount = function() {
							$("#batchBeneInput").val(ui.item.name);
							selectedBatchPaymentBeneficiary = ui.item;
							showSelectedBatchPaymentBeneficiaryDetails(ui.item);
							$("#addPaymentsToBatchDialog").addClass("working");
							setTimeout(function() {
								$("#addPaymentsToBatchDialog").removeClass("working");
								resetBatchPaymentItem();
							}, 500);
						}
						buildConfirmDialog("Changing the Beneficiary will reset any payment details you have entered.", "Do you want to proceed?", changeBeneAccount);
					} else {
						return false;
					}
				} else {
					this.value = ui.item.name;
					selectedBatchPaymentBeneficiary = ui.item;
					showSelectedBatchPaymentBeneficiaryDetails(ui.item)
				}
				return false;
			}
		},
		close: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(_beneAccounts, function() {
				if (this.name.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this.name;
					return false;
				}
			});
			$(this).val(matchie);
			if (valid) {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
			}
			if (!valid) {
				$(this).val("");
				selectedBatchPaymentBeneficiary = null;
				showSelectedBatchPaymentBeneficiaryDetails();
			}
			$(this).data().autocomplete.term = null;
		}
	}).data("autocomplete")._renderItem = function(ul, item) {
		if (item.value == "No Matches Found") {
			return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
		} else {
			return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br />" + item.accountnumber + "</a>").appendTo(ul);
		}
	};
	$("#batchBeneInputControl").on("click", function() {
		var isOpen = $("#batchBeneInput").autocomplete("widget").is(":visible")
		if (isOpen) {
			$("#batchBeneInput").autocomplete("close");
		} else {
			$("#batchBeneInput").autocomplete("search", "").focus();
		}
	});


	if (newBatchPayment.individualdebitsflag) {
		$("#batchPaymentCurrency").hide();
		$("#batchPaymentCustomCurrencySelect").show();
		$("#batchPaymentCurrencySelect").val("");
	} else {
		$("#batchPaymentCustomCurrencySelect").hide();
		$("#batchPaymentCurrencySelect").val("");
		$("#batchPaymentCurrency").show();
	}

	fetchPaymentMethods();

	if (item) {
		$("#batchBeneInput").val(batchPaymentItem.beneficiaryname);
		showSelectedBatchPaymentBeneficiaryDetails(selectedBatchPaymentBeneficiary);
		$("#batchPaymentMethodSelection").val(batchPaymentItem.paymentmethod).trigger("change");
		$("#batchPaymentAmountField").val(batchPaymentItem.paymentamount);
		$("#batchPaymentAmountTextValue").html(batchPaymentItem.paymentamount);
		$("#batchPaymentDebitEquivalentAmountField").val(batchPaymentItem.debitequivalentamount);
		$("#batchPaymentDebitEquivalentAmountTextValue").html(batchPaymentItem.debitequivalentamount);
		$("#batchPaymentReference").val(batchPaymentItem.paymentreference);
		$("#batchPaymentPurposeCodeField").val(batchPaymentItem.purposecode);
		$("#batchPaymentRemittanceInformation").val(batchPaymentItem.remittanceinformation);

		if (batchPaymentItem.supportingdocs.length) {

			for (var i = 0, l = batchPaymentItem.supportingdocs.length; i < l; i++) {
				var _doc = batchPaymentItem.supportingdocs[i];
				var $dataTableRow = $("<div class='data-table-row' data-doc-row='true' />"),
					$fileInfoCell = $("<div class='data-table-cell' data-doc-id='" + _doc.id + "' />").appendTo($dataTableRow),
					$removeLink = $("<a href='javasript:void(0)'><i class='fa fa-times fa-fw fa-lg'></i></a>").appendTo($fileInfoCell).on("click", function(e) {
						e.preventDefault();
						$(this).closest("div.data-table-row").remove();
						for (var a = 0, b = batchPaymentItem.supportingdocs.length; a < b; b++) {
							if (batchPaymentItem.supportingdocs[a].id == _doc.id) {
								batchPaymentItem.supportingdocs.splice(a, 1);
							}
						}
						if (!$("div[data-doc-row]='true'").size()) {
							$("div[data-supporting-docs='newInstruction']").hide();
						}
					}),
					$documentLink = $("<span>" + _doc.filename + " (" + _doc.filesize + ")</span>").appendTo($fileInfoCell),
					$statusTableCell = $("<div class='data-table-cell'>" + _doc.status + "</div>").appendTo($dataTableRow);
				$dataTableRow.appendTo($("div[data-supporting-docs='newInstruction']"));
			}
			$("div[data-supporting-docs='newInstruction']").show();
		} else {
			$("div[data-supporting-docs='newInstruction']").hide();
		}

	}

	$("#batchBeneInput").focus();
	$("#addPaymentsToBatchDialog").find("div.dialog-content").scrollTop(0);
}

function viewBatchPaymentItem(_target, item) {}

function removePaymentsFromBatch(e) {
	e.preventDefault();
	var deleteSelectedPayments = function() {
		var removeThesePayments = [];
		for (var i = 0, l = editBatchSelectedRowIds.length; i < l; i++) {
			var item = editBatchSelectedRowIds[i];
			if (item) removeThesePayments.unshift(item)
		};
		for (var i = 0; i < removeThesePayments.length; i++) {
			dataView.deleteItem(removeThesePayments[i])
		};
		editBatchGrid.setSelectedRows(0);
		editBatchSelectedRowIds = [];
		var totalPaymentAmount = 0.00;
		for (var i = 0, l = dataView.getItems().length; i < l; i++) {
			var item = dataView.getItem(i);
			item.number = i + 1;
			totalPaymentAmount = parseFloat(totalPaymentAmount) + parseFloat(item.paymentamount.replace(/[^0-9\.]+/g, ""));
		}
		newBatchPayment.paymentamount = totalPaymentAmount;
		newBatchPayment.debitequivalentamount = totalPaymentAmount;
		totalPaymentAmount = addCommas(totalPaymentAmount.toFixed(2));
		dataView.refresh();
		editBatchGrid.invalidate();
		editBatchGrid.render();
		$("#totalBatchPaymentAmount").empty().html("$" + totalPaymentAmount);
		buildNotification("Selected payments have been removed from this batch", 300, 3000);
	}
	if (editBatchSelectedRowIds.length) {
		buildConfirmDialog("Remove selected payments from this batch?", "", function() {
			deleteSelectedPayments();
		});
	} else {
		return false;
	}
}

/**********************************************************************
DOCUMENT READY
**********************************************************************/
$(function() {



	/* setup payment batch grid */
	var editBatchItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	dataView = new Slick.Data.DataView({
		editBatchItemMetaProvider: editBatchItemMetaProvider
	});
	editBatchGrid = new Slick.Grid("#editBatchGrid", dataView, editBatchColumns, editBatchOptions);
	editBatchGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	editBatchGrid.registerPlugin(editBatchItemMetaProvider);
	editBatchGrid.registerPlugin(editBatchCheckboxSelector);
	editBatchGrid.onSelectedRowsChanged.subscribe(function(e) {
		editBatchSelectedRowIds = [];
		var rows = editBatchGrid.getSelectedRows();
		for (var i = 0, l = rows.length; i < l; i++) {
			var item = dataView.getItem(rows[i])
			if (item.id) editBatchSelectedRowIds.push(item.id)
		}
	});
	editBatchGrid.onSort.subscribe(function(e, args) {
		sortcol = args.sortCol.field;
		sortdir = args.sortAsc ? 1 : -1;
		dataView.fastSort(sortcol, args.sortAsc);
	});
	editBatchGrid.onClick.subscribe(function(e, args) {
		var cell = editBatchGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = dataView.getItem(row);
		editBatchGrid.setSelectedRows(0);
		editBatchSelectedRowIds = [];
		addPaymentsToBatch($(e.target), item);
	});
	dataView.onRowCountChanged.subscribe(function(e, args) {
		editBatchGrid.updateRowCount();
		editBatchGrid.render();
	});
	dataView.onRowsChanged.subscribe(function(e, args) {
		editBatchGrid.invalidateRows(args.rows);
		editBatchGrid.render();
		if (editBatchSelectedRowIds.length > 0) {
			var selRows = [];
			for (var i = 0; i < editBatchSelectedRowIds.length; i++) {
				var idx = dataView.getRowById(editBatchSelectedRowIds[i]);
				if (idx != undefined)
					selRows.push(idx);
			}
			editBatchGrid.setSelectedRows(selRows);
		}
	});
	dataView.setItems(editBatchData);
	editBatchGrid.setColumns(editBatchColumns);

	/* setup review batch grid */
	var reviewItemMetaProvider = new Slick.Data.GroupItemMetadataProvider();
	reviewDataView = new Slick.Data.DataView({
		reviewItemMetaProvider: reviewItemMetaProvider
	});
	reviewGrid = new Slick.Grid("#reviewGrid", reviewDataView, reviewColumns, reviewOptions);
	reviewGrid.setSelectionModel(new Slick.RowSelectionModel({
		selectActiveRow: false
	}));
	reviewGrid.registerPlugin(reviewItemMetaProvider);
	reviewGrid.onSort.subscribe(function(e, args) {
		sortcol = args.sortCol.field;
		sortdir = args.sortAsc ? 1 : -1;
		reviewDataView.fastSort(sortcol, args.sortAsc);
	});
	reviewGrid.onClick.subscribe(function(e, args) {
		var cell = reviewGrid.getCellFromEvent(e);
		var row = cell.row;
		var $row = $(e.target).closest(".slick-row");
		var item = reviewDataView.getItem(row);
		addPaymentsToBatch($(e.target), item);
	});
	reviewDataView.setItems(reviewData);
	reviewGrid.setColumns(reviewColumns);

	$(window).on("resize", function() {
		editBatchGrid.resizeAndRender();
		reviewGrid.resizeAndRender();
	});
	$(window).on("resize", _.debounce(function(e) {
		editBatchGrid.resizeAndRender();
		reviewGrid.resizeAndRender();
	}, 100));


	/**********************************************************************
	NEW REQUEST INITIALIZATION
	**********************************************************************/


	/* SINGLE PAYMENT STEP FUNCTIONS */
	$("[data-action='new-payment']").on("click", setupNewPayment);
	$("[data-action='previousStep']").on("click", previousStepFunction);
	$("[data-action='cancelPaymentEntry']").on("click", cancelPaymentFunction);
	$("[data-action='nextStep']").on("click", paymentNextStep);
	$("[data-action='saveDraft']").on("click", confirmSaveAsDraft);
	$("[data-action='submitPayment']").on("click", confirmSubmitPayment);
	$("[data-action='closePaymentEntry']").on("click", closePayment);
	$("[data-action='closeBatchPayment']").on("click", closeBatchPayment);


	/* SINGLE PAYMENT FORM FIELD FUNCTIONS */

	$("#divisionSelectInput").on("change", handleDivisionChanges);

	$("#debitAccountInput").autocomplete({
		autoFocus: true,
		delay: 10,
		minLength: 0,
		appendTo: "#debitAccountInputAutoComplete",
		position: {
			my: "left top",
			at: "left bottom",
			collision: "flip"
		},
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_debitAccounts, extractLast(request.term).trim());
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		focus: function() {
			return false;
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				this.value = "";
				return false;
			} else {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
				if (selectedDebitAccount != null && step == 3) {
					if (selectedDebitAccount.number != ui.item.number) {
						if (type == "payotherdomesticbatch" || type == "payotherinternationalbatch") {
							var changeDebitAccount = function() {
								$("#debitAccountInput").val(ui.item.label);
								selectedDebitAccount = ui.item;
								showSelectedDebitAccountDetails(ui.item);
								newBatchPayment.payments = [];
								editBatchData = newBatchPayment.payments;
								dataView.setItems(editBatchData);
								editBatchGrid.invalidateAllRows();
								editBatchGrid.render();
								newBatchPayment.paymentamount = 0.00;
								newBatchPayment.debitequivalentamount = 0.00;
								$("#totalBatchPaymentAmount").html("$" + addCommas(newBatchPayment.paymentamount.toFixed(2)));
								$("#batchPaymentSection, #fxSection, #documentSection").hide();
								$("#paymentScreen").addClass("working");
								var batchloadTimer = setTimeout(function() {
									continuePaymentDataEntry(type);
									$("#paymentScreen").removeClass("working");
								}, 500);
							}
							buildConfirmDialog("Changing the Debit Account will reset the batch and remove any payments that have been added.", "Do you want to proceed?", changeDebitAccount);
						} else {
							var changeDebitAccount = function() {
								$("#debitAccountInput").val(ui.item.label);
								selectedDebitAccount = ui.item;
								showSelectedDebitAccountDetails(ui.item);
								resetSinglePaymentDataEntryFiels();
							}
							buildConfirmDialog("Changing the Debit Account will reset any payment details you have entered.", "Do you want to proceed?", changeDebitAccount);
						}
					} else {
						return false;
					}
				} else {
					this.value = ui.item.label;
					selectedDebitAccount = ui.item;
					showSelectedDebitAccountDetails(ui.item)
				}
				return false;
			}
		},
		close: function(event, ui) {
			var matcher = $(this).val().trim();
			var matchie = "";
			var valid = false;
			$.each(_debitAccounts, function() {
				if (this.label.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this.label;
					return false;
				}
			});
			if (valid) {
				$(this).val(matchie);
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
			}
			if (!valid) {
				$(this).val("");
				selectedDebitAccount = null;
				showSelectedDebitAccountDetails();
			}
			$(this).data().autocomplete.term = null;
		}
	}).data("autocomplete")._renderItem = function(ul, item) {
		if (item.value == "No Matches Found") {
			return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
		} else {
			return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.number + "</b><br />" + item.name + " &nbsp;&nbsp; " + item.ccy + "</a>").appendTo(ul);
		}
	};
	$("#debitInputControl").on("click", function() {
		var isOpen = $("#debitAccountInput").autocomplete("widget").is(":visible")
		if (isOpen) {
			$("#debitAccountInput").autocomplete("close");
		} else {
			$("#debitAccountInput").autocomplete("search", "").focus();
		}
	});

	$("#creditAccountInput").autocomplete({
		autoFocus: true,
		delay: 0,
		minLength: 0,
		appendTo: "#creditAccountInputAutoComplete",
		position: {
			my: "left top",
			at: "left bottom",
			collision: "flip"
		},
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_creditAccounts, extractLast(request.term).trim());
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		focus: function() {
			return false;
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				this.value = "";
				return false;
			} else {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
				if (selectedCreditAccount != null && step == 3) {
					if (selectedCreditAccount.number != ui.item.number) {
						var changeCreditAccount = function() {
							$("#creditAccountInput").val(ui.item.label);
							selectedCreditAccount = ui.item;
							showSelectedCreditAccountDetails(ui.item);
							resetSinglePaymentDataEntryFiels();
						}
						buildConfirmDialog("Changing the Credit Account will reset any payment details you have entered.", "Do you want to proceed?", changeCreditAccount);
					} else {
						return false;
					}
				} else {
					this.value = ui.item.label;
					selectedCreditAccount = ui.item;
					showSelectedCreditAccountDetails(ui.item)
				}
				return false;
			}
		},
		close: function(event, ui) {
			var matcher = $(this).val().trim();
			var matchie = "";
			var valid = false;
			$.each(_creditAccounts, function() {
				if (this.label.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this.label;
					return false;
				}
			});
			$(this).val(matchie);
			if (valid) {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
			}
			if (!valid) {
				$(this).val("");
				selectedCreditAccount = null;
				showSelectedCreditAccountDetails();
			}
			$(this).data().autocomplete.term = null;
		}
	}).data("autocomplete")._renderItem = function(ul, item) {
		if (item.value == "No Matches Found") {
			return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
		} else {
			return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.number + "</b><br />" + item.name + " &nbsp;&nbsp; " + item.ccy + "</a>").appendTo(ul);
		}
	};
	$("#creditInputControl").on("click", function() {
		var isOpen = $("#creditAccountInput").autocomplete("widget").is(":visible")
		if (isOpen) {
			$("#creditAccountInput").autocomplete("close");
		} else {
			$("#creditAccountInput").autocomplete("search", "").focus();
		}
	});

	$("#paymentMethodSelection").on("change", handlePaymentMethodChanges);

	$("#paymentDateInput").datepicker({
		dateFormat: 'dd/mm/yy',
		constrainInput: true,
		changeMonth: true,
		changeYear: true,
		duration: 0,
		minDate: 0,
		showOn: "button",
		buttonImage: "img/datepicker-icon.png",
		buttonImageOnly: true,
		buttonText: "Select date",
		beforeShow: function() {
			var widget = $("#paymentDateInput").datepicker("widget");
			widget.appendTo($("#paymentDateCalendar"));
			$("#paymentDateCalendar").show();
		},
		onClose: function() {
			var widget = $("#paymentDateInput").datepicker("widget");
			widget.appendTo($("body"));
		}
	}).mask("99/99/9999", {
		placeholder: "dd/mm/yyyy"
	}).on("change", function() {
		var $row = $(this).closest("div.row"),
			$dataCol = $(this).closest("div.data-column");
		if ($(this).val()) {
			if ($row.hasClass('error')) {
				$row.removeClass("error").find("div.data-error").remove();
			}
			var stringval = $(this).val(),
				testdate;
			try {
				testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
			} catch (e) {
				$row.addClass("error");
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Payment Date is not valid");
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is not valid");
				}
			} finally {
				if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
					$row.addClass("error");
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Payment Date cannot be in the past");
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Payment Date cannot be in the past");
					}
				} else {
					newSinglePayment.paymentdate = $(this).val();
				}
			}
		} else {
			if ($row.hasClass('error')) {
				$row.removeClass("error").find("div.data-error").remove();
			}
		}
	});

	$("#paymentCurrencySelect").on("change", handlePaymentCurrencyChanges);

	$("#paymentAmountInputField, #debitEquivalentAmountField").on({
		keydown: function(e) {
			preventAlphaKeys(e)
		},
		change: function(e) {
			handleAmountChanges($(this));
			if ($(this).closest("div.row").hasClass('error')) {
				$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
			}
			if ($(this).hasClass("error")) {
				$(this).removeClass("error").closest("div.row").find("div.label-column").removeClass("error");
				$(this).closest("div.row").find("div.data-error").remove();
			}
		}
	});

	$("#useDebitAmount").on("change", handleDebitEquivalentFlag);

	$("#fxSelection").on("change", handleRateTypeChanges);

	$("#useCardedRateFlag").on("change", handleCardedRateInContracts)

	$("#paymentReference").on("change", handlePaymentReferenceChanges);

	$("#debitAdviceDescription").on("change", handleDebitAdviceChanges);

	$("#remittanceInformation").on("change", handleRemittanceChanges);

	$("#purposeCodeSelection").on("change", handlePurposeCodeChanges);

	$("#chargesSelection").on("change", handleChargesChanges);

	$("#bopPriority, #bopAmountInWords, #bopUnitCode, #bopResidentRegionName, #bopResidentRegionCode, #bopField1, #bopField2, #bopField3, #bopField4, #bopField5, #bop1TransCode, #bop1TransDesc, #bop1CCY, #bop1Amount, #bop2TransCode, #bop2TransDesc, #bop2CCY, #bop2Amount, #bopContractNumber, #bopInvoiceNumber").on("change", handleBOPFieldChanges);

	$("#individualDebitsFlag").on("change", handleIndividualDebitsFlag);

	$("#urgentFlag").on("change", handleUrgentFlag);

	$("#batchNameInput").on("change", handleBatchNameChanges);

	$("#batchReferenceInput").on("change", handleBatchReferenceChanges);

	$("#batchPaymentCurrencySelection").on("change", handleBatchCurrencyChanges);

	$("#batchDebitEquivalentFlag").on("change", handleBatchPaymentDebitEquivalentFlag)


	$("#beneInput").autocomplete({
		autoFocus: true,
		delay: 0,
		minLength: 0,
		appendTo: "#beneInputAutoComplete",
		position: {
			my: "left top",
			at: "left bottom",
			collision: "flip"
		},
		source: function(request, response) {
			var results = $.ui.autocomplete.filter(_beneAccounts, extractLast(request.term));
			if (!results.length) {
				results = [{
					value: 'No Matches Found'
				}];
			}
			response(results);
		},
		focus: function() {
			return false;
		},
		select: function(event, ui) {
			if (ui.item.value == "No Matches Found") {
				this.value = "";
				return false;
			} else {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
				if (selectedBeneAccount != null && step == 3) {
					if (selectedBeneAccount.accountnumber != ui.item.accountnumber) {
						var changeBeneAccount = function() {
							$("#beneInput").val(ui.item.name);
							selectedBeneAccount = ui.item;
							showSelectedBeneficiaryDetails(ui.item);
							resetSinglePaymentDataEntryFiels();
						}
						buildConfirmDialog("Changing the Beneficiary will reset any payment details you have entered.", "Do you want to proceed?", changeBeneAccount);
					} else {
						return false;
					}
				} else {
					this.value = ui.item.name;
					selectedBeneAccount = ui.item;
					showSelectedBeneficiaryDetails(ui.item)
				}
				return false;
			}
		},
		close: function(e, ui) {
			var matcher = $(this).val();
			var matchie = "";
			var valid = false;
			$.each(_beneAccounts, function() {
				if (this.name.toLowerCase() == matcher.toLowerCase()) {
					valid = true;
					matchie = this.name;
					return false;
				}
			});
			$(this).val(matchie);
			if (valid) {
				if ($(this).closest("div.row").hasClass("error")) {
					$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
				}
			}
			if (!valid) {
				$(this).val("");
				selectedBeneAccount = null;
				showSelectedBeneficiaryDetails();
			}
			$(this).data().autocomplete.term = null;
		}
	}).data("autocomplete")._renderItem = function(ul, item) {
		if (item.value == "No Matches Found") {
			return $("<li></li>").data("item.autocomplete", item).append("<a>" + item.value + "</a>").appendTo(ul);
		} else {
			return $("<li></li>").data("item.autocomplete", item).append("<a><b>" + item.name + "</b><br />" + item.accountnumber + "</a>").appendTo(ul);
		}
	};
	$("#beneInputControl").on("click", function() {
		var isOpen = $("#beneInput").autocomplete("widget").is(":visible")
		if (isOpen) {
			$("#beneInput").autocomplete("close");
		} else {
			$("#beneInput").autocomplete("search", "").focus();
		}
	});

	$("#batchPaymentDateInput").datepicker({
		dateFormat: 'dd/mm/yy',
		constrainInput: true,
		changeMonth: true,
		changeYear: true,
		duration: 0,
		minDate: 0,
		showOn: "button",
		buttonImage: "img/datepicker-icon.png",
		buttonImageOnly: true,
		buttonText: "Select date",
		beforeShow: function() {
			var widget = $("#batchPaymentDateInput").datepicker("widget");
			widget.appendTo($("#batchPaymentDateCalendar"));
			$("#batchPaymentDateCalendar").show();
		},
		onClose: function() {
			var widget = $("#batchPaymentDateInput").datepicker("widget");
			widget.appendTo($("body"));
		}
	}).mask("99/99/9999", {
		placeholder: "dd/mm/yyyy"
	}).on("change", function() {
		var $row = $(this).closest("div.row"),
			$dataCol = $(this).closest("div.data-column");
		if ($(this).val()) {
			if ($row.hasClass('error')) {
				$row.removeClass("error").find("div.data-error").remove();
			}
			var stringval = $(this).val(),
				testdate;
			try {
				testdate = $.datepicker.parseDate('dd/mm/yy', stringval);
			} catch (e) {
				$row.addClass("error");
				if ($row.find("div.data-error").size()) {
					$row.find("div.data-error").html("Payment Date is not valid");
				} else {
					$("<div class='data-error' />").appendTo($dataCol).html("Payment Date is not valid");
				}
			} finally {
				if (new Date(testdate).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0) < 0) {
					$row.addClass("error");
					if ($row.find("div.data-error").size()) {
						$row.find("div.data-error").html("Payment Date cannot be in the past");
					} else {
						$("<div class='data-error' />").appendTo($dataCol).html("Payment Date cannot be in the past");
					}
				} else {
					newBatchPayment.paymentdate = $(this).val();
					for (var i = 0, l = newBatchPayment.payments.length; i < l; i++) {
						newBatchPayment.payments[i].paymentdate = newBatchPayment.paymentdate;
					}
				}
			}
		} else {
			if ($row.hasClass('error')) {
				$row.removeClass("error").find("div.data-error").remove();
			}
		}
	});


	/* batch name input */
	$("#batchNameInput").on("change", function() {
		if ($(this).val && $(this).closest("div.row").hasClass('error')) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
	});

	/* batch refereence */
	$("#batchReferenceInput").on("change", function() {
		if ($(this).val && $(this).closest("div.row").hasClass('error')) {
			$(this).closest("div.row").removeClass("error").find("div.data-error").remove();
		}
	});


	/* account detail dialogs */
	$("#showDebAccountDeatilsDialog, #showCredAccountDeatilsDialog, #selectedDebitAccountNumber, #selectedCreditAccountNumber").on("click", showAccountDetailsDialog);

	/* debit advice dialog */
	$("#debitAdviceDialogLink").on("click", showEditBatchDescriptionDialog);

	$("#viewDebitAdviceDialogLink").on("click", viewDebitAdviceDescriptionDialog);

	/* add payments to batch */
	$("#addPaymentsToBatch").on("click", function(e) {
		e.preventDefault();
		addPaymentsToBatch($(this));
	});

	/* remove payments from batch */
	$("#removePaymentsFromBatch").on("click", removePaymentsFromBatch);

	/* batch FX Rate Selection */
	$("#batchFXSelection").on("change", checkBatchFXRate);

	/* SEARCH DIALOG WINDOWS */
	$("#searchDebitAccountsDialog").on("click", function(e) {
		e.preventDefault();
		showAddDebitAccount($(this));
	});

	$("#searchCreditAccountsDialog").on("click", function(e) {
		e.preventDefault();
		showAddCreditAccount($(this));
	});

	$("#searchBeneDialog").on("click", function(e) {
		e.preventDefault();
		showAddBeneAccount($(this));
	});

	$("#fxContractSearch").on("click", function(e) {
		e.preventDefault();
		showDealNumberSearch($(this));
	});

	$("#instAttachSupportingDoc").on("change", hanldeAttachDocument);


	/* file upload */
	$("a[data-type='payfileupload']").on("click", triggerUploadDialog);


	/* template search */
	$("a[data-type='paytemplates']").on("click", triggerTemplateDialog);


});