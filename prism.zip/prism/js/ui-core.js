/* CLEAR LOCAL STORAGE */
/* if the version number is changed clear the local storage
var version = "20170419";
if (!store.get('stored_tbos_version') || store.get('stored_tbos_version') != version) {
	localStorage.clear();
}
store.set('stored_tbos_version', version);
 */


/********** UTILITIES **********/

/* smart dates */
function smartDates(date) {
	var _dates, date = date.toLowerCase()
	switch (date) {
		case "today":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date());
			break;
		case "yesterday":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - 1)));
			break;
		case "weektodate":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - (new Date().getDay() + 6) % 7))) + "&nbsp;&nbsp;-&nbsp;&nbsp;" + $.datepicker.formatDate('dd/mm/yy', new Date());
			break;
		case "lastweek":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate((new Date().getDate() - (new Date().getDay() + 6) % 7) - 7))) + "&nbsp;&nbsp;-&nbsp;&nbsp;" + $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(((new Date().getDate() - (new Date().getDay() + 6) % 7) - 7) + 6)));
			break;
		case "monthtodate":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().getFullYear(), new Date().getMonth(), 1)) + "&nbsp;&nbsp;-&nbsp;&nbsp;" + $.datepicker.formatDate('dd/mm/yy', new Date());
			break;
		case "lastmonth":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1)) + "&nbsp;&nbsp;-&nbsp;&nbsp;" + $.datepicker.formatDate('dd/mm/yy', new Date(new Date().getFullYear(), new Date().getMonth(), 0));
			break;
		case "randompast":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() - rand(1, 365))));
			break;
		case "randomfuture":
			_date = $.datepicker.formatDate('dd/mm/yy', new Date(new Date().setDate(new Date().getDate() + rand(0, 30))));
			break;
	}
	return _date;
}

/* time formatter */
function timeFormatter() {
	var date = new Date();
	var time = date.toLocaleTimeString();
	return time;
}

/* random string generator */
function randString(n) {
	if (!n) {
		n = 5
	}
	var text = '',
		possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
	for (var i = 0; i < n; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length))
	}
	return text;
}

/* random number generator */
function randNumber(n) {
	if (!n) {
		n = 5
	}
	var text = '',
		possible = '123456789';
	for (var i = 0; i < n; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length))
	}
	return text;
}

/* random from array */
function rand(min, max) {
	var offset = min;
	var range = (max - min) + 1;
	var randomNumber = Math.floor(Math.random() * range) + offset;
	return randomNumber;
}

function generateRandomDecimal(min, max) {
	var min = min,
		max = max,
		dnumber = (Math.random() * (max - min) + min).toFixed(3);
	return dnumber;
}

function isObject(val) {
	if (val === null) {
		return false;
	}
	return ((typeof val === 'function') || (typeof val === 'object'));
}

function getDataItemValue(item, column) {
	var values = item[column.field];
	if (column.fieldIdx !== undefined) {
		return values && values[column.fieldIdx];
	} else {
		return values;
	}
}

function getSortDataByIdx(item, idx) {
	return item[idx];
}

function sorterStringCompare(a, b) {
	var x = a[sortcol],
		y = b[sortcol];
	return sortdir * (x === y ? 0 : (x > y ? 1 : -1));
}

function sorterStringCompareWithFieldIDX(a, b, idx) {
	var x = getSortDataByIdx(a[sortcol], idx),
		y = getSortDataByIdx(b[sortcol], idx);
	return sortdir * (x === y ? 0 : (x > y ? 1 : -1));
}

function sorterNumeric(a, b) {
	var numb_a = (isNaN(a[sortcol])) ? a[sortcol].replace(/[^\d\.\-\ ]/g, '') : a[sortcol];
	var numb_b = (isNaN(b[sortcol])) ? b[sortcol].replace(/[^\d\.\-\ ]/g, '') : b[sortcol];
	var x = (isNaN(numb_a) || numb_a === "" || numb_a === null) ? -99e+10 : parseFloat(numb_a);
	var y = (isNaN(numb_b) || numb_b === "" || numb_b === null) ? -99e+10 : parseFloat(numb_b);
	return sortdir * (x === y ? 0 : (x > y ? 1 : -1));
}

function sorterDateIso(a, b) {
	var regex_a = new RegExp("^((19[1-9][1-9])|([2][01][0-9]))\\d-([0]\\d|[1][0-2])-([0-2]\\d|[3][0-1])(\\s([0]\\d|[1][0-2])(\\:[0-5]\\d){1,2}(\\:[0-5]\\d){1,2})?$", "gi");
	var regex_b = new RegExp("^((19[1-9][1-9])|([2][01][0-9]))\\d-([0]\\d|[1][0-2])-([0-2]\\d|[3][0-1])(\\s([0]\\d|[1][0-2])(\\:[0-5]\\d){1,2}(\\:[0-5]\\d){1,2})?$", "gi");

	if (regex_a.test(a[sortcol]) && regex_b.test(b[sortcol])) {
		var date_a = new Date(a[sortcol]);
		var date_b = new Date(b[sortcol]);
		var diff = date_a.getTime() - date_b.getTime();
		return sortdir * (diff === 0 ? 0 : (date_a > date_b ? 1 : -1));
	} else {
		var x = a[sortcol],
			y = b[sortcol];
		return sortdir * (x === y ? 0 : (x > y ? 1 : -1));
	}
}

function escapeHtmlEntities(str) {
	return str
		.replace(/&/g, '&amp;')
		.replace(/>/g, '&gt;')
		.replace(/</g, '&lt;')
		.replace(/"/g, '&quot;')
		.replace(/\n/g, '<br \\>');
}

function stripHTMLEntities(str) {
	return str
		.replace(/&/g, '')
		.replace(/>/g, '')
		.replace(/</g, '')
		.replace(/"/g, '')
		.replace(/\n/g, '');
}

function extractSplit(val) {
	return val.split(/,\s*/);
}

function split(val) {
	return val.split(/,\s*/);
}

function extractLast(term) {
	return extractSplit(term).pop();
}

function addCommas(nStr) {
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2')
	}
	return x1 + x2;
}

function removeCommas(str) {
	while (str.search(",") >= 0) {
		str = (str + "").replace(',', '');
	}
	return str;
}

function clearFormElements(id) {
	jQuery("#" + id).find(':input').each(function() {
		switch (this.type) {
			case 'password':
			case 'text':
			case 'textarea':
			case 'file':
			case 'select-one':
			case 'select-multiple':
				jQuery(this).val('');
				break;
			case 'checkbox':
			case 'radio':
				this.checked = false;
		}
	});
}


/* prevent alpha keys on numeric only fields */
function preventAlphaKeys(e) {
	if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 188, 190]) !== -1 ||
		(e.keyCode == 65 && e.ctrlKey === true) ||
		(e.keyCode == 67 && e.ctrlKey === true) ||
		(e.keyCode == 88 && e.ctrlKey === true) ||
		(e.keyCode >= 35 && e.keyCode <= 39)) {
		return;
	}
	if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
		e.preventDefault();
	}
}



/* test for transition end event */
function isTransitionsSupported() {
	var thisBody = document.body || document.documentElement,
		thisStyle = thisBody.style,
		support = thisStyle.transition !== undefined ||
		thisStyle.WebkitTransition !== undefined ||
		thisStyle.MozTransition !== undefined ||
		thisStyle.MsTransition !== undefined ||
		thisStyle.OTransition !== undefined;
	return support;
}
var transitionSupport = isTransitionsSupported();



/********** NAVIGATION AND SERVICES SLIDING PANELS **********/

/* navigation timers */
var loadSubmenuTimer, loadPageTimer;

/* hide left navigation */
function hideNavigation() {
	$(document).off(".navigation");
	if (transitionSupport) {
		$(".shell").removeClass("slide-right").on("transitionend.nav webkitTransitionEnd.nav oTransitionEnd.nav MSTransitionEnd.nav", function(e) {
			hideApplicationMenu();
			$(this).off(".nav");
		});
	} else {
		$(".shell").removeClass("slide-right").animate({
			left: 60,
			right: 0
		}, {
			duration: 300,
			queue: false,
			complete: function(e) {
				hideApplicationMenu();
			}
		});
	}
}

/* show left navigation */
function showNavigation(e) {
	e.preventDefault();
	var $shell = $(".shell"),
		$nav = $(".nav-main"),
		isRight = $shell.hasClass("slide-right"),
		isLeft = $shell.hasClass("slide-left");
	if (isRight) {
		hideNavigation()
	} else {
		$nav.show();
		if (isLeft) {
			hideServices()
		}
		if (transitionSupport) {
			$shell.off(".nav").addClass("slide-right");
		} else {
			$shell.addClass("slide-right").animate({
				left: 343,
				right: -343
			}, {
				duration: 300,
				queue: false
			});
		}
		$(document).on("keyup.navigation", function(e) {
			if (e.keyCode == 27 || e.keyCode == 37) {
				hideNavigation()
			}
		}).on("click.navigation", function(e){
			var $target = $(e.target);
			if ( $target.closest("div.nav-main").length != 1 ) {
				hideNavigation();
			}
		});
	}
}

/* hide application menu */
function hideApplicationMenu() {
	$(".nav-main").css({
		"overflow-y": "auto"
	});
}

/* show application menu */
function showApplicationMenu(e) {
	e.preventDefault();
	var $shell = $(".shell"),
		$nav = $(".nav-main"),
		isRight = $shell.hasClass("slide-right"),
		isLeft = $shell.hasClass("slide-left");
	if ($(this).parent("li").hasClass("active")) {
		if (isRight) {
			hideNavigation();
		} else {
			showNavigation(e);
		}
	} else {
		clearTimeout(loadSubmenuTimer);
		if (!isRight) {
			showNavigation(e);
		}
		$(".nav-main-list li.active").removeClass("active");
		$(".nav-main-list li div.app-menu.loading").removeClass("loading");
		$(this).parent("li").addClass("active");
		$(".nav-main").css({
			"overflow-y": "hidden"
		});
		$(this).next("div.app-menu").addClass("loading");
		loadSubmenuTimer = setTimeout(function() {
			$("div.app-menu.loading").removeClass("loading")
		}, 200);
	}
}

/* hide services menus */
function hideServices() {
	$(document).off(".services");
	$(".services ul li.highlight").removeClass("highlight");
	if (transitionSupport) {
		$(".shell").removeClass("slide-left").on("transitionend.services webkitTransitionEnd.services oTransitionEnd.services MSTransitionEnd.services", function() {
			$(".services ul li.active").removeClass("active");
			$(this).off(".services");
		});
	} else {
		$(".shell").removeClass("slide-left").animate({
			left: 60,
			right: 0
		}, {
			duration: 300,
			queue: false,
			complete: function() {
				$(".services ul li.active").removeClass("active");
			}
		});
	}
}

/* show services menus */
function showServices(e) {
	e.preventDefault();
	var $target = $(e.target).closest("li"),
		$shell = $(".shell"),
		isActive = $target.hasClass("active"),
		isRight = $shell.hasClass("slide-right"),
		isLeft = $shell.hasClass("slide-left");
	$shell.off(".services");
	if (isActive) {
		hideServices()
	} else {
		if (isLeft) {
			$(".services ul li.active").removeClass("active highlight");
		} else {
			if (isRight) {
				hideNavigation()
			}
			if (transitionSupport) {
				$shell.off(".services").addClass("slide-left");
			} else {
				$shell.addClass("slide-left").animate({
					left: -340,
					right: 340
				}, {
					duration: 300,
					queue: false
				});
			}
		}
		$target.addClass("active highlight");
		$(document).on("keyup.services", function(e) {
			if (e.keyCode == 27 || e.keyCode == 39) {
				hideServices()
			}
		}).on("click.services", function(e){
			var $target = $(e.target);
			if ( $target.closest("div.services").length != 1 ) {
				hideServices();
			}
		});
	}
}



/********* USER MENU **********/

/* toggle the user menu */
function toggleUserMenu(e) {
	e.stopPropagation();
	e.preventDefault();
	if ($(".workspace-menu").is(":visible")) {
		toggleWorkspaceMenu(e);
	}
	var $usermenu = $(".user-menu");
	if ($usermenu.is(":visible")) {
		$(".header").css({
			position: "fixed"
		});
		$(".user-name a").removeClass("open");
		$usermenu.hide();
		$(document).off(".user-menu");
	} else {
		$(".header").css({
			position: "absolute"
		});
		$(this).addClass("open");
		$usermenu.show();
		$(document).on("keyup.user-menu", function(e) {
			if (e.keyCode == 27) {
				toggleUserMenu(e)
			}
		});
		$(document).one("click.user-menu", function(e) {
			toggleUserMenu(e)
		});
	}
}

/* build the user preferences form */
function populateUserPreferences() {
	var preferencesFormElements = [{
		name: "Date Format",
		id: "upf1",
		type: "select",
		data: ["mmm dd, yyyy", "dd/mm/yyyy", "mm/dd/yyyy"]
	}, {
		name: "Time Format",
		id: "upf2",
		type: "select",
		data: ["hh24:mi:ss", "hh:mm:ss AM/PM"]
	}, {
		name: "Time Zone",
		id: "upf3",
		type: "select",
		data: ["(GMT -12:00) Eniwetok, Kwajalein", "(GMT -11:00) Midway Island, Samoa", "(GMT -10:00) Hawaii", "(GMT -9:00) Alaska", "(GMT -8:00) Pacific Time (US, Canada)", "(GMT -7:00) Mountain Time (US, Canada)", "(GMT -6:00) Central Time (US, Canada), Mexico City", "(GMT -5:00) Eastern Time (US, Canada), Bogota, Lima", "(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz", "(GMT -3:30) Newfoundland", "(GMT -3:00) Brazil, Buenos Aires, Georgetown", "(GMT -2:00) Mid-Atlantic", "(GMT -1:00 hour) Azores, Cape Verde Islands", "(GMT) Western Europe Time, London, Lisbon, Casablanca", "(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris", "(GMT +2:00) Kaliningrad, South Africa", "(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg", "(GMT +3:30) Tehran", "(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi", "(GMT +4:30) Kabul", "(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent", "(GMT +5:30) Bombay, Calcutta, Madras, New Delhi", "(GMT +5:45) Kathmandu", "(GMT +6:00) Almaty, Dhaka, Colombo", "(GMT +7:00) Bangkok, Hanoi, Jakarta", "(GMT +8:00) Beijing, Perth, Singapore, Hong Kong", "(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk", "(GMT +9:30) Adelaide, Darwin", "(GMT +10:00) Eastern Australia, Guam, Vladivostok", "(GMT +11:00) Magadan, Solomon Islands, New Caledonia", "(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka"]
	}, {
		name: "Decimal Separator",
		id: "upf4",
		type: "select",
		data: [". (Period)", ", (Comma)"]
	}, {
		name: "Thousand Separator",
		id: "upf5",
		type: "select",
		data: [". (Period)", ", (Comma)"]
	}, {
		name: "Report Retrieval Code",
		id: "upf6",
		type: "password",
		max: 20,
		placeholder: "Enter up to 20 characters"
	}, {
		name: "Encoding",
		id: "upf7",
		type: "select",
		data: ["UTF-8", "Traditional Chinese - Big5", "Japanese - JIS", "Japanese - Kana", "Vietnamese - Windows"]
	}, {
		name: "Reference Currency",
		id: "upf8",
		type: "select",
		data: ["AUD", "CNY", "EUR", "HKD", "IDR", "INR", "KRW", "KHR", "MYR", "NZD", "SGD", "THB", "USD", "VND"]
	}];
	var $userPrefsForm = $("<div class='data-form' />"),
		$formSection = $("<div class='form-section' />").appendTo($userPrefsForm);
	for (var i = 0; i < preferencesFormElements.length; i++) {
		var $row = $("<div class='row mandatory' />").appendTo($formSection),
			$label = $("<div class='label-column'><label>" + preferencesFormElements[i].name + "</label></div>)").appendTo($row),
			$data = $("<div class='data-column' />").appendTo($row),
			$select, $password, $toggle, $el;
		if (preferencesFormElements[i].type == "select") {
			$el = $("<div class='custom-select' style='width: 70%;' />"),
				$select = $("<select id='" + preferencesFormElements[i].id + "'></select>").appendTo($el);
			if (preferencesFormElements[i].data) {
				for (var d = 0; d < preferencesFormElements[i].data.length; d++) {
					var $option = $("<option>" + preferencesFormElements[i].data[d] + "</option>").appendTo($select)
				}
			}
		} else if (preferencesFormElements[i].type == "input") {
			$el = $("<input type='text' id='" + preferencesFormElements[i].id + "' maxlength='" + preferencesFormElements[i].max + "' placeholder='" + preferencesFormElements[i].placeholder + "' style='width: 70%;' />").appendTo($data)
		} else if (preferencesFormElements[i].type == "password") {
			$el = $("<div class='custom-input' style='width: 70%;' />").appendTo($data),
				$input = $("<input type='text' id='show-" + preferencesFormElements[i].id + "' maxlength='" + preferencesFormElements[i].max + "' placeholder='" + preferencesFormElements[i].placeholder + "' style='width: 70%; display: none;' />").appendTo($el),
				$password = $("<input type='password' id='" + preferencesFormElements[i].id + "' maxlength='" + preferencesFormElements[i].max + "' placeholder='" + preferencesFormElements[i].placeholder + "' autocomplete='false' style='width: 70%;' />").appendTo($el).attr("autocomplete", 'off'),
				$toggle = $("<div class='form-button small primary' style='position: absolute; top: 2px; right: 2px; padding: 0 8px;'>Show</div>").on("click", function(e) {
					var $target = $(e.target),
						$show = $target.parent("div").children("input[type='text']"),
						$hide = $target.parent("div").children("input[type='password']"),
						_state = ($target.html() == "Show") ? "Hide" : "Show";
					$target.html(_state);
					if (_state == "Hide") {
						$show.val($hide.val()).show();
						$hide.hide();
					} else {
						$hide.val($show.val()).show();
						$show.hide();
					}
				}).appendTo($el);
		}
		$el.appendTo($data);
	}
	return $userPrefsForm;
}

/* save the user preferences form */
function saveUserPreferences(dialog) {
	var $dialog = $("#" + dialog.id);
	$dialog.addClass("working");
	setTimeout(function() {
		$dialog.removeClass("working");
		buildErrorNotification("Error Notification", "This is to demonstrate the error notification UI.", 200);
	}, 800);
}

/* show user preferences dialog */
function showUserPreferencesDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "UserPreferences",
		title: "Set Preferences",
		size: "medium",
		icon: "<i class='fa fa-gear'></i>",
		content: function() {
			return populateUserPreferences()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					saveUserPreferences(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

/* load user language form */
function populateUserLanguage() {
	var $userLanguage = $("<div class='data-form top-label' />"),
		$formSection = $("<div class='form-section' />").appendTo($userLanguage),
		$row = $("<div class='row' />").appendTo($formSection),
		$label = $("<div class='label-column' style='vertical-align: top'><label>Available Languages</label></div>").appendTo($row),
		$data = $("<div class='data-column' style='vertical-align: top'><select size='10' style='width: 80%;'><option>Bahasa Indonesia</option><option>Bahasa Melayu</option><option>Chinese (Simplified)</option><option>Chinese (Traditional)</option><option>English</option><option>Japanese</option><option>Korean</option><option>Thai</option><option>Vietnamese</option></select></div>").appendTo($row);
	return $userLanguage;
}

/* save the user language */
function setUserLanguage(_dialog) {
	var $dialog = $("#" + _dialog.id);
	$dialog.addClass("working");
	setTimeout(function() {
		dialogHider(_dialog);
		document.location.href = 'index.html';
	}, 1000);
}

/* show language dialog */
function showLanguageDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "SetLanguage",
		title: "Set Language",
		size: "small",
		icon: "<i class='fa fa-language'></i>",
		content: function() {
			return populateUserLanguage()
		},
		buttons: [{
			name: "Cancel",
			icon: "<i class='fa fa-times fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					dialogHider(_dialog)
				}
			}]
		}, {
			name: "Ok",
			icon: "<i class='fa fa-check fa-fw'></i>",
			events: [{
				event: "click",
				action: function(e) {
					e.preventDefault();
					setUserLanguage(_dialog)
				}
			}],
			cssClass: "primary"
		}]
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

/* set the user homepage */
function setUserHomepage() {
	$("body").addClass("loading");
	$(".header, .shell").find(":focusable").attr("tabindex", -1);
	setTimeout(function() {
		$("body").removeClass("loading");
		$(".header, .shell").find(":focusable").removeAttr("tabindex");
		buildNotification("Your ANZ Transactive Global Homepage has been set to this page", 300, 1500);
	}, 800);
}



/********** APPLICATIONS **********/

/* sso applications array */
var applications = [{
	name: "ANZ Transactive - AU & NZ",
	target: "ANZ Transactive - AU NZ",
	url: "about:blank"
}, {
	name: "ANZ Transactive - Cash Asia",
	target: "ANZ Transactive - Cash Asia",
	url: "about:blank"
}, {
	name: "ANZ Transactive - Trade",
	target: "ANZ Transactive - Trade",
	url: "about:blank"
}, {
	name: "ANZ Transactive - APEA",
	target: "ANZ Transactive - APEA",
	url: "about:blank"
}, {
	name: "ANZ Royal Transactive",
	target: "",
	url: "about:blank"
}, {
	name: "ANZ Online",
	target: "ANZ Online",
	url: "about:blank"
}, {
	name: "ANZ Liquidity Management",
	target: "ANZ Liquidity Management",
	url: "about:blank"
}, {
	name: "ANZ Cashactive Control - AU",
	target: "ANZ Cashactive Control - AU",
	url: "about:blank"
}, {
	name: "ANZ Cashactive Control - NZ",
	target: "",
	url: "about:blank"
}, {
	name: "ANZ Cashactive Virtual - AU",
	target: "ANZ Cashactive Virtual - AU",
	url: "about:blank"
}, {
	name: "ANZ Cashactive Virtual - NZ",
	target: "ANZ Cashactive Virtual - NZ",
	url: "about:blank"
}, {
	name: "ANZ Fileactive",
	target: "ANZ Fileactive",
	url: "about:blank"
}, {
	name: "ANZ FX Online",
	target: "ANZ FX Online",
	url: "about:blank"
}, {
	name: "ANZ eMatching - AU",
	target: "ANZ eMatching - AU",
	url: "about:blank"
}, {
	name: "ANZ eMatching - NZ",
	target: "ANZ eMatching - NZ",
	url: "about:blank"
}, {
	name: "ANZ Billing & Analytics",
	target: "ANZ Billing Analytics",
	url: "about:blank"
}];


/********** DOWNLOADS SERVICE **********/

var downloadPanelLoaded = false;

function populateDownloads() {

	var $messageList = $("div.download-list"),
		$submenu = $messageList.closest("div.services-submenu");

	$submenu.removeClass("loading");
	downloadPanelLoaded = true;
}

/* show the message service panel */
function showDownloadService(e) {
	e.preventDefault();
	var $target = $(e.target).closest("li");
	if (!downloadPanelLoaded) {
		var $submenu = $target.children("div.services-submenu");
		$submenu.addClass("loading");
		populateDownloads();
	}
	showServices(e);
}

/********** MESSAGES SERVICE **********/

/* check if messages have been loaded and dialogs created */
var messagePanelLoaded = false;

/* messages array */
var messages = [{
	id: "ANZMessage1",
	date: "03/06/2014",
	title: "Routine Scheduled Maintenance",
	message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ultrices ligula purus, vel rutrum lorem tristique quis. Quisque pretium enim nec blandit blandit. Aliquam sed erat tellus. Nullam euismod sit amet metus eget feugiat. Nunc est massa, iaculis et leo ac, molestie dapibus nisi massa nunc. Nullam euismod sit amet metus eget feugiat. Nunc est massa, iaculis et leo ac, molestie dapibus nisi massa nunc.",
	link: "More Information...",
	url: "about:blank"
}, {
	id: "ANZMessage2",
	date: "02/06/2014",
	title: "Routine Scheduled Maintenance",
	message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ultrices ligula purus, vel rutrum lorem tristique quis. Quisque pretium enim nec blandit blandit. Aliquam sed erat tellus. Nullam euismod sit amet metus eget feugiat. Nunc est massa, iaculis et leo ac, molestie dapibus nisi massa nunc.",
	link: "More Information...",
	url: "about:blank"
}, {
	id: "ANZMessage3",
	date: "01/06/2014",
	title: "Routine Scheduled Maintenance",
	message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ultrices ligula purus, vel rutrum lorem tristique quis.",
	link: "More Information...",
	url: "about:blank"
}, {
	id: "ANZMessage4",
	date: "01/02/2014",
	title: "Routine Scheduled Maintenance",
	message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ultrices ligula purus, vel rutrum lorem tristique quis.",
	link: "More Information...",
	url: "about:blank"
}];

/* populate messages in message service panel */
function populateMessages() {
	var $messageList = $("div.message-list"),
		$submenu = $messageList.closest("div.services-submenu"),
		$ul = $("<ul />"),
		$li, $a, $date, $title, $message, $link, _shortmsg;
	$.each(messages, function() {
		$li = $("<li />").appendTo($ul),
			$a = $("<a href='#" + this.id + "' />").appendTo($li).on("click", function(e) {
				e.preventDefault();
				var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
				var _messageID = $(this).attr("href").substring(1),
					i = 0,
					_dialog;
				while (i < messages.length) {
					if (messages[i].id == _messageID) {
						_dialog = messages[i];
						break;
					}
					i += 1;
				}
				_dialog = {
					id: _dialog.id,
					title: "ANZ Message",
					size: "small",
					icon: "<i class='fa fa-circle'></i>",
					content: "<div class='message-dialog'><div style='position: absolute; top: 10px; right: 10px; color: #394A58;'>" + _dialog.date + "</div><div style='font-size: 18px; color: #004165; margin-top: 10px;'>" + _dialog.title + "</div><div style='color: #394A58;'>" + _dialog.message + "</div><div><a href='" + _dialog.url + "' target='" + _dialog.url + "'>" + _dialog.link + "</a></div></div>"
				}
				dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
			}),
			$date = $("<div><i class='fa fa-circle fa-fw'></i>" + this.date + "</div>").appendTo($a),
			$title = $("<div>" + this.title + "</div>").appendTo($a);
		if (this.message.length >= 160) {
			_shortmsg = this.message.substring(0, 160) + '...'
		} else {
			_shortmsg = this.message
		}
		$message = $("<div class='message'>" + _shortmsg + "</div>").appendTo($a),
			$link = $("<a class='message-link' href='" + this.url + "' target='" + this.url + "'>" + this.link + "</a>").appendTo($li);
	});
	$ul.appendTo($messageList);
	$submenu.removeClass("loading");
	messagePanelLoaded = true;
}

/* show the message service panel */
function showMessageService(e) {
	e.preventDefault();
	var $target = $(e.target).closest("li");
	if (!messagePanelLoaded) {
		var $submenu = $target.children("div.services-submenu");
		$submenu.addClass("loading");
		populateMessages();
	}
	showServices(e);
}



/********** HELP SERVICE *********/

/* check if faqs have been loaded */
var faqsLoaded = false;

var faqs = [];

/* populate the faq content */
function populateFAQs() {
	var $helpList = $("div.help-list"),
		$submenu = $helpList.closest("div.services-submenu"),
		$ul = $("<ul />"),
		$li, $a, $summary, $openIcon, $closeIcon, $faq;
	$.each(faqs, function() {
		$li = $("<li />").appendTo($ul),
			$a = $("<a class='faq'><div class='faq-title'>" + this.title + "</div></a>").appendTo($li);
		if(this.action){
			 $a.attr("href", "#" );
			 $("<div class='faq-open'><i class='fa fa-chevron-circle-right fa-fw fa-lg'></i></div>").appendTo($a);
			 $a.on("click", function(e) {
				e.preventDefault();
				renderSliderDialog(e); 
			});

		}
		else if (this.link && this.target) {
			$a.attr("href", this.link);
			$a.attr("target", this.target);
			$openIcon = $("<div class='faq-open'><i class='fa fa-external-link fa-fw'></i></div>").appendTo($a);
		} else {
			$a.attr("href", "#" + this.title);
			$openIcon = $("<div class='faq-open'><i class='fa fa-chevron-circle-right fa-fw fa-lg'></i></div>").appendTo($a);
			$closeIcon = $("<div class='faq-close'><i class='fa fa-times-circle fa-fw fa-lg'></i></div>").appendTo($a);
			$a.on("click", function(e) {
				e.preventDefault();
				$(this).parent("li").toggleClass("open")
			});
		}
		if (this.summary) {
			$summary = $("<div class='faq-summary'>" + this.summary + "</div>").appendTo($a);
		}
		if (this.faq) {
			$faq = $("<div class='faq-text'>" + this.faq + "</div>").appendTo($li);
		}
	});
	$ul.appendTo($helpList);
	$submenu.removeClass("loading");
	faqsLoaded = true;
}

/* show help service panel */
function showHelpService(e) {
	e.preventDefault();
	var $target = $(e.target).closest("li");
	if (!faqsLoaded) {
		var $submenu = $target.children("div.services-submenu");
		$submenu.addClass("loading");
		populateFAQs();
	}
	showServices(e);
}

/* show contact us dialog */
function showContactUsDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "ContactUs",
		title: "Contact Us",
		size: "large",
		icon: "<i class='fa fa-phone'></i>",
		content: "<p style='padding: 25px; color: #999;'>I am you trying to contact us</p>"
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}

/* show online resources dialog */
function showOnlineResourcesDialog(e) {
	e.preventDefault();
	var _origin = $(this).closest(".dialog-parent").length > 0 ? $(this).closest(".dialog-parent") : $(this);
	var _dialog = {
		id: "OnlineResources",
		title: "Online Resources",
		size: "large",
		icon: "<i class='fa fa-phone'></i>",
		content: "<p style='padding: 25px; color: #999;'>I am online resources</p>"
	}
	dialogViewer(_origin, _dialog, dialogBuilder(_dialog));
}



/* RESTRICT AND RELEASE TAB FOCUS TO A SECTION */
/* restrict and release tab focus functions. Used to restrict tabbing to a specific section like a dialog or form */

function restrictTabFocus(element, item) {

	var $element = element;

	var items = $element.find('select, input, textarea, button, a').filter(':visible');
	var inputs = $element.find('select, input, textarea').filter(':visible');

	items.off('keydown.tabfocus');

	inputs.off('keydown.tabfocus').on("keydown.tabfocus", function(e) {
		if (e.keyCode === 27) {
			$(this).blur();
			e.stopPropagation();
		}
	});

	var firstInput = null;
	if (inputs.length) {
		firstInput = inputs.first();
	}
	var firstItem = items.first();
	var lastItem = items.last();

	if (item) {
		item.focus();
	} else {
		if (firstInput != null) {
			firstInput.focus();
		} else {
			firstItem.focus();
		}
	}

	lastItem.off('keydown.tabfoucs').on('keydown.tabfocus', function(e) {
		if ((e.which === 9 && !e.shiftKey)) {
			e.preventDefault();
			firstItem.focus();
		}
	});

	firstItem.off('keydown.tabfoucs').on('keydown.tabfocus', function(e) {
		if ((e.which === 9 && e.shiftKey)) {
			e.preventDefault();
			lastItem.focus();
		}
	});
}


/********** DIALOGS **********/

/* dialog timer */
var dialogTimer, focusableItems;

/* build the dialog */
function dialogBuilder(_dialog) {
	var $dialogContainer = $("<div class='dialog-container' id='" + _dialog.id + "' />"),
		$dialogHeader = $("<div class='dialog-header' />").appendTo($dialogContainer).html(_dialog.icon + _dialog.title),
		$dialogControls = $("<div class='dialog-controls'></div>").appendTo($dialogContainer),
		$dialogClose = $("<a href='#" + _dialog.id + "' data-modal-control='close'><i class='fa fa-times fa-fw'></i></a>").on("click", function(e) {
			e.preventDefault();
			dialogHider(_dialog)
		}).appendTo($dialogControls);
	if (_dialog.closeAction) {
		$dialogClose.on("click", _dialog.closeAction);
	}
	var $dialogBody = $("<div class='dialog-body' />").appendTo($dialogContainer),
		$dialogContent = $("<div class='dialog-content' />").appendTo($dialogBody).html(_dialog.content);
	if (_dialog.buttons) {
		$dialogContent.addClass("has-buttons");
		var $dialogButtons = $("<div class='dialog-buttons' />").appendTo($dialogBody);
		for (var b = 0; b < _dialog.buttons.length; b++) {
			var $button = $("<a href='#" + _dialog.id + "' class='form-button'>" + _dialog.buttons[b].icon + _dialog.buttons[b].name + "</a>").appendTo($dialogButtons);
			if (_dialog.buttons[b].cssClass) {
				$button.addClass(_dialog.buttons[b].cssClass);
			}
			if (_dialog.buttons[b].attributes) {
				for (var a = 0; a < _dialog.buttons[b].attributes.length; a++) {
					$button.attr(_dialog.buttons[b].attributes[a].name, _dialog.buttons[b].attributes[a].value);
				}
			}
			if (_dialog.buttons[b].events) {
				for (var e = 0; e < _dialog.buttons[b].events.length; e++) {
					$button.on(_dialog.buttons[b].events[e].event, _dialog.buttons[b].events[e].action);
				}
			}
		}
	}

	return $dialogContainer;
}

/* hide dialog */
function dialogHider(_dialog) {
	var $dialog = $("#" + _dialog.id),
		_origin = $("[data-modal-parent-of='" + _dialog.id + "']");
	if (typeof _dialog.hasgrid == "function") {
		_dialog.hasgrid();
	}
	$dialog.removeClass("open " + _dialog.size);
	if ($dialog.hasClass("working")) {
		$dialog.removeClass("working")
	};
	if (_origin.is(":visible")) {
		$dialog.css({
			width: _origin.width(),
			height: _origin.height(),
			top: _origin.offset().top,
			left: _origin.offset().left
		});
	}
	dialogTimer = setTimeout(function() {
		_origin.removeAttr("data-modal-parent-of");
		$dialog.remove();
		$(document).off("keydown.dialog-manager");
		if (!$(".dialog-container").length) {
			$("body").removeClass("has-dialog");
			focusableItems.removeAttr("tabindex");
			focusableItems = '';
		} else {
			var _count = $("div.dialog-container").size();
			$("div.dialog-container").last().removeClass("moveback");
			$(document).on("keydown.dialog-manager", function(e) {
				if (e.keyCode == 27) {
					e.stopPropagation();
					dialogHider($("div.dialog-container").get(-1));
				}
			});
		}
		if (_dialog.from) {
			_dialog.from.focus();
		}
		if (typeof _dialog.close == "function") {
			_dialog.close();
		}
	}, 300);
}

/* show dialog */
function dialogViewer(_origin, _dialog, $dialog, callback) {
	clearTimeout(dialogTimer);
	var _hasOpenDialog = ($("div.dialog-container").size()) ? true : false;
	if (_origin) {
		$dialog.css({
			width: _origin.width(),
			height: _origin.height(),
			top: _origin.offset().top,
			left: _origin.offset().left
		})
	}
	$dialog.appendTo("body");
	dialogTimer = setTimeout(function() {
		$dialog.addClass("open " + _dialog.size);
		if (_origin) {
			_dialog.from = _origin;
		}
		$("body").addClass("has-dialog");
		if (_hasOpenDialog) {
			$("div.dialog-container").not($dialog).each(function() {
				$(this).addClass("moveback");
			});
		}
		focusableItems = $(".header, .nav, .shell, .control-menus, .dialog-windows").find(":focusable").attr("tabindex", -1);
		if ($(".ie8").size() > 0) {
			var $icons = $dialog.find(".fa");
			$icons.addClass("repaint");
			setTimeout(function() {
				$icons.removeClass("repaint");
			}, 1)
		}
		$(document).off("keydown.dialog-manager").on("keydown.dialog-manager", function(e) {
			if (e.keyCode == 27) {
				e.stopPropagation();
				dialogHider(_dialog);
			}
		});
		restrictTabFocus($dialog);
		$dialog.find("div.dialog-content").scrollTop(0);
		if (typeof callback == "function") {
			callback();
		}
	}, 10);
}



/********** CONFIRMATIONS AND PROMPTS **********/

/* cancel the confirmation dialog */
function closeConfirmation(e) {
	e.preventDefault();
	$(e.target).closest("div.confirmation-dialog").remove();
	$(document).off("keydown.confirm-overlay");
	$("body").removeClass("confirmation-overlay");
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").removeAttr("tabindex");
	} else {
		$(".header, .shell").find(":focusable").removeAttr("tabindex");
	}
}

/* ok the confirmation dialog */
function confirmOk(e, yes) {
	e.preventDefault();
	yes();
	closeConfirmation(e);
}

/* cancel the confirmation action */
function cancelConfirmationButton(e, no) {
	e.preventDefault();
	no();
	closeConfirmation(e);
}

/* build and show the confirmation dialog */
function buildConfirmDialog(messageA, messageB, yes, no) {
	var $confirmDialog = $("<div class='confirmation-dialog' />"),
		$confirmMessageContainer = $("<div class='confirmation-message' />").appendTo($confirmDialog),
		$confirmMessageA = $("<p>" + messageA + "</p>").appendTo($confirmMessageContainer),
		$confirmMessageB = $("<p>" + messageB + "</p>").appendTo($confirmMessageContainer),
		$confirmButtons = $("<div class='confirmation-buttons' />").appendTo($confirmDialog);
	if (typeof yes == "function") {
		if (typeof no == "function") {
			var $cancelButton = $("<a href='#ok' class='form-button' id='confirmDialogCancel'>Cancel</a>").on("click", function(e) {
				cancelConfirmationButton(e, no)
			}).appendTo($confirmButtons);
		} else {
			var $cancelButton = $("<a href='#cancel' class='form-button' id='confirmDialogCancel'>Cancel</a>").on("click", closeConfirmation).appendTo($confirmButtons);
		}
		var $okButton = $("<a href='#ok' class='form-button primary' id='confirmDialogOk'>Ok</a>").on("click", function(e) {
			confirmOk(e, yes)
		}).appendTo($confirmButtons);
	} else {
		var $okButton = $("<a href='#ok' class='form-button primary' id='confirmDialogOk'>Ok</a>").on("click", closeConfirmation).appendTo($confirmButtons);
	};
	$confirmDialog.appendTo("body").css({
		"position": "absolute",
		"top": "50%",
		"left": "50%",
		"width": $confirmDialog.outerWidth(true),
		'margin-top': -$confirmDialog.height() / 2,
		'margin-left': -$confirmDialog.outerWidth(true) / 2,
		'visibility': 'visible'
	});
	$okButton.focus();
	$("body").addClass("confirmation-overlay");
	$(document).on("keydown.confirm-overlay", function(e) {
		if (e.keyCode == 27) {
			e.stopImmediatePropagation();
		}
	})
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").attr("tabindex", -1);
	} else {
		$(".header, .shell").find(":focusable").attr("tabindex", -1);
	}
}

/* build and show the confirmation dialog */
function buildConfirmDialog1(messageA, messageB, yes, no) {
	var $confirmDialog = $("<div class='confirmation-dialog' />"),
		$confirmMessageContainer = $("<div class='confirmation-message' />").appendTo($confirmDialog),
		$confirmMessageA = $("<p>" + messageA + "</p>").appendTo($confirmMessageContainer),
		$confirmMessageB = $("<p>" + messageB + "</p>").appendTo($confirmMessageContainer),
		$confirmButtons = $("<div class='confirmation-buttons' />").appendTo($confirmDialog);
	if (typeof yes == "function") {
		if (typeof no == "function") {
			var $cancelButton = $("<a href='#ok' class='form-button' id='confirmDialogCancel'>No</a>").on("click", function(e) {
				cancelConfirmationButton(e, no)
			}).appendTo($confirmButtons);
		} else {
			var $cancelButton = $("<a href='#cancel' class='form-button' id='confirmDialogCancel'>No</a>").on("click", closeConfirmation).appendTo($confirmButtons);
		}
		var $okButton = $("<a href='#ok' class='form-button primary' id='confirmDialogOk'>Yes</a>").on("click", function(e) {
			confirmOk(e, yes)
		}).appendTo($confirmButtons);
	} else {
		var $okButton = $("<a href='#ok' class='form-button primary' id='confirmDialogOk'>Yes</a>").on("click", closeConfirmation).appendTo($confirmButtons);
	};
	$confirmDialog.appendTo("body").css({
		"position": "absolute",
		"top": "50%",
		"left": "50%",
		"width": $confirmDialog.outerWidth(true),
		'margin-top': -$confirmDialog.height() / 2,
		'margin-left': -$confirmDialog.outerWidth(true) / 2,
		'visibility': 'visible'
	});
	$okButton.focus();
	$("body").addClass("confirmation-overlay");
	$(document).on("keydown.confirm-overlay", function(e) {
		if (e.keyCode == 27) {
			e.stopImmediatePropagation();
		}
	})
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").attr("tabindex", -1);
	} else {
		$(".header, .shell").find(":focusable").attr("tabindex", -1);
	}
}


function buildConfirmOkDialog(messageA, messageB, yes) {
	var $confirmDialog = $("<div class='confirmation-dialog' />"),
		$confirmMessageContainer = $("<div class='confirmation-message' />").appendTo($confirmDialog),
		$confirmMessageA = $("<p>" + messageA + "</p>").appendTo($confirmMessageContainer),
		$confirmMessageB = $("<p>" + messageB + "</p>").appendTo($confirmMessageContainer),
		$confirmButtons = $("<div class='confirmation-buttons' />").appendTo($confirmDialog);
	if (typeof yes == "function") {
		var $okButton = $("<a href='#ok' class='form-button primary' id='confirmDialogOk'>Ok</a>").on("click", function(e) {
			confirmOk(e, yes)
		}).appendTo($confirmButtons);
	} else {
		var $okButton = $("<a href='#ok' class='form-button primary' id='confirmDialogOk'>Ok</a>").on("click", closeConfirmation).appendTo($confirmButtons);
	};
	$confirmDialog.appendTo("body").css({
		"position": "absolute",
		"top": "50%",
		"left": "50%",
		"width": $confirmDialog.outerWidth(true),
		'margin-top': -$confirmDialog.height() / 2,
		'margin-left': -$confirmDialog.outerWidth(true) / 2,
		'visibility': 'visible'
	});
	$okButton.focus();
	$("body").addClass("confirmation-overlay");
	$(document).on("keydown.confirm-overlay", function(e) {
		if (e.keyCode == 27) {
			e.stopImmediatePropagation();
		}
	})
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").attr("tabindex", -1);
	} else {
		$(".header, .shell").find(":focusable").attr("tabindex", -1);
	}
}

function closeCustomDialog(e) {
	e.preventDefault();
	$(e.target).closest("div.custom-dialog").remove();
	$("body").removeClass("confirmation-overlay");
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").removeAttr("tabindex");
	} else {
		$(".header, .shell").find(":focusable").removeAttr("tabindex");
	}
}

function customDialogFunction(e, btnFunction) {
	e.preventDefault();
	btnFunction();
	closeCustomDialog(e);
}

function buildCustomConfirmDialog(messageA, messageB, messageC, btnAtext, btnAfunction, btnAstyle, btnBtext, btnBfunction, btnBstyle, btnCtext, btnCfunction, btnCstyle) {
	var $customDialog = $("<div class='custom-dialog' />"),
		$customContainer = $("<div class='custom-message' />").appendTo($customDialog),
		$customMessageA = $("<p>" + messageA + "</p>").appendTo($customContainer),
		$customMessageB = $("<p>" + messageB + "</p>").appendTo($customContainer),
		$customMessageC = $("<p>" + messageC + "</p>").appendTo($customContainer);
	if (btnAtext || typeof btnAFunction == "function") {
		var $customButtons = $("<div class='custom-buttons' />").appendTo($customDialog),
			$btnA = $("<a href='javascript:void(0)' title='" + btnAtext + "' class='form-button " + btnAstyle + "'>" + btnAtext + "</a>").on("click", function(e) {
				customDialogFunction(e, btnAfunction)
			}).appendTo($customButtons);
	}
	if (btnBtext || typeof btnBFunction == "function") {
		var $btnB = $("<a href='javascript:void(0)' title='" + btnBtext + "' class='form-button " + btnBstyle + "'>" + btnBtext + "</a>").on("click", function(e) {
			customDialogFunction(e, btnBfunction)
		}).appendTo($customButtons);
	}
	if (btnCtext || typeof btnCFunction == "function") {
		var $btnC = $("<a href='javascript:void(0)' title='" + btnCtext + "' class='form-button " + btnCstyle + "'>" + btnCtext + "</a>").on("click", function(e) {
			customDialogFunction(e, btnCfunction)
		}).appendTo($customButtons);
	}
	$customDialog.appendTo("body").css({
		"position": "absolute",
		"top": "50%",
		"left": "50%",
		"width": $customDialog.outerWidth(true),
		'margin-top': -$customDialog.height() / 2,
		'margin-left': -$customDialog.outerWidth(true) / 2,
		'visibility': 'visible'
	});
	$("body").addClass("confirmation-overlay");
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").attr("tabindex", -1);
	} else {
		$(".header, .shell").find(":focusable").attr("tabindex", -1);
	}
}

function buildCustomDialog(messages, buttons) {
	var $customDialog = $("<div class='custom-dialog' />"),
		$customContainer = $("<div class='custom-message' />").appendTo($customDialog);

	if (messages) {
		for (var i = 0, l = messages.length; i < l; i++) {
			var _msg = messages[i];
			var $p = $("<p style='" + _msg.style + "'>" + _msg.text + "</p>").appendTo($customContainer);
		}
	}

	var $customButtons = $("<div class='custom-buttons' />").appendTo($customDialog);

	if (buttons) {
		for (var a = 0, b = buttons.length; a < b; a++) {
			var _btn = buttons[a];
			var btn = $("<a hef='javascript:void(0)' title='" + _btn.title + "' class='form-button " + _btn.class + "'>" + _btn.title + "</a>").appendTo($customButtons).on("click", _btn.action);
		}
	}

	$customDialog.appendTo("body").css({
		"position": "absolute",
		"top": "50%",
		"left": "50%",
		"width": $customDialog.outerWidth(true),
		'margin-top': -$customDialog.height() / 2,
		'margin-left': -$customDialog.outerWidth(true) / 2,
		'visibility': 'visible'
	});

	$("body").addClass("confirmation-overlay");
	if ($(".dialog-container").length) {
		$(".dialog-container").find(":focusable").attr("tabindex", -1);
	} else {
		$(".header, .shell").find(":focusable").attr("tabindex", -1);
	}
}


/********* NOTIFICATIONS **********/

/* notification timers */
var showNotification, hideNotification;

/* hide and remove the notification */
function removeNotification() {
	clearTimeout(showNotification);
	clearTimeout(hideNotification);
	$("div.notification").removeClass("show");
	hideNotification = setTimeout(function() {
		$("div.notification").remove()
	}, 300);
}

/* build and show the notification */
function buildNotification(message, delay, time) {
	clearTimeout(showNotification);
	clearTimeout(hideNotification);
	if ($("div[class*='notification']").length > 0) {
		$("div[class*='notification']").remove()
	}
	var $notification = $("<div class='notification' />"),
		$notificationMessage = $("<div class='notification-message' />").appendTo($notification),
		$icon = $("<i class='fa fa-check-circle fa-fw'></i>").appendTo($notificationMessage),
		$message = $("<span>" + message + "</span>").appendTo($notificationMessage),
		$notificationControl = $("<div class='notification-controls' />").appendTo($notification),
		$notificationCloseIcon = $("<a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i></a>").on("click", function(e) {
			removeNotification(e)
		}).appendTo($notificationControl);
	$notification.appendTo($("body")).css({
		'height': $notification.height(),
		'top': -$notification.height()
	});
	showNotification = setTimeout(function() {
		$notification.addClass('show');
		hideNotification = setTimeout(function() {
			removeNotification()
		}, parseInt(time))
	}, parseInt(delay));
}

/* hide and remove error notification */
function removeErrorNotification() {
	var msgHeight = $("div.error-notification").outerHeight();
	$("div.error-notification").removeClass("show").css("top", -msgHeight);
	$(document).off("click.error-notification");
	hideNotification = setTimeout(function() {
		$("div.error-notification").remove();
	}, 300);
}

function immediateRemoveErrorNotification() {
	$(document).off("click.error-notification");
	$("div.error-notification").remove();
}

/* toggle error message */
function toggleErrorMessage(e) {
	var $icon = $(e.target).prop("nodeName") == "I" ? $(e.target) : $(e.target).children("i"),
		$error = $("div.error-notification"),
		showMessage = $error.hasClass("show");
	if (showMessage) {
		$error.removeClass("show");
		$icon.removeClass("fa-chevron-up").addClass("fa-chevron-down");
	} else {
		$error.addClass("show");
		$icon.removeClass("fa-chevron-down").addClass("fa-chevron-up");
	}
}

function errorMessageClickInteraction(e) {
	var $target = $(e.target);
	if ($target.parents("div.error-notification").length != 0) {
		$("div.error-notification").css("z-index", "1000");
	} else {
		if ($("div.error-notification").css("z-index") != 400) {
			$("div.error-notification").css("z-index", "400");
		}
	}
}

/* build and preview error notification */
function buildErrorNotification(heading, message, delay) {
	clearTimeout(showNotification);
	clearTimeout(hideNotification);
	if ($("div[class*='notification']").length > 0) {
		$("div[class*='notification']").remove()
	}
	var $error = $("<div class='error-notification' />"),
		$errorHeading = $("<div class='error-head'><i class='fa fa-warning fa-fw fa-2x'></i><span>" + heading + "</span></div>").appendTo($error),
		$errorControls = $("<div class='error-controls' />").appendTo($error),
		$errorControlDiv = $("<div />").appendTo($errorControls);
	if (message) {
		$showMessageIcon = $("<a href='javascript:void(0)'><i class='fa fa-chevron-up fa-fw'></i></a>").on("click", toggleErrorMessage).appendTo($errorControlDiv);
		$errorMessage = $("<div class='error-content'>" + message + "</div>").appendTo($error);
	}
	$errorCloseIcon = $("<a href='javascript:void(0)'><i class='fa fa-times fa-fw'></i></a>").on("click", function(e) {
		e.preventDefault();
		removeErrorNotification()
	}).appendTo($errorControlDiv);
	$error.appendTo($("body"));
	var cntrlHeight = $errorHeading.outerHeight(),
		msgHeight = $errorMessage.outerHeight();
	$error.css("top", -(msgHeight + cntrlHeight + 5)).height(msgHeight + cntrlHeight);
	$(document).on("click.error-notification", errorMessageClickInteraction);
	showNotification = setTimeout(function() {
		$error.css("top", -(msgHeight)).addClass("show");
	}, parseInt(delay));
}



/********* CONTROL MENU FLYOUT **********/

/* show and hide control menus */
function controlMenuManager(e) {
	e.preventDefault();
	e.stopPropagation();
	var $button = $(this),
		buttons = $("div.control-list").find("span.has-menu"),
		controlMenu = $button.children("a").attr("href"),
		controlMenus = $("div.control-menus div.control-menu"),
		indicator = $(".indicator-menu").length,
		_items = $(controlMenu).find("a").size(),
		_currentItem = null,
		controlMenuTop = ($button.offset().top + $button.height());

	if ($button.closest("div.control-list").hasClass("dropup") || $button.hasClass("dropup")) {
		controlMenuTop = ($button.offset().top - $(controlMenu).height() - 24);
	}

	var controlMenuLeft = ($button.offset().left),
		controlMenuWidth = $(controlMenu).width(),
		controlMenuHeight = $(controlMenu).height(),
		positionBottom = (controlMenuTop + controlMenuHeight),
		buttonWidth = $button.width();
	if (indicator > 0) {
		$(".indicator-menu").hide()
	};
	if ($button.hasClass("disabled")) {
		return false
	};

	if ($button.closest("span").hasClass("pill-end")) {
		controlMenuLeft = ($button.prev().offset().left);
		buttonWidth = buttonWidth + $button.prev().width()
	}
	if (controlMenuLeft + controlMenuWidth > $(window).width()) {
		controlMenuLeft = (controlMenuLeft - controlMenuWidth) + buttonWidth
	}

	function hideMenus() {
		$(buttons).removeClass("on");
		$button.removeClass("on");
		$("span.has-menu").removeClass("on");
		$(controlMenus).hide().css({
			"z-index": "100",
			height: "auto",
			overflowY: "hidden"
		});
		$(controlMenus).find("a.sub-open").removeClass("sub-open");
		$(document).off("keyup.hide-menu");
		$(window).off("resize.hide-menu");
		$("body").off("click.hide-menu");
	}

	if ($(controlMenu).is(":visible")) {
		hideMenus();
	} else {
		hideMenus();
		$button.removeClass("focused").addClass("on");
		if ($button.parents().hasClass("dialog")) {
			$(controlMenu).css({
				"z-index": "400"
			})
		}
		$(controlMenu).css({
			top: controlMenuTop + 2,
			left: controlMenuLeft
		});
		if (positionBottom > $(window).height()) {
			var newMenuHeight = (controlMenuHeight - (positionBottom - $(window).height()) - 25)
			$(controlMenu).css({
				overflowY: "scroll",
				height: newMenuHeight
			});
		}
		$(controlMenu).show();
		$(window).on("resize.hide-menu", function() {
			hideMenus()
		});
		$(document).on("keyup.hide-menu", function(e) {
			e.preventDefault();
			if (e.keyCode == 27) {
				hideMenus()
			} else if (e.keyCode == 40) {
				if (_currentItem == null || _currentItem == _items - 1) {
					_currentItem = -1;
				}
				_currentItem++;
				$(controlMenu).find("a").eq(_currentItem).focus();
			} else if (e.keyCode == 38) {
				if (_currentItem == null || _currentItem == 0) {
					_currentItem = _items
				}
				_currentItem--;
				$(controlMenu).find("a").eq(_currentItem).focus();
			}
		});
		$("body").on("click.hide-menu", function() {
			hideMenus()
		});
	}
}



/********* CONTROL MENU ITEMS **********/
function handleControlMenuItems(e) {
	var $target = $(e.target);
	if ($target.hasClass("menu-section") || $target.prop("nodeName") == "UL" || $target.prop("nodeName") == "INPUT" || $target.prop("nodeName") == "DIV" || $target.hasClass("menu-heading") || $target.parent().hasClass("btn") || $target.hasClass("disabled")) {
		e.stopPropagation();
	}
	if ($target.prop("nodeName") == "A" || $target.prop("nodeName") == "I" || $target.prop("nodeName") == "SPAN") {
		if ($target.prop("nodeName") == "I" || $target.prop("nodeName") == "SPAN") {
			$target = $target.parent();
		}
		var listItem = $target.parent("li"),
			listGroup = listItem.closest("ul"),
			listMenu = listItem.closest("div.control-menu"),
			parentMenu = listItem.parents("div.control-menu").not(".sub"),
			menu = parentMenu.attr("id"),
			control = $("div.control-list").find("a[href='#" + menu + "']"),
			button = $(control).parent();
		if (!listItem.hasClass("no-set") && !listGroup.hasClass("no-set")) {
			parentMenu.find("li.active").removeClass("active");
			listItem.addClass("active");
		}
		if ( $(button).hasClass("show-selection") ) {
			if ( !listItem.hasClass("no-set") && !listGroup.hasClass("no-set") ) {
				var text = $target.clone().children().remove().end().text();
				$(control).children("span.item-text").text(text);				
			}
		}
		if (listItem.hasClass("has-menu")) {
			e.preventDefault();
			e.stopPropagation();
			var subMenu = listItem.children("a").attr("href"),
				subMenuHeight = $(subMenu).height(),
				subMenuWidth = $(subMenu).width(),
				winWidth = $(window).width(),
				winHeight = $(window).height(),
				subMenuTop = listItem.offset().top,
				subMenuLeft = (listItem.offset().left + listItem.width());
			if (listMenu.hasClass("drop-up")) {
				subMenuTop = (listItem.offset().top + listItem.height()) - $(subMenu).height()
			}
			if ((subMenuLeft + subMenuWidth + 30) > winWidth) {
				subMenuLeft = subMenuLeft - ((subMenuLeft + subMenuWidth) - winWidth) - 30
			}
			if ((subMenuTop + subMenuHeight + 30) > winHeight) {
				subMenuTop = subMenuTop - ((subMenuTop + subMenuHeight) - winHeight) - 30
			}
			if (listItem.hasClass('sub')) {
				var openSub = listGroup.find("a.sub-open").attr("href");
				if ($(openSub).is(":visible")) {
					$(openSub).hide()
				}
				listGroup.find("a.sub-open").removeClass("sub-open");
				$(subMenu).css({
					top: subMenuTop,
					left: subMenuLeft
				}).show();
				listItem.children("a").addClass("sub-open");
			} else {
				if ( $(subMenu).is(":visible") ) {
					$(subMenu).find("li.active").removeClass("active");
					$("div.control-menus").children("div.control-menu").not(parentMenu).hide();
					$("a.sub-open").removeClass("sub-open");
					parentMenu.find("div.control-menu").not(listMenu).hide();					
				} else {
					$(subMenu).find("li.active").removeClass("active");
					$("div.control-menus").children("div.control-menu").not(parentMenu).hide();
					$("a.sub-open").removeClass("sub-open");
					parentMenu.find("div.control-menu").not(listMenu).hide();
					$(subMenu).css({
						top: subMenuTop,
						left: subMenuLeft
					}).show();
					listItem.children("a").addClass("sub-open");					
				}
			}
		}
	}
}



/********* TAB AND PANEL SWITCHING **********/

/* switch between panels */
function panelSwitcher(e) {
	e.preventDefault();
	var $clicked = $(e.target),
		target = $(this).attr("data-panel"),
		scope = $(target).attr("data-group"),
		$panel;
	if ($clicked.closest("div[class*='-panel']").size() > 0) {
		$panel = $clicked.closest("div[class*='-panel']");
	} else {
		var $visiblePanel;
		$("div[data-group='" + scope + "']").each(function() {
			if (!$(this).hasClass("hidden")) {
				$visiblePanel = $(this);
			}
		});
		$panel = $visiblePanel;
	}
	$panel.addClass("loading");
	setTimeout(function() {
		$("[data-group='" + scope + "']").addClass("hidden");
		$panel.removeClass("loading");
		$(target).removeClass("hidden").find(".scroll-area").scrollTop(0);
		if ($(".ie8").size() > 0) {
			var $icons = $(target).find(".fa");
			$icons.addClass("repaint");
			setTimeout(function() {
				$icons.removeClass("repaint")
			}, 1)
		}
	}, 500);
}

/* switch active state between tabs */
function tabSwitcher(e) {
	var $target = $(e.target),
		$tab = $target.parent();
	if ($target.prop("nodeName") == "A") {
		e.preventDefault();
		if ($tab.hasClass("active")) {
			return false;
		} else {
			$tab.addClass("active").siblings().removeClass("active");
		}
	}
}


/********* FORM BUILDER **********/

/* build a form from the passed object */
function formBuilder(formOBJ) {

	var $dataForm = $("<div class='data-form' />"),

		$form = $("<form name='" + formOBJ.name + "' id='" + formOBJ.id + "' />").appendTo($dataForm);

	_sectionLength = formOBJ.sections.length;

	for (var i = 0; i < _sectionLength; i++) {

		var _section = formOBJ.sections[i];

		var $dataSection = $("<div class='data-entry' id='" + _section.id + "' />").appendTo($form);

		if (_section.attributes) {
			for (var s = 0; s < _section.attributes.length; s++) {
				$dataSection.attr(_section.attributes[s].name, _section.attributes[s].value);
			}
		}

		if (_section.heading) {
			var $heading = $("<div class='section-heading'>" + _section.heading + "</div>").appendTo($dataSection);
		}

		var $section = $("<div class='form-section' />").appendTo($dataSection);

		if (_section.rows) {

			var _rowLength = _section.rows.length;

			for (var r = 0; r < _rowLength; r++) {
				var _row = _section.rows[r];
				var $row = $("<div class='row' id='" + _row.id + "' />").appendTo($section);
				if (_row.mandatory) {
					$row.addClass("mandatory");
				}
				if (_row.disabled) {
					$row.addClass("disabled");
				}
				if (_row.attributes) {
					for (var ra = 0; ra < _row.attributes.length; ra++) {
						$row.attr(_row.attributes[ra].name, _row.attributes[ra].value);
					}
				}
				if (_row.label) {
					var $labelColumn = $("<div class='label-column' />").appendTo($row),
						$label = $("<label>" + _row.label + "</label>").appendTo($labelColumn);
				}
				var $dataColumn = $("<div class='data-column' />").appendTo($row);
				if (_row.dataColumnAttributes) {
					var _dataColumnAttributeLength = _row.dataColumnAttributes.length;
					for (var a = 0; a < _dataColumnAttributeLength; a++) {
						$dataColumn.attr(_row.dataColumnAttributes[a].name, _row.dataColumnAttributes[a].value)
					}
				}
				if (_row.elements) {

					var _elementLength = _row.elements.length;

					for (var e = 0; e < _elementLength; e++) {

						var _el = _row.elements[e],
							$element;

						if (_el.type == "radio") {
							$element = $("<input type='radio' name='" + _el.name + "' id='" + _el.id + "' value='" + _el.value + "' />").appendTo($dataColumn);
						}

						if (_el.type == "checkbox") {
							$element = $("<input type='checkbox' name='" + _el.name + "' id='" + _el.id + "' value='" + _el.value + "' />").appendTo($dataColumn);
						}

						if (_el.type == "input") {
							$element = $("<input type='text' name='" + _el.name + "' id='" + _el.id + "' value='" + _el.value + "' placeholder='" + _el.placeholder + "' />").appendTo($dataColumn);
						}

						if (_el.type == "textarea") {
							$element = $("<textarea name='" + _el.name + "' id='" + _el.id + "' placeholder='" + _el.placeholder + "'>" + _el.value + "</textarea>").appendTo($dataColumn);
						}

						if (_el.type == "select") {
							var $customSelect = $("<div class='custom-select' />").appendTo($dataColumn),
								$element = $("<select name='" + _el.name + "' id='" + _el.id + "'></select>").appendTo($customSelect);
							if (_el.data) {
								for (var o = 0; o < _el.data.length; o++) {
									var $option = $("<option value=" + _el.data[o].value + ">" + _el.data[o].option + "</option>").appendTo($element)
								}
							}
						}

						if (_el.type == "text") {
							$element = $("<div class='data-text' id='" + _el.id + "'>" + _el.value + "</div>").appendTo($dataColumn);
						}

						if (_el.type == "note") {
							$element = $("<div class='data-note' id='" + _el.id + "'>" + _el.value + "</div>").appendTo($dataColumn);
						}

						if (_el.description) {
							var $description = $("<label class='desc' for='" + _el.id + "'>" + _el.description + "</label>").appendTo($dataColumn);
						}

						if (_el.events) {
							for (var ev = 0; ev < _el.events.length; ev++) {
								$element.on(_el.events[ev].event, _el.events[ev].action);
							}
						}

						if (_el.attributes) {
							for (var at = 0; at < _el.attributes.length; at++) {
								$element.attr(_el.attributes[at].name, _el.attributes[at].value);
							}
						}

						if (_el.disabled || _row.disabled) {
							$element.addClass("disabled").attr("disabled", "disabled");
							if (_el.type == "select") {
								$customSelect.addClass("disabled");
							}
							if (_el.description) {
								$description.addClass("disabled");
							}
						}

					}
				}
			}
		}
	}
	if (formOBJ.cssClass) {
		$dataForm.addClass(formOBJ.cssClass)
	}
	$dataForm.appendTo("html");
	var rulesFunction = new Function(formOBJ.method);
	rulesFunction();
	$dataForm.detach();
	return $dataForm;
}


/***** ON READY BINDINGS *****/

$(function() {

	/* navigation */
	$(".nav-link").on("click", showNavigation);
	$(".app-menu-list").on("click", "a:not([target])", hideNavigation);
	$(".nav-main .has-menu").on("click", showApplicationMenu);
	$(".app-menu-close a").on("click", showNavigation);

	/* user */
	$(".user-name a").on("click", toggleUserMenu);
	$("a.user-homepage").on("click", setUserHomepage);

	/* services */
	$(".message-service").on("click", showMessageService);
	$(".help-service").on("click", showHelpService);
	$(".download-service").on("click", showDownloadService);
	$(".submenu-header a").on("click", hideServices);

	/* dialogs */
	$(".show-contact-us").on("click", showContactUsDialog);
	$(".show-online-resources").on("click", showOnlineResourcesDialog);
	$(".show-user-preferences").on("click", showUserPreferencesDialog);
	$(".show-language").on("click", showLanguageDialog);

	/* tas and panels */
	$("body").on("click.switch-tabs", "div.application-tabs", tabSwitcher);
	$("body").on("click.switch-panels", "[data-switch='switch-panels']", panelSwitcher);

	/* control bar buttons */
	$(".btn a").on("focus blur", function(e) {
		$(this).parent().toggleClass("focused", e.type === "focus")
	});
	$(".btn").not(".has-menu").on("mousedown mouseup", function(e) {
		if (e.type === "mousedown") {
			$(this).removeClass("focused").addClass("on")
		} else {
			$(this).removeClass("on focused")
		}
	});
	$(".btn.has-menu").on("mousedown", function(e) {
		$(this).removeClass("focused").addClass("on");
	});

	/* control bar menus */
	$("div.control-list").on("click.show-menu", "span.has-menu", controlMenuManager);

	/* control bar menu items */
	$("div.control-menu").on("click.menu-item-select", handleControlMenuItems);

	/* custom select focus styles */
	$(document).on("focus", ".custom-select select", function(e) {
		$(this).parent("div.custom-select").addClass("focused");
	}).on("blur", ".custom-select select", function(e) {
		$(this).parent("div.custom-select").removeClass("focused");
	})
});