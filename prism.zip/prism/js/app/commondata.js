var data = [],
	sharedData = [],
	dataschedule = [];

/**********************************************************************
REPORT PROFILES DATA
**********************************************************************/
for (var i = 0; i < 10; i++) {
	var d = (data[i] = {});
	d["id"] = Math.round(Math.random() * 1000000000);
	if (i < 5) {
		if (i % 2 == 0) {
			d["reptype"] = "Account Statement";
			d["repname"] = "Opperating Account Statements - " + Math.round(Math.random() * 100);
			d["repformat"] = "PDF"
			d["grouped"] = true
			d["description"] = "Statements For Manufacturing Inc. Operating Accounts " + Math.round(Math.random() * 100) + " to " + Math.round(Math.random() * 100);
			d["shared"] = "";
			d["sharedby"] = "";
			d["ownedby"] = "PrototypeUser";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Today";
			d["fromdate"] = "";
			d["todate"] = "";
			d["filtertype"] = "Account";
			d["filters"] = [{
				id: "id_0",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_1",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_2",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		} else {
			d["reptype"] = "Account Balance";
			d["repname"] = "Operating Account Balance Summary - " + Math.round(Math.random() * 100);
			d["repformat"] = "CSV"
			d["grouped"] = false
			d["description"] = "Balance Summary Report for Manufacturing Inc. Accounts " + Math.round(Math.random() * 100) + " to " + Math.round(Math.random() * 100);
			d["shared"] = "";
			d["sharedby"] = "";
			d["ownedby"] = "PrototypeUser";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Specific Date";
			d["fromdate"] = "06/05/2013";
			d["todate"] = "";
			d["filtertype"] = "Currency";
			d["filters"] = [{
				id: "id_0",
				ccy: "AUD",
				ccyname: "Australian Dollars"
			}, {
				id: "id_1",
				ccy: "CNY",
				ccyname: "Chinese Yuan"
			}, {
				id: "id_2",
				ccy: "EUR",
				ccyname: "Euro"
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		}
	} else {
		if (i % 2 == 0) {
			d["reptype"] = "Account Statement";
			d["repname"] = "Account Statement Report " + Math.round(Math.random() * 100);
			d["repformat"] = "Excel"
			d["grouped"] = true
			d["description"] = "Consulting Pte. Ltd. Account Statements";
			d["shared"] = "";
			d["sharedby"] = "";
			d["ownedby"] = "PrototypeUser";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Yesterday";
			d["fromdate"] = "";
			d["todate"] = "";
			d["filtertype"] = "Account";
			d["filters"] = [{
				id: "id_0",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_1",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_2",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_3",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_4",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_5",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		} else {
			d["reptype"] = "Account Balance";
			d["repname"] = "Balance Summary Report " + Math.round(Math.random() * 100);
			d["repformat"] = "CSV";
			d["grouped"] = false
			d["description"] = "Consulting Pte. Ltd. Balance Summary Reports";
			d["shared"] = "";
			d["sharedby"] = "";
			d["ownedby"] = "PrototypeUser";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Date Range";
			d["fromdate"] = "06/05/2013";
			d["todate"] = "10/05/2013";
			d["filtertype"] = "Currency";
			d["filters"] = [{
				id: "id_0",
				ccy: "AUD",
				ccyname: "Australian Dollars"
			}, {
				id: "id_1",
				ccy: "EUR",
				ccyname: "Euro"
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		}
	};
}


for (var i = 0; i < 10; i++) {
	var d = (sharedData[i] = {});
	d["id"] = Math.round(Math.random() * 1000000000);
	if (i < 5) {
		if (i % 2 == 0) {
			d["reptype"] = "Account Statement";
			d["repname"] = "Opp Statements - " + Math.round(Math.random() * 100);
			d["repformat"] = "PDF";
			d["grouped"] = false
			d["description"] = "Statement For Various Operating Accounts " + Math.round(Math.random() * 100) + " to " + Math.round(Math.random() * 100);
			d["shared"] = "y";
			d["sharedby"] = "User123";
			d["ownedby"] = "User123";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Date Range";
			d["fromdate"] = "06/05/2013";
			d["todate"] = "10/05/2013";
			d["filtertype"] = "Currency";
			d["filters"] = [{
				id: "id_0",
				ccy: "AUD",
				ccyname: "Australian Dollars"
			}, {
				id: "id_1",
				ccy: "EUR",
				ccyname: "Euro"
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		} else {
			d["reptype"] = "Account Balance";
			d["repname"] = "Operating Account Balance Summary - " + Math.round(Math.random() * 100);
			d["repformat"] = "Excel"
			d["grouped"] = false
			d["description"] = "Balance Summary Report for Manufacturing Inc. Accounts " + Math.round(Math.random() * 100) + " to " + Math.round(Math.random() * 100);
			d["shared"] = "y";
			d["sharedby"] = "userXYZ";
			d["ownedby"] = "userXYZ";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Yesterday";
			d["fromdate"] = "";
			d["todate"] = "";
			d["filtertype"] = "Account";
			d["filters"] = [{
				id: "id_0",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_1",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_2",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_3",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_4",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_5",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		}
	} else {
		if (i % 2 == 0) {
			d["reptype"] = "Account Statement";
			d["repname"] = "Account Statement Report " + Math.round(Math.random() * 100);
			d["repformat"] = "PDF";
			d["grouped"] = true
			d["description"] = "Consulting Pte. Ltd. Account Statements";
			d["shared"] = "y";
			d["sharedby"] = "userXYZ";
			d["ownedby"] = "userXYZ";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Yesterday";
			d["fromdate"] = "";
			d["todate"] = "";
			d["filtertype"] = "Account";
			d["filters"] = [{
				id: "id_0",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_1",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_2",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_3",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_4",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_5",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		} else {
			d["reptype"] = "Account Balance";
			d["repname"] = "Balance Summaries " + Math.round(Math.random() * 100);
			d["repformat"] = "Excel";
			d["grouped"] = false
			d["description"] = "Various Balance Summary Report";
			d["shared"] = "y";
			d["sharedby"] = "UserABC";
			d["ownedby"] = "UserABC";
			d["createdon"] = $.datepicker.formatDate('dd/mm/yy', new Date());
			d["datefilter"] = "Week To Date";
			d["fromdate"] = "";
			d["todate"] = "";
			d["filtertype"] = "Account";
			d["filters"] = [{
				id: "id_0",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_1",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}, {
				id: "id_2",
				accountnam: "CURRENT" + Math.round(Math.random() * 1000),
				accountnum: Math.round(Math.random() * 1000000000).toString()
			}];
			d["schedules"] = [];
			d["schedulesnumber"] = (d["schedules"].length > 0) ? d["schedules"].length : "-";
		}
	};
}


if (store.get('report-data')) {
	data = store.get('report-data');
} else {
	store.set('report-data', data);
}

if (store.get('report-sharedData')) {
	sharedData = store.get('report-sharedData');
} else {
	store.set('report-sharedData', sharedData);
}


for (var i = 0; i < 10; i++) {
	var d = (dataschedule[i] = {});
	d["id"] = "id_" + i;
	d["schedname"] = "Scheduled Report " + i;
	d["status"] = "Active";
	if (i < 5) {
		if (i % 2 == 0) {
			d["reptype"] = "Account Statement";
			d["schedfreq"] = "Daily";
			d["schedfreqdetail"] = "";
			d["schedstart"] = "30/08/2012";
			d["status"] = "Active";
			d["schedend"] = "30/08/2013";
			d["lastrundate"] = "30/08/2013";
			d["nextrundate"] = "";
			d["repprofile"] = "Y";
			d["ownedby"] = "PrototypeUser";
		} else {
			d["reptype"] = "Balance Summary";
			d["schedfreq"] = "Weekly";
			d["schedfreqdetail"] = "Monday";
			d["schedstart"] = "30/08/2012";
			d["status"] = "Active";
			d["schedend"] = "30/08/2013";
			d["lastrundate"] = "30/08/2013";
			d["nextrundate"] = "";
			d["repprofile"] = "Y";
			d["ownedby"] = "PrototypeUser";
		}
	} else {
		if (i % 2 == 0) {
			d["reptype"] = "Term Deposit Summary";
			d["schedfreq"] = "Monthly";
			d["schedfreqdetail"] = "1";
			d["schedstart"] = "30/08/2012";
			d["status"] = "Active";
			d["schedend"] = "30/08/2013";
			d["lastrundate"] = "30/08/2013";
			d["nextrundate"] = "";
			d["repprofile"] = "Y";
			d["ownedby"] = "PrototypeUser";
		} else {
			d["reptype"] = "Balance Summary";
			d["schedfreq"] = "Weekly";
			d["schedfreqdetail"] = "Monday";
			d["schedstart"] = "30/08/2012";
			d["status"] = "Active";
			d["schedend"] = "30/08/2013";
			d["lastrundate"] = "30/08/2013";
			d["nextrundate"] = "";
			d["repprofile"] = "Y";
			d["ownedby"] = "PrototypeUser";
		}
	}
}


if (store.get('schedule-data')) {
	dataschedule = store.get('schedule-data');
} else {
	store.set('schedule-data', dataschedule);
}